<?php
/**
 * Not found.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<div class="lc-container lc-page lc-404">
	<h1 class="h1 lc-page-title"><?php esc_html_e( 'No encontramos esta página', 'lachinata' ); ?></h1>
	<p class="body"><?php esc_html_e( 'Puede que el enlace haya cambiado. Busca el producto o vuelve a la tienda.', 'lachinata' ); ?></p>
	<form class="lc-search__row" role="search" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">
		<div class="lc-field lc-field--icon" style="flex: 1">
			<div class="lc-field__box">
				<?php echo lachinata_icon( 'search', array( 'size' => 'sm' ) ); ?>
				<input type="search" name="s" aria-label="<?php esc_attr_e( 'Buscar', 'lachinata' ); ?>" placeholder="<?php esc_attr_e( 'Buscar', 'lachinata' ); ?>">
				<input type="hidden" name="post_type" value="product">
			</div>
		</div>
		<?php echo lachinata_button( __( 'Buscar', 'lachinata' ), array( 'type' => 'submit' ) ); ?>
	</form>
	<?php
	echo lachinata_button(
		__( 'Ver la tienda', 'lachinata' ),
		array(
			'variant' => 'secondary',
			'href'    => function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' ),
			'icon'    => 'arrow-right',
		)
	); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped 
	?>
</div>
<?php
get_footer();
