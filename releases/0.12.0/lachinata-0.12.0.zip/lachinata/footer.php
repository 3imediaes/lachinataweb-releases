<?php
/**
 * Footer, BottomNav and the layers (menu, search, bag, toasts).
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;
?>
</main>
<?php
if ( lachinata_is_order_received() ) {
	lachinata_part( 'footer' );
} elseif ( ! lachinata_is_checkout_view() ) {
	lachinata_part( 'footer' );
	if ( ! is_singular( 'product' ) ) {
		lachinata_part( 'bottom-nav' );
	}
	lachinata_part( 'nav-drawer' );
	lachinata_part( 'search-bar' );
	lachinata_part( 'cart-sheet' );
}
?>
<div class="lc-toasts" aria-live="polite" data-lc-toasts></div>
<?php wp_footer(); ?>
</body>
</html>
