<?php
/**
 * Document head, PromoBar and AppBar (mobile and desktop).
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
	<?php wp_head(); ?>
</head>
<body <?php body_class( 'body' ); ?>>
<?php wp_body_open(); ?>
<a class="lc-skip" href="#main"><?php esc_html_e( 'Saltar al contenido', 'lachinata' ); ?></a>
<?php
if ( ! lachinata_is_checkout_view() ) {
	lachinata_part( 'promo-bar' );
}
lachinata_part( 'app-bar' );
?>
<main id="main" class="lc-main" tabindex="-1">
