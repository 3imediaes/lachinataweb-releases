<?php
/**
 * The bag: one markup for the /bolsa/ page (works without JavaScript through
 * WooCommerce's classic cart form handler) and for the BottomSheet, which loads the same
 * markup as a fragment (?lc-partial=cart) so cached pages never carry anyone's bag.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Whether the request asks for the bag fragment.
 */
function lachinata_is_cart_partial(): bool {
	return isset( $_REQUEST['lc-partial'] ) && 'cart' === $_REQUEST['lc-partial']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only switch of the template.
}

/**
 * Renders the bag page (or its fragment) whatever the cart page content is.
 *
 * @param string $template Template.
 */
function lachinata_cart_template( string $template ): string {
	if ( ! function_exists( 'is_cart' ) || ! is_cart() ) {
		return $template;
	}
	return get_template_directory() . ( lachinata_is_cart_partial() ? '/templates/cart-partial.php' : '/templates/cart-page.php' );
}
add_filter( 'template_include', 'lachinata_cart_template', 20 );

/**
 * Keeps the fragment mode across WooCommerce's redirects after updating or removing.
 *
 * @param string $location Redirect URL.
 */
function lachinata_cart_partial_redirect( string $location ): string {
	if ( lachinata_is_cart_partial() && function_exists( 'wc_get_cart_url' ) && str_starts_with( $location, wc_get_cart_url() ) ) {
		return add_query_arg( 'lc-partial', 'cart', $location );
	}
	return $location;
}
add_filter( 'wp_redirect', 'lachinata_cart_partial_redirect' );

/**
 * «Añadido a tu bolsa» message with the system wording.
 *
 * @param string            $message  Default HTML.
 * @param array<int, float> $products Product id => quantity.
 */
function lachinata_added_to_cart_message( string $message, array $products ): string {
	$names = array();
	foreach ( array_keys( $products ) as $product_id ) {
		$names[] = '«' . wp_strip_all_tags( get_the_title( $product_id ) ) . '»';
	}
	return esc_html(
		sprintf(
			/* translators: %s: product names. */
			_n( 'Has añadido %s a tu bolsa.', 'Has añadido %s a tu bolsa.', count( $names ), 'lachinata' ),
			wp_sprintf_l( '%l', $names )
		)
	);
}
add_filter( 'wc_add_to_cart_message_html', 'lachinata_added_to_cart_message', 10, 2 );

/**
 * Data of one cart line for the CartLine component.
 *
 * @param string               $key  Cart item key.
 * @param array<string, mixed> $item Cart item.
 * @return array<string, mixed>|null
 */
function lachinata_cart_line( string $key, array $item ): ?array {
	$product = $item['data'] ?? null;
	if ( ! $product instanceof WC_Product || ! $product->exists() || $item['quantity'] <= 0 ) {
		return null;
	}
	$parent = $product->is_type( 'variation' ) ? wc_get_product( $product->get_parent_id() ) : $product;
	$meta   = wp_strip_all_tags( wc_get_formatted_cart_item_data( $item, true ) );
	$unit   = lachinata_unit_price( $product );
	$max    = $product->get_max_purchase_quantity();
	/**
	 * Note under a cart line (for example «No se envía a Alemania»). Empty by default.
	 *
	 * @since 0.2.0
	 *
	 * @param string               $note Note text.
	 * @param array<string, mixed> $item Cart item.
	 */
	$note = (string) apply_filters( 'lachinata/cart/line_note', '', $item );

	return array(
		'key'      => $key,
		'name'     => $product->get_name(),
		'href'     => $product->is_visible() ? ( $product instanceof WC_Product_Variation ? $product->get_permalink( $item ) : $product->get_permalink() ) : '',
		'image_id' => (int) ( $product->get_image_id() ? $product->get_image_id() : ( $parent ? $parent->get_image_id() : 0 ) ),
		'tint'     => $parent ? lachinata_product_tint( $parent ) : '',
		'meta'     => trim( implode( ' · ', array_filter( array( str_replace( "\n", ' · ', trim( $meta ) ), wp_strip_all_tags( $unit ) ) ) ) ),
		'note'     => $note,
		'qty'      => (int) $item['quantity'],
		'max'      => $max > 0 ? $max : 99,
		'total'    => WC()->cart->get_product_subtotal( $product, $item['quantity'] ),
		'remove'   => wc_get_cart_remove_url( $key ),
		'sold_one' => $product->is_sold_individually(),
	);
}
