<?php
/**
 * Contract with the lachinata-core plugin. The theme never calls the plugin directly:
 * it asks lachinata_module() and leaves hooks under lachinata/… (see HOOKS.md).
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'lachinata_module' ) ) {
	/**
	 * Fallback when lachinata-core is not active: no module is running.
	 *
	 * @param string $id Module id.
	 */
	function lachinata_module( string $id ): bool { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- Same signature as the plugin's.
		return false;
	}
}

/**
 * Warns in the admin when lachinata-core is older than the version this theme needs.
 * Never blocks: the theme works without the plugin.
 */
function lachinata_core_version_notice(): void {
	if ( ! defined( 'LACHINATA_CORE_VERSION' ) || ! current_user_can( 'update_plugins' ) ) {
		return;
	}
	$required = get_file_data( get_template_directory() . '/style.css', array( 'core_min' => 'LaChinata Core Min' ) )['core_min'];
	if ( '' === $required || version_compare( LACHINATA_CORE_VERSION, $required, '>=' ) ) {
		return;
	}
	printf(
		'<div class="notice notice-warning"><p>%s</p></div>',
		esc_html(
			sprintf(
				/* translators: 1: required plugin version, 2: installed plugin version. */
				__( 'El tema La Chinata necesita La Chinata Core %1$s o superior; está instalada la %2$s. Actualiza el plugin.', 'lachinata' ),
				$required,
				LACHINATA_CORE_VERSION
			)
		)
	);
}
add_action( 'admin_notices', 'lachinata_core_version_notice' );

/**
 * Lets WordPress read the theme's own header.
 *
 * @param string[] $headers Extra theme headers.
 * @return string[]
 */
function lachinata_theme_headers( array $headers ): array {
	$headers[] = 'LaChinata Core Min';
	return $headers;
}
add_filter( 'extra_theme_headers', 'lachinata_theme_headers' );
