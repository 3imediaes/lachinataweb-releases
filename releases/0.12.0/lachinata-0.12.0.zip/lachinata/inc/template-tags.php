<?php
/**
 * Small components of the design system as PHP helpers. The HTML (classes, aria-*,
 * roles) is the one the bundle components print: design-system/sistema/components/bundle.js.
 * Helpers return escaped HTML; callers echo them.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Builds an HTML attribute string from an array (null/false values are skipped).
 *
 * @param array<string, scalar|null> $attributes Attributes.
 */
function lachinata_attrs( array $attributes ): string {
	$html = '';
	foreach ( $attributes as $name => $value ) {
		if ( null === $value || false === $value ) {
			continue;
		}
		$html .= true === $value ? ' ' . esc_attr( $name ) : sprintf( ' %s="%s"', esc_attr( $name ), esc_attr( (string) $value ) );
	}
	return $html;
}

/**
 * Only the data-* attributes of a filtered list (what a module may add to a component).
 *
 * @param array<mixed> $attributes Attributes.
 * @return array<string, scalar|null>
 */
function lachinata_data_attrs( array $attributes ): array {
	$out = array();
	foreach ( $attributes as $name => $value ) {
		if ( str_starts_with( (string) $name, 'data-' ) && ( null === $value || is_scalar( $value ) ) ) {
			$out[ (string) $name ] = $value;
		}
	}
	return $out;
}

/**
 * Joins class names, skipping empty ones.
 *
 * @param string|false|null ...$classes Class names.
 */
function lachinata_cx( ...$classes ): string {
	return implode( ' ', array_filter( $classes ) );
}

/**
 * Icon: 1.5 px stroke, 24 px, currentColor. Decorative unless it gets a label.
 *
 * @param string               $name Icon name (IconName in index.d.ts).
 * @param array<string, mixed> $args size ('sm'), class, label, filled.
 */
function lachinata_icon( string $name, array $args = array() ): string {
	$label  = $args['label'] ?? null;
	$filled = 'star' === $name && ( $args['filled'] ?? true );
	return sprintf(
		'<svg%s><use href="#lc-icon-%s"></use></svg>',
		lachinata_attrs(
			array(
				'class'           => lachinata_cx( 'lc-icon', 'sm' === ( $args['size'] ?? '' ) ? 'lc-icon--sm' : '', $args['class'] ?? '' ),
				'viewBox'         => '0 0 24 24',
				'fill'            => $filled ? 'currentColor' : 'none',
				'stroke'          => 'currentColor',
				'stroke-width'    => '1.5',
				'stroke-linecap'  => 'round',
				'stroke-linejoin' => 'round',
				'aria-hidden'     => $label ? null : 'true',
				'role'            => $label ? 'img' : null,
				'aria-label'      => $label,
				'focusable'       => 'false',
			)
		),
		esc_attr( $name )
	);
}

/**
 * Official logotype, inheriting currentColor.
 *
 * @param int $height Height in px.
 */
function lachinata_logo( int $height = 18 ): string {
	static $paths = null;
	if ( null === $paths ) {
		$svg   = (string) file_get_contents( get_template_directory() . '/assets/icons/logo.svg' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Generated file of the theme.
		$paths = preg_match( '/<svg[^>]*>(.*)<\/svg>/s', $svg, $match ) ? $match[1] : '';
	}
	return sprintf(
		'<svg%s>%s</svg>',
		lachinata_attrs(
			array(
				'class'      => 'lc-logo',
				'viewBox'    => '0 0 750 105',
				'height'     => $height,
				'width'      => (int) round( $height * 750 / 105 ),
				'role'       => 'img',
				'aria-label' => __( 'La Chinata', 'lachinata' ),
			)
		),
		wp_kses(
			$paths,
			array(
				'path' => array( 'd' => true ),
			)
		)
	);
}

/**
 * Button or link button.
 *
 * @param string               $text Visible text (escaped here).
 * @param array<string, mixed> $args variant, size, icon, icon_left, block, href, class, attrs.
 */
function lachinata_button( string $text, array $args = array() ): string {
	$variant = $args['variant'] ?? 'primary';
	$size    = $args['size'] ?? 'md';
	$href    = $args['href'] ?? null;
	$attrs   = array_merge(
		array(
			'class' => lachinata_cx( 'lc-btn', 'button', 'primary' !== $variant ? 'lc-btn--' . $variant : '', 'md' !== $size ? 'lc-btn--' . $size : '', ! empty( $args['block'] ) ? 'lc-btn--block' : '', $args['class'] ?? '' ),
			'href'  => $href,
			'type'  => $href ? null : ( $args['type'] ?? 'button' ),
		),
		$args['attrs'] ?? array()
	);
	return sprintf(
		'<%1$s%2$s>%3$s%4$s%5$s</%1$s>',
		$href ? 'a' : 'button',
		lachinata_attrs( $attrs ),
		empty( $args['icon_left'] ) ? '' : lachinata_icon( $args['icon_left'] ),
		esc_html( $text ),
		empty( $args['icon'] ) ? '' : lachinata_icon( $args['icon'] )
	);
}

/**
 * Round icon button (44 px) with optional counter.
 *
 * @param string               $icon  Icon name.
 * @param string               $label Accessible name.
 * @param array<string, mixed> $args  count, class, href, attrs.
 */
function lachinata_icon_button( string $icon, string $label, array $args = array() ): string {
	$href  = $args['href'] ?? null;
	$count = (int) ( $args['count'] ?? 0 );
	$attrs = array_merge(
		array(
			'type'       => $href ? null : 'button',
			'href'       => $href,
			'class'      => lachinata_cx( 'lc-btn', 'lc-btn--icon', $args['class'] ?? '' ),
			'aria-label' => $label,
		),
		$args['attrs'] ?? array()
	);
	return sprintf(
		'<%1$s%2$s>%3$s%4$s</%1$s>',
		$href ? 'a' : 'button',
		lachinata_attrs( $attrs ),
		lachinata_icon( $icon ),
		array_key_exists( 'count', $args ) ? sprintf( '<span class="lc-btn__count" aria-hidden="true" data-lc-cart-count%s><span data-lc-count-value>%s</span></span>', $count ? '' : ' hidden', esc_html( (string) $count ) ) : ''
	);
}

/**
 * Badge.
 *
 * @param string $text  Text.
 * @param string $tone  top, new, promo, olivita, soldout or a tint; '' is neutral.
 * @param string $extra_class Extra class.
 */
function lachinata_badge( string $text, string $tone = '', string $extra_class = '' ): string {
	return sprintf( '<span class="%s">%s</span>', esc_attr( lachinata_cx( 'lc-badge', 'badge', $tone ? 'lc-badge--' . $tone : '', $extra_class ) ), esc_html( $text ) );
}

/**
 * Chip as a link (navigation) or a button.
 *
 * @param string               $text Text.
 * @param array<string, mixed> $args href, selected, tint, icon, class, attrs.
 */
function lachinata_chip( string $text, array $args = array() ): string {
	$selected = ! empty( $args['selected'] );
	$tint     = $args['tint'] ?? '';
	$href     = $args['href'] ?? null;
	$attrs    = array_merge(
		array(
			'href'         => $href,
			'type'         => $href ? null : 'button',
			'class'        => lachinata_cx( 'lc-chip', 'label', $selected ? 'lc-chip--on' : '', $tint ? 'lc-chip--tint' : '', $args['class'] ?? '' ),
			'aria-pressed' => $href ? null : ( $selected ? 'true' : 'false' ),
			'aria-current' => $href && $selected ? 'page' : null,
			'style'        => $tint && ! $selected ? 'background: var(--tint-' . $tint . ')' : null,
		),
		$args['attrs'] ?? array()
	);
	return sprintf(
		'<%1$s%2$s>%3$s%4$s</%1$s>',
		$href ? 'a' : 'button',
		lachinata_attrs( $attrs ),
		esc_html( $text ),
		empty( $args['icon'] ) ? '' : lachinata_icon( $args['icon'], array( 'size' => 'sm' ) )
	);
}

/**
 * Star rating.
 *
 * @param float $value      Average (0–5).
 * @param int   $count      Number of reviews.
 * @param bool  $large      Large variant (product page).
 * @param bool  $show_value Show «4.8 (202)» instead of «(202)».
 */
function lachinata_rating( float $value, int $count = 0, bool $large = false, bool $show_value = false ): string {
	$stars = '';
	for ( $i = 1; $i <= 5; $i++ ) {
		$stars .= lachinata_icon( 'star', array( 'filled' => $i <= round( $value ) ) );
	}
	$average = number_format_i18n( $value, 1 );
	$label   = $count
		/* translators: 1: average rating, 2: number of reviews. */
		? sprintf( _n( '%1$s de 5, %2$s valoración', '%1$s de 5, %2$s valoraciones', $count, 'lachinata' ), $average, number_format_i18n( $count ) )
		/* translators: %s: average rating. */
		: sprintf( __( '%s de 5', 'lachinata' ), $average );
	$counter = $count ? sprintf( '<span class="lc-rating__count">%s</span>', esc_html( $show_value ? sprintf( '%1$s (%2$s)', $average, number_format_i18n( $count ) ) : sprintf( '(%s)', number_format_i18n( $count ) ) ) ) : '';

	return sprintf(
		'<span class="%1$s" role="img" aria-label="%2$s"><span class="lc-rating__stars" aria-hidden="true">%3$s</span>%4$s</span>',
		esc_attr( lachinata_cx( 'lc-rating', 'body-sm', $large ? 'lc-rating--lg' : '' ) ),
		esc_attr( $label ),
		$stars,
		$counter
	);
}

/**
 * Price block: current price, old price, tax note and unit price.
 *
 * @param array<string, mixed> $args now (HTML), old (HTML), note (text, false hides), unit (HTML), large, class.
 */
function lachinata_price( array $args ): string {
	$note = $args['note'] ?? false;
	$html = sprintf( '<span class="%s" data-no-translation>%s</span>', esc_attr( lachinata_cx( 'lc-price__now', ! empty( $args['large'] ) ? 'price-lg' : 'price' ) ), wp_kses_post( $args['now'] ?? '' ) );
	if ( ! empty( $args['old'] ) ) {
		$html .= sprintf( '<span class="lc-price__old body-sm" data-no-translation><span class="screen-reader-text">%s </span>%s</span>', esc_html__( 'Antes:', 'lachinata' ), wp_kses_post( $args['old'] ) );
	}
	if ( false !== $note && '' !== $note ) {
		$html .= sprintf( '<span class="lc-price__note caption">%s</span>', wp_kses_post( $note ) );
	}
	if ( ! empty( $args['unit'] ) ) {
		$html .= sprintf( '<span class="lc-price__unit body-sm" data-lc-unit-price>%s</span>', wp_kses_post( $args['unit'] ) );
	}
	return sprintf( '<div class="%s">%s</div>', esc_attr( lachinata_cx( 'lc-price', ! empty( $args['old'] ) ? 'lc-price--sale' : '', $args['class'] ?? '' ) ), $html );
}

/**
 * Quantity stepper. Uses a real number input so forms work without JavaScript.
 *
 * @param array<string, mixed> $args name, value, min, max, label, class, id.
 */
function lachinata_stepper( array $args = array() ): string {
	$value = (int) ( $args['value'] ?? 1 );
	$min   = (int) ( $args['min'] ?? 1 );
	$max   = (int) ( $args['max'] ?? 99 );
	return sprintf(
		'<div class="%1$s" role="group" aria-label="%2$s" data-lc-stepper><button type="button" aria-label="%3$s" data-lc-step="-1"%4$s>%5$s</button><input class="label" type="number" inputmode="numeric" name="%6$s"%7$s value="%8$d" min="%9$d" max="%10$d" step="1" aria-label="%2$s"><button type="button" aria-label="%11$s" data-lc-step="1"%12$s>%13$s</button></div>',
		esc_attr( lachinata_cx( 'lc-stepper', $args['class'] ?? '' ) ),
		esc_attr( $args['label'] ?? __( 'Cantidad', 'lachinata' ) ),
		esc_attr__( 'Menos', 'lachinata' ),
		$value <= $min ? ' disabled' : '',
		lachinata_icon( 'minus', array( 'size' => 'sm' ) ),
		esc_attr( $args['name'] ?? 'quantity' ),
		isset( $args['id'] ) ? ' id="' . esc_attr( $args['id'] ) . '"' : '',
		$value,
		$min,
		$max,
		esc_attr__( 'Más', 'lachinata' ),
		$value >= $max ? ' disabled' : '',
		lachinata_icon( 'plus', array( 'size' => 'sm' ) )
	);
}

/**
 * Notice.
 *
 * @param string $html Message (sentence; may contain a link).
 * @param string $tone neutral, success, info, warning or error.
 * @param string $extra_class Extra class.
 */
function lachinata_notice( string $html, string $tone = 'neutral', string $extra_class = '' ): string {
	$icons = array(
		'success' => 'check',
		'info'    => 'info',
		'warning' => 'alert',
		'error'   => 'alert',
		'neutral' => 'info',
	);
	return sprintf(
		'<div class="%1$s" role="%2$s">%3$s<span>%4$s</span></div>',
		esc_attr( lachinata_cx( 'lc-notice', 'body-sm', 'lc-notice--' . $tone, $extra_class ) ),
		'error' === $tone ? 'alert' : 'status',
		lachinata_icon( $icons[ $tone ] ?? 'info', array( 'size' => 'sm' ) ),
		wp_kses_post( $html )
	);
}

/**
 * Prints a template part with arguments (wrapper for readability in templates).
 *
 * @param string               $slug Part under template-parts/.
 * @param array<string, mixed> $args Arguments.
 */
function lachinata_part( string $slug, array $args = array() ): void {
	get_template_part( 'template-parts/' . $slug, null, $args );
}

/**
 * One value of the company data of the plugin («Datos de la empresa», filter
 * `lachinata/company`), or an empty string without the plugin.
 *
 * @param string $key Key: trade_name, legal_name, tax_id.
 */
function lachinata_company_value( string $key ): string {
	/**
	 * Company data of the shop (the plugin's «Datos de la empresa»): trade name, legal name,
	 * tax id, address, privacy email and legal pages. Empty without the plugin.
	 *
	 * @since 0.10.0
	 *
	 * @param array<string, string> $company Empty.
	 */
	$company = (array) apply_filters( 'lachinata/company', array() );
	return trim( (string) ( $company[ $key ] ?? '' ) );
}

/**
 * The shop's name for people («La Chinata»): the trade name of the company data, else the
 * site name. Never the slug or the domain.
 */
function lachinata_shop_name(): string {
	$name = lachinata_company_value( 'trade_name' );
	return '' !== $name ? $name : trim( wp_specialchars_decode( html_entity_decode( (string) get_bloginfo( 'name' ), ENT_QUOTES, 'UTF-8' ), ENT_QUOTES ) );
}
