<?php
/**
 * Order received page (Gracias.dc.html): data for woocommerce/checkout/thankyou.php.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Order received view (the checkout's endpoint, rendered with the classic template).
 */
function lachinata_is_order_received(): bool {
	return function_exists( 'is_order_received_page' ) && is_order_received_page();
}

/**
 * «Mientras llega»: cross-sells of what was bought and, without any, the best sellers of the
 * category of the first product (its top-level category when the subcategory has fewer than
 * two). Never what is in the order.
 *
 * @param WC_Order $order Order.
 * @param int      $limit Products.
 * @return WC_Product[]
 */
function lachinata_thankyou_products( WC_Order $order, int $limit = 4 ): array {
	$bought = array();
	$cross  = array();
	foreach ( $order->get_items() as $item ) {
		$product = $item instanceof WC_Order_Item_Product ? $item->get_product() : null;
		if ( ! $product instanceof WC_Product ) {
			continue;
		}
		$parent   = $product->get_parent_id() ? wc_get_product( $product->get_parent_id() ) : $product;
		$bought[] = $parent instanceof WC_Product ? $parent->get_id() : $product->get_id();
		$cross    = array_merge( $cross, $parent instanceof WC_Product ? $parent->get_cross_sell_ids() : array() );
	}
	$ids = array_values( array_diff( array_unique( array_map( 'intval', $cross ) ), $bought ) );

	if ( ! $ids && $bought ) {
		$terms = get_the_terms( $bought[0], 'product_cat' );
		if ( is_array( $terms ) && $terms ) {
			usort( $terms, static fn( WP_Term $a, WP_Term $b ): int => count( get_ancestors( $b->term_id, 'product_cat', 'taxonomy' ) ) <=> count( get_ancestors( $a->term_id, 'product_cat', 'taxonomy' ) ) );
			// The deepest category first; if it has too few, its top-level category.
			$ancestors = get_ancestors( $terms[0]->term_id, 'product_cat', 'taxonomy' );
			$root      = $ancestors ? get_term( (int) end( $ancestors ), 'product_cat' ) : null;
			foreach ( array_filter( array( $terms[0], $root ) ) as $term ) {
				$ids = wc_get_products(
					array(
						'status'   => 'publish',
						'limit'    => $limit,
						'category' => array( $term->slug ),
						'exclude'  => $bought,
						'orderby'  => 'popularity',
						'return'   => 'ids',
					)
				);
				if ( count( $ids ) >= 2 ) {
					break;
				}
			}
		}
	}

	/**
	 * Product ids of «Mientras llega» on the order received page.
	 *
	 * @since 0.5.0
	 *
	 * @param int[]    $ids   Cross-sells of the order, or best sellers of its first category.
	 * @param WC_Order $order Order.
	 */
	$ids      = (array) apply_filters( 'lachinata/thankyou/product_ids', array_map( 'intval', (array) $ids ), $order );
	$products = array_filter( array_map( 'wc_get_product', array_slice( $ids, 0, $limit ) ) );
	return array_values( array_filter( $products, static fn( $p ): bool => $p instanceof WC_Product && $p->is_visible() ) );
}

/**
 * Delivery block: the headline (the delivery date when a module knows it, the shipping
 * method otherwise) and the method with a short address.
 *
 * @param WC_Order $order Order.
 * @return array{title: string, text: string}|null Null for orders without shipping.
 */
function lachinata_thankyou_delivery( WC_Order $order ): ?array {
	if ( ! $order->get_items( 'shipping' ) ) {
		return null;
	}
	$method = (string) $order->get_shipping_method();
	/**
	 * Headline of the delivery block of the order received page.
	 *
	 * @since 0.5.0
	 *
	 * @param string   $title Shipping method name.
	 * @param WC_Order $order Order.
	 */
	$title = (string) apply_filters( 'lachinata/thankyou/delivery', $method, $order );
	$where = trim( implode( ', ', array_filter( array( $order->get_shipping_address_1(), trim( $order->get_shipping_postcode() . ' ' . $order->get_shipping_city() ) ) ) ) );
	return array(
		'title' => $title,
		'text'  => $title === $method ? $where : implode( ' · ', array_filter( array( $method, $where ) ) ),
	);
}

/**
 * Where «Seguir el pedido» goes until there is tracking: the order in the account, or the
 * order received page with its key for guests.
 *
 * @param WC_Order $order Order.
 */
function lachinata_thankyou_track_url( WC_Order $order ): string {
	return $order->get_customer_id() ? $order->get_view_order_url() : $order->get_checkout_order_received_url();
}

/**
 * Tracking of a shipped order: the carrier's page, the carrier and the number.
 *
 * @param WC_Order $order Order.
 * @return array{url: string, carrier: string, number: string}|null Null until the parcel has tracking.
 */
function lachinata_order_tracking( WC_Order $order ): ?array {
	/**
	 * Tracking of an order («Seguir el paquete» on the order received page and in the account).
	 *
	 * @since 0.8.0
	 *
	 * @param array{url: string, carrier: string, number: string}|null $tracking Null by default.
	 * @param WC_Order                                                 $order    Order.
	 */
	$tracking = apply_filters( 'lachinata/order/tracking', null, $order );
	if ( ! is_array( $tracking ) || '' === (string) ( $tracking['url'] ?? '' ) ) {
		return null;
	}
	return array(
		'url'     => (string) $tracking['url'],
		'carrier' => (string) ( $tracking['carrier'] ?? '' ),
		'number'  => (string) ( $tracking['number'] ?? '' ),
	);
}

/**
 * Status of an order as the buyer reads it, with the tone of its Badge (02-plantillas.md,
 * «Cuenta»: success Entregado, info En camino, soldout Cancelado).
 *
 * @param WC_Order $order Order.
 * @return array{label: string, tone: string}
 */
function lachinata_order_status( WC_Order $order ): array {
	$tones  = array(
		'completed'  => 'success',
		'processing' => 'info',
		'on-hold'    => 'new',
		'cancelled'  => 'soldout',
		'refunded'   => 'soldout',
		'failed'     => 'promo',
	);
	$status = array(
		'label' => wc_get_order_status_name( $order->get_status() ),
		'tone'  => $tones[ $order->get_status() ] ?? '',
	);
	/**
	 * Status of an order in the account (shipment: «En camino» once it has left).
	 *
	 * @since 0.8.0
	 *
	 * @param array{label: string, tone: string} $status WooCommerce's status name and its tone.
	 * @param WC_Order                           $order  Order.
	 */
	$status = (array) apply_filters( 'lachinata/order/status', $status, $order );
	return array(
		'label' => (string) ( $status['label'] ?? '' ),
		'tone'  => (string) ( $status['tone'] ?? '' ),
	);
}
