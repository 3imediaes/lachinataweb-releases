<?php
/**
 * Blog / magazine listing and fallback template.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<div class="lc-container lc-page">
	<h1 class="editorial-h1 lc-page-title">
		<?php
		if ( is_home() ) {
			$lachinata_blog = get_the_title( (int) get_option( 'page_for_posts' ) );
			echo esc_html( '' !== $lachinata_blog ? $lachinata_blog : __( 'Blog', 'lachinata' ) );
		} elseif ( is_search() ) {
			/* translators: %s: search terms. */
			echo esc_html( sprintf( __( 'Resultados para «%s»', 'lachinata' ), get_search_query() ) );
		} else {
			echo esc_html( wp_strip_all_tags( get_the_archive_title() ) );
		}
		?>
	</h1>
	<?php if ( have_posts() ) : ?>
		<div class="lc-posts">
			<?php
			while ( have_posts() ) :
				the_post();
				?>
				<article <?php post_class( 'lc-post' ); ?>>
					<?php if ( has_post_thumbnail() ) : ?>
						<a href="<?php the_permalink(); ?>" class="lc-post__media" tabindex="-1" aria-hidden="true"><?php the_post_thumbnail( 'lachinata-tile', array( 'alt' => '' ) ); ?></a>
					<?php endif; ?>
					<span class="eyebrow"><?php echo esc_html( get_the_date() ); ?></span>
					<h2 class="editorial-h2"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
					<p class="body-sm"><?php echo esc_html( get_the_excerpt() ); ?></p>
				</article>
			<?php endwhile; ?>
		</div>
		<?php
		the_posts_pagination(
			array(
				'prev_text' => __( 'Anteriores', 'lachinata' ),
				'next_text' => __( 'Siguientes', 'lachinata' ),
			)
		);
		?>
	<?php else : ?>
		<?php echo lachinata_notice( esc_html__( 'No hay contenido que mostrar.', 'lachinata' ) ); ?>
	<?php endif; ?>
</div>
<?php
get_footer();
