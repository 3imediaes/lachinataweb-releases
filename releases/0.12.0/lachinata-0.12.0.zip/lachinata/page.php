<?php
/**
 * Page.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

get_header();
while ( have_posts() ) :
	the_post();
	$lachinata_wc_page = function_exists( 'is_account_page' ) && ( is_account_page() || is_checkout() );
	?>
	<?php if ( ! $lachinata_wc_page ) : ?>
		<?php lachinata_part( 'breadcrumb', array( 'class' => 'lc-container' ) ); ?>
	<?php endif; ?>
	<article <?php post_class( lachinata_cx( 'lc-container', 'lc-page', $lachinata_wc_page ? 'lc-page--wc' : '', lachinata_is_block_checkout() ? 'lc-page--checkout' : '', lachinata_is_order_received() ? 'lc-page--thanks' : '' ) ); ?>>
		<?php if ( ! is_checkout() ) : ?>
			<?php the_title( '<h1 class="h1 lc-page-title">', '</h1>' ); ?>
		<?php endif; ?>
		<div class="lc-blocks lc-page__content body"><?php the_content(); ?></div>
	</article>
	<?php
endwhile;
get_footer();
