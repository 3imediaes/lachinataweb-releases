<?php
/**
 * Title: Marca · cita
 * Slug: lachinata/editorial-quote
 * Categories: lachinata
 * Description: Cita en Recoleta con comillas latinas, en verde oliva.
 * Keywords: cita, testimonio
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:quote {"className":"lc-quote-block"} -->
<blockquote class="wp-block-quote lc-quote-block"><!-- wp:paragraph {"className":"editorial-quote"} -->
<p class="editorial-quote"><?php echo esc_html__( '«El aceite se hace en el campo, no en la almazara.»', 'lachinata' ); ?></p>
<!-- /wp:paragraph --><cite class="caption"><?php echo esc_html__( 'Nombre y cargo', 'lachinata' ); ?></cite></blockquote>
<!-- /wp:quote -->
