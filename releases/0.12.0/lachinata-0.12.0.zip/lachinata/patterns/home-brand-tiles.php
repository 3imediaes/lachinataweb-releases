<?php
/**
 * Title: Home · oleotecas y regalos de empresa
 * Slug: lachinata/home-brand-tiles
 * Categories: lachinata
 * Description: Dos tiles de marca: oleotecas (crema) y regalos de empresa (tinta regalos).
 * Keywords: oleotecas, tiendas, empresa
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"className":"lc-brand-tiles","layout":{"type":"default"}} -->
<div class="wp-block-group lc-brand-tiles">
<!-- wp:group {"className":"lc-tile lc-tile--cream","layout":{"type":"default"}} -->
<div class="wp-block-group lc-tile lc-tile--cream">
<!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow"><?php echo esc_html__( 'Tiendas', 'lachinata' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"h3"} -->
<p class="h3"><?php echo esc_html__( 'Oleotecas', 'lachinata' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"label lc-tile__cta"} -->
<p class="label lc-tile__cta"><a href="#"><?php echo esc_html__( 'Ver el mapa', 'lachinata' ); ?></a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"lc-tile lc-tile--regalos","layout":{"type":"default"}} -->
<div class="wp-block-group lc-tile lc-tile--regalos">
<!-- wp:paragraph {"className":"eyebrow"} -->
<p class="eyebrow"><?php echo esc_html__( 'Empresas', 'lachinata' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"h3"} -->
<p class="h3"><?php echo esc_html__( 'Regalos de empresa', 'lachinata' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"label lc-tile__cta"} -->
<p class="label lc-tile__cta"><a href="#"><?php echo esc_html__( 'Pide propuesta', 'lachinata' ); ?></a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
