<?php
/**
 * Title: Home · banner de campaña
 * Slug: lachinata/home-campaign
 * Categories: lachinata
 * Description: Cifra en SantElia Script, una o dos palabras con emoción y la explicación en DIN, sobre el amarillo de marca.
 * Keywords: campaña, oferta, promoción, desperdicio cero
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"className":"lc-campaign","layout":{"type":"default"}} -->
<div class="wp-block-group lc-campaign">
<!-- wp:paragraph {"className":"campaign"} -->
<p class="campaign">-30%</p>
<!-- /wp:paragraph -->
<!-- wp:group {"className":"lc-campaign__text","layout":{"type":"default"}} -->
<div class="wp-block-group lc-campaign__text">
<!-- wp:paragraph {"className":"campaign-word"} -->
<p class="campaign-word"><?php echo esc_html__( 'Desperdicio cero', 'lachinata' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"body-sm"} -->
<p class="body-sm"><?php echo esc_html__( 'Productos con descuento por fecha próxima. Mismo sabor, menos desperdicio.', 'lachinata' ); ?> <a href="#"><?php echo esc_html__( 'Ver ofertas', 'lachinata' ); ?></a></p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
