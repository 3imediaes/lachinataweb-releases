<?php
/**
 * Title: Home · hero editorial
 * Slug: lachinata/home-hero
 * Categories: lachinata
 * Description: Eyebrow, titular Recoleta, entradilla y botón sobre una tinta; añade una imagen dentro del grupo y va a la derecha en escritorio.
 * Keywords: hero, portada, home
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"className":"lc-hero-block lc-tile--cosmetica","layout":{"type":"default"}} -->
<div class="wp-block-group lc-hero-block lc-tile--cosmetica">
<!-- wp:group {"className":"lc-hero-block__text","layout":{"type":"default"}} -->
<div class="wp-block-group lc-hero-block__text">
<!-- wp:paragraph {"className":"eyebrow lc-hero-block__eyebrow"} -->
<p class="eyebrow lc-hero-block__eyebrow"><?php echo esc_html__( 'Nueva generación', 'lachinata' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":1,"className":"editorial-display"} -->
<h1 class="wp-block-heading editorial-display"><?php echo esc_html__( 'Olivita, cosmética saludable', 'lachinata' ); ?></h1>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"editorial-lead"} -->
<p class="editorial-lead"><?php echo esc_html__( 'Belleza natural con aceite de oliva virgen extra.', 'lachinata' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"lc-wp-btn"} -->
<div class="wp-block-button lc-wp-btn"><a class="wp-block-button__link wp-element-button" href="#"><?php echo esc_html__( 'Descubre la línea', 'lachinata' ); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
