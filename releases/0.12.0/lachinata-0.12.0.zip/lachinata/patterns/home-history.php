<?php
/**
 * Title: Home · historia
 * Slug: lachinata/home-history
 * Categories: lachinata
 * Description: Bloque de marca sobre crema: eyebrow, titular Recoleta, entradilla y botón secundario.
 * Keywords: historia, marca, 1932
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;
?>
<!-- wp:group {"className":"lc-history","layout":{"type":"default"}} -->
<div class="wp-block-group lc-history">
<!-- wp:paragraph {"className":"eyebrow lc-history__eyebrow"} -->
<p class="eyebrow lc-history__eyebrow"><?php echo esc_html__( 'Desde 1932', 'lachinata' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:heading {"className":"editorial-h2"} -->
<h2 class="wp-block-heading editorial-h2"><?php echo esc_html__( 'Maestros oleícolas desde hace tres generaciones', 'lachinata' ); ?></h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"editorial-lead"} -->
<p class="editorial-lead"><?php echo esc_html__( 'Llevamos produciendo aceite de oliva virgen extra desde 1932. Hoy es el ingrediente de todo lo que hacemos.', 'lachinata' ); ?></p>
<!-- /wp:paragraph -->
<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"lc-wp-btn is-style-outline"} -->
<div class="wp-block-button lc-wp-btn is-style-outline"><a class="wp-block-button__link wp-element-button" href="#"><?php echo esc_html__( 'Descubre nuestra historia', 'lachinata' ); ?></a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
