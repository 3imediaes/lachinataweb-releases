<?php
/**
 * Blog post / magazine article (editorial template).
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

get_header();
while ( have_posts() ) :
	the_post();
	?>
	<article <?php post_class( 'lc-editorial' ); ?>>
		<header class="lc-editorial__head">
			<div class="lc-container">
				<?php lachinata_part( 'breadcrumb' ); ?>
				<span class="eyebrow lc-editorial__eyebrow"><time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time></span>
				<?php the_title( '<h1 class="editorial-h1 lc-editorial__title">', '</h1>' ); ?>
				<?php if ( has_excerpt() ) : ?>
					<p class="editorial-lead lc-editorial__lead"><?php echo esc_html( get_the_excerpt() ); ?></p>
				<?php endif; ?>
			</div>
		</header>
		<?php if ( has_post_thumbnail() ) : ?>
			<figure class="lc-container lc-editorial__media">
			<?php
			the_post_thumbnail(
				'lachinata-hero',
				array(
					'loading'       => 'eager',
					'fetchpriority' => 'high',
				)
			);
			?>
																</figure>
		<?php endif; ?>
		<div class="lc-container lc-blocks lc-editorial__content body"><?php the_content(); ?></div>
	</article>
	<?php
endwhile;
get_footer();
