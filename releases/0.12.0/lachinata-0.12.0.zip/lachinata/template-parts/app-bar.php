<?php
/**
 * AppBar: mobile (menu or back · logo · search · bag) and desktop (categories · logo ·
 * brand links · search · account · bag). Both are printed; CSS shows one per width.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_checkout    = lachinata_is_checkout_view();
$lachinata_secondary   = lachinata_is_secondary_view();
$lachinata_count       = function_exists( 'WC' ) && WC()->cart ? WC()->cart->get_cart_contents_count() : 0;
$lachinata_cart_url    = function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : '';
$lachinata_account     = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : '';
$lachinata_current     = lachinata_current_category();
$lachinata_root        = $lachinata_current ? lachinata_root_category( $lachinata_current ) : null;
$lachinata_back_url    = lachinata_back_url( $lachinata_current ? lachinata_term_url( $lachinata_current ) : home_url( '/' ) );
$lachinata_bag_args    = array(
	'count' => $lachinata_count,
	'href'  => $lachinata_cart_url,
	'attrs' => array( 'data-lc-open' => 'cart' ),
);
$lachinata_search_args = array(
	'href'  => add_query_arg(
		array(
			's'         => '',
			'post_type' => 'product',
		),
		home_url( '/' )
	),
	'attrs' => array( 'data-lc-open' => 'search' ),
);
?>
<header class="lc-appbar lc-appbar--mobile">
	<?php
	if ( lachinata_is_block_checkout() ) {
		echo lachinata_icon_button( 'chevron-left', __( 'Volver a la bolsa', 'lachinata' ), array( 'href' => $lachinata_cart_url ) );
	} elseif ( $lachinata_checkout ) {
		echo '<span></span>';
	} elseif ( $lachinata_secondary ) {
		echo lachinata_icon_button(
			'chevron-left',
			__( 'Volver', 'lachinata' ),
			array(
				'href'  => $lachinata_back_url,
				'attrs' => array( 'data-lc-back' => '' ),
			)
		);
	} else {
		echo lachinata_icon_button(
			'menu',
			__( 'Menú', 'lachinata' ),
			array(
				'attrs' => array(
					'data-lc-open'  => 'menu',
					'aria-haspopup' => 'dialog',
					'aria-controls' => 'lc-menu',
				),
			)
		);
	}
	?>
	<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="lc-appbar__logo" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: shop name. */ __( '%s, inicio', 'lachinata' ), lachinata_shop_name() ) ); ?>"><?php echo lachinata_logo( 18 ); ?></a>
	<div class="lc-appbar__actions">
		<?php
		if ( ! $lachinata_checkout ) {
			echo lachinata_icon_button( 'search', __( 'Buscar', 'lachinata' ), $lachinata_search_args );
			echo lachinata_icon_button( 'bag', __( 'Bolsa', 'lachinata' ), $lachinata_bag_args );
		}
		?>
	</div>
</header>
<header class="lc-appbar lc-appbar--desktop">
	<?php if ( ! $lachinata_checkout ) : ?>
		<nav class="lc-appbar__nav nav" aria-label="<?php esc_attr_e( 'Tienda', 'lachinata' ); ?>">
			<?php foreach ( lachinata_category_tree() as $lachinata_cat ) : ?>
				<div class="lc-megamenu">
					<a href="<?php echo esc_url( lachinata_term_url( $lachinata_cat['term'] ) ); ?>"<?php echo $lachinata_root && $lachinata_root->term_id === $lachinata_cat['term']->term_id ? ' aria-current="page"' : ''; ?>><?php echo esc_html( mb_strtoupper( $lachinata_cat['term']->name ) ); ?></a>
					<?php if ( $lachinata_cat['children'] ) : ?>
						<div class="lc-megamenu__panel">
							<ul class="lc-megamenu__list body">
								<li><a class="lc-megamenu__all label" href="<?php echo esc_url( lachinata_term_url( $lachinata_cat['term'] ) ); ?>">
									<?php
									/* translators: %s: category name. */
									echo esc_html( sprintf( __( 'Ver todo %s', 'lachinata' ), $lachinata_cat['term']->name ) );
									?>
								</a></li>
								<?php foreach ( $lachinata_cat['children'] as $lachinata_child ) : ?>
									<li><a href="<?php echo esc_url( lachinata_term_url( $lachinata_child ) ); ?>"><?php echo esc_html( $lachinata_child->name ); ?></a></li>
								<?php endforeach; ?>
							</ul>
							<?php
							$lachinata_thumb = (int) get_term_meta( $lachinata_cat['term']->term_id, 'thumbnail_id', true );
							if ( $lachinata_thumb ) {
								printf(
									'<span class="lc-megamenu__media%s">%s</span>',
									$lachinata_cat['tint'] ? ' lc-tile--' . esc_attr( $lachinata_cat['tint'] ) : '',
									wp_get_attachment_image(
										$lachinata_thumb,
										'woocommerce_thumbnail',
										false,
										array(
											'alt'     => '',
											'loading' => 'lazy',
										)
									)
								);
							}
							?>
						</div>
					<?php endif; ?>
				</div>
			<?php endforeach; ?>
		</nav>
	<?php elseif ( lachinata_is_block_checkout() ) : ?>
		<a class="lc-appbar__back body-sm" href="<?php echo esc_url( $lachinata_cart_url ); ?>"><?php echo lachinata_icon( 'chevron-left', array( 'size' => 'sm' ) ); ?><?php esc_html_e( 'Volver a la bolsa', 'lachinata' ); ?></a>
	<?php else : ?>
		<span></span>
	<?php endif; ?>
	<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="lc-appbar__logo" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: shop name. */ __( '%s, inicio', 'lachinata' ), lachinata_shop_name() ) ); ?>"><?php echo lachinata_logo( 26 ); ?></a>
	<div class="lc-appbar__actions lc-appbar__actions--end">
		<?php if ( lachinata_is_block_checkout() ) : ?>
			<span class="lc-appbar__secure caption"><?php echo lachinata_icon( 'check', array( 'size' => 'sm' ) ); ?><?php esc_html_e( 'Pago cifrado', 'lachinata' ); ?></span>
		<?php endif; ?>
		<?php if ( ! $lachinata_checkout ) : ?>
			<?php
			/**
			 * Utilities of the desktop AppBar, before the brand links (the locale module adds
			 * MarketBadge, next to Oleotecas and Blog).
			 *
			 * @since 0.11.0
			 */
			do_action( 'lachinata/app_bar/utilities' );
			?>
			<?php $lachinata_brand = lachinata_menu( 'brand' ); ?>
			<?php if ( $lachinata_brand ) : ?>
				<nav class="lc-appbar__nav nav" aria-label="<?php esc_attr_e( 'Marca', 'lachinata' ); ?>">
					<?php foreach ( $lachinata_brand as $lachinata_item ) : ?>
						<a href="<?php echo esc_url( $lachinata_item['url'] ); ?>"<?php echo $lachinata_item['current'] ? ' aria-current="page"' : ''; ?>><?php echo esc_html( mb_strtoupper( $lachinata_item['title'] ) ); ?></a>
					<?php endforeach; ?>
				</nav>
			<?php endif; ?>
			<?php
			echo lachinata_icon_button( 'search', __( 'Buscar', 'lachinata' ), $lachinata_search_args );
			echo lachinata_icon_button( 'user', __( 'Mi cuenta', 'lachinata' ), array( 'href' => $lachinata_account ) );
			echo lachinata_icon_button( 'bag', __( 'Bolsa', 'lachinata' ), $lachinata_bag_args );
			?>
		<?php endif; ?>
	</div>
</header>
