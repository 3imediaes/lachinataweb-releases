<?php
/**
 * BottomNav: Inicio, Tienda, Buscar, Bolsa, Cuenta (mobile only).
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_count = function_exists( 'WC' ) && WC()->cart ? WC()->cart->get_cart_contents_count() : 0;
$lachinata_items = array(
	array( 'home', __( 'Inicio', 'lachinata' ), home_url( '/' ), is_front_page(), array() ),
	array( 'grid', __( 'Tienda', 'lachinata' ), wc_get_page_permalink( 'shop' ), is_shop() || is_product_taxonomy(), array() ),
	array(
		'search',
		__( 'Buscar', 'lachinata' ),
		add_query_arg(
			array(
				's'         => '',
				'post_type' => 'product',
			),
			home_url( '/' )
		),
		is_search(),
		array( 'data-lc-open' => 'search' ),
	),
	array( 'bag', __( 'Bolsa', 'lachinata' ), wc_get_cart_url(), is_cart(), array( 'data-lc-open' => 'cart' ) ),
	array( 'user', __( 'Cuenta', 'lachinata' ), wc_get_page_permalink( 'myaccount' ), is_account_page(), array() ),
);
?>
<nav class="lc-bottomnav" aria-label="<?php esc_attr_e( 'Principal', 'lachinata' ); ?>">
	<?php foreach ( $lachinata_items as [ $lachinata_icon, $lachinata_label, $lachinata_url, $lachinata_current, $lachinata_attrs ] ) : ?>
		<a href="<?php echo esc_url( $lachinata_url ); ?>" class="caption"<?php echo lachinata_attrs( array_merge( $lachinata_attrs, array( 'aria-current' => $lachinata_current ? 'page' : null ) ) ); ?>>
			<?php echo lachinata_icon( $lachinata_icon ); ?>
			<?php echo esc_html( $lachinata_label ); ?>
			<?php if ( 'bag' === $lachinata_icon ) : ?>
				<span class="lc-btn__count" data-lc-cart-count<?php echo $lachinata_count ? '' : ' hidden'; ?>><span data-lc-count-value><?php echo esc_html( (string) $lachinata_count ); ?></span><span class="screen-reader-text"> <?php esc_html_e( 'artículos', 'lachinata' ); ?></span></span>
			<?php endif; ?>
		</a>
	<?php endforeach; ?>
</nav>
