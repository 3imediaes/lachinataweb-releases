<?php
/**
 * Breadcrumb («Estás en»). Hidden on mobile secondary views via CSS.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_items = lachinata_breadcrumb_items();
$lachinata_last  = count( $lachinata_items ) - 1;
?>
<nav class="<?php echo esc_attr( lachinata_cx( 'lc-crumbs', 'body-sm', $args['class'] ?? '' ) ); ?>" aria-label="<?php esc_attr_e( 'Estás en', 'lachinata' ); ?>">
	<?php foreach ( $lachinata_items as $lachinata_index => [ $lachinata_label, $lachinata_url ] ) : ?>
		<?php
		if ( $lachinata_index ) {
			echo lachinata_icon( 'chevron-right' );
		}
		?>
		<?php if ( $lachinata_index === $lachinata_last || '' === $lachinata_url ) : ?>
			<span<?php echo $lachinata_index === $lachinata_last ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $lachinata_label ); ?></span>
		<?php else : ?>
			<a href="<?php echo esc_url( $lachinata_url ); ?>"><?php echo esc_html( $lachinata_label ); ?></a>
		<?php endif; ?>
	<?php endforeach; ?>
</nav>
