<?php
/**
 * Bag as a BottomSheet (side panel on desktop). Its content is the same markup as the
 * /bolsa/ page, loaded on demand so cached pages never carry someone's bag.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="lc-layer lc-layer--sheet" data-lc-layer="cart" hidden>
	<div class="lc-layer__overlay" data-lc-close></div>
	<div class="lc-sheet" role="dialog" aria-modal="true" aria-labelledby="lc-cart-title" tabindex="-1">
		<div class="lc-sheet__grab" aria-hidden="true"></div>
		<div class="lc-sheet__head">
			<h2 class="h3" id="lc-cart-title" style="margin: 0"><?php esc_html_e( 'Tu bolsa', 'lachinata' ); ?></h2>
			<?php echo lachinata_icon_button( 'close', __( 'Cerrar', 'lachinata' ), array( 'attrs' => array( 'data-lc-close' => '' ) ) ); ?>
		</div>
		<div class="lc-sheet__content" data-lc-cart-body aria-busy="true">
			<p class="lc-sheet__loading body-sm"><?php esc_html_e( 'Cargando tu bolsa…', 'lachinata' ); ?></p>
		</div>
	</div>
</div>
