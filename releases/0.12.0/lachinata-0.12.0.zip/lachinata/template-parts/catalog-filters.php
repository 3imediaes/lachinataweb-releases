<?php
/**
 * Filter form (BottomSheet on mobile, side panel on desktop): attributes as chips and
 * a price range. A GET form WooCommerce understands; works without JavaScript.
 * Args: filters, context (sheet|panel).
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_context = $args['context'] ?? 'sheet';
$lachinata_keep    = array( 'paged', 'product-page', 'min_price', 'max_price' );
foreach ( $args['filters'] ?? array() as $lachinata_filter ) {
	$lachinata_keep[] = $lachinata_filter['param'];
}
// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only catalog filters.
$lachinata_min = isset( $_GET['min_price'] ) ? (string) wc_clean( wp_unslash( $_GET['min_price'] ) ) : '';
$lachinata_max = isset( $_GET['max_price'] ) ? (string) wc_clean( wp_unslash( $_GET['max_price'] ) ) : '';
// phpcs:enable
?>
<form method="get" action="<?php echo esc_url( remove_query_arg( $lachinata_keep ) ); ?>" class="<?php echo esc_attr( 'sheet' === $lachinata_context ? 'lc-filters lc-filters--sheet' : 'lc-filters lc-filters--panel' ); ?>">
	<div class="<?php echo 'sheet' === $lachinata_context ? 'lc-sheet__body' : 'lc-filters__body'; ?>">
		<?php foreach ( $args['filters'] ?? array() as $lachinata_filter ) : ?>
			<fieldset class="lc-sheet__group">
				<legend class="label"><?php echo esc_html( $lachinata_filter['label'] ); ?></legend>
				<div class="lc-chips">
					<?php foreach ( $lachinata_filter['terms'] as $lachinata_term ) : ?>
						<?php $lachinata_on = in_array( $lachinata_term->slug, $lachinata_filter['chosen'], true ); ?>
						<label class="<?php echo esc_attr( lachinata_cx( 'lc-chip', 'label', $lachinata_on ? 'lc-chip--on' : '' ) ); ?>">
							<input class="screen-reader-text" type="checkbox" name="<?php echo esc_attr( $lachinata_filter['param'] ); ?>[]" value="<?php echo esc_attr( $lachinata_term->slug ); ?>"<?php checked( $lachinata_on ); ?> data-lc-chip-input>
							<?php echo esc_html( $lachinata_term->name ); ?>
						</label>
					<?php endforeach; ?>
				</div>
			</fieldset>
		<?php endforeach; ?>
		<fieldset class="lc-sheet__group">
			<legend class="label"><?php esc_html_e( 'Precio', 'lachinata' ); ?></legend>
			<div class="lc-filters__price">
				<div class="lc-field">
					<label class="body-sm" for="lc-min-<?php echo esc_attr( $lachinata_context ); ?>"><?php /* translators: %s: currency symbol of the shop («€», «Kč»). */ echo esc_html( sprintf( __( 'Desde (%s)', 'lachinata' ), html_entity_decode( get_woocommerce_currency_symbol() ) ) ); ?></label>
					<div class="lc-field__box"><input id="lc-min-<?php echo esc_attr( $lachinata_context ); ?>" type="number" inputmode="decimal" min="0" step="1" name="min_price" value="<?php echo esc_attr( $lachinata_min ); ?>"></div>
				</div>
				<div class="lc-field">
					<label class="body-sm" for="lc-max-<?php echo esc_attr( $lachinata_context ); ?>"><?php /* translators: %s: currency symbol of the shop («€», «Kč»). */ echo esc_html( sprintf( __( 'Hasta (%s)', 'lachinata' ), html_entity_decode( get_woocommerce_currency_symbol() ) ) ); ?></label>
					<div class="lc-field__box"><input id="lc-max-<?php echo esc_attr( $lachinata_context ); ?>" type="number" inputmode="decimal" min="0" step="1" name="max_price" value="<?php echo esc_attr( $lachinata_max ); ?>"></div>
				</div>
			</div>
		</fieldset>
		<?php wc_query_string_form_fields( null, $lachinata_keep ); ?>
	</div>
	<div class="<?php echo 'sheet' === $lachinata_context ? 'lc-sheet__foot' : 'lc-filters__foot'; ?>">
		<?php
		echo lachinata_button(
			__( 'Borrar', 'lachinata' ),
			array(
				'variant' => 'secondary',
				'href'    => remove_query_arg( $lachinata_keep ),
			)
		);
		echo lachinata_button( __( 'Ver productos', 'lachinata' ), array( 'type' => 'submit' ) );
		?>
	</div>
</form>
