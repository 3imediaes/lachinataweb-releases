<?php
/**
 * CategoryTile. Args: title, href, tint, photo_id, eyebrow, text, cta, big, eager.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_photo = (int) ( $args['photo_id'] ?? 0 );
$lachinata_tint  = (string) ( $args['tint'] ?? '' );
?>
<a href="<?php echo esc_url( $args['href'] ?? '' ); ?>" class="<?php echo esc_attr( lachinata_cx( 'lc-tile', $lachinata_tint ? 'lc-tile--' . $lachinata_tint : '', $lachinata_photo ? 'lc-tile--photo' : '', $args['class'] ?? '' ) ); ?>">
	<?php if ( $lachinata_photo ) : ?>
		<?php
		echo wp_get_attachment_image(
			$lachinata_photo,
			'lachinata-tile',
			false,
			array(
				'class'   => 'lc-tile__photo',
				'alt'     => '',
				'loading' => empty( $args['eager'] ) ? 'lazy' : 'eager',
				'sizes'   => '(min-width: 1024px) 25vw, 100vw',
			)
		);
		?>
	<?php else : ?>
		<span class="lc-tile__halo" aria-hidden="true"></span>
	<?php endif; ?>
	<span class="lc-tile__text">
		<?php if ( ! empty( $args['eyebrow'] ) ) : ?>
			<span class="eyebrow"><?php echo esc_html( $args['eyebrow'] ); ?></span>
		<?php endif; ?>
		<span class="<?php echo empty( $args['big'] ) ? 'h3' : 'h2'; ?>"><?php echo esc_html( $args['title'] ?? '' ); ?></span>
		<?php if ( ! empty( $args['text'] ) ) : ?>
			<span class="body-sm"><?php echo esc_html( $args['text'] ); ?></span>
		<?php endif; ?>
	</span>
	<span class="lc-tile__cta label"><?php echo esc_html( $args['cta'] ?? __( 'Ver todo', 'lachinata' ) ); ?><?php echo lachinata_icon( 'arrow-right', array( 'size' => 'sm' ) ); ?></span>
</a>
