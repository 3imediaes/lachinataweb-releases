<?php
/**
 * OrderSummary of a placed order: lines with thumbnail and quantity, subtotal, discounts,
 * shipping («Gratis» when free), fees, VAT included, total and the payment note.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_order = $args['order'] ?? null;
if ( ! $lachinata_order instanceof WC_Order ) {
	return;
}
$lachinata_incl  = 'incl' === get_option( 'woocommerce_tax_display_cart' );
$lachinata_money = static fn( float $amount ): string => wc_price( $amount, array( 'currency' => $lachinata_order->get_currency() ) );
$lachinata_lines = array(
	array(
		'label' => __( 'Subtotal', 'lachinata' ),
		'value' => $lachinata_order->get_subtotal_to_display( false, $lachinata_incl ? 'incl' : 'excl' ),
	),
);
if ( (float) $lachinata_order->get_total_discount() > 0 ) {
	$lachinata_lines[] = array(
		'label' => __( 'Descuento', 'lachinata' ),
		'value' => '−' . $lachinata_money( (float) $lachinata_order->get_total_discount( ! $lachinata_incl ) ),
	);
}
if ( $lachinata_order->get_items( 'shipping' ) ) {
	$lachinata_ship    = (float) $lachinata_order->get_shipping_total() + ( $lachinata_incl ? (float) $lachinata_order->get_shipping_tax() : 0.0 );
	$lachinata_lines[] = array(
		'label' => (string) $lachinata_order->get_shipping_method(),
		'value' => $lachinata_ship > 0 ? $lachinata_money( $lachinata_ship ) : '',
		'free'  => $lachinata_ship <= 0,
	);
}
foreach ( $lachinata_order->get_fees() as $lachinata_fee ) {
	$lachinata_lines[] = array(
		'label' => $lachinata_fee->get_name(),
		'value' => $lachinata_money( (float) $lachinata_fee->get_total() + ( $lachinata_incl ? (float) $lachinata_fee->get_total_tax() : 0.0 ) ),
	);
}
if ( $lachinata_incl && (float) $lachinata_order->get_total_tax() > 0 ) {
	$lachinata_lines[] = array(
		'label' => __( 'IVA incluido', 'lachinata' ),
		'value' => $lachinata_money( (float) $lachinata_order->get_total_tax() ),
	);
}
$lachinata_payment = $lachinata_order->get_payment_method_title();
?>
<div class="lc-summary">
	<div class="lc-summary__items">
		<?php foreach ( $lachinata_order->get_items() as $lachinata_item ) : ?>
			<?php
			if ( ! $lachinata_item instanceof WC_Order_Item_Product ) {
				continue;
			}
			$lachinata_product = $lachinata_item->get_product();
			$lachinata_qty     = (int) $lachinata_item->get_quantity();
			$lachinata_meta    = wp_strip_all_tags(
				wc_display_item_meta(
					$lachinata_item,
					array(
						'echo'         => false,
						'separator'    => ' · ',
						'before'       => '',
						'after'        => '',
						'autop'        => false,
						'label_before' => '',
						'label_after'  => ': ',
					)
				)
			);
			$lachinata_line    = (float) $lachinata_item->get_total() + ( $lachinata_incl ? (float) $lachinata_item->get_total_tax() : 0.0 );
			?>
			<div class="lc-summary__item">
				<span class="lc-summary__thumb">
					<?php echo $lachinata_product instanceof WC_Product ? lachinata_product_image( (int) $lachinata_product->get_image_id(), 'woocommerce_gallery_thumbnail', '', false, '56px' ) : ''; ?>
					<span class="lc-summary__qty" aria-label="
					<?php
					/* translators: %d: quantity. */
					echo esc_attr( sprintf( _n( '%d unidad', '%d unidades', $lachinata_qty, 'lachinata' ), $lachinata_qty ) );
					?>
					"><?php echo esc_html( (string) $lachinata_qty ); ?></span>
				</span>
				<span class="lc-summary__name body-sm"><?php echo esc_html( $lachinata_item->get_name() ); ?>
					<?php if ( '' !== $lachinata_meta ) : ?>
						<span class="lc-summary__meta"><?php echo esc_html( $lachinata_meta ); ?></span>
					<?php endif; ?>
				</span>
				<span class="body-sm" data-no-translation><?php echo wp_kses_post( $lachinata_money( $lachinata_line ) ); ?></span>
			</div>
		<?php endforeach; ?>
	</div>
	<dl class="lc-summary__lines body-sm">
		<?php foreach ( $lachinata_lines as $lachinata_row ) : ?>
			<div class="lc-summary__line">
				<dt><?php echo esc_html( $lachinata_row['label'] ); ?></dt>
				<?php if ( ! empty( $lachinata_row['free'] ) ) : ?>
					<dd class="lc-summary__free"><?php esc_html_e( 'Gratis', 'lachinata' ); ?></dd>
				<?php else : ?>
					<dd data-no-translation><?php echo wp_kses_post( $lachinata_row['value'] ); ?></dd>
				<?php endif; ?>
			</div>
		<?php endforeach; ?>
	</dl>
	<div class="lc-summary__total">
		<span class="h4"><?php esc_html_e( 'Total', 'lachinata' ); ?></span>
		<span class="price-lg" data-no-translation><?php echo wp_kses_post( $lachinata_money( (float) $lachinata_order->get_total() ) ); ?></span>
	</div>
	<?php if ( '' !== $lachinata_payment ) : ?>
		<span class="lc-summary__note caption">
			<?php
			echo esc_html(
				null !== $lachinata_order->get_date_paid()
					/* translators: %s: payment method («Tarjeta», «PayPal»). */
					? sprintf( __( 'Pagado con %s', 'lachinata' ), $lachinata_payment )
					/* translators: %s: payment method («Tarjeta ···· 4242»). */
					: sprintf( __( 'Forma de pago: %s', 'lachinata' ), $lachinata_payment )
			);
			?>
		</span>
	<?php endif; ?>
</div>
