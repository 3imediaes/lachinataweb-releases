<?php
/**
 * Availability Notice of the product page. Args: product.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_product = $args['product'] ?? null;
if ( ! $lachinata_product instanceof WC_Product ) {
	return;
}

$lachinata_stock = $lachinata_product->get_stock_quantity();
$lachinata_low   = (int) wc_get_low_stock_amount( $lachinata_product );

if ( ! $lachinata_product->is_in_stock() ) {
	$lachinata_tone = 'neutral';
	$lachinata_text = __( 'Agotado por ahora.', 'lachinata' );
} elseif ( $lachinata_product->is_on_backorder() ) {
	$lachinata_tone = 'info';
	$lachinata_text = __( 'Disponible bajo pedido.', 'lachinata' );
} elseif ( $lachinata_product->managing_stock() && null !== $lachinata_stock && $lachinata_stock <= $lachinata_low ) {
	$lachinata_tone = 'warning';
	/* translators: %s: units left. */
	$lachinata_text = sprintf( _n( 'Queda %s unidad.', 'Quedan %s unidades.', (int) $lachinata_stock, 'lachinata' ), number_format_i18n( (int) $lachinata_stock ) );
} else {
	$lachinata_tone = 'success';
	$lachinata_text = __( 'Disponible', 'lachinata' );
}

/**
 * Availability line of the product page (the eta module adds «· envío en 24–48 h»).
 *
 * @since 0.2.0
 *
 * @param array{tone: string, text: string} $availability Tone and sentence.
 * @param WC_Product                        $product      Product.
 */
$lachinata_availability = (array) apply_filters(
	'lachinata/product/availability',
	array(
		'tone' => $lachinata_tone,
		'text' => $lachinata_text,
	),
	$lachinata_product
);

echo lachinata_notice( esc_html( (string) $lachinata_availability['text'] ), (string) $lachinata_availability['tone'], 'lc-buy__stock' );
