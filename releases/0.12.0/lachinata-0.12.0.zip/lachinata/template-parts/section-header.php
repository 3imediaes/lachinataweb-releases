<?php
/**
 * SectionHeader. Args: title, eyebrow, text, more, href, as (h1|h2|h3), level (class), id.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_tag   = in_array( $args['as'] ?? 'h2', array( 'h1', 'h2', 'h3' ), true ) ? ( $args['as'] ?? 'h2' ) : 'h2';
$lachinata_level = $args['level'] ?? $lachinata_tag;
?>
<div class="<?php echo esc_attr( lachinata_cx( 'lc-section', $args['class'] ?? '' ) ); ?>">
	<div class="lc-section__titles">
		<?php if ( ! empty( $args['eyebrow'] ) ) : ?>
			<span class="lc-section__eyebrow eyebrow"><?php echo esc_html( $args['eyebrow'] ); ?></span>
		<?php endif; ?>
		<<?php echo esc_html( $lachinata_tag ); ?> class="<?php echo esc_attr( $lachinata_level ); ?>" style="margin: 0"<?php echo empty( $args['id'] ) ? '' : ' id="' . esc_attr( $args['id'] ) . '"'; ?>><?php echo esc_html( $args['title'] ?? '' ); ?></<?php echo esc_html( $lachinata_tag ); ?>>
		<?php if ( ! empty( $args['text'] ) ) : ?>
			<p class="body-sm" style="margin: 0; color: var(--ink-soft)"><?php echo esc_html( $args['text'] ); ?></p>
		<?php endif; ?>
	</div>
	<?php if ( ! empty( $args['more'] ) && ! empty( $args['href'] ) ) : ?>
		<a href="<?php echo esc_url( $args['href'] ); ?>" class="lc-section__more label"><?php echo esc_html( $args['more'] ); ?><?php echo lachinata_icon( 'arrow-right', array( 'size' => 'sm' ) ); ?></a>
	<?php endif; ?>
</div>
