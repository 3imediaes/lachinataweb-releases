<?php
/**
 * StickyCta of the product page (mobile): price, Stepper and «Añadir a la bolsa».
 * Submits the buy form; the script shows it when the main button leaves the screen.
 * Args: product.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_product = $args['product'] ?? null;
if ( ! $lachinata_product instanceof WC_Product || ! $lachinata_product->is_purchasable() || ! $lachinata_product->is_in_stock() || ! $lachinata_product->is_type( array( 'simple', 'variable' ) ) ) {
	return;
}
$lachinata_unit = wp_strip_all_tags( lachinata_unit_price( $lachinata_product ) );
$lachinata_note = wp_strip_all_tags( lachinata_price_note() );
?>
<div class="lc-sticky" data-lc-sticky hidden>
	<div class="lc-sticky__price">
		<span class="price" data-no-translation data-lc-sticky-price><?php echo wp_kses_post( lachinata_display_price( $lachinata_product ) ); ?></span>
		<small class="caption"><?php echo esc_html( implode( ' · ', array_filter( array( strtok( $lachinata_unit, '|' ) ? trim( (string) strtok( $lachinata_unit, '|' ) ) : '', $lachinata_note ) ) ) ); ?></small>
	</div>
	<?php
	if ( ! $lachinata_product->is_sold_individually() ) {
		echo lachinata_stepper(
			array(
				'name'  => 'lc-sticky-qty',
				'value' => 1,
				'min'   => 1,
				'max'   => $lachinata_product->get_max_purchase_quantity() > 0 ? $lachinata_product->get_max_purchase_quantity() : 99,
				'class' => 'lc-sticky__stepper',
			)
		);
	}
	echo lachinata_button(
		__( 'Añadir a la bolsa', 'lachinata' ),
		array(
			'variant'   => 'cart',
			'size'      => 'lg',
			'icon_left' => 'bag',
			'type'      => 'submit',
			'attrs'     => array(
				'form'  => 'lc-buy',
				'name'  => 'add-to-cart',
				'value' => $lachinata_product->get_id(),
			),
		)
	);
	?>
</div>
