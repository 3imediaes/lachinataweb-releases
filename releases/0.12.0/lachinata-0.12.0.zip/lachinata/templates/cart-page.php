<?php
/**
 * The /bolsa/ page.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>
<div class="lc-container lc-cart-page">
	<h1 class="h1 lc-page-title"><?php esc_html_e( 'Tu bolsa', 'lachinata' ); ?></h1>
	<div data-lc-cart-root><?php lachinata_part( 'cart-body' ); ?></div>
</div>
<?php
get_footer();
