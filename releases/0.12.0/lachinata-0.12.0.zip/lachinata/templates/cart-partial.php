<?php
/**
 * Bag fragment for the BottomSheet (no header or footer).
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

nocache_headers();
lachinata_part( 'cart-body', array( 'context' => 'sheet' ) );
