<?php
/**
 * Template Name: Editorial (marca)
 * Template Post Type: page
 *
 * Brand pages (Acerca de, Oleotecas, Franquicias): Recoleta title on surface-cream,
 * lead and DIN body text at 65 characters per line.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

get_header();
while ( have_posts() ) :
	the_post();
	?>
	<article <?php post_class( 'lc-editorial' ); ?>>
		<header class="lc-editorial__head">
			<div class="lc-container">
				<?php lachinata_part( 'breadcrumb' ); ?>
				<?php the_title( '<h1 class="editorial-h1 lc-editorial__title">', '</h1>' ); ?>
				<?php if ( has_excerpt() ) : ?>
					<p class="editorial-lead lc-editorial__lead"><?php echo esc_html( get_the_excerpt() ); ?></p>
				<?php endif; ?>
			</div>
		</header>
		<div class="lc-container lc-blocks lc-editorial__content body"><?php the_content(); ?></div>
	</article>
	<?php
endwhile;
get_footer();
