<?php
/**
 * Product in a loop rendered by WooCommerce (shortcodes, related products): the ProductCard.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

global $product;
if ( ! $product instanceof WC_Product || ! $product->is_visible() ) {
	return;
}
lachinata_part( 'product-card', array( 'product' => $product ) );
