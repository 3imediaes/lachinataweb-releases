<?php
/**
 * Cuenta nueva (cliente). Texts and button in theme/inc/emails.php.
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package LaChinata\Theme
 * @version 10.9.0
 *
 * @var string   $email_heading Heading.
 * @var WC_Email $email         Email.
 */

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hooks.

/**
 * WooCommerce: email header.
 *
 * @since 2.5.0
 */
do_action( 'woocommerce_email_header', $email_heading, $email );
?>
<p class="lc-mail-caption">
	<?php
	echo esc_html(
		$email instanceof WC_Email_Customer_New_Account && '' !== (string) $email->set_password_url
			? __( 'El enlace para elegir tu contraseña caduca en 24 horas. Si no has creado tú esta cuenta, ignora este correo.', 'lachinata' )
			: __( 'Si no has creado tú esta cuenta, ignora este correo.', 'lachinata' )
	);
	?>
</p>
<?php

/**
 * WooCommerce: email footer.
 *
 * @since 2.5.0
 */
do_action( 'woocommerce_email_footer', $email );
