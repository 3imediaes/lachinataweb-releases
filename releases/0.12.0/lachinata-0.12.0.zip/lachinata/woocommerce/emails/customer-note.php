<?php
/**
 * Nota al cliente: la nota es la entradilla (comprador). Texts and button in theme/inc/emails.php.
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package LaChinata\Theme
 * @version 10.4.0
 *
 * @var string   $email_heading Heading.
 * @var WC_Email $email         Email.
 */

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hooks.

/**
 * WooCommerce: email header.
 *
 * @since 2.5.0
 */
do_action( 'woocommerce_email_header', $email_heading, $email );

/**
 * WooCommerce: email footer.
 *
 * @since 2.5.0
 */
do_action( 'woocommerce_email_footer', $email );
