<?php
/**
 * Reembolso total o parcial (comprador), con las líneas devueltas. Texts, facts and button in theme/inc/emails.php; the parts of the order it shows,
 * in lachinata_email_layout(). The «Contenido adicional» of WooCommerce is not printed:
 * nothing but the transactional message goes in (06-correos.md, «Sin marketing dentro»).
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package LaChinata\Theme
 * @version 10.4.0
 *
 * @var WC_Order $order         Order.
 * @var string   $email_heading Heading.
 * @var bool     $sent_to_admin Internal email.
 * @var bool     $plain_text    Plain text.
 * @var WC_Email $email         Email.
 */

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hooks.

/**
 * WooCommerce: email header.
 *
 * @since 2.5.0
 */
do_action( 'woocommerce_email_header', $email_heading, $email );

/**
 * WooCommerce: order lines and totals (email-order-details.php).
 *
 * @since 2.5.0
 */
do_action( 'woocommerce_email_order_details', $order, $sent_to_admin, $plain_text, $email );

/**
 * WooCommerce: order meta of extensions.
 *
 * @since 2.5.0
 */
do_action( 'woocommerce_email_order_meta', $order, $sent_to_admin, $plain_text, $email );

/**
 * WooCommerce: customer fields and addresses.
 *
 * @since 2.5.0
 */
do_action( 'woocommerce_email_customer_details', $order, $sent_to_admin, $plain_text, $email );

/**
 * WooCommerce: email footer.
 *
 * @since 2.5.0
 */
do_action( 'woocommerce_email_footer', $email );
