<?php
/**
 * Shipping and billing addresses of an email, in two columns that stack on mobile.
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package LaChinata\Theme
 * @version 10.6.0
 *
 * @var WC_Order $order Order.
 */

defined( 'ABSPATH' ) || exit;

if ( lachinata_email_layout( lachinata_email_current() )['addresses'] ) {
	echo lachinata_email_addresses( $order );
}
