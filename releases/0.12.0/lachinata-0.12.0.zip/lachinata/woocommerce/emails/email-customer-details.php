<?php
/**
 * Extra fields of the order that extensions add to the emails (label and value).
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package LaChinata\Theme
 * @version 9.7.0
 *
 * @var array<string, array{label: string, value: string}> $fields Fields.
 */

defined( 'ABSPATH' ) || exit;

if ( empty( $fields ) ) {
	return;
}
?>
<div class="lc-mail-fields">
	<?php foreach ( $fields as $lachinata_field ) : ?>
		<p><?php echo esc_html( wp_strip_all_tags( (string) $lachinata_field['label'] ) ); ?>: <span data-no-translation><?php echo wp_kses_post( (string) $lachinata_field['value'] ); ?></span></p>
	<?php endforeach; ?>
</div>
