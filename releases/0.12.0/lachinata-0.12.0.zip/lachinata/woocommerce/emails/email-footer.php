<?php
/**
 * Frame of every email, bottom: «¿Alguna duda?» in the emails to buyers, then, outside the
 * card, the shop's line, the «Pie de correos» links and why the reader gets the email.
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package LaChinata\Theme
 * @version 10.4.0
 */

defined( 'ABSPATH' ) || exit;

$lachinata_email = lachinata_email_current();
$lachinata_links = lachinata_email_footer_links( $lachinata_email );
if ( lachinata_email_layout( $lachinata_email )['help'] ) {
	echo lachinata_email_help();
}
?>
								</td>
							</tr>
						</table>
						<table role="presentation" width="600" cellpadding="0" cellspacing="0" class="lc-mail-foot">
							<tr>
								<td class="lc-mail-foot__cell lc-mail-pad">
									<p class="lc-mail-foot__line"><?php echo wp_kses( lachinata_email_footer_line( $lachinata_email ), array( 'a' => array( 'href' => array() ) ) ); ?></p>
									<?php if ( $lachinata_links ) : ?>
										<p class="lc-mail-foot__links">
											<?php
											$lachinata_html = array_map(
												static fn( array $link ): string => sprintf( '<a href="%1$s">%2$s</a>', esc_url( $link['url'] ), esc_html( $link['title'] ) ),
												$lachinata_links
											);
											echo implode( ' &nbsp;·&nbsp; ', $lachinata_html ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the callback.
											?>
										</p>
									<?php endif; ?>
									<?php $lachinata_why = lachinata_email_reason( $lachinata_email ); ?>
									<?php if ( '' !== $lachinata_why ) : ?>
										<p class="lc-mail-foot__why"><?php echo wp_kses( $lachinata_why, array( 'a' => array( 'href' => array() ) ) ); ?></p>
									<?php endif; ?>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</div>
	</body>
</html>
<?php
lachinata_email_current( null, true );
