<?php
/**
 * Order of an email: the payment instructions of the gateway as a note, the product lines
 * (full, or compact without photo), the totals and what other extensions add after the
 * table. What each email shows is lachinata_email_layout().
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package LaChinata\Theme
 * @version 11.2.0
 *
 * @var WC_Order      $order         Order.
 * @var bool          $sent_to_admin Internal email.
 * @var bool          $plain_text    Plain text.
 * @var WC_Email|null $email         Email.
 */

defined( 'ABSPATH' ) || exit;

$lachinata_email  = isset( $email ) && $email instanceof WC_Email ? $email : lachinata_email_current();
$lachinata_layout = lachinata_email_layout( $lachinata_email );

ob_start();
/**
 * WooCommerce: before the order table (payment instructions of the gateway, bank details).
 *
 * @since 2.5.0
 */
do_action( 'woocommerce_email_before_order_table', $order, $sent_to_admin, $plain_text, $email ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook.
$lachinata_before = trim( (string) ob_get_clean() );
if ( $lachinata_layout['instructions'] && '' !== wp_strip_all_tags( $lachinata_before ) ) {
	echo lachinata_email_note( '', wp_kses_post( $lachinata_before ) );
}

// The theme's own notes: transfer details, the delivery of an order still to pay.
echo lachinata_email_order_notes( $order, $lachinata_email );

/**
 * Before the product lines of an email: the module's notes (the gift's), with the
 * lc-mail-* classes.
 *
 * @since 0.8.0
 *
 * @param WC_Order      $order Order.
 * @param WC_Email|null $email Email.
 */
do_action( 'lachinata/email/before_lines', $order, $lachinata_email );

if ( $sent_to_admin && '' !== trim( $order->get_customer_note() ) ) {
	echo lachinata_email_note( __( 'Nota del cliente', 'lachinata' ), '<p>' . nl2br( esc_html( $order->get_customer_note() ) ) . '</p>' );
}

if ( 'none' !== $lachinata_layout['lines'] ) {
	echo lachinata_email_lines( $order, lachinata_email_items( $order, $lachinata_email ), 'compact' === $lachinata_layout['lines'] );
}
if ( $lachinata_layout['totals'] ) {
	echo lachinata_email_totals( $order );
}

ob_start();
/**
 * WooCommerce: after the order table.
 *
 * @since 2.5.0
 */
do_action( 'woocommerce_email_after_order_table', $order, $sent_to_admin, $plain_text, $email ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook.
$lachinata_after = trim( (string) ob_get_clean() );
if ( '' !== wp_strip_all_tags( $lachinata_after ) ) {
	echo '<div class="lc-mail-extra">' . wp_kses_post( $lachinata_after ) . '</div>';
}
