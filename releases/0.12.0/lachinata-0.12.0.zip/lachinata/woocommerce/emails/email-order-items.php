<?php
/**
 * Product lines as rows of the frame, for extensions that call wc_get_email_order_items()
 * inside their own table. The frame's emails use lachinata_email_lines().
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package LaChinata\Theme
 * @version 11.2.0
 *
 * @var WC_Order        $order      Order.
 * @var WC_Order_Item[] $items      Lines.
 * @var bool            $show_image Show the photo.
 */

defined( 'ABSPATH' ) || exit;

echo lachinata_email_line_rows( $order, $items, empty( $show_image ) );
