<?php
/**
 * Account navigation as Tabs (links).
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

/**
 * WooCommerce: before the account navigation.
 *
 * @since 0.2.0
 */
do_action( 'woocommerce_before_account_navigation' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.HookCommentWrongStyle, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook.
?>
<nav class="lc-tabs label lc-account__tabs" aria-label="<?php esc_attr_e( 'Tu cuenta', 'lachinata' ); ?>">
	<?php foreach ( wc_get_account_menu_items() as $lachinata_endpoint => $lachinata_label ) : ?>
		<?php $lachinata_current = wc_is_current_account_menu_item( $lachinata_endpoint ); ?>
		<a href="<?php echo esc_url( wc_get_account_endpoint_url( $lachinata_endpoint ) ); ?>"<?php echo $lachinata_current ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $lachinata_label ); ?></a>
	<?php endforeach; ?>
</nav>
<?php
/**
 * WooCommerce: after the account navigation.
 *
 * @since 0.2.0
 */
do_action( 'woocommerce_after_account_navigation' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.HookCommentWrongStyle, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook.
