<?php
/**
 * WooCommerce notices (success, error, info) with the Notice component.
 *
 * @package LaChinata\Theme
 * @var array<int, array{notice: string, data: array<string, mixed>}> $notices
 */

defined( 'ABSPATH' ) || exit;

if ( empty( $notices ) ) {
	return;
}
$lachinata_tone = (string) get_query_var( 'lachinata_notice_tone', 'info' );
?>
<div class="lc-notices">
	<?php foreach ( $notices as $lachinata_notice ) : ?>
		<?php echo lachinata_notice( wc_kses_notice( $lachinata_notice['notice'] ), $lachinata_tone ); ?>
	<?php endforeach; ?>
</div>
