<?php
/**
 * Product reviews with the system: list with Rating and the review form with Field.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

global $product;
if ( ! $product instanceof WC_Product || ! comments_open() ) {
	return;
}
$lachinata_reviews = get_comments(
	array(
		'post_id' => $product->get_id(),
		'status'  => 'approve',
		'type'    => 'review',
	)
);
?>
<div id="reviews" class="lc-reviews">
	<?php if ( $lachinata_reviews ) : ?>
		<ol class="lc-reviews__list">
			<?php foreach ( $lachinata_reviews as $lachinata_review ) : ?>
				<?php $lachinata_rating = (int) get_comment_meta( (int) $lachinata_review->comment_ID, 'rating', true ); ?>
				<li class="lc-reviews__item" id="comment-<?php echo esc_attr( $lachinata_review->comment_ID ); ?>">
					<?php
					if ( $lachinata_rating && wc_review_ratings_enabled() ) {
						echo lachinata_rating( (float) $lachinata_rating );
					}
					?>
					<p class="lc-reviews__meta body-sm">
						<strong><?php echo esc_html( get_comment_author( $lachinata_review ) ); ?></strong>
						<?php if ( wc_review_is_from_verified_owner( (int) $lachinata_review->comment_ID ) ) : ?>
							<span class="lc-reviews__verified"><?php echo lachinata_icon( 'check', array( 'size' => 'sm' ) ); ?><?php esc_html_e( 'Compra verificada', 'lachinata' ); ?></span>
						<?php endif; ?>
						<time datetime="<?php echo esc_attr( get_comment_date( 'c', $lachinata_review ) ); ?>"><?php echo esc_html( get_comment_date( '', $lachinata_review ) ); ?></time>
					</p>
					<div class="lc-prose body"><?php echo wp_kses_post( wpautop( $lachinata_review->comment_content ) ); ?></div>
				</li>
			<?php endforeach; ?>
		</ol>
	<?php else : ?>
		<p class="body-sm"><?php esc_html_e( 'Todavía no hay opiniones. Cuéntanos qué te parece.', 'lachinata' ); ?></p>
	<?php endif; ?>

	<?php if ( 'no' === get_option( 'woocommerce_review_rating_verification_required' ) || wc_customer_bought_product( '', get_current_user_id(), $product->get_id() ) ) : ?>
		<?php
		$lachinata_commenter    = wp_get_current_commenter();
		$lachinata_field        = static function ( string $name, string $label, string $type, string $value, string $autocomplete ): string {
			return sprintf(
				'<div class="lc-field"><label class="label" for="%1$s">%2$s</label><div class="lc-field__box"><input id="%1$s" name="%1$s" type="%3$s" value="%4$s" autocomplete="%5$s" required></div></div>',
				esc_attr( $name ),
				esc_html( $label ),
				esc_attr( $type ),
				esc_attr( $value ),
				esc_attr( $autocomplete )
			);
		};
		$lachinata_rating_field = '';
	if ( wc_review_ratings_enabled() ) {
		$lachinata_rating_field = '<div class="lc-field"><label class="label" for="rating">' . esc_html__( 'Tu valoración', 'lachinata' ) . '</label><div class="lc-field__box"><select name="rating" id="rating"' . ( wc_review_ratings_required() ? ' required' : '' ) . '><option value="">' . esc_html__( 'Elige de 1 a 5 estrellas', 'lachinata' ) . '</option>';
		foreach ( array( 5, 4, 3, 2, 1 ) as $lachinata_stars ) {
			/* translators: %d: number of stars. */
			$lachinata_rating_field .= sprintf( '<option value="%1$d">%2$s</option>', $lachinata_stars, esc_html( sprintf( _n( '%d estrella', '%d estrellas', $lachinata_stars, 'lachinata' ), $lachinata_stars ) ) );
		}
		$lachinata_rating_field .= '</select>' . lachinata_icon(
			'chevron-down',
			array(
				'size'  => 'sm',
				'class' => 'lc-field__chev',
			)
		) . '</div></div>';
	}
		$lachinata_fields = static function ( array $fields ) use ( $lachinata_field, $lachinata_commenter ): array {
			unset( $fields['url'] );
			$fields['author'] = $lachinata_field( 'author', __( 'Nombre', 'lachinata' ), 'text', (string) $lachinata_commenter['comment_author'], 'name' );
			$fields['email']  = $lachinata_field( 'email', __( 'Correo electrónico', 'lachinata' ), 'email', (string) $lachinata_commenter['comment_author_email'], 'email' );
			return $fields;
		};
		add_filter( 'comment_form_default_fields', $lachinata_fields );
		comment_form(
			array(
				'title_reply'          => esc_html__( 'Escribe tu opinión', 'lachinata' ),
				'title_reply_before'   => '<h3 id="reply-title" class="h4">',
				'title_reply_after'    => '</h3>',
				'class_form'           => 'lc-reviews__form',
				'class_submit'         => 'lc-btn button',
				'label_submit'         => esc_html__( 'Enviar opinión', 'lachinata' ),
				'comment_notes_before' => '<p class="body-sm">' . esc_html__( 'Tu correo no se publica.', 'lachinata' ) . '</p>',
				'comment_notes_after'  => '',
				'logged_in_as'         => '',
				'comment_field'        => $lachinata_rating_field . '<div class="lc-field"><label class="label" for="comment">' . esc_html__( 'Tu opinión', 'lachinata' ) . '</label><div class="lc-field__box"><textarea id="comment" name="comment" rows="5" required></textarea></div></div>',
			)
		);
		remove_filter( 'comment_form_default_fields', $lachinata_fields );
		?>
	<?php else : ?>
		<p class="body-sm"><?php esc_html_e( 'Solo pueden opinar quienes han comprado este producto.', 'lachinata' ); ?></p>
	<?php endif; ?>
</div>
