/**
 * Destination picker (module `locale`). The head script has already read the cookie: the
 * page carries `data-lc-destino` or, on a first visit, `data-lc-locale-pending`. Here:
 * open the picker on a first visit with the destination suggested by the location, apply
 * the preselection when it is closed without choosing, say «Parece que estás en…» once
 * when the location points to another shop, and, on pages that are the same for
 * everyone, write the visitor's destination and free shipping threshold in the texts of
 * the PromoBar and the UspBar that carry their templates (`data-lc-free`, from `shipping`).
 * Choosing is the form's own POST; nothing here redirects.
 */
(() => {
	const root = document.documentElement;
	const done = () => {
		root.removeAttribute('data-lc-locale-pending');
		document.dispatchEvent(new CustomEvent('lachinata:locale:done'));
	};

	const data = window.lachinataLocale;
	const state = window.lachinata && window.lachinata.locale;
	const layer = document.querySelector('[data-lc-layer="market"]');
	const form = layer && layer.querySelector('[data-lc-market]');
	if (!data || !state || !form) {
		done();
		return;
	}
	const { __, sprintf } = window.wp.i18n;

	const radios = [...form.querySelectorAll('input[name="lc_destino"]')];
	const other = form.querySelector('select[name="lc_destino_otro"]');
	const submit = form.querySelector('[data-lc-market-submit]');
	const hint = form.querySelector('[data-lc-market-hint]');
	const path = form.querySelector('[data-lc-market-path]');
	const arrow =
		'<svg class="lc-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><use href="#lc-icon-arrow-right"></use></svg>';

	let submitted = false;
	let preselected = '';

	const setCookie = (name, value, days) => {
		document.cookie = `${name}=${encodeURIComponent(value)}; path=/; SameSite=Lax${
			days ? `; max-age=${days * 86400}` : ''
		}${window.location.protocol === 'https:' ? '; Secure' : ''}`;
	};

	const value = () =>
		(other && other.value) ||
		(radios.find((radio) => radio.checked) || {}).value ||
		'';

	const refresh = () => {
		radios.forEach((radio) =>
			radio
				.closest('.lc-market__opt')
				.classList.toggle('lc-market__opt--on', radio.checked)
		);
		const store = data.stores[value()] || '';
		submit.textContent = store
			? sprintf(
					/* translators: %s: shop name («Canarias»). */
					__('Ir a la tienda de %s', 'lachinata-core'),
					store
				)
			: __('Continuar', 'lachinata-core');
		if (store) {
			submit.insertAdjacentHTML('beforeend', arrow);
		}
	};

	const select = (id) => {
		const radio = radios.find((item) => item.value === id);
		radios.forEach((item) => {
			item.checked = item === radio;
		});
		if (other) {
			other.value =
				!radio && [...other.options].some((o) => o.value === id)
					? id
					: '';
		}
		if (!radio && (!other || !other.value) && radios[0]) {
			radios[0].checked = true;
		}
		refresh();
	};

	radios.forEach((radio) =>
		radio.addEventListener('change', () => {
			if (other) {
				other.value = '';
			}
			refresh();
		})
	);
	if (other) {
		other.addEventListener('change', () => {
			if (other.value) {
				radios.forEach((radio) => {
					radio.checked = false;
				});
			} else if (radios[0]) {
				radios[0].checked = true;
			}
			refresh();
		});
	}
	form.addEventListener('submit', () => {
		submitted = true;
		path.value = window.location.pathname + window.location.search;
	});

	// The theme's layers cancel the event when they open the layer.
	const open = () =>
		!document.dispatchEvent(
			new CustomEvent('lachinata:layer:open', {
				cancelable: true,
				detail: { name: 'market' },
			})
		);

	const request = (params) => {
		const url = new URL(data.endpoint);
		Object.entries(params).forEach(([key, val]) =>
			url.searchParams.set(key, val)
		);
		return window
			.fetch(url, { credentials: 'same-origin' })
			.then((response) => (response.ok ? response.json() : {}))
			.catch(() => ({}));
	};

	// The free shipping texts of a destination: its label and threshold (a price in the
	// shop's currency, or null) in the templates of each item; without free shipping, the
	// item takes its text without an amount or, if it has none (PromoBar), goes.
	const free = (id, amount) => {
		const label = state.labels[id] || '';
		const fill = (text) =>
			text
				.split('{destino}')
				.join(label)
				.split('{envio_gratis}')
				.join(amount || '');
		document.querySelectorAll('[data-lc-free]').forEach((item) => {
			let templates;
			try {
				templates = JSON.parse(item.getAttribute('data-lc-free'));
			} catch {
				return;
			}
			const texts = amount ? templates.with : templates.without;
			if (!texts) {
				const next = item.parentNode.querySelector(
					'.lc-promo__msg:not([data-lc-free])'
				);
				if (!item.hidden && next) {
					next.hidden = false;
				}
				item.remove();
				return;
			}
			const title =
				item.querySelector('strong') ||
				item.querySelector(':scope > a, :scope > span');
			const text = item.querySelector('strong + span');
			if (title && 'title' in texts) {
				title.textContent = fill(texts.title);
			}
			if (text && 'text' in texts) {
				text.textContent = fill(texts.text);
			}
		});
	};
	const reveal = () => {
		const style = document.getElementById('lc-locale-free');
		if (style) {
			style.remove();
		}
	};

	// The page takes the destination without reloading (cache without destination).
	const apply = (id) => {
		state.current = id;
		root.setAttribute('data-lc-destino', id);
		state.hide(id);
		document.querySelectorAll('.lc-mbadge').forEach(state.label);
		document.querySelectorAll('[data-lc-locale-name]').forEach((name) => {
			name.textContent = state.labels[id] || '';
		});
		request({ destino: id }).then((answer) => {
			if (answer.threshold) {
				free(id, answer.threshold.value);
			}
		});
	};

	// Closed without choosing: the preselection, if it is of this shop. Never a redirect.
	const dismiss = () => {
		const id = preselected || value();
		if (!id || data.stores[id]) {
			setCookie(state.seen, '1', 0);
			done();
			return;
		}
		window
			.fetch(data.endpoint, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({ destino: id }),
			})
			.then((response) => (response.ok ? response.json() : null))
			.then((answer) => {
				if (answer && answer.reload) {
					window.location.reload();
					return;
				}
				if (answer) {
					apply(id);
				} else {
					setCookie(state.seen, '1', 0);
				}
				done();
			})
			.catch(() => {
				setCookie(state.seen, '1', 0);
				done();
			});
	};

	// «Parece que estás en …», once, in the toasts region (no layout shift).
	const suggestOtherShop = (suggestion) => {
		const region = document.querySelector('[data-lc-toasts]');
		if (!region) {
			return;
		}
		const notice = document.createElement('div');
		notice.className = 'lc-notice body-sm lc-notice--info';
		notice.setAttribute('role', 'status');
		const text = document.createElement('span');
		text.textContent = sprintf(
			/* translators: 1: destination («España · Islas Canarias»), 2: shop name («Canarias»). */
			__(
				'Parece que estás en %1$s. ¿Quieres ir a la tienda de %2$s?',
				'lachinata-core'
			),
			data.labels[suggestion.id] || suggestion.id,
			suggestion.store
		);
		const go = document.createElement('button');
		go.type = 'button';
		go.className = 'lc-notice__action label';
		go.textContent = __('Ir a la tienda', 'lachinata-core');
		go.addEventListener('click', () => {
			select(suggestion.id);
			form.requestSubmit();
		});
		const close = document.createElement('button');
		close.type = 'button';
		close.className = 'lc-btn lc-btn--icon lc-notice__close';
		close.setAttribute('aria-label', __('Cerrar', 'lachinata-core'));
		close.innerHTML = arrow.replace('arrow-right', 'close');
		close.addEventListener('click', () => notice.remove());
		notice.append(text, go, close);
		region.replaceChildren(notice);
	};

	document.addEventListener(
		'click',
		(event) => {
			if (event.target.closest('[data-lc-open="market"]')) {
				select(state.current || preselected || value());
			}
		},
		true
	);
	document.addEventListener('lachinata:layer:closed', (event) => {
		if (
			event.detail &&
			event.detail.name === 'market' &&
			!submitted &&
			root.hasAttribute('data-lc-locale-pending')
		) {
			dismiss();
		}
	});

	// Opened by the address (no JavaScript path): hand it to the theme's layers.
	if (!layer.hidden) {
		layer.hidden = true;
		open();
	}

	const checked = state.cookieValue(state.checked);
	if (root.hasAttribute('data-lc-locale-pending')) {
		setCookie(state.checked, '1', 365);
		request({ sugerir: 1 }).then((answer) => {
			if (answer.suggestion) {
				preselected = answer.suggestion.id;
				hint.textContent = answer.suggestion.hint;
				hint.hidden = false;
			}
			select(preselected || value());
			preselected = value();
			if (!open()) {
				done();
			}
		});
	} else if (state.current) {
		const params = state.renders ? {} : { destino: state.current };
		if (!checked) {
			params.sugerir = 1;
			setCookie(state.checked, '1', 365);
		}
		if (Object.keys(params).length) {
			request(params).then((answer) => {
				if (answer.threshold) {
					free(state.current, answer.threshold.value);
				}
				reveal();
				const suggestion = answer.suggestion;
				if (
					suggestion &&
					suggestion.store &&
					suggestion.id !== state.current
				) {
					suggestOtherShop(suggestion);
				}
			});
		}
	}
})();
