<?php
/**
 * Block `lachinata/oleotecas`: the finder inside any page.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

use LaChinata\Core\Hooks;
use LaChinata\Core\Templates;

defined( 'ABSPATH' ) || exit;

/**
 * The same finder of `/oleotecas/` (search, «Cerca de mí», list and map on demand) with an
 * optional heading, for the home or any page. Rendered on the server; the editor shows it
 * with ServerSideRender.
 */
final class Block {

	/**
	 * Editor script handle.
	 */
	public const EDITOR = 'lachinata-oleotecas-block';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'init', array( self::class, 'register' ) );
	}

	/**
	 * Registers the editor script and the block.
	 */
	public static function register(): void {
		$file  = LACHINATA_CORE_DIR . '/modules/oleotecas/build/block.asset.php';
		$asset = is_readable( $file ) ? require $file : array(
			'dependencies' => array( 'wp-blocks', 'wp-block-editor', 'wp-components', 'wp-element', 'wp-i18n', 'wp-server-side-render' ),
			'version'      => LACHINATA_CORE_VERSION,
		);
		wp_register_script( self::EDITOR, plugins_url( 'modules/oleotecas/build/block.js', LACHINATA_CORE_FILE ), (array) $asset['dependencies'], (string) $asset['version'], true );
		wp_set_script_translations( self::EDITOR, 'lachinata-core', LACHINATA_CORE_DIR . '/languages' );
		register_block_type(
			LACHINATA_CORE_DIR . '/modules/oleotecas/blocks/finder',
			array(
				'render_callback' => Hooks::wrap( static fn( $attributes ): string => self::render( is_array( $attributes ) ? $attributes : array() ), '' ),
			)
		);
	}

	/**
	 * HTML of the block.
	 *
	 * @param array<string, mixed> $attributes Attributes (title).
	 */
	public static function render( array $attributes ): string {
		if ( ! Directory::stores() ) {
			return '';
		}
		Pages::use_script();
		$title = trim( (string) ( $attributes['title'] ?? '' ) );
		$args  = Pages::finder_args( 'lc-finder-block', (string) get_post_type_archive_link( Model::POST_TYPE ) );
		return sprintf(
			'<section class="lc-stores-block">%1$s%2$s</section>',
			'' === $title ? '' : '<h2 class="h2">' . esc_html( $title ) . '</h2>',
			Templates::capture( 'oleotecas', 'parts/finder', $args )
		);
	}
}
