<?php
/**
 * The stores for the browser.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * Every store in short form, in a static JSON file with its version in the name
 * (`oleotecas.<hash>.json`): long cache headers, regenerated when a store, a zone, a
 * service or a setting changes. The finder computes distance, filters, order and «abierta
 * ahora» in the browser from it, so the page leaves the cache with nothing that depends on
 * the time or on who looks. The same document is served by REST (`/lachinata/v1/oleotecas`),
 * with CORS for the client shops, and is the shape the client mode will read (9b).
 *
 * @phpstan-import-type StoreData from Store
 */
final class Data {

	/**
	 * Option with the current file: name, URL, hash, time and number of stores.
	 */
	public const OPTION = 'lachinata_oleotecas_json';

	/**
	 * Format of the document; raised when a key changes.
	 */
	public const VERSION = 1;

	/**
	 * Folder under uploads.
	 */
	private const DIR = 'lachinata-oleotecas';

	/**
	 * Whether something changed in this request.
	 *
	 * @var bool
	 */
	private static bool $dirty = false;

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'save_post_' . Model::POST_TYPE, array( self::class, 'touch' ) );
		Hooks::add_action( 'deleted_post', array( self::class, 'touch_post' ), 10, 2 );
		Hooks::add_action( 'trashed_post', array( self::class, 'touch_post' ) );
		Hooks::add_action( 'updated_post_meta', array( self::class, 'touch_meta' ), 10, 2 );
		Hooks::add_action( 'added_post_meta', array( self::class, 'touch_meta' ), 10, 2 );
		foreach ( array( Model::ZONE, Model::SERVICE ) as $taxonomy ) {
			Hooks::add_action( 'created_' . $taxonomy, array( self::class, 'touch' ) );
			Hooks::add_action( 'edited_' . $taxonomy, array( self::class, 'touch' ) );
			Hooks::add_action( 'delete_' . $taxonomy, array( self::class, 'touch' ) );
		}
		Hooks::add_action( 'updated_option', array( self::class, 'touch_option' ) );
		Hooks::add_action( 'shutdown', array( self::class, 'flush' ) );
	}

	/**
	 * Marks the data as changed.
	 */
	public static function touch(): void {
		self::$dirty = true;
		Directory::reset();
	}

	/**
	 * A store was deleted or trashed.
	 *
	 * @param mixed $post_id Post id.
	 * @param mixed $post    Post (deleted_post).
	 */
	public static function touch_post( $post_id, $post = null ): void {
		if ( Model::POST_TYPE === get_post_type( (int) $post_id ) || ( $post instanceof \WP_Post && Model::POST_TYPE === $post->post_type ) ) {
			self::touch();
		}
	}

	/**
	 * A field of a store changed (also through REST, after save_post).
	 *
	 * @param mixed $meta_id Meta id.
	 * @param mixed $post_id Post id.
	 */
	public static function touch_meta( $meta_id, $post_id ): void {
		if ( Model::POST_TYPE === get_post_type( (int) $post_id ) ) {
			self::touch();
		}
	}

	/**
	 * A setting of the module changed.
	 *
	 * @param mixed $option Option name.
	 */
	public static function touch_option( $option ): void {
		if ( is_string( $option ) && str_starts_with( $option, 'lachinata_oleotecas_' ) && self::OPTION !== $option && Geocoding::FAILURE !== $option ) {
			self::touch();
		}
	}

	/**
	 * Writes the file at the end of a request that changed something.
	 */
	public static function flush(): void {
		if ( self::$dirty ) {
			self::$dirty = false;
			self::write();
		}
	}

	/**
	 * One store in short form.
	 *
	 * @param array<string, mixed> $store Store.
	 * @phpstan-param StoreData $store
	 * @param string               $today Y-m-d (specials that have not ended).
	 * @return array<string, mixed>
	 */
	public static function summary( array $store, string $today ): array {
		$place = Directory::place( $store );
		$image = $store['photos'] ? wp_get_attachment_image_url( $store['photos'][0], 'medium_large' ) : '';
		return array(
			'slug'         => $store['slug'],
			'name'         => $store['name'],
			'title'        => $store['title'],
			'url'          => $store['url'],
			'street'       => $store['street'],
			'line'         => $store['line'],
			'city'         => $store['city'],
			'postcode'     => $store['postcode'],
			'country'      => $store['country'],
			'countryName'  => $store['country_name'],
			'zone'         => $place['zone'] ? $place['zone']['slug'] : ( $place['country'] ? $place['country']['slug'] : '' ),
			'zones'        => Directory::zone_slugs( $store ),
			'lat'          => $store['lat'],
			'lng'          => $store['lng'],
			'timezone'     => $store['timezone'],
			'hours'        => $store['hours'],
			'specials'     => Schedule::upcoming( $store['specials'], $today, 20 ),
			'phone'        => $store['phone'],
			'phoneDisplay' => $store['phone_display'],
			'web'          => '' === $store['web']['url'] ? null : $store['web'],
			'image'        => is_string( $image ) ? $image : '',
			'services'     => array_column( $store['services'], 'slug' ),
		);
	}

	/**
	 * The whole document.
	 *
	 * @return array<string, mixed>
	 */
	public static function document(): array {
		$today    = gmdate( 'Y-m-d', time() - DAY_IN_SECONDS );
		$stores   = array();
		$services = array();
		foreach ( Directory::stores() as $store ) {
			$stores[] = self::summary( $store, $today );
			foreach ( $store['services'] as $service ) {
				$services[ $service['slug'] ] = $service['name'];
			}
		}
		$zones = array();
		foreach ( Directory::zones() as $zone ) {
			if ( ! $zone['stores'] ) {
				continue;
			}
			$parent  = $zone['parent'] ? Directory::zone( $zone['parent'] ) : null;
			$zones[] = array(
				'slug'   => $zone['slug'],
				'name'   => $zone['name'],
				'parent' => $parent ? $parent['slug'] : '',
				'count'  => count( $zone['stores'] ),
				'url'    => $zone['page'] ? $zone['url'] : '',
			);
		}
		return array(
			'version'  => self::VERSION,
			'noun'     => array( Texts::noun(), Texts::noun( true ) ),
			'nearKm'   => max( 1, (int) OleotecasModule::setting( 'near_km' ) ),
			'stores'   => $stores,
			'zones'    => $zones,
			'services' => (object) $services,
		);
	}

	/**
	 * Uploads folder of the file.
	 *
	 * @return array{dir: string, url: string}
	 */
	private static function folder(): array {
		$uploads = wp_get_upload_dir();
		return array(
			'dir' => trailingslashit( (string) $uploads['basedir'] ) . self::DIR,
			'url' => trailingslashit( (string) $uploads['baseurl'] ) . self::DIR,
		);
	}

	/**
	 * Writes the document to a new file, its `.htaccess` (cache and CORS) and the option;
	 * removes the older files but the previous one (pages in a cache may still ask for it).
	 *
	 * @return array{file: string, url: string, hash: string, at: int, count: int}|null
	 */
	public static function write(): ?array {
		Directory::reset();
		$document = self::document();
		$json     = (string) wp_json_encode( $document, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		$hash     = substr( md5( $json ), 0, 10 );
		$folder   = self::folder();
		if ( ! wp_mkdir_p( $folder['dir'] ) ) {
			return null;
		}
		$name = 'oleotecas.' . $hash . '.json';
		$path = $folder['dir'] . '/' . $name;
		if ( ! file_exists( $path ) && false === file_put_contents( $path, $json ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- A public file of our own folder.
			return null;
		}
		file_put_contents( $folder['dir'] . '/.htaccess', self::htaccess() ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- Headers of our own folder.
		$previous = get_option( self::OPTION );
		$keep     = array( $name, is_array( $previous ) ? (string) ( $previous['file'] ?? '' ) : '' );
		foreach ( (array) glob( $folder['dir'] . '/oleotecas.*.json' ) as $old ) {
			if ( is_string( $old ) && ! in_array( basename( $old ), $keep, true ) ) {
				wp_delete_file( $old );
			}
		}
		$state = array(
			'version' => LACHINATA_CORE_VERSION,
			'file'    => $name,
			'url'     => $folder['url'] . '/' . $name,
			'hash'    => $hash,
			'at'      => time(),
			'count'   => count( $document['stores'] ),
		);
		update_option( self::OPTION, $state, false );
		return $state;
	}

	/**
	 * The current file, or null when it was never written or is missing.
	 *
	 * @return array{file: string, url: string, hash: string, at: int, count: int}|null
	 */
	public static function current(): ?array {
		$state = get_option( self::OPTION );
		// Written by another version of the plugin: its keys may be others.
		if ( ! is_array( $state ) || empty( $state['file'] ) || LACHINATA_CORE_VERSION !== ( $state['version'] ?? '' ) ) {
			return null;
		}
		return array(
			'file'  => (string) $state['file'],
			'url'   => (string) ( $state['url'] ?? '' ),
			'hash'  => (string) ( $state['hash'] ?? '' ),
			'at'    => (int) ( $state['at'] ?? 0 ),
			'count' => (int) ( $state['count'] ?? 0 ),
		);
	}

	/**
	 * URL of the current file, written first when it is missing.
	 */
	public static function url(): string {
		$state = self::current();
		if ( null === $state || ! file_exists( self::folder()['dir'] . '/' . $state['file'] ) ) {
			$state = self::write();
		}
		return null === $state ? '' : set_url_scheme( $state['url'] );
	}

	/**
	 * Whether the file matches the data (health): same hash as a fresh document.
	 */
	public static function stale(): bool {
		$state = self::current();
		if ( null === $state ) {
			return true;
		}
		$json = (string) wp_json_encode( self::document(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		return substr( md5( $json ), 0, 10 ) !== $state['hash'] || ! file_exists( self::folder()['dir'] . '/' . $state['file'] );
	}

	/**
	 * Origins allowed to read the data from the browser: the client domains of the settings.
	 *
	 * @return list<string>
	 */
	public static function origins(): array {
		$out = array();
		foreach ( (array) OleotecasModule::setting( 'client_domains' ) as $domain ) {
			$host = strtolower( trim( (string) preg_replace( '#^https?://#', '', trim( (string) $domain ) ), '/' ) );
			if ( preg_match( '/^[a-z0-9.-]+\.[a-z]{2,}$/', $host ) ) {
				$out[] = 'https://' . $host;
			}
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * `.htaccess` of the folder: a year of cache (the name changes with the content) and
	 * CORS for the client domains. Servers that do not read it (nginx) take the same rules
	 * from docs/despliegue-oleotecas.md; the REST copy sends them always.
	 */
	public static function htaccess(): string {
		$lines   = array( '# lachinata-core: oleotecas', '<IfModule mod_headers.c>', '<FilesMatch "\.json$">', 'Header set Cache-Control "public, max-age=31536000, immutable"' );
		$origins = self::origins();
		if ( $origins ) {
			$pattern = implode( '|', array_map( static fn( string $origin ): string => preg_quote( $origin, '/' ), $origins ) );
			$lines[] = 'SetEnvIf Origin "^(' . $pattern . ')$" LC_CORS=$0';
			$lines[] = 'Header set Access-Control-Allow-Origin "%{LC_CORS}e" env=LC_CORS';
			$lines[] = 'Header merge Vary Origin';
		}
		$lines[] = '</FilesMatch>';
		$lines[] = '</IfModule>';
		return implode( "\n", $lines ) . "\n";
	}
}
