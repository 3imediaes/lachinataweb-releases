<?php
/**
 * Module `oleotecas`: the network of stores.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

use LaChinata\Core\GapLog;
use LaChinata\Core\Module;
use LaChinata\Core\Plugin;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Finder, map on demand, zone pages and the page of each store, on the post type
 * `oleoteca` (same URLs as before), with its own fields instead of ACF, a migration of the
 * old fields, a static JSON for the browser, structured data and the measurement of the
 * finder. Works for any brand with a network of stores: what a store is called, the tiles,
 * the geocoder, the distance of «cerca», the client domains and the texts are settings or
 * content. The client mode and the partners' API come in 9b (0.12.1): this version leaves
 * the setting of the mode, the data adapter (Source) and the slot of the token.
 */
final class OleotecasModule extends Module {

	/**
	 * Module id.
	 */
	public function id(): string {
		return 'oleotecas';
	}

	/**
	 * Module name.
	 */
	public function label(): string {
		return __( 'Oleotecas', 'lachinata-core' );
	}

	/**
	 * Module description.
	 */
	public function description(): string {
		return __( 'Buscador de tiendas con mapa a demanda, páginas de zona y ficha de cada tienda con horario, «abierta ahora», cómo llegar y datos estructurados. Sustituye a los campos de ACF del tipo «oleoteca» sin cambiar sus URL.', 'lachinata-core' );
	}

	/**
	 * Version in which the module was added.
	 */
	public function since(): string {
		return '0.12.0';
	}

	/**
	 * Documentation.
	 */
	public function docs(): string {
		return 'plugin/modules/oleotecas/README.md';
	}

	/**
	 * Requirements.
	 *
	 * @return array{woocommerce: string}
	 */
	public function requires(): array {
		return array( 'woocommerce' => '10.0' );
	}

	/**
	 * Settings. What changes between brands and shops travels in the JSON; the token of the
	 * partners and the client domains are of each site.
	 *
	 * @return array<string, array{type: 'bool'|'int'|'float'|'string'|'array', default: mixed, export?: bool}>
	 */
	public function settings(): array {
		$copy = static fn( string $type, $value, bool $export = true ): array => array(
			'type'    => $type,
			'default' => $value,
			'export'  => $export,
		);
		return array(
			'mode'              => $copy( 'string', Source::MASTER, false ),
			'master_url'        => $copy( 'string', '', false ),
			'partner_token'     => $copy( 'string', '', false ),
			'client_domains'    => $copy( 'array', array(), false ),
			'noun'              => $copy( 'string', '' ),
			'noun_plural'       => $copy( 'string', '' ),
			'store_title'       => $copy( 'string', '' ),
			'archive_title'     => $copy( 'string', '' ),
			'archive_lead'      => $copy( 'string', '' ),
			'slug_single'       => $copy( 'string', 'oleoteca' ),
			'slug_archive'      => $copy( 'string', 'oleotecas' ),
			'near_km'           => $copy( 'int', 150 ),
			'tiles_url'         => $copy( 'string', 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png?key={key}' ),
			'tiles_key'         => $copy( 'string', '', false ),
			'tiles_attribution' => $copy( 'string', '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> · © <a href="https://carto.com/attributions">CARTO</a>' ),
			'tiles_provider'    => $copy( 'string', 'OpenStreetMap y CARTO' ),
			'tiles_company'     => $copy( 'string', 'CARTO (CartoDB Inc.)' ),
			'tiles_privacy_url' => $copy( 'string', 'https://carto.com/privacy' ),
			'geocoder_url'      => $copy( 'string', Geocoder\Nominatim::URL ),
			'geocoder_contact'  => $copy( 'string', '', false ),
			'whatsapp_text'     => $copy( 'string', '' ),
			'og_image'          => $copy( 'int', 0, false ),
			'franchise_eyebrow' => $copy( 'string', '' ),
			'franchise_title'   => $copy( 'string', '' ),
			'franchise_text'    => $copy( 'string', '' ),
			'franchise_url'     => $copy( 'string', '' ),
			'franchise_cta'     => $copy( 'string', '' ),
		);
	}

	/**
	 * A setting of the module.
	 *
	 * @param string $key Setting key.
	 * @return mixed
	 */
	public static function setting( string $key ) {
		$module = self::instance();
		return null === $module ? null : Settings::get( $module, $key );
	}

	/**
	 * The module, for Settings.
	 */
	public static function instance(): ?Module {
		return Plugin::instance()->modules()->get( 'oleotecas' );
	}

	/**
	 * Problems of the module (the geocoder failing, a file that could not be written).
	 */
	public static function gaps(): GapLog {
		return new GapLog( 'lachinata_oleotecas_gaps', 'lachinata-oleotecas' );
	}

	/**
	 * Stores without coordinates or hours, the geocoder failing, the JSON out of date, the
	 * post type registered by another plugin and the client mode (not built yet).
	 *
	 * @return array{configured: bool, credentials: bool|null, notes: string[]}
	 */
	public function health(): array {
		$notes   = array();
		$stores  = Directory::stores();
		$no_geo  = array();
		$no_hour = array();
		foreach ( $stores as $store ) {
			if ( null === $store['lat'] || null === $store['lng'] ) {
				$no_geo[] = $store['slug'];
			}
			if ( ! Schedule::has_hours( $store['hours'] ) ) {
				$no_hour[] = $store['slug'];
			}
		}
		/* translators: %s: «39 oleotecas». */
		$notes[] = sprintf( __( '%s publicadas', 'lachinata-core' ), Texts::count( count( $stores ) ) );
		if ( $no_geo ) {
			/* translators: %s: slugs. */
			$notes[] = sprintf( __( 'Sin coordenadas: %s', 'lachinata-core' ), implode( ', ', $no_geo ) );
		}
		if ( $no_hour ) {
			/* translators: %s: slugs. */
			$notes[] = sprintf( __( 'Sin horario: %s', 'lachinata-core' ), implode( ', ', $no_hour ) );
		}
		$failure = Geocoding::last_failure();
		if ( null !== $failure ) {
			/* translators: 1: date, 2: message. */
			$notes[] = sprintf( __( 'El geocodificador falló el %1$s: %2$s', 'lachinata-core' ), wp_date( 'j M H:i', $failure['at'] ), $failure['message'] );
		}
		if ( Data::stale() ) {
			$notes[] = __( 'El JSON del buscador no coincide con los datos: se regenera al guardar una oleoteca o con «wp lachinata oleotecas json».', 'lachinata-core' );
		}
		if ( Tiles::needs_key() && ! Tiles::has_key() ) {
			$notes[] = __( 'Falta la clave de las teselas del mapa (WooCommerce → La Chinata → Oleotecas): sin ella no se ofrece el mapa.', 'lachinata-core' );
		}
		if ( Model::taken() ) {
			$notes[] = __( 'Otro plugin registraba ya el tipo de contenido «oleoteca»: desactívalo (docs/despliegue-oleotecas.md).', 'lachinata-core' );
		}
		if ( Source::CLIENT === self::setting( 'mode' ) ) {
			$notes[] = __( 'El modo cliente llega en la 0.12.1: de momento esta tienda funciona como maestra.', 'lachinata-core' );
		}
		$notes[] = __( 'Recuerda: nombre, dirección, teléfono y horario deben coincidir con el perfil de Google de cada tienda.', 'lachinata-core' );
		return array(
			'configured'  => (bool) $stores && ! $no_geo && ! $no_hour,
			'credentials' => Tiles::needs_key() ? Tiles::has_key() : null,
			'notes'       => $notes,
		);
	}

	/**
	 * Term meta of the zones. The stores and their fields are content of the site (posts):
	 * «Borrar datos» never deletes them.
	 *
	 * @return array{term_meta: string[]}
	 */
	public function owned_data(): array {
		return array(
			'term_meta' => array( Fields::ZONE_TEXT, Fields::ZONE_FAQ, Fields::ZONE_GROUP ),
		);
	}

	/**
	 * Registers the hooks.
	 */
	public function boot(): void {
		Model::boot();
		Data::boot();
		Rest::boot();
		Pages::boot();
		Seo::boot();
		Block::boot();
		Privacy::boot();
		if ( is_admin() ) {
			Editor::boot();
			ZoneFields::boot();
			OleotecasTab::boot();
		}
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::add_command( 'lachinata oleotecas', Cli::class );
		}
	}
}
