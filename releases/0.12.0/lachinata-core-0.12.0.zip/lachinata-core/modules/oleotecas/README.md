# Módulo `oleotecas`

Buscador de tiendas, mapa a demanda, páginas de zona y ficha de cada tienda de una red de tiendas físicas: las oleotecas de La Chinata, o las tiendas de cualquier marca. Sustituye a los 20 campos de ACF del tipo «oleoteca», al plugin propio que lo registraba y a la página de Elementor de `/oleotecas/`. **Las URL no cambian**: el módulo registra el mismo tipo de contenido (`oleoteca`, `/oleoteca/{slug}/`), así que se conservan los IDs, los enlaces y lo que posicionan.

Lo que cambia entre marcas son ajustes o contenido, no código: cómo se llama cada tienda, el nombre largo, el proveedor de teselas y su atribución, el geocodificador, la distancia de «cerca», los dominios cliente, el texto de WhatsApp, el bloque de franquicias y los textos y preguntas de cada zona.

Especificación: `design-system/sistema/09-oleotecas.md`. Decisiones: `design-system/docs/decisiones.md` (Oleotecas). Paso a producción: `docs/despliegue-oleotecas.md`. Ajustes: WooCommerce → La Chinata → Oleotecas.

El modo cliente (las tiendas de otro sitio) y la API de socios para el panel de las franquicias son del 9b (0.12.1). Esta versión deja preparados el ajuste `mode`, el adaptador de datos (`Source`) y el hueco del token (`partner_token`), sin rutas ni lógica.

## Qué hace

| Pieza | Cómo | Dónde |
| --- | --- | --- |
| **Modelo**: tipo `oleoteca` (rewrite `oleoteca`, sin `with_front`, archivo en `/oleotecas/`), zonas jerárquicas País › Zona (`lc_oleoteca_zona`, URL plana `/oleotecas/{zona}/`) y servicios (`lc_oleoteca_servicio`). `/oleoteca/` (el archivo viejo) va con 301 a `/oleotecas/` | `init`, `template_redirect` | `Model.php` |
| **Campos registrados** con `show_in_rest` y su esquema: nombre corto, dirección por partes (país ISO), coordenadas, zona horaria IANA, teléfono y WhatsApp en E.164, correo, tienda online propia (URL y etiqueta), redes (red + URL), horario semanal (una o dos franjas por día), horarios especiales (fecha o rango, cerrado o con franjas, nota), fotos (0–8), texto propio y favoritos (1–4 productos). En las zonas: texto, preguntas y «agrupar por ciudad» | `register_post_meta`, `register_term_meta` | `Fields.php`, `Schedule.php` |
| **Panel del editor**: dirección con «Buscar en el mapa» (el geocodificador propone) y marcador que se arrastra (la persona corrige), horario con dos franjas y «copiar el lunes a toda la semana», días especiales, contacto y redes como lista, fotos, texto y favoritos. Guarda los campos por la REST de WordPress con el post | `enqueue_block_editor_assets` | `Editor.php`, `src/editor.js` |
| **Zonas**: texto, etiqueta del grupo de fuera de la ciudad principal («Comunidad de Madrid») y preguntas en la pantalla de cada zona | `lc_oleoteca_zona_edit_form_fields`, `edited_lc_oleoteca_zona` | `ZoneFields.php` |
| **Geocodificador** en el servidor: Nominatim por defecto (URL y contacto en los ajustes, User-Agent identificable), sustituible por el filtro `lachinata/oleotecas/geocoder`. Una petición por segundo, caché (30 días lo encontrado, uno lo no encontrado) y el último fallo para la salud | | `Geocoding.php`, `Geocoder/` |
| **Migración** `wp lachinata oleotecas migrate [--map=<json>] [--dry-run] [--force] [--report=<json>]`: lee los campos de ACF de las publicadas, lee los horarios escritos a mano (`HoursParser`), normaliza dirección, teléfono y correo, deduce la zona horaria (la del país más cercana a las coordenadas), asigna país y zona y deja un informe. Lo que no entiende va al informe y se queda vacío. No toca los campos viejos; una tienda ya migrada no se vuelve a tocar sin `--force` | WP-CLI | `Migration.php`, `Cli.php` |
| **Datos para el navegador**: todas las tiendas en forma resumida en `uploads/lachinata-oleotecas/oleotecas.<hash>.json` (`.htaccess` con un año de caché y CORS para los dominios cliente), reescrito al final de la petición que cambia una tienda, una zona, un servicio o un ajuste, y al cambiar de versión. `wp lachinata oleotecas json` lo reescribe a mano | `save_post_oleoteca`, metadatos, términos, `updated_option`, `shutdown` | `Data.php`, `Source.php` |
| **Plantillas** del buscador, la zona y la ficha con el HTML de `StoreSearch`, `StoreCard`, `StoreMap`, `StoreHours`, `OpenStatus` y `SocialLinks`, servidas con la utilidad `Templates` del núcleo y sustituibles por el tema (`lachinata/oleotecas/*.php`). Sin datos, sin sección | `template_include` | `Pages.php`, `Html.php`, `templates/oleotecas/` |
| **Script del buscador** (7,5 KB comprimido): «abierta ahora» con `Intl` y la zona horaria de cada tienda (los especiales mandan; «cierra pronto» a 60 minutos), hoy en el horario, «Cerca de mí» (la ubicación solo al pulsar y nunca sale del navegador), búsqueda al enviar (primero nuestros datos; luego el geocodificador del servidor), nunca cero resultados, filtros, orden por distancia, «Ver más», Mapas de Apple en Apple y Google Maps en el resto, el correo fuera del HTML | | `src/finder.js`, `src/open.js`, `src/geo.js`, `src/render.js` |
| **Mapa a demanda**: Leaflet 1.9 y su agrupación, empaquetados en el plugin, se piden solo al pulsar «Ver en el mapa» (en móvil, botón secundario a todo el ancho bajo el buscador; en escritorio, el del panel del mapa en reposo; nunca flota sobre la lista). Teselas, clave y atribución de los ajustes (CARTO Positron, que pide clave desde el 23/09/2026); si la URL pide clave y falta, no se ofrece el mapa. Nunca abre en vista mundial: encuadra la lista (por defecto, el país con más tiendas; con «Cerca de mí» o una búsqueda, las más cercanas; con una tienda elegida, esa a zoom 16), con un zoom mínimo que llena el panel de teselas, y lleva «Centrar en mi ubicación» bajo + y −. Móvil: pantalla completa con la tarjeta en hoja inferior (foco atrapado, Escape). Escritorio: junto a la lista, chincheta ↔ tarjeta; pedido una vez, se queda cargado en la sesión | `import()` | `src/map.js`, `Tiles.php` |
| **Bloque** `lachinata/oleotecas`: el mismo buscador en cualquier página (el antiguo 6d de la home) | `init` | `Block.php`, `blocks/finder/`, `src/block.js` |
| **SEO**: títulos y descripciones de 09; `Store` (brand, address, geo, telephone, openingHoursSpecification, specialOpeningHoursSpecification, image, url = web propia si la hay, sameAs = redes; sin `parentOrganization`), `ItemList` en buscador y zona, `FAQPage` en la zona, `BreadcrumbList`; Open Graph con la primera foto o la imagen por defecto. Con Rank Math o Yoast, su título, descripción e imagen toman los nuestros y su schema sale de estas páginas. Sitemaps: solo las zonas con página | `wp_head`, filtros de WordPress, Rank Math y Yoast | `Seo.php` |
| **Migas y «Volver» del tema**: Inicio › Oleotecas › País › Zona › tienda; la ficha es vista secundaria y «Volver» va a su zona | `lachinata/breadcrumb/items`, `lachinata/view/secondary`, `lachinata/view/back_url` | `Pages.php` |
| **Medición** por el bus de `tracking` en el navegador (`window.lachinata.track`): `lc_store_search` (término o «location», resultados), `lc_store_view`, `lc_store_directions`, `lc_store_call`, `lc_store_whatsapp`, `lc_store_web` y `lc_store_map`, con el slug y la zona de la tienda; nunca la ubicación | | `src/finder.js` |
| **Privacidad**: el proveedor de las teselas se declara a `tracking` como servicio necesario sin cookies, para la política | `lachinata/tracking/services` | `Privacy.php` |
| **Salud**: tiendas publicadas, clave de teselas que falta (credencial), sin coordenadas, sin horario, el geocodificador fallando, el JSON desactualizado, el tipo registrado ya por otro plugin y el modo cliente pendiente | | `OleotecasModule::health()` |

## Paso a producción

`docs/despliegue-oleotecas.md`: en staging, simular la migración con el mapa de lachinata.es, migrar, comprobar las 39 URL y el schema en la prueba de resultados enriquecidos; desactivar el plugin «Oleotecas» en el mismo paso que se enciende el módulo; retirar la página de Elementor y, cuando Alberto lo confirme, los campos de ACF.

## Depende de

Ningún módulo. Necesita WooCommerce 10 (países, prefijos telefónicos, productos de los favoritos). Del núcleo usa `Templates`, `Settings`, `Hooks`, `Company` (nombre comercial para `{brand}` y la marca del schema) y la pantalla de ajustes. Con `tracking`, mide y declara el proveedor del mapa; sin él, nada de eso ocurre y el buscador funciona igual. El tema aporta las migas, «Volver», el sprite de iconos y el layout (`theme.css`); con otro tema, las plantillas funcionan sin ese layout.

## Hooks que escucha

- Núcleo de WordPress: `init` (tipo, taxonomías, campos, script y bloque), `template_redirect` (301 del archivo viejo y zonas sin página), `template_include`, `body_class`, `wp_head`, `wp_footer`, `document_title_parts`, `rest_api_init`, `rest_pre_serve_request` (CORS solo para los dominios cliente), `wp_sitemaps_taxonomies_query_args`, `enqueue_block_editor_assets`.
- Cambios de datos: `save_post_oleoteca`, `added_post_meta`, `updated_post_meta`, `deleted_post`, `trashed_post`, `created_`/`edited_`/`delete_` de las dos taxonomías, `updated_option`, `shutdown`; `lc_oleoteca_zona_edit_form_fields` y `edited_lc_oleoteca_zona`.
- SEO de terceros: `rank_math/frontend/title`, `rank_math/frontend/description`, `rank_math/opengraph/facebook/image`, `rank_math/json_ld`, `rank_math/sitemap/entry`, `wpseo_title`, `wpseo_metadesc`, `wpseo_opengraph_image`, `wpseo_json_ld_output`.
- Del tema: `lachinata/breadcrumb/items`, `lachinata/view/secondary`, `lachinata/view/back_url`, `lachinata/view/editorial`, `lachinata/app_bar/section` (OLEOTECAS marcado en la AppBar en todas sus páginas). De `tracking`: `lachinata/tracking/services`. Del núcleo: `lachinata/core/admin_tabs`.

## Hooks que emite

- `lachinata/oleotecas/geocoder` (filtro): el adaptador del geocodificador (interfaz `Geocoder`). Catalogado en `plugin/HOOKS.md`.
- En el navegador, el evento `lachinata:stores:list` en el elemento del buscador cada vez que cambia la lista (lo usa el mapa).

## Datos que guarda

- Metadatos de cada `oleoteca`: `_lc_oleotecas_name`, `_address`, `_lat`, `_lng`, `_timezone`, `_phone`, `_whatsapp`, `_email`, `_web`, `_social`, `_hours`, `_special`, `_photos`, `_text`, `_favorites` y `_migrated` (fecha y versión de la migración). Los campos viejos de ACF se quedan como estaban.
- Metadatos de cada zona: `_lc_oleotecas_text`, `_lc_oleotecas_faq`, `_lc_oleotecas_group`.
- Opciones `lachinata_oleotecas_*`: ajustes, el JSON actual (`_json`: archivo, hash, fecha, número y versión), el último fallo del geocodificador (`_geocoder_failure`) y el registro de huecos (`_gaps`). Transitorios de la caché del geocodificador y del límite por visitante (hash de la IP, nunca la IP).
- Archivos en `uploads/lachinata-oleotecas/`: el JSON actual, el anterior y el `.htaccess`.
- Las tiendas son contenido (entradas): «Borrar datos» borra los ajustes y los metadatos de las zonas, nunca las tiendas ni sus campos.

## REST y API para Odoo

- `GET /lachinata/v1/oleotecas` (las tiendas en forma resumida; con `?v=<hash>`, un año de caché; CORS para los dominios cliente).
- `GET /lachinata/v1/oleotecas/<slug>` (una tienda completa; favoritos con ID y SKU; nunca el correo).
- `GET /lachinata/v1/oleotecas/geocode?q=&country=` (coordenadas desde el servidor; 20 búsquedas cada 10 minutos por visitante, sin límite para quien edita).
- Los campos, también en `GET`/`POST /wp/v2/oleoteca/<id>` (`meta`), para quien puede editar.

Nada en el objeto `lachinata` de los pedidos.

## Ajustes y exportación

| Ajuste | Por defecto | En el JSON |
| --- | --- | --- |
| Cómo se llama cada tienda (`noun`, `noun_plural`) | «tienda», «tiendas» | sí |
| Nombre largo (`store_title`, con `{name}` y `{brand}`) | el nombre corto | sí |
| Título y entradilla del buscador (`archive_title`, `archive_lead` con `{stores}` y `{countries}`) | «Tiendas {marca}», «39 tiendas en 9 países.» | sí |
| URL de cada tienda y del buscador (`slug_single`, `slug_archive`) | `oleoteca`, `oleotecas` | sí |
| Distancia de «cerca» (`near_km`) | 150 | sí |
| Teselas, atribución, proveedores, empresa y su política (`tiles_url` con `{key}`, `tiles_attribution`, `tiles_provider`, `tiles_company`, `tiles_privacy_url`) | CARTO Positron, «© OpenStreetMap · © CARTO» | sí |
| Clave de las teselas (`tiles_key`) | vacía: sin mapa con CARTO | no (credencial de cada sitio) |
| Geocodificador (`geocoder_url`) y su contacto (`geocoder_contact`) | Nominatim, vacío | la URL sí; el contacto no |
| Texto de inicio de WhatsApp (`whatsapp_text`, con `{site}`) | vacío | sí |
| Imagen para compartir (`og_image`) | ninguna | no (ID de este sitio) |
| Bloque de franquicias (`franchise_*`) | vacío: no sale | sí |
| Dominios cliente (`client_domains`) | ninguno | no |
| Modo (`mode`), maestro (`master_url`) y token de socios (`partner_token`) | maestro | no (9b) |

## Qué pasa al apagarlo

El tipo de contenido deja de registrarse: las fichas, el buscador y las zonas dan 404, y las tiendas y sus campos se conservan. Al encenderlo vuelve todo como estaba. El JSON se queda en uploads con su última versión. Para no perder las URL, no se apaga en un sitio con tiendas publicadas sin otra cosa que registre el tipo.

## Pruebas

- `tests/HoursParserTest.php`: cada formato de horario de la exportación, los dos campos de una hora como horario continuo, el cero de más («17:300h»), lo que no se entiende (error, nunca una suposición), todos los campos reales del fixture, franjas, especiales, resumen y `openingHoursSpecification`.
- `tests/MigrationTest.php`: conversión de una tienda (dirección, coordenadas, teléfono, correo, zona), zonas horarias (Canarias, Busan, Puebla, Noruega), correcciones del mapa (nombre, ciudad, WhatsApp de Gijón con aviso), informe (sin horario, contenido viejo, la corrección de «17:300h»), calles, teléfonos de varios países, la migración completa (solo publicadas, zonas con su grupo, campos viejos intactos, idempotente y `--force` igual) y la simulación sin escrituras.
- `tests/DataTest.php`: qué zonas tienen página, el documento del buscador y su archivo con hash (se desactualiza al cambiar una tienda), CORS en REST y en `.htaccess`, la ficha completa sin correo y con los favoritos por SKU, el geocodificador con un doble (caché y límite 429) y el `Store` de schema.org.
- `tests/js/open.test.mjs` y `tests/js/geo.test.mjs` (`npm run test:js`, el runner de Node): «abierta ahora» en Canarias, Madrid, Busan y Puebla, «cierra pronto», especiales, vacaciones, cambio de hora de marzo y octubre; distancias, orden y búsqueda en nuestros datos.
- `tests/e2e/oleotecas.spec.mjs` (perfiles `es` y `all`): lista, estado y ninguna petición a Leaflet ni a las teselas antes de pulsar el mapa; «Cerca de mí» con ubicación simulada que no sale del navegador; búsqueda sin oleotecas que ofrece la más cercana; búsqueda sin JavaScript; zona con grupos, «abiertas ahora» y datos estructurados; ficha con datos y sin datos; mapa de la ficha a demanda; las 39 URL tras migrar y el 301 de `/oleoteca/`.

## Huecos conocidos

- Modo cliente y API de socios: 9b (0.12.1). Los perfiles `canarias` y `cz` tienen el módulo pendiente hasta entonces.
- CARTO es gratis para uso comercial hasta 1 millón de peticiones de teselas al mes; si se supera, otro proveedor es cambiar los ajustes del mapa. En wp-env, el mu-plugin de desarrollo sirve teselas de prueba locales si no hay clave guardada o con la constante `LACHINATA_DEV_FAKE_TILES` (la CI la activa en `.github/actions/wp-env`); con clave y sin la constante, las del proveedor.
- La galería de la ficha es un carrusel con desplazamiento, sin ampliación a pantalla completa.
- Los datos de cada ficha deben coincidir con su perfil de Google Business Profile: la salud solo lo recuerda.
- Nginx no lee el `.htaccess` del JSON: en ese servidor, las cabeceras de caché y CORS del archivo van en su configuración (la copia REST las manda siempre).
