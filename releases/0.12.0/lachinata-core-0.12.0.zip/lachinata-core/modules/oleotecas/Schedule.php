<?php
/**
 * Opening hours of a store.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

defined( 'ABSPATH' ) || exit;

/**
 * The week (each day: no slots = closed, one slot = continuous, two = split) and the
 * special days (a date or a range, closed or with their own slots, and a note), in the
 * store's local time. The same data feeds StoreHours, OpenStatus (computed in the browser
 * with the store's time zone) and the opening hours of the schema. Slots are «HH:MM» in
 * 24 h; a slot may end at 24:00.
 *
 * @phpstan-type Slot array{0: string, 1: string}
 * @phpstan-type Week array<string, list<Slot>>
 * @phpstan-type Special array{from: string, to: string, slots: list<Slot>, note: string}
 */
final class Schedule {

	/**
	 * Days, Monday first, as the keys of the week.
	 */
	public const DAYS = array( 'mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun' );

	/**
	 * Day names of schema.org.
	 */
	private const SCHEMA_DAYS = array(
		'mon' => 'Monday',
		'tue' => 'Tuesday',
		'wed' => 'Wednesday',
		'thu' => 'Thursday',
		'fri' => 'Friday',
		'sat' => 'Saturday',
		'sun' => 'Sunday',
	);

	/**
	 * Most slots in a day.
	 */
	public const MAX_SLOTS = 2;

	/**
	 * A time as «HH:MM», or null.
	 *
	 * @param mixed $value Value.
	 * @param bool  $end   Whether it closes a slot (24:00 allowed).
	 */
	public static function time( $value, bool $end = false ): ?string {
		if ( ! is_string( $value ) || ! preg_match( '/^(\d{1,2}):(\d{2})$/', trim( $value ), $match ) ) {
			return null;
		}
		$hours   = (int) $match[1];
		$minutes = (int) $match[2];
		if ( $minutes > 59 || $hours > 24 || ( 24 === $hours && ( ! $end || $minutes > 0 ) ) ) {
			return null;
		}
		return sprintf( '%02d:%02d', $hours, $minutes );
	}

	/**
	 * Valid slots of a day: well formed, opening before closing, sorted, not overlapping,
	 * at most two. Null when something is wrong (so nothing is half saved).
	 *
	 * @param mixed $slots Slots.
	 * @return list<Slot>|null
	 */
	public static function slots( $slots ): ?array {
		$out = array();
		foreach ( is_array( $slots ) ? $slots : array() as $slot ) {
			if ( ! is_array( $slot ) ) {
				return null;
			}
			$slot = array_values( $slot );
			$from = self::time( $slot[0] ?? null );
			$to   = self::time( $slot[1] ?? null, true );
			if ( null === $from || null === $to || $from >= $to ) {
				return null;
			}
			$out[] = array( $from, $to );
		}
		usort( $out, static fn( array $a, array $b ): int => strcmp( $a[0], $b[0] ) );
		if ( count( $out ) > self::MAX_SLOTS ) {
			return null;
		}
		for ( $i = 1, $n = count( $out ); $i < $n; $i++ ) {
			if ( $out[ $i ][0] < $out[ $i - 1 ][1] ) {
				return null;
			}
		}
		return $out;
	}

	/**
	 * The week as it is saved: the seven days, each one with its valid slots (a day with
	 * invalid slots is saved closed; the editor validates before).
	 *
	 * @param mixed $value Value.
	 * @return Week
	 */
	public static function sanitize_week( $value ): array {
		$value = is_array( $value ) ? $value : array();
		$week  = array();
		foreach ( self::DAYS as $day ) {
			$week[ $day ] = self::slots( $value[ $day ] ?? array() ) ?? array();
		}
		return $week;
	}

	/**
	 * Problems of a week, by day, for the editor and the partners' API.
	 *
	 * @param mixed $value Value.
	 * @return array<string, string>
	 */
	public static function week_errors( $value ): array {
		$errors = array();
		$value  = is_array( $value ) ? $value : array();
		foreach ( self::DAYS as $day ) {
			if ( null === self::slots( $value[ $day ] ?? array() ) ) {
				$errors[ $day ] = __( 'Revisa las franjas: hora de apertura antes que la de cierre, sin solaparse y como mucho dos.', 'lachinata-core' );
			}
		}
		return $errors;
	}

	/**
	 * A date as «Y-m-d», or null.
	 *
	 * @param mixed $value Value.
	 */
	public static function date( $value ): ?string {
		if ( ! is_string( $value ) || ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', trim( $value ), $match ) ) {
			return null;
		}
		return checkdate( (int) $match[2], (int) $match[3], (int) $match[1] ) ? trim( $value ) : null;
	}

	/**
	 * Special days as they are saved: valid ones, sorted by start. A closure for holidays is
	 * a range without slots and with its note.
	 *
	 * @param mixed $value Value.
	 * @return list<Special>
	 */
	public static function sanitize_specials( $value ): array {
		$out = array();
		foreach ( is_array( $value ) ? $value : array() as $item ) {
			$special = is_array( $item ) ? self::special( $item ) : null;
			if ( null !== $special ) {
				$out[] = $special;
			}
		}
		usort( $out, static fn( array $a, array $b ): int => strcmp( $a['from'], $b['from'] ) );
		return $out;
	}

	/**
	 * One special day or range, or null when it is not valid.
	 *
	 * @param array<mixed> $item Raw item.
	 * @return Special|null
	 */
	public static function special( array $item ): ?array {
		$from  = self::date( $item['from'] ?? null );
		$to    = self::date( $item['to'] ?? null ) ?? $from;
		$slots = self::slots( $item['slots'] ?? array() );
		if ( null === $from || null === $to || $to < $from || null === $slots ) {
			return null;
		}
		return array(
			'from'  => $from,
			'to'    => $to,
			'slots' => $slots,
			'note'  => Fields::text_line( $item['note'] ?? '' ),
		);
	}

	/**
	 * Whether the week has at least one open day.
	 *
	 * @param array<string, mixed> $week Week.
	 * @phpstan-param Week $week
	 */
	public static function has_hours( array $week ): bool {
		foreach ( self::DAYS as $day ) {
			if ( ! empty( $week[ $day ] ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Special days that have not ended by a date (the store's today), at most `$limit`.
	 *
	 * @param array<int, mixed> $specials Specials.
	 * @phpstan-param list<Special> $specials
	 * @param string            $today    Y-m-d.
	 * @param int               $limit    Most.
	 * @return list<Special>
	 */
	public static function upcoming( array $specials, string $today, int $limit = 4 ): array {
		return array_slice( array_values( array_filter( $specials, static fn( array $special ): bool => $special['to'] >= $today ) ), 0, $limit );
	}

	/**
	 * Slots as people read them: «10:00–14:00 y 17:00–20:30», or «Cerrado».
	 *
	 * @param array<int, mixed> $slots Slots.
	 * @phpstan-param list<Slot> $slots
	 */
	public static function slots_text( array $slots ): string {
		if ( ! $slots ) {
			return __( 'Cerrado', 'lachinata-core' );
		}
		$parts = array_map( static fn( array $slot ): string => $slot[0] . '–' . $slot[1], $slots );
		return 1 === count( $parts )
			? $parts[0]
			/* translators: 1: morning slot, 2: afternoon slot («10:00–14:00 y 17:00–20:30»). */
			: sprintf( __( '%1$s y %2$s', 'lachinata-core' ), $parts[0], $parts[1] );
	}

	/**
	 * Short summary of the week for the description of the page: the hours of most days,
	 * with the days they apply to («De lunes a sábado, 10:00–14:00 y 17:00–20:30»). Not the
	 * hours of today: the page comes from the cache.
	 *
	 * @param array<string, mixed> $week Week.
	 * @phpstan-param Week $week
	 */
	public static function summary( array $week ): string {
		$groups = self::groups( $week );
		if ( ! $groups ) {
			return '';
		}
		usort( $groups, static fn( array $a, array $b ): int => count( $b['days'] ) <=> count( $a['days'] ) );
		$main = $groups[0];
		return sprintf(
			/* translators: 1: days («De lunes a sábado»), 2: hours. */
			__( '%1$s, %2$s', 'lachinata-core' ),
			self::days_text( $main['days'] ),
			self::slots_text( $main['slots'] )
		);
	}

	/**
	 * Days that share the same slots, in week order. Closed days are left out.
	 *
	 * @param array<string, mixed> $week Week.
	 * @phpstan-param Week $week
	 * @return list<array{days: list<string>, slots: list<Slot>}>
	 */
	public static function groups( array $week ): array {
		$groups = array();
		foreach ( self::DAYS as $day ) {
			$slots = $week[ $day ] ?? array();
			if ( ! $slots ) {
				continue;
			}
			$key = wp_json_encode( $slots );
			if ( ! isset( $groups[ $key ] ) ) {
				$groups[ $key ] = array(
					'days'  => array(),
					'slots' => $slots,
				);
			}
			$groups[ $key ]['days'][] = $day;
		}
		return array_values( $groups );
	}

	/**
	 * Days as text: «De lunes a viernes» for a run, «Lunes, miércoles y viernes» otherwise.
	 *
	 * @param string[] $days Day keys, in week order.
	 * @phpstan-param list<string> $days
	 */
	public static function days_text( array $days ): string {
		$names = self::day_names();
		$index = array_map( static fn( string $day ): int => (int) array_search( $day, self::DAYS, true ), $days );
		if ( 1 === count( $days ) ) {
			return $names[ $days[0] ];
		}
		if ( 7 === count( $days ) ) {
			return __( 'Todos los días', 'lachinata-core' );
		}
		if ( count( $index ) - 1 === end( $index ) - $index[0] ) {
			/* translators: 1: first day, 2: last day (lower case). */
			return sprintf( __( 'De %1$s a %2$s', 'lachinata-core' ), mb_strtolower( $names[ $days[0] ] ), mb_strtolower( $names[ end( $days ) ] ) );
		}
		$list = array_map( static fn( string $day ): string => mb_strtolower( $names[ $day ] ), $days );
		$last = array_pop( $list );
		/* translators: 1: days separated by commas, 2: last day. */
		return ucfirst( sprintf( __( '%1$s y %2$s', 'lachinata-core' ), implode( ', ', $list ), $last ) );
	}

	/**
	 * Names of the days, Monday first.
	 *
	 * @return array<string, string>
	 */
	public static function day_names(): array {
		return array(
			'mon' => __( 'Lunes', 'lachinata-core' ),
			'tue' => __( 'Martes', 'lachinata-core' ),
			'wed' => __( 'Miércoles', 'lachinata-core' ),
			'thu' => __( 'Jueves', 'lachinata-core' ),
			'fri' => __( 'Viernes', 'lachinata-core' ),
			'sat' => __( 'Sábado', 'lachinata-core' ),
			'sun' => __( 'Domingo', 'lachinata-core' ),
		);
	}

	/**
	 * `openingHoursSpecification` of schema.org: one entry per slot and group of days.
	 *
	 * @param array<string, mixed> $week Week.
	 * @phpstan-param Week $week
	 * @return list<array<string, mixed>>
	 */
	public static function schema( array $week ): array {
		$out = array();
		foreach ( self::groups( $week ) as $group ) {
			foreach ( $group['slots'] as $slot ) {
				$out[] = array(
					'@type'     => 'OpeningHoursSpecification',
					'dayOfWeek' => array_map( static fn( string $day ): string => self::SCHEMA_DAYS[ $day ], $group['days'] ),
					'opens'     => $slot[0],
					'closes'    => '24:00' === $slot[1] ? '23:59' : $slot[1],
				);
			}
		}
		return $out;
	}

	/**
	 * `specialOpeningHoursSpecification`: closed days open and close at 00:00.
	 *
	 * @param array<int, mixed> $specials Specials that have not ended.
	 * @phpstan-param list<Special> $specials
	 * @return list<array<string, mixed>>
	 */
	public static function schema_specials( array $specials ): array {
		$out = array();
		foreach ( $specials as $special ) {
			$slots = $special['slots'] ? $special['slots'] : array( array( '00:00', '00:00' ) );
			foreach ( $slots as $slot ) {
				$out[] = array(
					'@type'        => 'OpeningHoursSpecification',
					'validFrom'    => $special['from'],
					'validThrough' => $special['to'],
					'opens'        => $slot[0],
					'closes'       => '24:00' === $slot[1] ? '23:59' : $slot[1],
				);
			}
		}
		return $out;
	}
}
