<?php
/**
 * Titles, descriptions, structured data, Open Graph and sitemaps of the module's pages.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

use LaChinata\Core\Company;
use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * Each store is a `Store` of schema.org with the brand, the address, the coordinates, the
 * phone, the weekly and the special hours, the photos, its own web (or its page) and its
 * profiles; a franchise, so without `parentOrganization`. The finder and the zones carry an
 * `ItemList` of the stores, the zones their `FAQPage`, and all of them their breadcrumb.
 * With Rank Math or Yoast active, their title and description take ours and their schema
 * is left out of these pages (one set of entities); without them, the module prints the
 * description and Open Graph itself.
 *
 * @phpstan-import-type StoreData from Store
 * @phpstan-import-type Zone from Directory
 */
final class Seo {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'document_title_parts', array( self::class, 'title_parts' ), 20 );
		Hooks::add_filter( 'rank_math/frontend/title', array( self::class, 'plugin_title' ), 20 );
		Hooks::add_filter( 'wpseo_title', array( self::class, 'plugin_title' ), 20 );
		Hooks::add_filter( 'rank_math/frontend/description', array( self::class, 'plugin_description' ), 20 );
		Hooks::add_filter( 'wpseo_metadesc', array( self::class, 'plugin_description' ), 20 );
		Hooks::add_filter( 'rank_math/opengraph/facebook/image', array( self::class, 'plugin_image' ), 20 );
		Hooks::add_filter( 'wpseo_opengraph_image', array( self::class, 'plugin_image' ), 20 );
		Hooks::add_filter( 'rank_math/json_ld', array( self::class, 'rank_math_schema' ), 99 );
		Hooks::add_filter( 'wpseo_json_ld_output', array( self::class, 'yoast_schema' ), 99 );
		Hooks::add_action( 'wp_head', array( self::class, 'head' ), 5 );
		Hooks::add_filter( 'wp_sitemaps_taxonomies_query_args', array( self::class, 'sitemap_terms' ), 10, 2 );
		Hooks::add_filter( 'rank_math/sitemap/entry', array( self::class, 'rank_math_entry' ), 10, 3 );
	}

	/**
	 * Whether Rank Math or Yoast prints the head of the page.
	 */
	public static function seo_plugin(): bool {
		return defined( 'RANK_MATH_VERSION' ) || defined( 'WPSEO_VERSION' );
	}

	/**
	 * Title of the current page of the module, or ''.
	 */
	public static function title(): string {
		if ( is_singular( Model::POST_TYPE ) ) {
			$store = Directory::store( (int) get_queried_object_id() );
			/* translators: %s: long name of the store. */
			return null === $store ? '' : sprintf( __( '%s: horario, dirección y teléfono', 'lachinata-core' ), $store['title'] );
		}
		$zone = self::zone();
		if ( null !== $zone ) {
			return sprintf(
				/* translators: 1: «Oleotecas La Chinata en Madrid», 2: «11 oleotecas». */
				__( '%1$s: %2$s, horarios y direcciones', 'lachinata-core' ),
				Texts::zone_title( $zone['name'] ),
				Texts::count( count( $zone['stores'] ) )
			);
		}
		if ( is_post_type_archive( Model::POST_TYPE ) ) {
			return sprintf(
				/* translators: 1: title of the finder, 2: «39 oleotecas». */
				__( '%1$s: %2$s, horarios y direcciones', 'lachinata-core' ),
				Texts::archive_title(),
				Texts::count( count( Directory::stores() ) )
			);
		}
		return '';
	}

	/**
	 * Description of the current page, or ''.
	 */
	public static function description(): string {
		if ( is_singular( Model::POST_TYPE ) ) {
			$store = Directory::store( (int) get_queried_object_id() );
			if ( null === $store ) {
				return '';
			}
			$parts = array( $store['line'] );
			$hours = Schedule::summary( $store['hours'] );
			if ( '' !== $hours ) {
				$parts[] = $hours;
			}
			if ( $store['services'] ) {
				$parts[] = implode( ', ', array_column( $store['services'], 'name' ) );
			}
			return implode( '. ', array_filter( $parts ) ) . '.';
		}
		$zone = self::zone();
		if ( null !== $zone ) {
			if ( '' !== $zone['text'] ) {
				return wp_trim_words( $zone['text'], 30, '…' );
			}
			$names = array();
			foreach ( $zone['stores'] as $id ) {
				$store = Directory::store( $id );
				if ( null !== $store ) {
					$names[] = $store['name'];
				}
			}
			return Texts::zone_title( $zone['name'] ) . ': ' . implode( ', ', $names ) . '.';
		}
		if ( is_post_type_archive( Model::POST_TYPE ) ) {
			return Texts::archive_lead( count( Directory::stores() ), Directory::country_count() );
		}
		return '';
	}

	/**
	 * The zone of the current page, or null.
	 *
	 * @return Zone|null
	 */
	private static function zone(): ?array {
		if ( ! is_tax( Model::ZONE ) ) {
			return null;
		}
		$term = get_queried_object();
		return $term instanceof \WP_Term ? Directory::zone( (int) $term->term_id ) : null;
	}

	/**
	 * Title of WordPress (without an SEO plugin).
	 *
	 * @param mixed $parts Parts.
	 * @return mixed
	 */
	public static function title_parts( $parts ) {
		$title = self::title();
		if ( '' !== $title && is_array( $parts ) ) {
			$parts['title'] = $title;
		}
		return $parts;
	}

	/**
	 * Title of Rank Math or Yoast: ours, with the site's name after the separator they use.
	 *
	 * @param mixed $title Their title.
	 * @return mixed
	 */
	public static function plugin_title( $title ) {
		$ours = self::title();
		return '' === $ours ? $title : $ours . ' | ' . ( class_exists( Company::class ) ? Company::trade_name() : get_bloginfo( 'name' ) );
	}

	/**
	 * Description of Rank Math or Yoast.
	 *
	 * @param mixed $description Theirs.
	 * @return mixed
	 */
	public static function plugin_description( $description ) {
		$ours = self::description();
		return '' === $ours ? $description : $ours;
	}

	/**
	 * Image to share: the first photo of the store, or the default image of the settings.
	 */
	public static function image(): string {
		$id = 0;
		if ( is_singular( Model::POST_TYPE ) ) {
			$store = Directory::store( (int) get_queried_object_id() );
			$id    = null !== $store && $store['photos'] ? $store['photos'][0] : 0;
		}
		if ( ! $id && ( Pages::is_view() ) ) {
			$id = (int) OleotecasModule::setting( 'og_image' );
		}
		$url = $id ? wp_get_attachment_image_url( $id, 'large' ) : '';
		return is_string( $url ) ? $url : '';
	}

	/**
	 * Image of Rank Math or Yoast.
	 *
	 * @param mixed $image Theirs.
	 * @return mixed
	 */
	public static function plugin_image( $image ) {
		$ours = Pages::is_view() ? self::image() : '';
		return '' === $ours ? $image : $ours;
	}

	/**
	 * Rank Math's schema is left out of these pages.
	 *
	 * @param mixed $data Their graph.
	 * @return mixed
	 */
	public static function rank_math_schema( $data ) {
		return Pages::is_view() ? array() : $data;
	}

	/**
	 * Yoast's schema is left out of these pages.
	 *
	 * @param mixed $output Their output.
	 * @return mixed
	 */
	public static function yoast_schema( $output ) {
		return Pages::is_view() ? false : $output;
	}

	/**
	 * Prints the structured data and, without an SEO plugin, the description and Open Graph.
	 */
	public static function head(): void {
		if ( ! Pages::is_view() ) {
			return;
		}
		if ( ! self::seo_plugin() ) {
			$description = self::description();
			$title       = self::title();
			$image       = self::image();
			$url         = self::canonical();
			if ( '' !== $description ) {
				printf( '<meta name="description" content="%s">' . "\n", esc_attr( $description ) );
			}
			printf( '<meta property="og:type" content="%s">' . "\n", esc_attr( is_singular() ? 'place' : 'website' ) );
			printf( '<meta property="og:title" content="%s">' . "\n", esc_attr( $title ) );
			if ( '' !== $description ) {
				printf( '<meta property="og:description" content="%s">' . "\n", esc_attr( $description ) );
			}
			printf( '<meta property="og:url" content="%s">' . "\n", esc_url( $url ) );
			if ( '' !== $image ) {
				printf( '<meta property="og:image" content="%s">' . "\n", esc_url( $image ) );
				echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
			}
		}
		$graph = self::graph();
		if ( $graph ) {
			printf(
				'<script type="application/ld+json">%s</script>' . "\n",
				wp_json_encode(
					array(
						'@context' => 'https://schema.org',
						'@graph'   => $graph,
					),
					JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG
				)
			);
		}
	}

	/**
	 * URL of the current page of the module.
	 */
	public static function canonical(): string {
		if ( is_singular( Model::POST_TYPE ) ) {
			return (string) get_permalink( get_queried_object_id() );
		}
		$zone = self::zone();
		if ( null !== $zone ) {
			return $zone['url'];
		}
		return (string) get_post_type_archive_link( Model::POST_TYPE );
	}

	/**
	 * The entities of the current page.
	 *
	 * @return list<array<string, mixed>>
	 */
	public static function graph(): array {
		$graph = array();
		if ( is_singular( Model::POST_TYPE ) ) {
			$store = Directory::store( (int) get_queried_object_id() );
			if ( null !== $store ) {
				$graph[] = self::store( $store );
			}
		} elseif ( is_tax( Model::ZONE ) || is_post_type_archive( Model::POST_TYPE ) ) {
			$zone    = self::zone();
			$ids     = null === $zone ? array_keys( Directory::stores() ) : $zone['stores'];
			$graph[] = self::item_list( $ids, self::canonical() );
			if ( null !== $zone && $zone['faq'] ) {
				$graph[] = self::faq( $zone );
			}
		}
		$crumbs = self::breadcrumb();
		if ( $crumbs ) {
			$graph[] = $crumbs;
		}
		return $graph;
	}

	/**
	 * `Store` of one store.
	 *
	 * @param array<string, mixed> $store Store.
	 * @phpstan-param StoreData $store
	 * @return array<string, mixed>
	 */
	public static function store( array $store ): array {
		$brand = class_exists( Company::class ) ? Company::trade_name() : get_bloginfo( 'name' );
		$data  = array(
			'@type'   => 'Store',
			'@id'     => $store['url'] . '#store',
			'name'    => $store['title'],
			'brand'   => array(
				'@type' => 'Brand',
				'name'  => $brand,
			),
			'address' => array_filter(
				array(
					'@type'           => 'PostalAddress',
					'streetAddress'   => $store['street'],
					'postalCode'      => $store['postcode'],
					'addressLocality' => $store['city'],
					'addressRegion'   => $store['region'],
					'addressCountry'  => $store['country'],
				)
			),
			'url'     => '' !== $store['web']['url'] ? $store['web']['url'] : $store['url'],
		);
		if ( '' !== $store['web']['url'] ) {
			$data['mainEntityOfPage'] = $store['url'];
		}
		if ( null !== $store['lat'] && null !== $store['lng'] ) {
			$data['geo'] = array(
				'@type'     => 'GeoCoordinates',
				'latitude'  => $store['lat'],
				'longitude' => $store['lng'],
			);
		}
		if ( '' !== $store['phone'] ) {
			$data['telephone'] = $store['phone'];
		}
		$hours = Schedule::schema( $store['hours'] );
		if ( $hours ) {
			$data['openingHoursSpecification'] = $hours;
		}
		$specials = Schedule::schema_specials( Schedule::upcoming( $store['specials'], gmdate( 'Y-m-d' ), 50 ) );
		if ( $specials ) {
			$data['specialOpeningHoursSpecification'] = $specials;
		}
		$images = array_values( array_filter( array_map( static fn( int $id ) => wp_get_attachment_image_url( $id, 'large' ), $store['photos'] ) ) );
		if ( $images ) {
			$data['image'] = $images;
		}
		$same = array_column( $store['social'], 'url' );
		if ( $same ) {
			$data['sameAs'] = $same;
		}
		return $data;
	}

	/**
	 * `ItemList` of stores.
	 *
	 * @param int[]  $ids Store ids.
	 * @phpstan-param list<int> $ids
	 * @param string $url Page.
	 * @return array<string, mixed>
	 */
	public static function item_list( array $ids, string $url ): array {
		$items    = array();
		$position = 0;
		foreach ( $ids as $id ) {
			$store = Directory::store( $id );
			if ( null === $store ) {
				continue;
			}
			$items[] = array(
				'@type'    => 'ListItem',
				'position' => ++$position,
				'url'      => $store['url'],
				'name'     => $store['title'],
			);
		}
		return array(
			'@type'           => 'ItemList',
			'@id'             => $url . '#list',
			'numberOfItems'   => count( $items ),
			'itemListElement' => $items,
		);
	}

	/**
	 * `FAQPage` of a zone.
	 *
	 * @param array<string, mixed> $zone Zone.
	 * @phpstan-param Zone $zone
	 * @return array<string, mixed>
	 */
	public static function faq( array $zone ): array {
		return array(
			'@type'      => 'FAQPage',
			'@id'        => $zone['url'] . '#faq',
			'mainEntity' => array_map(
				static fn( array $item ): array => array(
					'@type'          => 'Question',
					'name'           => $item['question'],
					'acceptedAnswer' => array(
						'@type' => 'Answer',
						'text'  => $item['answer'],
					),
				),
				$zone['faq']
			),
		);
	}

	/**
	 * `BreadcrumbList` from the theme's breadcrumb of the module (Pages::breadcrumb).
	 *
	 * @return array<string, mixed>|null
	 */
	public static function breadcrumb(): ?array {
		$items = Pages::breadcrumb( array( array( __( 'Inicio', 'lachinata-core' ), home_url( '/' ) ) ) );
		if ( ! is_array( $items ) || count( $items ) < 2 ) {
			return null;
		}
		$list     = array();
		$position = 0;
		$last     = count( $items ) - 1;
		foreach ( $items as $index => $item ) {
			$url = $index === $last ? self::canonical() : (string) $item[1];
			if ( '' === $url ) {
				continue;
			}
			$list[] = array(
				'@type'    => 'ListItem',
				'position' => ++$position,
				'name'     => (string) $item[0],
				'item'     => $url,
			);
		}
		return array(
			'@type'           => 'BreadcrumbList',
			'@id'             => self::canonical() . '#breadcrumb',
			'itemListElement' => $list,
		);
	}

	/**
	 * Sitemap of WordPress: only the zones with their own page.
	 *
	 * @param mixed $args     Query args.
	 * @param mixed $taxonomy Taxonomy.
	 * @return mixed
	 */
	public static function sitemap_terms( $args, $taxonomy ) {
		if ( Model::ZONE !== $taxonomy || ! is_array( $args ) ) {
			return $args;
		}
		$ids             = array_keys( array_filter( Directory::zones(), static fn( array $zone ): bool => $zone['page'] ) );
		$args['include'] = $ids ? $ids : array( 0 );
		return $args;
	}

	/**
	 * Sitemap of Rank Math: the zones without a page are left out.
	 *
	 * @param mixed $url    Entry.
	 * @param mixed $type   Type of object.
	 * @param mixed $item   Object.
	 * @return mixed
	 */
	public static function rank_math_entry( $url, $type, $item ) {
		if ( 'term' === $type && $item instanceof \WP_Term && Model::ZONE === $item->taxonomy ) {
			$zone = Directory::zone( (int) $item->term_id );
			return null !== $zone && $zone['page'] ? $url : false;
		}
		return $url;
	}
}
