<?php
/**
 * Where the finder takes its stores from.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

defined( 'ABSPATH' ) || exit;

/**
 * The finder (its template, the block and the browser) works on the document of Data, as an
 * array, whoever produces it: the stores of this site (master mode, `mode` = `master`) or,
 * in the client mode of 9b, the JSON of the master read with a cache and a local copy. The
 * adapter is chosen by the setting `mode`; only the master exists in this version.
 */
final class Source {

	/**
	 * Modes of the setting `mode`.
	 */
	public const MASTER = 'master';
	public const CLIENT = 'client';

	/**
	 * The mode of this site. The client mode is not built yet (9b): a site set to it keeps
	 * working as a master and the health says so.
	 */
	public static function mode(): string {
		return self::CLIENT === OleotecasModule::setting( 'mode' ) ? self::CLIENT : self::MASTER;
	}

	/**
	 * The document of the finder.
	 *
	 * @return array<string, mixed>
	 */
	public static function document(): array {
		return Data::document();
	}

	/**
	 * URL the browser reads the same document from (versioned).
	 */
	public static function url(): string {
		return Data::url();
	}
}
