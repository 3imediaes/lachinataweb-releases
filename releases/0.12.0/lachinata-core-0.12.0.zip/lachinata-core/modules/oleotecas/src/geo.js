/**
 * Distances and the search against our own data. The visitor's location never leaves the
 * browser: the distance is computed here.
 */

/**
 * Distance in km (haversine).
 *
 * @param {number} lat1 Latitude 1.
 * @param {number} lng1 Longitude 1.
 * @param {number} lat2 Latitude 2.
 * @param {number} lng2 Longitude 2.
 * @return {number} Km.
 */
export const distance = (lat1, lng1, lat2, lng2) => {
	const rad = Math.PI / 180;
	const a =
		Math.sin(((lat2 - lat1) * rad) / 2) ** 2 +
		Math.cos(lat1 * rad) *
			Math.cos(lat2 * rad) *
			Math.sin(((lng2 - lng1) * rad) / 2) ** 2;
	return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
};

/**
 * «1,2 km», «68 km».
 *
 * @param {number} km     Km.
 * @param {string} locale Locale of the page.
 * @return {string} Text.
 */
export const formatKm = (km, locale = 'es') =>
	`${new Intl.NumberFormat(locale, {
		maximumFractionDigits: km < 10 ? 1 : 0,
	}).format(km)} km`;

/**
 * Lower case without accents.
 *
 * @param {string} text Text.
 * @return {string} Folded.
 */
export const fold = (text) =>
	String(text || '')
		.normalize('NFD')
		.replace(/[̀-ͯ]/g, '')
		.toLowerCase()
		.trim();

/**
 * Stores that match a query in our data: zone, city, postcode (or its start) and name.
 * A zone or a city matches whole words; a name matches its start.
 *
 * @param {Array<Object>} stores Stores.
 * @param {Array<Object>} zones  Zones (slug, name).
 * @param {string}        query  Query.
 * @return {Array<Object>} Matches.
 */
export const matchStores = (stores, zones, query) => {
	const needle = fold(query);
	if (!needle) {
		return [];
	}
	const zoneSlugs = new Set(
		(zones || [])
			.filter((zone) => fold(zone.name) === needle)
			.map((zone) => zone.slug)
	);
	const digits = /^\d{3,}$/.test(needle);
	return stores.filter((store) => {
		if ((store.zones || []).some((slug) => zoneSlugs.has(slug))) {
			return true;
		}
		if (digits) {
			return String(store.postcode || '').startsWith(needle);
		}
		return (
			fold(store.city) === needle ||
			fold(store.countryName) === needle ||
			fold(store.name).startsWith(needle) ||
			fold(store.name)
				.split(/[\s·-]+/)
				.includes(needle)
		);
	});
};

/**
 * The centre of some stores.
 *
 * @param {Array<Object>} stores Stores with coordinates.
 * @return {{lat: number, lng: number}|null} Centre.
 */
export const centre = (stores) => {
	const located = stores.filter(
		(store) => store.lat !== null && store.lng !== null
	);
	if (!located.length) {
		return null;
	}
	return {
		lat:
			located.reduce((sum, store) => sum + store.lat, 0) / located.length,
		lng:
			located.reduce((sum, store) => sum + store.lng, 0) / located.length,
	};
};

/**
 * Stores sorted by distance to a point, each with its `km`.
 *
 * @param {Array<Object>}              stores Stores.
 * @param {{lat: number, lng: number}} origin Point.
 * @return {Array<Object>} Sorted copies.
 */
export const byDistance = (stores, origin) =>
	stores
		.map((store) => ({
			...store,
			km:
				store.lat === null || store.lng === null
					? Infinity
					: distance(origin.lat, origin.lng, store.lat, store.lng),
		}))
		.sort((a, b) => a.km - b.km);
