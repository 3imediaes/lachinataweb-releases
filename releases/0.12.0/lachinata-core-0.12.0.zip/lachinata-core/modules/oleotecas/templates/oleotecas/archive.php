<?php
/**
 * Finder (`/oleotecas/`): brand header, StoreSearch, the list with the map on demand, «Por
 * país y ciudad» and the franchise block (Oleotecas.dc.html, OleotecasDesktop.dc.html).
 *
 * The theme can override it with `lachinata/oleotecas/archive.php`.
 *
 * @package LaChinata\Core
 */

use LaChinata\Core\Modules\Oleotecas\Directory;
use LaChinata\Core\Modules\Oleotecas\Pages;
use LaChinata\Core\Modules\Oleotecas\Texts;
use LaChinata\Core\Templates;

defined( 'ABSPATH' ) || exit;

get_header();
?>
<div class="lc-stores lc-stores--finder">
	<header class="lc-stores-hero">
		<div class="lc-stores-hero__inner">
			<h1 class="editorial-h1"><?php echo esc_html( Texts::archive_title() ); ?></h1>
			<p class="body"><?php echo esc_html( Texts::archive_lead( count( Directory::stores() ), Directory::country_count() ) ); ?></p>
		</div>
	</header>
	<div class="lc-stores__inner">
		<?php Templates::part( 'oleotecas', 'parts/finder', Pages::finder_args() ); ?>
		<?php Templates::part( 'oleotecas', 'parts/places', array( 'places' => Pages::places() ) ); ?>
		<?php Templates::part( 'oleotecas', 'parts/franchise' ); ?>
	</div>
</div>
<?php
get_footer();
