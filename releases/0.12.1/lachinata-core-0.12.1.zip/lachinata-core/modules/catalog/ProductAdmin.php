<?php
/**
 * «La Chinata» tab in the product data box and content field on variations.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * Product edit screen.
 */
final class ProductAdmin {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'woocommerce_product_data_tabs', array( self::class, 'tab' ) );
		Hooks::add_action( 'woocommerce_product_data_panels', array( self::class, 'panel' ) );
		Hooks::add_action( 'woocommerce_admin_process_product_object', array( self::class, 'save' ) );
		Hooks::add_action( 'woocommerce_product_after_variable_attributes', array( self::class, 'variation_fields' ), 10, 3 );
		Hooks::add_action( 'woocommerce_admin_process_variation_object', array( self::class, 'save_variation' ), 10, 2 );
		Hooks::add_action( 'admin_notices', array( self::class, 'missing_weight_notice' ) );
	}

	/**
	 * Warns on the product screen when a product that ships has no weight: the shipping
	 * conditions count it as 0 kg.
	 */
	public static function missing_weight_notice(): void {
		$screen = get_current_screen();
		if ( null === $screen || 'product' !== $screen->id || 'post' !== $screen->base ) {
			return;
		}
		$product = wc_get_product( get_the_ID() );
		if ( ! $product instanceof \WC_Product || 'auto-draft' === $product->get_status() || ! self::lacks_weight( $product ) ) {
			return;
		}
		printf(
			'<div class="notice notice-warning"><p>%s</p></div>',
			esc_html__( 'Este producto no tiene peso. Cuenta como 0 kg en las condiciones de envío: complétalo en Datos del producto → Envío.', 'lachinata-core' )
		);
	}

	/**
	 * Whether a product ships without a weight (for variable products: a variation without
	 * its own weight and a parent without one either).
	 *
	 * @param \WC_Product $product Product.
	 */
	public static function lacks_weight( \WC_Product $product ): bool {
		if ( $product->is_virtual() || $product->is_type( array( 'grouped', 'external' ) ) ) {
			return false;
		}
		if ( ! $product instanceof \WC_Product_Variable ) {
			return '' === (string) $product->get_weight();
		}
		if ( '' !== (string) $product->get_weight() ) {
			return false;
		}
		foreach ( $product->get_children() as $child_id ) {
			$child = wc_get_product( $child_id );
			if ( $child instanceof \WC_Product && ! $child->is_virtual() && '' === (string) $child->get_weight( 'edit' ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Adds the tab.
	 *
	 * @param array<string, array<string, mixed>> $tabs Tabs.
	 * @return array<string, array<string, mixed>>
	 */
	public static function tab( array $tabs ): array {
		$tabs['lachinata'] = array(
			'label'    => __( 'La Chinata', 'lachinata-core' ),
			'target'   => 'lachinata_product_data',
			'class'    => array(),
			'priority' => 75,
		);
		return $tabs;
	}

	/**
	 * Unit options for selects.
	 *
	 * @return array<string, string>
	 */
	private static function unit_options(): array {
		return array_combine( array_keys( Quantity::UNITS ), array_keys( Quantity::UNITS ) );
	}

	/**
	 * Amount + unit inputs.
	 *
	 * @param string        $name  Base name.
	 * @param string        $label Label.
	 * @param Quantity|null $value Current value.
	 * @param string        $help  Help text.
	 */
	private static function quantity_inputs( string $name, string $label, ?Quantity $value, string $help ): void {
		printf(
			'<p class="form-field %1$s_field"><label for="%1$s_cantidad">%2$s</label><input type="number" min="0" step="any" class="short" style="width:8em" id="%1$s_cantidad" name="%1$s[cantidad]" value="%3$s"> <select name="%1$s[unidad]" aria-label="%4$s">',
			esc_attr( $name ),
			esc_html( $label ),
			esc_attr( null === $value ? '' : (string) $value->amount ),
			esc_attr__( 'Unidad', 'lachinata-core' )
		);
		foreach ( self::unit_options() as $unit ) {
			printf( '<option value="%1$s"%2$s>%1$s</option>', esc_attr( $unit ), selected( null === $value ? 'g' : $value->unit, $unit, false ) );
		}
		echo '</select> ' . wc_help_tip( $help ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wc_help_tip escapes.
	}

	/**
	 * Tab content.
	 */
	public static function panel(): void {
		global $product_object;
		$product = $product_object instanceof \WC_Product ? $product_object : null;
		$id      = $product ? $product->get_id() : 0;

		echo '<div id="lachinata_product_data" class="panel woocommerce_options_panel hidden">';
		wp_nonce_field( 'lachinata_catalog_product', 'lachinata_catalog_product_nonce' );

		echo '<div class="options_group">';
		self::quantity_inputs(
			'lc_contenido',
			__( 'Contenido', 'lachinata-core' ),
			$id ? Fields::quantity( $id, Fields::CONTENT ) : null,
			__( 'Cantidad que trae el envase. En productos variables, cada variación puede tener la suya.', 'lachinata-core' )
		);

		$reference = $id ? Fields::quantity( $id, Fields::REFERENCE ) : null;
		woocommerce_wp_select(
			array(
				'id'          => 'lc_referencia',
				'label'       => __( 'Referencia del precio por unidad', 'lachinata-core' ),
				'options'     => array( '' => __( 'Sin precio por unidad', 'lachinata-core' ) ) + array_combine( Quantity::REFERENCES, Quantity::REFERENCES ),
				'value'       => null === $reference ? '' : $reference->amount . ' ' . $reference->unit,
				'desc_tip'    => true,
				'description' => __( 'Se muestra «500 ml | 9,33 € / 1 l». Debe ser de la misma magnitud que el contenido.', 'lachinata-core' ),
			)
		);
		echo '</div><div class="options_group">';

		woocommerce_wp_text_input(
			array(
				'id'          => 'lc_etiqueta',
				'label'       => __( 'Etiqueta', 'lachinata-core' ),
				'value'       => $id ? (string) Fields::get( $id, Fields::LABEL ) : '',
				'desc_tip'    => true,
				'description' => __( 'Texto corto que aparece como etiqueta en la tarjeta y la ficha.', 'lachinata-core' ),
			)
		);
		woocommerce_wp_text_input(
			array(
				'id'    => 'lc_consumo_preferente',
				'label' => __( 'Consumo preferente', 'lachinata-core' ),
				'type'  => 'date',
				'value' => $id ? (string) Fields::get( $id, Fields::BEST_BEFORE ) : '',
			)
		);
		woocommerce_wp_checkbox(
			array(
				'id'          => 'lc_excluir_internacional',
				'label'       => __( 'Exclusión internacional', 'lachinata-core' ),
				'value'       => $id && Fields::get( $id, Fields::NO_SHIP_ABROAD ) ? 'yes' : 'no',
				'description' => __( 'Limita los destinos según WooCommerce → La Chinata → Envíos → Restricciones de producto.', 'lachinata-core' ),
			)
		);
		echo '<p class="form-field"><label for="lc_imagen_descripcion">' . esc_html__( 'Imagen de descripción', 'lachinata-core' ) . '</label>';
		Admin::image_picker( 'lc_imagen_descripcion', $id ? (int) Fields::get( $id, Fields::IMAGE ) : 0 );
		echo '</p></div>';

		echo '<div class="options_group" style="padding:0 12px 12px"><p><strong>' . esc_html__( 'Ingredientes', 'lachinata-core' ) . '</strong></p>';
		wp_editor(
			$id ? (string) Fields::get( $id, Fields::INGREDIENTS ) : '',
			'lc_ingredientes',
			array(
				'textarea_rows' => 6,
				'teeny'         => true,
				'media_buttons' => false,
			)
		);
		echo '</div>';
		/**
		 * End of the La Chinata tab of the product, for the fields of other modules (inside
		 * `.options_group` blocks; each module saves its own).
		 *
		 * @since 0.10.0
		 *
		 * @param \WC_Product|null $product Product being edited.
		 */
		do_action( 'lachinata/catalog/product_fields', $product );
		echo '</div>';
	}

	/**
	 * Saves the tab.
	 *
	 * @param \WC_Product $product Product being saved.
	 */
	public static function save( \WC_Product $product ): void {
		if ( ! isset( $_POST['lachinata_catalog_product_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['lachinata_catalog_product_nonce'] ) ), 'lachinata_catalog_product' ) ) {
			return;
		}

		$content = self::posted_quantity( wp_unslash( $_POST['lc_contenido'] ?? null ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitised by posted_quantity().
		self::set_or_delete( $product, Fields::CONTENT, $content?->to_array() );

		$reference = Quantity::parse( sanitize_text_field( wp_unslash( $_POST['lc_referencia'] ?? '' ) ) );
		self::set_or_delete( $product, Fields::REFERENCE, $reference?->to_array() );

		$product->update_meta_data( Fields::LABEL, sanitize_text_field( wp_unslash( $_POST['lc_etiqueta'] ?? '' ) ) );
		$product->update_meta_data( Fields::BEST_BEFORE, Fields::sanitize_date( sanitize_text_field( wp_unslash( $_POST['lc_consumo_preferente'] ?? '' ) ) ) );
		$product->update_meta_data( Fields::NO_SHIP_ABROAD, isset( $_POST['lc_excluir_internacional'] ) ? '1' : '' );
		$product->update_meta_data( Fields::IMAGE, (string) absint( $_POST['lc_imagen_descripcion'] ?? 0 ) );
		$product->update_meta_data( Fields::INGREDIENTS, wp_kses_post( wp_unslash( $_POST['lc_ingredientes'] ?? '' ) ) );
	}

	/**
	 * Content field in each variation.
	 *
	 * @param int      $loop           Variation index.
	 * @param mixed    $variation_data Unused.
	 * @param \WP_Post $variation      Variation post.
	 */
	public static function variation_fields( int $loop, mixed $variation_data, \WP_Post $variation ): void {
		$own = metadata_exists( 'post', $variation->ID, Fields::CONTENT ) ? Quantity::from_array( get_post_meta( $variation->ID, Fields::CONTENT, true ) ) : null;
		echo '<div class="form-row form-row-full">';
		self::quantity_inputs(
			'lc_contenido_variacion[' . $loop . ']',
			__( 'Contenido (vacío: el del producto)', 'lachinata-core' ),
			$own,
			__( 'Cantidad de esta variación para el precio por unidad.', 'lachinata-core' )
		);
		echo '</div>';
	}

	/**
	 * Saves the variation content.
	 *
	 * @param \WC_Product_Variation $variation Variation.
	 * @param int                   $loop      Variation index.
	 */
	public static function save_variation( \WC_Product_Variation $variation, int $loop ): void {
		check_ajax_referer( 'save-variations', 'security' );
		$posted = wp_unslash( $_POST['lc_contenido_variacion'][ $loop ] ?? null ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitised by posted_quantity().
		self::set_or_delete( $variation, Fields::CONTENT, self::posted_quantity( $posted )?->to_array() );
	}

	/**
	 * Quantity from a posted `{cantidad, unidad}` pair.
	 *
	 * @param mixed $posted Raw value.
	 */
	private static function posted_quantity( mixed $posted ): ?Quantity {
		if ( ! is_array( $posted ) ) {
			return null;
		}
		return Quantity::from_array(
			array(
				'cantidad' => (float) str_replace( ',', '.', sanitize_text_field( (string) ( $posted['cantidad'] ?? '' ) ) ),
				'unidad'   => sanitize_key( (string) ( $posted['unidad'] ?? '' ) ),
			)
		);
	}

	/**
	 * Updates the meta. An empty product field is stored as '' so the ACF value it
	 * replaces is not read again; an empty variation field is removed so it inherits.
	 *
	 * @param \WC_Product               $product Product or variation.
	 * @param string                    $key     Meta key.
	 * @param array<string, mixed>|null $value   Value.
	 */
	private static function set_or_delete( \WC_Product $product, string $key, ?array $value ): void {
		if ( null !== $value ) {
			$product->update_meta_data( $key, $value );
		} elseif ( $product->is_type( 'variation' ) ) {
			$product->delete_meta_data( $key );
		} else {
			$product->update_meta_data( $key, '' );
		}
	}
}
