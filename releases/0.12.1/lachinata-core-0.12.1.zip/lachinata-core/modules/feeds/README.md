# Módulo `feeds`

Feeds de producto para **Google Merchant Center** y el **catálogo de Meta**, para cualquier tienda. Sustituye a WooCommerce Google Product Feed y a la sincronización de catálogo de Facebook for WooCommerce. Genera feeds XML en el formato de Google (RSS 2.0 con `g:`), que también lee Meta, en segundo plano y a un archivo con URL pública aleatoria. Cada tienda configura sus feeds (destino, idioma y país), lo que deja fuera y cómo se forma cada campo.

**Los IDs no cambian.** El `id` de cada producto es el de su destino en `ProductIds` (WooCommerce → La Chinata → IDs de producto, en el núcleo), con preajustes compatibles con los plugins anteriores. Es el mismo ID que usan los eventos de medición (`tracking`) para el remarketing de Google Ads y el píxel de Meta. Merchant Center y Meta conservan así el historial y las campañas de cada producto.

Decisiones: `design-system/docs/decisiones.md` (incremento 7). Paso a producción: `docs/despliegue-tracking-feeds.md`. Ajustes: WooCommerce → La Chinata → Feeds.

## Qué hace

| Pieza | Cómo | Dónde |
| --- | --- | --- |
| **Feeds por destino, idioma y país**, con la moneda de la tienda. Los idiomas los da `Contracts\Languages`: sin `translate`, solo el de la tienda; con él, un feed por idioma con sus textos, categorías y URLs | `Services::languages()` | `Feeds.php` |
| **URL pública con un segmento aleatorio** por feed: `uploads/lachinata-feeds/<32 hexadecimales>/<feed>.xml`. Es un archivo estático que sirve el servidor web sin pasar por PHP. Se escribe a un temporal y se renombra al terminar | `Files.php` | `Files.php` |
| **Generación en segundo plano** (Action Scheduler): completa cada noche (03:30, hora de la tienda) y parcial dos minutos después de cambiar un producto, su stock o su precio. La parcial rehace solo lo que cambió y copia el resto de una caché junto al feed (`<feed>.xml.cache.json`). Un bloqueo evita dos generaciones a la vez | `woocommerce_update_product`, `…_set_stock`, `…_set_stock_status` y sus variaciones | `Schedule.php`, `Builder.php` |
| **Campos**: `id`, `title`, `description`, `link`, `image_link`, `additional_image_link` (hasta 10), `availability`, `price`, `sale_price` y `sale_price_effective_date`, `brand`, `gtin` (el nativo de WooCommerce), `mpn` (el SKU, configurable), `identifier_exists` (`no` sin GTIN ni MPN, solo Google), `condition`, `item_group_id` (variaciones), `google_product_category` (de la categoría, heredada), `product_type` (ruta de categorías), `shipping_weight`, `unit_pricing_measure` y `unit_pricing_base_measure` (contenido y referencia de `catalog`, por `Contracts\ProductContent`) y `custom_label_0` a `custom_label_4` | | `Item.php` |
| **Precios** con IVA (`wc_get_price_including_tax`), en la moneda de la tienda. **Disponibilidad** en el vocabulario de cada destino: `in_stock` o `backorder` para Google; `in stock` o `available for order` para Meta | | `Item.php` |
| **Título y descripción** del propio producto, en el idioma del feed, sin texto añadido. Google prohíbe el texto promocional, así que el envío va en Merchant Center y no en el título. En las variaciones, el título lleva sus atributos | | `Item.php` |
| **Marca**: la de WooCommerce (`product_brand`) y, si no hay, la de Datos de la empresa o el nombre del sitio | `Company::brand()` | núcleo |
| **Exclusiones** con su motivo: producto marcado «No enviar a los feeds»; categoría excluida con sus subcategorías; sin stock, sin imagen o sin precio (reglas activables); oculto o sin publicar. El panel muestra cada excluido con su motivo | | `Item::reason()`, `FeedsTab.php` |
| **Avisos de calidad**: sin GTIN, GTIN con un número de cifras que no existe, sin imagen, título de más de 150 caracteres y texto promocional (envío gratis, oferta, descuento, rebaja, Black Friday; un porcentaje, solo en el título, porque en la descripción suele ser un dato como «100 % natural») | | `Item.php` |
| **Etiquetas personalizadas** configurables: categoría principal, subcategoría, más vendidos («bestseller», los N con más ventas), en oferta («sale»), campaña (campo del producto) y franja de precio. De serie, 0 la categoría, 1 los más vendidos y 2 la campaña | | `Item.php` |
| **Campos del producto y de la categoría**: «No enviar a los feeds» y «Campaña» en la pestaña La Chinata (`lachinata/catalog/product_fields`; sin `catalog`, en Avanzado); «Categoría de Google» en cada categoría de productos | | `ProductFields.php` |
| **Panel**: cada feed con su URL para copiar, la última generación (productos, excluidos, avisos, segundos), «Generar ahora», «Descargar y validar» (descarga la URL pública como lo harán Merchant Center y Meta, y comprueba que es RSS, que hay productos, los campos obligatorios y que no hay IDs repetidos) y «Quitar» | `manage_woocommerce` | `FeedsTab.php`, `Validator.php` |
| **WP-CLI**: `wp lachinata feeds list`, `add --destination=google|meta [--language] [--country]`, `generate [--feed=<id>] [--sample=10 --output=<archivo>]` | | `Cli.php` |

## Paso a producción

`docs/despliegue-tracking-feeds.md`: comprobar que los IDs coinciden en staging, cambiar la fuente de Merchant Center y del catálogo de Meta a las URL nuevas y, después, desactivar los plugins anteriores.

## Depende de

Ningún módulo. Necesita WooCommerce 10. Del núcleo lee `ProductIds`, `Company` (marca) y `Contracts\Languages`. Con `catalog`, el contenido para el precio por unidad (`Contracts\ProductContent`) y la pestaña La Chinata del producto; sin `catalog` no hay precio por unidad y los campos van a Avanzado.

## Hooks que escucha

- `action_scheduler_init` (programa la generación diaria; lo comprueba una vez al día), `lachinata_feeds_full` y `lachinata_feeds_partial` (Action Scheduler).
- Cambios de producto: `woocommerce_new_product`, `woocommerce_update_product`, `woocommerce_new_product_variation`, `woocommerce_update_product_variation`, `woocommerce_product_set_stock`, `woocommerce_variation_set_stock`, `woocommerce_product_set_stock_status`, `woocommerce_variation_set_stock_status`, `before_delete_post` y `wp_trash_post`.
- Panel: `woocommerce_admin_process_product_object`, `woocommerce_product_options_advanced`, `product_cat_add_form_fields`, `product_cat_edit_form_fields`, `created_product_cat` y `edited_product_cat`.
- De `catalog`: `lachinata/catalog/product_fields`. Del núcleo: `lachinata/core/admin_tabs`.

## Hooks que emite

Ninguno propio. El ID de cada producto se puede ajustar con `lachinata/product_ids/id`, que es del núcleo (`plugin/HOOKS.md`).

## Datos que guarda

- Metadatos de producto `_lc_feeds_exclude` y `_lc_feeds_campaign`, y de término `_lc_feeds_google_category`.
- Opciones `lachinata_feeds_*`: ajustes, los feeds (`_feeds`, con su segmento), la última generación de cada uno (`_state`), los productos cambiados pendientes de la parcial (`_dirty`) y el registro de huecos (`_gaps`).
- Archivos en `uploads/lachinata-feeds/`: el feed y su caché. Quitar un feed borra los suyos. «Borrar datos» no borra los archivos: si hace falta, se quitan los feeds antes.

## REST y API para Odoo

No tiene rutas: los feeds son archivos estáticos. Nada en el objeto `lachinata` de los pedidos.

## Ajustes y exportación

| Ajuste | Por defecto | En el JSON |
| --- | --- | --- |
| Dejar fuera sin stock, sin imagen o sin precio (`exclude_out_of_stock`, `exclude_no_image`, `exclude_no_price`) | sí, sí, sí | sí |
| Categorías excluidas (`exclude_categories`) | ninguna | sí (son IDs de este sitio: revisar al importar en otro) |
| MPN (`mpn`: `sku` o `none`) | `sku` | sí |
| Etiquetas personalizadas (`labels`) | categoría, más vendidos, campaña | sí |
| Cuántos son «más vendidos» (`bestsellers`) | 20 | sí |
| Los feeds: destino, idioma, país y moneda | — | sí, en `data.feeds`, **sin la URL**. Al importar, un feed que ya existe conserva la suya y uno nuevo recibe otra |

## Qué pasa al apagarlo

No se generan más feeds. Los archivos se quedan con su última versión, así que Merchant Center y Meta siguen leyendo productos que pueden quedarse viejos: si se apaga para siempre, quita antes los feeds en el panel. Los campos del producto y la categoría se conservan.

## Pruebas

- `tests/FeedsTest.php` comprueba:
  - feeds y URL aleatoria, y que no se repite destino, idioma y país;
  - los campos de un producto en oferta con el ID del preajuste (Google Product Feed), la categoría de Google heredada, la ruta de categorías, el peso y la etiqueta de categoría;
  - las variaciones con `item_group_id` y la disponibilidad de Meta;
  - las exclusiones (producto, categoría con subcategorías, sin imagen, sin stock y la regla apagada);
  - los avisos (texto promocional en el título; un porcentaje en la descripción no lo es; sin GTIN);
  - la generación válida, que la parcial solo rehace lo cambiado y que la completa lo rehace todo;
  - la exportación sin URL y el escape de XML.
- Muestra de 10 productos: `wp lachinata feeds generate --feed=google-es_ES-ES --sample=10 --output=dist/feed-ejemplo-google.xml`.

## Huecos conocidos

- Un solo precio por feed: el de la tienda en su moneda. Varias monedas o precios por país necesitan otra tienda o un módulo de precios.
- `shipping` y `tax` no van en el feed: se configuran en Merchant Center (y en la configuración de envíos de Meta).
- La validación de «Descargar y validar» comprueba lo que comparten Google y Meta. Los avisos propios de Merchant Center (políticas, imágenes) se ven en su diagnóstico.
