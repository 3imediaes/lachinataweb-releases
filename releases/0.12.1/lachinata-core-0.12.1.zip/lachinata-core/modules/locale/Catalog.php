<?php
/**
 * The catalogue by destination.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Locale;

use LaChinata\Core\Hooks;
use LaChinata\Core\Services;
use LaChinata\Core\Shipping\Destination;

defined( 'ABSPATH' ) || exit;

/**
 * What does not travel to a destination comes from the shipping rules (contract
 * ShippingRules), never from a second list. It is precalculated in the internal taxonomy
 * `lc_restriccion` (one term per destination of this shop where the product does not ship),
 * recalculated when a product is saved and, in batches, when the shipping rules or the
 * destinations change. Listings, search, related products and blocks then filter with a
 * tax_query.
 *
 * When the page cache does not vary by `lc_destino`, the server shows everything and marks
 * the cards (`data-lc-no`) and the product page; a style in the head hides them for the
 * visitor's destination before painting (Front::head()).
 */
final class Catalog {

	/**
	 * Internal taxonomy.
	 */
	public const TAXONOMY = 'lc_restriccion';

	/**
	 * Action Scheduler hook of the batches.
	 */
	public const HOOK = 'lachinata_locale_index';

	/**
	 * Action Scheduler group.
	 */
	private const GROUP = 'lachinata-locale';

	/**
	 * Products per batch.
	 */
	public const BATCH = 100;

	/**
	 * Restricted product ids by destination, for the request.
	 *
	 * @var array<string, int[]>
	 */
	private static array $restricted = array();

	/**
	 * Registers the hooks (on `init`, after the taxonomy).
	 */
	public static function boot(): void {
		Hooks::add_action( 'woocommerce_new_product', array( self::class, 'index_product' ) );
		Hooks::add_action( 'woocommerce_update_product', array( self::class, 'index_product' ) );
		Hooks::add_action( 'lachinata/shipping/changed', array( self::class, 'schedule' ) );
		Hooks::add_action( 'lachinata/locale/changed', array( self::class, 'schedule' ) );
		Hooks::add_action( self::HOOK, array( self::class, 'run_batch' ) );
		Hooks::add_action( 'pre_get_posts', array( self::class, 'filter_query' ) );
		Hooks::add_filter( 'woocommerce_related_products', array( self::class, 'filter_ids' ) );
		Hooks::add_filter( 'lachinata/product/routine_ids', array( self::class, 'filter_ids' ) );
		Hooks::add_filter( 'lachinata/thankyou/product_ids', array( self::class, 'filter_ids' ) );
		Hooks::add_filter( 'lachinata/product_card/attributes', array( self::class, 'card_attributes' ), 10, 2 );
		Hooks::add_filter( 'lachinata/catalog/show_count', array( self::class, 'show_count' ) );
		Hooks::add_filter( 'lachinata/product/can_buy', array( self::class, 'can_buy' ), 10, 2 );
		Hooks::add_action( 'lachinata/product/before_buy', array( self::class, 'product_notice' ) );
		Hooks::add_filter( 'lachinata/cart/checkout_blocked', array( self::class, 'checkout_blocked' ), 10, 2 );
	}

	/**
	 * The taxonomy: internal, without screens, archives or REST.
	 */
	public static function register(): void {
		register_taxonomy(
			self::TAXONOMY,
			array( 'product' ),
			array(
				'public'             => false,
				'publicly_queryable' => false,
				'show_ui'            => false,
				'show_in_rest'       => false,
				'show_in_nav_menus'  => false,
				'rewrite'            => false,
				'query_var'          => false,
				'hierarchical'       => false,
				'label'              => __( 'Destinos sin envío', 'lachinata-core' ),
			)
		);
	}

	/**
	 * Destinations of this shop where a product does not ship, by the shipping rules.
	 * Null while `shipping` is off (nothing is recalculated then).
	 *
	 * @param \WC_Product $product Product.
	 * @return string[]|null Ids.
	 */
	public static function compute( \WC_Product $product ): ?array {
		$rules = Services::shipping_rules();
		if ( null === $rules ) {
			return null;
		}
		$out = array();
		foreach ( Config::own() as $destination ) {
			if ( true !== $rules->shippable( $product, Config::location( $destination ) ) ) {
				$out[] = $destination['id'];
			}
		}
		return $out;
	}

	/**
	 * Recalculates the terms of a product.
	 *
	 * @param int|mixed $product_id Product id.
	 */
	public static function index_product( $product_id ): void {
		$product = wc_get_product( (int) $product_id );
		if ( ! $product instanceof \WC_Product || $product instanceof \WC_Product_Variation ) {
			return;
		}
		$ids = self::compute( $product );
		if ( null !== $ids ) {
			wp_set_object_terms( $product->get_id(), array_map( 'strtolower', $ids ), self::TAXONOMY, false );
			self::$restricted = array();
		}
	}

	/**
	 * Schedules the whole catalogue, once (several changes in a row make one run).
	 */
	public static function schedule(): void {
		if ( ! function_exists( 'as_schedule_single_action' ) || ! function_exists( 'as_has_scheduled_action' ) || as_has_scheduled_action( self::HOOK, array( 0 ), self::GROUP ) ) {
			return;
		}
		as_schedule_single_action( time() + 30, self::HOOK, array( 0 ), self::GROUP );
	}

	/**
	 * Whether the catalogue is being recalculated.
	 */
	public static function pending(): bool {
		return function_exists( 'as_has_scheduled_action' ) && as_has_scheduled_action( self::HOOK, null, self::GROUP );
	}

	/**
	 * One batch, and the next one if there are more products.
	 *
	 * @param int|mixed $offset Offset.
	 * @param bool      $chain  Schedule the next batch (WP-CLI runs them in a row).
	 */
	public static function run_batch( $offset = 0, bool $chain = true ): int {
		$offset = max( 0, (int) $offset );
		$ids    = get_posts(
			array(
				'post_type'      => 'product',
				'post_status'    => array( 'publish', 'private', 'draft', 'pending', 'future' ),
				'fields'         => 'ids',
				'posts_per_page' => self::BATCH,
				'offset'         => $offset,
				'orderby'        => 'ID',
				'order'          => 'ASC',
				'no_found_rows'  => true,
			)
		);
		foreach ( $ids as $id ) {
			self::index_product( (int) $id );
		}
		if ( $chain && self::BATCH === count( $ids ) && function_exists( 'as_schedule_single_action' ) ) {
			as_schedule_single_action( time(), self::HOOK, array( $offset + self::BATCH ), self::GROUP );
		} elseif ( self::BATCH !== count( $ids ) ) {
			update_option( 'lachinata_locale_indexed', time(), false );
		}
		return count( $ids );
	}

	/**
	 * Destinations of this shop where a product does not ship, from its terms.
	 *
	 * @param \WC_Product $product Product or variation.
	 * @return string[] Ids.
	 */
	public static function restrictions( \WC_Product $product ): array {
		$id    = $product->get_parent_id() ? $product->get_parent_id() : $product->get_id();
		$terms = get_the_terms( $id, self::TAXONOMY );
		if ( ! is_array( $terms ) ) {
			return array();
		}
		$own = array_column( Config::own(), 'id' );
		return array_values( array_intersect( array_map( static fn( \WP_Term $t ): string => strtoupper( $t->slug ), $terms ), $own ) );
	}

	/**
	 * Ids of the products that do not ship to a destination.
	 *
	 * @param string $id Destination id.
	 * @return int[]
	 */
	public static function restricted_ids( string $id ): array {
		if ( ! isset( self::$restricted[ $id ] ) ) {
			$term                    = get_term_by( 'slug', strtolower( $id ), self::TAXONOMY );
			$objects                 = $term instanceof \WP_Term ? get_objects_in_term( $term->term_id, self::TAXONOMY ) : array();
			self::$restricted[ $id ] = is_array( $objects ) ? array_map( 'intval', $objects ) : array();
		}
		return self::$restricted[ $id ];
	}

	/**
	 * Listings, search and product blocks without what does not ship to the visitor's
	 * destination (only when the server renders for it). A single page is never filtered:
	 * the product page stays, with its notice.
	 *
	 * @param \WP_Query $query Query.
	 */
	public static function filter_query( $query ): void {
		if ( ! $query instanceof \WP_Query || ( is_admin() && ! wp_doing_ajax() ) || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}
		$destination = Visitor::rendered();
		if ( null === $destination || ( $query->is_main_query() && $query->is_singular() ) ) {
			return;
		}
		$types    = (array) $query->get( 'post_type' );
		$products = in_array( 'product', $types, true ) || ( $query->is_main_query() && ( $query->is_search() || $query->is_post_type_archive( 'product' ) || $query->is_tax( get_object_taxonomies( 'product' ) ) ) );
		if ( ! $products ) {
			return;
		}
		$ours      = array(
			'taxonomy' => self::TAXONOMY,
			'field'    => 'slug',
			'terms'    => array( strtolower( $destination['id'] ) ),
			'operator' => 'NOT IN',
		);
		$query_tax = $query->get( 'tax_query' );
		$query->set(
			'tax_query',
			is_array( $query_tax ) && $query_tax ? array(
				'relation' => 'AND',
				$query_tax,
				$ours,
			) : array( $ours )
		);
	}

	/**
	 * Related, routine and «thank you» products without what does not ship.
	 *
	 * @param int[]|mixed $ids Product ids.
	 * @return int[]|mixed
	 */
	public static function filter_ids( $ids ) {
		$destination = Visitor::rendered();
		if ( null === $destination || ! is_array( $ids ) ) {
			return $ids;
		}
		return array_values( array_diff( array_map( 'intval', $ids ), self::restricted_ids( $destination['id'] ) ) );
	}

	/**
	 * `data-lc-no` on the cards, for pages that are the same for everyone.
	 *
	 * @param array<string, mixed>|mixed $attributes Attributes.
	 * @param \WC_Product|mixed          $product    Product.
	 * @return array<string, mixed>|mixed
	 */
	public static function card_attributes( $attributes, $product ) {
		if ( Visitor::server_renders() || ! is_array( $attributes ) || ! $product instanceof \WC_Product ) {
			return $attributes;
		}
		$ids = self::restrictions( $product );
		if ( $ids ) {
			$attributes['data-lc-no'] = implode( ' ', $ids );
		}
		return $attributes;
	}

	/**
	 * Counts of the listing («24 productos», «Cargar más (12 de 24)») only when they are
	 * the visitor's: on pages that are the same for everyone, the browser may hide cards.
	 *
	 * @param bool|mixed $show Show the counts.
	 * @return bool|mixed
	 */
	public static function show_count( $show ) {
		return Visitor::server_renders() ? $show : false;
	}

	/**
	 * The buy form, not when the product does not ship to the visitor's destination.
	 *
	 * @param bool|mixed        $can     Show the form.
	 * @param \WC_Product|mixed $product Product.
	 * @return bool|mixed
	 */
	public static function can_buy( $can, $product ) {
		$destination = Visitor::rendered();
		if ( null === $destination || ! $product instanceof \WC_Product ) {
			return $can;
		}
		return in_array( $destination['id'], self::restrictions( $product ), true ) ? false : $can;
	}

	/**
	 * «No podemos enviar este producto a …» with «Cambiar destino», in place of the buy
	 * button. When the server renders for the visitor, only if it applies; otherwise
	 * marked with the destinations it applies to, for the style of the head.
	 *
	 * @param \WC_Product|mixed $product Product.
	 */
	public static function product_notice( $product ): void {
		if ( ! $product instanceof \WC_Product ) {
			return;
		}
		$ids = self::restrictions( $product );
		if ( Visitor::server_renders() ) {
			$destination = Visitor::current();
			if ( null !== $destination && in_array( $destination['id'], $ids, true ) ) {
				echo Front::unshippable( $destination['label'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in Front::unshippable().
			}
			return;
		}
		if ( $ids ) {
			echo Front::unshippable( '', $ids ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in Front::unshippable().
		}
	}

	/**
	 * Why «Tramitar pedido» is off: a line of the bag that does not ship to the customer's
	 * destination (each line already says it, from `shipping`).
	 *
	 * @param string|mixed $reason Reason so far.
	 * @param \WC_Cart     $cart   Cart.
	 * @return string|mixed
	 */
	public static function checkout_blocked( $reason, $cart ) {
		$rules = Services::shipping_rules();
		$place = Destination::customer();
		if ( '' !== $reason || null === $rules || null === $place || ! $cart instanceof \WC_Cart ) {
			return $reason;
		}
		foreach ( $cart->get_cart() as $item ) {
			$product = $item['data'] ?? null;
			if ( $product instanceof \WC_Product && $product->needs_shipping() && true !== $rules->shippable( $product, $place ) ) {
				$destination = Config::for_location( $place['country'], $place['state'] );
				$name        = null === $destination ? Destination::name( $place['country'] ) : $destination['label'];
				/* translators: %s: destination («Portugal»). */
				return sprintf( __( 'Hay productos que no se envían a %s. Quítalos de la bolsa o cambia el destino para tramitar el pedido.', 'lachinata-core' ), $name );
			}
		}
		return $reason;
	}
}
