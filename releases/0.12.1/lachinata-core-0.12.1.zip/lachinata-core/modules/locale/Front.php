<?php
/**
 * What the visitor sees: the picker, the badge and the footer link.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Locale;

use LaChinata\Core\Hooks;
use LaChinata\Core\Services;

defined( 'ABSPATH' ) || exit;

/**
 * MarketPicker in a layer of the theme (BottomSheet on mobile, a 480 px dialog on desktop),
 * MarketBadge in the PromoBar and the AppBar, «Cambiar destino» in the footer. Pages are
 * the same for everyone when they come from the cache, so the server prints the picker
 * closed and a small script in the head reads the cookie before painting: it marks the
 * page with the destination (`data-lc-destino`, which hides what does not ship when the
 * cache does not vary) or as pending (`data-lc-locale-pending`, which opens the picker and
 * keeps the cookie bar waiting). Only registered when there is something to choose.
 */
final class Front {

	/**
	 * Script handle.
	 */
	private const SCRIPT = 'lachinata-locale';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'wp_head', array( self::class, 'head' ), 0 );
		Hooks::add_action( 'wp_enqueue_scripts', array( self::class, 'enqueue' ) );
		Hooks::add_action( 'wp_footer', array( self::class, 'layer' ), 5 );
		Hooks::add_action( 'lachinata/promo_bar/start', array( self::class, 'badge' ) );
		Hooks::add_action( 'lachinata/app_bar/utilities', array( self::class, 'badge' ) );
		Hooks::add_action( 'lachinata/footer/legal', array( self::class, 'footer_link' ) );
		Hooks::add_filter( 'lachinata/tracking/services', array( self::class, 'service' ) );
	}

	/**
	 * Whether the page takes part: not the admin, not the checkout (nothing may cover
	 * «Pagar»; the badge is not there either).
	 */
	private static function applies(): bool {
		return ! is_admin() && ! ( function_exists( 'is_checkout' ) && is_checkout() );
	}

	/**
	 * Data of the head script: labels of this shop's destinations, the template of the
	 * badge, the cookies and, on pages that are the same for everyone, the destination they
	 * are printed with.
	 *
	 * @return array<string, mixed>
	 */
	public static function data(): array {
		$labels = array();
		foreach ( Config::own() as $destination ) {
			$labels[ $destination['id'] ] = $destination['label'];
		}
		$renders = Visitor::server_renders();
		return array(
			'labels'  => $labels,
			'badge'   => self::badge_label( '%s' ),
			'cookie'  => Visitor::COOKIE,
			'seen'    => Visitor::SEEN,
			'checked' => Visitor::CHECKED,
			'renders' => $renders,
			'shown'   => $renders ? '' : ( Visitor::fallback()['id'] ?? '' ),
		);
	}

	/**
	 * Head script (before any style is painted). When the cache does not vary by the
	 * cookie, it writes the style that hides what does not ship to the visitor's
	 * destination: three rules for that destination only (ids are ISO codes, checked
	 * against the configuration). If the page is printed for another destination, the
	 * free shipping texts (`data-lc-free`) wait hidden, in their place, until locale.js
	 * writes the visitor's.
	 */
	public static function head(): void {
		if ( ! self::applies() ) {
			return;
		}
		$script = '(function(d,c){var g=function(n){var m=c.cookie.match(new RegExp("(?:^|; )"+n+"=([^;]*)"));return m?decodeURIComponent(m[1]):""};'
			. 'var L=window.lachinata=Object.assign(window.lachinata||{},{});var o=' . wp_json_encode( self::data() ) . ';o.cookieValue=g;'
			. 'o.current=o.labels[g(o.cookie)]?g(o.cookie):"";'
			. 'o.label=function(el){if(o.current&&el){var s=el.querySelector("[data-lc-locale-label]");if(s){var t=c.createElement("span");t.textContent=o.labels[o.current];s.innerHTML=o.badge.replace("%s",t.innerHTML)}}};'
			. 'o.hide=function(id){if(o.renders||!o.labels[id])return;var s=c.getElementById("lc-locale-catalog")||c.head.appendChild(c.createElement("style"));s.id="lc-locale-catalog";'
			. 's.textContent=".lc-unshippable[data-lc-only]{display:none}[data-lc-no~=\""+id+"\"]{display:none!important}.lc-unshippable[data-lc-only~=\""+id+"\"]{display:grid}body:has(.lc-unshippable[data-lc-only~=\""+id+"\"]) :is(#lc-buy,.lc-buy__other,.lc-buy__stock,[data-lc-sticky]){display:none!important}"};'
			. 'L.locale=o;if(o.current){d.setAttribute("data-lc-destino",o.current);o.hide(o.current);if(!o.renders&&o.current!==o.shown){var f=c.head.appendChild(c.createElement("style"));f.id="lc-locale-free";f.textContent="[data-lc-free]{visibility:hidden}"}}else if(!g(o.seen)){d.setAttribute("data-lc-locale-pending","")}'
			. '})(document.documentElement,document);';
		if ( ! Visitor::server_renders() ) {
			echo '<style id="lc-locale-catalog">.lc-unshippable[data-lc-only]{display:none}</style>' . "\n";
		}
		echo '<script id="lc-locale-head">' . $script . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed code and JSON.
	}

	/**
	 * The picker's script.
	 */
	public static function enqueue(): void {
		if ( ! self::applies() ) {
			return;
		}
		wp_enqueue_script( self::SCRIPT, plugins_url( 'assets/locale.js', __FILE__ ), array( 'wp-i18n' ), LACHINATA_CORE_VERSION, array( 'strategy' => 'defer' ) );
		wp_set_script_translations( self::SCRIPT, 'lachinata-core', LACHINATA_CORE_DIR . '/languages' );
		wp_add_inline_script(
			self::SCRIPT,
			'window.lachinataLocale = ' . wp_json_encode(
				array(
					'endpoint' => rest_url( Rest::NAMESPACE . Rest::ROUTE ),
					'stores'   => self::store_names(),
					'labels'   => array_column( Config::destinations(), 'label', 'id' ),
				)
			) . ';',
			'before'
		);
	}

	/**
	 * Names of the shops of every destination ('' for this one), for «Ir a la tienda de…».
	 *
	 * @return array<string, string>
	 */
	private static function store_names(): array {
		$out = array();
		foreach ( Config::destinations() as $destination ) {
			$store                     = '' === $destination['store'] ? null : Config::store( $destination['store'] );
			$out[ $destination['id'] ] = null === $store ? '' : $store['name'];
		}
		return $out;
	}

	/**
	 * «Envío a %s» with the part that hides below 480 px.
	 *
	 * @param string $label Destination, already escaped.
	 */
	private static function badge_label( string $label ): string {
		return wp_kses(
			sprintf(
				/* translators: %s: destination («España · Península»). The span is hidden on small screens. */
				__( '<span class="lc-mbadge__pre">Envío a </span>%s', 'lachinata-core' ),
				$label
			),
			array( 'span' => array( 'class' => true ) )
		);
	}

	/**
	 * An icon of the theme's sprite.
	 *
	 * @param string $name Icon.
	 */
	private static function icon( string $name ): string {
		return '<svg class="lc-icon lc-icon--sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><use href="#lc-icon-' . esc_attr( $name ) . '"></use></svg>';
	}

	/**
	 * The destination the page is printed with: the visitor's when the server renders for
	 * it, otherwise the one of the default zone (the head script corrects it).
	 *
	 * @return array{id: string, label: string, note: string, store: string, list: string, states: string[]}|null
	 */
	private static function shown(): ?array {
		return Visitor::rendered() ?? Visitor::fallback();
	}

	/**
	 * MarketBadge, which opens the picker.
	 */
	public static function badge(): void {
		$destination = self::shown();
		if ( null === $destination ) {
			return;
		}
		$languages = Services::languages();
		$lang      = '';
		if ( count( $languages->languages() ) > 1 ) {
			$locale = determine_locale();
			$lang   = sprintf(
				'<span class="lc-mbadge__lang" aria-label="%1$s">%2$s</span>',
				/* translators: %s: language name («Español»). */
				esc_attr( sprintf( __( 'Idioma: %s', 'lachinata-core' ), $languages->label( $locale ) ) ),
				esc_html( strtoupper( substr( $locale, 0, 2 ) ) )
			);
		}
		printf(
			'<button type="button" class="lc-mbadge" aria-haspopup="dialog" data-lc-open="market">%1$s<span data-lc-locale-label>%2$s</span>%3$s%4$s</button><script>window.lachinata&&lachinata.locale&&lachinata.locale.label(document.currentScript.previousElementSibling)</script>',
			self::icon( 'pin' ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup.
			self::badge_label( esc_html( $destination['label'] ) ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_kses().
			$lang, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above.
			self::icon( 'chevron-down' ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup.
		);
	}

	/**
	 * «Cambiar destino» in the legal line of the footer: opens the picker; without
	 * JavaScript, the page with the picker open.
	 */
	public static function footer_link(): void {
		printf(
			'<a href="%1$s" data-lc-open="market">%2$s</a>',
			esc_url( self::open_url() ),
			esc_html__( 'Cambiar destino', 'lachinata-core' )
		);
	}

	/**
	 * The current page with the picker open (without JavaScript).
	 */
	public static function open_url(): string {
		return add_query_arg( Chooser::OPEN, 'elegir', home_url( self::path() ) );
	}

	/**
	 * Path of the current page relative to the home.
	 */
	private static function path(): string {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/';
		return Chooser::return_path( $uri );
	}

	/**
	 * A note of the picker: `{envio_gratis}` becomes the threshold of the destination.
	 *
	 * @param array{id: string, note: string, store: string, states: string[]} $destination Destination.
	 */
	public static function note( array $destination ): string {
		$note = $destination['note'];
		if ( ! str_contains( $note, '{envio_gratis}' ) ) {
			return $note;
		}
		$rules     = '' === $destination['store'] ? Services::shipping_rules() : null;
		$threshold = null === $rules ? null : $rules->free_shipping_from( Config::location( $destination ) );
		return null === $threshold ? '' : str_replace( '{envio_gratis}', Rest::plain_price( $threshold ), $note );
	}

	/**
	 * The layer with MarketPicker: a POST form that works without JavaScript too. Printed
	 * closed (it is the same for everyone); open when the address asks for it.
	 */
	public static function layer(): void {
		if ( ! self::applies() ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only opens the picker.
		$open    = isset( $_GET[ Chooser::OPEN ] );
		$current = self::shown();
		$main    = array_values( array_filter( Config::destinations(), static fn( array $d ): bool => 'main' === $d['list'] ) );
		$more    = array_values( array_filter( Config::destinations(), static fn( array $d ): bool => 'more' === $d['list'] ) );
		$value   = null === $current ? ( $main[0]['id'] ?? '' ) : $current['id'];
		$in_main = in_array( $value, array_column( $main, 'id' ), true );
		$close   = home_url( self::path() );
		$langs   = Services::languages();
		?>
		<div class="lc-layer lc-layer--sheet lc-layer--dialog" data-lc-layer="market" id="lc-market"<?php echo $open ? '' : ' hidden'; ?>>
			<a class="lc-layer__overlay" href="<?php echo esc_url( $close ); ?>" data-lc-close tabindex="-1" aria-hidden="true"></a>
			<div class="lc-sheet" role="dialog" aria-modal="true" aria-labelledby="lc-market-title" tabindex="-1">
				<div class="lc-sheet__grab" aria-hidden="true"></div>
				<div class="lc-sheet__head">
					<span></span>
					<a class="lc-btn lc-btn--icon" href="<?php echo esc_url( $close ); ?>" aria-label="<?php esc_attr_e( 'Cerrar', 'lachinata-core' ); ?>" data-lc-close><?php echo self::icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup. ?></a>
				</div>
				<div class="lc-sheet__body">
					<form class="lc-market" method="post" action="<?php echo esc_url( home_url( '/' ) ); ?>" data-lc-market>
						<input type="hidden" name="<?php echo esc_attr( Chooser::ACTION ); ?>" value="1">
						<input type="hidden" name="lc_ruta" value="<?php echo esc_attr( self::path() ); ?>" data-lc-market-path>
						<fieldset class="lc-market__group">
							<legend class="h3" id="lc-market-title"><?php esc_html_e( '¿Dónde recibes tu pedido?', 'lachinata-core' ); ?></legend>
							<p class="body-sm lc-market__hint" data-lc-market-hint hidden></p>
							<div class="lc-market__list" role="radiogroup" aria-labelledby="lc-market-title">
								<?php foreach ( $main as $destination ) : ?>
									<?php
									$on   = $destination['id'] === $value;
									$note = self::note( $destination );
									?>
									<label class="lc-market__opt<?php echo $on ? ' lc-market__opt--on' : ''; ?>">
										<input type="radio" name="lc_destino" value="<?php echo esc_attr( $destination['id'] ); ?>"<?php checked( $on ); ?>>
										<span class="lc-market__dot" aria-hidden="true"></span>
										<span class="lc-market__text">
											<span class="label"><?php echo esc_html( $destination['label'] ); ?></span>
											<?php if ( '' !== $note ) : ?>
												<span class="body-sm lc-market__note"><?php echo '' === $destination['store'] ? '' : self::icon( 'arrow-right' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup. ?><?php echo esc_html( $note ); ?></span>
											<?php endif; ?>
										</span>
									</label>
								<?php endforeach; ?>
							</div>
							<?php if ( $more ) : ?>
								<div class="lc-field lc-market__more">
									<label for="lc-market-more" class="label"><?php esc_html_e( 'Otro país', 'lachinata-core' ); ?></label>
									<div class="lc-field__box">
										<select id="lc-market-more" name="lc_destino_otro">
											<option value=""><?php esc_html_e( 'Elige un país', 'lachinata-core' ); ?></option>
											<?php foreach ( $more as $destination ) : ?>
												<option value="<?php echo esc_attr( $destination['id'] ); ?>"<?php selected( ! $in_main && $destination['id'] === $value ); ?>><?php echo esc_html( $destination['label'] ); ?></option>
											<?php endforeach; ?>
										</select>
										<?php echo str_replace( 'lc-icon lc-icon--sm', 'lc-icon lc-icon--sm lc-field__chev', self::icon( 'chevron-down' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup. ?>
									</div>
								</div>
							<?php endif; ?>
						</fieldset>
						<?php if ( count( $langs->languages() ) > 1 ) : ?>
							<fieldset class="lc-market__group">
								<legend class="label"><?php esc_html_e( 'Idioma', 'lachinata-core' ); ?></legend>
								<div class="lc-chips" role="radiogroup">
									<?php foreach ( $langs->languages() as $language ) : ?>
										<?php $on = determine_locale() === $language; ?>
										<label class="lc-chip<?php echo $on ? ' lc-chip--on' : ''; ?>"><input type="radio" class="screen-reader-text" name="lc_idioma" value="<?php echo esc_attr( $language ); ?>"<?php checked( $on ); ?>><?php echo esc_html( $langs->label( $language ) ); ?></label>
									<?php endforeach; ?>
								</div>
							</fieldset>
						<?php endif; ?>
						<button type="submit" class="lc-btn button lc-btn--lg lc-btn--block" data-lc-market-submit><?php esc_html_e( 'Continuar', 'lachinata-core' ); ?></button>
					</form>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * The notice of a product that does not ship, with «Cambiar destino» in place of the
	 * buy button. With `$only`, marked with the destinations it applies to (the head style
	 * shows it) and the destination's name filled from the cookie.
	 *
	 * @param string   $label Destination name, '' to fill it in the browser.
	 * @param string[] $only  Destination ids, for pages that are the same for everyone.
	 */
	public static function unshippable( string $label, array $only = array() ): string {
		$name = '<span data-lc-locale-name>' . esc_html( $label ) . '</span>';
		$text = sprintf(
			/* translators: %s: destination («Portugal»). */
			esc_html__( 'No podemos enviar este producto a %s.', 'lachinata-core' ),
			$name
		);
		$html = sprintf(
			'<div class="lc-unshippable"%1$s><div class="lc-notice body-sm lc-notice--warning" role="status">%2$s<span>%3$s</span></div><a class="lc-btn button lc-btn--secondary lc-btn--lg lc-btn--block" href="%4$s" data-lc-open="market">%5$s</a></div>',
			$only ? ' data-lc-only="' . esc_attr( implode( ' ', $only ) ) . '"' : '',
			self::icon( 'alert' ),
			$text,
			esc_url( self::open_url() ),
			esc_html__( 'Cambiar destino', 'lachinata-core' )
		);
		if ( $only ) {
			$html .= '<script>(function(e){var o=window.lachinata&&lachinata.locale;if(o&&o.current){e.querySelector("[data-lc-locale-name]").textContent=o.labels[o.current]}})(document.currentScript.previousElementSibling)</script>';
		}
		return $html;
	}

	/**
	 * The module's cookies in the cookie table (`tracking`), as necessary.
	 *
	 * @param array<int, array<string, mixed>>|mixed $services Services.
	 * @return array<int, array<string, mixed>>|mixed
	 */
	public static function service( $services ) {
		if ( ! is_array( $services ) ) {
			return $services;
		}
		$services[] = array(
			'id'         => 'locale',
			'name'       => __( 'Destino del pedido', 'lachinata-core' ),
			'provider'   => (string) wp_parse_url( home_url(), PHP_URL_HOST ),
			'category'   => 'necessary',
			'configured' => true,
			'cookies'    => array(
				array(
					'name'     => Visitor::COOKIE,
					'purpose'  => __( 'Recuerda dónde recibes tu pedido, para enseñarte lo que se envía allí, el envío gratis y la fecha de entrega.', 'lachinata-core' ),
					'duration' => __( '12 meses', 'lachinata-core' ),
				),
				array(
					'name'     => Visitor::SEEN,
					'purpose'  => __( 'Recuerda que has cerrado el selector de destino sin elegir.', 'lachinata-core' ),
					'duration' => __( 'Sesión', 'lachinata-core' ),
				),
				array(
					'name'     => Visitor::CHECKED,
					'purpose'  => __( 'Recuerda que ya te hemos sugerido la tienda de tu ubicación, para no repetirlo.', 'lachinata-core' ),
					'duration' => __( '12 meses', 'lachinata-core' ),
				),
			),
		);
		return $services;
	}
}
