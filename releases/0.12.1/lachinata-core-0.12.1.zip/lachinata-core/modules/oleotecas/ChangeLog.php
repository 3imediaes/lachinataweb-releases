<?php
/**
 * Record of the changes of the hours of each store.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * Every change of the weekly hours, the specials or the temporary closure of a store, from
 * the partners' API or from WordPress (the editor, WP-CLI): who, when, from where, before
 * and after. One entry per store and request, in the store's meta `_lc_oleotecas_log` (the
 * last 100, newest first), shown in the store's panel in the editor. A change through the
 * API may also be told by email to the address of the settings (`partner_notify_email`).
 *
 * @phpstan-import-type Week from Schedule
 * @phpstan-import-type Special from Schedule
 * @phpstan-type Entry array{at: int, actor: string, source: string, changes: array<string, array{before: mixed, after: mixed}>}
 */
final class ChangeLog {

	/**
	 * Entries kept per store.
	 */
	public const KEEP = 100;

	/**
	 * Fields that are recorded, by meta key.
	 */
	private const FIELDS = array(
		Fields::HOURS   => 'hours',
		Fields::SPECIAL => 'specials',
	);

	/**
	 * Who changes in this request, when it is not the current user (the partners' API).
	 *
	 * @var array{actor: string, source: string}|null
	 */
	private static ?array $context = null;

	/**
	 * Changes of this request not recorded yet, by store.
	 *
	 * @var array<int, array<string, array{before: mixed, after: mixed}>>
	 */
	private static array $pending = array();

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'update_post_metadata', array( self::class, 'before' ), 10, 3 );
		Hooks::add_filter( 'add_post_metadata', array( self::class, 'before' ), 10, 3 );
		Hooks::add_action( 'updated_post_meta', array( self::class, 'after' ), 10, 4 );
		Hooks::add_action( 'added_post_meta', array( self::class, 'after' ), 10, 4 );
		Hooks::add_action( 'shutdown', array( self::class, 'flush' ), 5 );
		Hooks::add_action( 'rest_api_init', array( self::class, 'routes' ) );
	}

	/**
	 * Who makes the changes from now on in this request.
	 *
	 * @param string $actor  Email of the person (X-LC-Actor).
	 * @param string $source Where from: `api`.
	 */
	public static function act_as( string $actor, string $source ): void {
		self::$context = array(
			'actor'  => $actor,
			'source' => $source,
		);
	}

	/**
	 * Back to the current user.
	 */
	public static function reset(): void {
		self::$context = null;
		self::$pending = array();
	}

	/**
	 * Keeps the value of a field before it changes (the filter lets the change go on).
	 *
	 * @param mixed $check   Null to go on.
	 * @param mixed $post_id Post id.
	 * @param mixed $key     Meta key.
	 * @return mixed
	 */
	public static function before( $check, $post_id, $key ) {
		$post_id = (int) $post_id;
		if ( null === $check && isset( self::FIELDS[ (string) $key ] ) && Model::POST_TYPE === get_post_type( $post_id ) && ! isset( self::$pending[ $post_id ][ self::FIELDS[ (string) $key ] ] ) ) {
			self::$pending[ $post_id ][ self::FIELDS[ (string) $key ] ] = array(
				'before' => self::normal( (string) $key, get_post_meta( $post_id, (string) $key, true ) ),
				'after'  => null,
			);
		}
		return $check;
	}

	/**
	 * Keeps the value of a field after it changed.
	 *
	 * @param mixed $meta_id Meta id.
	 * @param mixed $post_id Post id.
	 * @param mixed $key     Meta key.
	 * @param mixed $value   New value.
	 */
	public static function after( $meta_id, $post_id, $key, $value ): void {
		$post_id = (int) $post_id;
		$field   = self::FIELDS[ (string) $key ] ?? null;
		if ( null !== $field && isset( self::$pending[ $post_id ][ $field ] ) ) {
			self::$pending[ $post_id ][ $field ]['after'] = self::normal( (string) $key, $value );
		}
	}

	/**
	 * A field as it is compared and kept: the week with its seven days, the specials valid.
	 *
	 * @param string $key   Meta key.
	 * @param mixed  $value Value.
	 * @return array<mixed>
	 */
	private static function normal( string $key, $value ): array {
		return Fields::HOURS === $key ? Schedule::sanitize_week( $value ) : Schedule::sanitize_specials( $value );
	}

	/**
	 * Writes the entries of this request (at its end, or when the API answers).
	 */
	public static function flush(): void {
		$pending       = self::$pending;
		self::$pending = array();
		foreach ( $pending as $post_id => $fields ) {
			$changes = array_filter( $fields, static fn( array $change ): bool => null !== $change['after'] && $change['before'] !== $change['after'] );
			if ( ! $changes ) {
				continue;
			}
			$entry = array_merge( self::who(), array( 'changes' => $changes ) );
			$log   = self::entries( $post_id );
			array_unshift( $log, $entry );
			update_post_meta( $post_id, Fields::LOG, array_slice( $log, 0, self::KEEP ) );
			if ( 'api' === $entry['source'] ) {
				self::notify( $post_id, $entry );
			}
		}
	}

	/**
	 * Who changes: the API's actor, or the user of WordPress (the editor, WP-CLI).
	 *
	 * @return array{at: int, actor: string, source: string}
	 */
	private static function who(): array {
		if ( null !== self::$context ) {
			return array_merge( array( 'at' => time() ), self::$context );
		}
		$user = wp_get_current_user();
		$cli  = defined( 'WP_CLI' ) && WP_CLI;
		return array(
			'at'     => time(),
			'actor'  => $user->exists() ? $user->display_name . ' <' . $user->user_email . '>' : ( $cli ? 'WP-CLI' : '' ),
			'source' => $cli ? 'cli' : 'wp',
		);
	}

	/**
	 * The entries of a store, newest first.
	 *
	 * @param int $post_id Store.
	 * @return list<Entry>
	 */
	public static function entries( int $post_id ): array {
		$log = get_post_meta( $post_id, Fields::LOG, true );
		return is_array( $log ) ? array_values( array_filter( $log, 'is_array' ) ) : array();
	}

	/**
	 * What changed, as people read it: one line per day, the specials and the closure.
	 *
	 * @param array<string, mixed> $changes Changes of an entry.
	 * @return list<array{label: string, before: string, after: string}>
	 */
	public static function describe( array $changes ): array {
		$lines = array();
		if ( isset( $changes['hours'] ) ) {
			$before = Schedule::sanitize_week( $changes['hours']['before'] ?? array() );
			$after  = Schedule::sanitize_week( $changes['hours']['after'] ?? array() );
			foreach ( Schedule::day_names() as $day => $name ) {
				if ( $before[ $day ] !== $after[ $day ] ) {
					$lines[] = array(
						'label'  => $name,
						'before' => Schedule::slots_text( $before[ $day ] ),
						'after'  => Schedule::slots_text( $after[ $day ] ),
					);
				}
			}
		}
		if ( isset( $changes['specials'] ) ) {
			$before = Schedule::sanitize_specials( $changes['specials']['before'] ?? array() );
			$after  = Schedule::sanitize_specials( $changes['specials']['after'] ?? array() );
			$none   = __( 'Ninguno', 'lachinata-core' );
			$closed = array( Schedule::closure( $before ), Schedule::closure( $after ) );
			if ( $closed[0] !== $closed[1] ) {
				$lines[] = array(
					'label'  => __( 'Cierre temporal', 'lachinata-core' ),
					'before' => null === $closed[0] ? $none : self::special_text( $closed[0] + array( 'slots' => array() ) ),
					'after'  => null === $closed[1] ? $none : self::special_text( $closed[1] + array( 'slots' => array() ) ),
				);
			}
			$lists = array( Schedule::without_closure( $before ), Schedule::without_closure( $after ) );
			if ( $lists[0] !== $lists[1] ) {
				$lines[] = array(
					'label'  => __( 'Horarios especiales', 'lachinata-core' ),
					'before' => $lists[0] ? implode( '; ', array_map( array( self::class, 'special_text' ), $lists[0] ) ) : $none,
					'after'  => $lists[1] ? implode( '; ', array_map( array( self::class, 'special_text' ), $lists[1] ) ) : $none,
				);
			}
		}
		return $lines;
	}

	/**
	 * A special as text: «24 dic 2026: 10:00–14:00 (Nochebuena)».
	 *
	 * @param array{from: string, to: string, slots: array<int, mixed>, note: string} $special Special.
	 */
	public static function special_text( array $special ): string {
		$date  = static fn( string $day ): string => (string) wp_date( 'j M Y', (int) strtotime( $day . ' 12:00:00 UTC' ), new \DateTimeZone( 'UTC' ) );
		$dates = $special['from'] === $special['to']
			? $date( $special['from'] )
			/* translators: 1: first day, 2: last day. */
			: sprintf( __( 'del %1$s al %2$s', 'lachinata-core' ), $date( $special['from'] ), $date( $special['to'] ) );
		$text = $dates . ': ' . Schedule::slots_text( array_values( $special['slots'] ) );
		return '' === $special['note'] ? $text : $text . ' (' . $special['note'] . ')';
	}

	/**
	 * Tells the head office of a change made through the API, when there is an address.
	 *
	 * @param int                  $post_id Store.
	 * @param array<string, mixed> $entry   Entry.
	 */
	private static function notify( int $post_id, array $entry ): void {
		$to = sanitize_email( (string) OleotecasModule::setting( 'partner_notify_email' ) );
		if ( '' === $to ) {
			return;
		}
		$name  = (string) get_the_title( $post_id );
		$lines = array(
			/* translators: 1: who («ana@ejemplo.es»), 2: date and time. */
			sprintf( __( '%1$s ha cambiado el horario el %2$s desde el panel de franquicias.', 'lachinata-core' ), $entry['actor'], wp_date( 'j M Y H:i', (int) $entry['at'] ) ),
			'',
		);
		foreach ( self::describe( (array) $entry['changes'] ) as $line ) {
			/* translators: 1: what («Lunes»), 2: before, 3: after. */
			$lines[] = sprintf( __( '%1$s: %2$s → %3$s', 'lachinata-core' ), $line['label'], $line['before'], $line['after'] );
		}
		$lines[] = '';
		$lines[] = (string) get_edit_post_link( $post_id, 'raw' );
		wp_mail(
			$to,
			/* translators: %s: name of the store. */
			sprintf( __( 'Cambio de horario: %s', 'lachinata-core' ), $name ),
			implode( "\n", $lines )
		);
	}

	/**
	 * `GET /lachinata/v1/oleotecas/log/<id>`: the record of a store, for its editors.
	 */
	public static function routes(): void {
		register_rest_route(
			Rest::NAMESPACE,
			'/oleotecas/log/(?P<id>\d+)',
			array(
				'methods'             => 'GET',
				'callback'            => Hooks::rest( array( self::class, 'show' ) ),
				'permission_callback' => Hooks::wrap( static fn( \WP_REST_Request $request ): bool => current_user_can( 'edit_post', (int) $request['id'] ), false ),
			)
		);
	}

	/**
	 * The record of a store, as the panel shows it.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @phpstan-param \WP_REST_Request<array<string, mixed>> $request
	 */
	public static function show( \WP_REST_Request $request ): \WP_REST_Response {
		$out = array();
		foreach ( self::entries( (int) $request['id'] ) as $entry ) {
			$out[] = array(
				'at'      => wp_date( 'j M Y H:i', (int) $entry['at'] ),
				'actor'   => (string) $entry['actor'],
				'source'  => (string) $entry['source'],
				'changes' => self::describe( (array) $entry['changes'] ),
			);
		}
		return new \WP_REST_Response( $out );
	}
}
