<?php
/**
 * Markup of the system's pieces used by the module.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

defined( 'ABSPATH' ) || exit;

/**
 * The HTML of Icon, Button, Chip, OpenStatus, StoreCard, StoreHours, StoreMap and
 * SocialLinks of the bundle (same classes, `aria-*` and roles), printed by the module's
 * templates and dressed by the theme (components.css). The finder's script renders the
 * same card (src/render.js). Every string is escaped here.
 *
 * @phpstan-import-type Week from Schedule
 * @phpstan-import-type Special from Schedule
 */
final class Html {

	/**
	 * Icon of the theme's sprite.
	 *
	 * @param string $name  Icon name.
	 * @param bool   $small Small.
	 */
	public static function icon( string $name, bool $small = false ): string {
		return sprintf(
			'<svg class="lc-icon%1$s" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><use href="#lc-icon-%2$s"></use></svg>',
			$small ? ' lc-icon--sm' : '',
			esc_attr( sanitize_key( $name ) )
		);
	}

	/**
	 * HTML attributes; null and false are left out, true is a bare attribute.
	 *
	 * @param array<string, mixed> $attributes Attributes.
	 */
	public static function attrs( array $attributes ): string {
		$out = '';
		foreach ( $attributes as $name => $value ) {
			if ( null === $value || false === $value ) {
				continue;
			}
			$out .= true === $value ? ' ' . esc_attr( $name ) : sprintf( ' %1$s="%2$s"', esc_attr( $name ), 'href' === $name ? esc_url( (string) $value ) : esc_attr( (string) $value ) );
		}
		return $out;
	}

	/**
	 * Button or link button.
	 *
	 * @param string               $text Text.
	 * @param array<string, mixed> $args variant, size, icon_left, icon, block, href, class, attrs.
	 */
	public static function button( string $text, array $args = array() ): string {
		$variant = (string) ( $args['variant'] ?? 'primary' );
		$size    = (string) ( $args['size'] ?? 'md' );
		$href    = $args['href'] ?? null;
		$classes = array_filter(
			array(
				'lc-btn',
				'button',
				'primary' !== $variant ? 'lc-btn--' . $variant : '',
				'md' !== $size ? 'lc-btn--' . $size : '',
				empty( $args['block'] ) ? '' : 'lc-btn--block',
				(string) ( $args['class'] ?? '' ),
			)
		);
		$attrs   = array_merge(
			array(
				'class' => implode( ' ', $classes ),
				'href'  => $href,
				'type'  => null === $href ? 'button' : null,
			),
			(array) ( $args['attrs'] ?? array() )
		);
		return sprintf(
			'<%1$s%2$s>%3$s%4$s%5$s</%1$s>',
			null === $href ? 'button' : 'a',
			self::attrs( $attrs ),
			empty( $args['icon_left'] ) ? '' : self::icon( (string) $args['icon_left'] ),
			esc_html( $text ),
			empty( $args['icon'] ) ? '' : self::icon( (string) $args['icon'] )
		);
	}

	/**
	 * OpenStatus. The server always prints `unknown` («Consulta el horario»): the page comes
	 * from the cache and the browser computes the state with the store's time zone, in the
	 * same height.
	 *
	 * @param array<string, mixed> $attrs Extra attributes (`data-lc-open`).
	 */
	public static function open_status( array $attrs = array() ): string {
		return sprintf(
			'<span%1$s><span class="lc-open__dot" aria-hidden="true"></span><span class="lc-open__word label">%2$s</span><span class="lc-open__text"></span></span>',
			self::attrs( array_merge( array( 'class' => 'lc-open lc-open--unknown body-sm' ), $attrs ) ),
			esc_html__( 'Consulta el horario', 'lachinata-core' )
		);
	}

	/**
	 * StoreCard of a store in short form (Data::summary).
	 *
	 * @param array<string, mixed> $store Store.
	 * @param array<string, mixed> $args  layout (`media`), actions (bool), distance, list, index.
	 */
	public static function card( array $store, array $args = array() ): string {
		$name   = (string) $store['name'];
		$image  = (string) ( $store['image'] ?? '' );
		$media  = 'media' === ( $args['layout'] ?? '' ) && '' !== $image;
		$status = Schedule::has_hours( (array) ( $store['hours'] ?? array() ) );
		$html   = '';
		if ( $media ) {
			$html .= sprintf( '<div class="lc-store__media"><img src="%s" alt="" loading="lazy" width="400" height="300"></div>', esc_url( $image ) );
		}
		$html    .= '<div class="lc-store__body"><div class="lc-store__head">';
		$html    .= sprintf( '<a href="%1$s" class="lc-store__name h4">%2$s</a>', esc_url( (string) $store['url'] ), esc_html( $name ) );
		$distance = (string) ( $args['distance'] ?? '' );
		if ( '' !== $distance ) {
			$html .= sprintf( '<span class="lc-store__dist body-sm" data-no-translation>%s</span>', esc_html( $distance ) );
		}
		$html .= '</div>';
		$html .= sprintf( '<span class="lc-store__addr body-sm" data-no-translation>%s</span>', esc_html( (string) $store['line'] ) );
		if ( $status ) {
			$html .= self::open_status( array( 'data-lc-open' => '' ) );
		}
		$web = is_array( $store['web'] ?? null ) ? $store['web'] : null;
		if ( $web && '' !== (string) ( $web['url'] ?? '' ) ) {
			$html .= sprintf(
				'<a href="%1$s" class="lc-store__web body-sm" data-lc-store-web>%2$s<span>%3$s <span class="label" data-no-translation>%4$s</span></span></a>',
				esc_url( (string) $web['url'] ),
				self::icon( 'bag', true ),
				esc_html__( 'Tienda online:', 'lachinata-core' ),
				esc_html( (string) $web['label'] )
			);
		}
		if ( false !== ( $args['actions'] ?? true ) ) {
			$html .= '<div class="lc-store__actions">';
			$html .= self::directions_button(
				$store,
				array(
					'variant' => 'secondary',
					'size'    => 'sm',
				)
			);
			if ( '' !== (string) ( $store['phone'] ?? '' ) ) {
				$html .= self::button(
					__( 'Llamar', 'lachinata-core' ),
					array(
						'variant'   => 'ghost',
						'size'      => 'sm',
						'icon_left' => 'phone',
						'href'      => 'tel:' . $store['phone'],
						'attrs'     => array(
							/* translators: %s: store name. */
							'aria-label'         => sprintf( __( 'Llamar a %s', 'lachinata-core' ), $name ),
							'data-lc-store-call' => '',
						),
					)
				);
			}
			$html .= '</div>';
		}
		$html .= '</div>';
		return sprintf(
			'<article%1$s>%2$s</article>',
			self::attrs(
				array(
					'class'         => 'lc-store' . ( $media ? ' lc-store--media' : '' ),
					'data-lc-store' => (string) $store['slug'],
				)
			),
			$html
		);
	}

	/**
	 * «Cómo llegar»: Google Maps; the script switches to Apple Maps on Apple devices.
	 *
	 * @param array<string, mixed> $store Store (short form or Data).
	 * @param array<string, mixed> $args  Button args.
	 */
	public static function directions_button( array $store, array $args = array() ): string {
		$lat = $store['lat'] ?? null;
		$lng = $store['lng'] ?? null;
		$url = null === $lat || null === $lng
			? 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( (string) $store['title'] . ', ' . (string) $store['line'] )
			: 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode( $lat . ',' . $lng );
		return self::button(
			__( 'Cómo llegar', 'lachinata-core' ),
			array_merge(
				array(
					'icon_left' => 'navigation',
					'href'      => $url,
					'attrs'     => array(
						/* translators: %s: store name. */
						'aria-label'         => sprintf( __( 'Cómo llegar a %s', 'lachinata-core' ), (string) $store['name'] ),
						'data-lc-directions' => wp_json_encode(
							array(
								'lat'   => $lat,
								'lng'   => $lng,
								'title' => (string) $store['title'],
								'line'  => (string) $store['line'],
							)
						),
						'target'             => '_blank',
						'rel'                => 'noopener',
					),
				),
				$args
			)
		);
	}

	/**
	 * StoreHours: a real table, today marked by the script (the store's time zone), the
	 * special days below.
	 *
	 * @param array<string, mixed> $week     Week.
	 * @phpstan-param Week $week
	 * @param array<int, mixed>    $specials Upcoming specials.
	 * @phpstan-param list<Special> $specials
	 * @param string               $caption  Caption ('' for none).
	 */
	public static function hours( array $week, array $specials, string $caption = '' ): string {
		$names = Schedule::day_names();
		$rows  = '';
		foreach ( Schedule::DAYS as $day ) {
			$slots = $week[ $day ] ?? array();
			$cells = '';
			foreach ( $slots as $index => $slot ) {
				$cells .= sprintf(
					'<span class="lc-hours__slot">%1$s%2$s–%3$s</span>',
					$index ? '<span class="lc-hours__y">' . esc_html__( 'y', 'lachinata-core' ) . ' </span>' : '',
					esc_html( $slot[0] ),
					esc_html( $slot[1] )
				);
			}
			$rows .= sprintf(
				'<tr%1$s data-lc-day="%2$s"><th scope="row">%3$s</th><td>%4$s</td></tr>',
				$slots ? '' : ' class="lc-hours__closed"',
				esc_attr( $day ),
				esc_html( $names[ $day ] ),
				$slots ? $cells : esc_html__( 'Cerrado', 'lachinata-core' )
			);
		}
		$html = sprintf(
			'<table class="lc-hours__table body-sm">%1$s<tbody>%2$s</tbody></table>',
			'' === $caption ? '' : '<caption class="label">' . esc_html( $caption ) . '</caption>',
			$rows
		);
		if ( $specials ) {
			$items = '';
			foreach ( $specials as $special ) {
				$items .= sprintf(
					'<li data-lc-special-to="%1$s"><span>%2$s</span><span>%3$s</span></li>',
					esc_attr( $special['to'] ),
					esc_html( self::date_range( $special['from'], $special['to'] ) . ( '' === $special['note'] ? '' : ' · ' . $special['note'] ) ),
					esc_html( Schedule::slots_text( $special['slots'] ) )
				);
			}
			$html .= sprintf(
				'<div class="lc-hours__ex"><span class="label">%1$s</span><ul class="body-sm">%2$s</ul></div>',
				esc_html__( 'Horario especial', 'lachinata-core' ),
				$items
			);
		}
		return '<div class="lc-hours" data-lc-hours>' . $html . '</div>';
	}

	/**
	 * «24 dic» or «10 – 24 ago».
	 *
	 * @param string $from Y-m-d.
	 * @param string $to   Y-m-d.
	 */
	public static function date_range( string $from, string $to ): string {
		$start = strtotime( $from . ' 12:00:00 UTC' );
		$end   = strtotime( $to . ' 12:00:00 UTC' );
		$utc   = new \DateTimeZone( 'UTC' );
		if ( false === $start || false === $end ) {
			return '';
		}
		if ( $from === $to ) {
			return (string) wp_date( 'j M', $start, $utc );
		}
		return gmdate( 'm', $start ) === gmdate( 'm', $end )
			? wp_date( 'j', $start, $utc ) . ' – ' . wp_date( 'j M', $end, $utc )
			: wp_date( 'j M', $start, $utc ) . ' – ' . wp_date( 'j M', $end, $utc );
	}

	/**
	 * StoreMap at rest: the background, the button that loads it and the note.
	 *
	 * @param array<string, mixed> $args height, cta, note, stores (slugs to show), class.
	 */
	public static function map( array $args = array() ): string {
		$note = (string) ( $args['note'] ?? '' );
		return sprintf(
			'<div%1$s><div class="lc-map__tiles" aria-hidden="true"></div><div class="lc-map__idle">%2$s%3$s</div></div>',
			self::attrs(
				array(
					'class'       => trim( 'lc-map ' . (string) ( $args['class'] ?? '' ) ),
					'style'       => empty( $args['height'] ) ? null : 'height:' . (int) $args['height'] . 'px',
					'data-lc-map' => wp_json_encode( (array) ( $args['stores'] ?? array() ) ),
				)
			),
			self::button(
				'' === (string) ( $args['cta'] ?? '' ) ? __( 'Ver en el mapa', 'lachinata-core' ) : (string) $args['cta'],
				array(
					'variant'   => 'secondary',
					'icon_left' => 'map',
					'attrs'     => array( 'data-lc-map-load' => '' ),
				)
			),
			'' === $note ? '' : '<span class="caption lc-map__note">' . esc_html( $note ) . '</span>'
		);
	}

	/**
	 * Note under the map at rest: who serves the tiles (the setting's provider).
	 */
	public static function map_note(): string {
		$provider = trim( (string) OleotecasModule::setting( 'tiles_provider' ) );
		return '' === $provider
			? __( 'El mapa se carga cuando lo pides.', 'lachinata-core' )
			/* translators: %s: providers («OpenStreetMap y CARTO»). */
			: sprintf( __( 'El mapa se carga de %s cuando lo pides.', 'lachinata-core' ), $provider );
	}

	/**
	 * SocialLinks; nothing without profiles.
	 *
	 * @param list<array{network: string, url: string}> $links  Profiles.
	 * @param string                                    $of     Whose («Oleoteca La Chinata Bilbao»).
	 * @param bool                                      $labels Name next to the icon.
	 */
	public static function social( array $links, string $of, bool $labels = false ): string {
		if ( ! $links ) {
			return '';
		}
		$names = array(
			'instagram' => 'Instagram',
			'facebook'  => 'Facebook',
			'tiktok'    => 'TikTok',
			'youtube'   => 'YouTube',
			'x'         => 'X',
			'web'       => __( 'Web', 'lachinata-core' ),
		);
		$items = '';
		foreach ( $links as $link ) {
			$name   = $names[ $link['network'] ] ?? $link['network'];
			$icon   = 'x' === $link['network'] ? 'x-social' : ( 'web' === $link['network'] ? 'globe' : $link['network'] );
			$items .= sprintf(
				'<li><a href="%1$s" class="lc-social__a" rel="noopener" target="_blank"%2$s>%3$s%4$s</a></li>',
				esc_url( $link['url'] ),
				/* translators: 1: network, 2: store. */
				$labels ? '' : ' aria-label="' . esc_attr( sprintf( __( '%1$s de %2$s', 'lachinata-core' ), $name, $of ) ) . '"',
				self::icon( $icon ),
				$labels ? '<span class="body-sm">' . esc_html( $name ) . '</span>' : ''
			);
		}
		return sprintf(
			'<ul class="lc-social%1$s" aria-label="%2$s">%3$s</ul>',
			$labels ? ' lc-social--labels' : '',
			esc_attr__( 'Redes sociales', 'lachinata-core' ),
			$items
		);
	}
}
