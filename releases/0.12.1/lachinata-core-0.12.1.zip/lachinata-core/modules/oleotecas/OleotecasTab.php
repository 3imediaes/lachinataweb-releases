<?php
/**
 * WooCommerce → La Chinata → Oleotecas.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

use LaChinata\Core\Admin\Screen;
use LaChinata\Core\Hooks;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Mode (master or client) and master, names, map, search, contact, sharing, the franchise
 * block, client domains and URLs of the network, the state of the finder's JSON with a
 * button to write it again, and the tokens of the partners' API.
 */
final class OleotecasTab {

	/**
	 * Tab id.
	 */
	public const TAB = 'oleotecas';

	/**
	 * Actions of admin-post.php, also nonce actions and form ids.
	 */
	private const SAVE  = 'lachinata_oleotecas_settings';
	private const JSON  = 'lachinata_oleotecas_json';
	private const TOKEN = 'lachinata_oleotecas_token';

	/**
	 * Transient (per user) with a token just created, shown once.
	 */
	private const SHOWN = 'lachinata_oleotecas_shown_token_';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/core/admin_tabs', array( self::class, 'tab' ), 36 );
		Hooks::add_action( 'admin_post_' . self::SAVE, array( self::class, 'handle' ) );
		Hooks::add_action( 'admin_post_' . self::JSON, array( self::class, 'regenerate' ) );
		Hooks::add_action( 'admin_post_' . self::TOKEN, array( self::class, 'token' ) );
	}

	/**
	 * Adds the tab before Exportar/importar.
	 *
	 * @param array<string, array{label: string, render: callable}> $tabs Tabs.
	 * @return array<string, array{label: string, render: callable}>
	 */
	public static function tab( array $tabs ): array {
		$tab      = array(
			self::TAB => array(
				'label'  => __( 'Oleotecas', 'lachinata-core' ),
				'render' => array( self::class, 'render' ),
			),
		);
		$position = array_search( 'transfer', array_keys( $tabs ), true );
		$position = false === $position ? count( $tabs ) : $position;
		return array_slice( $tabs, 0, $position, true ) + $tab + $tabs;
	}

	/**
	 * Fields of the form, by section: key → label, kind (text, textarea, number, url, email,
	 * lines, secret, select with its options) and hint.
	 *
	 * @return array<string, array<string, array{label: string, kind: string, hint: string, options?: array<string, string>}>>
	 */
	private static function fields(): array {
		return array(
			__( 'Modo', 'lachinata-core' )                 => array(
				'mode'       => array(
					'label'   => __( 'Esta tienda', 'lachinata-core' ),
					'kind'    => 'select',
					'options' => array(
						Source::MASTER => __( 'Maestra: las tiendas se editan aquí', 'lachinata-core' ),
						Source::CLIENT => __( 'Cliente: muestra las tiendas de la maestra', 'lachinata-core' ),
					),
					'hint'    => __( 'En modo cliente no hay fichas ni zonas propias: el buscador enseña las tiendas de la maestra y sus tarjetas llevan a las fichas de la maestra.', 'lachinata-core' ),
				),
				'master_url' => array(
					'label' => __( 'URL de la tienda maestra', 'lachinata-core' ),
					'kind'  => 'url',
					'hint'  => __( 'Solo en modo cliente: https://lachinata.es. Sus tiendas se leen cada hora y se guarda una copia por si no responde.', 'lachinata-core' ),
				),
			),
			__( 'Nombres', 'lachinata-core' )              => array(
				'noun'          => array(
					'label' => __( 'Cómo se llama cada tienda', 'lachinata-core' ),
					'kind'  => 'text',
					'hint'  => __( 'En minúscula y en singular: «oleoteca». Vacío: «tienda».', 'lachinata-core' ),
				),
				'noun_plural'   => array(
					'label' => __( 'En plural', 'lachinata-core' ),
					'kind'  => 'text',
					'hint'  => __( '«oleotecas». Vacío: «tiendas».', 'lachinata-core' ),
				),
				'store_title'   => array(
					'label' => __( 'Nombre largo de cada tienda', 'lachinata-core' ),
					'kind'  => 'text',
					'hint'  => __( 'Va en el título de la ficha y en el buscador de Google. {name} es el nombre corto y {brand} el nombre comercial: «Oleoteca La Chinata {name}». Vacío: el nombre corto.', 'lachinata-core' ),
				),
				'archive_title' => array(
					'label' => __( 'Título del buscador', 'lachinata-core' ),
					'kind'  => 'text',
					'hint'  => __( '«Oleotecas La Chinata». Las zonas añaden «en Madrid».', 'lachinata-core' ),
				),
				'archive_lead'  => array(
					'label' => __( 'Entradilla del buscador', 'lachinata-core' ),
					'kind'  => 'textarea',
					'hint'  => __( '{stores} es el número de tiendas («39 oleotecas») y {countries} el de países.', 'lachinata-core' ),
				),
			),
			__( 'Mapa', 'lachinata-core' )                 => array(
				'tiles_url'         => array(
					'label' => __( 'Teselas', 'lachinata-core' ),
					'kind'  => 'text',
					'hint'  => __( 'Plantilla de URL de Leaflet ({s}, {z}, {x}, {y}, {r}); {key} es la clave de abajo. De serie, CARTO Positron, que pide clave.', 'lachinata-core' ),
				),
				'tiles_key'         => array(
					'label' => __( 'Clave de las teselas', 'lachinata-core' ),
					'kind'  => 'secret',
					'hint'  => __( 'La del proveedor (CARTO: gratis para uso comercial hasta 1 millón de peticiones al mes). Es de este sitio: no va en la exportación. Si la URL la pide y falta, no se ofrece el mapa.', 'lachinata-core' ),
				),
				'tiles_attribution' => array(
					'label' => __( 'Atribución', 'lachinata-core' ),
					'kind'  => 'text',
					'hint'  => __( 'Obligatoria y siempre visible en el mapa. Admite enlaces.', 'lachinata-core' ),
				),
				'tiles_provider'    => array(
					'label' => __( 'Proveedores (nota del mapa)', 'lachinata-core' ),
					'kind'  => 'text',
					'hint'  => __( '«El mapa se carga de OpenStreetMap y CARTO cuando lo pides.»', 'lachinata-core' ),
				),
				'tiles_company'     => array(
					'label' => __( 'Empresa de las teselas', 'lachinata-core' ),
					'kind'  => 'text',
					'hint'  => __( 'Sale en la política de privacidad como proveedor (no pone cookies).', 'lachinata-core' ),
				),
				'tiles_privacy_url' => array(
					'label' => __( 'Su política de privacidad', 'lachinata-core' ),
					'kind'  => 'url',
					'hint'  => '',
				),
			),
			__( 'Búsqueda', 'lachinata-core' )             => array(
				'near_km'          => array(
					'label' => __( 'Distancia de «cerca» (km)', 'lachinata-core' ),
					'kind'  => 'number',
					'hint'  => __( '«Otras oleotecas cerca» en la ficha.', 'lachinata-core' ),
				),
				'geocoder_url'     => array(
					'label' => __( 'Geocodificador', 'lachinata-core' ),
					'kind'  => 'url',
					'hint'  => __( 'API de búsqueda compatible con Nominatim. Se llama desde el servidor, una petición por segundo y con caché.', 'lachinata-core' ),
				),
				'geocoder_contact' => array(
					'label' => __( 'Contacto para el geocodificador', 'lachinata-core' ),
					'kind'  => 'email',
					'hint'  => __( 'Va en el User-Agent, como pide la política de uso de Nominatim.', 'lachinata-core' ),
				),
			),
			__( 'Contacto y compartir', 'lachinata-core' ) => array(
				'whatsapp_text' => array(
					'label' => __( 'Texto de inicio de WhatsApp', 'lachinata-core' ),
					'kind'  => 'text',
					'hint'  => __( '{site} es el dominio de esta tienda: «Hola, os escribo desde {site}».', 'lachinata-core' ),
				),
				'og_image'      => array(
					'label' => __( 'Imagen para compartir (ID)', 'lachinata-core' ),
					'kind'  => 'number',
					'hint'  => __( 'ID de la imagen de la biblioteca que se ve al compartir una página sin fotos.', 'lachinata-core' ),
				),
			),
			__( 'Bloque de franquicias', 'lachinata-core' ) => array(
				'franchise_eyebrow' => array(
					'label' => __( 'Antetítulo', 'lachinata-core' ),
					'kind'  => 'text',
					'hint'  => '',
				),
				'franchise_title'   => array(
					'label' => __( 'Título', 'lachinata-core' ),
					'kind'  => 'text',
					'hint'  => __( 'Sin título o sin enlace, el bloque no sale.', 'lachinata-core' ),
				),
				'franchise_text'    => array(
					'label' => __( 'Texto', 'lachinata-core' ),
					'kind'  => 'textarea',
					'hint'  => '',
				),
				'franchise_url'     => array(
					'label' => __( 'Enlace', 'lachinata-core' ),
					'kind'  => 'url',
					'hint'  => '',
				),
				'franchise_cta'     => array(
					'label' => __( 'Texto del botón', 'lachinata-core' ),
					'kind'  => 'text',
					'hint'  => '',
				),
			),
			__( 'Tiendas cliente y URL', 'lachinata-core' ) => array(
				'client_domains' => array(
					'label' => __( 'Dominios cliente', 'lachinata-core' ),
					'kind'  => 'lines',
					'hint'  => __( 'Uno por línea (lachinatacanarias.es). Solo ellos pueden leer los datos desde el navegador (CORS).', 'lachinata-core' ),
				),
				'slug_single'    => array(
					'label' => __( 'URL de cada tienda', 'lachinata-core' ),
					'kind'  => 'text',
					'hint'  => __( '/oleoteca/{slug}/. Cambiarla cambia todas las URL: no se toca en un sitio publicado.', 'lachinata-core' ),
				),
				'slug_archive'   => array(
					'label' => __( 'URL del buscador y las zonas', 'lachinata-core' ),
					'kind'  => 'text',
					'hint'  => __( '/oleotecas/ y /oleotecas/{zona}/.', 'lachinata-core' ),
				),
			),
			__( 'API de socios', 'lachinata-core' )        => array(
				'partner_notify_email' => array(
					'label' => __( 'Avisar de los cambios a', 'lachinata-core' ),
					'kind'  => 'email',
					'hint'  => __( 'Un correo a esta dirección cada vez que una franquicia cambia su horario desde el panel. Vacío: sin aviso (el registro de cambios de cada tienda se guarda igual).', 'lachinata-core' ),
				),
			),
		);
	}

	/**
	 * Prints the tab.
	 */
	public static function render(): void {
		$module = OleotecasModule::instance();
		if ( null === $module ) {
			return;
		}
		$values = Settings::all( $module );
		$state  = Data::current();
		?>
		<p>
			<?php esc_html_e( 'Cada tienda se edita en Oleotecas (menú de la izquierda): dirección con su marcador, horario, especiales, fotos, redes y favoritos. Las zonas, en Oleotecas → Zonas, con su texto y sus preguntas.', 'lachinata-core' ); ?>
			<a href="<?php echo esc_url( Screen::guide_url( 'oleotecas' ) ); ?>"><?php esc_html_e( 'Guía', 'lachinata-core' ); ?></a>
		</p>
		<h2><?php esc_html_e( 'Datos del buscador', 'lachinata-core' ); ?></h2>
		<p>
			<?php
			if ( null === $state ) {
				esc_html_e( 'Aún no se ha escrito el JSON.', 'lachinata-core' );
			} else {
				printf(
					/* translators: 1: «39 oleotecas», 2: date, 3: URL. */
					esc_html__( '%1$s, escrito el %2$s: %3$s', 'lachinata-core' ),
					esc_html( Texts::count( $state['count'] ) ),
					esc_html( (string) wp_date( 'j M Y H:i', $state['at'] ) ),
					'<a href="' . esc_url( $state['url'] ) . '" data-no-translation>' . esc_html( $state['file'] ) . '</a>'
				);
			}
			?>
		</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::JSON ); ?>">
			<?php wp_nonce_field( self::JSON ); ?>
			<?php submit_button( __( 'Volver a escribir el JSON', 'lachinata-core' ), 'secondary', 'submit', false ); ?>
		</form>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE ); ?>">
			<?php wp_nonce_field( self::SAVE ); ?>
			<?php foreach ( self::fields() as $section => $fields ) : ?>
				<h2><?php echo esc_html( $section ); ?></h2>
				<table class="form-table" role="presentation">
					<?php foreach ( $fields as $key => $field ) : ?>
						<?php
						$id    = 'lc-oleotecas-' . $key;
						$value = $values[ $key ] ?? '';
						?>
						<tr>
							<th scope="row"><label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $field['label'] ); ?></label></th>
							<td>
								<?php if ( 'select' === $field['kind'] ) : ?>
									<select id="<?php echo esc_attr( $id ); ?>" name="oleotecas[<?php echo esc_attr( $key ); ?>]" aria-describedby="<?php echo esc_attr( $id ); ?>-hint">
										<?php foreach ( (array) ( $field['options'] ?? array() ) as $option => $label ) : ?>
											<option value="<?php echo esc_attr( (string) $option ); ?>"<?php selected( (string) $value, (string) $option ); ?>><?php echo esc_html( $label ); ?></option>
										<?php endforeach; ?>
									</select>
								<?php elseif ( 'textarea' === $field['kind'] || 'lines' === $field['kind'] ) : ?>
									<textarea class="large-text" rows="3" id="<?php echo esc_attr( $id ); ?>" name="oleotecas[<?php echo esc_attr( $key ); ?>]" aria-describedby="<?php echo esc_attr( $id ); ?>-hint"><?php echo esc_textarea( is_array( $value ) ? implode( "\n", $value ) : (string) $value ); ?></textarea>
								<?php elseif ( 'secret' === $field['kind'] ) : ?>
									<input type="password" class="regular-text" id="<?php echo esc_attr( $id ); ?>" name="oleotecas[<?php echo esc_attr( $key ); ?>]" value="" autocomplete="off" placeholder="<?php echo '' !== (string) $value ? esc_attr__( 'Guardada (escribe otra para cambiarla)', 'lachinata-core' ) : ''; ?>" aria-describedby="<?php echo esc_attr( $id ); ?>-hint">
								<?php else : ?>
									<input type="<?php echo esc_attr( $field['kind'] ); ?>" class="<?php echo 'number' === $field['kind'] ? 'small-text' : 'large-text'; ?>" id="<?php echo esc_attr( $id ); ?>" name="oleotecas[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( (string) $value ); ?>" aria-describedby="<?php echo esc_attr( $id ); ?>-hint">
								<?php endif; ?>
								<?php if ( '' !== $field['hint'] ) : ?>
									<p class="description" id="<?php echo esc_attr( $id ); ?>-hint"><?php echo esc_html( $field['hint'] ); ?></p>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</table>
			<?php endforeach; ?>
			<?php submit_button(); ?>
		</form>
		<?php
		if ( ! Source::client() ) {
			self::render_tokens();
		}
	}

	/**
	 * Tokens of the partners' API: the one just created (once), the list with rotate and
	 * revoke, and a form for a new one.
	 */
	private static function render_tokens(): void {
		$shown = get_transient( self::SHOWN . get_current_user_id() );
		delete_transient( self::SHOWN . get_current_user_id() );
		$action = static function ( string $what, string $id, string $label, string $type ): void {
			?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::TOKEN ); ?>">
				<input type="hidden" name="do" value="<?php echo esc_attr( $what ); ?>">
				<input type="hidden" name="id" value="<?php echo esc_attr( $id ); ?>">
				<?php wp_nonce_field( self::TOKEN ); ?>
				<?php submit_button( $label, $type, 'submit', false ); ?>
			</form>
			<?php
		};
		?>
		<h2 id="lc-oleotecas-tokens"><?php esc_html_e( 'Tokens de la API de socios', 'lachinata-core' ); ?></h2>
		<p><?php esc_html_e( 'El panel de franquicias lee y cambia con ellos el horario, los días especiales y el cierre temporal de cada tienda (nada más). Cada cambio queda en el registro de la tienda. El token se ve una sola vez; al rotarlo, el anterior sigue valiendo 24 horas.', 'lachinata-core' ); ?>
			<a href="<?php echo esc_url( Screen::guide_url( 'oleotecas' ) ); ?>"><?php esc_html_e( 'Contrato de la API', 'lachinata-core' ); ?></a>
		</p>
		<?php if ( is_string( $shown ) && '' !== $shown ) : ?>
			<div class="notice notice-warning inline">
				<p><strong><?php esc_html_e( 'Copia el token ahora: no se volverá a mostrar.', 'lachinata-core' ); ?></strong></p>
				<p><input type="text" class="large-text code" readonly value="<?php echo esc_attr( $shown ); ?>" aria-label="<?php esc_attr_e( 'Token nuevo', 'lachinata-core' ); ?>" onfocus="this.select()" data-no-translation></p>
			</div>
		<?php endif; ?>
		<?php if ( Partners::all() ) : ?>
			<table class="widefat striped">
				<thead>
					<tr>
						<th scope="col"><?php esc_html_e( 'Nombre', 'lachinata-core' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Termina en', 'lachinata-core' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Creado', 'lachinata-core' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Último uso', 'lachinata-core' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Estado', 'lachinata-core' ); ?></th>
						<th scope="col"><span class="screen-reader-text"><?php esc_html_e( 'Acciones', 'lachinata-core' ); ?></span></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( Partners::all() as $token ) : ?>
						<tr>
							<td><?php echo esc_html( $token['name'] ); ?></td>
							<td><code data-no-translation>…<?php echo esc_html( $token['hint'] ); ?></code></td>
							<td><?php echo esc_html( (string) wp_date( 'j M Y H:i', $token['created'] ) ); ?></td>
							<td><?php echo $token['used'] ? esc_html( (string) wp_date( 'j M Y H:i', $token['used'] ) ) : esc_html__( 'Nunca', 'lachinata-core' ); ?></td>
							<td>
								<?php
								echo $token['expires']
									/* translators: %s: date. */
									? esc_html( sprintf( __( 'Rotado: vale hasta el %s', 'lachinata-core' ), wp_date( 'j M H:i', $token['expires'] ) ) )
									: esc_html__( 'Activo', 'lachinata-core' );
								?>
							</td>
							<td>
								<?php
								if ( ! $token['expires'] ) {
									$action( 'rotate', $token['id'], __( 'Rotar', 'lachinata-core' ), 'secondary' );
								}
								$action( 'revoke', $token['id'], __( 'Revocar', 'lachinata-core' ), 'delete' );
								?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::TOKEN ); ?>">
			<input type="hidden" name="do" value="create">
			<?php wp_nonce_field( self::TOKEN ); ?>
			<p>
				<label for="lc-oleotecas-token-name"><?php esc_html_e( 'Nombre del token nuevo', 'lachinata-core' ); ?></label>
				<input type="text" class="regular-text" id="lc-oleotecas-token-name" name="name" placeholder="<?php esc_attr_e( 'Panel de oleotecas', 'lachinata-core' ); ?>">
				<?php submit_button( __( 'Crear token', 'lachinata-core' ), 'secondary', 'submit', false ); ?>
			</p>
		</form>
		<?php
	}

	/**
	 * Creates, rotates or revokes a token.
	 */
	public static function token(): void {
		Screen::check( self::TOKEN );
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Screen::check().
		$do   = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( (string) $_POST['do'] ) ) : '';
		$id   = isset( $_POST['id'] ) ? sanitize_key( wp_unslash( (string) $_POST['id'] ) ) : '';
		$name = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['name'] ) ) : '';
		// phpcs:enable
		$secret = null;
		if ( 'create' === $do ) {
			$secret = Partners::create( $name );
		} elseif ( 'rotate' === $do ) {
			$secret = Partners::rotate( $id );
		} elseif ( 'revoke' === $do ) {
			Partners::revoke( $id );
			Screen::flash( 'success', array( __( 'Token revocado: deja de valer ahora mismo.', 'lachinata-core' ) ) );
		}
		if ( null !== $secret ) {
			set_transient( self::SHOWN . get_current_user_id(), $secret, 5 * MINUTE_IN_SECONDS );
		}
		Screen::redirect( self::TAB );
	}

	/**
	 * Saves the settings.
	 */
	public static function handle(): void {
		Screen::check( self::SAVE );
		$module = OleotecasModule::instance();
		if ( null === $module ) {
			Screen::redirect( self::TAB );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Screen::check(); each value is sanitized below.
		$posted = isset( $_POST['oleotecas'] ) && is_array( $_POST['oleotecas'] ) ? (array) wp_unslash( $_POST['oleotecas'] ) : array();
		$slugs  = array( Model::single_slug(), Model::archive_slug(), Source::mode() );
		foreach ( self::fields() as $fields ) {
			foreach ( $fields as $key => $field ) {
				$raw = is_scalar( $posted[ $key ] ?? null ) ? (string) $posted[ $key ] : '';
				if ( 'select' === $field['kind'] ) {
					$value = array_key_exists( $raw, (array) ( $field['options'] ?? array() ) ) ? $raw : (string) array_key_first( (array) ( $field['options'] ?? array() ) );
					Settings::set( $module, $key, $value );
					continue;
				}
				if ( 'secret' === $field['kind'] ) {
					// Empty keeps the saved one.
					if ( '' !== trim( $raw ) ) {
						Settings::set( $module, $key, sanitize_text_field( trim( $raw ) ) );
					}
					continue;
				}
				switch ( $field['kind'] ) {
					case 'number':
						$value = absint( $raw );
						break;
					case 'url':
						$value = esc_url_raw( trim( $raw ) );
						break;
					case 'email':
						$value = sanitize_email( $raw );
						break;
					case 'textarea':
						$value = sanitize_textarea_field( $raw );
						break;
					case 'lines':
						$value = array_values( array_filter( array_map( 'sanitize_text_field', preg_split( '/[\r\n,]+/', $raw ) ? preg_split( '/[\r\n,]+/', $raw ) : array() ) ) );
						break;
					default:
						$value = 'tiles_attribution' === $key ? wp_kses( $raw, array( 'a' => array( 'href' => array() ) ) ) : sanitize_text_field( $raw );
				}
				if ( in_array( $key, array( 'slug_single', 'slug_archive' ), true ) ) {
					$value = sanitize_title( (string) $value );
				}
				Settings::set( $module, $key, $value );
			}
		}
		if ( array( Model::single_slug(), Model::archive_slug(), Source::mode() ) !== $slugs ) {
			update_option( 'rewrite_rules', '' );
		}
		Data::touch();
		Screen::flash( 'success', array( __( 'Ajustes de oleotecas guardados.', 'lachinata-core' ) ) );
		Screen::redirect( self::TAB );
	}

	/**
	 * Writes the JSON again.
	 */
	public static function regenerate(): void {
		Screen::check( self::JSON );
		$state = Data::write();
		Screen::flash(
			null === $state ? 'error' : 'success',
			array( null === $state ? __( 'No se pudo escribir el JSON en uploads.', 'lachinata-core' ) : __( 'JSON escrito de nuevo.', 'lachinata-core' ) )
		);
		Screen::redirect( self::TAB );
	}
}
