<?php
/**
 * The shipping rules as a service for other modules.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping;

use LaChinata\Core\Contracts\ShippingRules;

defined( 'ABSPATH' ) || exit;

/**
 * Serves Contracts\ShippingRules through `lachinata/shipping/service` while the module is on.
 */
final class Rules implements ShippingRules {

	/**
	 * Whether a product can ship to a destination.
	 *
	 * @param \WC_Product                                               $product     Product or variation.
	 * @param array{country: string, state?: string, postcode?: string} $destination Destination.
	 * @return true|string
	 */
	public function shippable( \WC_Product $product, array $destination ): true|string {
		return Shippable::check( $product, $destination );
	}

	/**
	 * Zone used when the visitor's destination is not known.
	 */
	public function default_zone_id(): int {
		return Config::default_zone_id();
	}

	/**
	 * Free shipping threshold of the destination's zone.
	 *
	 * @param array{country: string, state?: string, postcode?: string} $destination Destination.
	 */
	public function free_shipping_from( array $destination ): ?float {
		return Config::threshold_for( $destination );
	}
}
