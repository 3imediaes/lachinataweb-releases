<?php
/**
 * Catalog data as the templates need it. Everything that changes between stores
 * (tints, unit price, tabs, seals, badges) comes through lachinata/… filters with a
 * neutral default, so the theme works with plain WooCommerce.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Tint of a product category ('' = no tint, surface-2 / surface-3 backgrounds).
 *
 * @param WP_Term $term Category.
 */
function lachinata_category_tint( WP_Term $term ): string {
	/**
	 * Tint of a product category: cosmetica, aceites, gourmet, regalos, hogar or ''.
	 *
	 * @since 0.2.0
	 *
	 * @param string  $tint Tint ('' by default).
	 * @param WP_Term $term Category.
	 */
	return (string) apply_filters( 'lachinata/category/tint', '', $term );
}

/**
 * Tint of a product.
 *
 * @param WC_Product $product Product.
 */
function lachinata_product_tint( WC_Product $product ): string {
	/**
	 * Tint of a product, used behind its photo and in the cart line.
	 *
	 * @since 0.2.0
	 *
	 * @param string     $tint    Tint ('' by default).
	 * @param WC_Product $product Product.
	 */
	return (string) apply_filters( 'lachinata/product/tint', '', $product );
}

/**
 * Content of a product as written on its label: «500 ml», «300 g».
 *
 * @param WC_Product $product Product or variation.
 */
function lachinata_product_content( WC_Product $product ): string {
	/**
	 * Content of a product («500 ml»), shown in the order lines of the emails.
	 *
	 * @since 0.8.0
	 *
	 * @param string     $content Content ('' by default).
	 * @param WC_Product $product Product or variation.
	 */
	return (string) apply_filters( 'lachinata/product/content', '', $product );
}

/**
 * Unit price line: «500 ml | 9,33 € / 1 l».
 *
 * @param WC_Product $product Product or variation.
 * @return string HTML.
 */
function lachinata_unit_price( WC_Product $product ): string {
	/**
	 * Content and price per reference quantity of a product or variation.
	 *
	 * @since 0.2.0
	 *
	 * @param string     $html    HTML ('' by default: nothing is shown).
	 * @param WC_Product $product Product or variation.
	 */
	return (string) apply_filters( 'lachinata/product/unit_price', '', $product );
}

/**
 * Price shown for a product: the lowest variation price for variable products.
 *
 * @param WC_Product $product Product.
 * @return string HTML.
 */
function lachinata_display_price( WC_Product $product ): string {
	$price = $product instanceof WC_Product_Variable ? $product->get_variation_price( 'min', true ) : wc_get_price_to_display( $product );
	return wc_price( (float) $price );
}

/**
 * Tax note under prices: WooCommerce's «price display suffix» setting.
 */
function lachinata_price_note(): string {
	$suffix = (string) get_option( 'woocommerce_price_display_suffix', '' );
	return '' === $suffix ? '' : wp_kses_post( $suffix );
}

/**
 * Badges of a product: «-20 %» when it is on sale, then all its product tags (the shop
 * decides how many and which), then what modules add. Cards and the product page show
 * them all, stacked.
 *
 * @param WC_Product $product Product.
 * @return array<int, array{text: string, tone: string, image_id?: int, term_id?: int}>
 */
function lachinata_product_badges( WC_Product $product ): array {
	$badges = array();
	if ( $product->is_on_sale() ) {
		$regular  = (float) $product->get_regular_price();
		$sale     = (float) $product->get_sale_price();
		$badges[] = array(
			'text' => $regular > 0 && $sale > 0
				/* translators: %s: discount percentage. */
				? sprintf( __( '-%s %%', 'lachinata' ), number_format_i18n( round( ( 1 - $sale / $regular ) * 100 ) ) )
				: __( 'Oferta', 'lachinata' ),
			'tone' => 'promo',
		);
	}
	$tags = get_the_terms( $product->get_id(), 'product_tag' );
	foreach ( is_array( $tags ) ? $tags : array() as $tag ) {
		$badges[] = array(
			'text'     => $tag->name,
			'tone'     => '',
			'image_id' => 0,
			'term_id'  => $tag->term_id,
		);
	}
	/**
	 * Badges of a product card and product page, in the order they are shown. A badge with
	 * `term_id` comes from a product tag (the module `catalog` gives it its tone, image and
	 * order); `image_id` is a small decorative image before the text (since 0.12.2).
	 *
	 * @since 0.2.0
	 *
	 * @param array<int, array{text: string, tone: string, image_id?: int, term_id?: int}> $badges  Badges (tone '' = neutral).
	 * @param WC_Product                                                                   $product Product.
	 */
	return (array) apply_filters( 'lachinata/product_card/badges', $badges, $product );
}

/**
 * Mark of the shipping class of a product on its card («Envío refrigerado» with a
 * snowflake), or null.
 *
 * @param WC_Product $product Product.
 * @return array{icon: string, label: string}|null
 */
function lachinata_product_marker( WC_Product $product ): ?array {
	/**
	 * Mark of a product on its card, in the lower left corner of the photo: an icon of the
	 * sprite and its accessible name. The module `catalog` gives the one of the shipping
	 * class (refrigerated goods).
	 *
	 * @since 0.12.2
	 *
	 * @param array{icon: string, label: string}|null $marker  Null by default (no mark).
	 * @param WC_Product                              $product Product.
	 */
	$marker = apply_filters( 'lachinata/product_card/marker', null, $product );
	return is_array( $marker ) && ! empty( $marker['icon'] ) && ! empty( $marker['label'] )
		? array(
			'icon'  => (string) $marker['icon'],
			'label' => (string) $marker['label'],
		)
		: null;
}

/**
 * Data a ProductCard needs.
 *
 * @param WC_Product $product Product.
 * @param string     $tint    Tint of the listing (the root category being viewed); the
 *                            product's own (its main category) when ''.
 * @return array<string, mixed>
 */
function lachinata_card_data( WC_Product $product, string $tint = '' ): array {
	$badges = lachinata_product_badges( $product );
	$old    = '';
	if ( $product->is_on_sale() && ! $product->is_type( 'variable' ) ) {
		$old = wc_price( (float) wc_get_price_to_display( $product, array( 'price' => $product->get_regular_price() ) ) );
	}
	/**
	 * Photo of a product on its card: another one of the gallery when the featured image is
	 * a setting shot (module `catalog`, «Imagen de tarjeta»).
	 *
	 * @since 0.12.2
	 *
	 * @param int        $image_id Attachment id (the featured image by default).
	 * @param WC_Product $product  Product.
	 */
	$image_id = (int) apply_filters( 'lachinata/product_card/image_id', (int) $product->get_image_id(), $product );
	return array(
		'id'         => $product->get_id(),
		'name'       => $product->get_name(),
		'href'       => $product->get_permalink(),
		'image_id'   => $image_id,
		'tint'       => '' !== $tint ? $tint : lachinata_product_tint( $product ),
		'badges'     => $badges,
		'badge'      => $badges[0] ?? null,
		'marker'     => lachinata_product_marker( $product ),
		'rating'     => wc_review_ratings_enabled() && $product->get_review_count() ? (float) $product->get_average_rating() : null,
		'reviews'    => (int) $product->get_review_count(),
		'meta'       => lachinata_unit_price( $product ),
		'price'      => lachinata_display_price( $product ),
		'price_from' => $product instanceof WC_Product_Variable && $product->get_variation_price( 'min' ) !== $product->get_variation_price( 'max' ),
		'old'        => $old,
		'sold_out'   => ! $product->is_in_stock(),
		'direct_add' => $product->is_type( 'simple' ) && $product->is_purchasable() && $product->is_in_stock() && ! $product->is_sold_individually(),
	);
}

/**
 * Categories of the shop (header, menu, search and home) with their children: the list
 * the shop configures (module `catalog`, with its seasonal campaigns) or, without one,
 * every top-level category in WooCommerce's order. The default «Uncategorized» category
 * is left out by id, not by slug.
 *
 * @return array<int, array{term: WP_Term, tint: string, children: WP_Term[]}>
 */
function lachinata_category_tree(): array {
	static $tree = null;
	if ( null !== $tree ) {
		return $tree;
	}
	/**
	 * Categories of the shop, in order, as term ids. The module `catalog` gives the list
	 * configured in La Chinata → Catálogo, with the campaigns running today.
	 *
	 * @since 0.12.2
	 *
	 * @param int[]|null $ids Null by default: every top-level category with products.
	 */
	$ids     = apply_filters( 'lachinata/catalog/categories', null );
	$parents = is_array( $ids )
		? ( $ids ? get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'include'    => array_map( 'intval', $ids ),
				'hide_empty' => true,
				'orderby'    => 'include',
			)
		) : array() )
		: get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'parent'     => 0,
				'hide_empty' => true,
				'exclude'    => array( (int) get_option( 'default_product_cat', 0 ) ),
				'orderby'    => 'menu_order',
			)
		);
	$tree    = array();
	foreach ( is_array( $parents ) ? $parents : array() as $parent ) {
		$children = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'parent'     => $parent->term_id,
				'hide_empty' => true,
				'orderby'    => 'menu_order',
			)
		);
		$tree[]   = array(
			'term'     => $parent,
			'tint'     => lachinata_category_tint( $parent ),
			'children' => is_array( $children ) ? $children : array(),
		);
	}
	return $tree;
}

/**
 * Link to a term, or '' on error.
 *
 * @param WP_Term $term Term.
 */
function lachinata_term_url( WP_Term $term ): string {
	$link = get_term_link( $term );
	return is_string( $link ) ? $link : '';
}

/**
 * Product photo as an <img> with width/height, or the category halo when there is none.
 *
 * @param int    $image_id   Attachment id.
 * @param string $size       Image size.
 * @param string $halo_class Halo class (lc-card__halo, lc-line__halo…).
 * @param bool   $eager      Load eagerly (first screen).
 * @param string $sizes      Sizes attribute (rendered width of the image).
 */
function lachinata_product_image( int $image_id, string $size, string $halo_class, bool $eager = false, string $sizes = '' ): string {
	if ( ! $image_id ) {
		return sprintf( '<span class="%s" aria-hidden="true"></span>', esc_attr( $halo_class ) );
	}
	return wp_get_attachment_image(
		$image_id,
		$size,
		false,
		array(
			'alt'           => '',
			'loading'       => $eager ? 'eager' : 'lazy',
			'fetchpriority' => $eager ? 'high' : null,
			'decoding'      => 'async',
			'sizes'         => '' !== $sizes ? $sizes : null,
		)
	);
}
