<?php
/**
 * Configuration of the catalog: store categories and campaigns, cross-sell by root
 * category and the marks of the shipping classes.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Reads the module settings clean (they also arrive from an imported JSON). Categories
 * and shipping classes go by slug, so the configuration travels between shops.
 */
final class Config {

	/**
	 * Cross-sell sources: the product's cross-sells and, without them, the best sellers of
	 * its subcategory; or only the best sellers.
	 */
	public const SOURCES = array( 'cross_sells', 'bestsellers' );

	/**
	 * Icons of the sprite a shipping class mark can use.
	 */
	public const MARKER_ICONS = array( 'snowflake', 'leaf', 'gift', 'truck', 'clock', 'alert', 'info', 'star' );

	/**
	 * Store categories, in order (slugs).
	 *
	 * @return string[]
	 */
	public static function store_categories(): array {
		return self::slugs( self::raw( 'store_categories' ) );
	}

	/**
	 * Seasonal campaigns: a category shown between two dates (included).
	 *
	 * @return array<int, array{category: string, from: string, to: string}>
	 */
	public static function campaigns(): array {
		return self::clean_campaigns( self::raw( 'campaigns' ) );
	}

	/**
	 * Cross-sell title and source by root category.
	 *
	 * @return array<int, array{category: string, title: string, source: string}>
	 */
	public static function cross_sell(): array {
		return self::clean_cross_sell( self::raw( 'cross_sell' ) );
	}

	/**
	 * Marks of the shipping classes.
	 *
	 * @return array<int, array{class: string, icon: string, label: string, notice: bool}>
	 */
	public static function markers(): array {
		return self::clean_markers( self::raw( 'markers' ) );
	}

	/**
	 * Categories the shop shows, as term ids in order: the campaigns running today first,
	 * then the store categories. Null when nothing is configured (the theme shows every
	 * top-level category).
	 *
	 * @param string $today Y-m-d; today in the site's time zone by default.
	 * @return int[]|null
	 */
	public static function categories( string $today = '' ): ?array {
		$today = '' !== $today ? $today : current_time( 'Y-m-d' );
		$slugs = array();
		foreach ( self::campaigns() as $campaign ) {
			if ( $campaign['from'] <= $today && $today <= $campaign['to'] ) {
				$slugs[] = $campaign['category'];
			}
		}
		$fixed = self::store_categories();
		if ( ! $fixed && ! $slugs ) {
			return null;
		}
		$ids = array();
		foreach ( array_unique( array_merge( $slugs, $fixed ) ) as $slug ) {
			$term = get_term_by( 'slug', $slug, 'product_cat' );
			if ( $term instanceof \WP_Term ) {
				$ids[] = $term->term_id;
			}
		}
		return $ids;
	}

	/**
	 * Cross-sell of a root category, or null when it has none of its own.
	 *
	 * @param \WP_Term $root Root category.
	 * @return array{title: string, source: string}|null
	 */
	public static function cross_sell_for( \WP_Term $root ): ?array {
		foreach ( self::cross_sell() as $row ) {
			if ( $row['category'] === $root->slug ) {
				return array(
					'title'  => $row['title'],
					'source' => $row['source'],
				);
			}
		}
		return null;
	}

	/**
	 * Mark of a shipping class, or null.
	 *
	 * @param string $slug Shipping class slug.
	 * @return array{class: string, icon: string, label: string, notice: bool}|null
	 */
	public static function marker_for( string $slug ): ?array {
		if ( '' === $slug ) {
			return null;
		}
		foreach ( self::markers() as $marker ) {
			if ( $marker['class'] === $slug ) {
				return $marker;
			}
		}
		return null;
	}

	/**
	 * Clean list of slugs.
	 *
	 * @param mixed $value Raw value.
	 * @return string[]
	 */
	public static function slugs( mixed $value ): array {
		$slugs = array_map( static fn( $slug ): string => sanitize_title( (string) $slug ), is_array( $value ) ? $value : array() );
		return array_values( array_unique( array_filter( $slugs ) ) );
	}

	/**
	 * Clean campaigns: a category and two valid dates, the first not after the second.
	 *
	 * @param mixed $value Raw value.
	 * @return array<int, array{category: string, from: string, to: string}>
	 */
	public static function clean_campaigns( mixed $value ): array {
		$clean = array();
		foreach ( is_array( $value ) ? $value : array() as $row ) {
			$row      = is_array( $row ) ? $row : array();
			$category = sanitize_title( (string) ( $row['category'] ?? '' ) );
			$from     = Fields::sanitize_date( $row['from'] ?? '' );
			$to       = Fields::sanitize_date( $row['to'] ?? '' );
			if ( '' !== $category && '' !== $from && '' !== $to && $from <= $to ) {
				$clean[] = array(
					'category' => $category,
					'from'     => $from,
					'to'       => $to,
				);
			}
		}
		return $clean;
	}

	/**
	 * Clean cross-sell rows: one per root category, with a title or a source of its own.
	 *
	 * @param mixed $value Raw value.
	 * @return array<int, array{category: string, title: string, source: string}>
	 */
	public static function clean_cross_sell( mixed $value ): array {
		$clean = array();
		foreach ( is_array( $value ) ? $value : array() as $row ) {
			$row      = is_array( $row ) ? $row : array();
			$category = sanitize_title( (string) ( $row['category'] ?? '' ) );
			$source   = (string) ( $row['source'] ?? '' );
			if ( '' === $category || isset( $clean[ $category ] ) ) {
				continue;
			}
			$clean[ $category ] = array(
				'category' => $category,
				'title'    => sanitize_text_field( (string) ( $row['title'] ?? '' ) ),
				'source'   => in_array( $source, self::SOURCES, true ) ? $source : self::SOURCES[0],
			);
		}
		return array_values( $clean );
	}

	/**
	 * Clean marks: one per shipping class, with an icon of the list and a text.
	 *
	 * @param mixed $value Raw value.
	 * @return array<int, array{class: string, icon: string, label: string, notice: bool}>
	 */
	public static function clean_markers( mixed $value ): array {
		$clean = array();
		foreach ( is_array( $value ) ? $value : array() as $row ) {
			$row   = is_array( $row ) ? $row : array();
			$class = sanitize_title( (string) ( $row['class'] ?? '' ) );
			$icon  = (string) ( $row['icon'] ?? '' );
			$label = sanitize_text_field( (string) ( $row['label'] ?? '' ) );
			if ( '' === $class || '' === $label || ! in_array( $icon, self::MARKER_ICONS, true ) || isset( $clean[ $class ] ) ) {
				continue;
			}
			$clean[ $class ] = array(
				'class'  => $class,
				'icon'   => $icon,
				'label'  => $label,
				'notice' => ! empty( $row['notice'] ),
			);
		}
		return array_values( $clean );
	}

	/**
	 * Stored value of a setting.
	 *
	 * @param string $key Setting key.
	 */
	private static function raw( string $key ): mixed {
		$module = CatalogModule::instance();
		return null === $module ? array() : Settings::get( $module, $key );
	}
}
