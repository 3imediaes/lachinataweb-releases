<?php
/**
 * WooCommerce → La Chinata → Datos de la empresa.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Admin;

use LaChinata\Core\Company;

defined( 'ABSPATH' ) || exit;

/**
 * Legal name, tax id, address, privacy email and legal pages of the shop (Company).
 */
final class CompanyTab {

	/**
	 * Tab id.
	 */
	public const TAB = 'company';

	/**
	 * Action of admin-post.php, also the nonce action and the form id.
	 */
	private const SAVE = 'lachinata_core_company';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_filter( 'lachinata/core/admin_tabs', array( self::class, 'tab' ), 6 );
		add_action( 'admin_post_' . self::SAVE, array( self::class, 'handle' ) );
	}

	/**
	 * Adds the tab after Atención al cliente.
	 *
	 * @param array<string, array{label: string, render: callable}> $tabs Tabs.
	 * @return array<string, array{label: string, render: callable}>
	 */
	public static function tab( array $tabs ): array {
		$tab      = array(
			self::TAB => array(
				'label'  => __( 'Datos de la empresa', 'lachinata-core' ),
				'render' => array( self::class, 'render' ),
			),
		);
		$position = array_search( ContactTab::TAB, array_keys( $tabs ), true );
		$position = false === $position ? 1 : $position + 1;
		return array_slice( $tabs, 0, $position, true ) + $tab + $tabs;
	}

	/**
	 * Prints the tab.
	 */
	public static function render(): void {
		$kept           = Screen::take_field_errors( self::SAVE );
		$errors         = $kept['errors'];
		$values         = array_merge( Company::get(), array_intersect_key( $kept['posted'], array_flip( Company::TEXTS ) ) );
		$texts          = array(
			'trade_name'    => array(
				'label' => __( 'Nombre comercial', 'lachinata-core' ),
				'type'  => 'text',
				/* translators: %s: site name. */
				'hint'  => sprintf( __( 'El nombre de la tienda tal como lo leen los clientes, en el aviso de cookies, la política y los correos. Vacío: el nombre del sitio (%s).', 'lachinata-core' ), get_bloginfo( 'name' ) ),
			),
			'legal_name'    => array(
				'label' => __( 'Razón social', 'lachinata-core' ),
				'type'  => 'text',
				'hint'  => __( 'El nombre legal de la empresa, como figura en el registro.', 'lachinata-core' ),
			),
			'tax_id'        => array(
				'label' => __( 'NIF / CIF / número de IVA', 'lachinata-core' ),
				'type'  => 'text',
				'hint'  => __( 'El identificador fiscal de la empresa en su país.', 'lachinata-core' ),
			),
			'address'       => array(
				'label' => __( 'Domicilio social', 'lachinata-core' ),
				'type'  => 'text',
				/* translators: %s: address of the shop in WooCommerce. */
				'hint'  => sprintf( __( 'Vacío: la dirección de la tienda en WooCommerce (%s).', 'lachinata-core' ), Company::store_address() ),
			),
			'privacy_email' => array(
				'label' => __( 'Correo de privacidad', 'lachinata-core' ),
				'type'  => 'email',
				'hint'  => __( 'Donde se ejercen los derechos sobre los datos. Sale en la política de cookies y en la de privacidad.', 'lachinata-core' ),
			),
		);
		$texts['brand'] = array(
			'label' => __( 'Marca', 'lachinata-core' ),
			'type'  => 'text',
			/* translators: %s: site name. */
			'hint'  => sprintf( __( 'La marca de los productos que no tienen la suya en WooCommerce → Productos → Marcas (feeds y medición). Vacío: el nombre comercial (%s).', 'lachinata-core' ), Company::trade_name() ),
		);
		$pages          = array(
			'privacy_page' => __( 'Política de privacidad', 'lachinata-core' ),
			'cookies_page' => __( 'Política de cookies', 'lachinata-core' ),
			'legal_page'   => __( 'Aviso legal', 'lachinata-core' ),
		);
		?>
		<p><?php esc_html_e( 'Los datos legales de quien vende en esta tienda. Los leen la política de cookies, el pie legal de los correos, los datos estructurados de la organización y la factura.', 'lachinata-core' ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" novalidate>
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE ); ?>">
			<?php wp_nonce_field( self::SAVE ); ?>
			<table class="form-table" role="presentation">
				<?php foreach ( $texts as $key => $field ) : ?>
					<?php $id = 'lc-company-' . $key; ?>
					<tr>
						<th scope="row"><label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $field['label'] ); ?></label></th>
						<td>
							<input type="<?php echo esc_attr( $field['type'] ); ?>" class="regular-text" id="<?php echo esc_attr( $id ); ?>" name="company[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( (string) $values[ $key ] ); ?>" aria-describedby="<?php echo esc_attr( $id ); ?>-hint<?php echo isset( $errors[ $key ] ) ? ' ' . esc_attr( $id ) . '-error' : ''; ?>"<?php echo isset( $errors[ $key ] ) ? ' aria-invalid="true"' : ''; ?>>
							<?php Screen::field_error( $errors, $key, $id ); ?>
							<p class="description" id="<?php echo esc_attr( $id ); ?>-hint"><?php echo esc_html( $field['hint'] ); ?></p>
						</td>
					</tr>
				<?php endforeach; ?>
				<?php foreach ( $pages as $key => $label ) : ?>
					<?php $id = 'lc-company-' . $key; ?>
					<tr>
						<th scope="row"><label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label></th>
						<td>
							<?php
							wp_dropdown_pages(
								array(
									'name'              => esc_attr( 'company[' . $key . ']' ),
									'id'                => esc_attr( $id ),
									'selected'          => (int) $values[ $key ],
									'show_option_none'  => esc_html__( '— Ninguna —', 'lachinata-core' ),
									'option_none_value' => '0',
									'post_status'       => array( 'publish', 'draft', 'private' ),
								)
							);
							?>
						</td>
					</tr>
				<?php endforeach; ?>
			</table>
			<p class="description"><?php esc_html_e( 'Son datos de este sitio: no salen en la exportación de configuración.', 'lachinata-core' ); ?></p>
			<?php submit_button(); ?>
		</form>
		<?php
	}

	/**
	 * Saves the values, or goes back with the error under each field.
	 */
	public static function handle(): void {
		Screen::check( self::SAVE );
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Screen::check(); each value is sanitized below and in Company::save().
		$values = isset( $_POST['company'] ) && is_array( $_POST['company'] ) ? (array) wp_unslash( $_POST['company'] ) : array();
		$values = array_map( static fn( $value ): string => is_scalar( $value ) ? sanitize_text_field( (string) $value ) : '', $values );
		$errors = array();
		$email  = trim( $values['privacy_email'] ?? '' );
		if ( '' !== $email && ! is_email( $email ) ) {
			$errors['privacy_email'] = __( 'Escribe un correo completo, como privacidad@tienda.com.', 'lachinata-core' );
		}
		if ( $errors ) {
			Screen::field_errors( self::SAVE, $errors, $values );
			Screen::flash( 'error', array( __( 'No se ha guardado: revisa los campos marcados.', 'lachinata-core' ) ) );
			Screen::redirect( self::TAB );
		}
		Company::save( $values );
		Screen::flash( 'success', array( __( 'Datos de la empresa guardados.', 'lachinata-core' ) ) );
		Screen::redirect( self::TAB );
	}
}
