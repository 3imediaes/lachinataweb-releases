<?php
/**
 * WooCommerce → La Chinata → Catálogo.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

use LaChinata\Core\Admin\Screen;
use LaChinata\Core\Hooks;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Two sections: the catalog health (calculated when it opens) and the configuration of
 * the shop (store categories and seasonal campaigns, cross-sell by root category and the
 * marks of the shipping classes). The count of the health also shows on the home of the
 * panel.
 */
final class CatalogTab {

	/**
	 * Tab id.
	 */
	public const TAB = 'catalog';

	/**
	 * Action of admin-post.php, also the nonce action.
	 */
	private const SAVE = 'lachinata_catalog_save';

	/**
	 * Empty rows for new campaigns, cross-sells and marks.
	 */
	private const BLANK = 2;

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/core/admin_tabs', array( self::class, 'tab' ), 20 );
		Hooks::add_action( 'admin_post_' . self::SAVE, array( self::class, 'handle' ) );
		Hooks::add_action( 'lachinata/core/admin_home', array( self::class, 'home' ) );
	}

	/**
	 * Adds the tab after Módulos.
	 *
	 * @param array<string, array{label: string, render: callable}> $tabs Tabs.
	 * @return array<string, array{label: string, render: callable}>
	 */
	public static function tab( array $tabs ): array {
		$tab = array(
			self::TAB => array(
				'label'  => __( 'Catálogo', 'lachinata-core' ),
				'render' => array( self::class, 'render' ),
			),
		);
		return array_slice( $tabs, 0, 1, true ) + $tab + $tabs;
	}

	/**
	 * «Salud del catálogo: N avisos» on the home of the panel.
	 */
	public static function home(): void {
		$count = Health::last_count();
		printf(
			'<div class="notice %1$s inline"><p>%2$s <a href="%3$s">%4$s</a></p></div>',
			$count ? 'notice-warning' : 'notice-success',
			esc_html(
				$count
					/* translators: %s: number of warnings. */
					? sprintf( _n( 'Salud del catálogo: %s aviso.', 'Salud del catálogo: %s avisos.', $count, 'lachinata-core' ), number_format_i18n( $count ) )
					: __( 'Salud del catálogo: sin avisos.', 'lachinata-core' )
			),
			esc_url( Screen::url( self::TAB, array( 'section' => 'health' ) ) ),
			esc_html__( 'Ver la salud del catálogo', 'lachinata-core' )
		);
	}

	/**
	 * Prints the tab.
	 */
	public static function render(): void {
		$section = isset( $_GET['section'] ) && 'settings' === $_GET['section'] ? 'settings' : 'health'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Navigation only.
		Screen::section_links(
			self::TAB,
			array(
				'health'   => __( 'Salud del catálogo', 'lachinata-core' ),
				'settings' => __( 'Tienda', 'lachinata-core' ),
			),
			$section
		);
		if ( 'settings' === $section ) {
			self::render_settings();
		} else {
			self::render_health();
		}
	}

	/**
	 * The health: a table per group with a link to each product.
	 */
	private static function render_health(): void {
		$found = Health::run();
		$count = Health::count( $found );
		echo '<p>' . esc_html__( 'Datos de las fichas que la tienda muestra tal como vienen pero conviene revisar. Nada de esto cambia lo que se ve: se corrige en cada producto. Se calcula al abrir esta pantalla.', 'lachinata-core' ) . ' <a href="' . esc_url( Screen::guide_url( 'catalog' ) ) . '">' . esc_html__( 'Guía', 'lachinata-core' ) . '</a></p>';
		if ( ! $count ) {
			echo '<div class="notice notice-success inline"><p>' . esc_html__( 'Sin avisos.', 'lachinata-core' ) . '</p></div>';
			return;
		}
		foreach ( Health::groups() as $group => $label ) {
			if ( ! $found[ $group ] ) {
				continue;
			}
			printf( '<h2>%1$s (%2$s)</h2>', esc_html( $label ), esc_html( number_format_i18n( count( $found[ $group ] ) ) ) );
			echo '<table class="widefat striped lc-admin__table"><thead><tr><th scope="col">' . esc_html__( 'Producto', 'lachinata-core' ) . '</th><th scope="col">' . esc_html__( 'Qué revisar', 'lachinata-core' ) . '</th></tr></thead><tbody>';
			foreach ( $found[ $group ] as $row ) {
				printf(
					'<tr><td><a href="%1$s">%2$s</a> <code>#%3$d</code></td><td>%4$s</td></tr>',
					esc_url( (string) get_edit_post_link( $row['id'] ) ),
					esc_html( '' !== $row['name'] ? $row['name'] : __( '(sin nombre)', 'lachinata-core' ) ),
					(int) $row['id'],
					esc_html( $row['detail'] )
				);
			}
			echo '</tbody></table>';
		}
	}

	/**
	 * The configuration of the shop.
	 */
	private static function render_settings(): void {
		$roots   = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
				'parent'     => 0,
				'orderby'    => 'menu_order',
			)
		);
		$roots   = is_array( $roots ) ? $roots : array();
		$classes = WC()->shipping()->get_shipping_classes();
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE ); ?>">
			<?php wp_nonce_field( self::SAVE ); ?>

			<h2><?php esc_html_e( 'Categorías de la tienda', 'lachinata-core' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Las que salen en la cabecera, el menú, el buscador y la portada, en este orden: slugs separados por comas (pueden ser también subcategorías). Vacío: todas las categorías principales con productos.', 'lachinata-core' ); ?></p>
			<p><input type="text" class="large-text" name="store_categories" value="<?php echo esc_attr( implode( ', ', Config::store_categories() ) ); ?>" placeholder="<?php echo esc_attr( implode( ', ', array_slice( wp_list_pluck( $roots, 'slug' ), 0, 5 ) ) ); ?>" aria-label="<?php esc_attr_e( 'Categorías de la tienda', 'lachinata-core' ); ?>"></p>

			<h3><?php esc_html_e( 'Campañas de temporada', 'lachinata-core' ); ?></h3>
			<p class="description"><?php esc_html_e( 'Una categoría (Navidad, Día de la Madre…) que entra delante de las demás entre dos fechas, ambas incluidas.', 'lachinata-core' ); ?></p>
			<table class="widefat striped lc-admin__table">
				<thead><tr><th scope="col"><?php esc_html_e( 'Categoría (slug)', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Desde', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Hasta', 'lachinata-core' ); ?></th></tr></thead>
				<tbody>
					<?php foreach ( array_merge( Config::campaigns(), array_fill( 0, self::BLANK, null ) ) as $index => $row ) : ?>
						<tr>
							<td><input type="text" name="campaigns[<?php echo (int) $index; ?>][category]" value="<?php echo esc_attr( $row['category'] ?? '' ); ?>" aria-label="<?php esc_attr_e( 'Categoría de la campaña', 'lachinata-core' ); ?>"></td>
							<td><input type="date" name="campaigns[<?php echo (int) $index; ?>][from]" value="<?php echo esc_attr( $row['from'] ?? '' ); ?>" aria-label="<?php esc_attr_e( 'Desde', 'lachinata-core' ); ?>"></td>
							<td><input type="date" name="campaigns[<?php echo (int) $index; ?>][to]" value="<?php echo esc_attr( $row['to'] ?? '' ); ?>" aria-label="<?php esc_attr_e( 'Hasta', 'lachinata-core' ); ?>"></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<h2><?php esc_html_e( 'Venta cruzada de la ficha', 'lachinata-core' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Título y fuente por categoría principal. Sin fila, «También te puede gustar» con las ventas cruzadas del producto y, si no tiene, los más vendidos de su subcategoría. Sin productos, la sección no se pinta.', 'lachinata-core' ); ?></p>
			<table class="widefat striped lc-admin__table">
				<thead><tr><th scope="col"><?php esc_html_e( 'Categoría principal', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Título', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Productos', 'lachinata-core' ); ?></th></tr></thead>
				<tbody>
					<?php foreach ( array_merge( Config::cross_sell(), array_fill( 0, self::BLANK, null ) ) as $index => $row ) : ?>
						<tr>
							<td>
								<select name="cross_sell[<?php echo (int) $index; ?>][category]" aria-label="<?php esc_attr_e( 'Categoría principal', 'lachinata-core' ); ?>">
									<option value=""><?php esc_html_e( '—', 'lachinata-core' ); ?></option>
									<?php foreach ( $roots as $root ) : ?>
										<option value="<?php echo esc_attr( $root->slug ); ?>"<?php selected( $row['category'] ?? '', $root->slug ); ?>><?php echo esc_html( $root->name ); ?></option>
									<?php endforeach; ?>
								</select>
							</td>
							<td><input type="text" class="regular-text" name="cross_sell[<?php echo (int) $index; ?>][title]" value="<?php echo esc_attr( $row['title'] ?? '' ); ?>" placeholder="<?php esc_attr_e( 'También te puede gustar', 'lachinata-core' ); ?>" aria-label="<?php esc_attr_e( 'Título', 'lachinata-core' ); ?>"></td>
							<td>
								<select name="cross_sell[<?php echo (int) $index; ?>][source]" aria-label="<?php esc_attr_e( 'Productos', 'lachinata-core' ); ?>">
									<option value="cross_sells"<?php selected( $row['source'] ?? '', 'cross_sells' ); ?>><?php esc_html_e( 'Ventas cruzadas del producto; si no tiene, los más vendidos de su subcategoría', 'lachinata-core' ); ?></option>
									<option value="bestsellers"<?php selected( $row['source'] ?? '', 'bestsellers' ); ?>><?php esc_html_e( 'Solo los más vendidos de su subcategoría', 'lachinata-core' ); ?></option>
								</select>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<h2><?php esc_html_e( 'Marcas de las clases de envío', 'lachinata-core' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Una pastilla con texto (y, si quieres, un icono) en la esquina de la foto de la tarjeta, para los productos de la clase. Con «Aviso en la ficha», la ficha añade el aviso con su título, su icono y las condiciones de envío de la clase (destinos, precio, envío gratis y días), sacadas de la configuración de Envíos y de Entrega estimada.', 'lachinata-core' ); ?></p>
			<table class="widefat striped lc-admin__table">
				<thead><tr><th scope="col"><?php esc_html_e( 'Clase de envío', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Texto en la tarjeta', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Icono en la tarjeta', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Aviso en la ficha', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Título del aviso', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Icono del aviso', 'lachinata-core' ); ?></th></tr></thead>
				<tbody>
					<?php foreach ( array_merge( Config::markers(), array_fill( 0, self::BLANK, null ) ) as $index => $row ) : ?>
						<tr>
							<td>
								<select name="markers[<?php echo (int) $index; ?>][class]" aria-label="<?php esc_attr_e( 'Clase de envío', 'lachinata-core' ); ?>">
									<option value=""><?php esc_html_e( '—', 'lachinata-core' ); ?></option>
									<?php foreach ( $classes as $class ) : ?>
										<option value="<?php echo esc_attr( $class->slug ); ?>"<?php selected( $row['class'] ?? '', $class->slug ); ?>><?php echo esc_html( $class->name ); ?></option>
									<?php endforeach; ?>
								</select>
							</td>
							<td><input type="text" class="regular-text" name="markers[<?php echo (int) $index; ?>][label]" value="<?php echo esc_attr( $row['label'] ?? '' ); ?>" placeholder="<?php esc_attr_e( 'Refrigerado', 'lachinata-core' ); ?>" aria-label="<?php esc_attr_e( 'Texto en la tarjeta', 'lachinata-core' ); ?>"></td>
							<td>
								<select name="markers[<?php echo (int) $index; ?>][card_icon]" aria-label="<?php esc_attr_e( 'Icono en la tarjeta', 'lachinata-core' ); ?>">
									<option value=""><?php esc_html_e( 'Ninguno', 'lachinata-core' ); ?></option>
									<?php foreach ( Config::MARKER_ICONS as $icon ) : ?>
										<option value="<?php echo esc_attr( $icon ); ?>"<?php selected( $row['card_icon'] ?? '', $icon ); ?>><?php echo esc_html( $icon ); ?></option>
									<?php endforeach; ?>
								</select>
							</td>
							<td><input type="checkbox" name="markers[<?php echo (int) $index; ?>][notice]" value="1"<?php checked( ! empty( $row['notice'] ) ); ?> aria-label="<?php esc_attr_e( 'Aviso en la ficha', 'lachinata-core' ); ?>"></td>
							<td><input type="text" class="regular-text" name="markers[<?php echo (int) $index; ?>][notice_label]" value="<?php echo esc_attr( $row['notice_label'] ?? '' ); ?>" placeholder="<?php esc_attr_e( 'Envío refrigerado', 'lachinata-core' ); ?>" aria-label="<?php esc_attr_e( 'Título del aviso', 'lachinata-core' ); ?>"></td>
							<td>
								<select name="markers[<?php echo (int) $index; ?>][notice_icon]" aria-label="<?php esc_attr_e( 'Icono del aviso', 'lachinata-core' ); ?>">
									<?php foreach ( Config::MARKER_ICONS as $icon ) : ?>
										<option value="<?php echo esc_attr( $icon ); ?>"<?php selected( $row['notice_icon'] ?? Config::NOTICE_ICON, $icon ); ?>><?php echo esc_html( $icon ); ?></option>
									<?php endforeach; ?>
								</select>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<?php submit_button( __( 'Guardar', 'lachinata-core' ) ); ?>
		</form>
		<?php
	}

	/**
	 * Saves the configuration of the shop.
	 */
	public static function handle(): void {
		Screen::check( self::SAVE );
		$module = CatalogModule::instance();
		if ( null === $module ) {
			Screen::redirect( self::TAB );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Screen::check(); each value is cleaned by Config.
		$post = wp_unslash( $_POST );
		$post = is_array( $post ) ? $post : array();
		Settings::set( $module, 'store_categories', Config::slugs( explode( ',', (string) ( $post['store_categories'] ?? '' ) ) ) );
		Settings::set( $module, 'campaigns', Config::clean_campaigns( $post['campaigns'] ?? array() ) );
		Settings::set( $module, 'cross_sell', Config::clean_cross_sell( $post['cross_sell'] ?? array() ) );
		Settings::set( $module, 'markers', Config::clean_markers( $post['markers'] ?? array() ) );

		$missing = array();
		foreach ( array_merge( Config::store_categories(), array_column( Config::campaigns(), 'category' ) ) as $slug ) {
			if ( ! get_term_by( 'slug', $slug, 'product_cat' ) ) {
				$missing[] = $slug;
			}
		}
		Screen::flash(
			$missing ? 'warning' : 'success',
			$missing
				/* translators: %s: category slugs. */
				? array( sprintf( __( 'Guardado. No existen estas categorías y no se muestran: %s.', 'lachinata-core' ), implode( ', ', $missing ) ) )
				: array( __( 'Guardado.', 'lachinata-core' ) )
		);
		Screen::redirect( self::TAB, array( 'section' => 'settings' ) );
	}
}
