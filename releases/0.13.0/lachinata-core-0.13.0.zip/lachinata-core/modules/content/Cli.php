<?php
/**
 * WP-CLI: wp lachinata content.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

defined( 'ABSPATH' ) || exit;

/**
 * Migration of the blog.
 */
final class Cli {

	/**
	 * Migrates the blog: format and section of every entry, the recipes to the block, the
	 * 301 of the old categories and the clicks of Search Console. With --dry-run it writes
	 * nothing and only reports.
	 *
	 * ## OPTIONS
	 *
	 * --map=<file>
	 * : JSON with the choices of the shop (sections, categories, types of dish, difficulties).
	 *
	 * [--gsc=<file>]
	 * : CSV of Search Console (pages: URL, clicks…).
	 *
	 * [--report=<file>]
	 * : Where to write the report in Markdown (without it, on screen).
	 *
	 * [--dry-run]
	 * : Report only.
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata content migrate --map=blog.json --gsc=gsc.csv --report=informe.md --dry-run
	 *
	 * @param string[]              $args       Positional arguments.
	 * @param array<string, string> $assoc_args Options.
	 */
	public function migrate( array $args, array $assoc_args ): void {
		unset( $args );
		$file = (string) ( $assoc_args['map'] ?? '' );
		$map  = is_readable( $file ) ? json_decode( (string) file_get_contents( $file ), true ) : null; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- A local file of the command.
		if ( ! is_array( $map ) ) {
			\WP_CLI::error( __( 'No se puede leer el mapa (--map, JSON).', 'lachinata-core' ) );
		}
		$dry_run = isset( $assoc_args['dry-run'] );
		$gsc     = isset( $assoc_args['gsc'] ) ? (string) $assoc_args['gsc'] : null;
		$report  = ( new Migration() )->run( $map, $dry_run, $gsc );
		$text    = Migration::markdown( $report, $dry_run );
		if ( isset( $assoc_args['report'] ) ) {
			file_put_contents( (string) $assoc_args['report'], $text ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- A local file of the command.
			/* translators: %s: file. */
			\WP_CLI::success( sprintf( __( 'Informe en %s.', 'lachinata-core' ), (string) $assoc_args['report'] ) );
			return;
		}
		\WP_CLI::log( $text );
	}
}
