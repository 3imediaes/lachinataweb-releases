<?php
/**
 * WooCommerce → La Chinata → Blog.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

use LaChinata\Core\Admin\Screen;
use LaChinata\Core\Hooks;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * The texts of the magazine, the section of the recipes, the minimum of recipes of a
 * subsection with its own page, the product categories that show recipes, the health and
 * beauty sections and their months without review, the months after which a news item
 * warns, and where each old category goes. Sections and categories go by slug.
 */
final class ContentTab {

	/**
	 * Tab id.
	 */
	public const TAB = 'content';

	/**
	 * Action of admin-post.php, also the nonce action.
	 */
	private const SAVE = 'lachinata_content_save';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/core/admin_tabs', array( self::class, 'tab' ), 30 );
		Hooks::add_action( 'admin_post_' . self::SAVE, array( self::class, 'handle' ) );
	}

	/**
	 * Adds the tab.
	 *
	 * @param array<string, array{label: string, render: callable}> $tabs Tabs.
	 * @return array<string, array{label: string, render: callable}>
	 */
	public static function tab( array $tabs ): array {
		$tabs[ self::TAB ] = array(
			'label'  => __( 'Blog', 'lachinata-core' ),
			'render' => array( self::class, 'render' ),
		);
		return $tabs;
	}

	/**
	 * A list of slugs as the text of a field.
	 *
	 * @param string $key Setting.
	 */
	private static function slugs( string $key ): string {
		return implode( ', ', array_map( 'strval', (array) ContentModule::setting( $key ) ) );
	}

	/**
	 * The screen.
	 */
	public static function render(): void {
		$text   = array(
			'blog_eyebrow' => array( __( 'Antetítulo de la revista', 'lachinata-core' ), Texts::blog_eyebrow() ),
			'blog_title'   => array( __( 'Título de la revista', 'lachinata-core' ), Texts::blog_title() ),
			'blog_lead'    => array( __( 'Entradilla de la revista', 'lachinata-core' ), '' ),
		);
		$lists  = array(
			'recipe_section'  => array( __( 'Sección de las recetas', 'lachinata-core' ), __( 'Slug de la sección. Vacío: la que más recetas tiene.', 'lachinata-core' ), (string) ContentModule::setting( 'recipe_section' ) ),
			'product_recipes' => array( __( 'Recetas en la ficha de producto', 'lachinata-core' ), __( 'Slugs de las categorías de producto (y sus hijas) que muestran «Recetas con este producto», «Ideas para tu…» en gracias y en el correo de pedido enviado. Solo categorías de cocina: nunca cosmética.', 'lachinata-core' ), self::slugs( 'product_recipes' ) ),
			'health_sections' => array( __( 'Secciones de salud y belleza', 'lachinata-core' ), __( 'Slugs de las secciones cuyas entradas deben revisarse con fuentes.', 'lachinata-core' ), self::slugs( 'health_sections' ) ),
		);
		$counts = array(
			'subsection_minimum'  => array( __( 'Recetas para que una subsección tenga página', 'lachinata-core' ), __( 'Por debajo, la subsección no tiene página propia y su antetítulo va sin enlace.', 'lachinata-core' ) ),
			'review_months'       => array( __( 'Meses sin revisar (salud y belleza)', 'lachinata-core' ), __( 'Pasado el plazo, la entrada pasa a la lista «para revisar».', 'lachinata-core' ) ),
			'news_warning_months' => array( __( 'Meses para el aviso de noticia antigua', 'lachinata-core' ), __( 'Pasado el plazo, la noticia abre con «Esta noticia es de… Puede que la información haya cambiado». 0: sin aviso.', 'lachinata-core' ) ),
		);
		$map    = array();
		foreach ( (array) ContentModule::setting( 'category_sections' ) as $category => $section ) {
			$map[] = $category . ' = ' . $section;
		}
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE ); ?>">
			<?php wp_nonce_field( self::SAVE ); ?>
			<table class="form-table" role="presentation">
				<?php foreach ( $text as $key => list( $label, $placeholder ) ) : ?>
					<tr>
						<th scope="row"><label for="lc-content-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
						<td><input type="text" class="large-text" id="lc-content-<?php echo esc_attr( $key ); ?>" name="content[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( (string) ContentModule::setting( $key ) ); ?>" placeholder="<?php echo esc_attr( $placeholder ); ?>"></td>
					</tr>
				<?php endforeach; ?>
				<?php foreach ( $lists as $key => list( $label, $hint, $value ) ) : ?>
					<tr>
						<th scope="row"><label for="lc-content-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
						<td>
							<input type="text" class="large-text" id="lc-content-<?php echo esc_attr( $key ); ?>" name="content[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $value ); ?>" aria-describedby="lc-content-<?php echo esc_attr( $key ); ?>-hint">
							<p class="description" id="lc-content-<?php echo esc_attr( $key ); ?>-hint"><?php echo esc_html( $hint ); ?></p>
						</td>
					</tr>
				<?php endforeach; ?>
				<?php foreach ( $counts as $key => list( $label, $hint ) ) : ?>
					<tr>
						<th scope="row"><label for="lc-content-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
						<td>
							<input type="number" min="0" class="small-text" id="lc-content-<?php echo esc_attr( $key ); ?>" name="content[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( (string) (int) ContentModule::setting( $key ) ); ?>" aria-describedby="lc-content-<?php echo esc_attr( $key ); ?>-hint">
							<p class="description" id="lc-content-<?php echo esc_attr( $key ); ?>-hint"><?php echo esc_html( $hint ); ?></p>
						</td>
					</tr>
				<?php endforeach; ?>
				<tr>
					<th scope="row"><label for="lc-content-category_sections"><?php esc_html_e( 'Categorías antiguas', 'lachinata-core' ); ?></label></th>
					<td>
						<textarea class="large-text code" rows="6" id="lc-content-category_sections" name="content[category_sections]" aria-describedby="lc-content-category_sections-hint"><?php echo esc_textarea( implode( "\n", $map ) ); ?></textarea>
						<p class="description" id="lc-content-category_sections-hint"><?php esc_html_e( 'Una por línea: «categoría = sección» (slugs). La categoría redirige con 301 a su sección; sin línea, al blog. La rellena la migración.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
			</table>
			<p class="description">
				<?php
				printf(
					/* translators: 1: link to the sections, 2: link to the topics. */
					esc_html__( 'Las secciones (con su texto, su orden y la categoría de productos de sus artículos) y los temas se editan en Entradas: %1$s y %2$s.', 'lachinata-core' ),
					'<a href="' . esc_url( admin_url( 'edit-tags.php?taxonomy=' . Model::SECTION ) ) . '">' . esc_html__( 'Secciones', 'lachinata-core' ) . '</a>',
					'<a href="' . esc_url( admin_url( 'edit-tags.php?taxonomy=' . Model::TOPIC ) ) . '">' . esc_html__( 'Temas', 'lachinata-core' ) . '</a>'
				);
				?>
			</p>
			<?php submit_button( __( 'Guardar', 'lachinata-core' ) ); ?>
		</form>
		<?php
	}

	/**
	 * Saves the settings.
	 */
	public static function handle(): void {
		Screen::check( self::SAVE );
		$module = ContentModule::instance();
		if ( null === $module ) {
			Screen::redirect( self::TAB );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Screen::check(); each value is sanitized below.
		$post   = isset( $_POST['content'] ) && is_array( $_POST['content'] ) ? (array) wp_unslash( $_POST['content'] ) : array();
		$string = static fn( string $key ): string => sanitize_text_field( (string) ( $post[ $key ] ?? '' ) );
		$slugs  = static fn( string $key ): array => array_values( array_filter( array_map( 'sanitize_title', explode( ',', (string) ( $post[ $key ] ?? '' ) ) ) ) );
		foreach ( array( 'blog_eyebrow', 'blog_title', 'blog_lead' ) as $key ) {
			Settings::set( $module, $key, $string( $key ) );
		}
		Settings::set( $module, 'recipe_section', sanitize_title( $string( 'recipe_section' ) ) );
		Settings::set( $module, 'product_recipes', $slugs( 'product_recipes' ) );
		Settings::set( $module, 'health_sections', $slugs( 'health_sections' ) );
		foreach ( array( 'subsection_minimum', 'review_months', 'news_warning_months' ) as $key ) {
			Settings::set( $module, $key, max( 0, (int) ( $post[ $key ] ?? 0 ) ) );
		}
		Settings::set( $module, 'category_sections', self::parse_map( (string) ( $post['category_sections'] ?? '' ) ) );
		Screen::flash( 'success', array( __( 'Guardado.', 'lachinata-core' ) ) );
		Screen::redirect( self::TAB );
	}

	/**
	 * «categoría = sección» lines as a map of slugs.
	 *
	 * @param string $text Lines.
	 * @return array<string, string>
	 */
	public static function parse_map( string $text ): array {
		$map = array();
		foreach ( (array) preg_split( '/\R/', $text ) as $line ) {
			$parts = array_map( 'trim', explode( '=', $line, 2 ) );
			if ( 2 === count( $parts ) && '' !== sanitize_title( $parts[0] ) && '' !== sanitize_title( $parts[1] ) ) {
				$map[ sanitize_title( $parts[0] ) ] = sanitize_title( $parts[1] );
			}
		}
		return $map;
	}
}
