<?php
/**
 * Content that goes out of date.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * A news item older than the setting (12 months by default) opens with a neutral notice:
 * «Esta noticia es de marzo de 2019. Puede que la información haya cambiado.». The
 * entries of the health and beauty sections without a review in 12 months are listed for
 * whoever reviews (posts list, health of the module). The reasons to review an entry
 * (Fields::REVIEW: a product it mentions changed, a store it names closed; 10b) are shown in
 * the editor; nothing is changed by itself.
 */
final class Freshness {

	/**
	 * Query var of the posts list: only the entries to review.
	 */
	public const LIST_VAR = 'lc_revisar';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		if ( is_admin() ) {
			Hooks::add_action( 'admin_notices', array( self::class, 'admin_notice' ) );
			Hooks::add_action( 'pre_get_posts', array( self::class, 'admin_list' ) );
		}
	}

	/**
	 * Months without review after which a health and beauty entry is listed.
	 */
	public static function review_months(): int {
		return max( 1, (int) ContentModule::setting( 'review_months' ) );
	}

	/**
	 * The notice of an old news item, or ''.
	 *
	 * @param \WP_Post $post Post.
	 */
	public static function news_notice( \WP_Post $post ): string {
		$months = (int) ContentModule::setting( 'news_warning_months' );
		if ( $months <= 0 || Model::NEWS !== Model::format_of( $post ) ) {
			return '';
		}
		$published = Dates::of( $post )['published'];
		if ( $published > strtotime( '-' . $months . ' months' ) ) {
			return '';
		}
		return Html::notice(
			esc_html(
				sprintf(
					/* translators: %s: month and year («marzo de 2019»). */
					__( 'Esta noticia es de %s. Puede que la información haya cambiado.', 'lachinata-core' ),
					wp_date( _x( 'F \d\e Y', 'month and year of an old news item', 'lachinata-core' ), $published )
				)
			),
			'neutral',
			'clock'
		);
	}

	/**
	 * Entries of the health and beauty sections without a real change in the months of
	 * the setting (ids).
	 *
	 * @return int[]
	 */
	public static function stale_health_posts(): array {
		$slugs = array_filter( array_map( 'sanitize_title', (array) ContentModule::setting( 'health_sections' ) ) );
		if ( ! $slugs ) {
			return array();
		}
		$limit = strtotime( '-' . self::review_months() . ' months' );
		$stale = array();
		$posts = Query::posts(
			array(
				'posts_per_page' => -1,
				'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- A few sections.
					array(
						'taxonomy'         => Model::SECTION,
						'field'            => 'slug',
						'terms'            => $slugs,
						'include_children' => true,
					),
				),
			)
		);
		foreach ( $posts as $post ) {
			if ( Dates::last( $post ) < $limit ) {
				$stale[] = $post->ID;
			}
		}
		return $stale;
	}

	/**
	 * Entries with reasons to review (Fields::REVIEW) or stale in health and beauty.
	 *
	 * @return int[]
	 */
	public static function to_review(): array {
		$flagged = get_posts(
			array(
				'post_type'      => 'post',
				'post_status'    => array( 'publish', 'draft', 'pending', 'future' ),
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_key'       => Fields::REVIEW, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Indexed by key.
			)
		);
		return array_values( array_unique( array_merge( array_map( 'intval', $flagged ), self::stale_health_posts() ) ) );
	}

	/**
	 * Reasons to review an entry, for the editor.
	 *
	 * @param int $post_id Post.
	 * @return string[]
	 */
	public static function reasons( int $post_id ): array {
		$reasons = get_post_meta( $post_id, Fields::REVIEW, true );
		$texts   = array();
		foreach ( is_array( $reasons ) ? $reasons : array() as $reason ) {
			if ( is_array( $reason ) && '' !== (string) ( $reason['text'] ?? '' ) ) {
				$texts[] = (string) $reason['text'];
			}
		}
		$post = get_post( $post_id );
		if ( $post instanceof \WP_Post && in_array( $post_id, self::stale_health_posts(), true ) ) {
			/* translators: %s: months. */
			$texts[] = sprintf( __( 'Contenido de salud y belleza sin revisar en %s meses: comprueba las afirmaciones y sus fuentes y marca la fecha de revisión.', 'lachinata-core' ), number_format_i18n( self::review_months() ) );
		}
		return $texts;
	}

	/**
	 * On the posts list: how many entries are waiting for a review, with the filtered list.
	 */
	public static function admin_notice(): void {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( null === $screen || 'edit-post' !== $screen->id || ! current_user_can( 'edit_posts' ) ) {
			return;
		}
		$count = count( self::to_review() );
		if ( ! $count ) {
			return;
		}
		printf(
			'<div class="notice notice-warning"><p>%1$s <a href="%2$s">%3$s</a></p></div>',
			esc_html(
				sprintf(
					/* translators: %s: number of entries. */
					_n( '%s entrada para revisar.', '%s entradas para revisar.', $count, 'lachinata-core' ),
					number_format_i18n( $count )
				)
			),
			esc_url( add_query_arg( self::LIST_VAR, '1', admin_url( 'edit.php' ) ) ),
			esc_html__( 'Ver la lista', 'lachinata-core' )
		);
	}

	/**
	 * The posts list with only the entries to review.
	 *
	 * @param \WP_Query $query Query.
	 */
	public static function admin_list( $query ): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only filter of a list.
		if ( ! $query instanceof \WP_Query || ! $query->is_main_query() || empty( $_GET[ self::LIST_VAR ] ) || 'post' !== $query->get( 'post_type' ) ) {
			return;
		}
		$ids = self::to_review();
		$query->set( 'post__in', $ids ? $ids : array( 0 ) );
	}
}
