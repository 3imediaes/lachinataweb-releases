<?php
/**
 * HTML of the components of the group «Blog».
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

use LaChinata\Core\Company;

defined( 'ABSPATH' ) || exit;

/**
 * The markup of ArticleCard, RecipeCard, ArticleMeta, SummaryBox, Toc, RecipeHeader,
 * IngredientList, StepList, CookMode and RecipeProducts as `components/bundle.js` prints
 * it (same classes, `aria-*` and roles), with the icons of the theme's sprite. The theme
 * dresses it; the module brings no CSS for the shop. Every method returns escaped HTML.
 *
 * @phpstan-import-type Data from Recipe
 */
final class Html {

	/**
	 * An icon of the theme's sprite.
	 *
	 * @param string $name  Icon.
	 * @param bool   $small 20 px instead of 24.
	 * @param string $extra Extra class.
	 */
	public static function icon( string $name, bool $small = false, string $extra = '' ): string {
		return sprintf(
			'<svg class="%1$s" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><use href="#lc-icon-%2$s"></use></svg>',
			esc_attr( trim( 'lc-icon' . ( $small ? ' lc-icon--sm' : '' ) . ' ' . $extra ) ),
			esc_attr( $name )
		);
	}

	/**
	 * HTML attributes; null and false values are left out, true prints the bare name.
	 *
	 * @param array<string, mixed> $attributes Attributes.
	 */
	public static function attrs( array $attributes ): string {
		$html = '';
		foreach ( $attributes as $name => $value ) {
			if ( null === $value || false === $value ) {
				continue;
			}
			$html .= true === $value ? ' ' . esc_attr( $name ) : sprintf( ' %s="%s"', esc_attr( $name ), esc_attr( (string) $value ) );
		}
		return $html;
	}

	/**
	 * Button or link with the Button classes.
	 *
	 * @param string               $text Text.
	 * @param array<string, mixed> $args variant, size, href, block, class, icon, icon_left, attrs.
	 */
	public static function button( string $text, array $args = array() ): string {
		$variant = (string) ( $args['variant'] ?? 'primary' );
		$size    = (string) ( $args['size'] ?? 'md' );
		$href    = $args['href'] ?? null;
		$classes = array_filter(
			array(
				'lc-btn',
				'button',
				'primary' !== $variant ? 'lc-btn--' . $variant : '',
				'md' !== $size ? 'lc-btn--' . $size : '',
				empty( $args['block'] ) ? '' : 'lc-btn--block',
				(string) ( $args['class'] ?? '' ),
			)
		);
		$attrs   = array_merge(
			array(
				'class' => implode( ' ', $classes ),
				'href'  => $href,
				'type'  => null === $href ? 'button' : null,
			),
			(array) ( $args['attrs'] ?? array() )
		);
		return sprintf(
			'<%1$s%2$s>%3$s%4$s%5$s</%1$s>',
			null === $href ? 'button' : 'a',
			self::attrs( $attrs ),
			empty( $args['icon_left'] ) ? '' : self::icon( (string) $args['icon_left'] ),
			esc_html( $text ),
			empty( $args['icon'] ) ? '' : self::icon( (string) $args['icon'] )
		);
	}

	/**
	 * Round icon button.
	 *
	 * @param string               $icon  Icon.
	 * @param string               $label Accessible name.
	 * @param array<string, mixed> $attrs Attributes.
	 */
	public static function icon_button( string $icon, string $label, array $attrs = array() ): string {
		return sprintf(
			'<button%1$s>%2$s</button>',
			self::attrs(
				array_merge(
					array(
						'type'       => 'button',
						'class'      => 'lc-btn lc-btn--icon',
						'aria-label' => $label,
					),
					$attrs
				)
			),
			self::icon( $icon )
		);
	}

	/**
	 * Notice.
	 *
	 * @param string $html Escaped sentence.
	 * @param string $tone neutral, info, success, warning or error.
	 * @param string $icon Icon.
	 */
	public static function notice( string $html, string $tone = 'neutral', string $icon = 'info' ): string {
		return sprintf(
			'<div class="lc-notice body-sm lc-notice--%1$s" role="%2$s">%3$s<span>%4$s</span></div>',
			esc_attr( $tone ),
			'error' === $tone ? 'alert' : 'status',
			self::icon( $icon, true ),
			$html
		);
	}

	/**
	 * A date as the site writes them («26 de octubre de 2026»).
	 *
	 * @param int $timestamp Timestamp.
	 */
	public static function date( int $timestamp ): string {
		return (string) wp_date( (string) get_option( 'date_format' ), $timestamp );
	}

	/**
	 * Name of the brand in the texts («el equipo de La Chinata»).
	 */
	public static function brand(): string {
		return Company::trade_name();
	}

	/**
	 * ArticleMeta: section, publication date (always), update date (only after a real
	 * review) and reading time (not in recipes).
	 *
	 * @param \WP_Post $post    Post.
	 * @param bool     $reading With the reading time.
	 */
	public static function meta( \WP_Post $post, bool $reading = true ): string {
		$section = Model::section_of( $post );
		$parts   = array();
		$dates   = Dates::of( $post );
		$parts[] = sprintf(
			'<span>%s</span>',
			sprintf(
				/* translators: %s: date. */
				esc_html__( 'Publicado el %s', 'lachinata-core' ),
				sprintf( '<time datetime="%1$s">%2$s</time>', esc_attr( gmdate( 'c', $dates['published'] ) ), esc_html( self::date( $dates['published'] ) ) )
			)
		);
		if ( null !== $dates['updated'] ) {
			$parts[] = sprintf(
				'<span>%s</span>',
				sprintf(
					/* translators: %s: date. */
					esc_html__( 'Actualizado el %s', 'lachinata-core' ),
					sprintf( '<time datetime="%1$s">%2$s</time>', esc_attr( gmdate( 'c', $dates['updated'] ) ), esc_html( self::date( $dates['updated'] ) ) )
				)
			);
		}
		if ( $reading ) {
			$time = Text::reading_time( (int) get_post_meta( $post->ID, Fields::WORDS, true ) );
			if ( '' !== $time ) {
				$parts[] = '<span>' . esc_html( $time ) . '</span>';
			}
		}
		$link = '';
		if ( null !== $section ) {
			$href = Query::section_url( $section );
			$link = '' === $href
				? sprintf( '<span class="lc-ameta__sec label">%s</span>', esc_html( $section->name ) )
				: sprintf( '<a href="%1$s" class="lc-ameta__sec label">%2$s</a>', esc_url( $href ), esc_html( $section->name ) );
		}
		return '<p class="lc-ameta body-sm">' . $link . implode( '', $parts ) . '</p>';
	}

	/**
	 * SummaryBox («En pocas palabras»).
	 *
	 * @param string $text  Plain text (paragraphs separated by blank lines).
	 * @param string $title Title.
	 */
	public static function summary( string $text, string $title = '' ): string {
		$text = trim( $text );
		if ( '' === $text ) {
			return '';
		}
		$title = '' !== $title ? $title : __( 'En pocas palabras', 'lachinata-core' );
		$paras = array_filter( array_map( 'trim', (array) preg_split( '/\n\s*\n/', $text ) ), static fn( string $value ): bool => '' !== $value );
		return sprintf(
			'<aside class="lc-summary" aria-label="%1$s"><p class="lc-summary__title eyebrow">%2$s</p><div class="body">%3$s</div></aside>',
			esc_attr( $title ),
			esc_html( $title ),
			implode( '', array_map( static fn( string $para ): string => '<p>' . esc_html( $para ) . '</p>', $paras ) )
		);
	}

	/**
	 * Toc: folding in mobile (`details`, closed), fixed column on desktop (`side`).
	 *
	 * @param array<int, array{text: string, href: string, level: int}> $items  Items.
	 * @param string                                                    $layout '' or side.
	 */
	public static function toc( array $items, string $layout = '' ): string {
		if ( ! $items ) {
			return '';
		}
		$title = __( 'En este artículo', 'lachinata-core' );
		$list  = '<ol class="lc-toc__list">';
		foreach ( $items as $item ) {
			$list .= sprintf(
				'<li%1$s><a href="%2$s" class="body-sm">%3$s</a></li>',
				3 === $item['level'] ? ' class="lc-toc__sub"' : '',
				esc_attr( $item['href'] ),
				esc_html( $item['text'] )
			);
		}
		$list .= '</ol>';
		if ( 'side' === $layout ) {
			return sprintf( '<nav class="lc-toc lc-toc--side" aria-label="%1$s" data-lc-toc><p class="label lc-toc__title">%2$s</p>%3$s</nav>', esc_attr( $title ), esc_html( $title ), $list );
		}
		return sprintf(
			'<details class="lc-toc"><summary class="label">%1$s%2$s%3$s</summary><nav aria-label="%4$s">%5$s</nav></details>',
			self::icon( 'list', true ),
			esc_html( $title ),
			self::icon( 'chevron-down', true, 'lc-toc__chev' ),
			esc_attr( $title ),
			$list
		);
	}

	/**
	 * ArticleCard (RecipeCard with a recipe).
	 *
	 * @param \WP_Post             $post   Post.
	 * @param string               $layout vertical, horizontal or feature.
	 * @param array<string, mixed> $attrs  Attributes of the article (measurement).
	 */
	public static function card( \WP_Post $post, string $layout = 'vertical', array $attrs = array() ): string {
		$format  = Model::format_of( $post );
		$recipe  = Model::RECIPE === $format;
		$feature = 'feature' === $layout;
		$href    = (string) get_permalink( $post );
		$ratio   = $feature ? '4 / 3' : ( 'horizontal' === $layout ? '1 / 1' : ( $recipe ? '4 / 5' : '3 / 2' ) );
		$section = Model::section_of( $post );
		$image   = (int) get_post_thumbnail_id( $post );
		$media   = $image
			? wp_get_attachment_image(
				$image,
				$feature ? 'large' : ( 'horizontal' === $layout ? 'thumbnail' : 'medium_large' ),
				false,
				array(
					'alt'     => '',
					'loading' => $feature ? 'eager' : 'lazy',
					'sizes'   => $feature ? '(min-width: 1024px) 740px, 100vw' : ( 'horizontal' === $layout ? '104px' : '(min-width: 1024px) 300px, 50vw' ),
				)
			)
			: '<span class="lc-card__halo"></span>';
		$facts   = array();
		if ( $recipe ) {
			$card = Recipe::card( $post->ID );
			if ( '' !== $card['time'] ) {
				$facts[] = '<span class="lc-acard__fact">' . self::icon( 'clock', true ) . esc_html( $card['time'] ) . '</span>';
			}
			if ( '' !== $card['difficulty'] ) {
				$facts[] = '<span>' . esc_html( $card['difficulty'] ) . '</span>';
			}
		} else {
			$time = Text::reading_time( (int) get_post_meta( $post->ID, Fields::WORDS, true ) );
			if ( '' !== $time ) {
				$facts[] = '<span>' . esc_html( $time ) . '</span>';
			}
		}
		$excerpt = '';
		if ( $feature ) {
			$summary = (string) get_post_meta( $post->ID, Fields::SUMMARY, true );
			$text    = '' !== trim( $summary ) ? wp_trim_words( $summary, 40, '…' ) : ( has_excerpt( $post ) ? get_the_excerpt( $post ) : Text::excerpt( $post->post_content ) );
			$excerpt = '' === $text ? '' : '<p class="lc-acard__excerpt body">' . esc_html( $text ) . '</p>';
		}
		return sprintf(
			'<article%1$s><a href="%2$s" class="lc-acard__media" tabindex="-1" aria-hidden="true" style="aspect-ratio: %3$s;%4$s">%5$s</a><div class="lc-acard__body">%6$s<a href="%2$s" class="lc-acard__title %7$s">%8$s</a>%9$s<div class="lc-acard__meta body-sm">%10$s</div></div></article>',
			self::attrs( array_merge( array( 'class' => 'lc-acard lc-acard--' . $layout ), $attrs ) ),
			esc_url( $href ),
			esc_attr( $ratio ),
			$image ? '' : ' background: var(--tint-' . esc_attr( Query::tint( $post ) ) . ');',
			$media,
			null === $section ? '' : '<span class="lc-acard__sec eyebrow">' . esc_html( $section->name ) . '</span>',
			$feature ? 'editorial-h2' : 'h4',
			esc_html( get_the_title( $post ) ),
			$excerpt,
			implode( '', $facts )
		);
	}

	/**
	 * Stepper of the servings (`output`): the script enables the buttons and scales.
	 *
	 * @param int $servings Servings.
	 */
	private static function servings( int $servings ): string {
		$label = __( 'Raciones', 'lachinata-core' );
		return sprintf(
			'<div class="lc-stepper" role="group" aria-label="%1$s" data-lc-servings="%2$d"><button type="button" aria-label="%3$s" disabled data-lc-step="-1">%4$s</button><output class="label" aria-live="polite">%2$d</output><button type="button" aria-label="%5$s" disabled data-lc-step="1">%6$s</button></div>',
			esc_attr( $label ),
			$servings,
			esc_attr__( 'Menos', 'lachinata-core' ),
			self::icon( 'minus', true ),
			esc_attr__( 'Más', 'lachinata-core' ),
			self::icon( 'plus', true )
		);
	}

	/**
	 * RecipeHeader: the times that exist, the total, the difficulty, the servings that
	 * scale and the actions (cook mode and print, which need the script: hidden until it
	 * runs).
	 *
	 * @param array<string, mixed> $recipe Recipe.
	 * @phpstan-param Data $recipe
	 */
	public static function recipe_header( array $recipe ): string {
		$facts = array_filter(
			array(
				__( 'Preparación', 'lachinata-core' ) => Recipe::duration( $recipe['prep'] ),
				__( 'Cocción', 'lachinata-core' )     => Recipe::duration( $recipe['cook'] ),
				__( 'Reposo', 'lachinata-core' )      => Recipe::duration( $recipe['rest'] ),
				__( 'Total', 'lachinata-core' )       => Recipe::duration( Recipe::total( $recipe ) ),
				__( 'Dificultad', 'lachinata-core' )  => Recipe::difficulty( $recipe['difficulty'] ),
			),
			static fn( string $value ): bool => '' !== $value
		);
		$dl    = '';
		foreach ( $facts as $name => $value ) {
			$dl .= sprintf( '<div class="lc-rhead__fact"><dt class="caption">%1$s</dt><dd class="label">%2$s</dd></div>', esc_html( (string) $name ), esc_html( $value ) );
		}
		$row = '';
		if ( $recipe['servings'] > 0 ) {
			$row .= sprintf( '<div class="lc-rhead__serv">%1$s<span class="label">%2$s</span>%3$s</div>', self::icon( 'users', true ), esc_html__( 'Raciones', 'lachinata-core' ), self::servings( $recipe['servings'] ) );
		}
		$actions = '';
		if ( $recipe['steps'] ) {
			$actions .= self::button(
				__( 'Modo cocina', 'lachinata-core' ),
				array(
					'variant'   => 'secondary',
					'size'      => 'sm',
					'icon_left' => 'utensils',
					'attrs'     => array(
						'data-lc-cook' => '',
						'hidden'       => true,
					),
				)
			);
		}
		$actions .= self::icon_button(
			'printer',
			__( 'Imprimir la receta', 'lachinata-core' ),
			array(
				'data-lc-print' => '',
				'hidden'        => true,
			)
		);
		$row     .= '<div class="lc-rhead__actions">' . $actions . '</div>';
		return sprintf(
			'<section class="lc-rhead" aria-label="%1$s">%2$s<div class="lc-rhead__row">%3$s</div></section>',
			esc_attr__( 'Datos de la receta', 'lachinata-core' ),
			'' === $dl ? '' : '<dl class="lc-rhead__facts">' . $dl . '</dl>',
			$row
		);
	}

	/**
	 * IngredientList: real check boxes, the link to the product under the line (outside
	 * the label) when it is on sale, and the quantity marked for the scaling.
	 *
	 * @param array<string, mixed> $recipe Recipe.
	 * @phpstan-param Data $recipe
	 * @param string               $id     Prefix of the ids.
	 */
	public static function ingredients( array $recipe, string $id = 'ing' ): string {
		$html = '<div class="lc-ing">';
		foreach ( $recipe['groups'] as $g => $group ) {
			$html .= '<div class="lc-ing__group">';
			if ( '' !== $group['title'] ) {
				$html .= '<h3 class="label lc-ing__gtitle">' . esc_html( $group['title'] ) . '</h3>';
			}
			$html .= '<ul class="lc-ing__list">';
			foreach ( $group['items'] as $i => $item ) {
				$cid     = $id . '-' . $g . '-' . $i;
				$number  = Recipe::number( $item['qty'] );
				$qty     = trim( $item['qty'] . ' ' . $item['unit'] );
				$product = Recipe::product( $item );
				$html   .= sprintf(
					'<li class="lc-ing__item"><input type="checkbox" id="%1$s" class="lc-ing__check"><label for="%1$s" class="body">%2$s%3$s%4$s</label>%5$s</li>',
					esc_attr( $cid ),
					'' === $qty ? '' : sprintf(
						'<span class="lc-ing__qty"%1$s>%2$s</span> ',
						null === $number ? '' : self::attrs(
							array(
								'data-lc-qty'  => (string) $number,
								'data-lc-unit' => $item['unit'],
							)
						),
						esc_html( $qty )
					),
					esc_html( $item['name'] ),
					'' === $item['note'] ? '' : '<span class="lc-ing__note">, ' . esc_html( $item['note'] ) . '</span>',
					null === $product ? '' : sprintf(
						'<a href="%1$s" class="lc-ing__prod body-sm" data-lc-ingredient-product="%2$d">%3$s%4$s</a>',
						esc_url( $product->get_permalink() ),
						$product->get_id(),
						self::icon( 'leaf', true ),
						esc_html( $product->get_name() )
					)
				);
			}
			$html .= '</ul></div>';
		}
		return $html . '</div>';
	}

	/**
	 * StepList.
	 *
	 * @param array<string, mixed> $recipe Recipe.
	 * @phpstan-param Data $recipe
	 */
	public static function steps( array $recipe ): string {
		$html = '<ol class="lc-rsteps">';
		foreach ( $recipe['steps'] as $i => $step ) {
			$html .= sprintf(
				'<li class="lc-rsteps__item" id="paso-%5$d"><span class="lc-rsteps__n label" aria-hidden="true">%1$s</span><div class="lc-rsteps__body"><p class="body">%2$s</p>%3$s%4$s</div></li>',
				esc_html( number_format_i18n( $i + 1 ) ),
				nl2br( esc_html( $step['text'] ) ),
				$step['time'] ? '<span class="lc-rsteps__time body-sm">' . self::icon( 'clock', true ) . esc_html( Recipe::duration( $step['time'] ) ) . '</span>' : '',
				$step['image'] ? wp_get_attachment_image(
					$step['image'],
					'medium_large',
					false,
					array(
						'class'   => 'lc-rsteps__img',
						'alt'     => $step['alt'],
						'loading' => 'lazy',
					)
				) : '',
				$i + 1
			);
		}
		return $html . '</ol>';
	}

	/**
	 * CookMode in a dialog that the script opens: one step at a time, big type, Previous
	 * and Next at hand, the step announced; the script keeps the screen on.
	 *
	 * @param array<string, mixed> $recipe Recipe.
	 * @phpstan-param Data $recipe
	 * @param string               $title  Title of the recipe.
	 */
	public static function cook_mode( array $recipe, string $title ): string {
		if ( ! $recipe['steps'] ) {
			return '';
		}
		$steps = array_map(
			static fn( array $step ): array => array(
				'text' => $step['text'],
				'time' => $step['time'] ? Recipe::duration( $step['time'] ) : '',
			),
			$recipe['steps']
		);
		$total = count( $steps );
		return sprintf(
			'<dialog class="lc-cookdlg" data-lc-cook-dialog aria-label="%1$s"><section class="lc-cook" aria-label="%1$s"><div class="lc-cook__top"><span class="label" data-lc-cook-count>%2$s</span>%3$s</div><div class="lc-cook__bar" aria-hidden="true"><span style="width: %4$s%%"></span></div><p class="lc-cook__title caption">%5$s</p><p class="lc-cook__text" aria-live="polite" data-lc-cook-text>%6$s</p><span class="lc-rsteps__time label" data-lc-cook-time hidden>%7$s<span></span></span><p class="lc-cook__note caption" data-lc-cook-note hidden>%8$s</p><div class="lc-cook__nav">%9$s%10$s</div></section><script type="application/json" data-lc-cook-steps>%11$s</script></dialog>',
			esc_attr__( 'Modo cocina', 'lachinata-core' ),
			/* translators: 1: step, 2: steps. */
			esc_html( sprintf( __( 'Paso %1$s de %2$s', 'lachinata-core' ), number_format_i18n( 1 ), number_format_i18n( $total ) ) ),
			self::icon_button( 'close', __( 'Salir del modo cocina', 'lachinata-core' ), array( 'data-lc-cook-close' => '' ) ),
			esc_attr( (string) round( 100 / $total, 2 ) ),
			esc_html( $title ),
			esc_html( $steps[0]['text'] ),
			self::icon( 'clock', true ),
			esc_html__( 'La pantalla no se apaga mientras cocinas.', 'lachinata-core' ),
			self::button(
				__( 'Anterior', 'lachinata-core' ),
				array(
					'variant'   => 'secondary',
					'icon_left' => 'chevron-left',
					'attrs'     => array(
						'data-lc-cook-prev' => '',
						'disabled'          => true,
					),
				)
			),
			self::button(
				__( 'Siguiente', 'lachinata-core' ),
				array(
					'icon'  => 'chevron-right',
					'attrs' => array( 'data-lc-cook-next' => '' ),
				)
			),
			wp_json_encode( $steps, JSON_HEX_TAG | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES )
		);
	}

	/**
	 * RecipeProducts («Ingredientes {marca} de esta receta»): photo, name, format and price
	 * of each product with its «+» (the theme's add to bag), and «Añadir los N a la bolsa»
	 * when more than one can be bought. Sold out ones say so and do not count.
	 *
	 * @param \WC_Product[] $products Products.
	 * @param string        $list_name Name of the list for the measurement («Receta: {título}»).
	 */
	public static function recipe_products( array $products, string $list_name ): string {
		if ( ! $products ) {
			return '';
		}
		/* translators: %s: brand («La Chinata»). */
		$title = sprintf( __( 'Ingredientes %s de esta receta', 'lachinata-core' ), self::brand() );
		$items = '';
		$buy   = array();
		foreach ( $products as $index => $product ) {
			$sold_out = ! $product->is_in_stock() || ! $product->is_purchasable();
			$direct   = ! $sold_out && $product->is_type( 'simple' );
			if ( $direct ) {
				$buy[] = $product->get_id();
			}
			$image = (int) $product->get_image_id();
			$name  = $product->get_name();
			$add   = '';
			if ( $sold_out ) {
				$add = '<span class="lc-badge badge lc-badge--soldout">' . esc_html__( 'Agotado', 'lachinata-core' ) . '</span>';
			} elseif ( $direct ) {
				$add = sprintf(
					'<a href="%1$s" class="lc-btn lc-btn--cart lc-card__add" aria-label="%2$s" data-lc-add="%3$d" data-lc-name="%4$s" rel="nofollow">%5$s</a>',
					esc_url( add_query_arg( 'add-to-cart', $product->get_id(), wc_get_cart_url() ) ),
					/* translators: %s: product name. */
					esc_attr( sprintf( __( 'Añadir %s a la bolsa', 'lachinata-core' ), $name ) ),
					$product->get_id(),
					esc_attr( $name ),
					self::icon( 'plus', true )
				);
			} else {
				$add = sprintf(
					'<a href="%1$s" class="lc-btn lc-btn--cart lc-card__add" aria-label="%2$s">%3$s</a>',
					esc_url( $product->get_permalink() ),
					/* translators: %s: product name. */
					esc_attr( sprintf( __( 'Elegir formato de %s', 'lachinata-core' ), $name ) ),
					self::icon( 'plus', true )
				);
			}
			$items .= sprintf(
				'<li class="lc-rprod__item" data-lc-item="%1$d" data-lc-list="%2$s" data-lc-index="%3$d"><a href="%4$s" class="lc-rprod__media" tabindex="-1" aria-hidden="true"%5$s>%6$s</a><div class="lc-rprod__info"><a href="%4$s" class="label">%7$s</a>%8$s<div class="lc-price"><span class="lc-price__now price" data-no-translation>%9$s</span></div></div>%10$s</li>',
				$product->get_id(),
				esc_attr( $list_name ),
				$index + 1,
				esc_url( $product->get_permalink() ),
				$image ? '' : ' style="background: var(--tint-gourmet)"',
				$image ? wp_get_attachment_image(
					$image,
					'thumbnail',
					false,
					array(
						'alt'     => '',
						'loading' => 'lazy',
					)
				) : '<span class="lc-card__halo"></span>',
				esc_html( $name ),
				'' === self::format( $product ) ? '' : '<span class="caption lc-rprod__meta">' . esc_html( self::format( $product ) ) . '</span>',
				wp_kses_post( $product->get_price_html() ),
				$add
			);
		}
		$all = '';
		if ( count( $buy ) > 1 ) {
			$label = sprintf(
				/* translators: %s: number of products. */
				_n( 'Añadir el %s a la bolsa', 'Añadir los %s a la bolsa', count( $buy ), 'lachinata-core' ),
				number_format_i18n( count( $buy ) )
			);
			$all = self::button(
				$label,
				array(
					'variant'   => 'cart',
					'block'     => true,
					'icon_left' => 'bag',
					'href'      => add_query_arg( AddMany::VAR, implode( ',', $buy ), wc_get_cart_url() ),
					'attrs'     => array(
						'data-lc-add'         => implode( ',', $buy ),
						'data-lc-added-label' => __( 'Añadidos a la bolsa', 'lachinata-core' ),
						'data-lc-name'        => sprintf(
							/* translators: %s: number of products. */
							_n( '%s producto', '%s productos', count( $buy ), 'lachinata-core' ),
							number_format_i18n( count( $buy ) )
						),
						'rel'                 => 'nofollow',
					),
				)
			);
		}
		return sprintf(
			'<section class="lc-rprod" aria-label="%1$s"><h2 class="h3 lc-rprod__title">%2$s</h2><ul class="lc-rprod__list">%3$s</ul>%4$s</section>',
			esc_attr( $title ),
			esc_html( $title ),
			$items,
			$all
		);
	}

	/**
	 * The format line of a product: its content and unit as the product page says it
	 * (`lachinata/product/unit_price`, first part), or its variation attributes.
	 *
	 * @param \WC_Product $product Product.
	 */
	public static function format( \WC_Product $product ): string {
		/** This filter is documented in theme/inc/catalog.php */
		$unit = wp_strip_all_tags( (string) apply_filters( 'lachinata/product/unit_price', '', $product ) ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingSinceComment -- The theme's hook.
		$unit = trim( (string) strtok( $unit, '|' ) );
		return $unit;
	}
}
