# Blog y recetas (`content`)

Desde la 0.13.0 (incremento 10a). Especificación: `design-system/sistema/08-contenido-seo.md`; composición: sección «Blog y recetas» de `02-plantillas.md` y los tableros Blog, Articulo, Receta y RecetaCocina (y sus versiones de escritorio).

## Qué hace

| Pieza | Cómo | Dónde |
| --- | --- | --- |
| **Modelo.** Las entradas siguen siendo `post` con su URL (`/slug/`). Formato (receta, artículo o noticia) en `_lc_content_formato`; secciones jerárquicas `lc_seccion` en `/blog/{seccion}/` (los tipos de plato son subsecciones de la sección de recetas: `/blog/recetas/postres/`); como mucho 20 temas `lc_tema` en `/blog/tema/{slug}/`; la revista en `/blog/`. Comentarios cerrados | taxonomías, regla de reescritura y `comments_open` | `Model.php`, `SectionFields.php` |
| **«En pocas palabras», revisión y fuentes.** Resumen visible arriba y base de la meta descripción; «Publicado el» siempre y «Actualizado el» solo con una revisión real (la fecha que marca el editor, nunca un guardado); fuentes enlazadas al pie | panel «Blog y recetas» del editor | `Editor.php`, `Dates.php`, `src/editor.js` |
| **Receta estructurada.** Bloque `lachinata/receta`: raciones, preparación, cocción y reposo (el total se calcula), dificultad, cocina, grupos de ingredientes (cantidad, unidad, ingrediente, nota y producto por ID y SKU), pasos con tiempo e imagen, consejos, variantes, conservación y vídeo (enlace, sin reproductor de terceros). Sin nutrición ni valoraciones | bloque dinámico; índice en metadatos al guardar | `Recipe.php`, `RecipeBlock.php`, `blocks/receta/` |
| **Plantillas.** Revista, sección o tema, artículo y receta con los componentes del grupo «Blog» (ArticleCard, RecipeCard, ArticleMeta, SummaryBox, Toc, RecipeHeader, IngredientList, StepList, CookMode, RecipeProducts). Índice automático desde 1.200 palabras | `template_include` con `Templates::locate()` | `Pages.php`, `Html.php`, `templates/content/` |
| **En el navegador.** Raciones que escalan (las cantidades que no son números no cambian), modo cocina con Screen Wake Lock y flechas del teclado, imprimir, la sección que se lee en el índice lateral. Sin JavaScript la receta está entera y sus casillas funcionan | módulo ES | `src/front.js` |
| **Ingredientes de la tienda.** «Ingredientes {marca} de esta receta» justo después de los ingredientes, con el «+» del tema (0.12.3) y «Añadir los N a la bolsa» (`?lc-add-many=`, también sin JavaScript). Un producto despublicado o agotado deja el ingrediente en texto | — | `Html::recipe_products()`, `AddMany.php` |
| **Recetas con un producto.** En la ficha (como mucho 3, debajo de todo lo que sirve para comprar, «Ver todas» a `/blog/recetas/?producto={id}` con `noindex`), en gracias y en el correo de pedido enviado («Ideas para tu {producto}»). Solo en las categorías del ajuste; nunca en la bolsa ni en el checkout | `lachinata/product/after`, `lachinata/thankyou/after`, `woocommerce_email_after_order_table` | `ProductRecipes.php` |
| **Contenido que caduca.** Aviso en las noticias de más de 12 meses (ajuste); lista «para revisar» con las entradas de salud y belleza sin revisar en 12 meses y las que tienen motivos (la migración; en 10b, productos que cambian y oleotecas que cierran) | aviso del panel y filtro de la lista de entradas | `Freshness.php` |
| **Datos estructurados.** `Organization` y `WebSite` en todo el sitio (de «Datos de la empresa», con «Redes» como `sameAs`), `BreadcrumbList`, `BlogPosting` o `Recipe` y `ItemList`. El autor es siempre la organización. Las entidades de Rank Math de esos tipos se quitan; Rank Math sigue con títulos, descripciones, sitemaps y redirecciones | `wp_head`, `rank_math/json_ld` | `Seo.php` |
| **Archivos antiguos.** 301 por regla: categoría a su sección (ajuste `category_sections`), etiqueta a la sección de su entrada más reciente, autor a `/blog/` | `template_redirect` | `Redirects.php` |
| **Migración.** `wp lachinata content migrate --map=… [--gsc=…] [--report=…] [--dry-run]`: secciones, formato y sección de cada entrada, recetas del esquema de Rank Math y del texto al bloque (analizador de ingredientes que marca lo dudoso; lo que pasa al bloque sale del texto), subsecciones desde `recipeCategory`, 301 de categorías, clics de Search Console y códigos cortos, con informe en Markdown. Idempotente | WP-CLI | `Migration.php`, `Ingredients.php`, `RecipeText.php`, `Cli.php` |

## Depende de

- WooCommerce 10 (productos de las recetas). Ningún módulo obligatorio.
- Tema `lachinata` para el aspecto (`blog.css`, `components.css`), los hooks de la ficha y de gracias, la bolsa y el «+». Con otro tema las páginas salen con las clases `.lc-*` sin vestir.
- Rank Math (opcional): sin él, el módulo pinta la meta descripción y el canonical de sus páginas.
- Núcleo: `Company` («Datos de la empresa» y «Redes»), `Templates`, `Settings`, `Hooks`.

## Hooks que escucha

- WordPress: `init`, `query_vars`, `pre_get_posts`, `template_include`, `template_redirect`, `wp_head`, `wp_robots`, `document_title_parts`, `comments_open`, `pings_open`, `pre_insert_term`, `save_post_post`, `enqueue_block_editor_assets`, `admin_notices`, `wp_loaded` (añadir varios), `lc_seccion_add_form_fields`, `lc_seccion_edit_form_fields`, `created_lc_seccion`, `edited_lc_seccion`.
- WooCommerce: `woocommerce_email_after_order_table` (pedido enviado).
- Tema: `lachinata/breadcrumb/items`, `lachinata/view/editorial`, `lachinata/view/blog`, `lachinata/view/secondary`, `lachinata/view/back_url`, `lachinata/app_bar/section`, `lachinata/product/after`, `lachinata/thankyou/after`.
- Rank Math: `rank_math/json_ld`, `rank_math/frontend/canonical`, `rank_math/frontend/description`, `rank_math/frontend/title`.
- Núcleo: `lachinata/core/admin_tabs`.

## Hooks que emite

- En el navegador: `lachinata:recipe:view`, `:scale`, `:print`, `:cook_mode`, `:ingredient_product` (`theme/HOOKS.md`, «Eventos del navegador»). Los medirá `tracking` en 10b.
- Lee (no emite) `lachinata/category/tint` y `lachinata/product/unit_price` del tema.

## Datos que guarda

- Entradas: `_lc_content_formato`, `_lc_content_resumen`, `_lc_content_revisado`, `_lc_content_fuentes` (panel del editor); `_lc_content_receta`, `_lc_content_producto` (una fila por producto), `_lc_content_minutos`, `_lc_content_palabras` (índice que se reescribe al guardar); `_lc_content_clics` (Search Console) y `_lc_content_revisar` (motivos).
- La receta misma vive en los atributos del bloque `lachinata/receta`, en el contenido de la entrada.
- Términos de `lc_seccion`: `_lc_content_categoria` y `_lc_content_orden`.
- Taxonomías `lc_seccion` y `lc_tema`; opción `lachinata_content_rewrite` (versión de las reglas de reescritura).
- Las entradas y sus campos son contenido del sitio: «Borrar datos» solo borra los metadatos de término y las opciones.

## REST y API para Odoo

Ninguna ruta propia. Los campos del panel van por la REST de WordPress (`meta` de `post`). Nada para Odoo.

## Ajustes y exportación

WooCommerce → La Chinata → Blog. Viajan en el JSON: `blog_eyebrow`, `blog_title`, `blog_lead` (textos de la revista; sin ellos, «La revista de {marca}» y «Blog»), `recipe_section`, `health_sections`, `product_recipes` y `category_sections` (por slug), `subsection_minimum` (6), `review_months` (12), `news_warning_months` (12). Las secciones y los temas son contenido: no viajan.

## Qué pasa al apagarlo

Las entradas vuelven a la plantilla `single.php` del tema, sin receta (el bloque no se pinta), sin `/blog/` ni secciones (404), sin redirecciones de categorías y sin el schema propio (vuelve el de Rank Math). Los datos se quedan y vuelven al encenderlo.

## Pruebas

- PHPUnit (`plugin/modules/content/tests/`): analizador de ingredientes y del texto de las recetas, receta como datos (tiempos, cantidades, productos por ID y SKU, índice), recetas de un producto y su ajuste, modelo (temas, slugs reservados, formatos, comentarios), fechas, noticia antigua, salud y belleza sin revisar, subsecciones, redirecciones, índice y tiempo de lectura, datos estructurados y la migración (en seco, de verdad e idempotente).
- e2e (`tests/e2e/content.spec.mjs`, sobre `tools/seed-blog.php`): revista, receta (raciones, casillas, modo cocina), ingredientes de la tienda y «Añadir los 2», artículo largo con índice y fuentes, noticia antigua, recetas en la ficha con «Ver todas», datos estructurados, archivos antiguos y la receta sin JavaScript.
- Lighthouse: revista, artículo y receta con mínimo 95 (`tools/lighthouse.mjs`).

## Huecos conocidos

- 10b (0.13.1): enlaces a producto en el texto como referencias, revisión del archivo con la poda, `llms.txt`, rastreadores por agente, medición, entradas a «Revisar» cuando cambia un producto y aviso de oleoteca cerrada.
- `translate` (11): textos, ingredientes, pasos y slugs por idioma por el contrato `Languages`; hoy todo es una cadena traducible o contenido del sitio.
- El texto de una receta migrada que no es receta (la introducción) va después de los consejos; el tablero no lo muestra.
- Los `SocialLinks` del pie van junto al sello: el `Footer` del sistema no los tiene todavía.
