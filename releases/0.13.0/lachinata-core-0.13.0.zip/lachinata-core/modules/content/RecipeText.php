<?php
/**
 * The recipe written in the text of an entry.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

defined( 'ABSPATH' ) || exit;

/**
 * Finds in the body of an old entry the ingredients (after a heading or a bold line with
 * «Ingredientes», with «Para …» as groups) and the steps (after «Preparación»,
 * «Elaboración», «Pasos»…), as lines with the first link of each, and the pieces of the
 * body that hold them, so the migration can take them out once they are in the block. The
 * body is cut in top-level pieces: blocks when it has them, elements of the classic editor
 * when not.
 *
 * @phpstan-type Line array{text: string, href: string, heading: bool, title: bool}
 * @phpstan-type Found array{servings: int, groups: array<int, array{title: string, lines: array<int, Line>}>, steps: string[], pieces: array<int, array{0: int, 1: int}>}
 */
final class RecipeText {

	/**
	 * Heading of the ingredients.
	 */
	private const INGREDIENTS = '/\bingredientes?\b/iu';

	/**
	 * Heading of the steps.
	 */
	private const STEPS = '/\b(preparaci[oó]n|elaboraci[oó]n|instrucciones|pasos|procedimiento|modo de (hacer|preparaci[oó]n)|c[oó]mo (se hace|hacer))\b/iu';

	/**
	 * Top-level pieces of a body.
	 *
	 * @param string $content Content.
	 * @return string[]
	 */
	public static function pieces( string $content ): array {
		if ( has_blocks( $content ) ) {
			return array_map( 'serialize_block', array_values( array_filter( parse_blocks( $content ), static fn( array $block ): bool => null !== $block['blockName'] || '' !== trim( (string) $block['innerHTML'] ) ) ) );
		}
		// The classic editor keeps paragraphs as line breaks: they become <p> and <br> first.
		preg_match_all( '/<(p|ul|ol|h[1-6]|div|figure|table|blockquote)\b[^>]*>.*?<\/\1>|[^<]+|<[^>]+>/is', wpautop( $content ), $matches );
		return array_values( array_filter( $matches[0], static fn( string $piece ): bool => '' !== trim( $piece ) ) );
	}

	/**
	 * Lines of a piece: one per paragraph, item or line break.
	 *
	 * @param string $piece HTML.
	 * @return array<int, Line>
	 */
	public static function lines( string $piece ): array {
		$piece = (string) preg_replace( '/<!--.*?-->/s', '', $piece );
		$parts = (array) preg_split( '/<br\s*\/?>|<\/(?:p|li|h[1-6]|div)>/i', $piece );
		$lines = array();
		foreach ( $parts as $part ) {
			$text = trim( (string) preg_replace( '/\s+/u', ' ', html_entity_decode( wp_strip_all_tags( $part ), ENT_QUOTES, 'UTF-8' ) ), " \t\n\r\0\x0B\xC2\xA0" );
			if ( '' === $text ) {
				continue;
			}
			$href    = preg_match( '/<a\s[^>]*href=["\']([^"\']+)["\']/i', $part, $m ) ? $m[1] : '';
			$inner   = trim( (string) preg_replace( '/^.*<(?:p|li|h[1-6]|div)\b[^>]*>/is', '', $part ) );
			$inner   = trim( (string) preg_replace( '/<\/?(span|em|u|i)\b[^>]*>/i', '', $inner ) );
			$bold    = (bool) preg_match( '/^<(strong|b)\b[^>]*>.*<\/\1>[:.\s]*$/is', $inner );
			$title   = (bool) preg_match( '/<h[2-6]\b/i', $part );
			$keyword = mb_strlen( $text ) <= 60 && ( preg_match( '/^' . trim( self::INGREDIENTS, '/iu' ) . '/iu', $text ) || preg_match( '/^' . trim( self::STEPS, '/iu' ) . '/iu', $text ) );
			$heading = $title || $bold || $keyword || ( mb_strlen( $text ) <= 60 && str_ends_with( $text, ':' ) );
			$lines[] = array(
				'text'    => $heading ? rtrim( $text, ' :.' ) : rtrim( $text, ' :' ),
				'href'    => $href,
				'heading' => $heading,
				'title'   => $title,
			);
		}
		return $lines;
	}

	/**
	 * The recipe in a body.
	 *
	 * @param string $content Content.
	 * @return Found
	 */
	public static function find( string $content ): array {
		$found  = array(
			'servings' => 0,
			'groups'   => array(),
			'steps'    => array(),
			'pieces'   => array(),
		);
		$pieces = self::pieces( $content );
		$mode   = '';
		$first  = null;
		$last   = null;
		$group  = -1;
		$ranges = array();
		foreach ( $pieces as $index => $piece ) {
			$used = false;
			foreach ( self::lines( $piece ) as $line ) {
				if ( '' !== $mode && $line['heading'] && preg_match( self::INGREDIENTS, $line['text'] ) && ! preg_match( self::STEPS, $line['text'] ) ) {
					// Another block of ingredients («Ingredientes para la cobertura»).
					if ( $used ) {
						$last = $index;
					}
					$ranges = self::close( $first, $last, $ranges );
					$mode   = '';
					$first  = null;
					$last   = null;
					$used   = false;
				}
				if ( '' === $mode ) {
					if ( $line['heading'] && preg_match( self::INGREDIENTS, $line['text'] ) && mb_strlen( $line['text'] ) <= 80 ) {
						$mode  = 'ingredients';
						$first = $index;
						$used  = true;
						if ( preg_match( '/(\d+)\s*(personas|raciones|comensales|unidades)/iu', $line['text'], $m ) || preg_match( '/para\s+(\d+)/iu', $line['text'], $m ) ) {
							$found['servings'] = $found['servings'] ? $found['servings'] : (int) $m[1];
						}
						$title             = preg_match( '/ingredientes?\s+(para\s+(?!\d)[^(]+)/iu', $line['text'], $t ) ? trim( $t[1] ) : '';
						$found['groups'][] = array(
							'title' => '' === $title ? '' : mb_strtoupper( mb_substr( $title, 0, 1 ) ) . mb_substr( $title, 1 ),
							'lines' => array(),
						);
						$group             = count( $found['groups'] ) - 1;
					}
					continue;
				}
				if ( $line['heading'] && preg_match( self::STEPS, $line['text'] ) && mb_strlen( $line['text'] ) <= 80 ) {
					$mode = 'steps';
					$used = true;
					continue;
				}
				if ( 'ingredients' === $mode ) {
					if ( $line['heading'] && preg_match( '/^para\s/iu', $line['text'] ) ) {
						$found['groups'][] = array(
							'title' => $line['text'],
							'lines' => array(),
						);
						$group             = count( $found['groups'] ) - 1;
						$used              = true;
						continue;
					}
					if ( $line['heading'] ) {
						$ranges = self::close( $first, $last, $ranges );
						$mode   = '';
						$first  = null;
						$last   = null;
						continue;
					}
					// A long sentence after the ingredients: the steps, without a heading.
					if ( mb_strlen( $line['text'] ) > 90 && $found['groups'][ $group ]['lines'] ) {
						$mode = 'steps';
					} else {
						$found['groups'][ $group ]['lines'][] = $line;
						$used                                 = true;
						continue;
					}
				}
				if ( $line['heading'] && ! $line['title'] && mb_strlen( $line['text'] ) <= 40 ) {
					// A sub-heading inside the steps («Montaje», «Para la salsa»).
					$used = true;
					continue;
				}
				if ( $line['heading'] || count( $found['steps'] ) >= 40 ) {
					$ranges = self::close( $first, $last, $ranges );
					$mode   = '';
					$first  = null;
					$last   = null;
					continue;
				}
				$found['steps'][] = trim( (string) preg_replace( '/^(paso\s*)?\d+\s*[.):-]\s*/iu', '', $line['text'] ) );
				$used             = true;
			}
			if ( $used && '' !== $mode ) {
				$last = $index;
			} elseif ( $used ) {
				$ranges[ count( $ranges ) - 1 ][1] = max( $ranges[ count( $ranges ) - 1 ][1] ?? $index, $index );
			}
		}
		$ranges          = self::close( $first, $last, $ranges );
		$mode            = '';
		$first           = null;
		$last            = null;
		$found['groups'] = array_values( array_filter( $found['groups'], static fn( array $g ): bool => (bool) $g['lines'] ) );
		$found['pieces'] = $found['groups'] ? $ranges : array();
		return $found;
	}

	/**
	 * Adds a block (first and last piece) to the list, when it has both ends.
	 *
	 * @param int|null                       $first  First piece.
	 * @param int|null                       $last   Last piece.
	 * @param array<int, array{0:int,1:int}> $ranges Blocks so far.
	 * @return array<int, array{0:int,1:int}>
	 */
	private static function close( ?int $first, ?int $last, array $ranges ): array {
		if ( null !== $first && null !== $last ) {
			$ranges[] = array( $first, $last );
		}
		return $ranges;
	}

	/**
	 * The body without the pieces of the recipe.
	 *
	 * @param string                         $content Content.
	 * @param array<int, array{0:int,1:int}> $ranges  First and last piece of each block.
	 */
	public static function without( string $content, array $ranges ): string {
		$pieces = self::pieces( $content );
		foreach ( array_reverse( $ranges ) as $range ) {
			array_splice( $pieces, $range[0], $range[1] - $range[0] + 1 );
		}
		return trim( implode( "\n\n", $pieces ) );
	}
}
