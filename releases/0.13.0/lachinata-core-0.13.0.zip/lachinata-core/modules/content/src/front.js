/**
 * Entries of the blog: the servings that scale the quantities, the cook mode (one step at
 * a time, the screen kept on with Screen Wake Lock), print and the section being read in
 * the contents column. Everything works without it: the quantities are those of the
 * recipe and the contents are links. Each action is told to whoever listens
 * (`lachinata:recipe:*`, plugin/HOOKS.md); the module does not measure here.
 */
import { __, sprintf } from '@wordpress/i18n';

const emit = (name, detail = {}) =>
	document.dispatchEvent(
		new window.CustomEvent(`lachinata:${name}`, { detail })
	);

const recipe = document.querySelector('[data-lc-recipe]');
const meta = () => ({
	id: Number(recipe?.dataset.lcRecipe || 0),
	title: recipe?.dataset.lcRecipeTitle || '',
});

/**
 * A quantity for people: whole numbers from 10, one decimal below (in the language of the
 * page).
 *
 * @param {number} value Quantity.
 */
const format = (value) =>
	new Intl.NumberFormat(document.documentElement.lang || undefined, {
		maximumFractionDigits: value >= 10 ? 0 : 1,
	}).format(value >= 10 ? Math.round(value) : value);

const initServings = () => {
	const stepper = document.querySelector('[data-lc-servings]');
	if (!stepper) {
		return;
	}
	const base = Number(stepper.dataset.lcServings) || 1;
	const output = stepper.querySelector('output');
	const minus = stepper.querySelector('[data-lc-step="-1"]');
	const plus = stepper.querySelector('[data-lc-step="1"]');
	let servings = base;
	const apply = () => {
		output.textContent = String(servings);
		minus.disabled = servings <= 1;
		plus.disabled = servings >= 48;
		document.querySelectorAll('[data-lc-servings-text]').forEach((el) => {
			el.textContent = String(servings);
		});
		document.querySelectorAll('[data-lc-qty]').forEach((el) => {
			const amount = (Number(el.dataset.lcQty) * servings) / base;
			el.textContent = [format(amount), el.dataset.lcUnit]
				.filter(Boolean)
				.join(' ');
		});
	};
	stepper.addEventListener('click', (event) => {
		const button = event.target.closest('[data-lc-step]');
		if (!button || button.disabled) {
			return;
		}
		servings = Math.min(
			48,
			Math.max(1, servings + Number(button.dataset.lcStep))
		);
		apply();
		emit('recipe:scale', { ...meta(), servings });
	});
	apply();
};

const initCook = () => {
	const dialog = document.querySelector('[data-lc-cook-dialog]');
	const open = document.querySelector('[data-lc-cook]');
	if (!dialog || !open || !dialog.showModal) {
		return;
	}
	const steps = JSON.parse(
		dialog.querySelector('[data-lc-cook-steps]').textContent || '[]'
	);
	const count = dialog.querySelector('[data-lc-cook-count]');
	const text = dialog.querySelector('[data-lc-cook-text]');
	const time = dialog.querySelector('[data-lc-cook-time]');
	const bar = dialog.querySelector('.lc-cook__bar span');
	const note = dialog.querySelector('[data-lc-cook-note]');
	const prev = dialog.querySelector('[data-lc-cook-prev]');
	const next = dialog.querySelector('[data-lc-cook-next]');
	let current = 0;
	let lock = null;

	const keepAwake = async () => {
		if (!('wakeLock' in navigator) || document.hidden || !dialog.open) {
			return;
		}
		try {
			lock = await navigator.wakeLock.request('screen');
			note.hidden = false;
		} catch {
			note.hidden = true;
		}
	};
	const show = () => {
		const step = steps[current] || {};
		count.textContent = sprintf(
			/* translators: 1: step, 2: steps. */
			__('Paso %1$s de %2$s', 'lachinata-core'),
			current + 1,
			steps.length
		);
		text.textContent = step.text || '';
		time.hidden = !step.time;
		time.lastChild.textContent = step.time || '';
		bar.style.width = `${((current + 1) / Math.max(1, steps.length)) * 100}%`;
		prev.disabled = current === 0;
		// The label is the first node of the button (the arrow follows it).
		next.firstChild.nodeValue =
			current === steps.length - 1
				? __('Terminar', 'lachinata-core')
				: __('Siguiente', 'lachinata-core');
	};
	const close = () => dialog.close();

	open.hidden = false;
	open.addEventListener('click', () => {
		show();
		dialog.showModal();
		keepAwake();
		emit('recipe:cook_mode', meta());
	});
	prev.addEventListener('click', () => {
		current = Math.max(0, current - 1);
		show();
	});
	next.addEventListener('click', () => {
		if (current === steps.length - 1) {
			close();
			return;
		}
		current += 1;
		show();
	});
	dialog
		.querySelector('[data-lc-cook-close]')
		.addEventListener('click', close);
	dialog.addEventListener('keydown', (event) => {
		if (event.key === 'ArrowRight' && current < steps.length - 1) {
			current += 1;
			show();
		} else if (event.key === 'ArrowLeft' && current > 0) {
			current -= 1;
			show();
		}
	});
	dialog.addEventListener('close', () => {
		lock?.release().catch(() => {});
		lock = null;
		// Back to the recipe at the step where the cook was.
		document
			.getElementById(`paso-${current + 1}`)
			?.scrollIntoView({ block: 'center' });
		open.focus({ preventScroll: true });
	});
	document.addEventListener('visibilitychange', () => {
		if (!document.hidden && dialog.open) {
			keepAwake();
		}
	});
};

const initPrint = () => {
	const button = document.querySelector('[data-lc-print]');
	if (!button) {
		return;
	}
	button.hidden = false;
	button.addEventListener('click', () => window.print());
	window.addEventListener('beforeprint', () => emit('recipe:print', meta()));
};

const initToc = () => {
	const toc = document.querySelector('[data-lc-toc]');
	if (!toc || !('IntersectionObserver' in window)) {
		return;
	}
	const links = [...toc.querySelectorAll('a[href^="#"]')];
	const targets = links
		.map((link) =>
			document.getElementById(
				decodeURIComponent(link.getAttribute('href').slice(1))
			)
		)
		.filter(Boolean);
	const mark = (id) =>
		links.forEach((link) => {
			const on = link.getAttribute('href') === `#${id}`;
			link.classList.toggle('lc-toc__on', on);
			if (on) {
				link.setAttribute('aria-current', 'true');
			} else {
				link.removeAttribute('aria-current');
			}
		});
	const observer = new window.IntersectionObserver(
		(entries) => {
			const visible = entries
				.filter((entry) => entry.isIntersecting)
				.sort(
					(a, b) =>
						a.boundingClientRect.top - b.boundingClientRect.top
				);
			if (visible[0]) {
				mark(visible[0].target.id);
			}
		},
		{ rootMargin: '-96px 0px -60% 0px' }
	);
	targets.forEach((target) => observer.observe(target));
};

initServings();
initCook();
initPrint();
initToc();
if (recipe) {
	emit('recipe:view', meta());
}
document.addEventListener('click', (event) => {
	const link = event.target.closest('[data-lc-ingredient-product]');
	if (link) {
		emit('recipe:ingredient_product', {
			...meta(),
			product: Number(link.dataset.lcIngredientProduct),
		});
	}
});
