<?php
/**
 * A recipe (`/slug/`): title, ArticleMeta, «En pocas palabras», photo 4:5 (4:3 on
 * desktop), RecipeHeader, ingredients with check boxes, «Ingredientes {marca} de esta
 * receta» right after them, steps, tips, the rest of the text of the entry, the line of
 * the brand and more recipes of its subsection. On desktop, ingredients and products in a
 * fixed column on the left and the steps on the right (Receta.dc.html,
 * RecetaDesktop.dc.html). The cook mode opens over the page (RecetaCocina.dc.html).
 *
 * The theme can override it with `lachinata/content/recipe.php`.
 *
 * @package LaChinata\Core
 */

use LaChinata\Core\Modules\Content\Fields;
use LaChinata\Core\Modules\Content\Html;
use LaChinata\Core\Modules\Content\Model;
use LaChinata\Core\Modules\Content\Pages;
use LaChinata\Core\Modules\Content\Query;
use LaChinata\Core\Modules\Content\Recipe;
use LaChinata\Core\Modules\Content\RecipeBlock;
use LaChinata\Core\Modules\Content\Texts;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- The pieces come escaped from Html and RecipeBlock; the content is the post's, filtered by WordPress.

get_header();
while ( have_posts() ) :
	the_post();
	$lachinata_post   = get_post();
	$lachinata_recipe = $lachinata_post instanceof WP_Post ? Recipe::of( $lachinata_post ) : null;
	if ( ! $lachinata_post instanceof WP_Post || null === $lachinata_recipe ) {
		continue;
	}
	$lachinata_title = get_the_title();
	// The block prints nothing here: this template places each part of the recipe.
	Pages::recipe_mode( true );
	/** This filter is documented in wp-includes/post-template.php */
	$lachinata_rest = trim( (string) apply_filters( 'the_content', get_the_content() ) ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound, WooCommerce.Commenting.CommentHooks.MissingSinceComment -- WordPress hook.
	Pages::recipe_mode( false );
	$lachinata_section = Model::section_of( $lachinata_post );
	$lachinata_more    = Query::related( $lachinata_post, 4 );
	$lachinata_list    = sprintf(
		/* translators: %s: recipe title. */
		__( 'Receta: %s', 'lachinata-core' ),
		wp_strip_all_tags( $lachinata_title )
	);
	?>
	<div class="lc-entry lc-entry--recipe" data-lc-recipe="<?php echo esc_attr( (string) $lachinata_post->ID ); ?>" data-lc-recipe-title="<?php echo esc_attr( wp_strip_all_tags( $lachinata_title ) ); ?>">
		<div class="lc-container lc-entry__crumbs"><?php get_template_part( 'template-parts/breadcrumb' ); ?></div>
		<article <?php post_class( 'lc-container lc-recipe-page' ); ?>>
			<div class="lc-recipe-page__hero">
				<header class="lc-recipe-page__head">
					<h1 class="editorial-h1 lc-entry__title"><?php echo esc_html( wp_strip_all_tags( $lachinata_title ) ); ?></h1>
					<?php echo Html::meta( $lachinata_post, false ); ?>
				</header>
				<div class="lc-recipe-page__summary"><?php echo Html::summary( (string) get_post_meta( $lachinata_post->ID, Fields::SUMMARY, true ) ); ?></div>
				<?php if ( has_post_thumbnail() ) : ?>
					<figure class="lc-recipe-page__media">
						<?php
						the_post_thumbnail(
							'large',
							array(
								'loading'       => 'eager',
								'fetchpriority' => 'high',
								'sizes'         => '(min-width: 1024px) 620px, 100vw',
							)
						);
						?>
					</figure>
				<?php endif; ?>
				<div class="lc-recipe-page__facts"><?php echo Html::recipe_header( $lachinata_recipe ); ?></div>
			</div>
			<div class="lc-recipe-page__cols">
				<div class="lc-recipe-page__left">
					<?php echo RecipeBlock::ingredients( $lachinata_recipe ); ?>
					<?php echo Html::recipe_products( Recipe::products( $lachinata_recipe ), $lachinata_list ); ?>
				</div>
				<div class="lc-recipe-page__right">
					<?php echo RecipeBlock::steps( $lachinata_recipe ); ?>
					<?php echo RecipeBlock::tips( $lachinata_recipe ); ?>
					<?php if ( '' !== $lachinata_rest ) : ?>
						<div class="lc-prose lc-blocks lc-entry__body body"><?php echo $lachinata_rest; ?></div>
					<?php endif; ?>
					<p class="lc-entry__sign body-sm"><?php echo esc_html( Texts::signature() ); ?></p>
				</div>
			</div>
		</article>
		<?php if ( $lachinata_more ) : ?>
			<?php
			$lachinata_link = null === $lachinata_section ? '' : Query::section_url( $lachinata_section );
			$lachinata_head = null !== $lachinata_section && $lachinata_section->parent
				/* translators: %s: type of dish, lower case («postres»). */
				? sprintf( __( 'Más %s', 'lachinata-core' ), mb_strtolower( $lachinata_section->name ) )
				: __( 'Más recetas', 'lachinata-core' );
			?>
			<section class="lc-container lc-entry__more lc-entry__more--recipes" aria-labelledby="lc-entry-more">
				<div class="lc-section">
					<div class="lc-section__titles"><h2 class="h2" id="lc-entry-more"><?php echo esc_html( $lachinata_head ); ?></h2></div>
					<?php if ( '' !== $lachinata_link ) : ?>
						<a href="<?php echo esc_url( $lachinata_link ); ?>" class="lc-section__more label"><?php esc_html_e( 'Ver todas', 'lachinata-core' ); ?><?php echo Html::icon( 'arrow-right', true ); ?></a>
					<?php endif; ?>
				</div>
				<div class="lc-blog__grid">
					<?php foreach ( $lachinata_more as $lachinata_index => $lachinata_related ) : ?>
						<?php
						echo Html::card(
							$lachinata_related,
							'vertical',
							array(
								'data-lc-entry' => $lachinata_related->ID,
								'data-lc-list'  => $lachinata_head,
								'data-lc-index' => $lachinata_index + 1,
							)
						);
						?>
					<?php endforeach; ?>
				</div>
			</section>
		<?php endif; ?>
		<?php echo Html::cook_mode( $lachinata_recipe, wp_strip_all_tags( $lachinata_title ) ); ?>
	</div>
	<?php
endwhile;
get_footer();
