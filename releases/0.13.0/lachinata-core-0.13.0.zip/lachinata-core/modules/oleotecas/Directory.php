<?php
/**
 * All the stores and their zones.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

defined( 'ABSPATH' ) || exit;

/**
 * The published stores, read once per request (a network has tens, not thousands), and the
 * zones with their stores. A zone has its page when it has two or more stores and they are
 * not exactly those of its country (Busan, with every store of South Korea, would repeat
 * the country's page).
 *
 * @phpstan-import-type StoreData from Store
 * @phpstan-type Zone array{id: int, slug: string, name: string, parent: int, url: string, stores: list<int>, page: bool, text: string, faq: list<array{question: string, answer: string}>, group: string}
 */
final class Directory {

	/**
	 * Stores of this request, by id.
	 *
	 * @var array<int, StoreData>|null
	 */
	private static ?array $stores = null;

	/**
	 * Zones of this request, by id.
	 *
	 * @var array<int, Zone>|null
	 */
	private static ?array $zones = null;

	/**
	 * Forgets what was read (after saving a store or a zone).
	 */
	public static function reset(): void {
		self::$stores = null;
		self::$zones  = null;
	}

	/**
	 * Published stores by id, sorted by country and name.
	 *
	 * @return array<int, StoreData>
	 */
	public static function stores(): array {
		if ( null !== self::$stores ) {
			return self::$stores;
		}
		$posts  = get_posts(
			array(
				'post_type'        => Model::POST_TYPE,
				'post_status'      => 'publish',
				'numberposts'      => -1,
				'orderby'          => 'title',
				'order'            => 'ASC',
				'suppress_filters' => false,
			)
		);
		$stores = array();
		foreach ( $posts as $post ) {
			$stores[ (int) $post->ID ] = Store::from_post( $post );
		}
		uasort( $stores, array( self::class, 'compare' ) );
		self::$stores = $stores;
		return $stores;
	}

	/**
	 * Default order: the shop's country first, then by country and by name.
	 *
	 * @param array<string, mixed> $a Store.
	 * @phpstan-param StoreData $a
	 * @param array<string, mixed> $b Store.
	 * @phpstan-param StoreData $b
	 */
	public static function compare( array $a, array $b ): int {
		$base = function_exists( 'WC' ) && WC()->countries ? WC()->countries->get_base_country() : '';
		$ka   = array( $a['country'] === $base ? 0 : 1, remove_accents( $a['country_name'] ), remove_accents( $a['name'] ) );
		$kb   = array( $b['country'] === $base ? 0 : 1, remove_accents( $b['country_name'] ), remove_accents( $b['name'] ) );
		return $ka <=> $kb;
	}

	/**
	 * One store.
	 *
	 * @param int $id Post id.
	 * @return StoreData|null
	 */
	public static function store( int $id ): ?array {
		return self::stores()[ $id ] ?? null;
	}

	/**
	 * Zones by id, with their stores (a country counts those of its zones too).
	 *
	 * @return array<int, Zone>
	 */
	public static function zones(): array {
		if ( null !== self::$zones ) {
			return self::$zones;
		}
		$terms = get_terms(
			array(
				'taxonomy'   => Model::ZONE,
				'hide_empty' => false,
			)
		);
		$zones = array();
		foreach ( is_array( $terms ) ? $terms : array() as $term ) {
			if ( ! $term instanceof \WP_Term ) {
				continue;
			}
			$zones[ (int) $term->term_id ] = array(
				'id'     => (int) $term->term_id,
				'slug'   => $term->slug,
				'name'   => $term->name,
				'parent' => (int) $term->parent,
				'url'    => '',
				'stores' => array(),
				'page'   => false,
				'text'   => trim( (string) get_term_meta( $term->term_id, Fields::ZONE_TEXT, true ) ),
				'faq'    => Fields::faq( get_term_meta( $term->term_id, Fields::ZONE_FAQ, true ) ),
				'group'  => trim( (string) get_term_meta( $term->term_id, Fields::ZONE_GROUP, true ) ),
			);
		}
		foreach ( self::stores() as $store ) {
			foreach ( $store['zones'] as $zone_id ) {
				for ( $id = $zone_id; isset( $zones[ $id ] ); $id = $zones[ $id ]['parent'] ) {
					$zones[ $id ]['stores'][] = $store['id'];
					if ( $zones[ $id ]['parent'] === $id ) {
						break;
					}
				}
			}
		}
		foreach ( $zones as $id => $zone ) {
			$stores = array_values( array_unique( $zone['stores'] ) );
			$parent = $zone['parent'] && isset( $zones[ $zone['parent'] ] ) ? array_values( array_unique( $zones[ $zone['parent'] ]['stores'] ) ) : null;
			sort( $stores );
			if ( null !== $parent ) {
				sort( $parent );
			}
			$zones[ $id ]['stores'] = $stores;
			$zones[ $id ]['page']   = count( $stores ) >= 2 && $stores !== $parent;
			$link                   = get_term_link( $id, Model::ZONE );
			$zones[ $id ]['url']    = is_string( $link ) ? $link : '';
		}
		// Keep the stores in the default order.
		$order = array_flip( array_keys( self::stores() ) );
		foreach ( $zones as $id => $zone ) {
			usort( $zones[ $id ]['stores'], static fn( int $a, int $b ): int => $order[ $a ] <=> $order[ $b ] );
		}
		self::$zones = $zones;
		return $zones;
	}

	/**
	 * One zone.
	 *
	 * @param int $id Term id.
	 * @return Zone|null
	 */
	public static function zone( int $id ): ?array {
		return self::zones()[ $id ] ?? null;
	}

	/**
	 * Countries (zones without parent) with stores, sorted like the stores.
	 *
	 * @return list<Zone>
	 */
	public static function countries(): array {
		$countries = array_values( array_filter( self::zones(), static fn( array $zone ): bool => 0 === $zone['parent'] && $zone['stores'] ) );
		$stores    = self::stores();
		usort(
			$countries,
			static fn( array $a, array $b ): int => self::compare( $stores[ $a['stores'][0] ], $stores[ $b['stores'][0] ] )
		);
		return $countries;
	}

	/**
	 * The deepest zone of a store with a page, then its country (for the breadcrumb and the
	 * link «Todas las oleotecas de España»).
	 *
	 * @param array<string, mixed> $store Store.
	 * @phpstan-param StoreData $store
	 * @return array{country: Zone|null, zone: Zone|null}
	 */
	public static function place( array $store ): array {
		$zones   = self::zones();
		$country = null;
		$zone    = null;
		foreach ( $store['zones'] as $id ) {
			if ( ! isset( $zones[ $id ] ) ) {
				continue;
			}
			if ( 0 === $zones[ $id ]['parent'] ) {
				$country = $country ?? $zones[ $id ];
			} else {
				$zone    = $zone ?? $zones[ $id ];
				$country = $zones[ $zones[ $id ]['parent'] ] ?? $country;
			}
		}
		return array(
			'country' => $country,
			'zone'    => $zone && $zone['page'] ? $zone : null,
		);
	}

	/**
	 * Slugs of the zones of a store and of their countries.
	 *
	 * @param array<string, mixed> $store Store.
	 * @phpstan-param StoreData $store
	 * @return list<string>
	 */
	public static function zone_slugs( array $store ): array {
		$zones = self::zones();
		$out   = array();
		foreach ( $store['zones'] as $id ) {
			for ( $current = $id, $guard = 0; isset( $zones[ $current ] ) && $guard < 5; $current = $zones[ $current ]['parent'], $guard++ ) {
				$out[] = $zones[ $current ]['slug'];
			}
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * Other stores within a distance, the closest first.
	 *
	 * @param array<string, mixed> $store Store.
	 * @phpstan-param StoreData $store
	 * @param int                  $km    Distance.
	 * @param int                  $limit Most.
	 * @return list<array{store: StoreData, km: float}>
	 */
	public static function nearby( array $store, int $km, int $limit = 3 ): array {
		if ( null === $store['lat'] || null === $store['lng'] ) {
			return array();
		}
		$out = array();
		foreach ( self::stores() as $other ) {
			if ( $other['id'] === $store['id'] || null === $other['lat'] || null === $other['lng'] ) {
				continue;
			}
			$distance = Store::distance( $store['lat'], $store['lng'], $other['lat'], $other['lng'] );
			if ( $distance <= $km ) {
				$out[] = array(
					'store' => $other,
					'km'    => $distance,
				);
			}
		}
		usort( $out, static fn( array $a, array $b ): int => $a['km'] <=> $b['km'] );
		return array_slice( $out, 0, $limit );
	}

	/**
	 * Number of countries with stores.
	 */
	public static function country_count(): int {
		return count( array_unique( array_filter( array_column( self::stores(), 'country' ) ) ) );
	}
}
