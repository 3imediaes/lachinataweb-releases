<?php
/**
 * Fields of each store and of each zone.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

defined( 'ABSPATH' ) || exit;

/**
 * Registered meta of the core (no ACF), with `show_in_rest` and a schema so the editor's
 * panel saves them through the REST API, and each value sanitised on the way in.
 */
final class Fields {

	public const NAME      = '_lc_oleotecas_name';
	public const ADDRESS   = '_lc_oleotecas_address';
	public const LAT       = '_lc_oleotecas_lat';
	public const LNG       = '_lc_oleotecas_lng';
	public const TIMEZONE  = '_lc_oleotecas_timezone';
	public const PHONE     = '_lc_oleotecas_phone';
	public const WHATSAPP  = '_lc_oleotecas_whatsapp';
	public const EMAIL     = '_lc_oleotecas_email';
	public const WEB       = '_lc_oleotecas_web';
	public const SOCIAL    = '_lc_oleotecas_social';
	public const HOURS     = '_lc_oleotecas_hours';
	public const SPECIAL   = '_lc_oleotecas_special';
	public const PHOTOS    = '_lc_oleotecas_photos';
	public const TEXT      = '_lc_oleotecas_text';
	public const FAVORITES = '_lc_oleotecas_favorites';
	public const MIGRATED  = '_lc_oleotecas_migrated';
	public const LOG       = '_lc_oleotecas_log';

	/**
	 * Zone term meta: own text, questions, and the label of the stores outside the main
	 * city when the zone groups its cards by city (empty: no grouping).
	 */
	public const ZONE_TEXT  = '_lc_oleotecas_text';
	public const ZONE_FAQ   = '_lc_oleotecas_faq';
	public const ZONE_GROUP = '_lc_oleotecas_group';

	/**
	 * Networks a store may link to (SocialLinks).
	 */
	public const NETWORKS = array( 'instagram', 'facebook', 'tiktok', 'youtube', 'x', 'web' );

	/**
	 * Most photos and favourites.
	 */
	public const MAX_PHOTOS    = 8;
	public const MAX_FAVORITES = 4;

	/**
	 * Registers the meta.
	 */
	public static function register(): void {
		$post  = static function ( string $key, string $type, $schema, callable $sanitize ): void {
			register_post_meta(
				Model::POST_TYPE,
				$key,
				array(
					'type'              => $type,
					'single'            => true,
					'show_in_rest'      => true === $schema ? true : array( 'schema' => $schema ),
					'sanitize_callback' => $sanitize,
					'auth_callback'     => static fn(): bool => current_user_can( 'edit_posts' ),
				)
			);
		};
		$slots = array(
			'type'  => 'array',
			'items' => array(
				'type'  => 'array',
				'items' => array( 'type' => 'string' ),
			),
		);
		$days  = array();
		foreach ( Schedule::DAYS as $day ) {
			$days[ $day ] = $slots;
		}

		$post( self::NAME, 'string', true, array( self::class, 'text_line' ) );
		$post(
			self::ADDRESS,
			'object',
			array(
				'type'       => 'object',
				'properties' => array(
					'street'   => array( 'type' => 'string' ),
					'postcode' => array( 'type' => 'string' ),
					'city'     => array( 'type' => 'string' ),
					'region'   => array( 'type' => 'string' ),
					'country'  => array( 'type' => 'string' ),
				),
			),
			array( self::class, 'address' )
		);
		$post( self::LAT, 'number', true, array( self::class, 'latitude' ) );
		$post( self::LNG, 'number', true, array( self::class, 'longitude' ) );
		$post( self::TIMEZONE, 'string', true, array( self::class, 'timezone' ) );
		$post( self::PHONE, 'string', true, array( self::class, 'phone' ) );
		$post( self::WHATSAPP, 'string', true, array( self::class, 'phone' ) );
		$post( self::EMAIL, 'string', true, 'sanitize_email' );
		$post(
			self::WEB,
			'object',
			array(
				'type'       => 'object',
				'properties' => array(
					'url'   => array( 'type' => 'string' ),
					'label' => array( 'type' => 'string' ),
				),
			),
			array( self::class, 'web' )
		);
		$post(
			self::SOCIAL,
			'array',
			array(
				'type'  => 'array',
				'items' => array(
					'type'       => 'object',
					'properties' => array(
						'network' => array(
							'type' => 'string',
							'enum' => self::NETWORKS,
						),
						'url'     => array( 'type' => 'string' ),
					),
				),
			),
			array( self::class, 'social' )
		);
		$post(
			self::HOURS,
			'object',
			array(
				'type'       => 'object',
				'properties' => $days,
			),
			array( Schedule::class, 'sanitize_week' )
		);
		$post(
			self::SPECIAL,
			'array',
			array(
				'type'  => 'array',
				'items' => array(
					'type'       => 'object',
					'properties' => array(
						'from'  => array( 'type' => 'string' ),
						'to'    => array( 'type' => 'string' ),
						'slots' => $slots,
						'note'  => array( 'type' => 'string' ),
						'kind'  => array( 'type' => 'string' ),
					),
				),
			),
			array( Schedule::class, 'sanitize_specials' )
		);
		$post(
			self::PHOTOS,
			'array',
			array(
				'type'     => 'array',
				'items'    => array( 'type' => 'integer' ),
				'maxItems' => self::MAX_PHOTOS,
			),
			array( self::class, 'photos' )
		);
		$post( self::TEXT, 'string', true, 'sanitize_textarea_field' );
		$post(
			self::FAVORITES,
			'array',
			array(
				'type'     => 'array',
				'items'    => array( 'type' => 'integer' ),
				'maxItems' => self::MAX_FAVORITES,
			),
			array( self::class, 'favorites' )
		);

		foreach ( array( self::ZONE_TEXT, self::ZONE_GROUP ) as $key ) {
			register_term_meta(
				Model::ZONE,
				$key,
				array(
					'type'              => 'string',
					'single'            => true,
					'show_in_rest'      => true,
					'sanitize_callback' => self::ZONE_TEXT === $key ? 'sanitize_textarea_field' : array( self::class, 'text_line' ),
				)
			);
		}
		register_term_meta(
			Model::ZONE,
			self::ZONE_FAQ,
			array(
				'type'              => 'array',
				'single'            => true,
				'show_in_rest'      => array(
					'schema' => array(
						'type'  => 'array',
						'items' => array(
							'type'       => 'object',
							'properties' => array(
								'question' => array( 'type' => 'string' ),
								'answer'   => array( 'type' => 'string' ),
							),
						),
					),
				),
				'sanitize_callback' => array( self::class, 'faq' ),
			)
		);
	}

	/**
	 * One line of text.
	 *
	 * @param mixed $value Value.
	 */
	public static function text_line( $value ): string {
		return trim( (string) preg_replace( '/\s+/u', ' ', sanitize_text_field( is_scalar( $value ) ? (string) $value : '' ) ) );
	}

	/**
	 * Address by parts; the country as an ISO code.
	 *
	 * @param mixed $value Value.
	 * @return array{street: string, postcode: string, city: string, region: string, country: string}
	 */
	public static function address( $value ): array {
		$value = is_array( $value ) ? $value : array();
		return array(
			'street'   => self::text_line( $value['street'] ?? '' ),
			'postcode' => self::text_line( $value['postcode'] ?? '' ),
			'city'     => self::text_line( $value['city'] ?? '' ),
			'region'   => self::text_line( $value['region'] ?? '' ),
			'country'  => strtoupper( substr( (string) preg_replace( '/[^A-Za-z]/', '', (string) ( $value['country'] ?? '' ) ), 0, 2 ) ),
		);
	}

	/**
	 * Latitude, or null out of range.
	 *
	 * @param mixed $value Value.
	 */
	public static function latitude( $value ): ?float {
		return self::coordinate( $value, 90 );
	}

	/**
	 * Longitude, or null out of range.
	 *
	 * @param mixed $value Value.
	 */
	public static function longitude( $value ): ?float {
		return self::coordinate( $value, 180 );
	}

	/**
	 * A coordinate with at most 6 decimals (about 10 cm), or null.
	 *
	 * @param mixed $value Value («38.967464 \t», with tabs and spaces as in the old fields).
	 * @param int   $limit Absolute limit.
	 */
	public static function coordinate( $value, int $limit ): ?float {
		$value = is_scalar( $value ) ? trim( str_replace( ',', '.', (string) $value ) ) : '';
		if ( '' === $value || ! is_numeric( $value ) ) {
			return null;
		}
		$number = round( (float) $value, 6 );
		return abs( $number ) <= $limit ? $number : null;
	}

	/**
	 * IANA time zone, or ''.
	 *
	 * @param mixed $value Value.
	 */
	public static function timezone( $value ): string {
		$value = is_string( $value ) ? trim( $value ) : '';
		return in_array( $value, \DateTimeZone::listIdentifiers(), true ) ? $value : '';
	}

	/**
	 * A phone already in E.164 (+34911431288), or ''. The editor's panel and the migration
	 * normalise it first (StorePhone).
	 *
	 * @param mixed $value Value.
	 */
	public static function phone( $value ): string {
		$value = is_string( $value ) ? (string) preg_replace( '/[^\d+]/', '', $value ) : '';
		return preg_match( '/^\+[1-9]\d{7,14}$/', $value ) ? $value : '';
	}

	/**
	 * Own online shop: URL and label (its domain when empty).
	 *
	 * @param mixed $value Value.
	 * @return array{url: string, label: string}
	 */
	public static function web( $value ): array {
		$value = is_array( $value ) ? $value : array();
		$url   = esc_url_raw( trim( (string) ( $value['url'] ?? '' ) ), array( 'https', 'http' ) );
		$label = self::text_line( $value['label'] ?? '' );
		if ( '' !== $url && '' === $label ) {
			$label = (string) preg_replace( '/^www\./', '', (string) wp_parse_url( $url, PHP_URL_HOST ) );
		}
		return array(
			'url'   => $url,
			'label' => '' === $url ? '' : $label,
		);
	}

	/**
	 * Profiles: known network and URL; one per network, in the given order.
	 *
	 * @param mixed $value Value.
	 * @return list<array{network: string, url: string}>
	 */
	public static function social( $value ): array {
		$out  = array();
		$seen = array();
		foreach ( is_array( $value ) ? $value : array() as $item ) {
			$network = is_array( $item ) ? (string) ( $item['network'] ?? '' ) : '';
			$url     = is_array( $item ) ? esc_url_raw( trim( (string) ( $item['url'] ?? '' ) ), array( 'https', 'http' ) ) : '';
			if ( ! in_array( $network, self::NETWORKS, true ) || '' === $url || isset( $seen[ $network ] ) ) {
				continue;
			}
			$seen[ $network ] = true;
			$out[]            = array(
				'network' => $network,
				'url'     => $url,
			);
		}
		return $out;
	}

	/**
	 * Attachment ids of images, at most eight.
	 *
	 * @param mixed $value Value.
	 * @return list<int>
	 */
	public static function photos( $value ): array {
		$ids = array_filter( array_map( 'absint', is_array( $value ) ? $value : array() ), static fn( int $id ): bool => $id > 0 && wp_attachment_is_image( $id ) );
		return array_slice( array_values( array_unique( $ids ) ), 0, self::MAX_PHOTOS );
	}

	/**
	 * Product ids, at most four.
	 *
	 * @param mixed $value Value.
	 * @return list<int>
	 */
	public static function favorites( $value ): array {
		$ids = array_filter( array_map( 'absint', is_array( $value ) ? $value : array() ), static fn( int $id ): bool => $id > 0 && 'product' === get_post_type( $id ) );
		return array_slice( array_values( array_unique( $ids ) ), 0, self::MAX_FAVORITES );
	}

	/**
	 * Questions of a zone: both parts filled.
	 *
	 * @param mixed $value Value.
	 * @return list<array{question: string, answer: string}>
	 */
	public static function faq( $value ): array {
		$out = array();
		foreach ( is_array( $value ) ? $value : array() as $item ) {
			$question = is_array( $item ) ? self::text_line( $item['question'] ?? '' ) : '';
			$answer   = is_array( $item ) ? sanitize_textarea_field( (string) ( $item['answer'] ?? '' ) ) : '';
			if ( '' !== $question && '' !== trim( $answer ) ) {
				$out[] = array(
					'question' => $question,
					'answer'   => trim( $answer ),
				);
			}
		}
		return $out;
	}
}
