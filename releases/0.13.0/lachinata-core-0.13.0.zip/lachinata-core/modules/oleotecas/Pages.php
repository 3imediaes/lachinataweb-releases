<?php
/**
 * The finder, the zones and each store's page.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

use LaChinata\Core\Hooks;
use LaChinata\Core\Templates;

defined( 'ABSPATH' ) || exit;

/**
 * Serves the module's templates (`templates/oleotecas/{archive,zone,single}.php`, which the
 * theme can override in `lachinata/oleotecas/`), fills the theme's breadcrumb and «Volver»,
 * sends a zone without its own page to where its stores are, and loads the finder's script
 * only where there is a finder or a store.
 *
 * @phpstan-import-type StoreData from Store
 * @phpstan-import-type Zone from Directory
 */
final class Pages {

	/**
	 * Script handle of the finder and the store page.
	 */
	public const SCRIPT = 'lachinata-oleotecas';

	/**
	 * Stores shown before «Ver más».
	 */
	public const PAGE_SIZE = 10;

	/**
	 * Whether this request prints a finder or a store (the script and its data go in the
	 * footer only then).
	 *
	 * @var bool
	 */
	private static bool $used = false;

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'template_include', array( self::class, 'template' ), 20 );
		Hooks::add_action( 'template_redirect', array( self::class, 'redirect_zone' ) );
		Hooks::add_filter( 'lachinata/breadcrumb/items', array( self::class, 'breadcrumb' ) );
		Hooks::add_filter( 'lachinata/view/secondary', array( self::class, 'secondary' ) );
		Hooks::add_filter( 'lachinata/view/back_url', array( self::class, 'back_url' ) );
		Hooks::add_filter( 'lachinata/view/editorial', array( self::class, 'editorial' ) );
		Hooks::add_filter( 'lachinata/app_bar/section', array( self::class, 'section' ) );
		Hooks::add_filter( 'body_class', array( self::class, 'body_class' ) );
		Hooks::add_action( 'init', array( self::class, 'register_script' ) );
		Hooks::add_action( 'wp_footer', array( self::class, 'footer' ), 5 );
	}

	/**
	 * Whether the request is one of the module's pages.
	 */
	public static function is_view(): bool {
		return self::is_finder() || is_tax( Model::ZONE ) || is_singular( Model::POST_TYPE );
	}

	/**
	 * Whether the request is the finder (the post type's archive; in client mode, its rule).
	 */
	public static function is_finder(): bool {
		return Source::client() ? Client::is_finder() : is_post_type_archive( Model::POST_TYPE );
	}

	/**
	 * URL of the finder of this site.
	 */
	public static function archive_url(): string {
		if ( Source::client() ) {
			return home_url( user_trailingslashit( Model::archive_slug() ) );
		}
		$link = get_post_type_archive_link( Model::POST_TYPE );
		return is_string( $link ) ? $link : home_url( user_trailingslashit( Model::archive_slug() ) );
	}

	/**
	 * Stores and countries of the document (the line under the finder's title).
	 *
	 * @return array{stores: int, countries: int}
	 */
	public static function counts(): array {
		$stores = (array) Source::document()['stores'];
		return array(
			'stores'    => count( $stores ),
			'countries' => count( array_unique( array_filter( array_map( static fn( $store ): string => (string) ( ( (array) $store )['country'] ?? '' ), $stores ) ) ) ),
		);
	}

	/**
	 * The module's template for its pages.
	 *
	 * @param mixed $template Template WordPress chose.
	 */
	public static function template( $template ): string {
		$name = '';
		if ( is_singular( Model::POST_TYPE ) ) {
			$name = 'single';
		} elseif ( is_tax( Model::ZONE ) ) {
			$name = 'zone';
		} elseif ( self::is_finder() ) {
			$name = 'archive';
		}
		if ( '' === $name ) {
			return (string) $template;
		}
		$file = Templates::locate( 'oleotecas', $name );
		if ( '' === $file ) {
			return (string) $template;
		}
		self::use_script();
		return $file;
	}

	/**
	 * Marks that the page needs the finder's script.
	 */
	public static function use_script(): void {
		self::$used = true;
		wp_enqueue_script( self::SCRIPT );
	}

	/**
	 * A zone without its own page: one store goes to its page; a zone with the same stores as
	 * its country, to the country; the rest, to the finder.
	 */
	public static function redirect_zone(): void {
		if ( ! is_tax( Model::ZONE ) ) {
			return;
		}
		$term = get_queried_object();
		$zone = $term instanceof \WP_Term ? Directory::zone( (int) $term->term_id ) : null;
		if ( null === $zone || $zone['page'] ) {
			return;
		}
		$target = self::archive_url();
		if ( 1 === count( $zone['stores'] ) ) {
			$target = (string) get_permalink( $zone['stores'][0] );
		} elseif ( $zone['parent'] ) {
			$parent = Directory::zone( $zone['parent'] );
			$target = $parent && $parent['page'] ? $parent['url'] : $target;
		}
		wp_safe_redirect( $target, 301 );
		exit;
	}

	/**
	 * The stores of the document, in short form, by slug.
	 *
	 * @param array<string, mixed> $document Document of the finder.
	 * @return array<string, array<string, mixed>>
	 */
	public static function by_slug( array $document ): array {
		$out = array();
		foreach ( (array) $document['stores'] as $store ) {
			$out[ (string) $store['slug'] ] = (array) $store;
		}
		return $out;
	}

	/**
	 * Arguments of the finder of the finder page (and of the block).
	 *
	 * @param string $id     Element id.
	 * @param string $action URL of the form.
	 * @return array<string, mixed>
	 */
	public static function finder_args( string $id = 'lc-finder', string $action = '' ): array {
		$document = Source::document();
		$stores   = array_values( array_map( static fn( $store ): array => (array) $store, (array) $document['stores'] ) );
		$counts   = self::counts();
		$query    = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['q'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- A public search.
		$all      = isset( $_GET['todas'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- A public view.
		$status   = sprintf(
			/* translators: 1: «39 oleotecas», 2: number of countries. */
			_n( '%1$s en %2$s país', '%1$s en %2$s países', $counts['countries'], 'lachinata-core' ),
			Texts::count( count( $stores ) ),
			number_format_i18n( $counts['countries'] )
		);
		if ( '' !== $query ) {
			$found = self::match( $stores, $query );
			if ( $found ) {
				$stores = $found;
				$status = sprintf(
					/* translators: 1: «3 oleotecas», 2: what was searched. */
					__( '%1$s en «%2$s»', 'lachinata-core' ),
					Texts::count( count( $found ) ),
					$query
				);
				$all = true;
			} else {
				$status = sprintf(
					/* translators: 1: «oleotecas», 2: what was searched. */
					__( 'No hay %1$s en «%2$s». Estas son todas.', 'lachinata-core' ),
					Texts::noun( true ),
					$query
				);
			}
		}
		$action = '' === $action ? self::archive_url() : $action;
		return array(
			'id'       => $id,
			'stores'   => $stores,
			'status'   => $status,
			'limit'    => $all ? 0 : self::PAGE_SIZE,
			'more_url' => add_query_arg( 'todas', '1', $action ) . '#' . $id,
			'action'   => $action,
			'query'    => $query,
			'filters'  => (array) $document['services'],
			'src'      => Source::url(),
		);
	}

	/**
	 * Stores whose name, city, postcode, zone or country contain the query (accents and case
	 * aside), for the search without JavaScript.
	 *
	 * @param list<array<string, mixed>> $stores Stores in short form.
	 * @param string                     $query  Query.
	 * @return list<array<string, mixed>>
	 */
	public static function match( array $stores, string $query ): array {
		$needle = self::fold( $query );
		if ( '' === $needle ) {
			return array();
		}
		$zones = array();
		foreach ( (array) Source::document()['zones'] as $zone ) {
			$zones[ (string) ( (array) $zone )['slug'] ] = (string) ( (array) $zone )['name'];
		}
		return array_values(
			array_filter(
				$stores,
				static function ( array $store ) use ( $needle, $zones ): bool {
					$hay = self::fold( implode( ' ', array( $store['name'], $store['city'], $store['postcode'], $store['countryName'], $zones[ $store['zone'] ] ?? '' ) ) );
					return str_contains( $hay, $needle );
				}
			)
		);
	}

	/**
	 * Lower case without accents.
	 *
	 * @param string $text Text.
	 */
	public static function fold( string $text ): string {
		return trim( mb_strtolower( remove_accents( $text ) ) );
	}

	/**
	 * Arguments of a zone's finder: all its stores, grouped by city when the zone says so
	 * («Madrid ciudad · 7», «Comunidad de Madrid · 4»).
	 *
	 * @param array<string, mixed> $zone Zone.
	 * @phpstan-param Zone $zone
	 * @return array<string, mixed>
	 */
	public static function zone_args( array $zone ): array {
		$document = Source::document();
		$slugs    = self::by_slug( $document );
		$stores   = array();
		foreach ( $zone['stores'] as $id ) {
			$store = Directory::store( $id );
			if ( null !== $store && isset( $slugs[ $store['slug'] ] ) ) {
				$stores[] = $slugs[ $store['slug'] ];
			}
		}
		$groups = array();
		if ( '' !== $zone['group'] && $stores ) {
			$cities = array_count_values( array_map( static fn( array $store ): string => (string) $store['city'], $stores ) );
			arsort( $cities );
			$main = (string) array_key_first( $cities );
			$in   = array_values( array_filter( $stores, static fn( array $store ): bool => $store['city'] === $main ) );
			$out  = array_values( array_filter( $stores, static fn( array $store ): bool => $store['city'] !== $main ) );
			if ( $in && $out ) {
				$groups = array(
					array(
						/* translators: 1: city, 2: number of stores. */
						'label'  => sprintf( __( '%1$s ciudad · %2$s', 'lachinata-core' ), $main, number_format_i18n( count( $in ) ) ),
						'stores' => $in,
					),
					array(
						'label'  => $zone['group'] . ' · ' . number_format_i18n( count( $out ) ),
						'stores' => $out,
					),
				);
				$stores = array_merge( $in, $out );
			}
		}
		$services = array();
		foreach ( $stores as $store ) {
			foreach ( (array) $store['services'] as $slug ) {
				$services[ $slug ] = ( (array) $document['services'] )[ $slug ] ?? $slug;
			}
		}
		return array(
			'id'      => 'lc-finder',
			'stores'  => $stores,
			'groups'  => $groups,
			'status'  => Texts::count( count( $stores ) ),
			'limit'   => 0,
			'action'  => $zone['url'],
			'zone'    => $zone['slug'],
			'filters' => $services,
			'src'     => Source::url(),
			/* translators: %s: number of stores. */
			'map_cta' => sprintf( __( 'Ver las %s en el mapa', 'lachinata-core' ), number_format_i18n( count( $stores ) ) ),
		);
	}

	/**
	 * «Por país y ciudad»: the shop's country (its zones with a page and «Resto de España»),
	 * then the rest of the world. Each place links to its page or, with one store, to it.
	 *
	 * @return list<array{title: string, links: list<array{name: string, count: string, url: string}>}>
	 */
	public static function places(): array {
		if ( Source::client() ) {
			return self::places_of( Source::document() );
		}
		$base   = function_exists( 'WC' ) && WC()->countries ? WC()->countries->get_base_country() : '';
		$zones  = Directory::zones();
		$home   = array();
		$abroad = array();
		$total  = 0;
		foreach ( Directory::countries() as $country ) {
			$first = Directory::store( $country['stores'][0] );
			$link  = static fn( array $zone ): array => array(
				'name'  => $zone['name'],
				'count' => Texts::count( count( $zone['stores'] ) ),
				'url'   => $zone['page'] ? $zone['url'] : (string) get_permalink( $zone['stores'][0] ),
			);
			if ( null !== $first && $first['country'] === $base ) {
				$links   = array();
				$covered = array();
				foreach ( $zones as $zone ) {
					if ( $zone['parent'] === $country['id'] && $zone['page'] ) {
						$links[] = $link( $zone );
						$covered = array_merge( $covered, $zone['stores'] );
					}
				}
				$rest = count( array_diff( $country['stores'], $covered ) );
				if ( $rest && $links ) {
					$links[] = array(
						/* translators: %s: country. */
						'name'  => sprintf( __( 'Resto de %s', 'lachinata-core' ), $country['name'] ),
						'count' => Texts::count( $rest ),
						'url'   => $country['page'] ? $country['url'] : self::archive_url(),
					);
				}
				$home[] = array(
					'title' => $country['name'] . ' · ' . number_format_i18n( count( $country['stores'] ) ),
					'links' => $links ? $links : array( $link( $country ) ),
				);
			} else {
				$abroad[] = $link( $country );
				$total   += count( $country['stores'] );
			}
		}
		if ( $abroad ) {
			$home[] = array(
				'title' => ( $home ? __( 'Resto del mundo', 'lachinata-core' ) : __( 'Por país', 'lachinata-core' ) ) . ' · ' . number_format_i18n( $total ),
				'links' => $abroad,
			);
		}
		return $home;
	}

	/**
	 * «Por país y ciudad» from a document (client mode): the same blocks as places(), with
	 * the master's URLs. A place without its own page links to its only store or, with
	 * more, to the master's finder.
	 *
	 * @param array<string, mixed> $document Document of the finder.
	 * @return list<array{title: string, links: list<array{name: string, count: string, url: string}>}>
	 */
	public static function places_of( array $document ): array {
		$base   = function_exists( 'WC' ) && WC()->countries ? WC()->countries->get_base_country() : '';
		$finder = '' !== (string) ( $document['finder'] ?? '' ) ? (string) $document['finder'] : self::archive_url();
		$stores = array_map( static fn( $store ): array => (array) $store, (array) $document['stores'] );
		$zones  = array();
		foreach ( (array) $document['zones'] as $zone ) {
			$zone                   = (array) $zone;
			$zones[ $zone['slug'] ] = $zone + array(
				'stores' => array(),
				'iso'    => '',
			);
		}
		foreach ( $stores as $store ) {
			foreach ( (array) $store['zones'] as $slug ) {
				if ( isset( $zones[ $slug ] ) ) {
					$zones[ $slug ]['stores'][] = $store;
					$zones[ $slug ]['iso']      = '' === (string) $zones[ $slug ]['parent'] ? (string) $store['country'] : $zones[ $slug ]['iso'];
				}
			}
		}
		$link   = static fn( array $zone ): array => array(
			'name'  => (string) $zone['name'],
			'count' => Texts::count( count( $zone['stores'] ) ),
			'url'   => '' !== (string) $zone['url'] ? (string) $zone['url'] : ( 1 === count( $zone['stores'] ) ? (string) $zone['stores'][0]['url'] : $finder ),
		);
		$home   = array();
		$abroad = array();
		$total  = 0;
		// Countries in the order of the stores (the master sorts them).
		$order = array();
		foreach ( $stores as $store ) {
			foreach ( (array) $store['zones'] as $slug ) {
				if ( isset( $zones[ $slug ] ) && '' === (string) $zones[ $slug ]['parent'] && ! in_array( $slug, $order, true ) ) {
					$order[] = $slug;
				}
			}
		}
		foreach ( $order as $slug ) {
			$country = $zones[ $slug ];
			if ( $country['iso'] !== $base ) {
				$abroad[] = $link( $country );
				$total   += count( $country['stores'] );
				continue;
			}
			$links   = array();
			$covered = array();
			foreach ( $zones as $zone ) {
				if ( $zone['parent'] === $slug && '' !== (string) $zone['url'] ) {
					$links[] = $link( $zone );
					$covered = array_merge( $covered, array_column( $zone['stores'], 'slug' ) );
				}
			}
			$rest = count( array_diff( array_column( $country['stores'], 'slug' ), $covered ) );
			if ( $rest && $links ) {
				$links[] = array(
					/* translators: %s: country. */
					'name'  => sprintf( __( 'Resto de %s', 'lachinata-core' ), $country['name'] ),
					'count' => Texts::count( $rest ),
					'url'   => '' !== (string) $country['url'] ? (string) $country['url'] : $finder,
				);
			}
			$home[] = array(
				'title' => $country['name'] . ' · ' . number_format_i18n( count( $country['stores'] ) ),
				'links' => $links ? $links : array( $link( $country ) ),
			);
		}
		if ( $abroad ) {
			$home[] = array(
				'title' => ( $home ? __( 'Resto del mundo', 'lachinata-core' ) : __( 'Por país', 'lachinata-core' ) ) . ' · ' . number_format_i18n( $total ),
				'links' => $abroad,
			);
		}
		return $home;
	}

	/**
	 * Breadcrumb of the module's pages: Inicio › Oleotecas › País › Zona › tienda.
	 *
	 * @param mixed $items Items of the theme ([label, url]).
	 * @return mixed
	 */
	public static function breadcrumb( $items ) {
		if ( ! self::is_view() || ! is_array( $items ) || ! $items ) {
			return $items;
		}
		$out     = array( $items[0] );
		$archive = self::archive_url();
		if ( self::is_finder() ) {
			$out[] = array( Texts::archive_title(), '' );
			return $out;
		}
		$out[] = array( ucfirst( Texts::noun( true ) ), $archive );
		if ( is_tax( Model::ZONE ) ) {
			$term = get_queried_object();
			$zone = $term instanceof \WP_Term ? Directory::zone( (int) $term->term_id ) : null;
			if ( $zone && $zone['parent'] ) {
				$parent = Directory::zone( $zone['parent'] );
				if ( $parent ) {
					$out[] = array( $parent['name'], $parent['page'] ? $parent['url'] : '' );
				}
			}
			$out[] = array( null === $zone ? single_term_title( '', false ) : $zone['name'], '' );
			return $out;
		}
		$store = Directory::store( (int) get_queried_object_id() );
		if ( null !== $store ) {
			$place = Directory::place( $store );
			if ( $place['country'] ) {
				$out[] = array( $place['country']['name'], $place['country']['page'] ? $place['country']['url'] : '' );
			}
			if ( $place['zone'] ) {
				$out[] = array( $place['zone']['name'], $place['zone']['url'] );
			}
			$out[] = array( $store['name'], '' );
		}
		return $out;
	}

	/**
	 * A store's page is a secondary view (AppBar with «Volver»).
	 *
	 * @param mixed $secondary Theme's answer.
	 * @return mixed
	 */
	public static function secondary( $secondary ) {
		return is_singular( Model::POST_TYPE ) ? true : $secondary;
	}

	/**
	 * The module's pages have an editorial title (Recoleta).
	 *
	 * @param mixed $editorial Theme's answer.
	 * @return mixed
	 */
	public static function editorial( $editorial ) {
		return self::is_view() ? true : $editorial;
	}

	/**
	 * «Volver» from a store goes to its zone, or to the finder.
	 *
	 * @param mixed $url Theme's URL.
	 * @return mixed
	 */
	public static function back_url( $url ) {
		if ( ! is_singular( Model::POST_TYPE ) ) {
			return $url;
		}
		$store = Directory::store( (int) get_queried_object_id() );
		$place = null === $store ? null : Directory::place( $store );
		return $place && $place['zone'] ? $place['zone']['url'] : self::archive_url();
	}

	/**
	 * Every page of the module belongs to the finder's section of the AppBar («Oleotecas»).
	 *
	 * @param mixed $url Theme's section.
	 * @return mixed
	 */
	public static function section( $url ) {
		return self::is_view() ? self::archive_url() : $url;
	}

	/**
	 * Body class of the module's pages.
	 *
	 * @param mixed $classes Classes.
	 * @return mixed
	 */
	public static function body_class( $classes ) {
		if ( is_array( $classes ) && self::is_view() ) {
			$classes[] = 'lc-stores-page';
		}
		return $classes;
	}

	/**
	 * Registers the script (enqueued only where it is used).
	 */
	public static function register_script(): void {
		$file  = LACHINATA_CORE_DIR . '/modules/oleotecas/build/finder.asset.php';
		$asset = is_readable( $file ) ? require $file : array(
			'dependencies' => array( 'wp-i18n' ),
			'version'      => LACHINATA_CORE_VERSION,
		);
		wp_register_script(
			self::SCRIPT,
			plugins_url( 'modules/oleotecas/build/finder.js', LACHINATA_CORE_FILE ),
			(array) $asset['dependencies'],
			(string) $asset['version'],
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
		wp_set_script_translations( self::SCRIPT, 'lachinata-core', LACHINATA_CORE_DIR . '/languages' );
	}

	/**
	 * Settings of the script: tiles, attribution, endpoint of the geocoder, opening text of
	 * WhatsApp. Printed only where the script is.
	 */
	public static function footer(): void {
		if ( ! self::$used ) {
			return;
		}
		$config = array(
			'tiles'       => Tiles::url(),
			'attribution' => (string) OleotecasModule::setting( 'tiles_attribution' ),
			'geocode'     => rest_url( Rest::NAMESPACE . '/oleotecas/geocode' ),
			'archive'     => self::archive_url(),
			'country'     => function_exists( 'WC' ) && WC()->countries ? WC()->countries->get_base_country() : '',
		);
		printf( '<script type="application/json" id="lc-stores-config">%s</script>', wp_json_encode( $config, JSON_HEX_TAG | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) );
	}
}
