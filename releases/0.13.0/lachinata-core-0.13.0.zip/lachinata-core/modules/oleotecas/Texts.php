<?php
/**
 * Names of the network and of each store.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

use LaChinata\Core\Company;

defined( 'ABSPATH' ) || exit;

/**
 * What changes between brands is a setting, not code: what a store is called («oleoteca»,
 * «tienda»), the long name of each one («Oleoteca La Chinata {name}»), the title of the
 * finder and of the zones, and the lead with the counts. Neutral by default («tienda»,
 * «{name}», the trade name of «Datos de la empresa»).
 */
final class Texts {

	/**
	 * What a store is called, singular or plural, in lower case.
	 *
	 * @param bool $plural Plural.
	 */
	public static function noun( bool $plural = false ): string {
		$value = trim( (string) OleotecasModule::setting( $plural ? 'noun_plural' : 'noun' ) );
		if ( '' !== $value ) {
			return $value;
		}
		return $plural ? __( 'tiendas', 'lachinata-core' ) : __( 'tienda', 'lachinata-core' );
	}

	/**
	 * «11 oleotecas», «1 oleoteca».
	 *
	 * @param int $count Count.
	 */
	public static function count( int $count ): string {
		return number_format_i18n( $count ) . ' ' . self::noun( 1 !== $count );
	}

	/**
	 * Long name of a store («Oleoteca La Chinata Bilbao»): `{name}` is the short name and
	 * `{brand}` the trade name.
	 *
	 * @param string $name Short name.
	 */
	public static function store_title( string $name ): string {
		$template = trim( (string) OleotecasModule::setting( 'store_title' ) );
		return self::fill( '' === $template ? '{name}' : $template, array( 'name' => $name ) );
	}

	/**
	 * Title of the finder («Oleotecas La Chinata»).
	 */
	public static function archive_title(): string {
		$title = trim( (string) OleotecasModule::setting( 'archive_title' ) );
		return '' === $title ? self::fill( ucfirst( self::noun( true ) ) . ' {brand}', array() ) : self::fill( $title, array() );
	}

	/**
	 * Title of a zone («Oleotecas La Chinata en Madrid»).
	 *
	 * @param string $zone Zone name.
	 */
	public static function zone_title( string $zone ): string {
		/* translators: 1: title of the finder («Oleotecas La Chinata»), 2: zone. */
		return sprintf( __( '%1$s en %2$s', 'lachinata-core' ), self::archive_title(), $zone );
	}

	/**
	 * Lead of the finder: the setting with `{stores}` and `{countries}` filled; by default
	 * «39 oleotecas en 9 países».
	 *
	 * @param int $stores    Stores.
	 * @param int $countries Countries.
	 */
	public static function archive_lead( int $stores, int $countries ): string {
		$lead = trim( (string) OleotecasModule::setting( 'archive_lead' ) );
		if ( '' === $lead ) {
			/* translators: 1: «39 oleotecas», 2: number of countries. */
			$lead = sprintf( _n( '%1$s en %2$s país.', '%1$s en %2$s países.', $countries, 'lachinata-core' ), '{stores}', '{countries}' );
		}
		return self::fill(
			$lead,
			array(
				'stores'    => self::count( $stores ),
				'countries' => number_format_i18n( $countries ),
			)
		);
	}

	/**
	 * Fills the placeholders of a text; `{brand}` is always the trade name.
	 *
	 * @param string                $text   Text.
	 * @param array<string, string> $values Values.
	 */
	public static function fill( string $text, array $values ): string {
		$values['brand'] = class_exists( Company::class ) ? Company::trade_name() : get_bloginfo( 'name' );
		foreach ( $values as $key => $value ) {
			$text = str_replace( '{' . $key . '}', $value, $text );
		}
		return trim( (string) preg_replace( '/\s+/u', ' ', $text ) );
	}
}
