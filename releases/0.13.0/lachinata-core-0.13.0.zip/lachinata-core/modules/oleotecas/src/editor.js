/**
 * Panel of a store in the editor: address with «Buscar en el mapa» and a marker that can be
 * dragged (the geocoder proposes, the person corrects), contact, hours with two slots per
 * day and «copiar a toda la semana», special days, profiles, photos, own text and
 * favourites. Saves the registered fields (`_lc_oleotecas_*`) with the post.
 */
import apiFetch from '@wordpress/api-fetch';
import { MediaUpload, MediaUploadCheck } from '@wordpress/block-editor';
import {
	Button,
	CheckboxControl,
	ComboboxControl,
	FormTokenField,
	Notice,
	SelectControl,
	TextControl,
	TextareaControl,
} from '@wordpress/components';
import { useDispatch, useSelect } from '@wordpress/data';
import { PluginDocumentSettingPanel } from '@wordpress/editor';
import { useEffect, useRef, useState } from '@wordpress/element';
import { __, sprintf } from '@wordpress/i18n';
import { registerPlugin } from '@wordpress/plugins';

import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import './editor.css';

const settings = window.lcStoresEditor || {};
const DAYS = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];
const DAY_NAMES = () => ({
	mon: __('Lunes', 'lachinata-core'),
	tue: __('Martes', 'lachinata-core'),
	wed: __('Miércoles', 'lachinata-core'),
	thu: __('Jueves', 'lachinata-core'),
	fri: __('Viernes', 'lachinata-core'),
	sat: __('Sábado', 'lachinata-core'),
	sun: __('Domingo', 'lachinata-core'),
});
const K = (name) => `_lc_oleotecas_${name}`;
const field = { __nextHasNoMarginBottom: true, __next40pxDefaultSize: true };

/**
 * Meta of the post and its setter.
 *
 * @return {[Object, Function]} Meta and setter of one key.
 */
const useMeta = () => {
	const meta = useSelect(
		(select) => select('core/editor').getEditedPostAttribute('meta') || {},
		[]
	);
	const { editPost } = useDispatch('core/editor');
	return [meta, (key, value) => editPost({ meta: { [K(key)]: value } })];
};

/**
 * E.164 from what the person types, with the calling code of the store's country.
 *
 * @param {string} value   Typed.
 * @param {string} country ISO code.
 * @return {string} Number.
 */
const e164 = (value, country) => {
	const raw = String(value || '').trim();
	if (!raw) {
		return '';
	}
	let digits = raw.replace(/\D/g, '');
	if (raw.startsWith('+')) {
		return `+${digits}`;
	}
	if (digits.startsWith('00')) {
		return `+${digits.slice(2)}`;
	}
	const code = (settings.callingCode || {})[country] || '';
	digits = digits.replace(/^0+/, '');
	return code ? `+${code}${digits}` : raw;
};

/**
 * Problems of a day's slots.
 *
 * @param {Array<Array<string>>} slots Slots.
 * @return {string} Problem or ''.
 */
const slotError = (slots) => {
	const sorted = [...slots].sort((a, b) => a[0].localeCompare(b[0]));
	for (let i = 0; i < sorted.length; i++) {
		if (!sorted[i][0] || !sorted[i][1] || sorted[i][0] >= sorted[i][1]) {
			return __('La apertura va antes que el cierre.', 'lachinata-core');
		}
		if (i && sorted[i][0] < sorted[i - 1][1]) {
			return __('Las franjas se solapan.', 'lachinata-core');
		}
	}
	return '';
};

/**
 * One or two slots.
 *
 * @param {Object}   props          Props.
 * @param {Array}    props.slots    Slots.
 * @param {Function} props.onChange Setter.
 * @param {string}   props.label    Label of the group.
 */
const Slots = ({ slots, onChange, label }) => (
	<div className="lc-stores-editor__slots" role="group" aria-label={label}>
		{slots.map((slot, index) => (
			<div className="lc-stores-editor__slot" key={index}>
				<TextControl
					{...field}
					type="time"
					label={__('Abre', 'lachinata-core')}
					value={slot[0]}
					onChange={(value) =>
						onChange(
							slots.map((item, i) =>
								i === index ? [value, item[1]] : item
							)
						)
					}
				/>
				<TextControl
					{...field}
					type="time"
					label={__('Cierra', 'lachinata-core')}
					value={slot[1]}
					onChange={(value) =>
						onChange(
							slots.map((item, i) =>
								i === index ? [item[0], value] : item
							)
						)
					}
				/>
				<Button
					variant="link"
					isDestructive
					onClick={() =>
						onChange(slots.filter((item, i) => i !== index))
					}
				>
					{__('Quitar', 'lachinata-core')}
				</Button>
			</div>
		))}
		{slots.length < 2 && (
			<Button
				variant="secondary"
				size="small"
				onClick={() =>
					onChange([
						...slots,
						slots.length ? ['17:00', '20:00'] : ['10:00', '14:00'],
					])
				}
			>
				{slots.length
					? __('Añadir tarde (horario partido)', 'lachinata-core')
					: __('Añadir horario', 'lachinata-core')}
			</Button>
		)}
		{slotError(slots) && (
			<Notice status="error" isDismissible={false}>
				{slotError(slots)}
			</Notice>
		)}
	</div>
);

/**
 * Map with a marker that can be dragged.
 *
 * @param {Object}   props        Props.
 * @param {number}   props.lat    Latitude.
 * @param {number}   props.lng    Longitude.
 * @param {Function} props.onMove Called with lat, lng.
 */
const MarkerMap = ({ lat, lng, onMove }) => {
	const node = useRef(null);
	const map = useRef(null);
	const marker = useRef(null);
	useEffect(() => {
		if (!node.current || map.current) {
			return;
		}
		map.current = L.map(node.current, { scrollWheelZoom: false });
		L.tileLayer(settings.tiles, {
			attribution: settings.attribution,
			subdomains: 'abcd',
			maxZoom: 19,
		}).addTo(map.current);
		marker.current = L.marker([lat || 40.4, lng || -3.7], {
			draggable: true,
			keyboard: true,
			title: __('Arrastra para corregir la posición', 'lachinata-core'),
		}).addTo(map.current);
		marker.current.on('dragend', () => {
			const point = marker.current.getLatLng();
			onMove(
				Math.round(point.lat * 1e6) / 1e6,
				Math.round(point.lng * 1e6) / 1e6
			);
		});
		map.current.setView([lat || 40.4, lng || -3.7], lat ? 16 : 5);
	}, []); // eslint-disable-line react-hooks/exhaustive-deps
	useEffect(() => {
		if (map.current && lat && lng) {
			marker.current.setLatLng([lat, lng]);
			map.current.setView(
				[lat, lng],
				Math.max(map.current.getZoom(), 15)
			);
		}
	}, [lat, lng]);
	return (
		<div
			ref={node}
			className="lc-stores-editor__map"
			style={{ height: 220 }}
		/>
	);
};

const AddressPanel = () => {
	const [meta, set] = useMeta();
	const address = meta[K('address')] || {};
	const [busy, setBusy] = useState(false);
	const [message, setMessage] = useState('');
	const setAddress = (key, value) =>
		set('address', { ...address, [key]: value });
	const countries = Object.entries(settings.countries || {}).map(
		([value, label]) => ({
			value,
			label,
		})
	);
	const search = async () => {
		setBusy(true);
		setMessage('');
		const query = [address.street, address.postcode, address.city]
			.filter(Boolean)
			.join(', ');
		try {
			const place = await apiFetch({
				path: `/lachinata/v1/oleotecas/geocode?q=${encodeURIComponent(query)}&country=${encodeURIComponent(address.country || '')}`,
			});
			set('lat', place.lat);
			set('lng', place.lng);
			setMessage(
				__(
					'Posición propuesta: comprueba el marcador y arrástralo si hace falta.',
					'lachinata-core'
				)
			);
		} catch (error) {
			setMessage(
				error?.message ||
					__('No encontramos esa dirección.', 'lachinata-core')
			);
		}
		setBusy(false);
	};
	return (
		<PluginDocumentSettingPanel
			name="lc-stores-address"
			title={__('Dirección y mapa', 'lachinata-core')}
		>
			<TextControl
				{...field}
				label={__('Nombre corto', 'lachinata-core')}
				help={__(
					'«Bilbao», «Madrid · Sol». El largo se compone con el ajuste del módulo.',
					'lachinata-core'
				)}
				value={meta[K('name')] || ''}
				onChange={(value) => set('name', value)}
			/>
			<TextControl
				{...field}
				label={__('Calle y número', 'lachinata-core')}
				value={address.street || ''}
				onChange={(value) => setAddress('street', value)}
			/>
			<TextControl
				{...field}
				label={__('Código postal', 'lachinata-core')}
				value={address.postcode || ''}
				onChange={(value) => setAddress('postcode', value)}
			/>
			<TextControl
				{...field}
				label={__('Ciudad', 'lachinata-core')}
				value={address.city || ''}
				onChange={(value) => setAddress('city', value)}
			/>
			<ComboboxControl
				{...field}
				label={__('País', 'lachinata-core')}
				value={address.country || ''}
				options={countries}
				onChange={(value) => setAddress('country', value || '')}
			/>
			<Button
				variant="secondary"
				isBusy={busy}
				disabled={busy || !address.city}
				onClick={search}
			>
				{__('Buscar en el mapa', 'lachinata-core')}
			</Button>
			{message && <p className="description">{message}</p>}
			{settings.tiles ? (
				<MarkerMap
					lat={meta[K('lat')]}
					lng={meta[K('lng')]}
					onMove={(lat, lng) => {
						set('lat', lat);
						set('lng', lng);
					}}
				/>
			) : (
				<p className="description">
					{__(
						'Sin teselas (falta la clave del mapa en los ajustes): escribe las coordenadas a mano.',
						'lachinata-core'
					)}
				</p>
			)}
			<TextControl
				{...field}
				type="number"
				step="0.000001"
				label={__('Latitud', 'lachinata-core')}
				value={meta[K('lat')] ?? ''}
				onChange={(value) =>
					set('lat', value === '' ? null : Number(value))
				}
			/>
			<TextControl
				{...field}
				type="number"
				step="0.000001"
				label={__('Longitud', 'lachinata-core')}
				value={meta[K('lng')] ?? ''}
				onChange={(value) =>
					set('lng', value === '' ? null : Number(value))
				}
			/>
			<ComboboxControl
				{...field}
				label={__('Zona horaria', 'lachinata-core')}
				help={__(
					'La de la tienda: «abierta ahora» se calcula con ella.',
					'lachinata-core'
				)}
				value={meta[K('timezone')] || ''}
				options={(settings.timezones || []).map((value) => ({
					value,
					label: value,
				}))}
				onChange={(value) => set('timezone', value || '')}
			/>
		</PluginDocumentSettingPanel>
	);
};

const ContactPanel = () => {
	const [meta, set] = useMeta();
	const country = (meta[K('address')] || {}).country || settings.base || '';
	const web = meta[K('web')] || {};
	const social = meta[K('social')] || [];
	return (
		<PluginDocumentSettingPanel
			name="lc-stores-contact"
			title={__('Contacto y redes', 'lachinata-core')}
		>
			<TextControl
				{...field}
				type="tel"
				label={__('Teléfono', 'lachinata-core')}
				help={__(
					'Se guarda en formato internacional (+34…).',
					'lachinata-core'
				)}
				value={meta[K('phone')] || ''}
				onChange={(value) => set('phone', value)}
				onBlur={() => set('phone', e164(meta[K('phone')], country))}
			/>
			<TextControl
				{...field}
				type="tel"
				label={__('WhatsApp', 'lachinata-core')}
				value={meta[K('whatsapp')] || ''}
				onChange={(value) => set('whatsapp', value)}
				onBlur={() =>
					set('whatsapp', e164(meta[K('whatsapp')], country))
				}
			/>
			<TextControl
				{...field}
				type="email"
				label={__('Correo', 'lachinata-core')}
				help={__('Nunca sale en claro en la página.', 'lachinata-core')}
				value={meta[K('email')] || ''}
				onChange={(value) => set('email', value)}
			/>
			<TextControl
				{...field}
				type="url"
				label={__('Tienda online propia', 'lachinata-core')}
				value={web.url || ''}
				onChange={(value) => set('web', { ...web, url: value })}
			/>
			<TextControl
				{...field}
				label={__('Etiqueta de la tienda online', 'lachinata-core')}
				help={__('Vacío: su dominio.', 'lachinata-core')}
				value={web.label || ''}
				onChange={(value) => set('web', { ...web, label: value })}
			/>
			{social.map((item, index) => (
				<div className="lc-stores-editor__row" key={index}>
					<SelectControl
						{...field}
						label={__('Red', 'lachinata-core')}
						value={item.network}
						options={(settings.networks || []).map((value) => ({
							value,
							label: value,
						}))}
						onChange={(value) =>
							set(
								'social',
								social.map((row, i) =>
									i === index
										? { ...row, network: value }
										: row
								)
							)
						}
					/>
					<TextControl
						{...field}
						type="url"
						label={__('URL', 'lachinata-core')}
						value={item.url}
						onChange={(value) =>
							set(
								'social',
								social.map((row, i) =>
									i === index ? { ...row, url: value } : row
								)
							)
						}
					/>
					<Button
						variant="link"
						isDestructive
						onClick={() =>
							set(
								'social',
								social.filter((row, i) => i !== index)
							)
						}
					>
						{__('Quitar', 'lachinata-core')}
					</Button>
				</div>
			))}
			<Button
				variant="secondary"
				onClick={() =>
					set('social', [
						...social,
						{ network: 'instagram', url: '' },
					])
				}
			>
				{__('Añadir red', 'lachinata-core')}
			</Button>
		</PluginDocumentSettingPanel>
	);
};

const HoursPanel = () => {
	const [meta, set] = useMeta();
	const hours = meta[K('hours')] || {};
	const names = DAY_NAMES();
	const setDay = (day, slots) =>
		set('hours', {
			...Object.fromEntries(DAYS.map((key) => [key, hours[key] || []])),
			[day]: slots,
		});
	return (
		<PluginDocumentSettingPanel
			name="lc-stores-hours"
			title={__('Horario', 'lachinata-core')}
		>
			<p className="description">
				{__(
					'Sin franjas, el día está cerrado. Dos franjas: horario partido.',
					'lachinata-core'
				)}
			</p>
			{DAYS.map((day) => (
				<fieldset key={day} className="lc-stores-editor__day">
					<legend>{names[day]}</legend>
					<Slots
						label={names[day]}
						slots={hours[day] || []}
						onChange={(slots) => setDay(day, slots)}
					/>
				</fieldset>
			))}
			<Button
				variant="secondary"
				onClick={() =>
					set(
						'hours',
						Object.fromEntries(
							DAYS.map((day) => [
								day,
								(hours.mon || []).map((slot) => [...slot]),
							])
						)
					)
				}
			>
				{__('Copiar el lunes a toda la semana', 'lachinata-core')}
			</Button>
		</PluginDocumentSettingPanel>
	);
};

const SpecialsPanel = () => {
	const [meta, set] = useMeta();
	const specials = meta[K('special')] || [];
	const change = (index, values) =>
		set(
			'special',
			specials.map((item, i) =>
				i === index ? { ...item, ...values } : item
			)
		);
	return (
		<PluginDocumentSettingPanel
			name="lc-stores-specials"
			title={__('Horarios especiales', 'lachinata-core')}
		>
			<p className="description">
				{__(
					'Festivos, Navidad o vacaciones: mandan sobre el horario semanal.',
					'lachinata-core'
				)}
			</p>
			{specials.map((item, index) => (
				<fieldset key={index} className="lc-stores-editor__day">
					<legend>
						{sprintf(
							/* translators: %d: number. */ __(
								'Especial %d',
								'lachinata-core'
							),
							index + 1
						)}
					</legend>
					<TextControl
						{...field}
						type="date"
						label={__('Desde', 'lachinata-core')}
						value={item.from || ''}
						onChange={(value) => change(index, { from: value })}
					/>
					<TextControl
						{...field}
						type="date"
						label={__('Hasta', 'lachinata-core')}
						value={item.to || ''}
						onChange={(value) => change(index, { to: value })}
					/>
					<CheckboxControl
						__nextHasNoMarginBottom
						label={__('Cerrado', 'lachinata-core')}
						checked={!(item.slots || []).length}
						onChange={(closed) =>
							change(index, {
								slots: closed ? [] : [['10:00', '14:00']],
								kind: closed ? item.kind : undefined,
							})
						}
					/>
					{!(item.slots || []).length && (
						<CheckboxControl
							__nextHasNoMarginBottom
							label={__('Cierre temporal', 'lachinata-core')}
							help={__(
								'Vacaciones o reforma. Solo uno a la vez: es el que ve y cambia la franquicia en su panel.',
								'lachinata-core'
							)}
							checked={item.kind === 'closure'}
							onChange={(closure) =>
								set(
									'special',
									specials.map((row, i) => {
										if (i === index) {
											return {
												...row,
												kind: closure
													? 'closure'
													: undefined,
											};
										}
										return closure
											? { ...row, kind: undefined }
											: row;
									})
								)
							}
						/>
					)}
					{(item.slots || []).length > 0 && (
						<Slots
							label={item.from}
							slots={item.slots}
							onChange={(slots) => change(index, { slots })}
						/>
					)}
					<TextControl
						{...field}
						label={__('Nota', 'lachinata-core')}
						help={__(
							'«Nochebuena», «Vacaciones».',
							'lachinata-core'
						)}
						value={item.note || ''}
						onChange={(value) => change(index, { note: value })}
					/>
					<Button
						variant="link"
						isDestructive
						onClick={() =>
							set(
								'special',
								specials.filter((row, i) => i !== index)
							)
						}
					>
						{__('Quitar', 'lachinata-core')}
					</Button>
				</fieldset>
			))}
			<Button
				variant="secondary"
				onClick={() =>
					set('special', [
						...specials,
						{ from: '', to: '', slots: [], note: '' },
					])
				}
			>
				{__('Añadir día especial', 'lachinata-core')}
			</Button>
		</PluginDocumentSettingPanel>
	);
};

const ContentPanel = () => {
	const [meta, set] = useMeta();
	const photos = meta[K('photos')] || [];
	const favorites = meta[K('favorites')] || [];
	const [names, setNames] = useState({});
	const [suggestions, setSuggestions] = useState([]);
	const images = useSelect(
		(select) =>
			photos.map((id) => select('core').getMedia(id)).filter(Boolean),
		[photos]
	);
	useEffect(() => {
		if (!favorites.length) {
			return;
		}
		apiFetch({
			path: `/wc/store/v1/products?include=${favorites.join(',')}&per_page=4`,
		})
			.then((products) =>
				setNames(
					Object.fromEntries(
						products.map((product) => [product.id, product.name])
					)
				)
			)
			.catch(() => {});
	}, [favorites.join(',')]); // eslint-disable-line react-hooks/exhaustive-deps
	const token = (id) =>
		`${names[id] || __('Producto', 'lachinata-core')} #${id}`;
	return (
		<PluginDocumentSettingPanel
			name="lc-stores-content"
			title={__('Texto, fotos y favoritos', 'lachinata-core')}
		>
			<TextareaControl
				__nextHasNoMarginBottom
				label={__('Texto propio', 'lachinata-core')}
				help={__(
					'Dos o tres frases: qué la hace especial, cómo llegar, qué se puede hacer allí.',
					'lachinata-core'
				)}
				value={meta[K('text')] || ''}
				onChange={(value) => set('text', value)}
			/>
			<MediaUploadCheck>
				<MediaUpload
					multiple
					gallery={false}
					allowedTypes={['image']}
					value={photos}
					onSelect={(media) =>
						set(
							'photos',
							media
								.map((item) => item.id)
								.slice(0, settings.maxPhotos || 8)
						)
					}
					render={({ open }) => (
						<Button variant="secondary" onClick={open}>
							{sprintf(
								/* translators: 1: photos, 2: most. */ __(
									'Fotos (%1$d de %2$d)',
									'lachinata-core'
								),
								photos.length,
								settings.maxPhotos || 8
							)}
						</Button>
					)}
				/>
			</MediaUploadCheck>
			<div className="lc-stores-editor__photos">
				{images.map((image) => (
					<img
						key={image.id}
						src={
							image.media_details?.sizes?.thumbnail?.source_url ||
							image.source_url
						}
						alt={image.alt_text}
						width="64"
						height="48"
					/>
				))}
			</div>
			<p className="description">
				{__(
					'4:3. La primera es la de la tarjeta y la de compartir.',
					'lachinata-core'
				)}
			</p>
			<FormTokenField
				__nextHasNoMarginBottom
				__next40pxDefaultSize
				label={__('Favoritos (hasta 4)', 'lachinata-core')}
				value={favorites.map(token)}
				suggestions={suggestions}
				maxLength={settings.maxFavs || 4}
				onInputChange={(search) => {
					if (search.length < 3) {
						return;
					}
					apiFetch({
						path: `/wc/store/v1/products?search=${encodeURIComponent(search)}&per_page=10`,
					})
						.then((products) => {
							setNames((current) => ({
								...current,
								...Object.fromEntries(
									products.map((product) => [
										product.id,
										product.name,
									])
								),
							}));
							setSuggestions(
								products.map(
									(product) =>
										`${product.name} #${product.id}`
								)
							);
						})
						.catch(() => {});
				}}
				onChange={(tokens) =>
					set(
						'favorites',
						tokens
							.map((item) =>
								Number(String(item).split('#').pop())
							)
							.filter(Boolean)
					)
				}
			/>
		</PluginDocumentSettingPanel>
	);
};

const SOURCES = () => ({
	api: __('Panel de franquicias', 'lachinata-core'),
	wp: __('WordPress', 'lachinata-core'),
	cli: __('WP-CLI', 'lachinata-core'),
});

const LogPanel = () => {
	const { id, saving } = useSelect(
		(select) => ({
			id: select('core/editor').getCurrentPostId(),
			saving: select('core/editor').isSavingPost(),
		}),
		[]
	);
	const [entries, setEntries] = useState(null);
	const [all, setAll] = useState(false);
	useEffect(() => {
		if (saving || !id) {
			return;
		}
		apiFetch({ path: `/lachinata/v1/oleotecas/log/${id}` })
			.then(setEntries)
			.catch(() => setEntries([]));
	}, [id, saving]);
	const shown = entries && !all ? entries.slice(0, 5) : entries || [];
	return (
		<PluginDocumentSettingPanel
			name="lc-stores-log"
			title={__('Registro de cambios', 'lachinata-core')}
		>
			<p className="description">
				{__(
					'Horario, días especiales y cierre temporal: quién los cambió, cuándo y desde dónde.',
					'lachinata-core'
				)}
			</p>
			{entries && !entries.length && (
				<p>{__('Aún no hay cambios.', 'lachinata-core')}</p>
			)}
			<ol className="lc-stores-editor__log">
				{shown.map((entry, index) => (
					<li key={index}>
						<p>
							<strong>{entry.at}</strong>
							{' · '}
							{entry.actor || __('Sin autor', 'lachinata-core')}
							{' · '}
							{SOURCES()[entry.source] || entry.source}
						</p>
						<ul>
							{entry.changes.map((line, i) => (
								<li key={i}>
									{sprintf(
										/* translators: 1: what («Lunes»), 2: before, 3: after. */ __(
											'%1$s: %2$s → %3$s',
											'lachinata-core'
										),
										line.label,
										line.before,
										line.after
									)}
								</li>
							))}
						</ul>
					</li>
				))}
			</ol>
			{entries && entries.length > 5 && !all && (
				<Button variant="link" onClick={() => setAll(true)}>
					{sprintf(
						/* translators: %d: number of changes. */ __(
							'Ver los %d cambios',
							'lachinata-core'
						),
						entries.length
					)}
				</Button>
			)}
		</PluginDocumentSettingPanel>
	);
};

registerPlugin('lachinata-oleotecas', {
	render: () => (
		<>
			<AddressPanel />
			<ContactPanel />
			<HoursPanel />
			<SpecialsPanel />
			<LogPanel />
			<ContentPanel />
		</>
	),
});
