<?php
/**
 * Store page (`/oleoteca/{slug}/`): photos, header with OpenStatus, «Cómo llegar», call and
 * WhatsApp, hours, own text and services, favourites, own online shop, map, profiles,
 * stores nearby and the franchise block (OleotecaFicha.dc.html, OleotecaFichaDesktop.dc.html).
 * No data, no section: the minimal page (name, address, coordinates, hours) is complete.
 *
 * The theme can override it with `lachinata/oleotecas/single.php`.
 *
 * @package LaChinata\Core
 */

use LaChinata\Core\Modules\Oleotecas\Directory;
use LaChinata\Core\Modules\Oleotecas\Html;
use LaChinata\Core\Modules\Oleotecas\OleotecasModule;
use LaChinata\Core\Modules\Oleotecas\Schedule;
use LaChinata\Core\Modules\Oleotecas\Store;
use LaChinata\Core\Modules\Oleotecas\Texts;
use LaChinata\Core\Modules\Oleotecas\Tiles;
use LaChinata\Core\Templates;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- The pieces come escaped from Html; the rest is escaped where it is printed.

$lachinata_store = Directory::store( (int) get_queried_object_id() );
$lachinata_post  = get_queried_object();
if ( null === $lachinata_store && $lachinata_post instanceof WP_Post ) {
	$lachinata_store = Store::from_post( $lachinata_post );
}

get_header();
if ( null !== $lachinata_store ) :
	$lachinata_place    = Directory::place( $lachinata_store );
	$lachinata_near_km  = max( 1, (int) OleotecasModule::setting( 'near_km' ) );
	$lachinata_nearby   = Directory::nearby( $lachinata_store, $lachinata_near_km );
	$lachinata_today    = gmdate( 'Y-m-d', time() - DAY_IN_SECONDS );
	$lachinata_specials = Schedule::upcoming( $lachinata_store['specials'], $lachinata_today );
	$lachinata_services = array_column( $lachinata_store['services'], 'name' );
	$lachinata_country  = $lachinata_place['country'];
	$lachinata_all_url  = $lachinata_country && $lachinata_country['page'] ? $lachinata_country['url'] : (string) get_post_type_archive_link( 'oleoteca' );
	$lachinata_all_text = $lachinata_country && $lachinata_country['page']
		/* translators: 1: «oleotecas», 2: country. */
		? sprintf( __( 'Todas las %1$s de %2$s', 'lachinata-core' ), Texts::noun( true ), $lachinata_country['name'] )
		/* translators: %s: «oleotecas». */
		: sprintf( __( 'Todas las %s', 'lachinata-core' ), Texts::noun( true ) );
	$lachinata_whatsapp = Store::whatsapp_url( $lachinata_store );
	$lachinata_site_tz  = wp_timezone_string();
	$lachinata_data     = array(
		'slug'     => $lachinata_store['slug'],
		'zone'     => $lachinata_place['zone'] ? $lachinata_place['zone']['slug'] : ( $lachinata_country ? $lachinata_country['slug'] : '' ),
		'timezone' => $lachinata_store['timezone'],
		'hours'    => $lachinata_store['hours'],
		'specials' => $lachinata_specials,
		'lat'      => $lachinata_store['lat'],
		'lng'      => $lachinata_store['lng'],
		'title'    => $lachinata_store['title'],
		'line'     => $lachinata_store['line'],
	);
	$lachinata_contact  = static function ( string $layout ) use ( $lachinata_store, $lachinata_whatsapp ): void {
		echo Html::directions_button(
			$lachinata_store,
			array(
				'size'  => 'lg',
				'block' => true,
			)
		);
		if ( '' === $lachinata_store['phone'] && '' === $lachinata_whatsapp ) {
			return;
		}
		echo '<div class="lc-store-page__pair">';
		if ( '' !== $lachinata_store['phone'] ) {
			echo Html::button(
				__( 'Llamar', 'lachinata-core' ),
				array(
					'variant'   => 'secondary',
					'icon_left' => 'phone',
					'block'     => true,
					'href'      => 'tel:' . $lachinata_store['phone'],
					'attrs'     => array( 'data-lc-store-call' => $layout ),
				)
			);
		}
		if ( '' !== $lachinata_whatsapp ) {
			echo Html::button(
				__( 'WhatsApp', 'lachinata-core' ),
				array(
					'variant'   => 'secondary',
					'icon_left' => 'whatsapp',
					'block'     => true,
					'href'      => $lachinata_whatsapp,
					'attrs'     => array(
						'data-lc-store-whatsapp' => $layout,
						'target'                 => '_blank',
						'rel'                    => 'noopener',
					),
				)
			);
		}
		echo '</div>';
	};
	?>
<article class="lc-store-page" data-lc-store-page="<?php echo esc_attr( (string) wp_json_encode( $lachinata_data ) ); ?>">
	<div class="lc-store-page__crumbs"><?php get_template_part( 'template-parts/breadcrumb' ); ?></div>

	<?php if ( $lachinata_store['photos'] ) : ?>
		<div class="lc-store-page__gallery" tabindex="0" aria-label="<?php esc_attr_e( 'Fotos', 'lachinata-core' ); ?>">
			<?php foreach ( $lachinata_store['photos'] as $lachinata_index => $lachinata_photo ) : ?>
				<figure class="lc-store-page__photo">
					<?php
					echo wp_get_attachment_image( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core markup.
						$lachinata_photo,
						'large',
						false,
						array(
							'loading'       => $lachinata_index ? 'lazy' : 'eager',
							'fetchpriority' => $lachinata_index ? 'auto' : 'high',
							'sizes'         => '(min-width: 1024px) 50vw, 100vw',
						)
					);
					?>
				</figure>
			<?php endforeach; ?>
			<?php if ( count( $lachinata_store['photos'] ) > 1 ) : ?>
				<span class="caption lc-store-page__count" aria-hidden="true" data-lc-gallery-count>1 / <?php echo esc_html( (string) count( $lachinata_store['photos'] ) ); ?></span>
			<?php endif; ?>
		</div>
	<?php endif; ?>

	<header class="lc-stores-hero lc-store-page__hero">
		<div class="lc-stores-hero__inner">
			<div class="lc-store-page__crumbs-desktop"><?php get_template_part( 'template-parts/breadcrumb' ); ?></div>
			<?php if ( '' !== $lachinata_store['city'] ) : ?>
				<span class="eyebrow"><?php echo esc_html( mb_strtoupper( Texts::noun() . ' · ' . $lachinata_store['city'] ) ); ?></span>
			<?php endif; ?>
			<h1 class="editorial-h1"><?php echo esc_html( $lachinata_store['title'] ); ?></h1>
			<p class="body lc-store-page__address" data-no-translation><?php echo esc_html( $lachinata_store['line'] ); ?></p>
			<?php if ( Schedule::has_hours( $lachinata_store['hours'] ) ) : ?>
				<?php echo Html::open_status( array( 'data-lc-open' => '' ) ); ?>
			<?php endif; ?>
		</div>
	</header>

	<div class="lc-store-page__body">
		<div class="lc-store-page__main">
			<div class="lc-store-page__actions"><?php $lachinata_contact( 'main' ); ?></div>

			<?php if ( Schedule::has_hours( $lachinata_store['hours'] ) ) : ?>
				<section class="lc-store-page__section lc-store-page__hours">
					<h2 class="h3"><?php esc_html_e( 'Horario', 'lachinata-core' ); ?></h2>
					<?php echo Html::hours( $lachinata_store['hours'], $lachinata_specials ); ?>
					<?php if ( '' !== $lachinata_store['timezone'] && $lachinata_store['timezone'] !== $lachinata_site_tz && '' !== $lachinata_store['city'] ) : ?>
						<p class="caption lc-store-page__tz">
							<?php
							/* translators: %s: city of the store. */
							echo esc_html( sprintf( __( 'Hora de %s.', 'lachinata-core' ), $lachinata_store['city'] ) );
							?>
						</p>
					<?php endif; ?>
				</section>
			<?php endif; ?>

			<?php if ( '' !== $lachinata_store['text'] || $lachinata_services ) : ?>
				<section class="lc-store-page__section">
					<h2 class="h3">
						<?php
						/* translators: %s: «oleoteca». */
						echo esc_html( sprintf( __( 'En esta %s', 'lachinata-core' ), Texts::noun() ) );
						?>
					</h2>
					<?php if ( '' !== $lachinata_store['text'] ) : ?>
						<p class="body lc-store-page__text"><?php echo esc_html( $lachinata_store['text'] ); ?></p>
					<?php endif; ?>
					<?php if ( $lachinata_services ) : ?>
						<ul class="body-sm lc-store-page__services">
							<?php foreach ( $lachinata_services as $lachinata_service ) : ?>
								<li><?php echo Html::icon( 'check', true ); ?><span><?php echo esc_html( $lachinata_service ); ?></span></li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>
				</section>
			<?php endif; ?>

			<?php
			$lachinata_products = array_filter(
				array_map( static fn( int $id ) => function_exists( 'wc_get_product' ) ? wc_get_product( $id ) : null, $lachinata_store['favorites'] ),
				static fn( $product ): bool => $product instanceof WC_Product && $product->is_visible()
			);
			?>
			<?php if ( $lachinata_products ) : ?>
				<section class="lc-store-page__section">
					<h2 class="h3">
						<?php
						/* translators: %s: «oleoteca». */
						echo esc_html( sprintf( __( 'Los favoritos de la %s', 'lachinata-core' ), Texts::noun() ) );
						?>
					</h2>
					<div class="lc-store-page__favorites">
						<?php
						foreach ( $lachinata_products as $lachinata_product ) {
							$GLOBALS['product'] = $lachinata_product; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WooCommerce's loop global for its template.
							wc_get_template_part( 'content', 'product' );
						}
						wp_reset_postdata();
						?>
					</div>
				</section>
			<?php endif; ?>

			<?php if ( '' !== $lachinata_store['web']['url'] ) : ?>
				<section class="lc-store-page__web">
					<div>
						<span class="eyebrow">
							<?php
							/* translators: %s: «oleoteca». */
							echo esc_html( mb_strtoupper( sprintf( __( 'Tienda online de esta %s', 'lachinata-core' ), Texts::noun() ) ) );
							?>
						</span>
						<span class="h4" data-no-translation><?php echo esc_html( $lachinata_store['web']['label'] ); ?></span>
					</div>
					<?php
					echo Html::button(
						/* translators: %s: domain of the online shop. */
						sprintf( __( 'Ir a %s', 'lachinata-core' ), $lachinata_store['web']['label'] ),
						array(
							'variant' => 'secondary',
							'icon'    => 'external',
							'href'    => $lachinata_store['web']['url'],
							'attrs'   => array(
								'data-lc-store-web' => '',
								'rel'               => 'noopener',
							),
						)
					);
					?>
				</section>
			<?php endif; ?>

			<section class="lc-store-page__section lc-store-page__nearby">
				<h2 class="h3">
					<?php
					echo esc_html(
						$lachinata_nearby
							/* translators: %s: «oleotecas». */
							? sprintf( __( 'Otras %s cerca', 'lachinata-core' ), Texts::noun( true ) )
							/* translators: %s: «oleotecas». */
							: sprintf( __( 'Más %s', 'lachinata-core' ), Texts::noun( true ) )
					);
					?>
				</h2>
				<?php if ( $lachinata_nearby ) : ?>
					<?php
					$lachinata_today_key = gmdate( 'Y-m-d', time() - DAY_IN_SECONDS );
					foreach ( $lachinata_nearby as $lachinata_near ) {
						echo Html::card(
							\LaChinata\Core\Modules\Oleotecas\Data::summary( $lachinata_near['store'], $lachinata_today_key ),
							array( 'distance' => number_format_i18n( $lachinata_near['km'], $lachinata_near['km'] < 10 ? 1 : 0 ) . ' km' )
						);
					}
					?>
				<?php else : ?>
					<p class="body lc-store-page__muted">
						<?php
						/* translators: 1: «oleoteca», 2: distance in km. */
						echo esc_html( sprintf( __( 'No hay otra %1$s a menos de %2$s km.', 'lachinata-core' ), Texts::noun(), number_format_i18n( $lachinata_near_km ) ) );
						?>
					</p>
				<?php endif; ?>
				<a class="label lc-store-page__all" href="<?php echo esc_url( $lachinata_all_url ); ?>"><?php echo esc_html( $lachinata_all_text ); ?> <?php echo Html::icon( 'arrow-right', true ); ?></a>
			</section>
		</div>

		<aside class="lc-store-page__aside">
			<?php if ( Schedule::has_hours( $lachinata_store['hours'] ) ) : ?>
				<div class="lc-store-page__aside-status"><?php echo Html::open_status( array( 'data-lc-open' => '' ) ); ?></div>
			<?php endif; ?>
			<div class="lc-store-page__aside-actions"><?php $lachinata_contact( 'aside' ); ?></div>
			<?php if ( '' !== $lachinata_store['phone'] || '' !== $lachinata_store['email'] ) : ?>
				<div class="body-sm lc-store-page__contact">
					<?php if ( '' !== $lachinata_store['phone'] ) : ?>
						<span><?php esc_html_e( 'Teléfono', 'lachinata-core' ); ?> <a href="tel:<?php echo esc_attr( $lachinata_store['phone'] ); ?>" class="label" data-no-translation data-lc-store-call="text"><?php echo esc_html( $lachinata_store['phone_display'] ); ?></a></span>
					<?php endif; ?>
					<?php if ( '' !== $lachinata_store['email'] ) : ?>
						<span hidden data-lc-mail="<?php echo esc_attr( base64_encode( strrev( $lachinata_store['email'] ) ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Keeps the address out of the HTML, as the system asks. ?>"><a href="#" class="label"><?php esc_html_e( 'Escribir un correo', 'lachinata-core' ); ?></a></span>
					<?php endif; ?>
				</div>
			<?php endif; ?>
			<?php if ( null !== $lachinata_store['lat'] && null !== $lachinata_store['lng'] && Tiles::available() ) : ?>
				<section class="lc-store-page__where">
					<h2 class="h3 lc-store-page__mobile-title"><?php esc_html_e( 'Dónde está', 'lachinata-core' ); ?></h2>
					<?php
					echo Html::map(
						array(
							'note'   => Html::map_note(),
							'stores' => array( $lachinata_store['slug'] ),
						)
					);
					?>
				</section>
			<?php endif; ?>
			<?php if ( $lachinata_store['social'] ) : ?>
				<section class="lc-store-page__social">
					<h2 class="h3 lc-store-page__mobile-title">
						<?php
						/* translators: «Síguela»: follow the store (feminine, as «oleoteca»). */
						echo esc_html_x( 'Síguela', 'store', 'lachinata-core' );
						?>
					</h2>
					<?php echo Html::social( $lachinata_store['social'], $lachinata_store['title'], true ); ?>
				</section>
			<?php endif; ?>
		</aside>
	</div>

	<div class="lc-stores__inner"><?php Templates::part( 'oleotecas', 'parts/franchise' ); ?></div>
</article>
	<?php
endif;
get_footer();
