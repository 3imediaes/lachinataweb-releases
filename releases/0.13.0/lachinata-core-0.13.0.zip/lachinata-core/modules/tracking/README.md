# Módulo `tracking`

Cookies y medición del comercio, para cualquier tienda. El aviso y el panel de cookies (`ConsentBanner`) se forman con los servicios que la tienda tiene configurados. Se ocupa también del modo de consentimiento v2 de Google, del registro de pruebas del consentimiento y de la política de cookies, que se mantiene cierta sola. La medición va encima del consentimiento: GA4, Google Ads y el píxel de Meta, con un bus de eventos propio y envíos desde el servidor (sección «Medición»).

**Cada servicio es opcional.** Un servicio sin su ID no se carga, no sale en el aviso ni en la política y la salud lo marca «sin configurar». Uno mal configurado (formato incorrecto, o Google Ads sin la etiqueta de compra) queda apagado y la salud avisa de ello. Una tienda sin ningún servicio de analítica ni de publicidad no muestra aviso de cookies. El código no lleva ningún ID, token, texto legal ni dato de empresa: son ajustes de cada tienda.

Especificación: componente `design-system/sistema/components/ConsentBanner` y borrador de política `design-system/docs/legal/politica-de-cookies.md`. Las decisiones están en `design-system/docs/decisiones.md` (incremento 7) y la guía de configuración en `docs/guias/medicion.md`. Los ajustes, en WooCommerce → La Chinata → Cookies y medición.

## Qué hace

### Consentimiento

| Pieza | Cómo | Dónde |
| --- | --- | --- |
| **Registro de servicios** `lachinata/tracking/services`. Cada servicio declara id, nombre, quién, empresa, categoría (`necessary`, `analytics`, `marketing`), si está configurado, sus cookies (nombre, quién, para qué, duración), los `handles` de los scripts que esperan al consentimiento, si usa el modo de consentimiento de Google, su política de privacidad y si está en el Marco de Privacidad UE-EE. UU. Solo cuentan los configurados. Lo usan este módulo y cualquier otro módulo o plugin | filtro | `Registry.php` |
| Servicios que trae el módulo: tienda (`lc_consent`), WooCommerce, WordPress, Stripe y PayPal (necesarios, si su pasarela está activa), GA4 (analítica), Google Ads, Meta y Mailchimp for WooCommerce (publicidad) | `Registry::builtin()` | `Registry.php` |
| **Aviso y panel** con el HTML exacto de `ConsentBanner`: «Configurar», «Rechazar todo» y «Aceptar todo» con el mismo peso (los tres `secondary`). En el panel, una fila por categoría con servicios y `.lc-switch`. **Las opcionales empiezan apagadas**: un interruptor solo sale encendido si esa persona ya lo aceptó (una casilla premarcada no es consentimiento). El nombre de la tienda en los textos es el nombre comercial de Datos de la empresa. Se pinta oculto en todas las páginas, porque van en caché, y `consent.js` muestra la barra si no hay una elección válida. El panel atrapa el foco, se cierra con Escape y deja inerte la página de detrás. Sin JavaScript no hay aviso: no se carga nada opcional | `wp_footer` | `Banner.php`, `src/consent.js`; capas en `theme/assets/css/theme.css` |
| Enlace **«Configurar cookies»** en la línea legal del pie: reabre el panel y, sin JavaScript, lleva a la política. En los correos no se pone | `lachinata/footer/consent` (tema) | `Banner.php` |
| **Modo de consentimiento v2** antes de cualquier otro script del `<head>`, solo con un servicio de Google: `ad_storage`, `analytics_storage`, `ad_user_data` y `ad_personalization` en `denied`, `security_storage` en `granted`, `wait_for_update: 500` y `ads_data_redaction`. Con una elección guardada, el `update` va en el mismo script. Al elegir, `update` | `wp_head`, prioridad 1 | `Banner::head()` |
| **Cookie `lc_consent`**: `<versión>.<analítica><publicidad>.<id aleatorio>.<fecha unix>`, 12 meses, `SameSite=Lax`, `Secure` con HTTPS. La escribe el navegador. La **versión** es un resumen de la lista de servicios opcionales activos (más una revisión manual, «Volver a preguntar a todos»): si cambia, la cookie vieja no vale y el aviso vuelve a salir | `Consent.php` | `Consent.php`, `src/consent.js` |
| **Scripts en espera**: los `handles` de los servicios salen como `type="text/plain" data-lc-consent="<categoría>"`, con sus partes en línea. `consent.js` los activa, en orden, al aceptar su categoría. Retirar una categoría borra sus cookies propias y recarga la página | `script_loader_tag` | `Gate.php` |
| **Mailchimp for WooCommerce**, como publicidad, mientras el ajuste está encendido (lo está de serie). Su script público (captura del correo para carritos abandonados), su píxel y el script de sitio conectado (`mcjs`) esperan al consentimiento. Sus cookies de PHP (atribución de campaña al llegar desde un correo; correo del carrito por AJAX y en el checkout de bloques) pasan por `mailchimp_allowed_to_use_cookie`, que responde según `lc_consent`. La sincronización de productos, pedidos y clientes sigue igual | `mailchimp_allowed_to_use_cookie`, `mailchimp_add_inline_footer_script` | `Mailchimp.php` |
| **Registro de pruebas del consentimiento**, sin datos personales: id aleatorio, fecha, versión, opciones, forma (aceptar, rechazar, a medida) y servicios activos. Sin IP, usuario ni navegador. Dos veces la misma elección en un minuto cuenta como una. Se borra pasado el plazo (36 meses de serie), cada día | `POST /lachinata/v1/consent`, Action Scheduler | `ConsentLog.php` |
| **Política de cookies**: `wp lachinata tracking policy` (o «Crear la política de cookies» en el panel) crea la página como **borrador pendiente de revisión legal**, con los datos de WooCommerce → La Chinata → Datos de la empresa. Lo que nombra servicios no se escribe en la página: lo pinta el bloque `lachinata/cookie-table` en cada visita (tabla de cookies, tipos, medición sin cookies, quién recibe los datos y fecha del último cambio) | WP-CLI, bloque dinámico | `Policy.php`, `Cli.php`, `blocks/cookie-table/`, `src/policy.js` |

### Medición

La tabla de eventos y la configuración de cada servicio están en `docs/guias/medicion.md`.

| Pieza | Cómo | Dónde |
| --- | --- | --- |
| **Bus de eventos** `window.lachinata.track(evento, datos)`, con nombres y parámetros de GA4, como única fuente. Tres adaptadores lo traducen: **GA4** (analítica), **Google Ads** (conversiones por etiqueta y remarketing dinámico) y **píxel de Meta** (publicidad). Cada uno se carga solo con su consentimiento, de forma asíncrona y después de `load`. Los eventos de la página esperan a la elección | | `src/measure.js` |
| **De dónde salen los eventos**: datos de la página que imprime el servidor (`#lc-measure`: view_item, view_cart, search, purchase); tarjetas y líneas de la bolsa con `data-lc-item`; promociones con `data-lc-promo` (`blocks`); eventos DOM del tema (`lachinata:cart:add`, `:remove`, `:quantity`, `:view`, `lachinata:content:added`); clics en tarjetas, promociones y «Tramitar pedido» | `lachinata/product_card/attributes`, `lachinata/cart/line_attributes` | `Measure.php` |
| **Productos**: la misma forma en todos los eventos (`item_id` de GA4 según `ProductIds`, nombre, marca, `item_category` a `item_category3`, variante, precio con IVA, cantidad, descuento, lista e índice). Llevan también los IDs de Google y Meta, que no llegan a GA4. **`value` = productos con IVA, sin envío**; envío e impuestos aparte en la compra | | `Items.php` |
| **Compra una vez por pedido**: «gracias» la imprime solo la primera vez y solo para quien tiene la clave del pedido (`_lc_tracking_sent`). En el servidor sale al pasar a «Procesando», «Completado» o «En espera», una sola vez | | `Measure.php`, `Server.php` |
| **Checkout sin etiquetas de terceros**: `begin_checkout`, `add_shipping_info` y `add_payment_info` (acciones `wp.hooks` del checkout de bloques; con un solo método de pago, que nadie elige, `add_payment_info` sale al enviar el pedido), `lc_express_pay`, `lc_gift`, `lc_shipping_unavailable` y `lc_checkout_error` (almacenes `wp.data`) van a `POST /lachinata/v1/event`. El servidor rehace los productos desde el carrito y los envía con el consentimiento de la cookie. En el checkout no se muestra la barra de cookies, para que nada tape «Pagar» | `wp.hooks`, `wp.data` | `src/measure.js`, `Server.php` |
| **Desde el servidor, en cola** (Action Scheduler):<br>— **GA4** por Measurement Protocol. Solo con consentimiento de analítica y con el `client_id` y la sesión leídos de las cookies de GA4 (`_ga`, `_ga_<id>`): la compra (con los del checkout, guardados en el pedido), sus reembolsos, los pasos del checkout y `lc_coupon`. Sin ese consentimiento no sale nada a GA4. Con el secreto, la compra de GA4 sale solo de aquí: nunca cuenta doble.<br>— **Meta** por la API de conversiones: Purchase, InitiateCheckout, AddPaymentInfo y AddToCart, solo con publicidad, con el `event_id` del píxel.<br>Las credenciales se añaden al enviar. Un error de red o un 5xx se reintenta una vez; el resto va al registro de huecos | `woocommerce_order_status_changed`, `woocommerce_order_refunded`, `woocommerce_applied_coupon`, `woocommerce_coupon_error` | `Server.php`, `Http.php` |
| **Contexto del pedido**: al pagar se guarda en el pedido el consentimiento y los IDs de GA4 y Meta del visitante (`_lc_tracking_context`), sin IP ni navegador (WooCommerce ya los guarda en el pedido) | `woocommerce_store_api_checkout_update_order_from_request` | `Server.php` |
| **Eventos para la página siguiente**: alta de cuenta, inicio de sesión, alta en la newsletter (`lachinata/newsletter/subscribed`) y cualquier `do_action( 'lachinata/tracking/event', $evento, $datos )` viajan en la cookie corta `lc_track_next`, solo con consentimiento | | `Measure.php` |
| **Medición sin cookies de Google tras rechazar** (modo de consentimiento avanzado): opcional y **apagada de serie** | `google_cookieless` | `src/measure.js`, `Policy.php` |

## Paso a producción

`docs/despliegue-tracking-feeds.md`.

## Depende de

Ningún módulo. Necesita WooCommerce 10. Lee del núcleo «Datos de la empresa» (`Company`) y los IDs de producto (`ProductIds`). Convive con Mailchimp for WooCommerce si está instalado.

## Hooks que escucha

- `wp_head` (prioridad 1), `wp_enqueue_scripts`, `wp_footer` y `script_loader_tag`.
- Pedidos y carrito: `woocommerce_store_api_checkout_update_order_from_request`, `woocommerce_checkout_order_processed`, `woocommerce_order_status_changed`, `woocommerce_order_refunded`, `woocommerce_applied_coupon`, `woocommerce_coupon_error`, `woocommerce_created_customer` y `wp_login`.
- `lachinata_tracking_send` (Action Scheduler) y `lachinata_tracking_purge_consent`.
- Del tema: `lachinata/product_card/attributes` y `lachinata/cart/line_attributes`. De `newsletter`: `lachinata/newsletter/subscribed`. De cualquiera: `lachinata/tracking/event`.
- `rest_api_init`, `action_scheduler_init` (programa el borrado, una vez al día), `init` (registra el bloque) y `admin_init` (fecha del último cambio de la política).
- `added_option`, `updated_option` y `deleted_option`, para olvidar la lista de servicios cuando cambia un ajuste.
- De Mailchimp for WooCommerce: `mailchimp_allowed_to_use_cookie` y `mailchimp_add_inline_footer_script`.
- Del tema: `lachinata/footer/consent`. Del núcleo: `lachinata/core/admin_tabs`.

## Hooks que emite

| Hook | Tipo | Para qué |
| --- | --- | --- |
| `lachinata/tracking/services` | filtro | Servicios que ponen cookies o cargan scripts |
| `lachinata/tracking/banner` | filtro | Si una página lleva el aviso y los scripts de consentimiento |
| `lachinata/tracking/graph_version` | filtro | Versión de la Graph API de Meta |
| `lachinata/tracking/queued` | acción | Una petición a GA4 o Meta entra en la cola (sin credenciales) |

En el navegador: el evento `lachinata:consent` en `document` (detalle: la elección) y `window.lcConsent`; `window.lachinata.consent.open()` abre el panel. Catálogo: `plugin/HOOKS.md`.

## Datos que guarda

- Tabla `{prefijo}lc_tracking_consent`: las pruebas del consentimiento. La crea la migración 1 y la borra «Borrar datos».
- Metadato de página `_lc_tracking_review`: la política sigue pendiente de revisión legal.
- Metadato de pedido `_lc_tracking_sent`: qué eventos del pedido ya salieron.
- Opciones `lachinata_tracking_*`: ajustes, registro de huecos (`_gaps`) y fecha del último cambio de la política (`_policy_changed`).

## REST y API para Odoo

`POST /lachinata/v1/event`: lo que el checkout pide enviar desde el servidor. Solo admite eventos y parámetros conocidos, rehace los productos desde el carrito o el catálogo, necesita la cookie de consentimiento y acepta 60 eventos por visitante cada 10 minutos.

`POST /lachinata/v1/consent`: es pública por naturaleza (eligen visitantes sin cuenta), así que solo acepta un id de 32 hexadecimales, la versión vigente (otra responde 409), dos booleanos y la forma. No aporta nada al objeto `lachinata` de los pedidos.

## Ajustes y exportación

| Ajuste | Por defecto | En el JSON |
| --- | --- | --- |
| IDs y credenciales: `ga4_id`, `ga4_api_secret`, `ads_id`, `ads_label_*`, `meta_pixel_id`, `meta_capi_token`, `meta_test_code` | vacíos (servicio apagado) | **no**: son de cada tienda (copiarlos mezclaría sus datos) y los secretos nunca salen |
| Conversiones mejoradas y remarketing dinámico de Google Ads (`ads_enhanced`, `ads_remarketing`) | no | sí |
| Mailchimp solo con consentimiento (`mailchimp_consent`) | sí | sí |
| Medición sin cookies de Google tras rechazar (`google_cookieless`) | no | sí |
| Plazo de las pruebas del consentimiento (`retention_months`) | 36 | sí |
| Revisión de la política (`policy_revision`, «Volver a preguntar a todos») | 0 | no |

Cada campo se valida al guardar (`G-…`, `AW-…`, etiquetas, ID de píxel numérico, tokens, `TEST…`) y el error sale junto a él, sin guardar nada. Los secretos no se muestran: se cambian escribiendo otro o se quitan con «Quitar». «Probar conexión» envía un evento de prueba al endpoint de validación de GA4 o a «Probar eventos» de Meta. Todo el panel exige `manage_woocommerce`.

## Qué pasa al apagarlo

Desaparecen el aviso, el enlace del pie, el modo de consentimiento y el bloqueo de scripts. Mailchimp for WooCommerce vuelve a cargar sus scripts y a poner sus cookies sin preguntar, así que en una tienda con servicios opcionales hace falta otro aviso. El bloque de la política deja de pintarse, aunque el texto fijo de la página sigue ahí. Las pruebas y los ajustes se conservan.

## Pruebas

- `tests/ConsentTest.php` comprueba:
  - una tienda sin servicios no pinta nada: ni aviso, ni script en el `<head>`, ni enlace del pie;
  - los formatos y los estados (`ok`, `off`, `broken`; Google Ads sin la etiqueta de compra);
  - el aviso solo con las categorías de los servicios activos y el HTML del sistema, con los tres botones del mismo peso;
  - el modo de consentimiento en «denegado» sin ninguna etiqueta cargada;
  - que la versión cambia con los servicios y que una elección vieja o caducada no vale;
  - el bloqueo de scripts;
  - la ruta de pruebas: una sola fila por doble clic, 409 con otra versión, 400 con un id mal formado y el borrado pasado el plazo;
  - la política según los servicios;
  - «Probar conexión» contra GA4 y Meta simulados.
- `tests/ServerTest.php` comprueba, con clientes HTTP simulados:
  - la compra una vez aunque cambie el estado, con el `client_id` y la sesión del visitante, `value` sin envío y `event_id` compartido con Meta;
  - sin consentimiento de analítica, nada a GA4 (ni la compra ni su reembolso), tampoco sin la cookie `_ga`; sin publicidad, nada a Meta;
  - el reembolso;
  - el reenvío del checkout: nada sin consentimiento; con él, los productos del carrito y 400 para un evento que no es del checkout;
  - el envío con las credenciales al final y el error en el registro de huecos sin el token;
  - los productos (ID de GA4, ruta de categorías, descuento, lista, IDs de los otros destinos) y que sin servicios las tarjetas no llevan datos.
- e2e `tests/e2e/tracking.spec.mjs` (perfiles `es` y `all`, con IDs de prueba; las etiquetas se interceptan y el servidor no sale de wp-env):
  - sin elegir no hay etiquetas ni cookies `_ga`, `_fbp` o `_gcl`, y los tres botones pesan igual;
  - rechazar deja `lc_consent` en `00`, no vuelve a preguntar y el pie reabre el panel, con foco atrapado y Escape;
  - aceptar y recorrer el embudo: view_item_list → select_item → view_item → add_to_cart → view_cart en orden y con sus parámetros, el checkout sin etiquetas pero con begin_checkout y add_payment_info en el servidor, la compra una vez aunque se recargue «gracias», y en el servidor una compra de GA4 y la de Meta con el mismo `event_id`.
- El humo de cada perfil comprueba el aviso (`es` y `all` lo rechazan; `canarias` y `cz`, con el módulo y sin IDs, no lo tienen) y que no se carga ninguna etiqueta sin consentimiento.

## Huecos conocidos

- La política es un borrador de Claude: necesita revisión legal antes de publicarse (aviso en la salud hasta marcarla como revisada).
- Las duraciones de las cookies de terceros son las publicadas por cada servicio: conviene comprobarlas en staging con el navegador limpio.
