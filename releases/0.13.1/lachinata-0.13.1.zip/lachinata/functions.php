<?php
/**
 * La Chinata theme bootstrap.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

define( 'LACHINATA_THEME_VERSION', '0.13.1' );

require get_template_directory() . '/inc/contract.php';
require get_template_directory() . '/inc/setup.php';
require get_template_directory() . '/inc/assets.php';
require get_template_directory() . '/inc/template-tags.php';
require get_template_directory() . '/inc/catalog.php';
require get_template_directory() . '/inc/navigation.php';
require get_template_directory() . '/inc/woocommerce.php';
require get_template_directory() . '/inc/cart.php';
require get_template_directory() . '/inc/thankyou.php';
require get_template_directory() . '/inc/emails.php';
