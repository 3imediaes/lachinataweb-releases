<?php
/**
 * What an entry mentions: products and stores.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * Links to a product are references (`data-lc-product="{id}"`): on the page the link takes
 * the product's current address, and without a published product the text stays without
 * link. Each entry keeps the products it mentions (references and recipe) and the stores
 * (links to their page and, in news, the name in the title). With that:
 * - a product that changes its ingredients, seals or the fields of `catalog` that count, or
 *   that is no longer published, sends the entries that mention it to «Revisar» (only when
 *   the change is after their last review);
 * - a store that closes for good shows a notice in the entries that mention it and sends
 *   them to «Revisar»; a link to a store that does not exist does the same.
 */
final class Mentions {

	/**
	 * Attribute of a reference to a product.
	 */
	public const ATTRIBUTE = 'data-lc-product';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'the_content', array( self::class, 'resolve' ), 20 );
		Hooks::add_action( 'lachinata/catalog/product_changed', array( self::class, 'product_changed' ), 10, 3 );
		Hooks::add_action( 'lachinata/catalog/product_discontinued', array( self::class, 'product_discontinued' ), 10, 2 );
		Hooks::add_action( 'lachinata/oleotecas/closed', array( self::class, 'store_closed' ), 10, 3 );
	}

	/**
	 * The links with a reference take the product's address; without a published product,
	 * only their text stays.
	 *
	 * @param mixed $html Content.
	 */
	public static function resolve( $html ): string {
		$html = (string) $html;
		if ( false === strpos( $html, self::ATTRIBUTE ) ) {
			return $html;
		}
		return (string) preg_replace_callback(
			'/<a\s([^>]*' . self::ATTRIBUTE . '=["\'](\d+)["\'][^>]*)>(.*?)<\/a>/is',
			static function ( array $link ): string {
				$product = wc_get_product( (int) $link[2] );
				if ( ! $product instanceof \WC_Product || 'publish' !== $product->get_status() || ! $product->is_visible() ) {
					return $link[3];
				}
				$attrs = (string) preg_replace( '/\shref=["\'][^"\']*["\']/i', '', ' ' . $link[1] );
				return '<a href="' . esc_url( $product->get_permalink() ) . '"' . $attrs . '>' . $link[3] . '</a>';
			},
			$html
		);
	}

	/**
	 * Products referenced in a text.
	 *
	 * @param string $content Content.
	 * @return int[]
	 */
	public static function products_in( string $content ): array {
		preg_match_all( '/' . self::ATTRIBUTE . '=["\'](\d+)["\']/', $content, $matches );
		return array_values( array_unique( array_map( 'intval', $matches[1] ) ) );
	}

	/**
	 * Stores linked in a text, and in the title of a news item, by slug.
	 *
	 * @param \WP_Post $post Post.
	 * @return string[]
	 */
	public static function stores_in( \WP_Post $post ): array {
		$slugs = array();
		preg_match_all( '/<a\s[^>]*href=["\']([^"\']+)["\']/i', $post->post_content, $matches );
		foreach ( $matches[1] as $url ) {
			/**
			 * The slug of a store from a link to its page, or '' (module `oleotecas`).
			 *
			 * @since 0.13.1
			 *
			 * @param string $slug '' by default.
			 * @param string $url  Link.
			 */
			$slug = (string) apply_filters( 'lachinata/oleotecas/slug_of', '', html_entity_decode( $url ) );
			if ( '' !== $slug ) {
				$slugs[ $slug ] = $slug;
			}
		}
		if ( Model::NEWS === Model::format_of( $post ) ) {
			$title = remove_accents( mb_strtolower( wp_strip_all_tags( $post->post_title ) ) );
			/**
			 * Short name of every store by slug, closed ones too (module `oleotecas`).
			 *
			 * @since 0.13.1
			 *
			 * @param array<string, string> $names None by default.
			 */
			foreach ( (array) apply_filters( 'lachinata/oleotecas/names', array() ) as $slug => $name ) {
				$name = remove_accents( mb_strtolower( (string) $name ) );
				if ( mb_strlen( $name ) >= 4 && preg_match( '/\b' . preg_quote( $name, '/' ) . '\b/u', $title ) ) {
					$slugs[ (string) $slug ] = (string) $slug;
				}
			}
		}
		return array_values( $slugs );
	}

	/**
	 * What the store module says of a slug, or null without the module.
	 *
	 * @param string $slug Slug.
	 * @return array{exists: bool, closed: bool, name: string, url: string, finder: string}|null
	 */
	public static function store( string $slug ): ?array {
		/**
		 * What the module `oleotecas` knows of the store of a slug: whether it exists, whether
		 * it is closed, its name, its page and the finder. Null without the module.
		 *
		 * @since 0.13.1
		 *
		 * @param array|null $status Null by default.
		 * @param string     $slug   Slug of the store's page.
		 */
		$status = apply_filters( 'lachinata/oleotecas/status', null, $slug );
		if ( ! is_array( $status ) ) {
			return null;
		}
		return array(
			'exists' => ! empty( $status['exists'] ),
			'closed' => ! empty( $status['closed'] ),
			'name'   => (string) ( $status['name'] ?? '' ),
			'url'    => (string) ( $status['url'] ?? '' ),
			'finder' => (string) ( $status['finder'] ?? '' ),
		);
	}

	/**
	 * Rewrites the index of an entry: products and stores, and the reason to review a link
	 * to a store that no longer exists.
	 *
	 * @param \WP_Post $post Post.
	 */
	public static function reindex( \WP_Post $post ): void {
		$products = self::products_in( $post->post_content );
		$recipe   = get_post_meta( $post->ID, Fields::RECIPE, true );
		$products = array_values( array_unique( array_merge( $products, array_map( 'intval', is_array( $recipe ) ? (array) ( $recipe['products'] ?? array() ) : array() ) ) ) );
		delete_post_meta( $post->ID, Fields::MENTIONS );
		foreach ( $products as $id ) {
			add_post_meta( $post->ID, Fields::MENTIONS, $id );
		}
		$stores = self::stores_in( $post );
		delete_post_meta( $post->ID, Fields::STORES );
		foreach ( $stores as $slug ) {
			add_post_meta( $post->ID, Fields::STORES, $slug );
			$status = self::store( $slug );
			if ( null !== $status && ! $status['exists'] && 'publish' === $post->post_status ) {
				Review::add( $post->ID, 'store-missing:' . $slug, __( 'Menciona una oleoteca que ya no existe.', 'lachinata-core' ) . ' (' . $slug . ')' );
			}
		}
	}

	/**
	 * The notices of the closed stores an entry mentions.
	 *
	 * @param \WP_Post $post Post.
	 */
	public static function notices( \WP_Post $post ): string {
		$html = '';
		foreach ( array_map( 'strval', (array) get_post_meta( $post->ID, Fields::STORES, false ) ) as $slug ) {
			$status = self::store( $slug );
			if ( null === $status || ! $status['closed'] ) {
				continue;
			}
			$html .= Html::notice(
				sprintf(
					/* translators: 1: store, 2: link to the finder. */
					esc_html__( '%1$s ya no está abierta. %2$s', 'lachinata-core' ),
					esc_html( $status['name'] ),
					'<a href="' . esc_url( $status['finder'] ) . '">' . esc_html__( 'Consulta las oleotecas más cercanas', 'lachinata-core' ) . '</a>'
				),
				'warning',
				'alert'
			);
		}
		return $html;
	}

	/**
	 * Entries that mention a product (references or recipe).
	 *
	 * @param int $product_id Product.
	 * @return int[]
	 */
	public static function entries_with_product( int $product_id ): array {
		return array_map(
			'intval',
			get_posts(
				array(
					'post_type'   => 'post',
					'post_status' => array( 'publish', 'draft', 'pending', 'future', 'private' ),
					'numberposts' => -1,
					'fields'      => 'ids',
					'meta_query'  => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Indexed by key.
						'relation' => 'OR',
						array(
							'key'   => Fields::MENTIONS,
							'value' => $product_id,
						),
						array(
							'key'   => Fields::PRODUCT,
							'value' => $product_id,
						),
					),
				)
			)
		);
	}

	/**
	 * `lachinata/catalog/product_changed`: the entries that mention the product and were last
	 * reviewed before the change go to «Revisar».
	 *
	 * @param mixed $product_id Product.
	 * @param mixed $what       What changed, for people («los ingredientes»).
	 * @param mixed $date       Day of the change (Y-m-d).
	 */
	public static function product_changed( $product_id, $what, $date ): void {
		$product = wc_get_product( (int) $product_id );
		$name    = $product instanceof \WC_Product ? $product->get_name() : '#' . (int) $product_id;
		$when    = strtotime( (string) $date . ' 23:59:59' );
		foreach ( self::entries_with_product( (int) $product_id ) as $id ) {
			$post = get_post( $id );
			if ( ! $post instanceof \WP_Post || ( $when && Dates::last( $post ) > $when ) ) {
				continue;
			}
			Review::add(
				$id,
				'product:' . (int) $product_id . ':' . sanitize_key( (string) $what ),
				sprintf(
					/* translators: 1: product, 2: what changed («sus ingredientes»), 3: date. */
					__( 'El producto %1$s cambió %2$s el %3$s.', 'lachinata-core' ),
					$name,
					(string) $what,
					Html::date( $when ? $when : time() )
				)
			);
		}
	}

	/**
	 * `lachinata/catalog/product_discontinued`: the entries that mention it go to «Revisar»
	 * (their links to it already show as text).
	 *
	 * @param mixed $product_id Product.
	 * @param mixed $date       Day (Y-m-d).
	 */
	public static function product_discontinued( $product_id, $date ): void {
		unset( $date );
		$name = get_the_title( (int) $product_id );
		foreach ( self::entries_with_product( (int) $product_id ) as $id ) {
			/* translators: %s: product. */
			Review::add( $id, 'product:' . (int) $product_id . ':gone', sprintf( __( 'El producto %s ya no está a la venta: su enlace sale como texto.', 'lachinata-core' ), $name ) );
		}
	}

	/**
	 * `lachinata/oleotecas/closed`: the entries that mention the store go to «Revisar» (their
	 * notice shows by itself).
	 *
	 * @param mixed $store_id Store.
	 * @param mixed $slug     Slug of its page.
	 * @param mixed $name     Its short name.
	 */
	public static function store_closed( $store_id, $slug, $name ): void {
		unset( $store_id );
		$ids = get_posts(
			array(
				'post_type'   => 'post',
				'post_status' => array( 'publish', 'draft', 'pending', 'future', 'private' ),
				'numberposts' => -1,
				'fields'      => 'ids',
				'meta_key'    => Fields::STORES, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Indexed by key.
				'meta_value'  => (string) $slug, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- Indexed by key.
			)
		);
		foreach ( $ids as $id ) {
			/* translators: %s: store. */
			Review::add( (int) $id, 'store-closed:' . (string) $slug, sprintf( __( 'La oleoteca %s ha cerrado: la entrada ya muestra el aviso; revisa el texto.', 'lachinata-core' ), (string) $name ) );
		}
	}
}
