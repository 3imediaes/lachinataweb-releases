<?php
/**
 * The destination the visitor chose.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Locale;

use LaChinata\Core\Hooks;
use LaChinata\Core\Services;
use LaChinata\Core\Shipping\Destination;

defined( 'ABSPATH' ) || exit;

/**
 * Where it is kept and who reads it. The `lc_destino` cookie (a year, SameSite=Lax) holds
 * the id of a destination of this shop; the user meta keeps it for the next device and the
 * login brings it back. From the cookie come the WooCommerce customer (country and state,
 * so the bag and the checkout calculate with it), the destination of the eta endpoint and,
 * when the page cache varies by the cookie, the destination of cached pages
 * (`lachinata/shipping/destination`).
 */
final class Visitor {

	/**
	 * Cookie with the chosen destination.
	 */
	public const COOKIE = 'lc_destino';

	/**
	 * Session cookie: the picker was closed without choosing (it does not open again until
	 * the browser closes).
	 */
	public const SEEN = 'lc_destino_visto';

	/**
	 * Cookie: the suggestion by location was already checked once (the «Parece que estás
	 * en…» notice never comes back).
	 */
	public const CHECKED = 'lc_destino_aviso';

	/**
	 * User meta with the chosen destination.
	 */
	public const META = '_lc_locale_destination';

	/**
	 * Key in the WooCommerce session: destination already applied to the customer.
	 */
	private const SESSION = 'lc_locale_applied';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/shipping/destination', array( self::class, 'shipping_destination' ) );
		Hooks::add_filter( 'lachinata/eta/rest_destination', array( self::class, 'rest_destination' ), 10, 2 );
		Hooks::add_filter( 'lachinata/shipping/destination_label', array( self::class, 'destination_label' ), 10, 2 );
		Hooks::add_action( 'woocommerce_cart_loaded_from_session', array( self::class, 'sync_customer' ) );
		Hooks::add_action( 'woocommerce_add_to_cart', array( self::class, 'sync_customer' ) );
		Hooks::add_action( 'wp_login', array( self::class, 'login' ), 10, 2 );
		Hooks::add_filter( 'woocommerce_set_cookie_options', array( self::class, 'cookie_options' ), 10, 2 );
	}

	/**
	 * SameSite=Lax on the module's cookies (WooCommerce sets none).
	 *
	 * @param array<string, mixed>|mixed $options Options of setcookie().
	 * @param string|mixed               $name    Cookie name.
	 * @return array<string, mixed>|mixed
	 */
	public static function cookie_options( $options, $name ) {
		if ( is_array( $options ) && in_array( $name, array( self::COOKIE, self::SEEN, self::CHECKED ), true ) ) {
			$options['samesite'] = 'Lax';
		}
		return $options;
	}

	/**
	 * Whether the page cache varies by `lc_destino` (or there is none): then the server
	 * renders for the visitor's destination. Otherwise pages are the same for everyone and
	 * the browser completes them.
	 */
	public static function server_renders(): bool {
		return 'none' !== LocaleModule::setting( 'cache_mode' );
	}

	/**
	 * The destination of this shop in the cookie, or null.
	 *
	 * @return array{id: string, label: string, note: string, store: string, list: string, states: string[]}|null
	 */
	public static function current(): ?array {
		$raw         = isset( $_COOKIE[ self::COOKIE ] ) ? sanitize_text_field( wp_unslash( $_COOKIE[ self::COOKIE ] ) ) : '';
		$destination = '' === $raw ? null : Config::find( $raw );
		return null !== $destination && '' === $destination['store'] ? $destination : null;
	}

	/**
	 * The destination the HTML is rendered for: the visitor's when the cache varies by the
	 * cookie, none otherwise (the page then shows everything and the browser hides).
	 *
	 * @return array{id: string, label: string, note: string, store: string, list: string, states: string[]}|null
	 */
	public static function rendered(): ?array {
		return self::server_renders() ? self::current() : null;
	}

	/**
	 * The destination shown when the visitor has not chosen: the one of the default zone
	 * of the shipping rules, or the first of this shop.
	 *
	 * @return array{id: string, label: string, note: string, store: string, list: string, states: string[]}|null
	 */
	public static function fallback(): ?array {
		$rules = Services::shipping_rules();
		$place = Destination::of_zone( new \WC_Shipping_Zone( null === $rules ? 0 : $rules->default_zone_id() ) );
		$found = Config::for_location( $place['country'], $place['state'] );
		if ( null !== $found && '' === $found['store'] ) {
			return $found;
		}
		return Config::own()[0] ?? null;
	}

	/**
	 * The label of this shop's destination for a place («España · Península») in the free
	 * shipping texts of the PromoBar and the UspBar.
	 *
	 * @param string|mixed                $name        Name so far.
	 * @param array<string, string>|mixed $destination Country and state.
	 * @return string|mixed
	 */
	public static function destination_label( $name, $destination ) {
		if ( ! is_array( $destination ) || empty( $destination['country'] ) ) {
			return $name;
		}
		$found = Config::for_location( (string) $destination['country'], (string) ( $destination['state'] ?? '' ) );
		return null !== $found && '' === $found['store'] ? $found['label'] : $name;
	}

	/**
	 * Destination of cached pages (PromoBar, UspBar, product page) when the server renders
	 * for the visitor.
	 *
	 * @param array<string, string>|null $destination Destination so far.
	 * @return array<string, string>|null
	 */
	public static function shipping_destination( $destination ) {
		$current = self::rendered();
		return null === $current ? $destination : Config::location( $current );
	}

	/**
	 * Destination of the eta endpoint from its `destino` parameter («ES-IB» → ES:PM).
	 *
	 * @param array<string, string>|null $destination Parsed destination.
	 * @param string                     $code        Raw parameter.
	 * @return array<string, string>|null
	 */
	public static function rest_destination( $destination, $code ) {
		$found = Config::find( (string) $code );
		return null === $found ? $destination : Config::location( $found );
	}

	/**
	 * Keeps a destination of this shop: cookie, user meta and WooCommerce customer.
	 *
	 * @param array{id: string, label: string, note: string, store: string, list: string, states: string[]} $destination Destination.
	 */
	public static function choose( array $destination ): void {
		self::set_cookie( self::COOKIE, $destination['id'], YEAR_IN_SECONDS );
		if ( is_user_logged_in() ) {
			update_user_meta( get_current_user_id(), self::META, $destination['id'] );
		}
		self::apply( $destination );
	}

	/**
	 * Gives the destination to the WooCommerce customer when the visitor already has a
	 * session (never starts one: that would take cached pages away from them). Runs on
	 * every cart load and on the first add to the bag.
	 */
	public static function sync_customer(): void {
		$current = self::current();
		$session = function_exists( 'WC' ) ? WC()->session : null;
		if ( null === $current || ! $session instanceof \WC_Session_Handler || ! $session->has_session() || $session->get( self::SESSION ) === $current['id'] ) {
			return;
		}
		self::apply( $current );
	}

	/**
	 * Country and state of the customer (shipping and billing, as WooCommerce's own
	 * calculator does), and the mark that it is applied.
	 *
	 * @param array{id: string, label: string, note: string, store: string, list: string, states: string[]} $destination Destination.
	 */
	private static function apply( array $destination ): void {
		$customer = function_exists( 'WC' ) ? WC()->customer : null;
		$session  = function_exists( 'WC' ) ? WC()->session : null;
		if ( ! $customer instanceof \WC_Customer || ! $session instanceof \WC_Session_Handler || ! $session->has_session() ) {
			return;
		}
		$place = Config::location( $destination );
		if ( $customer->get_shipping_country() !== $place['country'] || ( '' !== $place['state'] && ! in_array( $customer->get_shipping_state(), $destination['states'], true ) ) ) {
			$customer->set_shipping_location( $place['country'], $place['state'], '' );
			$customer->set_billing_location( $place['country'], $place['state'], '' );
			$customer->save();
		}
		$session->set( self::SESSION, $destination['id'] );
	}

	/**
	 * On login, the destination of the profile wins; without one, the profile keeps the
	 * cookie's.
	 *
	 * @param string   $login User login.
	 * @param \WP_User $user  User.
	 */
	public static function login( $login, $user ): void {
		unset( $login );
		if ( ! $user instanceof \WP_User ) {
			return;
		}
		$saved = Config::find( (string) get_user_meta( $user->ID, self::META, true ) );
		if ( null !== $saved && '' === $saved['store'] ) {
			self::set_cookie( self::COOKIE, $saved['id'], YEAR_IN_SECONDS );
			return;
		}
		$current = self::current();
		if ( null !== $current ) {
			update_user_meta( $user->ID, self::META, $current['id'] );
		}
	}

	/**
	 * Sets a cookie of the module for the domain of the shop (WooCommerce's wrapper, with
	 * COOKIEPATH and COOKIE_DOMAIN; SameSite=Lax from cookie_options()), also for this request.
	 *
	 * @param string $name     Name.
	 * @param string $value    Value.
	 * @param int    $lifetime Seconds; 0 for a session cookie.
	 */
	public static function set_cookie( string $name, string $value, int $lifetime ): void {
		$_COOKIE[ $name ] = $value;
		if ( ! headers_sent() ) {
			wc_setcookie( $name, $value, $lifetime ? time() + $lifetime : 0, is_ssl() );
		}
	}
}
