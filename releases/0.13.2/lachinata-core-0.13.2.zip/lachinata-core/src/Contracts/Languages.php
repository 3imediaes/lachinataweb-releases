<?php
/**
 * Languages the shop sells in.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Contracts;

defined( 'ABSPATH' ) || exit;

/**
 * The languages of the shop and how a text or a link reads in each one. The core serves a
 * single language, the one of the site (Languages\SiteLanguage); `translate` will serve
 * the others with the same contract. Readers (the feeds, the `hreflang` of `content`)
 * loop over languages() and never assume there is only one.
 */
interface Languages {

	/**
	 * Language codes of the shop (WordPress locales, «es_ES», «cs_CZ»), the default first.
	 *
	 * @return string[]
	 */
	public function languages(): array;

	/**
	 * The default language.
	 */
	public function default_language(): string;

	/**
	 * Name of a language for people («Español»).
	 *
	 * @param string $language Locale.
	 */
	public function label( string $language ): string;

	/**
	 * Title and description of a product (or variation) in a language. Without a
	 * translation, the original.
	 *
	 * @param \WC_Product $product  Product or variation.
	 * @param string      $language Locale.
	 * @return array{title: string, description: string, short_description: string}
	 */
	public function product_texts( \WC_Product $product, string $language ): array;

	/**
	 * Name of a term (a category) in a language.
	 *
	 * @param \WP_Term $term     Term.
	 * @param string   $language Locale.
	 */
	public function term_name( \WP_Term $term, string $language ): string;

	/**
	 * A link of the shop in a language (a product permalink, the home…).
	 *
	 * @param string $url      Link in the default language.
	 * @param string $language Locale.
	 */
	public function url( string $url, string $language ): string;
}
