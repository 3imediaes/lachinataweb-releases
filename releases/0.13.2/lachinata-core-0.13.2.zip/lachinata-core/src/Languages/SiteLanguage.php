<?php
/**
 * The language of the site, while no module serves more.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Languages;

use LaChinata\Core\Contracts\Languages;

defined( 'ABSPATH' ) || exit;

/**
 * One language, the locale of the site, with the texts and links as they are.
 */
final class SiteLanguage implements Languages {

	/**
	 * Languages of the shop: only the site's.
	 *
	 * @return string[]
	 */
	public function languages(): array {
		return array( $this->default_language() );
	}

	/**
	 * The locale of the site.
	 */
	public function default_language(): string {
		return get_locale();
	}

	/**
	 * Name of the language, from the WordPress translations when they are installed.
	 *
	 * @param string $language Locale.
	 */
	public function label( string $language ): string {
		if ( 'en_US' === $language ) {
			return 'English';
		}
		if ( ! function_exists( 'wp_get_available_translations' ) ) {
			require_once ABSPATH . 'wp-admin/includes/translation-install.php';
		}
		// Reads the cached list of WordPress.org; without it, the locale itself.
		$known = wp_get_available_translations();
		return isset( $known[ $language ]['native_name'] ) ? (string) $known[ $language ]['native_name'] : $language;
	}

	/**
	 * The product's own texts.
	 *
	 * @param \WC_Product $product  Product or variation.
	 * @param string      $language Locale.
	 * @return array{title: string, description: string, short_description: string}
	 */
	public function product_texts( \WC_Product $product, string $language ): array {
		unset( $language );
		return array(
			'title'             => $product->get_name(),
			'description'       => (string) $product->get_description(),
			'short_description' => (string) $product->get_short_description(),
		);
	}

	/**
	 * The term's own name.
	 *
	 * @param \WP_Term $term     Term.
	 * @param string   $language Locale.
	 */
	public function term_name( \WP_Term $term, string $language ): string {
		unset( $language );
		return $term->name;
	}

	/**
	 * The link as it is.
	 *
	 * @param string $url      Link.
	 * @param string $language Locale.
	 */
	public function url( string $url, string $language ): string {
		unset( $language );
		return $url;
	}
}
