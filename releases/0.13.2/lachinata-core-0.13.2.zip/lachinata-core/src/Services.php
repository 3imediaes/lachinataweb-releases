<?php
/**
 * Shared services that modules offer each other.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core;

defined( 'ABSPATH' ) || exit;

/**
 * A module never builds another module's classes: it asks here for the interface in
 * Contracts/, which the serving module fills with a filter while it is on, and checks it
 * is there.
 */
final class Services {

	/**
	 * Short notices by WhatsApp or SMS (module `notify`), or null when it is off.
	 */
	public static function notifier(): ?Contracts\Notifier {
		/**
		 * The notifier of the site (module `notify`).
		 *
		 * @since 0.8.0
		 *
		 * @param Contracts\Notifier|null $notifier Null while no module serves it.
		 */
		$notifier = apply_filters( 'lachinata/notify/service', null );
		return $notifier instanceof Contracts\Notifier ? $notifier : null;
	}

	/**
	 * The newsletter provider (module `newsletter`), or null when it is off.
	 */
	public static function newsletter(): ?Contracts\Newsletter {
		/**
		 * The newsletter service of the site (module `newsletter`).
		 *
		 * @since 0.8.0
		 *
		 * @param Contracts\Newsletter|null $newsletter Null while no module serves it.
		 */
		$newsletter = apply_filters( 'lachinata/newsletter/service', null );
		return $newsletter instanceof Contracts\Newsletter ? $newsletter : null;
	}

	/**
	 * The shipping rules (module `shipping`), or null when it is off.
	 */
	public static function shipping_rules(): ?Contracts\ShippingRules {
		/**
		 * The shipping rules of the site (module `shipping`).
		 *
		 * @since 0.9.0
		 *
		 * @param Contracts\ShippingRules|null $rules Null while no module serves them.
		 */
		$rules = apply_filters( 'lachinata/shipping/service', null );
		return $rules instanceof Contracts\ShippingRules ? $rules : null;
	}

	/**
	 * Delivery dates (module `eta`), or null when it is off.
	 */
	public static function delivery(): ?Contracts\DeliveryEstimator {
		/**
		 * The delivery estimator of the site (module `eta`).
		 *
		 * @since 0.9.0
		 *
		 * @param Contracts\DeliveryEstimator|null $estimator Null while no module serves it.
		 */
		$estimator = apply_filters( 'lachinata/eta/service', null );
		return $estimator instanceof Contracts\DeliveryEstimator ? $estimator : null;
	}

	/**
	 * The languages of the shop: `translate` when it serves them; otherwise the site's
	 * only language. Never null.
	 */
	public static function languages(): Contracts\Languages {
		/**
		 * The languages of the shop (module `translate`, increment 10).
		 *
		 * @since 0.10.0
		 *
		 * @param Contracts\Languages|null $languages Null while no module serves them.
		 */
		$languages = apply_filters( 'lachinata/languages/service', null );
		return $languages instanceof Contracts\Languages ? $languages : new Languages\SiteLanguage();
	}

	/**
	 * Net content of the products (module `catalog`), or null when it is off.
	 */
	public static function product_content(): ?Contracts\ProductContent {
		/**
		 * The net content of the products (module `catalog`).
		 *
		 * @since 0.10.0
		 *
		 * @param Contracts\ProductContent|null $content Null while no module serves it.
		 */
		$content = apply_filters( 'lachinata/catalog/service', null );
		return $content instanceof Contracts\ProductContent ? $content : null;
	}
}
