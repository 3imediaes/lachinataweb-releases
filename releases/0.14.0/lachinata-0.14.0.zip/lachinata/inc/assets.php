<?php
/**
 * Styles, scripts and font preloads.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Whether the current view uses the editorial typography (Recoleta).
 */
function lachinata_is_editorial_view(): bool {
	$editorial = is_front_page() || is_singular( 'post' ) || is_page_template( 'templates/editorial.php' ) || is_home() || is_category() || is_tag();
	/**
	 * Whether the view uses the editorial typography (Recoleta is preloaded): a page of a
	 * module with an editorial title, such as the store finder.
	 *
	 * @since 0.12.0
	 *
	 * @param bool $editorial Home, posts, the editorial template and the blog archives.
	 */
	return (bool) apply_filters( 'lachinata/view/editorial', $editorial );
}

/**
 * Whether the view is a page of the blog (blog.css is loaded): posts and their archives,
 * and the module pages that say so (the magazine, sections and topics of `content`).
 */
function lachinata_is_blog_view(): bool {
	$blog = is_singular( 'post' ) || is_home() || is_category() || is_tag();
	/**
	 * Whether the view is a page of the blog (the components of the group «Blog» and the
	 * layout of the magazine, the article and the recipe are loaded: blog.css).
	 *
	 * @since 0.13.0
	 *
	 * @param bool $blog Posts and their archives.
	 */
	return (bool) apply_filters( 'lachinata/view/blog', $blog );
}

/**
 * Enqueues the theme styles and script.
 */
function lachinata_enqueue_assets(): void {
	$uri = get_template_directory_uri();

	wp_enqueue_style( 'lachinata-tokens', $uri . '/assets/css/tokens.css', array(), LACHINATA_THEME_VERSION );
	wp_enqueue_style( 'lachinata-components', $uri . '/assets/css/components.css', array( 'lachinata-tokens' ), LACHINATA_THEME_VERSION );
	wp_enqueue_style( 'lachinata-theme', $uri . '/assets/css/theme.css', array( 'lachinata-components' ), LACHINATA_THEME_VERSION );

	if ( lachinata_is_blog_view() ) {
		wp_enqueue_style( 'lachinata-blog', $uri . '/assets/css/blog.css', array( 'lachinata-theme' ), LACHINATA_THEME_VERSION );
	}

	if ( function_exists( 'is_checkout' ) && ( is_checkout() || is_account_page() ) ) {
		wp_enqueue_style( 'lachinata-checkout', $uri . '/assets/css/checkout.css', array( 'lachinata-theme' ), LACHINATA_THEME_VERSION );
	}

	$asset_file = get_template_directory() . '/build/theme.asset.php';
	if ( is_readable( $asset_file ) ) {
		$asset = require $asset_file;
		wp_enqueue_script(
			'lachinata-theme',
			$uri . '/build/theme.js',
			$asset['dependencies'],
			$asset['version'],
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
		wp_set_script_translations( 'lachinata-theme', 'lachinata', get_template_directory() . '/languages' );
		// Core registers its packages in the head; on the front end ours are only needed by
		// this deferred script, so they move to the footer and stop blocking the first paint.
		foreach ( $asset['dependencies'] as $dependency ) {
			wp_scripts()->add_data( $dependency, 'group', 1 );
		}
		foreach ( array( 'wp-hooks' ) as $core_dependency ) {
			wp_scripts()->add_data( $core_dependency, 'group', 1 );
		}
		wp_add_inline_script( 'lachinata-theme', 'window.lachinata = Object.assign( window.lachinata || {}, ' . wp_json_encode( lachinata_script_data() ) . ' );', 'before' );
	}
}
add_action( 'wp_enqueue_scripts', 'lachinata_enqueue_assets' );

/**
 * Data the front-end script needs.
 *
 * @return array<string, mixed>
 */
function lachinata_script_data(): array {
	return array(
		'storeApi'  => esc_url_raw( rest_url( 'wc/store/v1/' ) ),
		'cartUrl'   => function_exists( 'wc_get_cart_url' ) ? esc_url_raw( wc_get_cart_url() ) : '',
		'searchUrl' => esc_url_raw( home_url( '/' ) ),
		'currency'  => function_exists( 'get_woocommerce_currency' ) ? array(
			'decimal'  => wc_get_price_decimal_separator(),
			'thousand' => wc_get_price_thousand_separator(),
			'decimals' => wc_get_price_decimals(),
			'format'   => get_woocommerce_price_format(),
			'symbol'   => html_entity_decode( get_woocommerce_currency_symbol() ),
		) : null,
	);
}

/**
 * Removes what the system replaces: jQuery and WooCommerce's classic front-end
 * scripts and styles. The block checkout keeps its own scripts.
 */
function lachinata_dequeue_assets(): void {
	if ( is_admin() ) {
		return;
	}
	foreach ( array( 'wc-add-to-cart', 'wc-cart-fragments', 'woocommerce', 'wc-single-product', 'wc-add-to-cart-variation', 'wc-cart', 'sourcebuster-js', 'wc-order-attribution', 'zoom', 'flexslider', 'photoswipe', 'photoswipe-ui-default' ) as $handle ) {
		wp_dequeue_script( $handle );
	}
	foreach ( array( 'photoswipe', 'photoswipe-default-skin', 'woocommerce-inline' ) as $handle ) {
		wp_dequeue_style( $handle );
	}
	$needs_blocks = function_exists( 'is_checkout' ) && ( is_checkout() || has_block( 'woocommerce/checkout' ) );
	if ( ! $needs_blocks ) {
		wp_dequeue_style( 'wc-blocks-style' );
		wp_dequeue_style( 'wc-blocks-vendors-style' );
	}
	if ( ! is_singular() || ! comments_open() ) {
		wp_dequeue_script( 'comment-reply' );
	}
	wp_dequeue_style( 'classic-theme-styles' );

	// The checkout block removes the classic checkout scripts from render(), which in a
	// classic theme runs after wp_enqueue_scripts: it never happens. Same list as the block
	// (Checkout::dequeue_woocommerce_core_scripts); wc-checkout pulls jQuery and five more.
	if ( lachinata_is_block_checkout() ) {
		foreach ( array( 'wc-checkout', 'wc-address-autocomplete', 'wc-password-strength-meter', 'selectWoo' ) as $handle ) {
			wp_dequeue_script( $handle );
		}
		wp_dequeue_style( 'wc-address-autocomplete' );
		wp_dequeue_style( 'select2' );
	}
	// WooCommerce enqueues selectWoo (and so jQuery, in the head) on every checkout and
	// account page; the order received page has no select.
	if ( function_exists( 'is_order_received_page' ) && is_order_received_page() ) {
		wp_dequeue_script( 'selectWoo' );
		wp_dequeue_style( 'select2' );
	}
}
add_action( 'wp_enqueue_scripts', 'lachinata_dequeue_assets', 100 );

/**
 * Checkout form view: the checkout page without the order-pay and order-received
 * endpoints, which WooCommerce renders with the classic templates.
 */
function lachinata_is_block_checkout(): bool {
	return function_exists( 'is_checkout' ) && is_checkout() && ! is_checkout_pay_page() && ! is_order_received_page();
}

/**
 * Prefetch hints before WooCommerce adds its own (priority 10).
 *
 * @param array<int, string|array<string, string>> $urls          Hints.
 * @param string                                   $relation_type Relation.
 * @return array<int, string|array<string, string>>
 */
function lachinata_hints_before_woocommerce( array $urls, string $relation_type ): array {
	if ( 'prefetch' === $relation_type ) {
		$GLOBALS['lachinata_prefetch_before'] = $urls;
	}
	return $urls;
}
add_filter( 'wp_resource_hints', 'lachinata_hints_before_woocommerce', 9, 2 );

/**
 * Drops WooCommerce's prefetch of the cart block. The cart page holds the cart block, but
 * the bag is /bolsa/ (templates/cart-page.php) and never renders it. On the checkout
 * WooCommerce only prefetches the cart block, so everything it added goes; elsewhere it
 * also prefetches the checkout, which stays, and only the cart's own files go.
 *
 * @param array<int, string|array<string, string>> $urls          Hints.
 * @param string                                   $relation_type Relation.
 * @return array<int, string|array<string, string>>
 */
function lachinata_drop_cart_block_prefetch( array $urls, string $relation_type ): array {
	if ( 'prefetch' !== $relation_type || ! isset( $GLOBALS['lachinata_prefetch_before'] ) ) {
		return $urls;
	}
	$before = $GLOBALS['lachinata_prefetch_before'];
	if ( lachinata_is_block_checkout() ) {
		return $before;
	}
	return array_values(
		array_filter(
			$urls,
			static function ( $hint ): bool {
				$href = is_array( $hint ) ? (string) ( $hint['href'] ?? '' ) : (string) $hint;
				return ! preg_match( '#/woocommerce/assets/client/blocks/cart-frontend(\.min)?\.js|/wp-includes/js/dist/style-engine(\.min)?\.js#', $href );
			}
		)
	);
}
add_filter( 'wp_resource_hints', 'lachinata_drop_cart_block_prefetch', 11, 2 );

// The system draws every WooCommerce element; its stylesheets are not loaded.
add_filter( 'woocommerce_enqueue_styles', '__return_empty_array' );

/**
 * Preloads the fonts the first screen needs: DIN always, Recoleta on editorial views.
 * SantElia Script is never preloaded: campaign-font.js loads it after the page (64 KB in the
 * critical path delayed the LCP of the home).
 */
function lachinata_preload_fonts(): void {
	$fonts = array( 'DINPro-Light', 'DINPro-Medium', 'DINPro-Black' );
	if ( lachinata_is_editorial_view() ) {
		$fonts[] = 'Recoleta-Black';
	}
	foreach ( $fonts as $font ) {
		printf(
			'<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n",
			esc_url( get_template_directory_uri() . '/assets/fonts/' . $font . '.woff2' )
		);
	}
}
add_action( 'wp_head', 'lachinata_preload_fonts', 1 );

/**
 * Prints the icon sprite once, at the start of the body.
 */
function lachinata_icon_sprite(): void {
	$sprite = get_template_directory() . '/assets/icons/sprite.svg';
	if ( is_readable( $sprite ) ) {
		echo preg_replace( '/<!--.*?-->\s*/s', '', (string) file_get_contents( $sprite ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped, WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Generated file of the theme.
	}
}
add_action( 'wp_body_open', 'lachinata_icon_sprite', 1 );

/**
 * Marks the document as having JavaScript before the first paint (no flash of the
 * no-JS fallbacks such as the «Actualizar bolsa» button).
 */
function lachinata_js_class(): void {
	echo "<script>document.documentElement.classList.add('lc-js');</script>\n";
}
add_action( 'wp_head', 'lachinata_js_class', 0 );

// No emojis in the interface (system rule): WordPress' emoji detection script is not loaded.
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
