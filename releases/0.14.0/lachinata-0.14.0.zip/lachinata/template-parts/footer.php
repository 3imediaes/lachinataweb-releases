<?php
/**
 * Footer on the Inverse theme: newsletter slot, link groups (accordion on mobile,
 * four columns on desktop), seal and legal line.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_groups = lachinata_menu( 'footer' );
?>
<footer class="lc-footer" data-theme="dark">
	<?php if ( has_action( 'lachinata/footer/newsletter' ) ) : ?>
		<div class="lc-footer__news">
			<?php
			/**
			 * Newsletter sign-up of the footer (provider pending: nothing by default).
			 *
			 * @since 0.2.0
			 */
			do_action( 'lachinata/footer/newsletter' );
			?>
		</div>
	<?php endif; ?>
	<?php if ( $lachinata_groups ) : ?>
		<div class="lc-footer__groups">
			<div class="lc-acc">
				<?php foreach ( $lachinata_groups as $lachinata_index => $lachinata_group ) : ?>
					<div class="lc-acc__item">
						<button type="button" class="lc-acc__btn h4" aria-expanded="false" aria-controls="lc-foot-<?php echo esc_attr( (string) $lachinata_index ); ?>" data-lc-toggle>
							<?php echo esc_html( $lachinata_group['title'] ); ?>
							<?php echo lachinata_icon( 'chevron-down' ); ?>
						</button>
						<div class="lc-acc__panel body-sm" id="lc-foot-<?php echo esc_attr( (string) $lachinata_index ); ?>" hidden>
							<?php foreach ( $lachinata_group['children'] as $lachinata_link ) : ?>
								<a href="<?php echo esc_url( $lachinata_link['url'] ); ?>"><?php echo esc_html( $lachinata_link['title'] ); ?></a>
							<?php endforeach; ?>
						</div>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<div class="lc-footer__cols">
			<?php foreach ( $lachinata_groups as $lachinata_group ) : ?>
				<div>
					<h2 class="h4"><?php echo esc_html( $lachinata_group['title'] ); ?></h2>
					<?php foreach ( $lachinata_group['children'] as $lachinata_link ) : ?>
						<a href="<?php echo esc_url( $lachinata_link['url'] ); ?>" class="body-sm"><?php echo esc_html( $lachinata_link['title'] ); ?></a>
					<?php endforeach; ?>
				</div>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
	<div class="lc-footer__seal">
		<?php echo lachinata_logo( 16 ); ?>
		<?php if ( get_bloginfo( 'description' ) ) : ?>
			<small class="caption"><?php bloginfo( 'description' ); ?></small>
		<?php endif; ?>
		<?php echo lachinata_social_links(); ?>
	</div>
	<div class="lc-footer__legal caption">
		<?php
		/**
		 * Start of the legal line (the locale module adds the destination and language link).
		 *
		 * @since 0.2.0
		 */
		do_action( 'lachinata/footer/legal' );
		foreach ( lachinata_menu( 'legal' ) as $lachinata_link ) {
			printf( '<a href="%s">%s</a>', esc_url( $lachinata_link['url'] ), esc_html( $lachinata_link['title'] ) );
		}
		/**
		 * End of the legal links of the footer (the tracking module adds «Configurar cookies»,
		 * which reopens the cookie panel).
		 *
		 * @since 0.10.0
		 */
		do_action( 'lachinata/footer/consent' );
		/**
		 * Copyright line of the footer.
		 *
		 * @since 0.2.0
		 *
		 * @param string $text «© 2026 Site name» by default.
		 */
		$lachinata_copyright = (string) apply_filters( 'lachinata/footer/copyright', sprintf( '© %1$s %2$s', wp_date( 'Y' ), lachinata_shop_name() ) );
		?>
		<span><?php echo esc_html( $lachinata_copyright ); ?></span>
	</div>
</footer>
