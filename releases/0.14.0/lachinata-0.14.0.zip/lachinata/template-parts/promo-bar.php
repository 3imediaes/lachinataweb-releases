<?php
/**
 * PromoBar: one line; each item of the «promo» menu is a message and they take turns.
 * On mobile it may start with the destination badge (`lachinata/promo_bar/start`).
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_messages = array_map(
	static fn( array $item ): array => $item + array( 'short' => $item['text'] ),
	lachinata_menu( 'promo' )
);
/**
 * Messages of the PromoBar.
 *
 * @since 0.2.0
 *
 * @param array<int, array{title: string, url: string, icon: string, short?: string, attrs?: array<string, string>}> $messages Items of the «promo» menu; `short`, the text when the MarketBadge already says the destination (mobile; the item's description, since 0.12.1); `attrs`, data-* attributes of the message (since 0.11.0).
 */
$lachinata_messages = (array) apply_filters( 'lachinata/promo_bar/messages', $lachinata_messages );
if ( ! $lachinata_messages && ! has_action( 'lachinata/promo_bar/start' ) ) {
	return;
}
?>
<div class="lc-promo body-sm" role="status" data-lc-promo>
	<?php
	/**
	 * Start of the PromoBar, on mobile (the locale module adds MarketBadge; the messages
	 * then take the rest of the bar).
	 *
	 * @since 0.11.0
	 */
	do_action( 'lachinata/promo_bar/start' );
	?>
	<?php
	foreach ( $lachinata_messages as $lachinata_index => $lachinata_message ) :
		$lachinata_short = trim( (string) ( $lachinata_message['short'] ?? '' ) );
		$lachinata_text  = '' === $lachinata_short || $lachinata_short === $lachinata_message['title']
			? esc_html( $lachinata_message['title'] )
			: '<span class="lc-promo__full">' . esc_html( $lachinata_message['title'] ) . '</span><span class="lc-promo__short">' . esc_html( $lachinata_short ) . '</span>';
		?>
		<span class="lc-promo__msg"<?php echo lachinata_attrs( lachinata_data_attrs( (array) ( $lachinata_message['attrs'] ?? array() ) ) ); ?><?php echo $lachinata_index ? ' hidden' : ''; ?>>
			<?php echo lachinata_icon( '' !== $lachinata_message['icon'] ? $lachinata_message['icon'] : 'truck', array( 'size' => 'sm' ) ); ?>
			<?php if ( $lachinata_message['url'] && '#' !== $lachinata_message['url'] ) : ?>
				<a href="<?php echo esc_url( $lachinata_message['url'] ); ?>"><?php echo $lachinata_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above. ?></a>
			<?php else : ?>
				<span><?php echo $lachinata_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above. ?></span>
			<?php endif; ?>
		</span>
	<?php endforeach; ?>
</div>
