<?php
/**
 * Order received (Gracias.dc.html): confirmation, delivery date and address, «Seguir el
 * pedido», save your details, the order and «Mientras llega». WooCommerce's hooks stay:
 * gateways print their notes in `woocommerce_thankyou_<gateway>` and `woocommerce_thankyou`
 * (its order table is removed: the OrderSummary replaces it).
 *
 * @package LaChinata\Theme
 * @version 11.2.0
 *
 * @var WC_Order|false $order
 */

defined( 'ABSPATH' ) || exit;

$lachinata_order = $order ?? false;
?>
<div class="lc-thanks woocommerce-order">
	<?php if ( ! $lachinata_order instanceof WC_Order ) : ?>
		<section class="lc-thanks__hero">
			<h1 class="h1"><?php esc_html_e( 'Gracias. Hemos recibido tu pedido.', 'lachinata' ); ?></h1>
		</section>
	<?php else : ?>
		<?php
		/**
		 * WooCommerce: before the order received content.
		 *
		 * @since 0.5.0
		 */
		do_action( 'woocommerce_before_thankyou', $lachinata_order->get_id() ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.HookCommentWrongStyle, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook.
		?>

		<?php if ( $lachinata_order->has_status( 'failed' ) ) : ?>
			<section class="lc-thanks__hero lc-thanks__hero--failed">
				<h1 class="h1"><?php esc_html_e( 'No hemos podido cobrar tu pedido', 'lachinata' ); ?></h1>
				<?php echo lachinata_notice( esc_html__( 'Tu banco o la pasarela han rechazado el pago. Vuelve a intentarlo o elige otra forma de pago.', 'lachinata' ), 'error' ); ?>
				<?php
				echo lachinata_button(
					__( 'Volver a pagar', 'lachinata' ),
					array(
						'href'  => $lachinata_order->get_checkout_payment_url(),
						'block' => true,
					)
				);
				?>
			</section>
		<?php else : ?>
			<section class="lc-thanks__hero">
				<span class="lc-thanks__check" aria-hidden="true"><?php echo lachinata_icon( 'check' ); ?></span>
				<span class="eyebrow lc-thanks__number" data-no-translation>
					<?php
					/* translators: %s: order number. */
					echo esc_html( sprintf( __( 'Pedido %s', 'lachinata' ), $lachinata_order->get_order_number() ) );
					?>
				</span>
				<h1 class="h1">
					<?php
					$lachinata_name = $lachinata_order->get_billing_first_name();
					echo esc_html(
						'' === $lachinata_name
							? __( 'Gracias. Tu pedido está en marcha.', 'lachinata' )
							/* translators: %s: customer's first name. */
							: sprintf( __( 'Gracias, %s. Tu pedido está en marcha.', 'lachinata' ), $lachinata_name )
					);
					?>
				</h1>
				<?php if ( $lachinata_order->get_billing_email() ) : ?>
					<p class="body"><?php echo wp_kses( sprintf( /* translators: %s: email address. */ __( 'Te hemos enviado la confirmación a %s.', 'lachinata' ), '<span data-no-translation>' . esc_html( $lachinata_order->get_billing_email() ) . '</span>' ), array( 'span' => array( 'data-no-translation' => array() ) ) ); ?></p>
				<?php endif; ?>
			</section>

			<?php $lachinata_delivery = lachinata_thankyou_delivery( $lachinata_order ); ?>
			<section class="lc-thanks__delivery">
				<?php if ( null !== $lachinata_delivery ) : ?>
					<div class="lc-thanks__when">
						<span class="lc-thanks__icon" aria-hidden="true"><?php echo lachinata_icon( 'truck' ); ?></span>
						<div class="lc-thanks__when-text">
							<span class="h4"><?php echo esc_html( $lachinata_delivery['title'] ); ?></span>
							<?php if ( '' !== $lachinata_delivery['text'] ) : ?>
								<span class="body-sm" data-no-translation><?php echo esc_html( $lachinata_delivery['text'] ); ?></span>
							<?php endif; ?>
							<span class="caption"><?php esc_html_e( 'Te avisaremos por correo cuando salga.', 'lachinata' ); ?></span>
						</div>
					</div>
				<?php endif; ?>
				<?php
				/**
				 * Room for the gift block next to the delivery date (module `gift`): «Es un
				 * regalo para María» and how the recipient will be told.
				 *
				 * @since 0.7.0
				 *
				 * @param WC_Order $order Order.
				 */
				do_action( 'lachinata/thankyou/gift', $lachinata_order );
				?>
				<?php
				$lachinata_tracking = lachinata_order_tracking( $lachinata_order );
				echo lachinata_button(
					null === $lachinata_tracking ? __( 'Seguir el pedido', 'lachinata' ) : __( 'Seguir el paquete', 'lachinata' ),
					array(
						'href'    => null === $lachinata_tracking ? lachinata_thankyou_track_url( $lachinata_order ) : $lachinata_tracking['url'],
						'variant' => 'secondary',
						'block'   => true,
						'icon'    => 'arrow-right',
					)
				);
				?>
			</section>

			<?php
			/**
			 * Room for «save your details» on the order received page (module `checkout`).
			 *
			 * @since 0.5.0
			 *
			 * @param WC_Order $order Order.
			 */
			do_action( 'lachinata/thankyou/account', $lachinata_order );
			?>
			<div class="lc-thanks__invoice">
				<?php
				/**
				 * Room for «¿Necesitas factura con NIF?» on the order received page (module
				 * `checkout`): an express payment brings no tax id.
				 *
				 * @since 0.6.0
				 *
				 * @param WC_Order $order Order.
				 */
				do_action( 'lachinata/thankyou/invoice', $lachinata_order );
				?>
			</div>
		<?php endif; ?>

		<section class="lc-thanks__summary" aria-label="<?php esc_attr_e( 'Tu pedido', 'lachinata' ); ?>">
			<?php lachinata_part( 'order-summary', array( 'order' => $lachinata_order ) ); ?>
		</section>

		<div class="lc-thanks__gateway">
			<?php
			/**
			 * WooCommerce: notes of the gateway used (bank details, instructions).
			 *
			 * @since 0.5.0
			 */
			do_action( 'woocommerce_thankyou_' . $lachinata_order->get_payment_method(), $lachinata_order->get_id() ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.HookCommentWrongStyle, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook.
			/**
			 * WooCommerce: order received.
			 *
			 * @since 0.5.0
			 */
			do_action( 'woocommerce_thankyou', $lachinata_order->get_id() ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.HookCommentWrongStyle, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook.
			?>
		</div>

		<?php $lachinata_more = lachinata_thankyou_products( $lachinata_order ); ?>
		<?php if ( count( $lachinata_more ) >= 2 ) : ?>
			<section class="lc-thanks__more" aria-labelledby="lc-thanks-more">
				<?php
				lachinata_part(
					'section-header',
					array(
						'title' => __( 'Mientras llega', 'lachinata' ),
						'text'  => __( 'Lo que suele acompañar a lo que has pedido', 'lachinata' ),
						'level' => 'h3',
						'id'    => 'lc-thanks-more',
					)
				);
				?>
				<div class="lc-carousel">
					<?php foreach ( array_values( $lachinata_more ) as $lachinata_index => $lachinata_item ) : ?>
						<?php
						lachinata_part(
							'product-card',
							array(
								'product' => $lachinata_item,
								'list'    => array(
									'id'    => 'thankyou',
									'name'  => __( 'Mientras llega', 'lachinata' ),
									'index' => $lachinata_index + 1,
								),
							)
						);
						?>
					<?php endforeach; ?>
				</div>
			</section>
		<?php endif; ?>

		<?php
		/**
		 * Thank you page, after «Mientras llega» and before «Seguir comprando».
		 *
		 * @since 0.13.0
		 *
		 * @param WC_Order $order Order.
		 */
		do_action( 'lachinata/thankyou/after', $lachinata_order );
		?>

		<div class="lc-thanks__continue">
			<?php
			echo lachinata_button(
				__( 'Seguir comprando', 'lachinata' ),
				array(
					'href'    => function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' ),
					'variant' => 'ghost',
					'block'   => true,
					'icon'    => 'arrow-right',
				)
			);
			?>
		</div>
	<?php endif; ?>
</div>
