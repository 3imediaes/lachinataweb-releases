# Módulo `catalog`

Datos propios del catálogo que en la web actual están en ACF, con campos nativos de WordPress y WooCommerce: contenido y referencia para el precio por unidad (también por variación), ingredientes, etiqueta, imagen de descripción, consumo preferente y exclusión internacional del producto; tinta de cada categoría; taxonomía `tipo` (sellos) con su icono. Sustituye a ACF sin migración de datos: lee las claves de ACF hasta que se normalizan.

Desde la 0.12.2 (incremento 9c), además: categoría principal e imagen de tarjeta del producto; tono, imagen y orden de cada etiqueta de producto; la configuración de la tienda (categorías de la tienda con campañas de temporada, venta cruzada por categoría raíz y marcas de las clases de envío) y la salud del catálogo. El principio: **la plantilla pinta los datos tal como vienen**; lo que está mal se corrige en la ficha y la salud lo avisa.

Especificación: `design-system/sistema/03-implementacion.md` («ACF se retira» y tabla de módulos). Huecos del tema que rellena: `theme/HOOKS.md`. Se enciende por defecto al activar el plugin.

## Qué hace

| Pieza | Cómo | Dónde |
| --- | --- | --- |
| Campos del producto en la pestaña «La Chinata» de la ficha del panel (y por variación, contenido y referencia) | `woocommerce_product_data_tabs`, `woocommerce_product_data_panels`, `woocommerce_product_after_variable_attributes`, `woocommerce_admin_process_product_object` y `_variation_object` | `ProductAdmin.php` |
| Metadatos nativos con `show_in_rest` (editor y Store API): `_lc_contenido`, `_lc_referencia` (cantidad y unidad por separado), `_lc_ingredientes`, `_lc_etiqueta`, `_lc_imagen_descripcion`, `_lc_consumo_preferente`, `_lc_excluir_internacional`. Si un producto aún no está normalizado, se lee la clave de ACF (`cantidad_unidad_medida`…) | `register_post_meta`, `register_term_meta` | `Fields.php`, `Quantity.php` |
| Tinta de la categoría (`_lc_tint`, la heredan las subcategorías) e icono del tipo (`_lc_icono`), con selector de medios | Campos de término (`product_cat_*_form_fields`, `created_`/`edited_`) | `TermFields.php`, `Admin.php` |
| Taxonomía `tipo` (sellos del producto) | `register_taxonomy` en `init` | `TipoTaxonomy.php` |
| Lo que ve el cliente, por los huecos del tema: precio por unidad («500 ml \| 9,33 € / 1 l»), tinta de categoría y de producto, etiqueta antes de las insignias, pestañas Ingredientes e imagen de descripción, sellos, consumo preferente y la segunda línea de los productos en los correos | Filtros `lachinata/product/*`, `lachinata/category/tint`, `lachinata/product_card/badges` | `Storefront.php`, `UnitPrice.php` |
| Normalización de ACF a los campos nativos (una vez por sitio): cantidad y unidad por separado; el EAN no se migra (manda el GTIN de WooCommerce y solo se avisa de los que no coinciden) | `wp lachinata catalog normalize [--dry-run] [--from-shipping-class=<slug>]` | `NormalizeCommand.php` |
| La marca de exclusión internacional para `shipping` | Filtro `lachinata/catalog/no_ship_abroad` (0.9.0) | `CatalogModule.php` |
| Categoría principal (`_lc_catalog_categoria_principal`, una de las del producto) e imagen de tarjeta (`_lc_catalog_imagen_tarjeta`) en la pestaña «La Chinata» | `lachinata/product/main_category`, `lachinata/product_card/image_id`; la tinta del producto sale de la principal | `ProductAdmin.php`, `Storefront.php` |
| Aspecto de cada etiqueta de producto: tono de la lista del sistema, imagen opcional (la bandera de «Extremeño») y orden | Campos del término `product_tag`; `lachinata/product_card/badges` las devuelve todas, en ese orden, tras «-20 %» y la «etiqueta» | `TermFields.php`, `Storefront.php` |
| Marca de una clase de envío: pastilla con texto en la tarjeta y un icono opcional («Refrigerado», sin icono, en Frío y Fresco) y, si se marca, su aviso en la ficha con su título, su icono y las condiciones que dan `shipping` y `eta` («Envío refrigerado» con el camión). Desde 0.12.3; antes, un icono con nombre accesible | `lachinata/product_card/marker`, `lachinata/product/notices` y `lachinata/catalog/marker_conditions` (0.12.2) | `Config.php`, `Storefront.php` |
| Categorías de la tienda: lista ordenada y campañas de temporada con fechas (entran delante mientras duran) | `lachinata/catalog/categories` | `Config.php`, `Storefront.php` |
| Venta cruzada por categoría raíz: título y fuente (las del producto y, sin ellas, los más vendidos de su subcategoría; o solo los más vendidos) | `lachinata/product/cross_sell` | `Config.php`, `Storefront.php` |
| WooCommerce → La Chinata → Catálogo: «Salud del catálogo» (se calcula al abrirla) y «Tienda» (la configuración de arriba); contador en la portada | `lachinata/core/admin_tabs`, `lachinata/core/admin_home` | `CatalogTab.php`, `Health.php` |
| Salud: precio por unidad sin referencia, sin contenido, de magnitudes distintas o con una referencia cien veces mayor que el contenido; GTIN que no puede existir (también de las variaciones); EAN antiguo distinto del GTIN; sin imagen; sin categoría; categoría principal que ya no es del producto | `wp lachinata catalog health [--format=table\|json\|count]` | `Health.php`, `NormalizeCommand.php` |
| Migración (dentro de `normalize`): categoría principal de Rank Math si el producto sigue en ella; EAN como GTIN si no hay GTIN y el dígito de control cuadra; en las descripciones, subtítulos en negrita en su propia línea a `h3` y `[products skus="…"]` al bloque `lachinata/products`, sin tocar el texto; informe de lo que no se traslada | `wp lachinata catalog normalize` | `Migrate.php`, `NormalizeCommand.php` |
| **Cambios que cuentan** (0.13.1): la fecha del último cambio de los sellos (`tipo`) y de los campos vigilados (ajuste `watched_fields`; de serie, los ingredientes, que llevan alérgenos, trazas y nutrición) en `_lc_catalog_cambios`, y `lachinata/catalog/product_changed`; al dejar de estar publicado, `lachinata/catalog/product_discontinued`. La descripción libre y el stock no cuentan. El blog manda a «Revisar» las entradas que lo mencionan | `updated_post_meta`, `deleted_post_meta`, `set_object_terms`, `transition_post_status` | `Changes.php` |
| **Paquete editorial** (0.14.0): los textos en español de los productos (nombre, descripción corta y larga, etiqueta, título y descripción SEO, texto alternativo de las imágenes, descripción de las variaciones que la tienen) salen como JSON con la huella de cada texto y vuelven con detección de conflictos; nombres cambiados aparte en el informe; `--mark-reviewed` marca «Revisado» (`SourceStatus` del núcleo) lo que entra entero. Sin ingredientes ni nutrición | `wp lachinata catalog export-editorial [--file] [--ids] [--category] [--post-status] [--source-status]`, `import-editorial <archivo> [--dry-run] [--mark-reviewed] [--report]` | `Editorial.php`, `NormalizeCommand.php` |

## Depende de

Ningún módulo. WooCommerce 10. No necesita ACF: si está, conviven y el módulo lee sus valores hasta normalizarlos.

## Hooks que escucha

- `init` (taxonomía y metadatos), la ficha de producto y las variaciones en el panel, los formularios de `product_cat` y `tipo`, `admin_enqueue_scripts` y `admin_notices` (selector de medios y avisos de la normalización).
- Del tema: `lachinata/product/unit_price`, `lachinata/product/tint`, `lachinata/category/tint`, `lachinata/product_card/badges`, `lachinata/product/tabs`, `lachinata/product/seals`, `lachinata/product/details`, `lachinata/product/content`; desde 0.12.2, `lachinata/product_card/marker`, `lachinata/product_card/image_id`, `lachinata/product/main_category`, `lachinata/product/notices`, `lachinata/product/cross_sell` y `lachinata/catalog/categories`.
- Del núcleo: `lachinata/catalog/no_ship_abroad`, `lachinata/core/admin_tabs`, `lachinata/core/admin_home`.
- Los formularios de `product_tag` (tono, imagen y orden).

## Hooks que emite

- `lachinata/catalog/marker_conditions` (0.12.2): las frases del aviso de una clase con marca; las añaden `shipping` y `eta`.
- `lachinata/catalog/product_fields`: final de la pestaña «La Chinata», para los campos de otros módulos.
- Lo demás sale por los huecos del tema (`theme/HOOKS.md`) y por `lachinata/catalog/no_ship_abroad` (`plugin/HOOKS.md`).

## Datos que guarda

- Metadatos de producto y variación: `_lc_contenido`, `_lc_referencia`, `_lc_ingredientes`, `_lc_etiqueta`, `_lc_imagen_descripcion`, `_lc_consumo_preferente`, `_lc_excluir_internacional`; desde 0.12.2, `_lc_catalog_categoria_principal` y `_lc_catalog_imagen_tarjeta`.
- Metadatos de término: `_lc_tint` (`product_cat`), `_lc_icono` (`tipo`); desde 0.12.2, `_lc_catalog_tono`, `_lc_catalog_imagen` y `_lc_catalog_orden` (`product_tag`). Los términos de `tipo` son contenido del sitio.
- Opciones (0.12.2): `lachinata_catalog_store_categories`, `lachinata_catalog_campaigns`, `lachinata_catalog_cross_sell`, `lachinata_catalog_markers` (por slug de categoría y de clase de envío) y el transitorio `lachinata_catalog_health_count` (último recuento de la salud, un día).
- El paquete editorial escribe los campos de WooCommerce, `_lc_etiqueta`, `rank_math_title`, `rank_math_description` y el texto alternativo de los adjuntos (`_wp_attachment_image_alt`), y marca `_lc_source_status`, que es del núcleo, con su utilidad `SourceStatus`.
- Son anteriores a la regla `_lc_<módulo>_*` y se quedan con su nombre (excepción catalogada en `plugin/HOOKS.md`). Las claves de ACF no se tocan nunca.

## REST y API para Odoo

Los metadatos de producto van en la API REST y en la Store API (`show_in_rest`). Nada en el objeto `lachinata` de los pedidos.

## Ajustes y exportación

Desde 0.12.2, cuatro ajustes de tipo lista que viajan en el JSON: `store_categories`, `campaigns`, `cross_sell` y `markers`. Van por slug (de categoría y de clase de envío) para que valgan en otra tienda; `Config` los lee saneados, también cuando llegan de un JSON importado. Los datos de cada producto y término (tonos de etiqueta, categoría principal…) son contenido y no viajan.

## Qué pasa al apagarlo

El tema vuelve a sus valores neutros: sin tintas, sin precio por unidad, sin etiqueta, pestañas ni sellos propios; etiquetas en gris, sin marca de clase ni aviso de refrigerado; todas las categorías raíz en la navegación; venta cruzada «También te puede gustar» con las ventas cruzadas o los más vendidos; la taxonomía `tipo` deja de registrarse (sus términos siguen en la base de datos) y `shipping` deja de ver la exclusión internacional del producto (solo cuentan las clases de envío). Los datos se quedan. «Borrar datos» borra los metadatos de producto y término de arriba (nunca las claves de ACF ni los pedidos), después de descargar el JSON del módulo.

## Pruebas

- `tests/ShopTest.php` (etiquetas con su aspecto y orden, marca y aviso de la clase, categoría principal, imagen de tarjeta, categorías y campañas, venta cruzada), `tests/HealthTest.php` (salud y recuento), `tests/FieldsTest.php` (registro, lectura con la clave de ACF de respaldo), `tests/QuantityTest.php` (cantidad y unidad), `tests/UnitPriceTest.php` (precio por unidad, también por variación), `tests/StorefrontTest.php` (lo que llega al tema por cada hueco), `tests/NormalizeCommandTest.php` (normalización, `--dry-run`, GTIN, `--from-shipping-class`, categoría principal, EAN a GTIN, subtítulos a `h3` y `[products]` al bloque).
- `tests/EditorialTest.php` (paquete: solo lectura, campos vacíos, sin ingredientes, variaciones con descripción; importación, ida y vuelta sin cambios, conflictos, simulación, errores, nombres aparte y «Revisado»).
- e2e: `tests/e2e/catalog.spec.mjs` (tarjeta, opiniones, ChipRow y aviso de refrigerado).
- En cada perfil: `tests/profiles/ProfileBootTest.php`. El módulo solo: `tools/tests/modules-isolated.sh`.

## Huecos conocidos

- Exclusión internacional duplicada (clase «Ocultar internacional» y campo): pendiente de decidir cuál manda; `normalize --from-shipping-class` pasa de la clase al campo.
- `rutina`, `destacamos`, `modo_empleo` y `email_collect` de ACF no se migran (decidido).
- El modo de empleo no está en el paquete editorial: no existe como campo (`modo_empleo` no se migró). Ingredientes y valores nutricionales tampoco: vendrán de la aplicación de La Chinata (`07-traduccion.md`).
- El grupo «Oleoteca» de ACF llegó con `oleotecas` (0.12.0).
- La maquetación antigua de algunas descripciones (`div.row`, `h4` con `span` y estilos en línea) no se toca: el informe de la migración la lista y decide La Chinata.
- El pedido mínimo (21 productos con Min/Max Quantities) llega con el módulo de personalizados; hasta entonces, solo en el informe.
