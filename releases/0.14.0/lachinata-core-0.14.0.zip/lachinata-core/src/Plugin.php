<?php
/**
 * Plugin entry point.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Wires the plugin into WordPress and boots the enabled modules.
 */
final class Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var Plugin|null
	 */
	private static ?Plugin $instance = null;

	/**
	 * Module registry.
	 *
	 * @var ModuleRegistry
	 */
	private ModuleRegistry $modules;

	/**
	 * Version manifest.
	 *
	 * @var Updates\Manifest
	 */
	private Updates\Manifest $manifest;

	/**
	 * Builds the registry and the version manifest client.
	 */
	private function __construct() {
		$this->modules  = new ModuleRegistry();
		$this->manifest = Updates\Manifest::from_constants();
	}

	/**
	 * Returns the shared instance.
	 */
	public static function instance(): Plugin {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * The module registry.
	 */
	public function modules(): ModuleRegistry {
		return $this->modules;
	}

	/**
	 * The version manifest client.
	 */
	public function manifest(): Updates\Manifest {
		return $this->manifest;
	}

	/**
	 * Registers the plugin hooks.
	 */
	public function boot(): void {
		add_action( 'init', array( $this, 'load_textdomain' ) );
		add_action( 'before_woocommerce_init', array( $this, 'declare_woocommerce_compatibility' ) );
		add_action( 'plugins_loaded', array( $this, 'boot_modules' ), 20 );
		( new Updates\Updater( $this->manifest ) )->boot();
		Rest\OrderData::boot();
		Contact::boot();
		Company::boot();
		Robots::boot();
		Mail::boot();
		SourceStatus::boot();

		if ( is_admin() ) {
			Admin\Screen::boot();
			Admin\SourceStatusAdmin::boot();
			VersionCheck::boot();
			Health::boot();
		}

		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			$config = new Cli\ConfigCommand();
			\WP_CLI::add_command( 'lachinata module', Cli\ModuleCommand::class );
			\WP_CLI::add_command( 'lachinata export', array( $config, 'export' ) );
			\WP_CLI::add_command( 'lachinata import', array( $config, 'import' ) );
		}
	}

	/**
	 * Registers the built-in modules and boots the enabled ones.
	 */
	public function boot_modules(): void {
		$this->modules->register( new Modules\Catalog\CatalogModule() );
		$this->modules->register( new Modules\Shipping\ShippingModule() );
		$this->modules->register( new Modules\Eta\EtaModule() );
		$this->modules->register( new Modules\Checkout\CheckoutModule() );
		$this->modules->register( new Modules\Gift\GiftModule() );
		$this->modules->register( new Modules\Odoo\OdooModule() );
		$this->modules->register( new Modules\Notify\NotifyModule() );
		$this->modules->register( new Modules\Shipment\ShipmentModule() );
		$this->modules->register( new Modules\Newsletter\NewsletterModule() );
		$this->modules->register( new Modules\Blocks\BlocksModule() );
		$this->modules->register( new Modules\Tracking\TrackingModule() );
		$this->modules->register( new Modules\Feeds\FeedsModule() );
		$this->modules->register( new Modules\Locale\LocaleModule() );
		$this->modules->register( new Modules\Oleotecas\OleotecasModule() );
		$this->modules->register( new Modules\Content\ContentModule() );

		/**
		 * Fires before the enabled modules boot, so other code can register its own.
		 *
		 * @since 0.2.0
		 *
		 * @param ModuleRegistry $modules Module registry.
		 */
		do_action( 'lachinata/core/register_modules', $this->modules );

		Upgrades::run( $this->modules );

		$this->modules->boot_enabled();
	}

	/**
	 * First activation: enables the default modules.
	 */
	public static function activate(): void {
		if ( false === get_option( ModuleRegistry::OPTION ) ) {
			add_option( ModuleRegistry::OPTION, ModuleRegistry::DEFAULTS );
		}
	}

	/**
	 * Loads the plugin translations.
	 */
	public function load_textdomain(): void {
		load_plugin_textdomain( 'lachinata-core', false, dirname( plugin_basename( LACHINATA_CORE_FILE ) ) . '/languages' );
	}

	/**
	 * Declares compatibility with HPOS and the block checkout.
	 */
	public function declare_woocommerce_compatibility(): void {
		if ( ! class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			return;
		}
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', LACHINATA_CORE_FILE, true );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', LACHINATA_CORE_FILE, true );
	}
}
