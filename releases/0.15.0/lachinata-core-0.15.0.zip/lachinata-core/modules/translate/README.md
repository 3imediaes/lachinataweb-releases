# Módulo `translate`

Sustituye a TranslatePress (`design-system/sistema/07-traduccion.md`). Desde la 0.15.0 (11b): tabla de traducciones, direcciones por idioma, `hreflang`, sitemaps, editor lado a lado, correos en el idioma del pedido y el contrato `Languages` v2. Claude, glosario, memoria, los siete controles, colas, panel y migración desde TranslatePress llegan en la 0.16.0 (11c).

## Qué hace

- **Traducciones como campos de la misma ficha**, nunca copias: un producto es uno solo en todos los idiomas (mismo ID, stock, precio, pedidos y medición). Se guardan en la tabla `{prefijo}lc_translate`: objeto (tipo, subtipo e ID), campo, idioma, texto, huella del español del que sale, estado (`auto`, `edited`, `outdated`), origen (`claude`, `person`, `import`) y fecha. El slug traducido va en la misma tabla, en su columna, con un índice único por idioma.
- **Qué se traduce**: lo declarado en `lachinata/translate/fields`. El módulo trae lo de WordPress, WooCommerce y Rank Math (nombre, descripciones, slug, descripción de cada variación, texto alternativo, etiqueta de los elementos de menú, títulos y descripciones SEO, nombre y descripción de categorías, etiquetas y términos de atributo); cada módulo añade lo suyo (`catalog`, `content`, `oleotecas`). Nunca ingredientes ni valores nutricionales: vendrán de la aplicación de La Chinata, y hasta entonces se ve el español.
- **Una página existe en un idioma solo si está traducida entera**: cada campo obligatorio cuyo español tiene texto, traducido. Si no, no hay dirección en ese idioma: sus enlaces llevan a la española, no sale en `hreflang` ni en el sitemap de ese idioma, y pedirla en `/en/…` lleva a la española con una 302 (con lo que siga: endpoint y parámetros). Las imágenes, los elementos de menú, las variaciones y los términos sin dirección se traducen campo a campo. La home existe siempre (son los bloques de la home).
- **Direcciones**: un subdirectorio por idioma (`/en/`), el español sin prefijo. El idioma lo da la dirección, nunca el navegador ni la IP. La dirección traducida es la española con el slug del objeto traducido y los segmentos que son páginas o términos traducidos (`/tienda/` → `/en/shop/`, `/blog/recetas/x/` → `/en/blog/recipes/y/`); conserva la forma (`.html`). Por dentro, la petición se convierte en la española y la resuelve WordPress (o Permalink Manager); la API REST bajo `/en/wp-json/` conserva sus rutas y responde en inglés. Un objeto pedido con su slug español va a su dirección traducida con una 301. Los endpoints internos de WooCommerce no se traducen.
- **SEO**: `hreflang` entre los idiomas en que existe la página, con `x-default` al español; la canónica de cada idioma es ella misma (WordPress y Rank Math la sacan del enlace permanente, que ya sale traducido); los títulos y descripciones de Rank Math leen el texto traducido; un sitemap por idioma en el índice de Rank Math (`translate-en-sitemap.xml`) o, sin Rank Math, en el de WordPress, solo con lo que existe en ese idioma. `og:locale` y `lang` salen del idioma de la petición.
- **Textos en la página**: títulos, contenido y extractos de las entradas de la consulta (copias: la caché de objetos guarda siempre el español), getters de los productos y variaciones, metadatos declarados, términos, menús y, en correos y en las páginas de pedido recibido y cuenta, los nombres de las líneas del pedido. Las cadenas de interfaz salen de los `.mo` del tema y del plugin (`tools/i18n/`) y de los paquetes de idioma de WordPress y WooCommerce.
- **Editor lado a lado**: en productos, páginas y entradas, una caja «Traducciones» con una pestaña por idioma, el español y la traducción campo a campo, y su estado («Automática», «Editada», «Desfasada: el español cambió», «Sin traducir»); en categorías y términos, debajo del formulario. Cambiar un campo lo deja «Editada» por una persona. Debajo dice si la página existe en ese idioma y, si no, qué falta. No hay edición desde la parte pública. «Volver a traducir» y «Proponer al glosario» llegan con Claude (11c).
- **Cuando cambia el español**, la traducción de ese campo pasa a «Desfasada» y sigue publicada hasta que se traduzca de nuevo; una editada conserva su origen «persona» y nunca se pisa. Borrar un producto o un término borra sus traducciones.
- **Correos en el idioma del pedido**: el pedido guarda el idioma en que se hizo (`_lc_translate_language`) y los correos al comprador salen en él (asunto, textos del tema, nombres de los productos y enlaces); los de la tienda, siempre en el idioma del sitio. Las líneas del pedido guardan los nombres en español, que son los que leen Odoo y el panel.
- **WP-CLI**: `wp lachinata translate set|get|import|export|status|refresh`.

## Depende de

- WooCommerce 10.0 o superior.
- Nada de otros módulos. `catalog`, `content` y `oleotecas` declaran sus campos con `lachinata/translate/fields` si están encendidos.
- Paquetes de idioma de WordPress y WooCommerce de cada idioma (Escritorio → Actualizaciones, o `wp language core install en_GB` y `wp language plugin install woocommerce en_GB`): la salud avisa si falta el de WooCommerce. Sin el de WordPress, los correos no cambian de idioma (WordPress solo cambia a idiomas instalados).

## Hooks que escucha

- `lachinata/languages/service`: sirve `Contracts\Languages` (v2).
- `locale` (prioridad 1), `do_parse_request`, `parse_request`, `template_redirect`, `home_url`, `post_link`, `post_type_link`, `page_link`, `term_link`, `post_type_archive_link`: direcciones por idioma.
- `the_posts`, `the_title`, `get_the_excerpt`, `content_pagination`, `get_post_metadata`, `get_term_metadata`, `get_term`, `get_terms`, `woocommerce_product_get_name`, `woocommerce_product_get_short_description`, `woocommerce_product_get_description`, `woocommerce_product_variation_get_name`, `woocommerce_order_item_get_name`, `wp_setup_nav_menu_item`: textos.
- `wp_head` (`hreflang`), `rank_math/sitemap/providers`, `wp_sitemaps_init`, `rank_math/replacements`, `rank_math/frontend/description`.
- `save_post`, `woocommerce_update_product`, `woocommerce_update_product_variation`, `added_post_meta`, `updated_post_meta`, `deleted_post_meta`, `edited_term`, `added_term_meta`, `updated_term_meta`, `deleted_post`, `delete_term`, `shutdown`: el español que cambia.
- `woocommerce_checkout_create_order`, `woocommerce_store_api_checkout_update_order_meta`, `woocommerce_checkout_create_order_line_item`, `woocommerce_email_classes`, `woocommerce_email_recipient_{id}`, `woocommerce_allow_restoring_email_locale`: correos.
- `add_meta_boxes`, `admin_init`, `{taxonomía}_edit_form`, `edited_{taxonomía}`, `admin_head`: editor. `lachinata/core/admin_tabs` y `admin_post_lachinata_translate_settings`: pestaña.
- `lachinata/source_status/changed`: todavía no (la cola de 11c).

## Hooks que emite

- `lachinata/translate/fields` (filtro): campos traducibles por tipo de objeto. Catálogo en `plugin/HOOKS.md`.
- `lachinata/translate/availability_changed` (acción): cambian los idiomas en que existe un objeto.
- `lachinata/translate/edited` (acción): una persona cambió traducciones en el editor.

## Datos que guarda

- Tabla `{prefijo}lc_translate` (migración 1).
- `_lc_translate_in` (metadato de entrada y de término, una fila por idioma): idiomas en que existe, recalculado al escribir una traducción o cambiar el español.
- `_lc_translate_language` (metadato de pedido): idioma en que se hizo. Lo lee `tracking`.
- Opciones `lachinata_translate_languages` y `lachinata_translate_only_reviewed`; transitorios `lachinata_translate_slugs_{idioma}`.

## REST y API para Odoo

Nada propio. La API REST de WordPress y la Store API responden en el idioma de la dirección (`/en/wp-json/…`). El objeto `lachinata` de los pedidos no cambia; los nombres de las líneas siguen en español.

## Ajustes y exportación

WooCommerce → La Chinata → Traducción: los idiomas (locale, código de la dirección y de `hreflang`, nombre) y «Solo productos, páginas y entradas con el español Revisado» (encendido de serie; lo usará la cola de 11c). Los dos entran en el JSON exportado. Las traducciones no van en el JSON: se exportan aparte con `wp lachinata translate export --language=en_GB`.

## Qué pasa al apagarlo

El contrato `Languages` vuelve a un solo idioma, el del sitio: no hay prefijos, ni `hreflang`, ni sitemaps por idioma, y el selector de `locale` no enseña idiomas. `/en/…` deja de existir. La tabla, los metadatos y los idiomas de los pedidos se conservan; «Borrar datos» borra la tabla y los metadatos de entradas y términos, nunca los de los pedidos.

## Pruebas

- `plugin/modules/translate/tests/TranslateTest.php`: tabla y slugs únicos, cuándo existe una página, direcciones en los dos sentidos (también la API REST bajo `/en/`), una petición a `/en/` con sus textos y `hreflang`, metadatos y términos, el contrato, el editor, el español que cambia, correos e importación.
- `theme/tests/WooCommerceStringsTest.php`: los avisos clásicos dicen «bolsa».
- `tests/e2e/translate.spec.mjs` (perfiles `es` y `all`; en `canarias` y `cz`, sin `/en/`): ficha, categoría, página y receta en inglés, lo no traducido al español, sitemap y `llms.txt`, el selector y la cookie `lc_idioma`, un pedido en inglés con su correo.
- Traducciones de prueba: `tools/fixtures/traducciones-en.json` (`npm run env:seed`).

## Huecos conocidos

- Claude, glosario, memoria, controles, colas, panel, límite de gasto y la migración desde TranslatePress con sus 301 y 410: 11c.
- Textos que viven en opciones de otros módulos (destinos de `locale`, bloques de la home y `PromoBar` de `blocks`, marcas de envío de `catalog`, título de las pasarelas): siguen en español en `/en/` hasta que 11c los traduzca con el panel.
- Atributos de producto propios (no de taxonomía) y textos de la receta fuera del bloque: sin traducir.
- Un producto con un campo obligatorio nuevo en español (una descripción que antes no tenía) deja de existir en inglés hasta que se traduzca.
