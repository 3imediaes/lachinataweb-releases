# API pública de lachinata-core

Lo que leen otros, sean otros módulos, el tema u Odoo: servicios entre módulos, hooks del núcleo y de los módulos, rutas REST y metadatos. Los huecos que pinta el tema están en [`theme/HOOKS.md`](../theme/HOOKS.md). El contrato que hay detrás es [`docs/arquitectura-modulos.md`](../docs/arquitectura-modulos.md).

- **Desde**: versión en la que apareció. **Obsoleto desde**: versión desde la que no debe usarse. Lo obsoleto se mantiene, como alias, al menos una versión menor más (obsoleto en la 0.9 → se puede quitar en la 0.10).
- Un hook nuevo con prefijo `lachinata/` entra aquí o en `theme/HOOKS.md` en el mismo cambio: `npm run check:docs` (CI) falla si falta alguno.
- Los callbacks de los módulos van envueltos (`Hooks`). Para quitar uno, usa `LaChinata\Core\Hooks::remove_filter()` con el mismo callback: el `remove_filter()` de WordPress no lo encuentra.

## Servicios entre módulos

Un módulo no usa clases de otro. Pide el servicio al núcleo, comprueba que existe y sigue sin él si no está.

| Filtro | Servicio | Contrato | Lo sirve | Lo usan | Desde | Obsoleto desde |
| --- | --- | --- | --- | --- | --- | --- |
| `lachinata/notify/service` | `Services::notifier()` | `Contracts\Notifier` (`Notice`, `NoticeResult`) | `notify` | `gift`, `shipment` | 0.8.0 | — |
| `lachinata/newsletter/service` | `Services::newsletter()` | `Contracts\Newsletter` | `newsletter` | (bloque de franquicias, 6f) | 0.8.0 | — |
| `lachinata/shipping/service` | `Services::shipping_rules()` | `Contracts\ShippingRules` (versión 2 desde la 0.11.0: `free_shipping_from()`; versión 3 desde la 0.12.2: `unavailable_message()`, el aviso de la ficha de un producto que no se envía) | `shipping` | `eta`, `locale`, `lachinata_producto_enviable()` | 0.9.0 | — |
| `lachinata/eta/service` | `Services::delivery()` | `Contracts\DeliveryEstimator` | `eta` | `gift` | 0.9.0 | — |
| `lachinata/languages/service` | `Services::languages()` | `Contracts\Languages` (versión 2 desde la 0.15.0: `current()`, `code()`, `available()`, `post_url()`, `term_url()`, `alternates()`, `switch_to()` y `restore()`) | núcleo (`Languages\SiteLanguage`, el idioma del sitio); `translate` (0.15.0) | `feeds`, `content` (`llms.txt`), `locale` (selector y pastilla), `tracking` (idioma de los eventos) | 0.10.0 | — |
| `lachinata/catalog/service` | `Services::product_content()` | `Contracts\ProductContent` | `catalog` | `feeds` | 0.10.0 | — |
| `lachinata/shipment/sources` | `Tracking::of()` | `Contracts\TrackingSource` | núcleo (WooCommerce Shipment Tracking) | `gift`, `shipment` | 0.10.0 | — |
| `lachinata/tracking/sources` | alias de `lachinata/shipment/sources` (el prefijo `lachinata/tracking/` es de la analítica) | `Contracts\TrackingSource` | núcleo | — | 0.8.0 | 0.10.0 |

Utilidades sin estado del núcleo que comparten los módulos: `Shipping\Zones`, `Shipping\Destination`, `Shipping\Package`, `Gtin` (0.12.2: si un GTIN puede existir; `catalog` y `feeds`), `Delivery\Estimate`, `Delivery\Format`, `Phone`, `Sms`, `Orders`, `Mail`, `Contact`, `Company`, `ProductIds`, `GapLog`, `Settings`, `SourceStatus` (0.14.0: estado del español, «Pendiente» o «Revisado», de productos, páginas y entradas; `catalog` lo marca al importar el paquete editorial).

Las traducciones viven en la tabla propia de `translate` (`{prefijo}lc_translate`), que nadie más lee: los demás preguntan a `Services::languages()`.

## Núcleo

| Hook | Tipo | Para qué | Desde | Obsoleto desde |
| --- | --- | --- | --- | --- |
| `lachinata/core/register_modules` `( ModuleRegistry $modules )` | acción | Registrar módulos propios antes del arranque | 0.2.0 | — |
| `lachinata/core/admin_tabs` `( array $tabs )` | filtro | Pestañas de WooCommerce → La Chinata (cada módulo añade la suya) | 0.3.0 | — |
| `lachinata/core/admin_home` | acción | Arriba de la portada de WooCommerce → La Chinata: un resumen corto de un módulo con enlace a su pantalla (`catalog`: «Salud del catálogo: N avisos»). Nunca un aviso global del panel | 0.12.2 | — |
| `lachinata/core/config_imported` `( ImportPlan $plan )` | acción | Después de escribir una importación de configuración | 0.3.0 | — |
| `lachinata/core/releases_url` `( string $url )` | filtro | URL base de la distribución de versiones (un espejo o una copia local para pruebas) | 0.3.2 | — |
| `lachinata/robots/noindex` `( bool $noindex )` | filtro | La página no se indexa (sí se sigue). El núcleo lo lleva a `wp_robots` y a las directivas de Rank Math, que quita todos los filtros de `wp_robots`. Lo usan el tema (página 2 de opiniones) y `content` (sección filtrada por producto) | 0.13.0 | — |
| `lachinata/core/docs_url` `( string $base )` | filtro | Dónde se leen las guías de uso del panel (de serie, `guias/` del sitio público de versiones, que publica cada release desde `docs/guias/`) | 0.10.0 | — |
| `lachinata/core/module_failed` `( string $module, string $where, Throwable $error )` | acción | Un módulo ha fallado y queda apagado el resto de la petición | 0.9.0 | — |
| `lachinata/core/data_deleted` `( Module $module )` | acción | Se han borrado los datos de un módulo («Borrar datos» o `wp lachinata module delete-data`) | 0.9.0 | — |
| `lachinata/rest/order` `( array $data, WC_Order $order )` | filtro | El objeto `lachinata` del pedido en la API REST: cada módulo rellena su clave; no se añaden ni se quitan claves (`docs/api-odoo.md`) | 0.6.1 | — |
| `lachinata/order/carrier` `( ?string $carrier, int $instance_id, WC_Order $order )` | filtro | Transportista de un pedido según su instancia de envío (`odoo`: mapa instancia → transportista) | 0.7.0 | — |
| `lachinata/shipping/destination` `( ?array $destination )` | filtro | Destino del visitante en páginas en caché (`locale` lo rellena desde la cookie `lc_destino` cuando la caché varía por ella) | 0.4.0 | — |
| `lachinata/shipping/changed` | acción | Ha cambiado la configuración de envíos o plazos: olvidar decisiones y tarifas memorizadas | 0.9.0 | — |
| `lachinata/product_ids/id` `( string $id, WC_Product $product, string $destination )` | filtro | El ID de un producto para un destino (`google`, `meta`, `ga4`) cuando el catálogo usa uno propio que ningún preajuste da (WooCommerce → La Chinata → IDs de producto) | 0.10.0 | — |
| `lachinata/source_status/post_types` `( string[] $post_types )` | filtro | Tipos de contenido cuyo texto en español tiene estado («Pendiente» o «Revisado»): productos, páginas y entradas | 0.14.0 | — |
| `lachinata/source_status/changed` `( int $post_id, string $status, string $previous )` | acción | El español de un producto, página o entrada cambia de estado, lo escriba quien lo escriba (caja del editor, acción en lote, REST, paquete editorial). `translate` pondrá en la cola lo que pase a «Revisado» | 0.14.0 | — |
| `lachinata/catalog/no_ship_abroad` `( bool $excluded, int $product_id )` | filtro | Si un producto no se envía fuera de España (`catalog`, `_lc_excluir_internacional`) | 0.9.0 | — |
| `lachinata/shipping/only_to` `( string[] $places, int $product_id )` | filtro | Lugares a los que se envía un producto por sí solo, además de los de su clase (`shipping`: «Solo se envía a», `_lc_shipping_solo_a`); `Shipping\Package::product_entry()` lo pone en `only` | 0.12.2 | — |

## Módulos

| Hook | Tipo | Lo dispara | Lo escucha | Para qué | Desde | Obsoleto desde |
| --- | --- | --- | --- | --- | --- | --- |
| `lachinata/catalog/product_fields` `( ?WC_Product $product )` | acción | `catalog` | `feeds` | Final de la pestaña «La Chinata» del producto, para los campos de otros módulos (cada uno guarda los suyos) | 0.10.0 | — |
| `lachinata/catalog/marker_conditions` `( string[] $sentences, string $class, WC_Product $product )` | filtro | `catalog` | `shipping` (destinos, precio y envío gratis de la clase), `eta` (días de salida o de entrega) | Frases del aviso de una clase de envío con marca en la ficha («Solo a España peninsular; gratis desde 60 €. Sale de lunes a miércoles.»), en texto plano | 0.12.2 | — |
| `lachinata/catalog/product_changed` `( int $product_id, string $what, string $date )` | acción | `catalog` | `content` (las entradas que lo mencionan, revisadas antes del cambio, pasan a «Revisar») | Cambian los sellos o un campo vigilado del producto (de serie, los ingredientes, con alérgenos, trazas y nutrición); `$what` para personas («sus ingredientes») | 0.13.1 | — |
| `lachinata/catalog/product_discontinued` `( int $product_id, string $date )` | acción | `catalog` | `content` (a «Revisar»; su enlace ya sale como texto) | El producto deja de estar publicado (privado, borrador o papelera); agotado no cuenta | 0.13.1 | — |
| `lachinata/oleotecas/closed` `( int $post_id, string $slug, string $name )` | acción | `oleotecas` | `content` (las entradas que la mencionan pasan a «Revisar»; el aviso sale solo) | Una oleoteca cierra para siempre (el día de su fecha de cierre) | 0.13.1 | — |
| `lachinata/oleotecas/status` `( ?array $status, string $slug )` | filtro | `content` | `oleotecas` | Lo que sabe el módulo de la oleoteca de un slug: `exists`, `closed`, `name`, `subject` («la oleoteca La Chinata Vitoria», 0.13.2), `plural` (0.13.2), `url`, `finder` (null sin el módulo) | 0.13.1 | — |
| `lachinata/oleotecas/slug_of` `( string $slug, string $url )` | filtro | `content` | `oleotecas` | El slug de una oleoteca a partir de un enlace a su ficha, o `''` | 0.13.1 | — |
| `lachinata/oleotecas/names` `( array $names )` | filtro | `content` | `oleotecas` | Nombre corto de cada oleoteca publicada por slug, cerradas también (las noticias de aperturas) | 0.13.1 | — |
| `lachinata/content/published_in` `( bool $published, WP_Post $post, string $language )` | filtro | `content` | — | Si una entrada está publicada en un idioma (`llms.txt`). De serie, lo que dice `Languages::available()` (0.15.0): con `translate`, solo cuando está traducida entera; sin él, solo el idioma del sitio | 0.13.1 | — |
| `lachinata/translate/fields` `( array $fields )` | filtro | `translate` | `catalog` (etiqueta de la tarjeta, sellos), `content` («En pocas palabras», fuentes, secciones), `oleotecas` (texto propio, zonas y sus preguntas, servicios) | Campos traducibles por tipo de objeto (`post:product`, `term:lc_seccion`…): dónde está el español (columna, metadato), formato, si la página lo necesita para existir en un idioma y qué se ve sin traducción. Ni ingredientes ni nutrición | 0.15.0 | — |
| `lachinata/translate/availability_changed` `( string $type, int $id, string[] $languages )` | acción | `translate` | — | Cambian los idiomas en que existe un producto, página, entrada o término (sitemaps, cachés) | 0.15.0 | — |
| `lachinata/translate/edited` `( string $type, int $id, int $changed )` | acción | `translate` | — (la memoria de traducción de 11c) | Una persona cambia traducciones en el editor | 0.15.0 | — |
| `lachinata/blocks/product_ids` `( int[] $ids )` | filtro | `blocks` | `locale` (quita los que no se envían al destino) | Productos del bloque `lachinata/products`, en orden | 0.12.2 | — |
| `lachinata/checkout/after_shipping` | acción | `checkout` | — (hoy los módulos registran sus campos en `woocommerce_init`) | Registrar campos y scripts de los *slots* del checkout de bloques | 0.5.0 | — |
| `lachinata/checkout/address_lookup` `( ?AddressLookup $lookup )` | filtro | `checkout` | — | Servicio de autocompletado de dirección, consultado desde el servidor | 0.5.0 | — |
| `lachinata/checkout/numeric_postcodes` `( string[] $countries )` | filtro | `checkout` | — | Países con códigos postales solo numéricos (teclado numérico) | 0.5.0 | — |
| `lachinata/checkout/no_state_countries` `( string[] $countries )` | filtro | `checkout` | — | Países donde el checkout oculta la provincia | 0.5.1 | — |
| `lachinata/checkout/invoice_details` `( WC_Order $order )` | acción | `checkout` | — | Un pedido recibe sus datos de factura de empresa (`_lc_empresa`, `_lc_nif`) | 0.6.0 | — |
| `lachinata/shipping/rate_providers` `( array $providers )` | filtro | `shipping` | — | Proveedores de tarifa en vivo (un conector nuevo se registra aquí) | 0.4.0 | — |
| `lachinata/shipping/octolize_method_ids` `( string[] $ids )` | filtro | `shipping` | — | Métodos cuyas tarifas toma el adaptador de Octolize | 0.4.0 | — |
| `lachinata/shipping/conflicting_plugins` `( string[] $patterns )` | filtro | `shipping` | — | Fragmentos de nombre de plugins que se solapan con los módulos de envío (aviso en el panel) | 0.4.0 | — |
| `lachinata/shipping/simulation_eta` `( string $text, int $instance_id, Package $package, WC_Shipping_Zone $zone )` | filtro | `shipping` | `eta` | Plazo de una instancia en el probador de envíos | 0.4.0 | — |
| `lachinata/shipping/destination_label` `( string $name, array $destination )` | filtro | `shipping` | `locale` (la etiqueta del destino: «España · Península») | Nombre del destino del visitante en los textos de envío gratis de la PromoBar y la UspBar (`{destino}`); de serie, el país o la provincia de WooCommerce | 0.11.0 | — |
| `lachinata/eta/rest_destination` `( ?array $destination, string $code )` | filtro | `eta` | (`locale`, 8) | Destino del endpoint `/lachinata/v1/eta` desde su parámetro `destino` | 0.4.0 | — |
| `lachinata/delivery/from_dispatch` `( ?array $dates, WC_Order $order, ?int $shipped )` | filtro | `shipment` | `eta` | Fechas de entrega de un pedido que salió un día concreto | 0.8.0 | — |
| `lachinata/notify/whatsapp_provider` `( WhatsAppProvider $provider )` | filtro | `notify` | — | Proveedor de WhatsApp de los avisos | 0.8.0 | — |
| `lachinata/notify/sms_provider` `( SmsProvider $provider )` | filtro | `notify` | — | Proveedor de SMS (otro en lugar de OVH) | 0.8.0 | — |
| `lachinata/notify/template` `( string $name, string $kind, bool $link )` | filtro | `notify` | — | Plantilla de WhatsApp de un tipo de aviso (para tipos nuevos) | 0.8.0 | — |
| `lachinata/notify/status` `( WC_Order $order, string $kind, string $state, string $reason )` | acción | `notify` | — | Un WhatsApp cambia de estado (enviado, entregado, leído, fallido) | 0.8.0 | — |
| `lachinata/notify/fallback` `( WC_Order $order, string $kind, NoticeResult $result )` | acción | `notify` | `gift`, `shipment` | Un aviso que WhatsApp no entregó salió por SMS (o volvió a fallar) | 0.8.0 | — |
| `lachinata/order/carrier_unknown` `( int $instance_id, WC_Order $order )` | acción | `gift`, `shipment` | `odoo` | Un aviso salió sin transportista: hueco del mapa instancia → transportista | 0.8.0 | — |
| `lachinata/shipment/delivery_events` `( array $sources )` | filtro | `shipment` | — | De dónde sale el día del reparto (API de un transportista); hoy ninguna | 0.8.0 | — |
| `lachinata/shipment/out_for_delivery` `( WC_Order $order )` | acción | `shipment` | — | Un pedido sale hoy a reparto | 0.8.0 | — |
| `lachinata/newsletter/provider` `( Provider $provider )` | filtro | `newsletter` | — | Proveedor de newsletter (Brevo u otro en lugar de Mailchimp) | 0.8.0 | — |
| `lachinata/newsletter/mailchimp_plugin` `( bool $active )` | filtro | `newsletter` | — | Si Mailchimp for WooCommerce recoge el consentimiento del checkout | 0.8.0 | — |
| `lachinata/tracking/services` `( array $services )` | filtro | `tracking` | — | Servicios que ponen cookies o cargan scripts que esperan al consentimiento: id, nombre, quién, empresa, categoría (`necessary`, `analytics`, `marketing`), si está configurado, cookies (nombre, quién, para qué, duración), `handles` de scripts, modo de consentimiento de Google, política y Marco de Privacidad UE-EE. UU. De ellos salen el aviso, la versión de la política y la tabla de cookies | 0.10.0 | — |
| `lachinata/tracking/event` `( string $name, array $params )` | acción | cualquier módulo | `tracking` | Un evento de medición para la página siguiente (`generate_lead` del formulario de franquicias, por ejemplo). Nombres de GA4; sin datos personales. Solo se guarda con consentimiento | 0.10.0 | — |
| `lachinata/tracking/queued` `( array $job )` | acción | `tracking` | — | Una petición a GA4 o Meta entra en la cola (`to`, `name`, `body`, sin credenciales), para pruebas y depuración | 0.10.0 | — |
| `lachinata/newsletter/subscribed` `( string $source )` | acción | `newsletter` | `tracking` (sign_up, Subscribe) | Alta en la newsletter pendiente de confirmar (`footer`); no lleva el correo | 0.10.0 | — |
| `lachinata/tracking/banner` `( bool $applies )` | filtro | `tracking` | — | Si una página lleva el aviso y los scripts de consentimiento | 0.10.0 | — |
| `lachinata/tracking/graph_version` `( string $version )` | filtro | `tracking` | — | Versión de la Graph API de Meta (API de conversiones) | 0.10.0 | — |
| `lachinata/email/frame` `( bool $frame )` | filtro | `gift`, `shipment` | tema | Si el tema pinta el marco de los correos (ver `theme/HOOKS.md`) | 0.8.0 | — |
| `lachinata/locale/changed` | acción | `locale` | `locale` | Han cambiado los destinos o las otras tiendas (se recalcula el catálogo por destino) | 0.11.0 | — |
| `lachinata/oleotecas/geocoder` `( Geocoder $geocoder )` | filtro | `oleotecas` | — | El geocodificador del módulo (interfaz `Geocoder`): otro proveedor u otro doble de pruebas. De serie, Nominatim con la URL y el contacto de los ajustes | 0.12.0 | — |

## API REST

| Ruta o clave | Módulo | Qué es | Desde | Obsoleto desde |
| --- | --- | --- | --- | --- |
| Objeto `lachinata` de `GET /wc/v3/orders/<id>` | núcleo y módulos | Lo que lee Odoo: `version`, `invoice`, `newsletter`, `delivery`, `shipping`, `gift`, `shipment`. Contrato completo en `docs/api-odoo.md` | 0.6.1 | — |
| `lachinata_invoice` de `GET /wc/v3/orders/<id>` | `checkout` | Empresa y NIF en la raíz del pedido, alias de `lachinata.invoice` | 0.5.1 | 0.6.1 |
| `GET /lachinata/v1/eta` | `eta` | Fecha de entrega de la ficha y la cuenta atrás, según destino | 0.4.0 | — |
| `GET /lachinata/v1/address/search` y `/address/select` | `checkout` | Autocompletado de dirección desde el servidor (solo con proveedor) | 0.5.0 | — |
| `POST /lachinata/v1/checkout/gap` | `checkout` | El script del checkout anota un hueco de configuración | 0.5.0 | — |
| `GET`/`POST /lachinata/v1/notify/whatsapp` | `notify` | Webhook de Meta: verificación y estados de los mensajes (firmado) | 0.8.0 | — |
| `POST /lachinata/v1/event` | `tracking` | Lo que el checkout (sin etiquetas de terceros) pide enviar desde el servidor: `begin_checkout`, `add_shipping_info`, `add_payment_info`, `add_to_cart` (API de conversiones, con el `event_id` del píxel) y los `lc_*` del embudo. Pública: solo eventos y parámetros conocidos, productos rehechos desde el carrito, consentimiento de la cookie y 60 por visitante cada 10 minutos | 0.10.0 | — |
| `POST /lachinata/v1/consent` | `tracking` | Prueba de una elección del aviso de cookies: identificador aleatorio, versión, opciones y forma (sin datos personales). Pública por naturaleza: valida cada campo y la versión vigente | 0.10.0 | — |
| `GET`/`POST /lachinata/v1/locale` | `locale` | `GET`: destino sugerido por la ubicación (`sugerir=1`) y umbral de envío gratis de un destino (`destino=ES-IB`: `threshold.value`, precio en la moneda de la tienda o `null`). `POST`: guarda un destino de esta tienda (el selector cerrado sin elegir). Pública: solo destinos configurados, Origin o Referer de este sitio, sin caché | 0.11.0 | — |
| `GET /lachinata/v1/oleotecas` | `oleotecas` | Las tiendas en forma resumida (el documento del buscador, `version` 1): con `?v=<hash>`, un año de caché; CORS solo para los dominios cliente de los ajustes. La misma copia está en `uploads/lachinata-oleotecas/oleotecas.<hash>.json`. Desde 0.12.1, también `lang` (idioma del sitio) y `finder` (URL del buscador), que leen las tiendas cliente; en una tienda cliente la ruta no existe | 0.12.0 | — |
| `GET /lachinata/v1/oleotecas/<slug>` | `oleotecas` | Una tienda completa: horario, especiales, fotos, redes, texto y favoritos (ID local y SKU). Nunca el correo | 0.12.0 | — |
| `GET /lachinata/v1/oleotecas/geocode?q=` | `oleotecas` | Coordenadas de un sitio que no está en nuestros datos, desde el servidor (caché, una petición por segundo al proveedor, 20 búsquedas cada 10 minutos por visitante; sin límite para quien edita) | 0.12.0 | — |
| `GET`, `PUT /lachinata/v1/oleotecas/partner/<slug>` | `oleotecas` | API de socios (el panel de franquicias): horario semanal, horarios especiales y cierre temporal de una tienda, nada más. `Authorization: Bearer <token>` (WooCommerce → La Chinata → Oleotecas), `X-LC-Actor` (correo de quien cambia) para escribir, `ETag` e `If-Match` opcional (412), 120 peticiones cada 10 minutos por token (429 con `Retry-After`). Contrato con ejemplos en `docs/guias/oleotecas.md`. Solo en el sitio maestro | 0.12.1 | — |
| `GET /lachinata/v1/oleotecas/log/<id>` | `oleotecas` | El registro de cambios de horario de una tienda, para el panel del editor (quien puede editarla) | 0.12.1 | — |
| Datos de la Store API `lachinata-shipping` (bolsa) y `lachinata-gift` (checkout) | `shipping`, `gift` | Motivo de «sin envío», envío gratis y productos que no viajan; el regalo del checkout | 0.5.0 | — |

## En la página

Atributos que un módulo pinta para que otro los lea en el navegador, sin usar sus clases.

| Atributo | Lo pinta | Lo lee | Qué es | Desde | Obsoleto desde |
| --- | --- | --- | --- | --- | --- |
| `data-lc-promo` (en `.lc-hero-block` y `.lc-campaign`) | `blocks` | `tracking` (view_promotion, select_promotion) | JSON con `promotion_id`, `promotion_name`, `creative_name` y `creative_slot` | 0.10.0 | — |
| `data-lc-destino`, `data-lc-locale-pending` (en `<html>`), `data-lc-no` (en `.lc-card`) | `locale` | `locale` (estilo del `<head>`), `tracking` (consent.js espera a `lachinata:locale:done` mientras está `data-lc-locale-pending`) | Destino elegido, primera visita sin elegir y destinos donde no se envía una tarjeta | 0.11.0 | — |
| `data-lc-consent` (en `<script type="text/plain">`) | `tracking` | `tracking` (consent.js) | Script en espera de la categoría (`analytics`, `marketing`) | 0.10.0 | — |

## Metadatos

Los módulos guardan con el prefijo `_lc_`. Los nuevos siguen `_lc_<módulo>_*`. Los anteriores a la regla se quedan con su nombre, porque Odoo y el tema los leen: son excepciones catalogadas aquí con su dueño. Lo estable para Odoo es el objeto `lachinata`, no los metadatos en bruto. «Borrar datos» borra los de producto y término de un módulo apagado; los de pedido, nunca.

| Clave | Dónde | Dueño | La leen también | Convención | Desde | Obsoleto desde |
| --- | --- | --- | --- | --- | --- | --- |
| `_lc_contenido`, `_lc_referencia`, `_lc_ingredientes`, `_lc_etiqueta`, `_lc_imagen_descripcion`, `_lc_consumo_preferente` | producto | `catalog` | tema (por filtros), Store API | excepción (anterior a la regla) | 0.2.0 | — |
| `_lc_excluir_internacional` | producto | `catalog` | `shipping` (por `lachinata/catalog/no_ship_abroad`) | excepción | 0.2.0 | — |
| `_lc_tint` | término de `product_cat` | `catalog` | tema (por filtros) | excepción | 0.2.0 | — |
| `_lc_icono` | término de `tipo` | `catalog` | tema (por filtros) | excepción | 0.2.0 | — |
| `_lc_catalog_categoria_principal`, `_lc_catalog_imagen_tarjeta` | producto | `catalog` | tema (por `lachinata/product/main_category` y `lachinata/product_card/image_id`), REST de WordPress | `_lc_catalog_*` | 0.12.2 | — |
| `_lc_catalog_tono`, `_lc_catalog_imagen`, `_lc_catalog_orden` | término de `product_tag` | `catalog` | tema (por `lachinata/product_card/badges`), REST de WordPress | `_lc_catalog_*` | 0.12.2 | — |
| `_lc_shipping_solo_a` | producto | `shipping` | `locale` (por las reglas de envío: catálogo por destino y aviso de la ficha) | `_lc_shipping_*` | 0.12.2 | — |
| `_lc_live` | línea de envío del pedido y tarifa | `shipping` | `eta`, API REST | excepción | 0.4.0 | — |
| `_lc_eta` | línea de envío del pedido y tarifa | `eta` | `gift` (sin `eta`), API REST | excepción | 0.4.0 | — |
| `_lc_empresa`, `_lc_nif` | pedido | `checkout` | Odoo (también en `lachinata.invoice`) | excepción | 0.5.1 | — |
| `_lc_tarjeta` | pedido | `checkout` | tema (por `lachinata/order/payment_label`) | excepción | 0.8.1 | — |
| `_lc_account`, `_lc_account_at` | pedido | `checkout` | — | excepción | 0.5.1 | — |
| `_lc_newsletter_optin` | pedido | `newsletter` (`checkout` hasta la 0.8) | Odoo (en `lachinata.newsletter`) | excepción | 0.6.0 | — |
| `_lc_regalo`, `_lc_regalo_para`, `_lc_regalo_mensaje`, `_lc_regalo_de`, `_lc_regalo_aviso`, `_lc_regalo_contacto`, `_lc_regalo_consentimiento`, `_lc_regalo_avisado`, `_lc_regalo_contacto_borrado` | pedido | `gift` | `shipment` (`_lc_regalo`: un regalo nunca recibe el WhatsApp del comprador), Odoo (en `lachinata.gift`) | excepción | 0.7.0 | — |
| `_lc_gift_erase_at` | pedido | `gift` | — (el barrido diario de borrados) | `_lc_gift_*` | 0.9.0 | — |
| `_lc_regalo_enlace` | pedido | `notify` (enlace corto de la 0.7) | — | excepción | 0.7.0 | 0.8.0 |
| `_lc_notify`, `_lc_notify_ref` | pedido | `notify` | — | `_lc_notify_*` | 0.8.0 | — |
| `_lc_enlace` | pedido | `notify` | — | excepción | 0.8.0 | — |
| `_lc_feeds_exclude`, `_lc_feeds_campaign` | producto | `feeds` | — («No enviar a los feeds» y la campaña de una etiqueta personalizada) | `_lc_feeds_*` | 0.10.0 | — |
| `_lc_feeds_google_category` | término de `product_cat` | `feeds` | — (categoría de Google, heredada por las subcategorías) | `_lc_feeds_*` | 0.10.0 | — |
| `_lc_tracking_context` | pedido | `tracking` | — (consentimiento e IDs de GA4 y Meta del checkout, para los envíos del servidor) | `_lc_tracking_*` | 0.10.0 | — |
| `_lc_tracking_sent` | pedido | `tracking` | — (qué eventos del pedido ya salieron: la compra una sola vez, el reembolso) | `_lc_tracking_*` | 0.10.0 | — |
| `_lc_tracking_review` | página (política de cookies) | `tracking` | — (aviso en la salud hasta marcarla como revisada) | `_lc_tracking_*` | 0.10.0 | — |
| `_lc_shipment_whatsapp`, `_lc_shipment_notified`, `_lc_shipment_out_for_delivery` | pedido | `shipment` | Odoo (en `lachinata.shipment`) | `_lc_shipment_*` | 0.8.0 | — |
| `_lc_locale_destination` | usuario | `locale` | — (el destino elegido; al iniciar sesión vuelve a la cookie) | `_lc_locale_*` | 0.11.0 | — |
| `_lc_oleotecas_name`, `_lc_oleotecas_address`, `_lc_oleotecas_lat`, `_lc_oleotecas_lng`, `_lc_oleotecas_timezone`, `_lc_oleotecas_phone`, `_lc_oleotecas_whatsapp`, `_lc_oleotecas_email`, `_lc_oleotecas_web`, `_lc_oleotecas_social`, `_lc_oleotecas_hours`, `_lc_oleotecas_special`, `_lc_oleotecas_photos`, `_lc_oleotecas_text`, `_lc_oleotecas_favorites` | entrada `oleoteca` | `oleotecas` | REST de WordPress (`meta`, para el panel del editor) | `_lc_oleotecas_*` | 0.12.0 | — |
| `_lc_oleotecas_migrated` | entrada `oleoteca` | `oleotecas` | — (fecha y versión de la migración desde ACF; con ella, la migración no la vuelve a tocar sin `--force`) | `_lc_oleotecas_*` | 0.12.0 | — |
| `_lc_oleotecas_log` | entrada `oleoteca` | `oleotecas` | — (registro de cambios del horario, los especiales y el cierre temporal: autor, origen, fecha, antes y después; los 100 últimos) | `_lc_oleotecas_*` | 0.12.1 | — |
| `_lc_oleotecas_text`, `_lc_oleotecas_faq`, `_lc_oleotecas_group` | término de `lc_oleoteca_zona` | `oleotecas` | REST de WordPress | `_lc_oleotecas_*` | 0.12.0 | — |
| `_lc_content_formato`, `_lc_content_resumen`, `_lc_content_revisado`, `_lc_content_fuentes` | entrada | `content` | REST de WordPress (`meta`, para el panel del editor) | `_lc_content_*` | 0.13.0 | — |
| `_lc_content_receta`, `_lc_content_producto`, `_lc_content_minutos`, `_lc_content_palabras` | entrada | `content` | — (índice de la receta del bloque y de las palabras, que se reescribe al guardar) | `_lc_content_*` | 0.13.0 | — |
| `_lc_content_clics`, `_lc_content_revisar` | entrada | `content` | — (clics de Search Console para «Lo más leído»; motivos para revisar la entrada) | `_lc_content_*` | 0.13.0 | — |
| `_lc_content_categoria`, `_lc_content_orden` | término de `lc_seccion` | `content` | — (categoría de productos de la sección y su orden en la revista) | `_lc_content_*` | 0.13.0 | — |
| `_lc_content_menciona`, `_lc_content_oleoteca` | entrada | `content` | — (índice de los productos y las oleotecas que menciona; se reescribe al guardar) | `_lc_content_*` | 0.13.1 | — |
| `_lc_content_llms` | entrada | `content` | REST de WordPress (`fijar` o `excluir` en `llms.txt`) | `_lc_content_*` | 0.13.1 | — |
| `_lc_content_poda`, `_lc_content_impresiones`, `_lc_content_entrantes`, `_lc_content_destino` | entrada | `content` | — (decisión de la revisión del archivo, impresiones de Search Console, enlaces internos entrantes y destino por ID de una entrada «Retirada») | `_lc_content_*` | 0.13.1 | — |
| `_lc_catalog_cambios` | producto | `catalog` | — (fecha del último cambio de cada campo vigilado y de los sellos) | `_lc_catalog_*` | 0.13.1 | — |
| `_lc_oleotecas_closed`, `_lc_oleotecas_closed_at` | entrada `oleoteca` | `oleotecas` | REST de WordPress (`closed`, la fecha de cierre definitivo; `closed_at`, cuándo se fijó, para los tokens) | `_lc_oleotecas_*` | 0.13.1 | — |
| `_lc_source_status` | producto, página, entrada | núcleo (`SourceStatus`) | `catalog` (lo marca con `--mark-reviewed` del paquete editorial), REST de WordPress (`meta`); `translate` (la cola de 11c) | núcleo | 0.14.0 | — |
| `_lc_translate_in` | producto, página, entrada, término (una fila por idioma) | `translate` | — (idiomas en que existe, para los sitemaps y las listas) | `_lc_translate_*` | 0.15.0 | — |
| `_lc_translate_language` | pedido | `translate` | `tracking` (idioma de la compra y del reembolso) | `_lc_translate_*` | 0.15.0 | — |
| `_wc_shipment_tracking_items` | pedido | WooCommerce Shipment Tracking (lo escribe Odoo) | núcleo (`Tracking`), `gift`, `shipment` | ajena | 0.7.0 | — |

Opciones: `lachinata_<módulo>_*` para cada módulo (ajustes, configuración, registro de huecos `lachinata_<módulo>_gaps`, versión de sus datos `lachinata_<módulo>_schema`) y `lachinata_core_*` para el núcleo. Entran en el JSON exportado los ajustes con `export` y lo que devuelve `export_data()` de cada módulo; las credenciales, nunca.

## Clases movidas al núcleo (0.9.0)

| Antes | Ahora | Obsoleto desde | Se quita en |
| --- | --- | --- | --- |
| `Modules\Eta\Estimate` | `Delivery\Estimate` | 0.9.0 | 0.10.0 |
| `Modules\Eta\Format` | `Delivery\Format` | 0.9.0 | 0.10.0 |
| `Modules\Shipping\Package` | `Shipping\Package` | 0.9.0 | 0.10.0 |
| `Modules\Shipping\Destination` | `Shipping\Destination` | 0.9.0 | 0.10.0 |
