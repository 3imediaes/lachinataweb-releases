<?php
/**
 * HTML of the editorial blocks.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Blocks;

defined( 'ABSPATH' ) || exit;

/**
 * Each block prints the markup of its piece of the system, the same classes the theme's
 * patterns and templates use (`lc-hero-block`, `lc-tiles` + `lc-tile`, `lc-campaign`,
 * `lc-usp`, `lc-history`, `lc-quote-block`), so the theme dresses it (theme.css,
 * components.css from bundle.css). The content is the block's attributes: it survives a
 * change of theme. Texts are escaped here.
 */
final class Render {

	/**
	 * Tints of the system a block may take (tokens.json).
	 */
	public const TINTS = array( 'cream', 'cosmetica', 'aceites', 'gourmet', 'regalos', 'hogar' );

	/**
	 * A text attribute, trimmed.
	 *
	 * @param array<string, mixed> $attributes Attributes.
	 * @param string               $key        Key.
	 */
	private static function text( array $attributes, string $key ): string {
		return trim( (string) ( $attributes[ $key ] ?? '' ) );
	}

	/**
	 * Icon of the theme's sprite (Icon of the bundle).
	 *
	 * @param string $name Icon name.
	 * @param bool   $small Small size.
	 */
	public static function icon( string $name, bool $small = false ): string {
		return sprintf(
			'<svg class="lc-icon%1$s" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><use href="#lc-icon-%2$s"></use></svg>',
			$small ? ' lc-icon--sm' : '',
			esc_attr( sanitize_key( $name ) )
		);
	}

	/**
	 * Button of the bundle (`lc-btn`), primary or secondary, with the arrow.
	 *
	 * @param string $text      Text.
	 * @param string $url       URL.
	 * @param bool   $secondary Secondary.
	 */
	public static function button( string $text, string $url, bool $secondary = false ): string {
		if ( '' === $text || '' === $url ) {
			return '';
		}
		return sprintf(
			'<a class="lc-btn button%1$s" href="%2$s">%3$s%4$s</a>',
			$secondary ? ' lc-btn--secondary' : '',
			esc_url( $url ),
			esc_html( $text ),
			self::icon( 'arrow-right' )
		);
	}

	/**
	 * Hero: eyebrow, headline in Recoleta (or a campaign figure in SantElia), lead, button and
	 * photo, on a tint.
	 *
	 * @param array<string, mixed> $attributes Attributes.
	 */
	public static function hero( array $attributes ): string {
		$tint     = in_array( $attributes['tint'] ?? '', self::TINTS, true ) ? (string) $attributes['tint'] : 'cream';
		$campaign = ! empty( $attributes['campaign'] );
		$size     = 'h1' === ( $attributes['size'] ?? '' ) ? 'editorial-h1' : 'editorial-display';
		$image    = (int) ( $attributes['imageId'] ?? 0 );
		$parts    = '';
		if ( '' !== self::text( $attributes, 'eyebrow' ) ) {
			$parts .= '<p class="eyebrow lc-hero-block__eyebrow">' . esc_html( self::text( $attributes, 'eyebrow' ) ) . '</p>';
		}
		if ( '' !== self::text( $attributes, 'title' ) ) {
			$parts .= sprintf( '<h1 class="%1$s">%2$s</h1>', $campaign ? 'campaign' : $size, esc_html( self::text( $attributes, 'title' ) ) );
		}
		if ( '' !== self::text( $attributes, 'lead' ) ) {
			$parts .= '<p class="editorial-lead">' . esc_html( self::text( $attributes, 'lead' ) ) . '</p>';
		}
		$parts .= self::button( self::text( $attributes, 'ctaText' ), self::text( $attributes, 'ctaUrl' ) );
		$media  = $image > 0 ? '<figure class="lc-hero-block__media">' . wp_get_attachment_image(
			$image,
			'large',
			false,
			array(
				'loading'       => 'eager',
				'fetchpriority' => 'high',
				'sizes'         => '(min-width: 1024px) 58vw, 100vw',
			)
		) . '</figure>' : '';
		return sprintf(
			'<section class="lc-hero-block lc-tile--%1$s"%4$s><div class="lc-hero-block__text">%2$s</div>%3$s</section>',
			esc_attr( $tint ),
			$parts,
			$media,
			self::promotion( 'hero', self::text( $attributes, 'title' ), self::text( $attributes, 'ctaUrl' ) )
		);
	}

	/**
	 * Category tiles: the chosen categories (slugs, in order) or the top-level ones, each on
	 * its tint (`lachinata/category/tint`, module catalog) or its photo; in a grid (Home) or
	 * one under another (Acerca de, tablero Marca).
	 *
	 * @param array<string, mixed> $attributes Attributes.
	 */
	public static function category_tiles( array $attributes ): string {
		$slugs = array_values( array_filter( array_map( 'sanitize_title', explode( ',', self::text( $attributes, 'categories' ) ) ) ) );
		$args  = array(
			'taxonomy'   => 'product_cat',
			'hide_empty' => false,
		);
		if ( $slugs ) {
			$args['slug']    = $slugs;
			$args['orderby'] = 'slug__in';
		} else {
			$args['parent']  = 0;
			$args['exclude'] = array( (int) get_option( 'default_product_cat' ) );
			$args['orderby'] = 'menu_order';
		}
		$terms = get_terms( $args );
		if ( ! is_array( $terms ) || ! $terms ) {
			return '';
		}
		$cta   = '' !== self::text( $attributes, 'cta' ) ? self::text( $attributes, 'cta' ) : __( 'Ver todo', 'lachinata-core' );
		$tiles = '';
		foreach ( $terms as $index => $term ) {
			if ( ! $term instanceof \WP_Term ) {
				continue;
			}
			$link  = get_term_link( $term );
			$photo = (int) get_term_meta( $term->term_id, 'thumbnail_id', true );
			/** This filter is documented in theme/inc/catalog.php */
			$tint   = (string) apply_filters( 'lachinata/category/tint', '', $term ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingSinceComment -- The theme's hook.
			$tiles .= sprintf(
				'<a href="%1$s" class="lc-tile%2$s%3$s">%4$s<span class="lc-tile__text"><span class="%5$s">%6$s</span>%7$s</span><span class="lc-tile__cta label">%8$s%9$s</span></a>',
				esc_url( is_string( $link ) ? $link : '' ),
				'' !== $tint ? ' lc-tile--' . esc_attr( $tint ) : '',
				$photo ? ' lc-tile--photo' : '',
				$photo ? wp_get_attachment_image(
					$photo,
					'large',
					false,
					array(
						'class' => 'lc-tile__photo',
						'alt'   => '',
						'sizes' => '(min-width: 1024px) 25vw, 100vw',
					)
				) : '<span class="lc-tile__halo" aria-hidden="true"></span>',
				0 === $index ? 'h2' : 'h3',
				esc_html( $term->name ),
				'' !== trim( $term->description ) ? '<span class="body-sm">' . esc_html( wp_strip_all_tags( $term->description ) ) . '</span>' : '',
				esc_html( $cta ),
				self::icon( 'arrow-right', true )
			);
		}
		return sprintf( '<section class="lc-tiles%1$s">%2$s</section>', 'list' === ( $attributes['layout'] ?? '' ) ? ' lc-tiles--list' : '', $tiles );
	}

	/**
	 * Campaign banner: figure in SantElia, one or two words, the text and the link.
	 *
	 * @param array<string, mixed> $attributes Attributes.
	 */
	public static function promo( array $attributes ): string {
		// Coral (campaign-coral) only for Black Friday, with ink text (02-plantillas.md).
		$tone   = in_array( $attributes['tone'] ?? '', array( 'ink', 'coral' ), true ) ? (string) $attributes['tone'] : 'accent';
		$link   = '' !== self::text( $attributes, 'linkText' ) && '' !== self::text( $attributes, 'linkUrl' )
			? sprintf( ' <a href="%1$s">%2$s</a>', esc_url( self::text( $attributes, 'linkUrl' ) ), esc_html( self::text( $attributes, 'linkText' ) ) )
			: '';
		$figure = self::text( $attributes, 'figure' );
		$word   = self::text( $attributes, 'word' );
		return sprintf(
			'<section class="lc-campaign%1$s"%6$s>%2$s<div class="lc-campaign__text">%3$s<p class="body-sm">%4$s%5$s</p></div></section>',
			'accent' === $tone ? '' : ' lc-campaign--' . $tone,
			'' === $figure ? '' : '<p class="campaign">' . esc_html( $figure ) . '</p>',
			'' === $word ? '' : '<p class="campaign-word">' . esc_html( $word ) . '</p>',
			esc_html( self::text( $attributes, 'text' ) ),
			$link,
			self::promotion( 'promo', trim( $figure . ' ' . $word ), self::text( $attributes, 'linkUrl' ) )
		);
	}

	/**
	 * `data-lc-promo` of a hero or a campaign: what the promotion is, for whoever measures
	 * it (`tracking`: view_promotion and select_promotion; plugin/HOOKS.md, «En la página»).
	 * Nothing when it has no name.
	 *
	 * @param string $creative hero or promo.
	 * @param string $name     Headline or figure and word.
	 * @param string $url      Link of the promotion.
	 */
	private static function promotion( string $creative, string $name, string $url ): string {
		if ( '' === trim( $name ) ) {
			return '';
		}
		$data = array(
			'promotion_id'   => sanitize_title( $name ),
			'promotion_name' => wp_strip_all_tags( $name ),
			'creative_name'  => $creative,
		);
		if ( '' !== $url ) {
			$data['creative_slot'] = (string) wp_parse_url( $url, PHP_URL_PATH );
		}
		return sprintf( " data-lc-promo='%s'", esc_attr( (string) wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ) );
	}

	/**
	 * Advantages (UspBar): icon, title and text of each.
	 *
	 * @param array<string, mixed> $attributes Attributes.
	 */
	public static function usp( array $attributes ): string {
		$items = '';
		foreach ( (array) ( $attributes['items'] ?? array() ) as $item ) {
			if ( ! is_array( $item ) || '' === trim( (string) ( $item['title'] ?? '' ) ) ) {
				continue;
			}
			$icon   = '' !== trim( (string) ( $item['icon'] ?? '' ) ) ? (string) $item['icon'] : 'check';
			$items .= sprintf(
				'<div class="lc-usp__item body-sm">%1$s<div><strong>%2$s</strong><span>%3$s</span></div></div>',
				self::icon( $icon ),
				esc_html( trim( (string) $item['title'] ) ),
				esc_html( trim( (string) ( $item['text'] ?? '' ) ) )
			);
		}
		if ( '' === $items ) {
			return '';
		}
		return sprintf( '<div class="lc-usp%1$s">%2$s</div>', 'row' === ( $attributes['layout'] ?? '' ) ? ' lc-usp--row' : '', $items );
	}

	/**
	 * History: eyebrow, headline in Recoleta, lead and a secondary button, on cream.
	 *
	 * @param array<string, mixed> $attributes Attributes.
	 */
	public static function history( array $attributes ): string {
		return sprintf(
			'<section class="lc-history">%1$s%2$s%3$s%4$s</section>',
			'' !== self::text( $attributes, 'eyebrow' ) ? '<p class="eyebrow lc-history__eyebrow">' . esc_html( self::text( $attributes, 'eyebrow' ) ) . '</p>' : '',
			'' !== self::text( $attributes, 'title' ) ? '<h2 class="editorial-h2">' . esc_html( self::text( $attributes, 'title' ) ) . '</h2>' : '',
			'' !== self::text( $attributes, 'lead' ) ? '<p class="editorial-lead">' . esc_html( self::text( $attributes, 'lead' ) ) . '</p>' : '',
			self::button( self::text( $attributes, 'ctaText' ), self::text( $attributes, 'ctaUrl' ), true )
		);
	}

	/**
	 * Quote in Recoleta and olive, with its author.
	 *
	 * @param array<string, mixed> $attributes Attributes.
	 */
	public static function quote( array $attributes ): string {
		if ( '' === self::text( $attributes, 'text' ) ) {
			return '';
		}
		return sprintf(
			'<blockquote class="lc-quote-block"><p class="editorial-quote">%1$s</p>%2$s</blockquote>',
			esc_html( self::text( $attributes, 'text' ) ),
			'' !== self::text( $attributes, 'cite' ) ? '<cite class="caption">' . esc_html( self::text( $attributes, 'cite' ) ) . '</cite>' : ''
		);
	}

	/**
	 * Products chosen by SKU (which does not change between shops or migrations) or by id,
	 * in that order, drawn with the card of the theme through WooCommerce's loop template
	 * (content-product.php). Products that do not exist, are not visible or do not ship to
	 * the visitor are left out; without products, nothing is printed.
	 *
	 * @param array<string, mixed> $attributes Attributes.
	 */
	public static function products( array $attributes ): string {
		$ids = array();
		foreach ( array_filter( array_map( 'trim', explode( ',', self::text( $attributes, 'skus' ) ) ) ) as $sku ) {
			$ids[] = (int) wc_get_product_id_by_sku( $sku );
		}
		foreach ( array_filter( array_map( 'absint', explode( ',', self::text( $attributes, 'ids' ) ) ) ) as $id ) {
			$ids[] = $id;
		}
		/**
		 * Product ids of a products block, in order (module `locale` leaves out those that
		 * do not ship to the visitor's destination).
		 *
		 * @since 0.12.2
		 *
		 * @param int[] $ids Product ids.
		 */
		$ids = (array) apply_filters( 'lachinata/blocks/product_ids', array_values( array_unique( array_filter( $ids ) ) ) );

		$previous = $GLOBALS['product'] ?? null;
		ob_start();
		foreach ( $ids as $id ) {
			$product = wc_get_product( (int) $id );
			if ( ! $product instanceof \WC_Product || ! $product->is_visible() ) {
				continue;
			}
			$GLOBALS['product'] = $product; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- WooCommerce's loop template reads it; restored below.
			wc_get_template_part( 'content', 'product' );
		}
		$GLOBALS['product'] = $previous; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- Restored.
		$cards              = trim( (string) ob_get_clean() );
		return '' === $cards ? '' : '<div class="lc-grid lc-products">' . $cards . '</div>';
	}
}
