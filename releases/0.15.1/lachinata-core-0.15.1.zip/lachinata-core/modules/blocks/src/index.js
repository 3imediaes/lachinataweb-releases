/**
 * Module `blocks`: the editor of the editorial blocks. The blocks are rendered on the
 * server (Render.php, the same HTML the theme dresses), so the editor shows that render
 * (ServerSideRender) and the sidebar edits the attributes: texts, links, tint, image.
 * Nothing is saved as HTML: the content is the attributes.
 */
import { registerBlockType } from '@wordpress/blocks';
import {
	InspectorControls,
	MediaUpload,
	MediaUploadCheck,
	useBlockProps,
} from '@wordpress/block-editor';
import {
	Button,
	PanelBody,
	SelectControl,
	TextControl,
	TextareaControl,
	ToggleControl,
} from '@wordpress/components';
import { __ } from '@wordpress/i18n';
import ServerSideRender from '@wordpress/server-side-render';

const TINTS = [
	{ value: 'cream', label: __('Crema', 'lachinata-core') },
	{ value: 'cosmetica', label: __('Cosmética', 'lachinata-core') },
	{ value: 'aceites', label: __('Aceites', 'lachinata-core') },
	{ value: 'gourmet', label: __('Gourmet', 'lachinata-core') },
	{ value: 'regalos', label: __('Regalos', 'lachinata-core') },
	{ value: 'hogar', label: __('Hogar', 'lachinata-core') },
];

const text = (key, label, help) => ({ key, label, help, type: 'text' });
const area = (key, label, help) => ({ key, label, help, type: 'area' });

/**
 * Fields of the sidebar of each block.
 */
const FIELDS = {
	'lachinata/hero': [
		text('eyebrow', __('Antetítulo', 'lachinata-core')),
		area('title', __('Titular', 'lachinata-core')),
		area('lead', __('Entradilla', 'lachinata-core')),
		text('ctaText', __('Texto del botón', 'lachinata-core')),
		text('ctaUrl', __('Enlace del botón', 'lachinata-core')),
		{
			key: 'tint',
			label: __('Tinta', 'lachinata-core'),
			type: 'select',
			options: TINTS,
		},
		{
			key: 'size',
			label: __('Tamaño del titular', 'lachinata-core'),
			type: 'select',
			options: [
				{
					value: 'display',
					label: __('Portada (display)', 'lachinata-core'),
				},
				{ value: 'h1', label: __('Página (h1)', 'lachinata-core') },
			],
		},
		{
			key: 'campaign',
			label: __(
				'Titular como cifra de campaña (SantElia)',
				'lachinata-core'
			),
			type: 'toggle',
		},
		{ key: 'imageId', label: __('Foto', 'lachinata-core'), type: 'image' },
	],
	'lachinata/category-tiles': [
		text(
			'categories',
			__('Categorías', 'lachinata-core'),
			__(
				'Slugs separados por comas, en orden. Vacío: las categorías principales.',
				'lachinata-core'
			)
		),
		text(
			'cta',
			__('Texto del enlace', 'lachinata-core'),
			__('Vacío: «Ver todo».', 'lachinata-core')
		),
		{
			key: 'layout',
			label: __('Disposición', 'lachinata-core'),
			type: 'select',
			options: [
				{ value: 'grid', label: __('Rejilla', 'lachinata-core') },
				{
					value: 'list',
					label: __('Una bajo otra', 'lachinata-core'),
				},
			],
		},
	],
	'lachinata/products': [
		text(
			'skus',
			__('SKU', 'lachinata-core'),
			__(
				'Separados por comas, en el orden en que se muestran. El SKU no cambia entre tiendas.',
				'lachinata-core'
			)
		),
		text(
			'ids',
			__('ID de producto', 'lachinata-core'),
			__('Alternativa al SKU, separados por comas.', 'lachinata-core')
		),
	],
	'lachinata/promo': [
		text(
			'figure',
			__('Cifra (SantElia)', 'lachinata-core'),
			__('-30%, 2x1…', 'lachinata-core')
		),
		text('word', __('Una o dos palabras', 'lachinata-core')),
		area('text', __('Explicación', 'lachinata-core')),
		text('linkText', __('Texto del enlace', 'lachinata-core')),
		text('linkUrl', __('Enlace', 'lachinata-core')),
		{
			key: 'tone',
			label: __('Fondo', 'lachinata-core'),
			type: 'select',
			options: [
				{ value: 'accent', label: __('Acento', 'lachinata-core') },
				{ value: 'ink', label: __('Tinta', 'lachinata-core') },
				{
					value: 'coral',
					label: __('Coral (solo Black Friday)', 'lachinata-core'),
				},
			],
		},
	],
	'lachinata/usp': [
		{
			key: 'items',
			label: __('Ventajas', 'lachinata-core'),
			type: 'lines',
			help: __(
				'Una por línea: icono | título | texto (iconos: truck, leaf, phone, gift…).',
				'lachinata-core'
			),
		},
		{
			key: 'layout',
			label: __('Disposición', 'lachinata-core'),
			type: 'select',
			options: [
				{ value: 'grid', label: __('Rejilla 2 × 2', 'lachinata-core') },
				{ value: 'row', label: __('Fila', 'lachinata-core') },
			],
		},
	],
	'lachinata/history': [
		text('eyebrow', __('Antetítulo', 'lachinata-core')),
		area('title', __('Titular', 'lachinata-core')),
		area('lead', __('Entradilla', 'lachinata-core')),
		text('ctaText', __('Texto del botón', 'lachinata-core')),
		text('ctaUrl', __('Enlace del botón', 'lachinata-core')),
	],
	'lachinata/quote': [
		area('text', __('Cita', 'lachinata-core')),
		text('cite', __('Autor', 'lachinata-core')),
	],
};

/**
 * Ventajas as lines «icono | título | texto» and back.
 *
 * @param {Array} items Items.
 * @return {string} Lines.
 */
const toLines = (items) =>
	(items || [])
		.map((item) =>
			[item.icon || '', item.title || '', item.text || ''].join(' | ')
		)
		.join('\n');

/**
 * @param {string} value Lines.
 * @return {Array} Items.
 */
const fromLines = (value) =>
	value
		.split('\n')
		.map((line) => line.split('|').map((part) => part.trim()))
		.filter((parts) => parts.some(Boolean))
		.map(([icon = '', title = '', itemText = '']) => ({
			icon,
			title,
			text: itemText,
		}));

/**
 * A field of the sidebar.
 *
 * @param {Object}                       props
 * @param {Object}                       props.field         Field.
 * @param {Object}                       props.attributes    Attributes.
 * @param {(attributes: Object) => void} props.setAttributes Setter.
 */
function Field({ field, attributes, setAttributes }) {
	const value = attributes[field.key];
	const set = (next) => setAttributes({ [field.key]: next });
	switch (field.type) {
		case 'area':
			return (
				<TextareaControl
					label={field.label}
					help={field.help}
					value={value || ''}
					onChange={set}
					__nextHasNoMarginBottom
				/>
			);
		case 'select':
			return (
				<SelectControl
					label={field.label}
					value={value}
					options={field.options}
					onChange={set}
					__nextHasNoMarginBottom
					__next40pxDefaultSize
				/>
			);
		case 'toggle':
			return (
				<ToggleControl
					label={field.label}
					checked={!!value}
					onChange={set}
					__nextHasNoMarginBottom
				/>
			);
		case 'lines':
			return (
				<TextareaControl
					label={field.label}
					help={field.help}
					value={toLines(value)}
					onChange={(next) => set(fromLines(next))}
					__nextHasNoMarginBottom
				/>
			);
		case 'image':
			return (
				<MediaUploadCheck>
					<MediaUpload
						allowedTypes={['image']}
						value={value}
						onSelect={(media) => set(media.id)}
						render={({ open }) => (
							<div>
								<Button variant="secondary" onClick={open}>
									{value
										? __(
												'Cambiar la foto',
												'lachinata-core'
											)
										: __(
												'Elegir una foto',
												'lachinata-core'
											)}
								</Button>{' '}
								{!!value && (
									<Button
										variant="link"
										isDestructive
										onClick={() => set(0)}
									>
										{__('Quitar', 'lachinata-core')}
									</Button>
								)}
							</div>
						)}
					/>
				</MediaUploadCheck>
			);
		default:
			return (
				<TextControl
					label={field.label}
					help={field.help}
					value={value || ''}
					onChange={set}
					__nextHasNoMarginBottom
					__next40pxDefaultSize
				/>
			);
	}
}

/**
 * Editor of a block: its sidebar and the server's render.
 *
 * @param {Object}                       props
 * @param {string}                       props.name          Block name.
 * @param {Object}                       props.attributes    Attributes.
 * @param {(attributes: Object) => void} props.setAttributes Setter.
 */
function Edit({ name, attributes, setAttributes }) {
	const blockProps = useBlockProps();
	return (
		<div {...blockProps}>
			<InspectorControls>
				<PanelBody title={__('Contenido', 'lachinata-core')}>
					{FIELDS[name].map((field) => (
						<Field
							key={field.key}
							field={field}
							attributes={attributes}
							setAttributes={setAttributes}
						/>
					))}
				</PanelBody>
			</InspectorControls>
			<ServerSideRender block={name} attributes={attributes} />
		</div>
	);
}

Object.keys(FIELDS).forEach((name) => {
	registerBlockType(name, {
		edit: (props) => <Edit {...props} name={name} />,
		save: () => null,
	});
});
