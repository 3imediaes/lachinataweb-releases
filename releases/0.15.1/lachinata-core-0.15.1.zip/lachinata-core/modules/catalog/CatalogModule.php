<?php
/**
 * Module `catalog`: catalog data that used to live in ACF.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

use LaChinata\Core\Hooks;
use LaChinata\Core\Module;
use LaChinata\Core\Plugin;

defined( 'ABSPATH' ) || exit;

/**
 * Content and unit price, ingredients, label, description image, best-before date,
 * international exclusion, category tint and seals (`tipo`) with icon; main category and
 * card image of the product, look of the product tags, marks of the shipping classes,
 * store categories with campaigns, cross-sell by root category and the catalog health.
 */
final class CatalogModule extends Module {

	/**
	 * Module id.
	 */
	public function id(): string {
		return 'catalog';
	}

	/**
	 * Module name.
	 */
	public function label(): string {
		return __( 'Catálogo', 'lachinata-core' );
	}

	/**
	 * Module description.
	 */
	public function description(): string {
		return __( 'Contenido y precio por unidad, ingredientes, etiquetas, sellos, tinta de categoría, categorías de la tienda, venta cruzada y salud del catálogo. Sustituye a ACF.', 'lachinata-core' );
	}

	/**
	 * Version in which the module was added.
	 */
	public function since(): string {
		return '0.2.0';
	}

	/**
	 * Documentation.
	 */
	public function docs(): string {
		return 'plugin/modules/catalog/README.md';
	}

	/**
	 * Requirements.
	 *
	 * @return array{woocommerce: string}
	 */
	public function requires(): array {
		return array( 'woocommerce' => '10.0' );
	}

	/**
	 * Configuration of the shop (it travels in the JSON): store categories and campaigns,
	 * cross-sell by root category and marks of the shipping classes, all by slug. Read them
	 * clean with Config.
	 *
	 * @return array<string, array{type: 'array', default: array<int, mixed>, export: bool}>
	 */
	public function settings(): array {
		$list = array(
			'type'    => 'array',
			'default' => array(),
			'export'  => true,
		);
		return array(
			'store_categories' => $list,
			'campaigns'        => $list,
			'cross_sell'       => $list,
			'markers'          => $list,
			'watched_fields'   => $list,
		);
	}

	/**
	 * The module, for Settings.
	 */
	public static function instance(): ?Module {
		return Plugin::instance()->modules()->get( 'catalog' );
	}

	/**
	 * Product and term fields («Borrar datos» removes them; the old ACF values stay).
	 *
	 * @return array{product_meta: string[], term_meta: string[]}
	 */
	public function owned_data(): array {
		return array(
			'product_meta' => array( Fields::CONTENT, Fields::REFERENCE, Fields::INGREDIENTS, Fields::LABEL, Fields::IMAGE, Fields::BEST_BEFORE, Fields::NO_SHIP_ABROAD, Fields::MAIN_CATEGORY, Fields::CARD_IMAGE, Changes::META ),
			'term_meta'    => array( Fields::TINT, Fields::ICON, Fields::TAG_TONE, Fields::TAG_IMAGE, Fields::TAG_ORDER ),
		);
	}

	/**
	 * Registers the hooks.
	 */
	public function boot(): void {
		Hooks::add_action( 'init', array( TipoTaxonomy::class, 'register' ), 5 );
		Hooks::add_action( 'init', array( Fields::class, 'register' ) );
		Hooks::add_filter( 'lachinata/translate/fields', array( Fields::class, 'translatable' ) );
		Hooks::add_filter( 'lachinata/catalog/no_ship_abroad', static fn( $excluded, $product_id ): bool => (bool) $excluded || (bool) Fields::get( (int) $product_id, Fields::NO_SHIP_ABROAD ), 10, 2 );
		$content = new Content();
		Hooks::add_filter( 'lachinata/catalog/service', static fn() => $content );
		Storefront::boot();
		Changes::boot();

		if ( is_admin() ) {
			Admin::boot();
			ProductAdmin::boot();
			TermFields::boot();
			CatalogTab::boot();
		}

		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::add_command( 'lachinata catalog', NormalizeCommand::class );
		}
	}
}
