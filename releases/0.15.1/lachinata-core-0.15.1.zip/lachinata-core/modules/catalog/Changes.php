<?php
/**
 * Dates of the changes that count in a product.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * What a text may have said of a product and can stop being true: its seals (`tipo`) and
 * the fields of the setting `watched_fields` (the ingredients by default, where allergens,
 * traces and nutrition also go). When one of them changes, the product keeps the date
 * (`_lc_catalog_cambios`) and `lachinata/catalog/product_changed` tells it; when the
 * product is no longer published (private, draft or bin; sold out does not count),
 * `lachinata/catalog/product_discontinued`. The free description is not watched.
 */
final class Changes {

	/**
	 * Dates of the last change, by field (Y-m-d).
	 */
	public const META = '_lc_catalog_cambios';

	/**
	 * Key of the seals in the dates.
	 */
	private const SEALS = 'sellos';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'updated_post_meta', array( self::class, 'on_meta' ), 10, 4 );
		Hooks::add_action( 'deleted_post_meta', array( self::class, 'on_meta' ), 10, 4 );
		Hooks::add_action( 'set_object_terms', array( self::class, 'on_terms' ), 10, 6 );
		Hooks::add_action( 'transition_post_status', array( self::class, 'on_status' ), 10, 3 );
	}

	/**
	 * Fields watched (meta keys), from the setting.
	 *
	 * @return string[]
	 */
	public static function watched(): array {
		$module = CatalogModule::instance();
		$keys   = null === $module ? array() : (array) \LaChinata\Core\Settings::get( $module, 'watched_fields' );
		$keys   = array_values( array_filter( array_map( static fn( $key ): string => sanitize_key( (string) $key ), $keys ) ) );
		return $keys ? $keys : array( Fields::INGREDIENTS );
	}

	/**
	 * A watched field changed.
	 *
	 * @param mixed $meta_id  Meta id(s).
	 * @param mixed $post_id  Post id.
	 * @param mixed $meta_key Key.
	 * @param mixed $value    Value.
	 */
	public static function on_meta( $meta_id, $post_id, $meta_key, $value ): void {
		unset( $meta_id, $value );
		if ( ! in_array( (string) $meta_key, self::watched(), true ) || 'product' !== get_post_type( (int) $post_id ) ) {
			return;
		}
		self::record( (int) $post_id, (string) $meta_key, self::label( (string) $meta_key ) );
	}

	/**
	 * The seals changed (a different set of `tipo` terms).
	 *
	 * @param mixed $object_id  Object.
	 * @param mixed $terms      Terms given.
	 * @param mixed $tt_ids     New term taxonomy ids.
	 * @param mixed $taxonomy   Taxonomy.
	 * @param mixed $append     Appended.
	 * @param mixed $old_tt_ids Old term taxonomy ids.
	 */
	public static function on_terms( $object_id, $terms, $tt_ids, $taxonomy, $append, $old_tt_ids ): void {
		unset( $terms, $append );
		if ( TipoTaxonomy::TAXONOMY !== $taxonomy || 'product' !== get_post_type( (int) $object_id ) ) {
			return;
		}
		$new = array_map( 'intval', (array) $tt_ids );
		$old = array_map( 'intval', (array) $old_tt_ids );
		sort( $new );
		sort( $old );
		if ( $new !== $old ) {
			self::record( (int) $object_id, self::SEALS, __( 'sus sellos', 'lachinata-core' ) );
		}
	}

	/**
	 * A product that was published is no longer.
	 *
	 * @param mixed $new_status New status.
	 * @param mixed $old_status Old status.
	 * @param mixed $post       Post.
	 */
	public static function on_status( $new_status, $old_status, $post ): void {
		if ( ! $post instanceof \WP_Post || 'product' !== $post->post_type || 'publish' !== $old_status || 'publish' === $new_status ) {
			return;
		}
		/**
		 * A product is no longer published (private, draft or bin). Sold out does not count.
		 * The blog sends the entries that mention it to «Revisar».
		 *
		 * @since 0.13.1
		 *
		 * @param int    $product_id Product.
		 * @param string $date       Day (Y-m-d).
		 */
		do_action( 'lachinata/catalog/product_discontinued', $post->ID, wp_date( 'Y-m-d' ) );
	}

	/**
	 * Keeps the date and tells it.
	 *
	 * @param int    $product_id Product.
	 * @param string $key        Field.
	 * @param string $what       What changed, for people («sus ingredientes»).
	 */
	private static function record( int $product_id, string $key, string $what ): void {
		$dates         = get_post_meta( $product_id, self::META, true );
		$dates         = is_array( $dates ) ? $dates : array();
		$today         = wp_date( 'Y-m-d' );
		$dates[ $key ] = $today;
		update_post_meta( $product_id, self::META, $dates );
		/**
		 * A field that counts changed in a product: its seals or one of the fields watched
		 * (ingredients by default). The blog sends the entries that mention it to «Revisar».
		 *
		 * @since 0.13.1
		 *
		 * @param int    $product_id Product.
		 * @param string $what       What changed, for people («sus ingredientes»).
		 * @param string $date       Day (Y-m-d).
		 */
		do_action( 'lachinata/catalog/product_changed', $product_id, $what, $today );
	}

	/**
	 * What a field is for people.
	 *
	 * @param string $key Meta key.
	 */
	public static function label( string $key ): string {
		if ( Fields::INGREDIENTS === $key ) {
			return __( 'sus ingredientes', 'lachinata-core' );
		}
		/* translators: %s: meta key. */
		return sprintf( __( 'el campo %s', 'lachinata-core' ), $key );
	}
}
