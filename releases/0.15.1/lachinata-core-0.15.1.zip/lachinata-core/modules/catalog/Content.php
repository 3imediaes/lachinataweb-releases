<?php
/**
 * Contracts\ProductContent served by `catalog`.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

use LaChinata\Core\Contracts\ProductContent;

defined( 'ABSPATH' ) || exit;

/**
 * The content and reference fields of the La Chinata tab, for other modules.
 */
final class Content implements ProductContent {

	/**
	 * Content of a product or variation.
	 *
	 * @param \WC_Product $product Product or variation.
	 * @return array{amount: float, unit: string}|null
	 */
	public function content( \WC_Product $product ): ?array {
		return self::shape( Fields::content( $product ) );
	}

	/**
	 * Reference quantity of the unit price.
	 *
	 * @param \WC_Product $product Product or variation.
	 * @return array{amount: float, unit: string}|null
	 */
	public function reference( \WC_Product $product ): ?array {
		return self::shape( Fields::reference( $product ) );
	}

	/**
	 * Quantity as the contract returns it.
	 *
	 * @param Quantity|null $quantity Quantity.
	 * @return array{amount: float, unit: string}|null
	 */
	private static function shape( ?Quantity $quantity ): ?array {
		return null === $quantity ? null : array(
			'amount' => $quantity->amount,
			'unit'   => $quantity->unit,
		);
	}
}
