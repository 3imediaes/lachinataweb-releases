<?php
/**
 * Editorial package of the products: the Spanish texts out and back in.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

use LaChinata\Core\SourceStatus;

defined( 'ABSPATH' ) || exit;

/**
 * The review of the Spanish text of the catalog (07-traduccion.md, «Orden de trabajo»): the
 * texts of each product go out as JSON, someone proposes the corrected text, the shop
 * approves it and it comes back in. Each field carries the fingerprint of the text it was
 * exported from: if the text on the site changed since then, importing it would overwrite
 * someone's work, so it is a conflict and is not written. Ingredients and nutrition are
 * not in the package (they will come from the shop's own application).
 *
 * Read only, to find the product and for people: `id`, `sku`, `url`, `estado` and, in a
 * variation, its attributes.
 */
final class Editorial {

	/**
	 * Format of the package.
	 */
	public const FORMAT = 'lachinata-catalogo-editorial';

	/**
	 * Version of the format.
	 */
	public const VERSION = 1;

	/**
	 * Rank Math's SEO title and description of a product.
	 */
	private const SEO_TITLE       = 'rank_math_title';
	private const SEO_DESCRIPTION = 'rank_math_description';

	/**
	 * Fields of a product in the package, in this order.
	 */
	public const FIELDS = array( 'nombre', 'descripcion_corta', 'descripcion', 'etiqueta', 'seo_titulo', 'seo_descripcion' );

	/**
	 * Fields that keep HTML; the rest is plain text.
	 */
	private const HTML = array( 'descripcion_corta', 'descripcion' );

	/**
	 * The package of some products.
	 *
	 * @param int[] $ids Product ids (parents, not variations).
	 * @return array<string, mixed>
	 */
	public static function export( array $ids ): array {
		$products = array();
		foreach ( $ids as $id ) {
			$product = wc_get_product( $id );
			if ( $product instanceof \WC_Product && ! $product instanceof \WC_Product_Variation ) {
				$products[] = self::product( $product );
			}
		}
		return array(
			'formato'   => self::FORMAT,
			'version'   => self::VERSION,
			'exportado' => gmdate( 'c' ),
			'sitio'     => home_url( '/' ),
			'productos' => $products,
		);
	}

	/**
	 * Ids of the products to export: published by default.
	 *
	 * @param array{ids?: int[], category?: string, status?: string, source?: string} $args Filters.
	 * @return int[]
	 */
	public static function ids( array $args = array() ): array {
		$query = array(
			'post_type'      => 'product',
			'post_status'    => '' !== ( $args['status'] ?? '' ) ? array_map( 'trim', explode( ',', (string) $args['status'] ) ) : array( 'publish' ),
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'orderby'        => 'ID',
			'order'          => 'ASC',
		);
		if ( ! empty( $args['ids'] ) ) {
			$query['post__in'] = array_map( 'absint', $args['ids'] );
		}
		if ( '' !== ( $args['category'] ?? '' ) ) {
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- A one-off export.
			$query['tax_query'] = array(
				array(
					'taxonomy'         => 'product_cat',
					'field'            => 'slug',
					'terms'            => (string) $args['category'],
					'include_children' => true,
				),
			);
		}
		if ( in_array( $args['source'] ?? '', array( SourceStatus::PENDING, SourceStatus::REVIEWED ), true ) ) {
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- A one-off export.
			$query['meta_query'] = array( SourceStatus::meta_query( (string) $args['source'] ) );
		}
		return array_map( 'intval', get_posts( $query ) );
	}

	/**
	 * One product of the package.
	 *
	 * @param \WC_Product $product Product.
	 * @return array<string, mixed>
	 */
	private static function product( \WC_Product $product ): array {
		$fields = array();
		foreach ( self::FIELDS as $field ) {
			$fields[ $field ] = self::entry( self::read( $product, $field ) );
		}
		$images = array();
		foreach ( self::image_ids( $product ) as $image_id ) {
			$images[] = array(
				'id'  => $image_id,
				'alt' => self::entry( self::alt( $image_id ) ),
			);
		}
		$variations = array();
		foreach ( $product->get_children() as $child_id ) {
			$variation = wc_get_product( $child_id );
			if ( ! $variation instanceof \WC_Product_Variation || '' === trim( $variation->get_description( 'edit' ) ) ) {
				continue;
			}
			$variations[] = array(
				'id'        => $variation->get_id(),
				'sku'       => $variation->get_sku( 'edit' ),
				'atributos' => wc_get_formatted_variation( $variation, true, false, false ),
				'campos'    => array( 'descripcion' => self::entry( $variation->get_description( 'edit' ) ) ),
			);
		}
		return array(
			'id'          => $product->get_id(),
			'sku'         => $product->get_sku( 'edit' ),
			'url'         => (string) get_permalink( $product->get_id() ),
			'estado'      => SourceStatus::get( $product->get_id() ),
			'campos'      => $fields,
			'imagenes'    => $images,
			'variaciones' => $variations,
		);
	}

	/**
	 * A text and the fingerprint of what it is now.
	 *
	 * @param string $text Text.
	 * @return array{texto: string, huella: string}
	 */
	private static function entry( string $text ): array {
		return array(
			'texto'  => $text,
			'huella' => self::fingerprint( $text ),
		);
	}

	/**
	 * Fingerprint of a text: line endings and the spaces at both ends do not count.
	 *
	 * @param string $text Text.
	 */
	public static function fingerprint( string $text ): string {
		return sha1( trim( str_replace( array( "\r\n", "\r" ), "\n", $text ) ) );
	}

	/**
	 * A field of a product as it is now.
	 *
	 * @param \WC_Product $product Product.
	 * @param string      $field   Field of the package.
	 */
	private static function read( \WC_Product $product, string $field ): string {
		return match ( $field ) {
			'nombre'            => $product->get_name( 'edit' ),
			'descripcion_corta' => $product->get_short_description( 'edit' ),
			'descripcion'       => $product->get_description( 'edit' ),
			'etiqueta'          => (string) Fields::get( $product->get_id(), Fields::LABEL ),
			'seo_titulo'        => (string) get_post_meta( $product->get_id(), self::SEO_TITLE, true ),
			'seo_descripcion'   => (string) get_post_meta( $product->get_id(), self::SEO_DESCRIPTION, true ),
			default             => '',
		};
	}

	/**
	 * Writes a field (the product is saved afterwards).
	 *
	 * @param \WC_Product $product Product.
	 * @param string      $field   Field of the package.
	 * @param string      $text    New text, already clean.
	 */
	private static function write( \WC_Product $product, string $field, string $text ): void {
		switch ( $field ) {
			case 'nombre':
				$product->set_name( $text );
				break;
			case 'descripcion_corta':
				$product->set_short_description( $text );
				break;
			case 'descripcion':
				$product->set_description( $text );
				break;
			case 'etiqueta':
				$product->update_meta_data( Fields::LABEL, $text );
				break;
			case 'seo_titulo':
				$product->update_meta_data( self::SEO_TITLE, $text );
				break;
			case 'seo_descripcion':
				$product->update_meta_data( self::SEO_DESCRIPTION, $text );
				break;
		}
	}

	/**
	 * The text of a field as it may be saved.
	 *
	 * @param string $field Field of the package.
	 * @param string $text  Text of the package.
	 */
	private static function clean( string $field, string $text ): string {
		return in_array( $field, self::HTML, true ) ? trim( wp_kses_post( $text ) ) : sanitize_text_field( $text );
	}

	/**
	 * Featured image and gallery, without repeating one.
	 *
	 * @param \WC_Product $product Product.
	 * @return int[]
	 */
	private static function image_ids( \WC_Product $product ): array {
		$ids = array_merge( array( (int) $product->get_image_id( 'edit' ) ), array_map( 'intval', $product->get_gallery_image_ids( 'edit' ) ) );
		return array_values( array_unique( array_filter( $ids ) ) );
	}

	/**
	 * Alternative text of an image.
	 *
	 * @param int $image_id Attachment id.
	 */
	private static function alt( int $image_id ): string {
		return (string) get_post_meta( $image_id, '_wp_attachment_image_alt', true );
	}

	/**
	 * Imports a package.
	 *
	 * @param array<string, mixed> $package       Decoded package.
	 * @param bool                 $dry_run       Report only.
	 * @param bool                 $mark_reviewed Mark as «Revisado» each product that comes in whole (no conflict, no error).
	 * @return array{products: int, updated: int, unchanged: int, conflicts: string[], errors: string[], names: array<int, array{id: int, sku: string, before: string, after: string}>, reviewed: int, changed: string[]}
	 */
	public static function import( array $package, bool $dry_run = false, bool $mark_reviewed = false ): array {
		$report = array(
			'products'  => 0,
			'updated'   => 0,
			'unchanged' => 0,
			'conflicts' => array(),
			'errors'    => array(),
			'names'     => array(),
			'reviewed'  => 0,
			'changed'   => array(),
		);
		if ( self::FORMAT !== ( $package['formato'] ?? '' ) || self::VERSION !== (int) ( $package['version'] ?? 0 ) ) {
			$report['errors'][] = sprintf( 'No es un paquete editorial del catálogo (formato %1$s, versión %2$d).', self::FORMAT, self::VERSION );
			return $report;
		}
		// An image may be in several products: the first text it gets wins.
		$image_alts  = array();
		$image_owner = array();
		foreach ( (array) ( $package['productos'] ?? array() ) as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			++$report['products'];
			$product = self::find( $row, $report['errors'] );
			if ( null === $product ) {
				continue;
			}
			$label  = sprintf( '#%1$d %2$s', $product->get_id(), '' !== $product->get_sku() ? '(' . $product->get_sku() . ')' : '' );
			$whole  = true;
			$dirty  = false;
			$writes = array();
			foreach ( (array) ( $row['campos'] ?? array() ) as $field => $entry ) {
				if ( ! in_array( $field, self::FIELDS, true ) ) {
					$report['errors'][] = sprintf( '%1$s: el campo «%2$s» no está en el paquete; no se importa.', trim( $label ), $field );
					$whole              = false;
					continue;
				}
				$result = self::compare( $field, self::read( $product, $field ), $entry );
				if ( 'apply' === $result['action'] ) {
					$writes[ $field ] = $result['text'] ?? '';
				} elseif ( 'same' === $result['action'] ) {
					++$report['unchanged'];
				} else {
					$report[ 'conflict' === $result['action'] ? 'conflicts' : 'errors' ][] = sprintf( '%1$s, %2$s: %3$s', trim( $label ), $field, $result['why'] ?? '' );
					$whole = false;
				}
			}
			foreach ( $writes as $field => $text ) {
				if ( 'nombre' === $field ) {
					$report['names'][] = array(
						'id'     => $product->get_id(),
						'sku'    => $product->get_sku(),
						'before' => $product->get_name( 'edit' ),
						'after'  => $text,
					);
				}
				self::write( $product, $field, $text );
				$report['changed'][] = sprintf( '%1$s: %2$s', trim( $label ), $field );
				++$report['updated'];
				$dirty = true;
			}

			$alts = array();
			foreach ( (array) ( $row['imagenes'] ?? array() ) as $image ) {
				$image_id = is_array( $image ) ? absint( $image['id'] ?? 0 ) : 0;
				if ( ! in_array( $image_id, self::image_ids( $product ), true ) ) {
					$report['errors'][] = sprintf( '%1$s: la imagen #%2$d no es de este producto.', trim( $label ), $image_id );
					$whole              = false;
					continue;
				}
				$result = self::compare( 'alt', self::alt( $image_id ), $image['alt'] ?? null );
				if ( 'apply' === $result['action'] && isset( $image_alts[ $image_id ] ) && ( $result['text'] ?? '' ) !== $image_alts[ $image_id ] ) {
					$result = array(
						'action' => 'conflict',
						'why'    => sprintf( 'la imagen también está en #%d con otro texto alternativo', $image_owner[ $image_id ] ?? 0 ),
					);
				}
				if ( 'apply' === $result['action'] ) {
					$alts[ $image_id ]        = $result['text'] ?? '';
					$image_alts[ $image_id ]  = $result['text'] ?? '';
					$image_owner[ $image_id ] = $product->get_id();
					$report['changed'][]      = sprintf( '%1$s: alt de la imagen #%2$d', trim( $label ), $image_id );
					++$report['updated'];
				} elseif ( 'same' === $result['action'] ) {
					++$report['unchanged'];
				} else {
					$report[ 'conflict' === $result['action'] ? 'conflicts' : 'errors' ][] = sprintf( '%1$s, alt de la imagen #%2$d: %3$s', trim( $label ), $image_id, $result['why'] ?? '' );
					$whole = false;
				}
			}

			$variations = array();
			foreach ( (array) ( $row['variaciones'] ?? array() ) as $child ) {
				$child_id  = is_array( $child ) ? absint( $child['id'] ?? 0 ) : 0;
				$variation = wc_get_product( $child_id );
				if ( ! $variation instanceof \WC_Product_Variation || $variation->get_parent_id() !== $product->get_id() ) {
					$report['errors'][] = sprintf( '%1$s: la variación #%2$d no es de este producto.', trim( $label ), $child_id );
					$whole              = false;
					continue;
				}
				$result = self::compare( 'descripcion', $variation->get_description( 'edit' ), $child['campos']['descripcion'] ?? null );
				if ( 'apply' === $result['action'] ) {
					$variation->set_description( $result['text'] ?? '' );
					$variations[]        = $variation;
					$report['changed'][] = sprintf( '%1$s: descripción de la variación #%2$d', trim( $label ), $child_id );
					++$report['updated'];
				} elseif ( 'same' === $result['action'] ) {
					++$report['unchanged'];
				} else {
					$report[ 'conflict' === $result['action'] ? 'conflicts' : 'errors' ][] = sprintf( '%1$s, variación #%2$d: %3$s', trim( $label ), $child_id, $result['why'] ?? '' );
					$whole = false;
				}
			}

			if ( $dry_run ) {
				$report['reviewed'] += $mark_reviewed && $whole && ! SourceStatus::is_reviewed( $product->get_id() ) ? 1 : 0;
				continue;
			}
			if ( $dirty ) {
				$product->save();
			}
			foreach ( $variations as $variation ) {
				$variation->save();
			}
			foreach ( $alts as $image_id => $text ) {
				update_post_meta( $image_id, '_wp_attachment_image_alt', $text );
			}
			if ( $mark_reviewed && $whole && SourceStatus::set( $product->get_id(), SourceStatus::REVIEWED ) ) {
				++$report['reviewed'];
			}
		}
		return $report;
	}

	/**
	 * The product of a row: by id, and the SKU must match when both have one.
	 *
	 * @param array<string, mixed> $row    Row of the package.
	 * @param string[]             $errors Errors, by reference.
	 */
	private static function find( array $row, array &$errors ): ?\WC_Product {
		$id      = absint( $row['id'] ?? 0 );
		$product = $id ? wc_get_product( $id ) : null;
		if ( ! $product instanceof \WC_Product || $product instanceof \WC_Product_Variation ) {
			$errors[] = sprintf( '#%d: no existe ese producto en este sitio.', $id );
			return null;
		}
		$sku = (string) ( $row['sku'] ?? '' );
		if ( '' !== $sku && '' !== $product->get_sku() && $sku !== $product->get_sku() ) {
			$errors[] = sprintf( '#%1$d: el SKU del paquete (%2$s) no es el del producto (%3$s); no se importa.', $id, $sku, $product->get_sku() );
			return null;
		}
		return $product;
	}

	/**
	 * What to do with a field: write it, nothing (same text), a conflict (the site changed
	 * since the export) or an error (no text or no fingerprint).
	 *
	 * @param string $field   Field of the package (`alt` for an image).
	 * @param string $current Text on the site now.
	 * @param mixed  $entry   `{texto, huella}` of the package.
	 * @return array{action: string, text?: string, why?: string}
	 */
	private static function compare( string $field, string $current, $entry ): array {
		if ( ! is_array( $entry ) || ! is_string( $entry['texto'] ?? null ) ) {
			return array(
				'action' => 'error',
				'why'    => 'falta el texto',
			);
		}
		if ( ! is_string( $entry['huella'] ?? null ) || '' === $entry['huella'] ) {
			return array(
				'action' => 'error',
				'why'    => 'falta la huella del texto exportado',
			);
		}
		// The text as it was exported is not a proposal, even if cleaning it would change it.
		if ( self::fingerprint( $entry['texto'] ) === $entry['huella'] ) {
			return array( 'action' => 'same' );
		}
		$text = self::clean( 'alt' === $field ? 'etiqueta' : $field, $entry['texto'] );
		if ( self::fingerprint( $text ) === self::fingerprint( $current ) ) {
			return array( 'action' => 'same' );
		}
		if ( self::fingerprint( $current ) !== $entry['huella'] ) {
			return array(
				'action' => 'conflict',
				'why'    => 'el texto del sitio ha cambiado desde la exportación; no se pisa',
			);
		}
		return array(
			'action' => 'apply',
			'text'   => $text,
		);
	}

	/**
	 * The report of an import, as Markdown.
	 *
	 * @param array<string, mixed> $report  Report of import().
	 * @param bool                 $dry_run Whether nothing was written.
	 */
	public static function markdown( array $report, bool $dry_run ): string {
		$out   = array( '# Importación editorial del catálogo' . ( $dry_run ? ' (simulación)' : '' ), '' );
		$out[] = sprintf( '- Productos en el paquete: %d', (int) $report['products'] );
		$out[] = sprintf( '- Campos cambiados: %d', (int) $report['updated'] );
		$out[] = sprintf( '- Campos sin cambios: %d', (int) $report['unchanged'] );
		$out[] = sprintf( '- Conflictos: %d', count( (array) $report['conflicts'] ) );
		$out[] = sprintf( '- Errores: %d', count( (array) $report['errors'] ) );
		$out[] = sprintf( '- Marcados como «Revisado»: %d', (int) $report['reviewed'] );
		$out[] = '';
		$out[] = '## Nombres que cambian';
		$out[] = '';
		$out[] = 'El nombre es dato de calidad: revisa cada cambio.';
		$out[] = '';
		if ( ! $report['names'] ) {
			$out[] = 'Ninguno.';
		} else {
			$out[] = '| Producto | SKU | Antes | Después |';
			$out[] = '| --- | --- | --- | --- |';
			foreach ( (array) $report['names'] as $name ) {
				$out[] = sprintf( '| #%1$d | %2$s | %3$s | %4$s |', $name['id'], $name['sku'], str_replace( '|', '\|', $name['before'] ), str_replace( '|', '\|', $name['after'] ) );
			}
		}
		foreach ( array(
			'conflicts' => 'Conflictos (no se han escrito)',
			'errors'    => 'Errores',
			'changed'   => 'Campos cambiados',
		) as $key => $title ) {
			$out[] = '';
			$out[] = '## ' . $title;
			$out[] = '';
			$lines = (array) $report[ $key ];
			foreach ( $lines ? $lines : array( 'Ninguno.' ) as $line ) {
				$out[] = $lines ? '- ' . $line : $line;
			}
		}
		return implode( "\n", $out ) . "\n";
	}
}
