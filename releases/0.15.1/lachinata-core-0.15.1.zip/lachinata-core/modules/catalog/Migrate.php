<?php
/**
 * Description changes of the migration.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

defined( 'ABSPATH' ) || exit;

/**
 * Two changes to the old descriptions, without touching their text: subtitles made with
 * bold on a line of their own become `h3`, and the `[products]` shortcode becomes the products
 * block of the module `blocks`. Everything else (old layouts with columns and inline
 * styles) is left as it is for La Chinata to decide.
 */
final class Migrate {

	/**
	 * Attributes of `[products]` the block keeps.
	 */
	private const KEPT = array( 'skus', 'ids' );

	/**
	 * A subtitle made with bold on a line of its own (followed by a line break, a `<br>` or
	 * the end of the paragraph) → `<h3>`, with the same text. Bold inside a sentence is
	 * left as it is.
	 *
	 * @param string $html Description.
	 * @return array{html: string, count: int}
	 */
	public static function headings( string $html ): array {
		$count = 0;
		$h3    = static function ( string $title ) use ( &$count ): string {
			++$count;
			return '<h3>' . trim( $title ) . '</h3>';
		};
		// <p><strong>Title</strong></p> and <p><strong>Title</strong><br />rest</p>.
		$html = (string) preg_replace_callback(
			'#<p>[ \t]*<strong>([^<]{1,200})</strong>[ \t]*(?:</p>|<br\s*/?>\s*(.*?)</p>)#is',
			static function ( array $found ) use ( $h3 ): string {
				$rest = trim( $found[2] ?? '' );
				return $h3( $found[1] ) . ( '' === $rest ? '' : "\n<p>" . $rest . '</p>' );
			},
			$html
		);
		// Without paragraphs (wpautop adds them when the page is drawn): a line that is only
		// the bold text, ended by a line break, a <br> or the end of the description.
		$html = (string) preg_replace_callback(
			'#(^|\n)[ \t]*<strong>([^<]{1,200})</strong>[ \t]*(<br\s*/?>[ \t]*)?(?=\r?\n|$)#i',
			static fn( array $found ): string => $found[1] . $h3( $found[2] ),
			$html
		);
		return array(
			'html'  => $html,
			'count' => $count,
		);
	}

	/**
	 * `[products skus="a,b"]` (or `ids`) → `<!-- wp:lachinata/products {"skus":"a,b"} /-->`.
	 * Attributes the block does not have (limit, columns, orderby…) are reported, and a
	 * shortcode without skus or ids (by category, for example) is left as it is.
	 *
	 * @param string $html Description.
	 * @return array{html: string, count: int, dropped: string[], kept: string[]}
	 */
	public static function products( string $html ): array {
		$count   = 0;
		$dropped = array();
		$kept    = array();
		$html    = (string) preg_replace_callback(
			'/\[products(\s[^\]]*)?\]/i',
			static function ( array $found ) use ( &$count, &$dropped, &$kept ): string {
				$attributes = shortcode_parse_atts( trim( $found[1] ?? '' ) );
				$attributes = is_array( $attributes ) ? array_change_key_case( $attributes ) : array();
				$block      = array();
				foreach ( self::KEPT as $key ) {
					$list = array_values( array_filter( array_map( 'trim', explode( ',', (string) ( $attributes[ $key ] ?? '' ) ) ) ) );
					if ( $list ) {
						$block[ $key ] = implode( ',', 'ids' === $key ? array_map( 'absint', $list ) : array_map( 'sanitize_text_field', $list ) );
					}
				}
				if ( ! $block ) {
					$kept[] = $found[0];
					return $found[0];
				}
				++$count;
				foreach ( array_diff_key( $attributes, array_flip( self::KEPT ) ) as $key => $value ) {
					$dropped[] = is_int( $key ) ? (string) $value : $key . '="' . $value . '"';
				}
				return '<!-- wp:lachinata/products ' . wp_json_encode( $block, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . ' /-->';
			},
			$html
		);
		return array(
			'html'    => $html,
			'count'   => $count,
			'dropped' => $dropped,
			'kept'    => $kept,
		);
	}
}
