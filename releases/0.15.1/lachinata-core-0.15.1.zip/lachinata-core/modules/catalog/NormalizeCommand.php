<?php
/**
 * WP-CLI: wp lachinata catalog.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

use LaChinata\Core\Gtin;
use WP_CLI;

defined( 'ABSPATH' ) || exit;

/**
 * `wp lachinata catalog`: the one-off normalization of the old data (ACF, Rank Math, old
 * descriptions), the catalog health and the editorial package of the Spanish texts.
 */
final class NormalizeCommand {

	/**
	 * Copies the ACF values to the new meta. Idempotent: never overwrites an `_lc_*` value.
	 *
	 * Also: the main category of Rank Math (`rank_math_primary_product_cat`) when the
	 * product is still in it; the old EAN as GTIN when the product has none and its check
	 * digit is right; in the descriptions, subtitles in bold on a line of their own as `h3`
	 * and `[products skus="…"]` as the products block (text untouched). Reports (without
	 * writing) EANs that differ from the GTIN, values that cannot be read («500 mililitros»)
	 * and the shortcode attributes the block does not keep.
	 *
	 * ## OPTIONS
	 *
	 * [--dry-run]
	 * : Report only.
	 *
	 * [--from-shipping-class=<slug>]
	 * : Also marks the international exclusion (`_lc_excluir_internacional`) on the
	 * products of this shipping class (for example the class «Ocultar internacional»).
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata catalog normalize --dry-run
	 *     wp lachinata catalog normalize --from-shipping-class=ocultar-internacional
	 *
	 * @param string[]             $args       Positional arguments.
	 * @param array<string, mixed> $assoc_args Named arguments.
	 */
	public function normalize( array $args, array $assoc_args ): void {
		$dry_run = (bool) WP_CLI\Utils\get_flag_value( $assoc_args, 'dry-run', false );
		$class   = sanitize_title( (string) ( $assoc_args['from-shipping-class'] ?? '' ) );
		if ( '' !== $class && ! get_term_by( 'slug', $class, 'product_shipping_class' ) ) {
			WP_CLI::error( sprintf( 'No existe la clase de envío «%s».', $class ) );
		}
		$report = self::run( $dry_run, $class );

		foreach ( $report['problems'] as $line ) {
			WP_CLI::warning( $line );
		}
		WP_CLI::success(
			sprintf(
				'%1$s: %2$d valores de producto, %3$d iconos de sello, %4$d categorías principales, %5$d GTIN desde el EAN, %6$d subtítulos a h3 y %7$d bloques de productos; %8$d avisos.',
				$dry_run ? 'Simulación' : 'Normalizado',
				$report['product_values'],
				$report['term_values'],
				$report['main_categories'],
				$report['gtins'],
				$report['headings'],
				$report['product_blocks'],
				count( $report['problems'] )
			)
		);
		if ( '' !== $class ) {
			WP_CLI::success( sprintf( 'Exclusión internacional desde la clase «%1$s»: %2$d productos.', $class, $report['flag_values'] ) );
		}
	}

	/**
	 * Does the work; separated from the command for tests.
	 *
	 * @param bool   $dry_run        Report only.
	 * @param string $shipping_class Shipping class slug whose products get the international exclusion; '' to skip.
	 * @return array{product_values: int, term_values: int, flag_values: int, main_categories: int, gtins: int, headings: int, product_blocks: int, problems: string[]}
	 */
	public static function run( bool $dry_run, string $shipping_class = '' ): array {
		$report = array(
			'product_values'  => 0,
			'term_values'     => 0,
			'flag_values'     => 0,
			'main_categories' => 0,
			'gtins'           => 0,
			'headings'        => 0,
			'product_blocks'  => 0,
			'problems'        => array(),
		);

		$ids = get_posts(
			array(
				'post_type'      => 'product',
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
			)
		);

		foreach ( $ids as $id ) {
			$id = (int) $id;
			foreach ( Fields::LEGACY as $key => $legacy ) {
				if ( metadata_exists( 'post', $id, $key ) || ! metadata_exists( 'post', $id, $legacy ) ) {
					continue;
				}
				$raw   = get_post_meta( $id, $legacy, true );
				$value = Fields::from_legacy( $key, $raw );
				if ( null === $value || ( '' === $value && '' !== $raw ) ) {
					$report['problems'][] = sprintf( '#%1$d %2$s: no se entiende «%3$s».', $id, $legacy, is_scalar( $raw ) ? (string) $raw : wp_json_encode( $raw ) );
					continue;
				}
				if ( '' === $value ) {
					continue;
				}
				++$report['product_values'];
				if ( ! $dry_run ) {
					update_post_meta( $id, $key, $value );
				}
			}

			self::main_category( $id, $dry_run, $report );
			self::gtin( $id, $dry_run, $report );
			self::description( $id, $dry_run, $report );
		}

		$terms = get_terms(
			array(
				'taxonomy'   => TipoTaxonomy::TAXONOMY,
				'hide_empty' => false,
				'fields'     => 'ids',
			)
		);
		foreach ( is_array( $terms ) ? $terms : array() as $term_id ) {
			$term_id = (int) $term_id;
			if ( metadata_exists( 'term', $term_id, Fields::ICON ) ) {
				continue;
			}
			$icon = Fields::icon( $term_id );
			if ( $icon ) {
				++$report['term_values'];
				if ( ! $dry_run ) {
					update_term_meta( $term_id, Fields::ICON, $icon );
				}
			}
		}

		if ( '' !== $shipping_class ) {
			$report['flag_values'] = self::flag_class( $shipping_class, $dry_run );
		}

		return $report;
	}

	/**
	 * Main category from Rank Math, when the product has none yet and is still in it.
	 *
	 * @param int                  $id      Product id.
	 * @param bool                 $dry_run Report only.
	 * @param array<string, mixed> $report  Report.
	 */
	private static function main_category( int $id, bool $dry_run, array &$report ): void {
		$legacy = absint( get_post_meta( $id, Fields::LEGACY_MAIN_CATEGORY, true ) );
		if ( ! $legacy || metadata_exists( 'post', $id, Fields::MAIN_CATEGORY ) ) {
			return;
		}
		if ( ! has_term( $legacy, 'product_cat', $id ) ) {
			$report['problems'][] = sprintf( '#%1$d categoría principal de Rank Math %2$d: el producto ya no está en ella (no se copia).', $id, $legacy );
			return;
		}
		++$report['main_categories'];
		if ( ! $dry_run ) {
			update_post_meta( $id, Fields::MAIN_CATEGORY, $legacy );
		}
	}

	/**
	 * The old EAN as GTIN when the product has none and the EAN can exist; otherwise a
	 * warning when they differ.
	 *
	 * @param int                  $id      Product id.
	 * @param bool                 $dry_run Report only.
	 * @param array<string, mixed> $report  Report.
	 */
	private static function gtin( int $id, bool $dry_run, array &$report ): void {
		$ean = trim( (string) get_post_meta( $id, 'ean', true ) );
		if ( '' === $ean ) {
			return;
		}
		$product = wc_get_product( $id );
		$gtin    = $product ? (string) $product->get_global_unique_id() : '';
		if ( '' === $gtin && $product ) {
			if ( ! Gtin::valid( $ean ) ) {
				$report['problems'][] = sprintf( '#%1$d EAN «%2$s» sin GTIN: el dígito de control no cuadra (no se copia).', $id, $ean );
				return;
			}
			if ( ! $dry_run ) {
				try {
					$product->set_global_unique_id( Gtin::digits( $ean ) );
					$product->save();
				} catch ( \WC_Data_Exception $e ) {
					$report['problems'][] = sprintf( '#%1$d EAN «%2$s»: %3$s (no se copia).', $id, $ean, $e->getMessage() );
					return;
				}
			}
			++$report['gtins'];
			return;
		}
		if ( Gtin::digits( $gtin ) !== Gtin::digits( $ean ) ) {
			$report['problems'][] = sprintf( '#%1$d EAN «%2$s» ≠ GTIN «%3$s» (no se cambia).', $id, $ean, $gtin );
		}
	}

	/**
	 * Subtitles and `[products]` in the description and the short description.
	 *
	 * @param int                  $id      Product id.
	 * @param bool                 $dry_run Report only.
	 * @param array<string, mixed> $report  Report.
	 */
	private static function description( int $id, bool $dry_run, array &$report ): void {
		global $wpdb;
		$post = get_post( $id );
		if ( ! $post instanceof \WP_Post ) {
			return;
		}
		$changes = array();
		foreach ( array( 'post_content', 'post_excerpt' ) as $field ) {
			$headings                  = Migrate::headings( (string) $post->$field );
			$products                  = Migrate::products( $headings['html'] );
			$report['headings']       += $headings['count'];
			$report['product_blocks'] += $products['count'];
			if ( $products['dropped'] ) {
				$report['problems'][] = sprintf( '#%1$d [products]: el bloque no guarda %2$s.', $id, implode( ' ', array_unique( $products['dropped'] ) ) );
			}
			foreach ( $products['kept'] as $shortcode ) {
				$report['problems'][] = sprintf( '#%1$d %2$s: sin skus ni ids, se queda como está.', $id, $shortcode );
			}
			if ( $products['html'] !== $post->$field ) {
				$changes[ $field ] = $products['html'];
			}
		}
		if ( $changes && ! $dry_run ) {
			// Straight to the table: the block comments and the HTML are written as they are.
			$wpdb->update( $wpdb->posts, $changes, array( 'ID' => $id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- One-off migration.
			clean_post_cache( $id );
		}
	}

	/**
	 * Lists the catalog health (what La Chinata → Catálogo → Salud del catálogo shows).
	 *
	 * ## OPTIONS
	 *
	 * [--format=<format>]
	 * : table (by default), json or count.
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata catalog health
	 *     wp lachinata catalog health --format=count
	 *
	 * @param string[]             $args       Positional arguments.
	 * @param array<string, mixed> $assoc_args Named arguments.
	 */
	public function health( array $args, array $assoc_args ): void {
		$found  = Health::run();
		$format = (string) ( $assoc_args['format'] ?? 'table' );
		if ( 'count' === $format ) {
			WP_CLI::line( (string) Health::count( $found ) );
			return;
		}
		$rows = array();
		foreach ( Health::groups() as $group => $label ) {
			foreach ( $found[ $group ] as $row ) {
				$rows[] = array(
					'grupo'    => $label,
					'producto' => $row['id'],
					'nombre'   => $row['name'],
					'detalle'  => $row['detail'],
				);
			}
		}
		WP_CLI\Utils\format_items( 'json' === $format ? 'json' : 'table', $rows, array( 'grupo', 'producto', 'nombre', 'detalle' ) );
		WP_CLI::log( sprintf( '%d avisos.', Health::count( $found ) ) );
	}

	/**
	 * Exports the Spanish texts of the products as an editorial package (JSON): name, short
	 * description, description, label, SEO title and description, the alternative text of
	 * the images and the description of the variations that have one. Each text carries the
	 * fingerprint the import checks. Ingredients and nutrition are not in it.
	 *
	 * ## OPTIONS
	 *
	 * [--file=<file>]
	 * : Where to write it. Without it, to the screen.
	 *
	 * [--ids=<ids>]
	 * : Only these products (comma-separated ids).
	 *
	 * [--category=<slug>]
	 * : Only the products of this category and its subcategories.
	 *
	 * [--post-status=<status>]
	 * : Statuses of the products, comma-separated. By default, publish.
	 *
	 * [--source-status=<status>]
	 * : Only the products whose Spanish is pending or reviewed.
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata catalog export-editorial --file=editorial.json
	 *     wp lachinata catalog export-editorial --category=gourmet --source-status=pending
	 *
	 * @subcommand export-editorial
	 *
	 * @param string[]             $args       Positional arguments.
	 * @param array<string, mixed> $assoc_args Named arguments.
	 */
	public function export_editorial( array $args, array $assoc_args ): void {
		$ids     = Editorial::ids(
			array(
				'ids'      => array_filter( array_map( 'absint', explode( ',', (string) ( $assoc_args['ids'] ?? '' ) ) ) ),
				'category' => sanitize_title( (string) ( $assoc_args['category'] ?? '' ) ),
				'status'   => sanitize_text_field( (string) ( $assoc_args['post-status'] ?? '' ) ),
				'source'   => sanitize_key( (string) ( $assoc_args['source-status'] ?? '' ) ),
			)
		);
		$package = Editorial::export( $ids );
		$json    = (string) wp_json_encode( $package, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		$file    = (string) ( $assoc_args['file'] ?? '' );
		if ( '' === $file ) {
			WP_CLI::line( $json );
			return;
		}
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- WP-CLI writes a local file.
		if ( false === file_put_contents( $file, $json . "\n" ) ) {
			WP_CLI::error( sprintf( 'No se ha podido escribir %s.', $file ) );
		}
		WP_CLI::success( sprintf( '%1$d productos en %2$s.', count( $package['productos'] ), $file ) );
	}

	/**
	 * Imports an editorial package. A field is written only if the text on the site is
	 * still the one it was exported from (same fingerprint); otherwise it is a conflict and
	 * nothing of that field is written. Every name that changes is listed apart.
	 *
	 * ## OPTIONS
	 *
	 * <file>
	 * : The package (JSON of export-editorial).
	 *
	 * [--dry-run]
	 * : Report only.
	 *
	 * [--mark-reviewed]
	 * : Mark as «Revisado» each product that comes in whole (no conflict and no error).
	 *
	 * [--report=<file>]
	 * : Also writes the report as Markdown.
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata catalog import-editorial editorial.json --dry-run
	 *     wp lachinata catalog import-editorial editorial.json --mark-reviewed --report=informe.md
	 *
	 * @subcommand import-editorial
	 *
	 * @param string[]             $args       Positional arguments.
	 * @param array<string, mixed> $assoc_args Named arguments.
	 */
	public function import_editorial( array $args, array $assoc_args ): void {
		$file = (string) ( $args[0] ?? '' );
		if ( ! is_readable( $file ) ) {
			WP_CLI::error( sprintf( 'No se puede leer %s.', $file ) );
		}
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- WP-CLI reads a local file.
		$package = json_decode( (string) file_get_contents( $file ), true );
		if ( ! is_array( $package ) ) {
			WP_CLI::error( sprintf( '%s no es un JSON válido.', $file ) );
		}
		$dry_run = (bool) WP_CLI\Utils\get_flag_value( $assoc_args, 'dry-run', false );
		$report  = Editorial::import( $package, $dry_run, (bool) WP_CLI\Utils\get_flag_value( $assoc_args, 'mark-reviewed', false ) );

		foreach ( $report['names'] as $name ) {
			WP_CLI::log( sprintf( 'Nombre #%1$d: «%2$s» → «%3$s»', $name['id'], $name['before'], $name['after'] ) );
		}
		foreach ( $report['conflicts'] as $line ) {
			WP_CLI::warning( 'Conflicto: ' . $line );
		}
		foreach ( $report['errors'] as $line ) {
			WP_CLI::warning( $line );
		}
		$out = (string) ( $assoc_args['report'] ?? '' );
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- WP-CLI writes a local file.
		if ( '' !== $out && false === file_put_contents( $out, Editorial::markdown( $report, $dry_run ) ) ) {
			WP_CLI::warning( sprintf( 'No se ha podido escribir el informe en %s.', $out ) );
		}
		WP_CLI::success(
			sprintf(
				'%1$s: %2$d productos, %3$d campos cambiados, %4$d sin cambios, %5$d nombres cambiados, %6$d conflictos, %7$d errores y %8$d marcados como «Revisado».',
				$dry_run ? 'Simulación' : 'Importado',
				$report['products'],
				$report['updated'],
				$report['unchanged'],
				count( $report['names'] ),
				count( $report['conflicts'] ),
				count( $report['errors'] ),
				$report['reviewed']
			)
		);
	}

	/**
	 * Marks the international exclusion on the products of a shipping class (a variation
	 * of the class marks its parent). Products already marked are not counted.
	 *
	 * @param string $slug    Shipping class slug.
	 * @param bool   $dry_run Report only.
	 * @return int Products marked.
	 */
	private static function flag_class( string $slug, bool $dry_run ): int {
		$ids      = get_posts(
			array(
				'post_type'      => array( 'product', 'product_variation' ),
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- One-off command.
					array(
						'taxonomy' => 'product_shipping_class',
						'field'    => 'slug',
						'terms'    => $slug,
					),
				),
			)
		);
		$products = array();
		foreach ( $ids as $id ) {
			$parent     = wp_get_post_parent_id( (int) $id );
			$products[] = $parent ? $parent : (int) $id;
		}

		$count = 0;
		foreach ( array_unique( $products ) as $id ) {
			if ( Fields::get( $id, Fields::NO_SHIP_ABROAD ) ) {
				continue;
			}
			++$count;
			if ( ! $dry_run ) {
				update_post_meta( $id, Fields::NO_SHIP_ABROAD, '1' );
			}
		}
		return $count;
	}
}
