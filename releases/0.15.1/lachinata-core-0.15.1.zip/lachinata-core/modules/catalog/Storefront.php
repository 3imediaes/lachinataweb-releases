<?php
/**
 * Fills the theme hooks with the catalog data.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * Front-end side of the module. Prints nothing itself: answers the theme's filters.
 */
final class Storefront {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/category/tint', array( self::class, 'category_tint' ), 10, 2 );
		Hooks::add_filter( 'lachinata/product/tint', array( self::class, 'product_tint' ), 10, 2 );
		Hooks::add_filter( 'lachinata/product/unit_price', array( self::class, 'unit_price' ), 10, 2 );
		Hooks::add_filter( 'lachinata/product/content', array( self::class, 'content' ), 10, 2 );
		Hooks::add_filter( 'lachinata/product/tabs', array( self::class, 'tabs' ), 10, 2 );
		Hooks::add_filter( 'lachinata/product/seals', array( self::class, 'seals' ), 10, 2 );
		Hooks::add_filter( 'lachinata/product/details', array( self::class, 'details' ), 10, 2 );
		Hooks::add_filter( 'lachinata/product_card/badges', array( self::class, 'badges' ), 10, 2 );
		Hooks::add_filter( 'lachinata/product_card/marker', array( self::class, 'marker' ), 10, 2 );
		Hooks::add_filter( 'lachinata/product_card/image_id', array( self::class, 'card_image' ), 10, 2 );
		Hooks::add_filter( 'lachinata/product/main_category', array( self::class, 'main_category' ), 10, 2 );
		Hooks::add_filter( 'lachinata/product/notices', array( self::class, 'notices' ), 10, 2 );
		Hooks::add_filter( 'lachinata/product/cross_sell', array( self::class, 'cross_sell' ), 10, 2 );
		Hooks::add_filter( 'lachinata/catalog/categories', array( self::class, 'categories' ) );
	}

	/**
	 * Tint of a category.
	 *
	 * @param string   $tint Current tint.
	 * @param \WP_Term $term Category.
	 */
	public static function category_tint( string $tint, \WP_Term $term ): string {
		if ( 'product_cat' !== $term->taxonomy ) {
			return $tint;
		}
		$found = Fields::tint( $term->term_id );
		return '' === $found ? $tint : $found;
	}

	/**
	 * Tint of a product: the one of its main category; without one, the one of its deepest
	 * category that has (or inherits) one.
	 *
	 * @param string      $tint    Current tint.
	 * @param \WC_Product $product Product.
	 */
	public static function product_tint( string $tint, \WC_Product $product ): string {
		$id   = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();
		$main = Fields::main_category( $id );
		if ( $main && '' !== Fields::tint( $main ) ) {
			return Fields::tint( $main );
		}
		$terms = get_the_terms( $id, 'product_cat' );
		if ( ! is_array( $terms ) ) {
			return $tint;
		}
		usort( $terms, static fn( \WP_Term $a, \WP_Term $b ): int => count( get_ancestors( $b->term_id, 'product_cat', 'taxonomy' ) ) <=> count( get_ancestors( $a->term_id, 'product_cat', 'taxonomy' ) ) );
		foreach ( $terms as $term ) {
			$found = Fields::tint( $term->term_id );
			if ( '' !== $found ) {
				return $found;
			}
		}
		return $tint;
	}

	/**
	 * «500 ml | 9,33 € / 1 l». Variable products use their cheapest variation, so the
	 * unit price always matches a real price and content.
	 *
	 * @param string      $html    Current HTML.
	 * @param \WC_Product $product Product or variation.
	 */
	public static function unit_price( string $html, \WC_Product $product ): string {
		if ( $product instanceof \WC_Product_Variable ) {
			$prices = $product->get_variation_prices( true );
			$id     = array_key_first( $prices['price'] ?? array() );
			$cheap  = null === $id ? null : wc_get_product( $id );
			if ( ! $cheap instanceof \WC_Product ) {
				return $html;
			}
			$product = $cheap;
		}
		$formatted = UnitPrice::format( (float) wc_get_price_to_display( $product ), Fields::content( $product ), Fields::reference( $product ) );
		return '' === $formatted ? $html : $formatted;
	}

	/**
	 * Content of the product or variation («500 ml»).
	 *
	 * @param string      $content Content.
	 * @param \WC_Product $product Product.
	 */
	public static function content( string $content, \WC_Product $product ): string {
		$found = Fields::content( $product );
		return null === $found ? $content : $found->label();
	}

	/**
	 * Adds «Ingredientes» after the description and the description image.
	 *
	 * @param array<int, array{id: string, title: string, content: string}> $tabs    Tabs.
	 * @param \WC_Product                                                   $product Product.
	 * @return array<int, array{id: string, title: string, content: string}>
	 */
	public static function tabs( array $tabs, \WC_Product $product ): array {
		$id    = $product->get_id();
		$image = (int) Fields::get( $id, Fields::IMAGE );

		foreach ( $tabs as $index => $tab ) {
			if ( 'description' === $tab['id'] && $image ) {
				$tabs[ $index ]['content'] .= wp_get_attachment_image( $image, 'large', false, array( 'class' => 'lc-desc-image' ) );
			}
		}

		$ingredients = (string) Fields::get( $id, Fields::INGREDIENTS );
		if ( '' !== trim( wp_strip_all_tags( $ingredients ) ) ) {
			$position = (int) array_search( 'description', array_column( $tabs, 'id' ), true ) + 1;
			array_splice(
				$tabs,
				$position,
				0,
				array(
					array(
						'id'      => 'ingredients',
						'title'   => __( 'Ingredientes', 'lachinata-core' ),
						'content' => wpautop( wp_kses_post( $ingredients ) ),
					),
				)
			);
		}
		return $tabs;
	}

	/**
	 * Seals (`tipo` terms) with their icon.
	 *
	 * @param array<int, array{name: string, url: string, image_id: int}> $seals   Seals.
	 * @param \WC_Product                                                 $product Product.
	 * @return array<int, array{name: string, url: string, image_id: int}>
	 */
	public static function seals( array $seals, \WC_Product $product ): array {
		$terms = get_the_terms( $product->get_id(), TipoTaxonomy::TAXONOMY );
		foreach ( is_array( $terms ) ? $terms : array() as $term ) {
			$link    = get_term_link( $term );
			$seals[] = array(
				'name'     => $term->name,
				'url'      => is_string( $link ) ? $link : '',
				'image_id' => Fields::icon( $term->term_id ),
			);
		}
		return $seals;
	}

	/**
	 * Best-before date in the product details.
	 *
	 * @param array<int, array{label: string, value: string}> $rows    Rows.
	 * @param \WC_Product                                     $product Product.
	 * @return array<int, array{label: string, value: string}>
	 */
	public static function details( array $rows, \WC_Product $product ): array {
		$date = (string) Fields::get( $product->get_id(), Fields::BEST_BEFORE );
		if ( '' !== $date ) {
			$rows[] = array(
				'label' => __( 'Consumo preferente', 'lachinata-core' ),
				'value' => wp_date( get_option( 'date_format' ), (int) strtotime( $date . ' 12:00:00' ) ),
			);
		}
		return $rows;
	}

	/**
	 * The look of each product tag (tone, image and order of the term) and the product
	 * «etiqueta» as a neutral badge after the sale one.
	 *
	 * @param array<int, array{text: string, tone: string, image_id?: int, term_id?: int}> $badges  Badges.
	 * @param \WC_Product                                                                  $product Product.
	 * @return array<int, array{text: string, tone: string, image_id?: int, term_id?: int}>
	 */
	public static function badges( array $badges, \WC_Product $product ): array {
		$lead = array();
		$tags = array();
		$rest = array();
		foreach ( $badges as $index => $badge ) {
			$term_id = (int) ( $badge['term_id'] ?? 0 );
			if ( ! $term_id ) {
				if ( 'promo' === $badge['tone'] ) {
					$lead[] = $badge;
				} else {
					$rest[] = $badge;
				}
				continue;
			}
			$badge['tone']     = Fields::tag_tone( $term_id );
			$badge['image_id'] = absint( get_term_meta( $term_id, Fields::TAG_IMAGE, true ) );
			$tags[]            = array( (int) get_term_meta( $term_id, Fields::TAG_ORDER, true ), $index, $badge );
		}
		usort( $tags, static fn( array $a, array $b ): int => array( $a[0], $a[1] ) <=> array( $b[0], $b[1] ) );

		$label = (string) Fields::get( $product->get_id(), Fields::LABEL );
		if ( '' !== $label ) {
			$lead[] = array(
				'text' => $label,
				'tone' => '',
			);
		}
		return array_merge( $lead, array_column( $tags, 2 ), $rest );
	}

	/**
	 * Mark of the product's shipping class (a variation uses its own class, or the parent's).
	 *
	 * @param array{icon: string, label: string}|null|mixed $marker  Current mark.
	 * @param \WC_Product                                   $product Product.
	 * @return array{icon: string, label: string}|null|mixed
	 */
	public static function marker( $marker, \WC_Product $product ) {
		$found = Config::marker_for( $product->get_shipping_class() );
		return null === $found ? $marker : array(
			'icon'  => $found['card_icon'],
			'label' => $found['label'],
		);
	}

	/**
	 * «Imagen de tarjeta» of the product, when it is set and still exists.
	 *
	 * @param int         $image_id Current image.
	 * @param \WC_Product $product  Product.
	 */
	public static function card_image( int $image_id, \WC_Product $product ): int {
		$card = absint( get_post_meta( $product->get_id(), Fields::CARD_IMAGE, true ) );
		return $card && wp_attachment_is_image( $card ) ? $card : $image_id;
	}

	/**
	 * Main category of the product.
	 *
	 * @param int         $term_id Current category (the deepest one by default).
	 * @param \WC_Product $product Product.
	 */
	public static function main_category( int $term_id, \WC_Product $product ): int {
		$main = Fields::main_category( $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id() );
		return $main ? $main : $term_id;
	}

	/**
	 * The notice of a shipping class with a mark («Envío refrigerado»), with its conditions
	 * from the modules that know them (`lachinata/catalog/marker_conditions`): where it goes,
	 * what it costs, from when it is free, which days it leaves.
	 *
	 * @param array<int, array{tone: string, icon: string, html: string}> $notices Notices.
	 * @param \WC_Product                                                 $product Product.
	 * @return array<int, array{tone: string, icon: string, html: string}>
	 */
	public static function notices( array $notices, \WC_Product $product ): array {
		$class  = $product->get_shipping_class();
		$marker = Config::marker_for( $class );
		if ( null === $marker || ! $marker['notice'] ) {
			return $notices;
		}
		/**
		 * Sentences with the conditions of a shipping class for its notice on the product
		 * page, as plain text: `shipping` gives destinations, price and free shipping
		 * threshold; `eta`, the days it leaves.
		 *
		 * @since 0.12.2
		 *
		 * @param string[]    $sentences Sentences, none by default.
		 * @param string      $class     Shipping class slug.
		 * @param \WC_Product $product   Product.
		 */
		$sentences = array_filter( array_map( 'strval', (array) apply_filters( 'lachinata/catalog/marker_conditions', array(), $class, $product ) ) );
		$notices[] = array(
			'tone' => 'info',
			'icon' => $marker['notice_icon'],
			'html' => trim(
				sprintf(
					/* translators: 1: mark of the shipping class («Envío refrigerado»), 2: its conditions. */
					__( '<strong>%1$s.</strong> %2$s', 'lachinata-core' ),
					esc_html( $marker['notice_label'] ),
					esc_html( implode( ' ', $sentences ) )
				)
			),
		);
		return $notices;
	}

	/**
	 * Cross-sell title and source of the product's root category.
	 *
	 * @param array{title: string, source: string} $cross_sell Current title and source.
	 * @param \WC_Product                          $product    Product.
	 * @return array{title: string, source: string}
	 */
	public static function cross_sell( array $cross_sell, \WC_Product $product ): array {
		$id   = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();
		$main = Fields::main_category( $id );
		if ( ! $main ) {
			$terms = get_the_terms( $id, 'product_cat' );
			$main  = is_array( $terms ) && $terms ? $terms[0]->term_id : 0;
		}
		if ( ! $main ) {
			return $cross_sell;
		}
		$ancestors = get_ancestors( $main, 'product_cat', 'taxonomy' );
		$root      = get_term( $ancestors ? (int) end( $ancestors ) : $main, 'product_cat' );
		$own       = $root instanceof \WP_Term ? Config::cross_sell_for( $root ) : null;
		if ( null === $own ) {
			return $cross_sell;
		}
		return array(
			'title'  => '' !== $own['title'] ? $own['title'] : $cross_sell['title'],
			'source' => $own['source'],
		);
	}

	/**
	 * Store categories, with the campaigns running today.
	 *
	 * @param int[]|null|mixed $ids Current categories (null: every top-level one).
	 * @return int[]|null|mixed
	 */
	public static function categories( $ids ) {
		$own = Config::categories();
		return null === $own ? $ids : $own;
	}
}
