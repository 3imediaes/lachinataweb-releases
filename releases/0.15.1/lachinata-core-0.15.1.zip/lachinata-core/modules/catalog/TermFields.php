<?php
/**
 * Fields on the category (tint), seal (icon) and product tag (look of the badge) screens.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * Adds and saves the catalog term fields.
 */
final class TermFields {

	private const NONCE = 'lachinata_catalog_term';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'product_cat_add_form_fields', array( self::class, 'tint_add' ) );
		Hooks::add_action( 'product_cat_edit_form_fields', array( self::class, 'tint_edit' ) );
		Hooks::add_action( 'created_product_cat', array( self::class, 'save_tint' ) );
		Hooks::add_action( 'edited_product_cat', array( self::class, 'save_tint' ) );

		Hooks::add_action( TipoTaxonomy::TAXONOMY . '_add_form_fields', array( self::class, 'icon_add' ) );
		Hooks::add_action( TipoTaxonomy::TAXONOMY . '_edit_form_fields', array( self::class, 'icon_edit' ) );
		Hooks::add_action( 'created_' . TipoTaxonomy::TAXONOMY, array( self::class, 'save_icon' ) );
		Hooks::add_action( 'edited_' . TipoTaxonomy::TAXONOMY, array( self::class, 'save_icon' ) );

		Hooks::add_action( 'product_tag_add_form_fields', array( self::class, 'tag_add' ) );
		Hooks::add_action( 'product_tag_edit_form_fields', array( self::class, 'tag_edit' ) );
		Hooks::add_action( 'created_product_tag', array( self::class, 'save_tag' ) );
		Hooks::add_action( 'edited_product_tag', array( self::class, 'save_tag' ) );
	}

	/**
	 * Tint names for the select.
	 *
	 * @return array<string, string>
	 */
	private static function tint_options(): array {
		return array(
			''          => __( 'Sin tinta (hereda de la categoría superior)', 'lachinata-core' ),
			'cosmetica' => __( 'Cosmética', 'lachinata-core' ),
			'aceites'   => __( 'Aceites', 'lachinata-core' ),
			'gourmet'   => __( 'Gourmet', 'lachinata-core' ),
			'regalos'   => __( 'Regalos', 'lachinata-core' ),
			'hogar'     => __( 'Hogar', 'lachinata-core' ),
		);
	}

	/**
	 * Tint select.
	 *
	 * @param string $current Current value.
	 */
	private static function tint_select( string $current ): void {
		wp_nonce_field( self::NONCE, self::NONCE . '_nonce' );
		echo '<select name="lc_tint" id="lc_tint">';
		foreach ( self::tint_options() as $value => $label ) {
			printf( '<option value="%1$s"%2$s>%3$s</option>', esc_attr( $value ), selected( $current, $value, false ), esc_html( $label ) );
		}
		echo '</select>';
		echo '<p class="description">' . esc_html__( 'Color de la categoría en tiles, tarjetas y menú. Las subcategorías sin tinta usan la de su categoría superior.', 'lachinata-core' ) . '</p>';
	}

	/**
	 * Tint field on the «add category» form.
	 */
	public static function tint_add(): void {
		echo '<div class="form-field"><label for="lc_tint">' . esc_html__( 'Tinta', 'lachinata-core' ) . '</label>';
		self::tint_select( '' );
		echo '</div>';
	}

	/**
	 * Tint field on the «edit category» form.
	 *
	 * @param \WP_Term $term Term.
	 */
	public static function tint_edit( \WP_Term $term ): void {
		echo '<tr class="form-field"><th scope="row"><label for="lc_tint">' . esc_html__( 'Tinta', 'lachinata-core' ) . '</label></th><td>';
		self::tint_select( (string) get_term_meta( $term->term_id, Fields::TINT, true ) );
		echo '</td></tr>';
	}

	/**
	 * Saves the tint.
	 *
	 * @param int $term_id Term id.
	 */
	public static function save_tint( int $term_id ): void {
		$nonce = isset( $_POST[ self::NONCE . '_nonce' ] ) ? sanitize_key( wp_unslash( $_POST[ self::NONCE . '_nonce' ] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, self::NONCE ) || ! current_user_can( 'manage_product_terms' ) || ! isset( $_POST['lc_tint'] ) ) {
			return;
		}
		$tint = Fields::sanitize_tint( sanitize_key( wp_unslash( $_POST['lc_tint'] ) ) );
		if ( '' === $tint ) {
			delete_term_meta( $term_id, Fields::TINT );
		} else {
			update_term_meta( $term_id, Fields::TINT, $tint );
		}
	}

	/**
	 * Icon picker.
	 *
	 * @param int $attachment_id Current attachment id.
	 */
	private static function icon_picker( int $attachment_id ): void {
		wp_nonce_field( self::NONCE, self::NONCE . '_nonce' );
		Admin::image_picker( 'lc_icono', $attachment_id );
		echo '<p class="description">' . esc_html__( 'Imagen del sello que se muestra en la ficha de producto.', 'lachinata-core' ) . '</p>';
	}

	/**
	 * Icon field on the «add seal» form.
	 */
	public static function icon_add(): void {
		echo '<div class="form-field"><label for="lc_icono">' . esc_html__( 'Icono', 'lachinata-core' ) . '</label>';
		self::icon_picker( 0 );
		echo '</div>';
	}

	/**
	 * Icon field on the «edit seal» form.
	 *
	 * @param \WP_Term $term Term.
	 */
	public static function icon_edit( \WP_Term $term ): void {
		echo '<tr class="form-field"><th scope="row"><label for="lc_icono">' . esc_html__( 'Icono', 'lachinata-core' ) . '</label></th><td>';
		self::icon_picker( Fields::icon( $term->term_id ) );
		echo '</td></tr>';
	}

	/**
	 * Saves the icon.
	 *
	 * @param int $term_id Term id.
	 */
	public static function save_icon( int $term_id ): void {
		$nonce = isset( $_POST[ self::NONCE . '_nonce' ] ) ? sanitize_key( wp_unslash( $_POST[ self::NONCE . '_nonce' ] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, self::NONCE ) || ! current_user_can( 'manage_product_terms' ) || ! isset( $_POST['lc_icono'] ) ) {
			return;
		}
		update_term_meta( $term_id, Fields::ICON, absint( $_POST['lc_icono'] ) );
	}

	/**
	 * Tones a product tag can take, for the select.
	 *
	 * @return array<string, string>
	 */
	private static function tone_options(): array {
		return array(
			''        => __( 'Neutra (gris claro)', 'lachinata-core' ),
			'top'     => __( 'Top (azul)', 'lachinata-core' ),
			'new'     => __( 'Novedad (amarillo)', 'lachinata-core' ),
			'promo'   => __( 'Promoción (rojo)', 'lachinata-core' ),
			'olivita' => __( 'Olivita', 'lachinata-core' ),
		) + array_map(
			/* translators: %s: category tint. */
			static fn( string $label ): string => sprintf( __( 'Tinta de %s', 'lachinata-core' ), $label ),
			array_slice( self::tint_options(), 1, null, true )
		);
	}

	/**
	 * Fields of a product tag: tone, image and order.
	 *
	 * @param string $tone  Tone.
	 * @param int    $image Attachment id.
	 * @param int    $order Order.
	 * @param bool   $table Edit screen (table rows) or add screen.
	 */
	private static function tag_fields( string $tone, int $image, int $order, bool $table ): void {
		wp_nonce_field( self::NONCE, self::NONCE . '_nonce' );
		$fields = array(
			'lc_tono'   => array(
				__( 'Tono de la etiqueta', 'lachinata-core' ),
				static function () use ( $tone ): void {
					echo '<select name="lc_tono" id="lc_tono">';
					foreach ( self::tone_options() as $value => $label ) {
						printf( '<option value="%1$s"%2$s>%3$s</option>', esc_attr( $value ), selected( $tone, $value, false ), esc_html( $label ) );
					}
					echo '</select>';
				},
				__( 'Aspecto en la tarjeta y la ficha, de la lista de tonos del sistema.', 'lachinata-core' ),
			),
			'lc_imagen' => array(
				__( 'Imagen', 'lachinata-core' ),
				static fn() => Admin::image_picker( 'lc_imagen', $image ),
				__( 'Opcional: una imagen pequeña delante del texto, como una bandera. Es decorativa.', 'lachinata-core' ),
			),
			'lc_orden'  => array(
				__( 'Orden', 'lachinata-core' ),
				static fn() => printf( '<input type="number" name="lc_orden" id="lc_orden" value="%d" step="1" class="small-text">', (int) $order ),
				__( 'Las etiquetas se apilan de menor a mayor número; a igual número, por nombre.', 'lachinata-core' ),
			),
		);
		foreach ( $fields as $id => [ $label, $control, $help ] ) {
			if ( $table ) {
				printf( '<tr class="form-field"><th scope="row"><label for="%1$s">%2$s</label></th><td>', esc_attr( $id ), esc_html( $label ) );
			} else {
				printf( '<div class="form-field"><label for="%1$s">%2$s</label>', esc_attr( $id ), esc_html( $label ) );
			}
			$control();
			echo '<p class="description">' . esc_html( $help ) . '</p>';
			echo $table ? '</td></tr>' : '</div>';
		}
	}

	/**
	 * Fields on the «add tag» form.
	 */
	public static function tag_add(): void {
		self::tag_fields( '', 0, 0, false );
	}

	/**
	 * Fields on the «edit tag» form.
	 *
	 * @param \WP_Term $term Term.
	 */
	public static function tag_edit( \WP_Term $term ): void {
		self::tag_fields( Fields::tag_tone( $term->term_id ), absint( get_term_meta( $term->term_id, Fields::TAG_IMAGE, true ) ), (int) get_term_meta( $term->term_id, Fields::TAG_ORDER, true ), true );
	}

	/**
	 * Saves the look of a tag.
	 *
	 * @param int $term_id Term id.
	 */
	public static function save_tag( int $term_id ): void {
		$nonce = isset( $_POST[ self::NONCE . '_nonce' ] ) ? sanitize_key( wp_unslash( $_POST[ self::NONCE . '_nonce' ] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, self::NONCE ) || ! current_user_can( 'manage_product_terms' ) || ! isset( $_POST['lc_tono'] ) ) {
			return;
		}
		$values = array(
			Fields::TAG_TONE  => Fields::sanitize_tag_tone( sanitize_key( wp_unslash( $_POST['lc_tono'] ) ) ),
			Fields::TAG_IMAGE => absint( $_POST['lc_imagen'] ?? 0 ),
			Fields::TAG_ORDER => intval( sanitize_text_field( wp_unslash( $_POST['lc_orden'] ?? '0' ) ) ),
		);
		foreach ( $values as $key => $value ) {
			if ( '' === $value || 0 === $value ) {
				delete_term_meta( $term_id, $key );
			} else {
				update_term_meta( $term_id, $key, $value );
			}
		}
	}
}
