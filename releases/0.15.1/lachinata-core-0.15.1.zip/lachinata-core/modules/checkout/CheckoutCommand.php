<?php
/**
 * WP-CLI: wp lachinata checkout.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Checkout;

defined( 'ABSPATH' ) || exit;

/**
 * Composes the checkout page.
 */
final class CheckoutCommand {

	/**
	 * Creates or repairs the checkout page and composes it as the system wants it
	 * (Page.php): our block and the delivery instructions after the shipping options,
	 * express buttons at 44 px and «Pagar» with the total. Running it again changes nothing.
	 * Same as «Crear o reparar la página del checkout» in the Checkout tab.
	 *
	 * ## OPTIONS
	 *
	 * [--dry-run]
	 * : Prints the composed content without saving it.
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata checkout install-page
	 *
	 * @subcommand install-page
	 *
	 * @param string[]              $args       Positional arguments.
	 * @param array<string, string> $assoc_args Options.
	 */
	public function install_page( array $args, array $assoc_args ): void {
		unset( $args );
		$dry_run = isset( $assoc_args['dry-run'] );
		$result  = Page::install( $dry_run );
		if ( 'error' === $result['status'] ) {
			\WP_CLI::error( Page::message( $result ) );
		}
		if ( $dry_run ) {
			\WP_CLI::line( $result['content'] );
			return;
		}
		\WP_CLI::success( Page::message( $result ) );
	}
}
