# Módulo `checkout`

Extiende el checkout de bloques de WooCommerce con el sistema (fase 1 de «Checkout» en `design-system/sistema/03-implementacion.md`). El motor (impuestos, envíos, cupones, pasarelas, pedido) se queda en WooCommerce; el módulo no sustituye ningún bloque.

La página se lee en tarjetas (`CheckoutSection`, `.lc-chk`) sobre una columna `surface-2`, en el orden fijo de `design-system/sistema/02-plantillas.md`: **Contacto · Envío (dirección y método) · ¿Es un regalo? · Facturación · Pago**, con la fila exprés arriba y el resumen y un único «Pagar X €» con la línea legal abajo.

Las piezas nativas (campos, filas de envío y pago, resumen, botones exprés) llevan el HTML de WooCommerce vestido con tokens en `theme/assets/css/checkout.css`; lo propio (cabecera y pestañas de Facturación, avisos, salidas, hueco de regalo, gracias) lleva el `.lc-*` exacto del sistema. Condición de esa fase 1: el test de humo que vigila las clases de WooCommerce (abajo).

Ajustes (página de «Contactar», instrucciones para el repartidor) y huecos: WooCommerce → La Chinata → Checkout.

## Qué hace
| Pieza | Cómo (API de WooCommerce) | Dónde |
| --- | --- | --- |
| Composición de la página en el orden de las tarjetas: exprés · Contacto · dirección de entrega, métodos de envío, nuestro bloque tras el envío y la nota del pedido (Envío) · hueco del regalo · nuestras pestañas, los campos del pedido (Empresa, NIF), nuestra elección de dirección y la dirección de facturación de WooCommerce (Facturación) · Pago · línea legal · «Pagar». Los bloques que no conoce (de otro plugin) van, en su orden, antes de la línea legal. Botones exprés a 44 px y radio 0; «Pago cifrado» como nota de Pago; resumen sin la descripción corta de los productos; un primario «Pagar 69,85 €» (estilo `with-price`, separador espacio) | Orden de los bloques internos y atributos guardados en la página, también los de bloques anidados (`disableProductDescriptions` del bloque de artículos del resumen) | `Page.php`; botón «Crear o reparar la página del checkout» (pestaña Checkout) y `wp lachinata checkout install-page [--dry-run]`, los dos con `Page::install()`: crea la página si falta, le pone el checkout de bloques de WooCommerce si no lo tiene y la compone (idempotente; el seed lo ejecuta; **hay que ejecutarlo al actualizar desde la 0.5.x**). La salud avisa si la página falta o no está compuesta |
| Instrucciones para el repartidor (la nota del pedido, `customer_note`): **apagadas por defecto**. Con el ajuste, dentro de la tarjeta Envío | La nota sigue en la página, en su sitio; sin el ajuste se quita al servir la página (`render_block_data` sobre el área de campos) | `Page::render_data()`, ajuste `delivery_notes` (exportable) |
| Bloque `lachinata/checkout-after-shipping` (cierra la tarjeta Envío): aviso de la zona, aviso del envío gratis; sin envío, motivo (`Notice`), «Qué puedes hacer» (Dividir el pedido → `/bolsa/`, Cambiar dirección, Contactar; «Quitar de la bolsa» para lo que no viaja) y los envíos que el peso deja fuera, deshabilitados con su motivo (`ShippingOption` `disabled`) | Bloque interno (`registerCheckoutBlock`, `block.json` con padre `checkout-fields-block`); datos de `extensions['lachinata-shipping']` del módulo `shipping` (`StoreApi.php`, ExtendSchema) | `blocks/after-shipping/`, `src/after-shipping.js`, `src/components.js` |
| El motivo de «sin envío» una sola vez | El error de carrito `lachinata_shipping_<causa>` (lo sigue enviando `shipping`, que bloquea el pedido) se quita de los avisos de arriba; el tema oculta el aviso genérico de WooCommerce cuando hay `.lc-checkout-shipping--cause` | `src/notices.js`; `theme/assets/css/checkout.css` |
| Textos en la voz del sistema: títulos Contacto · Envío (con «Método de envío» dentro) · Pago, «Iniciar sesión», «bolsa» y no «carrito», errores como instrucción, «Pagar» | Filtro `i18n.gettext_woocommerce` de `@wordpress/hooks` sobre las cadenas de origen de WooCommerce | `src/texts.js` |
| Provincia rellenada desde el código postal en España (visible y editable: solo cambia cuando cambian los dos primeros dígitos) | `wc/store/cart` → `setShippingAddress`/`setBillingAddress` | `src/fields.js`, `Provinces.php` |
| Teclado numérico en el código postal (países con códigos solo de cifras, filtro `lachinata/checkout/numeric_postcodes`), «Solo para la entrega.» bajo el teléfono (que ocupa su línea) y, en España, «Se rellena con el código postal.» bajo la provincia | **Sin API**: atributo `inputmode` y un `span.lc-field__help` sobre el HTML que pinta WooCommerce; mejora progresiva (abajo) | `src/fields.js` |
| Tarjeta Facturación, antes de Pago e independiente del método: cabecera (icono `receipt`) y pestañas **Particular \| Empresa / Autónomo** (la segunda muestra Empresa y NIF/CIF, obligatorios, de dos en dos); «La misma dirección que la de entrega» (por defecto) o «Usar otra dirección de facturación», que abre la dirección de facturación de WooCommerce en un panel `surface-2` (país, nombre, apellidos, dirección, piso, código postal, ciudad y provincia; el teléfono se oculta y sigue al de entrega). Con una bolsa que no se envía no hay elección: la de facturación es la única dirección | Bloques `lachinata/checkout-billing-type` (`src/billing-type.js`: la pestaña marca la casilla `lachinata/company-invoice` con la acción pública `setAdditionalFields`, mismas reglas que en la 0.5.1, y el tema oculta la casilla) y `lachinata/checkout-billing` (`src/billing.js`, con la acción interna `__internalSetUseShippingAsBilling`, ver «Riesgos conocidos»); campos adicionales en `order` con reglas `required`/`hidden` sobre la casilla | `Page.php`, `src/billing-type.js`, `src/billing.js`, `src/fields.js`, `Invoice.php` |
| Factura de empresa: Empresa y NIF validados contra el país de facturación (NIF, NIE o CIF con su control en España; NIF-IVA con prefijo en la UE, solo el formato; cualquier identificador fuera), guardados en `_lc_empresa` y `_lc_nif`; en el pedido (bajo la facturación), en los correos y en la API REST (`lachinata.invoice`; `lachinata_invoice` queda como alias de la 0.5.1); acción `lachinata/checkout/invoice_details` para Odoo. Después de pagar (los pagos exprés no traen NIF), «¿Necesitas factura con NIF?» en gracias y en el pedido de la cuenta | `woocommerce_validate_additional_field`, `woocommerce_store_api_checkout_order_processed`, `woocommerce_email_order_meta_fields`, `woocommerce_rest_prepare_shop_order_object` | `Invoice.php`, `TaxId.php` |
| Dirección: País, Teléfono (obligatorio), Nombre, Apellidos, Dirección, Piso/puerta, Código postal, Ciudad, Provincia. La provincia solo donde el país la tiene (WooCommerce) y además oculta en `Fields::NO_STATE` (filtro `lachinata/checkout/no_state_countries`): hoy **DE** (los Länder no forman parte de la dirección postal). Ampliar la lista ahí | Locale de WooCommerce (`priority`, `hidden`) y `woocommerce_checkout_phone_field` = obligatorio (también lo pide Stripe a la cartera en el pago exprés) | `Fields.php` |
| «Guardar mis datos» **fuera del checkout** (0.6.0): en gracias, a quien no tiene cuenta, «Crear mi cuenta» con un clic, con el correo de WooCommerce para poner la contraseña; los pedidos anteriores de ese correo pasan a la cuenta. La casilla nativa de WooCommerce (Contacto, con contraseña) se apaga. Los pedidos de la 0.5.x que llevan la casilla marcada (`_wc_other/lachinata/save-details`) siguen creando su cuenta al quedar pagados | `woocommerce_order_status_*`; `wc_create_new_customer` con contraseña generada; la página de pedido recibido sigue visible una hora con la clave aunque el pedido ya sea de un cliente (`woocommerce_order_received_verify_known_shoppers`), porque el cliente aún no tiene contraseña | `Account.php` |
| Autocompletado de dirección: preparado sin proveedor. Con uno en `lachinata/checkout/address_lookup` (una clase que implemente `Address\AddressLookup`), pasa a ser el proveedor de WooCommerce y el navegador le pregunta a nuestras rutas `lachinata/v1/address/search` y `/select` (límite de 60 por minuto y visitante), nunca al servicio | `woocommerce_address_providers` y `wc.addressAutocomplete.registerAddressAutocompleteProvider` | `Address/`, `src/address.js` |
| Hueco del regalo (incremento 5): su propia tarjeta entre Envío y Facturación; sin el módulo no se pinta nada | *Slot* `lachinata/checkout/gift` (bloque `lachinata/checkout-gift`): el *fill* pinta la tarjeta entera, `CheckoutSection` plegada (`lc-chk lc-chk--quiet`, icono `gift`, «¿Es un regalo?») con `GiftOption`. Además, *slots* `lachinata/checkout/after-shipping` (al final de la tarjeta Envío) y `lachinata/checkout/summary` (dentro de `ExperimentalOrderMeta`); acción PHP `lachinata/checkout/after_shipping`, solo para registrar campos y script | `src/gift.js`, `src/after-shipping.js`, `src/summary.js`, `Integration.php` |
| API para Odoo: el objeto `lachinata` de cada pedido en la API REST (`invoice`, `newsletter`; el resto lo rellenan el núcleo y los otros módulos) | Filtro `lachinata/rest/order` del núcleo (`plugin/src/Rest/OrderData.php`); contrato en `docs/api-odoo.md` | `Invoice.php` (`newsletter` lo añade el módulo `newsletter`) |
| Carga del script | `IntegrationInterface` en `woocommerce_blocks_checkout_block_registration`: WooCommerce lo carga antes de pintar el checkout y le pasa `lachinata-checkout_data` (`wcSettings`) | `Integration.php` |

Del tema (funciona sin el módulo): cabecera reducida («Volver a la bolsa», logo y, en escritorio, «Pago cifrado»), las tarjetas sobre `surface-2`, 7/12 + 5/12 con el resumen a la derecha (sin `UspBar`: las ventajas no ayudan a pagar) y el aspecto de todas las piezas (`theme/assets/css/checkout.css`). El resumen se queda fijo bajo la cabecera (72 px + `space-8`) solo si cabe en la ventana; si no, o sin JavaScript, se desplaza con la página y nunca tapa el primer producto (`theme/src/js/checkout-summary.js`). Sin el módulo, la página de serie de WooCommerce queda con una tarjeta por paso.

El ajuste de WooCommerce «Permitir a los clientes acceder a una cuenta existente durante el pago» (`woocommerce_enable_checkout_login_reminder`) pone «Iniciar sesión» a la derecha de Contacto; el seed lo activa y está en `docs/despliegue-checkout.md`.

El bloque propio no tiene vista en el editor: la página no se edita a mano, se compone con el botón o el comando. Si alguien lo borra en el editor, WooCommerce lo vuelve a añadir al final del área de campos (está bloqueado para borrar); `install-page` lo devuelve a su sitio.

Rellenar un *slot* desde otro módulo (el regalo pinta su tarjeta entera, `plugin/modules/gift/src/index.js`):

```js
const { Fill } = wc.blocksCheckout.createSlotFill( 'lachinata/checkout/gift' );
wp.plugins.registerPlugin( 'lachinata-gift', {
	scope: 'woocommerce-checkout',
	render: () => (
		// El Fill de WooCommerce clona su hijo con los props del hueco: { cart, extensions }.
		<Fill>
			<GiftCard />
		</Fill>
	),
} );
```

## Lo que se quita del checkout y del resto del sitio
Es la lista de lo que puede romper una actualización de WordPress, WooCommerce o una pasarela. Cada entrada dice por qué se quita y qué lo vigila. El test de humo es `tests/e2e/checkout.spec.mjs` (`npm run test:e2e`, job `e2e` de la CI, obligatorio para fusionar).

| Qué | Dónde | Por qué | Lo vigila |
| --- | --- | --- | --- |
| `wp-components` (266 KB comprimido) como dependencia de `wp-notices`, **solo en el checkout** | `Assets::lighten()`, en `wp_print_footer_scripts` | Desde WordPress 7.1, `wp-notices` depende de `wp-components` para sus `InlineNotices`/`SnackbarNotices`, que solo carga al pintarlos; el checkout de bloques usa el store de avisos y no los pinta. Se comprueba en cada petición sobre la cola: si otro script encolado (o una de sus dependencias) necesita `wp-components`, se queda y queda anotado en Huecos de configuración con el nombre del script. | Test de humo «el checkout se pinta…» (no se carga `components.min.js` y no hay errores en consola); `tests/AssetsTest.php` (la regla de la cola). |
| Precarga de `wp-components` en el resto de páginas | `Assets::prefetch()` | Con artículos en la bolsa, WooCommerce precarga los scripts del checkout en todas las páginas; `wp-components` ya no lo usa el checkout. Vuelve en cuanto un checkout lo haya necesitado (hay una entrada en Huecos de configuración). | Test de humo de la ficha; `tests/AssetsTest.php`. |
| Precargas del bloque de bolsa (`cart-frontend.js` y sus dependencias), **en todo el sitio** | Tema, `theme/inc/assets.php` (`lachinata_drop_cart_block_prefetch()`) | La página de bolsa de WooCommerce contiene el bloque de bolsa, así que WooCommerce lo precarga con la bolsa llena; pero la bolsa es `/bolsa/` (`templates/cart-page.php`) y nunca lo pinta. En el checkout eran 53 ficheros. Las precargas del checkout en el resto de páginas se mantienen. | Test de humo del checkout, de la bolsa y de la ficha (sin `prefetch` de `cart-frontend`). |
| Scripts del checkout clásico en el checkout de bloques (`wc-checkout` y, con él, jQuery, `woocommerce`, `wc-country-select`, `wc-address-i18n`, `wc-custom-place-order-button`, blockUI, js-cookie; `selectWoo`, `wc-address-autocomplete`, `wc-password-strength-meter`) | Tema, `theme/inc/assets.php` (`lachinata_dequeue_assets()`) | El bloque de checkout los quita desde su `render()` (`Checkout::dequeue_woocommerce_core_scripts`), que en un tema clásico se ejecuta después de `wp_enqueue_scripts`: nunca llega a quitarlos. Es la misma lista que usa el bloque. Solo en el formulario de checkout; pagar un pedido y pedido recibido usan las plantillas clásicas y los conservan. | Test de humo del checkout (ni `frontend/checkout.js` ni jQuery). |
| Visor del registro de depuración de Octolize (`wpdesk_wc_shipping_notices_*`) para clientes | Módulo `shipping`, `Live\OctolizeDhlProvider::dequeue_log_viewer()` | Octolize lo carga en la bolsa y el checkout para todos (y en todo el front para gestores), aunque solo los gestores ven el registro; usa jQuery sin declararlo y da un error en el checkout sin jQuery. Los gestores lo conservan. | Test de humo del checkout, la bolsa y la ficha (sin errores y sin su script), en local con Octolize instalado; la CI no instala Octolize. |
| Script de Stripe para el checkout clásico (`wc-stripe-upe-classic`), **en el checkout de bloques** | `Gateways::dequeue()`, en `wp_footer` (Stripe lo encola ahí, prioridad 10) | Stripe lo encola en cualquier checkout; en el de bloques trabaja su integración de bloques (`wc-stripe-blocks-integration`) y este script solo arrastra `wc-checkout` y jQuery. | Test de humo «el checkout se pinta…» (sin `upe-classic` ni `frontend/checkout.js`); `tests/e2e/payments.spec.mjs`: pedido con tarjeta, con 3D Secure y con PayPal (local, con pasarelas). |
| Scripts de Stripe (`stripe.js`, `wc-stripe-*`) **en la ficha y en la bolsa** | `Gateways::dequeue()` | El pago exprés va solo en el checkout (Alberto: ficha y bolsa, apagados; la bolsa queda como opción futura), pero Stripe carga `stripe.js` en las dos igualmente. | Test de humo de la bolsa y de la ficha (ni `js.stripe.com` ni el plugin de Stripe). |
| Scripts y estilos de PayPal (`ppcp-*`, `wc-ppcp-*`) **mientras PayPal no está disponible** (sin conectar o apagado), también como dependencias del script del checkout de bloques | `Gateways::dequeue_unavailable()` | Sin conectar, PayPal carga su SDK v6 en el checkout y la ficha, que falla (token, jQuery). Es el estado de un sitio recién desplegado y de la CI. | Job `e2e` de la CI (Stripe y PayPal activos sin claves): test de humo completo sin errores. |
| (Se añade) jQuery como dependencia de `ppcp-checkout-block` | `Gateways::declare_jquery()` | El script de bloques de PayPal usa jQuery sin declararlo; el tema no carga jQuery. | Test de humo: jQuery solo aparece con el script de PayPal; pedidos de prueba con PayPal. |
| (Se añade) `preconnect` a `js.stripe.com` y `api.stripe.com` en el checkout | `Gateways::preconnect()` | Los botones exprés de Stripe van arriba. | `tests/GatewaysTest.php`. |
| Scripts y estilos de Stripe y PayPal (`stripe`, `wc-stripe-*`, `stripelink*`, `ppcp-*`, `wc-ppcp-*`), también como dependencias, y la precarga del pago exprés de Stripe, **en la página de gracias** (0.8.0) | `Gateways::dequeue_order_received()`, `Gateways::order_received_preloads()` | Gracias es un *endpoint* de la página del checkout y las pasarelas cargan allí lo del checkout (`stripe.js` con sus marcos, los métodos de PayPal), sin nada que pagar: 3D Secure y PayPal terminan en el checkout o en la pasarela antes de llegar a gracias, y «Pagar el pedido» es otra página. Lighthouse de gracias, de 44–78 a 99 | `tests/GatewaysTest.php`; e2e de pagos (3D Secure y PayPal llegan a gracias) |
| Scripts del checkout de bloques (`wc-checkout*`, `wc-blocks-checkout`, `wc-cart-checkout-*`, `wc-payment-method-*`, `lachinata-checkout`, `lachinata-gift`, `lachinata-shipment`) **en la página de gracias** (0.8.0); los estilos se quedan | `Assets::order_received()` | WooCommerce los encola allí por ser la página del checkout, en el `<head>`, y bloqueaban el primer pintado (5 s en móvil). Gracias es la plantilla PHP del tema: sus formularios («Crear mi cuenta», factura con NIF) no los usan | `tests/GatewaysTest.php`; e2e de gracias |
| `selectWoo` (y con él jQuery) **en la página de gracias** | Tema, `lachinata_dequeue_assets()` | WooCommerce lo encola en todas las páginas del checkout y la cuenta; gracias no tiene desplegables | e2e de gracias |

Si una actualización hace saltar el test: mira primero qué entrada de la tabla toca. Una clase de `checkout.css` que WooCommerce ya no pinta se quita o se cambia en `checkout.css` (y la tabla de abajo no cambia); un script que vuelve a cargarse se investiga antes de tocar el test.

## Clases de WooCommerce que viste el tema
El test «existen las clases de WooCommerce que viste checkout.css» lee todas las clases `wc-block-*` y `wc-blocks-*` de `theme/assets/css/checkout.css` y exige que cada una aparezca en el DOM del checkout en alguno de sus estados (sin dirección, con errores de validación, con la nota del pedido abierta, con dirección y tarifas) o, si solo existe en otros estados, como literal en los scripts de WooCommerce que carga la página. WooCommerce declara privadas esas clases (`docs/theming/block-theme-development/css-styling.md`): pueden cambiar en cualquier versión.

Primera alarma, al crear el test con WooCommerce 11.2.1: `wc-block-components-combobox` y `wc-block-components-combobox-control` ya no existían (el país es un `select`); se quitaron de `checkout.css`.

## Lo que se toca por encima de WooCommerce sin API
Además de la tabla anterior, se hacen sobre el HTML o el estado que pinta WooCommerce porque su API de campos no lo permite: `inputmode="numeric"` en el código postal, las ayudas bajo el teléfono y la provincia y el teléfono de facturación copiado del de entrega (`src/fields.js`). Son **mejora progresiva**: si WooCommerce cambia los ids `*-postcode`/`*-phone`/`*-state` o el HTML de alrededor, dejan de aplicarse y el checkout sigue funcionando (todo va dentro de un `try`). Lo vigila el test «mejora progresiva…», que sirve nuestro script con los ids cambiados y una excepción dentro y hace un pedido.

**Tarjetas agrupadas solo con CSS.** Envío (dirección + método + nuestro bloque + nota) y Facturación (pestañas + campos del pedido + elección + dirección de facturación) son pasos hermanos de WooCommerce: no se puede envolver un bloque suyo en uno nuestro. El tema pinta cada paso como tarjeta y pega al anterior el que lo sigue en su grupo (`:has(+ …)` y `+`), sin separación, sin borde ni radio entre los dos. Lo vigila `tests/e2e/checkout-cards.spec.mjs` a 390 y 1440: orden de las tarjetas, separación `space-3`/`space-4`, cada grupo de una pieza (mismos lados, borde superior solo en el primero, inferior solo en el último, radios solo en las esquinas de fuera, sin hueco entre pasos), sin hueco bajo la cabecera, filas de campos, ayudas y resumen. Quitando a propósito una de las reglas de unión, el test falla y dice qué paso y qué borde.

## Pasarelas
Configuración de prueba en local con `tools/seed-payments.php` (lee `LACHINATA_DEV_*` de `.wp-env.override.json`, nunca las imprime) y procedimiento en `docs/despliegue-checkout.md`:

- **Stripe:** tarjeta como `PaymentOption` (se monta al cargar: es el método por defecto) y, en la fila exprés, solo Apple Pay y Google Pay, solo en el checkout, a 44 px y con esquinas rectas. Sin Link ni Amazon Pay.
- **PayPal:** solo en la sección de Pago. Con PayPal Payments 4.2 (SDK v6), fuera de la fila exprés PayPal no pinta botón propio: el botón de WooCommerce lleva al cliente a PayPal, y dice «Pagar con PayPal» (`woocommerce_paypal_payments_blocks_payment_method_data`). Por eso su SDK no se carga en el checkout y no hay nada que diferir. Sin Paga Más Tarde ni sus mensajes, que eran lo que cargaba el SDK en ficha y bolsa.
- **Pendiente de decidir:** Stripe también encola en el checkout de bloques `wc_stripe_express_checkout` (su pago exprés para páginas clásicas, con jQuery y lodash); la fila exprés de bloques la registra su integración de bloques. Quitarlo no está aprobado ni se puede comprobar en local (Apple Pay y Google Pay no aparecen en un Chrome sin cartera).
- **Solo desarrollo:** el SDK v6 de PayPal no acepta `localhost` como dominio (`invalid_domain`): en local el sitio va en `http://127.0.0.1.nip.io:8888` y Chrome lo trata como seguro (`--unsafely-treat-insecure-origin-as-secure`, en `playwright.config.mjs` y `tools/lighthouse.mjs`). `WP_BASE_URL=http://127.0.0.1.nip.io:8888 npm run test:e2e`.

## Página de pago y tarjeta del pedido
- **order-pay** (el enlace «Pagar {total}» del pedido telefónico y del pago fallido) es formulario clásico: la viste el tema con `theme/woocommerce/checkout/form-pay.php` (tarjetas «Tu pedido» y «Pago», métodos como `PaymentOption`), conservando `#order_review`, `#payment`, los ids, las acciones y el nonce de WooCommerce, que necesitan Stripe, PayPal y `checkout.js`.
- **`PayForOrder`:** Stripe en order-pay como en el checkout. Su fila exprés (Apple Pay y Google Pay, la imprime Stripe con `woocommerce_pay_order_before_payment` cuando el pago exprés está activo en el checkout) a 44 px y sin esquinas (`wc_stripe_express_checkout_params`); cuando aparece, se muestra el «o» del tema (`.lc-pay__or`) y los textos con `data-lc-wallets` pasan a nombrar las carteras. La apariencia del formulario de tarjeta (`wc_stripe_upe_params.appearance`) se arma en el navegador con los tokens del tema: control de 44 px, borde `line-strong` como los campos del checkout, radio 0, DIN y el foco del sistema; DIN llega al marco de Stripe con las hojas de la tienda (`wc_stripe_upe_permitted_font_domains`, necesita CORS en las fuentes). `lachinata/checkout/wallets` dice al tema si la tienda ofrece carteras.
- **`CardDetails`:** al completarse un pago de Stripe guarda en `_lc_tarjeta` los cuatro últimos dígitos y la cartera (Apple Pay, Google Pay); en pedidos anteriores lo lee una vez, al pedirlo. Lo da por `lachinata/order/payment_label` («Tarjeta ···· 4242»). Nada se guarda antes del pago.

## Rendimiento
`npm run lighthouse` mide también el checkout con la bolsa llena y una dirección de Plasencia (job informativo `lighthouse` de la CI). Mide con la depuración apagada (`CLAUDE.md`).

| Medición (WooCommerce 11.2.1, WordPress 7.1.3, sin pasarelas) | Rendimiento | LCP | Peso |
| --- | --- | --- | --- |
| Checkout de serie | 67 | 14,2 s | 2.047 KB |
| Sin precargas del bloque de bolsa ni scripts del checkout clásico | 70–75 | 6,7 s | 839 KB |
| Además, sin `wp-components` (lo que hay hoy) | 79 (76–81) | 4,9 s | 529 KB |

Con las pasarelas (23/10/2026, después de las decisiones de Alberto y de lo que quita `Gateways.php`; origen `127.0.0.1.nip.io`, mediana de 5):

| Checkout | Rendimiento | LCP | JS |
| --- | --- | --- | --- |
| Sin pasarelas | 77 (73–78) | 5,3 s | 402 KB |
| Stripe: tarjeta y pago exprés | 67 (64–67) | 7,3 s | 2.507 KB |
| Stripe: tarjeta, sin pago exprés | 61 (55–66) | 7,3 s | 1.485 KB |
| Stripe y PayPal | 66 (64–71) | 7,9 s | 2.493 KB |

| Bolsa con artículos | Rendimiento |
| --- | --- |
| Sin pasarelas | 94 |
| Stripe y PayPal | 96 (antes de quitar Stripe y los mensajes de PayPal de la bolsa: 87) |

Con la página en tarjetas (0.6.0, misma medición): checkout **66 (66–70)**, accesibilidad 100, CLS 0,061. Dos arreglos para no perder la puntuación: el acordeón del resumen a todo el ancho en móvil va por media query y no por la clase `is-mobile`, que WooCommerce pone con JS después de pintar (movía la página: CLS 0,48), y el control de tarifas, que WooCommerce pinta vacío y llena un instante después, reserva el alto de una opción (CLS 0,38 → 0,06). Textos secundarios sobre `surface-2` en `ink-soft`: `ink-muted` da 4,47:1 sobre `surface-2`, por debajo de AA.

El pago exprés (Apple Pay y Google Pay) suma ~1 MB de JS de Stripe pero no mueve la puntuación ni el LCP de forma medible (la diferencia queda dentro de la dispersión). Lo que cuesta es el formulario de tarjeta de Stripe (Payment Element), que se monta al cargar por ser el método por defecto: con él, el checkout no pasa de ~67. PayPal ya no carga nada pesado en el checkout.

Las precargas de WooCommerce se guardan en el transitorio `woocommerce_block_asset_resource_hints`, cuya clave no tiene en cuenta `SCRIPT_DEBUG`: si se generó con la depuración encendida, apuntan a los ficheros sin minificar. Al medir en local tras apagar la depuración: `wp-env run cli wp transient delete woocommerce_block_asset_resource_hints`.

## Depende de

Ningún módulo. WooCommerce 10 con el checkout de bloques. Los datos de «sin envío» llegan de `shipping` por la Store API (`extensions['lachinata-shipping']`): sin `shipping`, el bloque tras el envío no pinta motivo ni salidas. Los huecos (`lachinata/checkout/gift`, `after-shipping`, `summary`) los rellenan otros módulos con *fills* de JS; sin ellos, quedan vacíos.

## Hooks que escucha

- Página y bloques: `render_block_data` (nota del pedido), `woocommerce_blocks_checkout_block_registration` (script), `init` (bloques propios), `wp_enqueue_scripts`, `wp_resource_hints`, `wp_preload_resources`, `wp_print_footer_scripts`, `wp_footer`.
- Campos y validación: `woocommerce_init`, `woocommerce_get_country_locale(_default)`, `woocommerce_validate_additional_field`, `woocommerce_store_api_checkout_order_processed`, `pre_option_woocommerce_checkout_phone_field`, `pre_option_woocommerce_address_autocomplete_enabled`, `woocommerce_address_providers`.
- Cuenta: `pre_option_woocommerce_enable_signup_and_login_from_checkout`, `woocommerce_order_status_*`, `template_redirect`, `woocommerce_order_received_verify_known_shoppers`.
- Pasarelas: `wc_stripe_express_checkout_params`, `wc_stripe_upe_permitted_font_domains`, `gettext_woocommerce-gateway-stripe`, `woocommerce_paypal_payments_blocks_payment_method_data`, `woocommerce_pre_payment_complete` (tarjeta).
- Pedido y correos: `woocommerce_admin_order_data_after_billing_address`, `woocommerce_email_order_meta_fields`, `woocommerce_rest_prepare_shop_order_object`, `woocommerce_view_order`.
- Del tema: `lachinata/thankyou/account`, `lachinata/thankyou/invoice`, `lachinata/order/payment_label`, `lachinata/checkout/wallets`. Del núcleo: `lachinata/rest/order`, `lachinata/core/admin_tabs`, `rest_api_init` (rutas propias).

## Hooks que emite

| Hook | Tipo | Para qué |
| --- | --- | --- |
| `lachinata/checkout/after_shipping` | acción | Registrar campos y scripts de los *slots* |
| `lachinata/checkout/address_lookup` | filtro | Proveedor de autocompletado de dirección |
| `lachinata/checkout/numeric_postcodes`, `lachinata/checkout/no_state_countries` | filtro | Países con códigos numéricos; países sin provincia |
| `lachinata/checkout/invoice_details` `( WC_Order $order )` | acción | El pedido recibe su factura de empresa |

*Slots* de JS: `lachinata/checkout/gift`, `lachinata/checkout/after-shipping`, `lachinata/checkout/summary` (arriba). Catálogo con versiones: `plugin/HOOKS.md`.

## Datos que guarda

- Metadatos de pedido: `_lc_empresa`, `_lc_nif` (factura de empresa), `_lc_tarjeta` (últimos dígitos y cartera), `_lc_account`, `_lc_account_at` (oferta de cuenta en gracias). Lee `_wc_other/lachinata/save-details` de pedidos de la 0.5.x.
- Opciones `lachinata_checkout_*`: ajustes y registro de huecos (`lachinata_checkout_gaps`).
- La composición de la página (orden y atributos de bloques) se guarda en la propia página de checkout de WooCommerce.

## REST y API para Odoo

- `lachinata.invoice` del objeto de la API de pedidos; `lachinata_invoice` en la raíz como alias obsoleto desde la 0.6.1 (`docs/api-odoo.md`).
- Rutas propias: `GET /lachinata/v1/address/search` y `/address/select` (solo con proveedor), `POST /lachinata/v1/checkout/gap`.

## Ajustes y exportación

| Ajuste | Por defecto | En el JSON |
| --- | --- | --- |
| Página de «Contactar» de las salidas (`contact_url`) | vacía = sin «Contactar» (el panel lo avisa) | no (es de cada sitio) |
| Instrucciones para el repartidor (`delivery_notes`) | no | sí |

Sin `export_data()`. La composición de la página no viaja en el JSON: se rehace en cada sitio con `wp lachinata checkout install-page`.

## Qué pasa al apagarlo

El tema pinta el checkout de bloques de WooCommerce de serie, con su aspecto y una tarjeta por paso: sin bloque tras el envío, sin pestañas de Facturación ni factura de empresa, sin huecos para el regalo (que se apaga con él), sin provincia desde el código postal y con la casilla nativa «Guardar mis datos». El orden de bloques que dejó `install-page` sigue en la página y no estorba. Las pasarelas siguen funcionando. Los pedidos conservan sus metadatos; `lachinata.invoice` sale `null` en los nuevos.

## Pruebas
- PHP: `tests/AssetsTest.php` (regla de `wp-components`), `tests/PageTest.php` (orden de las tarjetas, la página de la 0.5.1 recompuesta, bloques desconocidos antes de la línea legal, atributos también anidados, la nota del pedido según el ajuste, composición idempotente, provincias contra las de WooCommerce), `tests/AccountTest.php` (cuenta tras el pago de un pedido de la 0.5.x, sin casilla o con correo existente no hay cuenta, plazo de gracia, casilla nativa apagada, «Guardar mis datos» ya no es campo del checkout, autocompletado solo con proveedor y sus rutas), `tests/GatewaysTest.php` (scripts de Stripe y PayPal, jQuery de PayPal, «Pagar con PayPal», `preconnect`); `tests/profiles/LaChinataEsTest.php` cubre los datos de la Store API (peso, envíos no disponibles, peso por línea, productos que no viajan).
- Humo (`npm run test:e2e`, sobre el sitio del seed): el checkout se pinta sin errores ni lo que se quita, clases de `checkout.css` (también con Facturación en Empresa y otra dirección), bolsa y ficha, sin envío por peso (motivo una sola vez, salidas, envíos deshabilitados), producto que no viaja («Quitar de la bolsa»), provincia, teclado numérico, sin pasos, nombre accesible «Pagar 26,26 €», sin «Guardar mis datos» ni instrucciones y con novedades sin marcar, gracias, «Crear mi cuenta» y la factura con NIF después de pagar, orden de la dirección y Alemania sin provincia, Facturación antes de Pago con las pestañas (también con el teclado) y la factura de empresa en el pedido, la red de seguridad de la facturación y la mejora progresiva de los campos.
- Tarjetas (`tests/e2e/checkout-cards.spec.mjs`, 390 y 1440): ver «Tarjetas agrupadas solo con CSS».
- Pagos (`tests/e2e/payments.spec.mjs`, se saltan sin pasarelas configuradas, como en la CI): fila exprés sin PayPal ni Link y «Pagar con PayPal», tarjeta 4242, tarjeta con 3D Secure 3184 (completa cada reto) y PayPal con el comprador sandbox. Se pasan en local con las claves antes de cada release que toque el checkout o las pasarelas.
- Pedido telefónico (`tests/e2e/phone-order.spec.mjs`): pedido creado en el panel con «Enviar los detalles del pedido al cliente», página de pago con el aspecto del checkout y sin desbordar a 390, y pago con la tarjeta 4242 y con PayPal sandbox (se saltan sin pasarelas). `tests/CardDetailsTest.php`: etiqueta de la tarjeta y de la cartera, nada guardado antes del pago. `tests/PayForOrderTest.php`: carteras solo con el pago exprés de Stripe en el checkout, nada fuera de order-pay, scripts con los tokens.
- La CI (`e2e`) instala Stripe y PayPal activos sin claves y pasa el test de humo en ese estado.

- El consentimiento de novedades pasó a `newsletter` (`NewsletterTest::test_checkout_box_and_consent`).
- El humo de cada perfil (`tests/e2e/smoke.spec.mjs`) completa un pedido en el checkout de cada tienda: con el módulo (es, canarias, cz, all) y sin el plugin (off).

## Huecos conocidos
- **Aviso temprano:** el workflow «WooCommerce siguiente» (`.github/workflows/woocommerce-next.yml`, lunes y a mano) pasa PHPUnit y el e2e del checkout contra la próxima beta o candidata de WooCommerce y abre un issue si algo se rompe, antes de que esa versión llegue a las tiendas.
- **Elección de la dirección de facturación (`lachinata/checkout-billing`).** WooCommerce guarda «usar la misma dirección» como una casilla del bloque de dirección de entrega y la cambia con una acción **interna** de su store de checkout, `__internalSetUseShippingAsBilling` (WooCommerce 11.2). El bloque usa esa acción y el tema oculta la casilla nativa. Red: el bloque comprueba en cada carga que la acción existe; si una versión de WooCommerce la quita o la renombra, no se pinta, vuelve la casilla nativa en la dirección de entrega y el formulario de facturación sigue apareciendo dentro de la tarjeta Facturación, y el hueco queda en WooCommerce → La Chinata → Checkout → Huecos de configuración (`POST lachinata/v1/checkout/gap`). Lo vigila el test de humo «red de seguridad…» (sirve un `wc-blocks-data.js` con la acción renombrada y, al terminar, borra el hueco que provoca) y «facturación antes de Pago…».
- **Pestañas Particular | Empresa / Autónomo (`lachinata/checkout-billing-type`).** Usan la acción pública `setAdditionalFields` del store de checkout. Si faltara, el bloque pinta solo la cabecera de Facturación y vuelve la casilla «Necesito factura a nombre de una empresa» (el tema solo la oculta cuando hay pestañas). Lo vigila «facturación antes de Pago…».
- **Link dentro de la tarjeta.** Con Link activo en la cuenta de Stripe, el formulario de tarjeta (Payment Element) ofrece Link aunque el plugin pida solo `card`; el plugin no tiene opción para quitarlo. Se apaga en el panel de Stripe (Ajustes → Métodos de pago → Link), en prueba y en vivo (`docs/despliegue-checkout.md`).

- Lighthouse del checkout entre 55 y 67 según el entorno: el formulario de tarjeta de Stripe es el techo.
- `wc_stripe_express_checkout` (pago exprés de Stripe para páginas clásicas) sigue cargándose en el checkout de bloques: decidirlo probando con una cartera real.
- Proveedor de autocompletado de dirección: preparado, sin elegir.
