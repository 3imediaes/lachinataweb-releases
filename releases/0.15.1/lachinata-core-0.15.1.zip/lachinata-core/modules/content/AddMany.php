<?php
/**
 * «Añadir los N a la bolsa» of a recipe.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * `?lc-add-many=12,34,56` on the bag URL adds one unit of each product (simple, published,
 * in stock) and goes to the bag, like WooCommerce's `?add-to-cart=` for one. It is the link
 * of the button, so it works without JavaScript; with it, the theme's add to bag follows
 * the same link with `?lc-partial=cart` and reads the bag from the answer.
 */
final class AddMany {

	/**
	 * Query var.
	 */
	public const VAR = 'lc-add-many';

	/**
	 * Most products in one request.
	 */
	private const MOST = 20;

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		// Before WooCommerce's form handler (20), which would redirect first.
		Hooks::add_action( 'wp_loaded', array( self::class, 'handle' ), 19 );
	}

	/**
	 * Adds the products of the link and redirects to the bag.
	 */
	public static function handle(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Same as WooCommerce's ?add-to-cart=: adding to one's own bag.
		$raw = isset( $_GET[ self::VAR ] ) ? sanitize_text_field( wp_unslash( (string) $_GET[ self::VAR ] ) ) : '';
		if ( '' === $raw || ! function_exists( 'WC' ) || null === WC()->cart ) {
			return;
		}
		$ids   = array_slice( array_unique( array_filter( array_map( 'absint', explode( ',', $raw ) ) ) ), 0, self::MOST );
		$added = array();
		foreach ( $ids as $id ) {
			$product = wc_get_product( $id );
			if ( ! $product instanceof \WC_Product || ! $product->is_type( 'simple' ) || 'publish' !== $product->get_status() || ! $product->is_purchasable() || ! $product->is_in_stock() ) {
				continue;
			}
			if ( WC()->cart->add_to_cart( $id, 1 ) ) {
				$added[ $id ] = 1;
			}
		}
		if ( $added ) {
			wc_add_to_cart_message( $added, true );
		}
		wp_safe_redirect( wc_get_cart_url() );
		exit;
	}
}
