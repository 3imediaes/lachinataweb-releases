<?php
/**
 * `llms.txt` and the rules for crawlers.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

use LaChinata\Core\Company;
use LaChinata\Core\Hooks;
use LaChinata\Core\Services;

defined( 'ABSPATH' ) || exit;

/**
 * `llms.txt` at the root (and `/{lang}/llms.txt` for each other language): who the shop is
 * (from «Datos de la empresa» and a text of the panel), the key pages and the best guides
 * and recipes (by default the 30 articles and the 30 recipes with most clicks that have «En
 * pocas palabras», which describes each link; the editor can pin or leave out entries).
 * Never news, entries «Retiradas» or in «Revisar», or what is not published in that
 * language. `robots.txt`: every crawler allowed by default, with rules by agent in the
 * panel; filters and parameters, the bag, the checkout and the account stay closed to all.
 */
final class Ai {

	/**
	 * Query var of `llms.txt` (its value: the language, or `1` for the default one).
	 */
	public const VAR = 'lc_llms';

	/**
	 * Pin («fijar») or leave out («excluir») an entry in `llms.txt`.
	 */
	public const PIN = '_lc_content_llms';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'init', array( self::class, 'rules' ) );
		Hooks::add_filter( 'query_vars', array( self::class, 'query_vars' ) );
		Hooks::add_action( 'template_redirect', array( self::class, 'serve' ), 1 );
		Hooks::add_filter( 'robots_txt', array( self::class, 'robots' ), 99, 2 );
	}

	/**
	 * Rules of `llms.txt`.
	 */
	public static function rules(): void {
		add_rewrite_rule( '^llms\.txt$', 'index.php?' . self::VAR . '=1', 'top' );
		add_rewrite_rule( '^([a-z]{2})/llms\.txt$', 'index.php?' . self::VAR . '=$matches[1]', 'top' );
		register_post_meta(
			'post',
			self::PIN,
			array(
				'type'              => 'string',
				'single'            => true,
				'default'           => '',
				'show_in_rest'      => array(
					'schema' => array(
						'type' => 'string',
						'enum' => array( '', 'fijar', 'excluir' ),
					),
				),
				'auth_callback'     => static fn(): bool => current_user_can( 'edit_posts' ),
				'sanitize_callback' => static fn( $value ): string => in_array( (string) $value, array( 'fijar', 'excluir' ), true ) ? (string) $value : '',
			)
		);
	}

	/**
	 * Query var.
	 *
	 * @param mixed $vars Vars.
	 * @return mixed
	 */
	public static function query_vars( $vars ) {
		if ( is_array( $vars ) ) {
			$vars[] = self::VAR;
		}
		return $vars;
	}

	/**
	 * Language of the request of `llms.txt`, or '' when it is not one.
	 */
	private static function language(): string {
		$value = (string) get_query_var( self::VAR );
		if ( '' === $value ) {
			return '';
		}
		$languages = Services::languages();
		if ( '1' === $value ) {
			// `translate` serves `/en/llms.txt` as `/llms.txt` in the language of the address.
			return $languages->current();
		}
		foreach ( $languages->languages() as $language ) {
			if ( $language !== $languages->default_language() && ( $language === $value || $languages->code( $language ) === $value ) ) {
				return $language;
			}
		}
		return '';
	}

	/**
	 * Prints `llms.txt`.
	 */
	public static function serve(): void {
		$language = self::language();
		if ( '' === $language ) {
			if ( '' !== (string) get_query_var( self::VAR ) ) {
				global $wp_query;
				$wp_query->set_404();
				status_header( 404 );
			}
			return;
		}
		header( 'Content-Type: text/plain; charset=utf-8' );
		header( 'X-Robots-Tag: noindex' );
		echo self::text( $language ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Plain text (Markdown), not HTML.
		exit;
	}

	/**
	 * The entries of `llms.txt` of a format: pinned ones first, then by clicks, with a summary.
	 *
	 * @param string $format   Format.
	 * @param int    $count    How many.
	 * @param string $language Language.
	 * @return \WP_Post[]
	 */
	public static function entries( string $format, int $count, string $language ): array {
		if ( $count <= 0 ) {
			return array();
		}
		$posts = Query::posts(
			array(
				'posts_per_page' => -1,
				'meta_query'     => Query::format_query( $format ), // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Indexed by key.
			)
		);
		$posts = array_values(
			array_filter(
				$posts,
				static function ( \WP_Post $post ) use ( $language ): bool {
					/**
					 * Whether an entry is published in a language: by default, what the contract
					 * `Languages` says (`translate`: only when it is translated whole; without
					 * it, only the site's language).
					 *
					 * @since 0.13.1
					 *
					 * @param bool     $published The site's language by default.
					 * @param \WP_Post $post      Entry.
					 * @param string   $language  Language.
					 */
					$published = (bool) apply_filters( 'lachinata/content/published_in', Services::languages()->available( 'post', $post->ID, $language ), $post, $language );
					return $published
						&& 'excluir' !== get_post_meta( $post->ID, self::PIN, true )
						&& '' !== trim( (string) get_post_meta( $post->ID, Fields::SUMMARY, true ) )
						&& ! Review::pending( $post->ID );
				}
			)
		);
		usort(
			$posts,
			static fn( \WP_Post $a, \WP_Post $b ): int => array( 'fijar' === get_post_meta( $b->ID, self::PIN, true ), (int) get_post_meta( $b->ID, Fields::CLICKS, true ) ) <=> array( 'fijar' === get_post_meta( $a->ID, self::PIN, true ), (int) get_post_meta( $a->ID, Fields::CLICKS, true ) )
		);
		return array_slice( $posts, 0, $count );
	}

	/**
	 * Text of `llms.txt` in a language.
	 *
	 * @param string $language Language.
	 */
	public static function text( string $language ): string {
		// Titles, summaries and links in that language (`translate`), then back.
		Services::languages()->switch_to( $language );
		try {
			return self::compose( $language );
		} finally {
			Services::languages()->restore();
		}
	}

	/**
	 * Text of `llms.txt` in the language switched to.
	 *
	 * @param string $language Language.
	 */
	private static function compose( string $language ): string {
		$languages = Services::languages();
		$url       = static fn( string $link ): string => $languages->url( $link, $language );
		$company   = Company::get();
		$lines     = array( '# ' . Company::trade_name(), '' );
		$about     = trim( (string) ContentModule::setting( 'llms_about' ) );
		$tagline   = trim( wp_specialchars_decode( (string) get_bloginfo( 'description' ), ENT_QUOTES ) );
		if ( '' !== $tagline || '' !== $about ) {
			$lines[] = '> ' . ( '' !== $about ? $about : $tagline );
			$lines[] = '';
		}
		$facts = array_filter(
			array(
				'' !== $company['legal_name'] ? sprintf( '%1$s: %2$s', __( 'Empresa', 'lachinata-core' ), $company['legal_name'] ) : '',
				'' !== $company['address'] ? sprintf( '%1$s: %2$s', __( 'Dirección', 'lachinata-core' ), $company['address'] ) : '',
				'' !== $about && '' !== $tagline ? $tagline : '',
			)
		);
		if ( $facts ) {
			$lines   = array_merge( $lines, $facts );
			$lines[] = '';
		}
		$pages = self::pages( $language );
		if ( $pages ) {
			$lines[] = '## ' . __( 'Páginas clave', 'lachinata-core' );
			$lines[] = '';
			foreach ( $pages as $page ) {
				$lines[] = sprintf( '- [%1$s](%2$s)', $page['title'], $url( $page['url'] ) );
			}
			$lines[] = '';
		}
		foreach (
			array(
				Model::ARTICLE => array( __( 'Guías y artículos', 'lachinata-core' ), (int) ContentModule::setting( 'llms_articles' ) ),
				Model::RECIPE  => array( __( 'Recetas', 'lachinata-core' ), (int) ContentModule::setting( 'llms_recipes' ) ),
			) as $format => list( $title, $count )
		) {
			$posts = self::entries( $format, $count, $language );
			if ( ! $posts ) {
				continue;
			}
			$lines[] = '## ' . $title;
			$lines[] = '';
			foreach ( $posts as $post ) {
				$lines[] = sprintf( '- [%1$s](%2$s): %3$s', html_entity_decode( get_the_title( $post ), ENT_QUOTES, 'UTF-8' ), $url( (string) get_permalink( $post ) ), Seo::description( $post->ID ) );
			}
			$lines[] = '';
		}
		return implode( "\n", $lines );
	}

	/**
	 * The key pages any shop has, in the order of the file.
	 *
	 * @return array<string, string> Label by key.
	 */
	public static function key_labels(): array {
		return array(
			'about'    => __( 'Acerca de', 'lachinata-core' ),
			'shipping' => __( 'Envíos y devoluciones', 'lachinata-core' ),
			'faq'      => __( 'Preguntas frecuentes', 'lachinata-core' ),
			'contact'  => __( 'Contacto', 'lachinata-core' ),
		);
	}

	/**
	 * The page chosen for each key page (0: none). The list of 0.13.1 went in this order.
	 *
	 * @return array<string, int>
	 */
	public static function key_pages(): array {
		$saved = (array) ContentModule::setting( 'llms_pages' );
		$out   = array();
		foreach ( array_keys( self::key_labels() ) as $index => $key ) {
			$out[ $key ] = absint( $saved[ $key ] ?? ( array_is_list( $saved ) ? ( $saved[ $index ] ?? 0 ) : 0 ) );
		}
		return $out;
	}

	/**
	 * Key pages not chosen, or chosen and not published (for the health of the module).
	 *
	 * @return string[] Their labels.
	 */
	public static function missing_pages(): array {
		$labels = self::key_labels();
		$out    = array();
		foreach ( self::key_pages() as $key => $id ) {
			if ( ! $id || 'publish' !== get_post_status( $id ) ) {
				$out[] = $labels[ $key ];
			}
		}
		return $out;
	}

	/**
	 * Key pages: the pages of the setting (About, shipping and returns, FAQ, contact), the
	 * store finder and the categories of the shop in their order.
	 *
	 * @param string $language Language.
	 * @return array<int, array{title: string, url: string}>
	 */
	public static function pages( string $language ): array {
		unset( $language );
		$pages = array();
		foreach ( self::key_pages() as $id ) {
			if ( $id && 'publish' === get_post_status( $id ) ) {
				$pages[] = array(
					'title' => html_entity_decode( get_the_title( $id ), ENT_QUOTES, 'UTF-8' ),
					'url'   => (string) get_permalink( $id ),
				);
			}
		}
		/** This filter is documented in plugin/modules/content/Mentions.php */
		$stores = apply_filters( 'lachinata/oleotecas/status', null, '' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingSinceComment -- Documented in Mentions::store().
		if ( is_array( $stores ) && '' !== (string) ( $stores['finder'] ?? '' ) ) {
			$pages[] = array(
				'title' => __( 'Buscador de oleotecas', 'lachinata-core' ),
				'url'   => (string) $stores['finder'],
			);
		}
		/** This filter is documented in theme/inc/navigation.php */
		$categories = apply_filters( 'lachinata/catalog/categories', null ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingSinceComment -- The theme's hook.
		if ( ! is_array( $categories ) ) {
			// Without the list of the shop, every root category with products (as the header).
			$categories = get_terms(
				array(
					'taxonomy'   => 'product_cat',
					'parent'     => 0,
					'hide_empty' => true,
					'fields'     => 'ids',
					'exclude'    => array( (int) get_option( 'default_product_cat' ) ),
				)
			);
		}
		foreach ( is_array( $categories ) ? $categories : array() as $term_id ) {
			$term = get_term( (int) $term_id, 'product_cat' );
			$link = $term instanceof \WP_Term ? get_term_link( $term ) : '';
			if ( is_string( $link ) && '' !== $link ) {
				$pages[] = array(
					'title' => html_entity_decode( $term->name, ENT_QUOTES, 'UTF-8' ),
					'url'   => $link,
				);
			}
		}
		return $pages;
	}

	/**
	 * Paths closed to every crawler: filters and parameters, the bag, the checkout and the
	 * account.
	 *
	 * @return string[]
	 */
	public static function closed_paths(): array {
		$paths = array( '/*?*filter_', '/*?*min_price=', '/*?*max_price=', '/*?*orderby=', '/*?*add-to-cart=', '/*?*' . AddMany::VAR . '=', '/*?*' . Pages::PRODUCT_VAR . '=' );
		foreach ( array( 'cart', 'checkout', 'myaccount' ) as $page ) {
			$id   = function_exists( 'wc_get_page_id' ) ? wc_get_page_id( $page ) : 0;
			$path = $id > 0 ? (string) wp_parse_url( (string) get_permalink( $id ), PHP_URL_PATH ) : '';
			if ( '' !== $path ) {
				$paths[] = trailingslashit( $path );
			}
		}
		return $paths;
	}

	/**
	 * Rules by agent of the panel: [{agent, allow}], all allowed by default.
	 *
	 * @return array<int, array{agent: string, allow: bool}>
	 */
	public static function crawlers(): array {
		$rules = array();
		foreach ( (array) ContentModule::setting( 'crawlers' ) as $rule ) {
			$agent = is_array( $rule ) ? trim( sanitize_text_field( (string) ( $rule['agent'] ?? '' ) ) ) : '';
			if ( '' !== $agent && '*' !== $agent ) {
				$rules[] = array(
					'agent' => $agent,
					'allow' => ! empty( $rule['allow'] ),
				);
			}
		}
		return $rules;
	}

	/**
	 * `robots.txt`: every crawler, and each agent of the panel, with the closed paths; an
	 * agent not allowed, closed to all. When the site is not public, WordPress's stays.
	 *
	 * @param mixed $output    Current text.
	 * @param mixed $is_public Whether the site is public.
	 */
	public static function robots( $output, $is_public ): string {
		$output = (string) $output;
		if ( ! $is_public ) {
			return $output;
		}
		$closed = array_map( static fn( string $path ): string => 'Disallow: ' . $path, self::closed_paths() );
		// Into the group for every crawler that is already there (some read only the first).
		if ( preg_match( '/^User-agent:\s*\*\s*$/mi', $output, $match, PREG_OFFSET_CAPTURE ) ) {
			$at     = (int) $match[0][1] + strlen( $match[0][0] );
			$have   = array_map( 'trim', explode( "\n", $output ) );
			$add    = array_values( array_filter( $closed, static fn( string $line ): bool => ! in_array( $line, $have, true ) ) );
			$output = substr( $output, 0, $at ) . ( $add ? "\n" . implode( "\n", $add ) : '' ) . substr( $output, $at );
			$blocks = array();
		} else {
			$blocks = array( implode( "\n", array_merge( array( 'User-agent: *' ), $closed ) ) );
		}
		foreach ( self::crawlers() as $rule ) {
			$blocks[] = implode( "\n", array_merge( array( 'User-agent: ' . $rule['agent'] ), $rule['allow'] ? $closed : array( 'Disallow: /' ) ) );
		}
		$tail = $blocks ? "\n\n" . implode( "\n\n", $blocks ) : '';
		return rtrim( $output ) . $tail . "\n\n# llms.txt: " . home_url( '/llms.txt' ) . "\n";
	}
}
