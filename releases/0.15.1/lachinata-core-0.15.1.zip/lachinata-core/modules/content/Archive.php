<?php
/**
 * Review of the archive (pruning).
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

defined( 'ABSPATH' ) || exit;

/**
 * Nothing is deleted blindly. Each entry gets a decision: keep and improve, keep, merge,
 * redirect, retire or review. The list comes from a CSV (`post_id, url, tipo, clics_16m,
 * propuesta, destino, motivo`; when `decision_final` and `destino_final` come, those rule);
 * the module's rules only propose for the entries that are not in it. Nothing is applied
 * until the list is approved; then, in one go: retire and redirect leave the entry
 * «Retirada» with its 410 or its 301 (a 410 only without internal links: with them, a 301 to
 * its section), merge does the same with the secondary entry and sends the main one to
 * «Revisar» with a link to it, and review sends the entry to «Revisar». «Mantener y mejorar»
 * is the list «Por mejorar», by clicks, with what each entry lacks.
 *
 * @phpstan-type Row array{source: string, proposal: string, target: string, target_id?: int, reason: string, final: bool, applied: string}
 */
final class Archive {

	/**
	 * Decision of an entry.
	 */
	public const META = '_lc_content_poda';

	/**
	 * Impressions of Search Console.
	 */
	public const IMPRESSIONS = '_lc_content_impresiones';

	/**
	 * Entries of this site that link to the entry.
	 */
	public const INBOUND = '_lc_content_entrantes';

	public const KEEP_IMPROVE = 'Mantener y mejorar';
	public const KEEP         = 'Mantener';
	public const MERGE        = 'Fusionar';
	public const REDIRECT     = 'Redirigir';
	public const RETIRE       = 'Retirar';
	public const REVIEW       = 'Revisar';

	/**
	 * Decisions, in the order of the screen.
	 *
	 * @return string[]
	 */
	public static function decisions(): array {
		return array( self::KEEP_IMPROVE, self::KEEP, self::MERGE, self::REDIRECT, self::RETIRE, self::REVIEW );
	}

	/**
	 * A decision as it is written in a list («retirar», «Mantener y Mejorar»), or ''.
	 *
	 * @param string $value Value.
	 */
	public static function decision_of( string $value ): string {
		$value = mb_strtolower( trim( $value ) );
		foreach ( self::decisions() as $decision ) {
			if ( mb_strtolower( $decision ) === $value ) {
				return $decision;
			}
		}
		return '';
	}

	/**
	 * Saved row of an entry, or null.
	 *
	 * @param int $post_id Post.
	 * @return Row|null
	 */
	public static function row( int $post_id ): ?array {
		$row = get_post_meta( $post_id, self::META, true );
		if ( ! is_array( $row ) || '' === (string) ( $row['proposal'] ?? '' ) ) {
			return null;
		}
		return array(
			'source'   => (string) ( $row['source'] ?? '' ),
			'proposal' => (string) $row['proposal'],
			'target'   => (string) ( $row['target'] ?? '' ),
			'reason'   => (string) ( $row['reason'] ?? '' ),
			'final'    => ! empty( $row['final'] ),
			'applied'  => (string) ( $row['applied'] ?? '' ),
		);
	}

	/**
	 * Reads a CSV with a header into rows by column name.
	 *
	 * @param string $file File.
	 * @return array<int, array<string, string>>
	 */
	public static function csv( string $file ): array {
		$handle = is_readable( $file ) ? fopen( $file, 'r' ) : false; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- A CSV given by the editor.
		if ( false === $handle ) {
			return array();
		}
		$first = (string) fgets( $handle );
		$first = (string) preg_replace( '/^\xEF\xBB\xBF/', '', $first );
		$comma = substr_count( $first, ';' ) > substr_count( $first, ',' ) ? ';' : ',';
		$head  = array_map( static fn( $name ): string => sanitize_key( (string) $name ), str_getcsv( trim( $first ), $comma, '"', '\\' ) );
		$rows  = array();
		while ( ( $line = fgetcsv( $handle, 0, $comma, '"', '\\' ) ) !== false ) { // phpcs:ignore Generic.CodeAnalysis.AssignmentInCondition.FoundInWhileCondition -- Reading a file.
			if ( count( $line ) < 2 ) {
				continue;
			}
			$rows[] = array_combine( $head, array_pad( array_slice( array_map( 'strval', $line ), 0, count( $head ) ), count( $head ), '' ) );
		}
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- A CSV given by the editor.
		return $rows;
	}

	/**
	 * Imports the list: each row by `post_id`; `decision_final` and `destino_final`, when
	 * filled, rule over `propuesta` and `destino`.
	 *
	 * @param string $file CSV.
	 * @return array{rows: int, matched: int, missing: int[], final: int}
	 */
	public static function import_list( string $file ): array {
		$stats = array(
			'rows'    => 0,
			'matched' => 0,
			'missing' => array(),
			'final'   => 0,
		);
		foreach ( self::csv( $file ) as $line ) {
			++$stats['rows'];
			$id   = absint( $line['post_id'] ?? 0 );
			$post = $id ? get_post( $id ) : null;
			if ( ! $post instanceof \WP_Post || 'post' !== $post->post_type ) {
				$stats['missing'][] = $id;
				continue;
			}
			$final    = self::decision_of( (string) ( $line['decision_final'] ?? '' ) );
			$proposal = '' !== $final ? $final : self::decision_of( (string) ( $line['propuesta'] ?? '' ) );
			if ( '' === $proposal ) {
				$stats['missing'][] = $id;
				continue;
			}
			$own    = '' !== $final && '' !== trim( (string) ( $line['destino_final'] ?? '' ) );
			$target = $own ? (string) $line['destino_final'] : (string) ( $line['destino'] ?? '' );
			// The id of the destination, when the list brings it (`destino_id`): it wins over
			// an address that may not be the slug (URI of Permalink Manager).
			$target_id = $own ? 0 : absint( $line['destino_id'] ?? 0 );
			update_post_meta(
				$id,
				self::META,
				array(
					'source'    => 'lista',
					'proposal'  => $proposal,
					'target'    => trim( $target ),
					'target_id' => $target_id,
					'reason'    => sanitize_text_field( (string) ( $line['motivo'] ?? '' ) ),
					'final'     => '' !== $final,
					'applied'   => (string) ( self::row( $id )['applied'] ?? '' ),
				)
			);
			if ( isset( $line['clics_16m'] ) && '' !== $line['clics_16m'] && '' === (string) get_post_meta( $id, Fields::CLICKS, true ) ) {
				update_post_meta( $id, Fields::CLICKS, (int) $line['clics_16m'] );
			}
			++$stats['matched'];
			$stats['final'] += '' !== $final ? 1 : 0;
		}
		return $stats;
	}

	/**
	 * Clicks and impressions of Search Console (CSV of pages: URL, clicks, impressions…), by
	 * the address of each entry (also on the production domain).
	 *
	 * @param string $file CSV.
	 * @return array{rows: int, matched: int}
	 */
	public static function import_gsc( string $file ): array {
		$stats = array(
			'rows'    => 0,
			'matched' => 0,
		);
		foreach ( self::csv( $file ) as $line ) {
			$values = array_values( $line );
			if ( count( $values ) < 2 ) {
				continue;
			}
			++$stats['rows'];
			$slug  = basename( trim( (string) wp_parse_url( (string) $values[0], PHP_URL_PATH ), '/' ) );
			$posts = '' === $slug ? array() : get_posts(
				array(
					'name'        => $slug,
					'post_type'   => 'post',
					'post_status' => 'any',
					'numberposts' => 1,
				)
			);
			if ( ! $posts ) {
				continue;
			}
			++$stats['matched'];
			update_post_meta( $posts[0]->ID, Fields::CLICKS, (int) preg_replace( '/\D/', '', (string) $values[1] ) );
			if ( isset( $values[2] ) ) {
				update_post_meta( $posts[0]->ID, self::IMPRESSIONS, (int) preg_replace( '/\D/', '', (string) $values[2] ) );
			}
		}
		return $stats;
	}

	/**
	 * Counts the internal links each entry receives from the published ones.
	 *
	 * @return int Entries with at least one.
	 */
	public static function count_inbound(): int {
		$posts  = get_posts(
			array(
				'post_type'   => 'post',
				'post_status' => 'publish',
				'numberposts' => -1,
			)
		);
		$counts = array();
		$host   = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		foreach ( $posts as $post ) {
			preg_match_all( '/<a\s[^>]*href=["\']([^"\'#?]+)/i', $post->post_content, $matches );
			$seen = array();
			foreach ( $matches[1] as $url ) {
				$link_host = (string) wp_parse_url( $url, PHP_URL_HOST );
				// The last segment: old addresses carry the blog of the old shop (`/blog/{slug}`).
				$path = sanitize_title( (string) preg_replace( '/\.html?$/i', '', basename( trim( (string) wp_parse_url( $url, PHP_URL_PATH ), '/' ) ) ) );
				if ( ( '' !== $link_host && $link_host !== $host && ! self::own_host( $link_host ) ) || '' === $path ) {
					continue;
				}
				$seen[ $path ] = true;
			}
			foreach ( array_keys( $seen ) as $slug ) {
				if ( $slug !== $post->post_name ) {
					$counts[ $slug ] = ( $counts[ $slug ] ?? 0 ) + 1;
				}
			}
		}
		$all  = get_posts(
			array(
				'post_type'   => 'post',
				'post_status' => 'any',
				'numberposts' => -1,
			)
		);
		$with = 0;
		foreach ( $all as $post ) {
			$count = (int) ( $counts[ $post->post_name ] ?? 0 );
			update_post_meta( $post->ID, self::INBOUND, $count );
			$with += $count ? 1 : 0;
		}
		return $with;
	}

	/**
	 * Whether a host is the production domain of this shop (`.html` links of the old site).
	 *
	 * @param string $host Host.
	 */
	private static function own_host( string $host ): bool {
		$own = array_filter( array_map( 'trim', (array) ContentModule::setting( 'own_hosts' ) ) );
		return in_array( preg_replace( '/^www\./', '', $host ), array_map( static fn( $item ): string => (string) preg_replace( '/^www\./', '', (string) $item ), $own ), true );
	}

	/**
	 * The module's proposal for the entries that are not in the list (rules of 08).
	 *
	 * @return array<string, int> Proposals by decision.
	 */
	public static function propose(): array {
		$posts    = get_posts(
			array(
				'post_type'   => 'post',
				'post_status' => 'publish',
				'numberposts' => -1,
			)
		);
		$clicks   = array();
		$keywords = array();
		$products = array();
		foreach ( $posts as $post ) {
			$clicks[ $post->ID ] = (int) get_post_meta( $post->ID, Fields::CLICKS, true );
			$keyword             = mb_strtolower( trim( (string) get_post_meta( $post->ID, 'rank_math_focus_keyword', true ) ) );
			if ( '' !== $keyword ) {
				$keywords[ $keyword ][] = $post->ID;
			}
			$main = (int) get_post_meta( $post->ID, Fields::MENTIONS, true );
			if ( $main ) {
				$products[ $main ][] = $post->ID;
			}
		}
		arsort( $clicks );
		$top    = array_slice( array_keys( $clicks ), 0, 100 );
		$counts = array();
		foreach ( $posts as $post ) {
			$row = self::row( $post->ID );
			if ( null !== $row && 'reglas' !== $row['source'] ) {
				continue;
			}
			$proposal = self::KEEP;
			$target   = '';
			$reason   = '';
			$format   = Model::format_of( $post );
			$age      = time() - (int) get_post_time( 'U', true, $post );
			$mine     = $clicks[ $post->ID ];
			$inbound  = (int) get_post_meta( $post->ID, self::INBOUND, true );
			$twin     = self::twin( $post, $keywords, $products, $clicks );
			if ( in_array( $post->ID, $top, true ) || ( Model::RECIPE === $format && $mine > 0 ) ) {
				$proposal = self::KEEP_IMPROVE;
				$reason   = __( 'Trae tráfico (las 100 primeras o una receta con visitas)', 'lachinata-core' );
			} elseif ( null !== $twin ) {
				$proposal = self::MERGE;
				$target   = (string) get_permalink( $twin );
				/* translators: %s: title of the other entry. */
				$reason = sprintf( __( 'Compite con «%s»', 'lachinata-core' ), get_the_title( $twin ) );
			} elseif ( Model::NEWS === $format && $mine < 10 && $age > 3 * YEAR_IN_SECONDS ) {
				$proposal = $inbound ? self::REDIRECT : self::RETIRE;
				$target   = $inbound ? '' : '410';
				$reason   = $inbound ? __( 'Noticia antigua sin tráfico, con enlaces: 301 a su sección', 'lachinata-core' ) : __( 'Noticia de más de tres años, sin tráfico ni enlaces', 'lachinata-core' );
			}
			update_post_meta(
				$post->ID,
				self::META,
				array(
					'source'   => 'reglas',
					'proposal' => $proposal,
					'target'   => $target,
					'reason'   => $reason,
					'final'    => false,
					'applied'  => (string) ( $row['applied'] ?? '' ),
				)
			);
			$counts[ $proposal ] = ( $counts[ $proposal ] ?? 0 ) + 1;
		}
		return $counts;
	}

	/**
	 * Another entry that competes with this one and has more clicks: the same keyword in
	 * Rank Math, or the same main product and a similar title.
	 *
	 * @param \WP_Post             $post     Post.
	 * @param array<string, int[]> $keywords Entries by keyword.
	 * @param array<int, int[]>    $products Entries by main product.
	 * @param array<int, int>      $clicks   Clicks by entry.
	 */
	private static function twin( \WP_Post $post, array $keywords, array $products, array $clicks ): ?int {
		$keyword    = mb_strtolower( trim( (string) get_post_meta( $post->ID, 'rank_math_focus_keyword', true ) ) );
		$candidates = '' === $keyword ? array() : (array) ( $keywords[ $keyword ] ?? array() );
		$main       = (int) get_post_meta( $post->ID, Fields::MENTIONS, true );
		foreach ( $main ? (array) ( $products[ $main ] ?? array() ) : array() as $other ) {
			similar_text( mb_strtolower( $post->post_title ), mb_strtolower( (string) get_the_title( $other ) ), $percent );
			if ( $percent >= 75 ) {
				$candidates[] = $other;
			}
		}
		$best = null;
		foreach ( array_unique( $candidates ) as $other ) {
			if ( $other !== $post->ID && ( $clicks[ $other ] ?? 0 ) > ( $clicks[ $post->ID ] ?? 0 ) && ( null === $best || ( $clicks[ $other ] ?? 0 ) > ( $clicks[ $best ] ?? 0 ) ) ) {
				$best = (int) $other;
			}
		}
		return $best;
	}

	/**
	 * What an entry of «Por mejorar» lacks.
	 *
	 * @param \WP_Post $post Post.
	 * @return string[]
	 */
	public static function lacks( \WP_Post $post ): array {
		$lacks = array();
		if ( '' === trim( (string) get_post_meta( $post->ID, Fields::SUMMARY, true ) ) ) {
			$lacks[] = __( '«En pocas palabras»', 'lachinata-core' );
		}
		if ( Model::RECIPE === Model::format_of( $post ) ) {
			$recipe = Recipe::of( $post );
			if ( null === $recipe || ! $recipe['groups'] || ! $recipe['steps'] || ! Recipe::total( $recipe ) || ! $recipe['servings'] ) {
				$lacks[] = __( 'datos de receta', 'lachinata-core' );
			}
		}
		$image = (int) get_post_thumbnail_id( $post );
		if ( ! $image ) {
			$lacks[] = __( 'imagen destacada', 'lachinata-core' );
		} elseif ( '' === trim( (string) get_post_meta( $image, '_wp_attachment_image_alt', true ) ) ) {
			$lacks[] = __( 'texto alternativo', 'lachinata-core' );
		}
		if ( ! get_post_meta( $post->ID, Fields::MENTIONS, false ) ) {
			$lacks[] = __( 'enlaces a producto', 'lachinata-core' );
		}
		$health = array_filter( array_map( 'sanitize_title', (array) ContentModule::setting( 'health_sections' ) ) );
		$root   = Model::section_of( $post );
		if ( $health && null !== $root && in_array( Model::root( $root )->slug, $health, true ) && ! get_post_meta( $post->ID, Fields::SOURCES, true ) ) {
			$lacks[] = __( 'fuentes', 'lachinata-core' );
		}
		return $lacks;
	}

	/**
	 * «Por mejorar»: the entries to keep and improve, by clicks.
	 *
	 * @return \WP_Post[]
	 */
	public static function to_improve(): array {
		$posts = get_posts(
			array(
				'post_type'   => 'post',
				'post_status' => 'publish',
				'numberposts' => -1,
				'meta_key'    => self::META, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Indexed by key.
			)
		);
		$posts = array_values(
			array_filter(
				$posts,
				static fn( \WP_Post $post ): bool => self::KEEP_IMPROVE === ( self::row( $post->ID )['proposal'] ?? '' )
			)
		);
		usort( $posts, static fn( \WP_Post $a, \WP_Post $b ): int => (int) get_post_meta( $b->ID, Fields::CLICKS, true ) <=> (int) get_post_meta( $a->ID, Fields::CLICKS, true ) );
		return $posts;
	}

	/**
	 * Applies the list. Only rows not applied yet; with `$dry_run`, nothing is written.
	 *
	 * @param bool $dry_run Dry run.
	 * @return array{applied: array<string, int>, targets: array<string, int>, paths: array<string, int>, notes: string[]}
	 */
	public static function apply( bool $dry_run ): array {
		$out   = array(
			'applied' => array(),
			'targets' => array(),
			'paths'   => array(),
			'notes'   => array(),
		);
		$posts = get_posts(
			array(
				'post_type'   => 'post',
				'post_status' => array( 'publish', 'draft', 'pending', 'private' ),
				'numberposts' => -1,
				'meta_key'    => self::META, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Indexed by key.
			)
		);
		foreach ( $posts as $post ) {
			$row = self::row( $post->ID );
			if ( null === $row || '' !== $row['applied'] || in_array( $row['proposal'], array( self::KEEP, self::KEEP_IMPROVE ), true ) ) {
				continue;
			}
			$decision = $row['proposal'];
			$target   = Retired::target_by_id( (int) ( $row['target_id'] ?? 0 ) ) ?? Retired::target_of( $row['target'] );
			if ( in_array( $decision, array( self::RETIRE, self::REDIRECT, self::MERGE ), true ) ) {
				$missing = 'url' === $target['type'] && ( Migration::looks_like_product( $target['url'] ) || self::nothing_at( $target['url'] ) );
				if ( $missing ) {
					/* translators: 1: entry, 2: address. */
					$out['notes'][] = sprintf( __( '%1$s: en %2$s no hay nada; 301 a su sección.', 'lachinata-core' ), self::label( $post ), $target['url'] );
				}
				if ( $missing || ( 'gone' === $target['type'] && (int) get_post_meta( $post->ID, self::INBOUND, true ) > 0 ) ) {
					// A 410 only without internal links, and never a 301 to a page that is not
					// there: a 301 to its section.
					$section = Model::section_of( $post );
					$target  = array(
						'type' => null === $section ? 'url' : 'section',
						'id'   => null === $section ? 0 : Model::root( $section )->term_id,
						'url'  => null === $section ? Query::home_url() : '',
					);
					if ( ! $missing ) {
						/* translators: %s: entry. */
						$out['notes'][] = sprintf( __( '%s: tiene enlaces internos; 301 a su sección en lugar de 410.', 'lachinata-core' ), self::label( $post ) );
					}
				}
				$out['targets'][ $target['type'] ] = ( $out['targets'][ $target['type'] ] ?? 0 ) + 1;
				if ( 'url' === $target['type'] ) {
					$out['paths'][ $target['url'] ] = ( $out['paths'][ $target['url'] ] ?? 0 ) + 1;
				}
				if ( ( self::REDIRECT === $decision || self::MERGE === $decision ) && 'gone' === $target['type'] ) {
					/* translators: %s: entry. */
					$out['notes'][] = sprintf( __( '%s: sin destino; se retira con 410.', 'lachinata-core' ), self::label( $post ) );
				}
				if ( ! $dry_run ) {
					update_post_meta( $post->ID, Retired::TARGET, $target );
					wp_update_post(
						array(
							'ID'          => $post->ID,
							'post_status' => Retired::STATUS,
						)
					);
				}
				if ( self::MERGE === $decision && in_array( $target['type'], array( 'post' ), true ) && ! $dry_run ) {
					Review::add(
						$target['id'],
						'merge:' . $post->ID,
						sprintf(
							/* translators: 1: title of the merged entry, 2: link to edit it. */
							__( 'Fusionada con «%1$s», ya retirada con 301 aquí: lleva lo útil (%2$s).', 'lachinata-core' ),
							get_the_title( $post ),
							(string) get_edit_post_link( $post->ID, 'raw' )
						)
					);
				}
			} elseif ( self::REVIEW === $decision && ! $dry_run ) {
				Review::add( $post->ID, 'archive', '' !== $row['reason'] ? $row['reason'] : __( 'Revisión del archivo.', 'lachinata-core' ) );
			}
			if ( ! $dry_run ) {
				$row['applied'] = wp_date( 'Y-m-d' );
				update_post_meta( $post->ID, self::META, $row );
			}
			$out['applied'][ $decision ] = ( $out['applied'][ $decision ] ?? 0 ) + 1;
		}
		return $out;
	}

	/**
	 * Whether a path of this site names nothing: the first rewrite rule that matches it (as
	 * WordPress reads a request) is the generic one of entries or pages and there is no such
	 * entry, page, product, store or section. A 301 there would end in a 404. A rule of its
	 * own (the store finder, the magazine) answers by itself.
	 *
	 * @param string $path Path («/slug/»).
	 */
	private static function nothing_at( string $path ): bool {
		$request = trim( $path, '/' );
		if ( '' === $request ) {
			return false;
		}
		foreach ( (array) get_option( 'rewrite_rules' ) as $regex => $query ) {
			if ( ! preg_match( '#^' . $regex . '#', $request ) && ! preg_match( '#^' . $regex . '#', $request . '/' ) ) {
				continue;
			}
			if ( ! preg_match( '/(?:^|[?&])(?:name|pagename)=/', (string) $query ) ) {
				return false;
			}
			$types = array_values( array_diff( get_post_types( array( 'public' => true ) ), array( 'attachment' ) ) );
			return null === get_page_by_path( basename( $request ), OBJECT, $types ) && ! get_term_by( 'slug', basename( $request ), Model::SECTION );
		}
		return true;
	}

	/**
	 * «Title (#id)».
	 *
	 * @param \WP_Post $post Post.
	 */
	public static function label( \WP_Post $post ): string {
		return sprintf( '%1$s (#%2$d)', html_entity_decode( get_the_title( $post ), ENT_QUOTES, 'UTF-8' ), $post->ID );
	}
}
