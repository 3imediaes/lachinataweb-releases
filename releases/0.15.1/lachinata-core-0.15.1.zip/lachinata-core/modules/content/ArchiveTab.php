<?php
/**
 * WooCommerce → La Chinata → Revisión de contenido.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

use LaChinata\Core\Admin\Screen;
use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * The review of the archive: import the list and the clicks of Search Console, see the
 * decision of each entry (from the list or from the module's rules), the list «Por mejorar»
 * and, once the list is approved, apply it in one go.
 */
final class ArchiveTab {

	/**
	 * Tab id.
	 */
	public const TAB = 'content-review';

	/**
	 * Action of admin-post.php, also the nonce action.
	 */
	private const SAVE = 'lachinata_content_review';

	/**
	 * Rows a page.
	 */
	private const PAGE = 50;

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/core/admin_tabs', array( self::class, 'tab' ), 31 );
		Hooks::add_action( 'admin_post_' . self::SAVE, array( self::class, 'handle' ) );
	}

	/**
	 * Adds the tab.
	 *
	 * @param array<string, array{label: string, render: callable}> $tabs Tabs.
	 * @return array<string, array{label: string, render: callable}>
	 */
	public static function tab( array $tabs ): array {
		$tabs[ self::TAB ] = array(
			'label'  => __( 'Revisión de contenido', 'lachinata-core' ),
			'render' => array( self::class, 'render' ),
		);
		return $tabs;
	}

	/**
	 * The screen.
	 */
	public static function render(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only filters of the screen.
		$view     = isset( $_GET['view'] ) ? sanitize_key( wp_unslash( (string) $_GET['view'] ) ) : '';
		$decision = isset( $_GET['decision'] ) ? Archive::decision_of( sanitize_text_field( wp_unslash( (string) $_GET['decision'] ) ) ) : '';
		$paged    = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
		$counts = self::counts();
		?>
		<p><?php esc_html_e( 'Cada entrada tiene una decisión: la de la lista importada o, si no está en ella, la que proponen las reglas del módulo. Nada se aplica hasta que la lista está aprobada.', 'lachinata-core' ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE ); ?>">
			<?php wp_nonce_field( self::SAVE ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="lc-review-list"><?php esc_html_e( 'Lista de la revisión (CSV)', 'lachinata-core' ); ?></label></th>
					<td>
						<input type="file" id="lc-review-list" name="list" accept=".csv,text/csv" aria-describedby="lc-review-list-hint">
						<p class="description" id="lc-review-list-hint"><?php esc_html_e( 'Columnas post_id, url, tipo, clics_16m, propuesta, destino, motivo; si vienen decision_final y destino_final, mandan esas. Destino: 410 o una dirección (301).', 'lachinata-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="lc-review-gsc"><?php esc_html_e( 'Search Console (CSV de páginas)', 'lachinata-core' ); ?></label></th>
					<td><input type="file" id="lc-review-gsc" name="gsc" accept=".csv,text/csv"></td>
				</tr>
			</table>
			<p>
				<button type="submit" name="do" value="import" class="button button-primary"><?php esc_html_e( 'Importar y proponer', 'lachinata-core' ); ?></button>
			</p>
		</form>

		<h2><?php esc_html_e( 'Decisiones', 'lachinata-core' ); ?></h2>
		<ul class="subsubsub">
			<li><a href="<?php echo esc_url( Screen::url( self::TAB ) ); ?>"<?php echo '' === $decision && '' === $view ? ' class="current"' : ''; ?>><?php esc_html_e( 'Todas', 'lachinata-core' ); ?> <span class="count">(<?php echo esc_html( number_format_i18n( array_sum( $counts ) ) ); ?>)</span></a> |</li>
			<?php foreach ( Archive::decisions() as $item ) : ?>
				<li><a href="<?php echo esc_url( Screen::url( self::TAB, array( 'decision' => $item ) ) ); ?>"<?php echo $decision === $item ? ' class="current"' : ''; ?>><?php echo esc_html( $item ); ?> <span class="count">(<?php echo esc_html( number_format_i18n( (int) ( $counts[ $item ] ?? 0 ) ) ); ?>)</span></a> |</li>
			<?php endforeach; ?>
			<li><a href="<?php echo esc_url( Screen::url( self::TAB, array( 'view' => 'improve' ) ) ); ?>"<?php echo 'improve' === $view ? ' class="current"' : ''; ?>><?php esc_html_e( 'Por mejorar', 'lachinata-core' ); ?></a></li>
		</ul>
		<br class="clear">
		<?php
		if ( 'improve' === $view ) {
			self::improve();
		} else {
			self::table( $decision, $paged );
		}
		$broken = Retired::broken();
		if ( $broken ) {
			/* translators: %s: number of entries. */
			echo '<div class="notice notice-warning inline"><p>' . esc_html( sprintf( _n( '%s entrada retirada redirige a un destino que ya no existe: va a su sección.', '%s entradas retiradas redirigen a un destino que ya no existe: van a su sección.', count( $broken ), 'lachinata-core' ), number_format_i18n( count( $broken ) ) ) ) . '</p></div>';
		}
		?>
		<h2><?php esc_html_e( 'Aplicar', 'lachinata-core' ); ?></h2>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE ); ?>">
			<?php wp_nonce_field( self::SAVE ); ?>
			<p><label><input type="checkbox" name="approved" value="1"> <?php esc_html_e( 'La lista está aprobada. Aplicar las decisiones pendientes: las entradas a retirar, redirigir o fusionar pasan a «Retirada» con su 410 o su 301, y las de revisar, a «Revisar». Se deshace volviendo a publicar cada entrada.', 'lachinata-core' ); ?></label></p>
			<p><button type="submit" name="do" value="apply" class="button"><?php esc_html_e( 'Aplicar la lista', 'lachinata-core' ); ?></button></p>
		</form>
		<?php
	}

	/**
	 * Entries by decision.
	 *
	 * @return array<string, int>
	 */
	private static function counts(): array {
		$counts = array();
		foreach ( self::ids() as $id ) {
			$row = Archive::row( $id );
			if ( null !== $row ) {
				$counts[ $row['proposal'] ] = ( $counts[ $row['proposal'] ] ?? 0 ) + 1;
			}
		}
		return $counts;
	}

	/**
	 * Entries with a decision, by clicks.
	 *
	 * @return int[]
	 */
	private static function ids(): array {
		return array_map(
			'intval',
			get_posts(
				array(
					'post_type'   => 'post',
					'post_status' => array( 'publish', 'draft', 'pending', 'private', Retired::STATUS ),
					'numberposts' => -1,
					'fields'      => 'ids',
					'meta_key'    => Archive::META, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Indexed by key.
				)
			)
		);
	}

	/**
	 * The table of decisions.
	 *
	 * @param string $decision Filter.
	 * @param int    $paged    Page.
	 */
	private static function table( string $decision, int $paged ): void {
		$ids = array_values( array_filter( self::ids(), static fn( int $id ): bool => '' === $decision || ( Archive::row( $id )['proposal'] ?? '' ) === $decision ) );
		usort( $ids, static fn( int $a, int $b ): int => (int) get_post_meta( $b, Fields::CLICKS, true ) <=> (int) get_post_meta( $a, Fields::CLICKS, true ) );
		$total = count( $ids );
		$ids   = array_slice( $ids, ( $paged - 1 ) * self::PAGE, self::PAGE );
		?>
		<table class="widefat striped">
			<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'Entrada', 'lachinata-core' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Formato', 'lachinata-core' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Clics', 'lachinata-core' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Enlaces entrantes', 'lachinata-core' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Fecha', 'lachinata-core' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Decisión', 'lachinata-core' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Destino', 'lachinata-core' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Motivo', 'lachinata-core' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $ids as $id ) : ?>
					<?php
					$post = get_post( $id );
					$row  = Archive::row( $id );
					if ( ! $post instanceof \WP_Post || null === $row ) {
						continue;
					}
					?>
					<tr>
						<td><a href="<?php echo esc_url( (string) get_edit_post_link( $id ) ); ?>"><?php echo esc_html( get_the_title( $post ) ); ?></a><?php echo Retired::STATUS === $post->post_status ? ' · <em>' . esc_html_x( 'Retirada', 'post status', 'lachinata-core' ) . '</em>' : ''; ?></td>
						<td><?php echo esc_html( Model::formats()[ Model::format_of( $post ) ] ?? '' ); ?></td>
						<td><?php echo esc_html( number_format_i18n( (int) get_post_meta( $id, Fields::CLICKS, true ) ) ); ?></td>
						<td><?php echo esc_html( number_format_i18n( (int) get_post_meta( $id, Archive::INBOUND, true ) ) ); ?></td>
						<td><?php echo esc_html( get_the_date( 'Y-m-d', $post ) ); ?></td>
						<td><?php echo esc_html( $row['proposal'] ); ?><br><span class="description"><?php echo esc_html( 'lista' === $row['source'] ? ( $row['final'] ? __( 'decisión final', 'lachinata-core' ) : __( 'lista', 'lachinata-core' ) ) : __( 'reglas', 'lachinata-core' ) ); ?><?php echo '' !== $row['applied'] ? ' · ' . esc_html__( 'aplicada', 'lachinata-core' ) : ''; ?></span></td>
						<td><?php echo '' !== $row['target'] ? '<code>' . esc_html( $row['target'] ) . '</code>' : ''; ?></td>
						<td><?php echo esc_html( $row['reason'] ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
		$pages = (int) ceil( $total / self::PAGE );
		if ( $pages > 1 ) {
			echo '<p class="tablenav-pages">';
			for ( $page = 1; $page <= $pages; $page++ ) {
				$args = array( 'paged' => $page );
				if ( '' !== $decision ) {
					$args['decision'] = $decision;
				}
				printf( $page === $paged ? '<strong>%2$s</strong> ' : '<a href="%1$s">%2$s</a> ', esc_url( Screen::url( self::TAB, $args ) ), esc_html( number_format_i18n( $page ) ) );
			}
			echo '</p>';
		}
	}

	/**
	 * «Por mejorar»: by clicks, with what each entry lacks.
	 */
	private static function improve(): void {
		?>
		<table class="widefat striped">
			<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'Entrada', 'lachinata-core' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Clics', 'lachinata-core' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Le falta', 'lachinata-core' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( Archive::to_improve() as $post ) : ?>
					<tr>
						<td><a href="<?php echo esc_url( (string) get_edit_post_link( $post->ID ) ); ?>"><?php echo esc_html( get_the_title( $post ) ); ?></a></td>
						<td><?php echo esc_html( number_format_i18n( (int) get_post_meta( $post->ID, Fields::CLICKS, true ) ) ); ?></td>
						<td><?php echo esc_html( implode( ', ', Archive::lacks( $post ) ) ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Import and propose, or apply.
	 */
	public static function handle(): void {
		Screen::check( self::SAVE );
		$do = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( (string) $_POST['do'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Screen::check().
		if ( 'apply' === $do ) {
			if ( empty( $_POST['approved'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Screen::check().
				Screen::flash( 'error', array( __( 'No se ha aplicado nada: marca que la lista está aprobada.', 'lachinata-core' ) ) );
				Screen::redirect( self::TAB );
			}
			$result = Archive::apply( false );
			$lines  = array();
			foreach ( $result['applied'] as $decision => $count ) {
				$lines[] = $decision . ': ' . number_format_i18n( $count );
			}
			Screen::flash( 'success', array_merge( array( __( 'Lista aplicada.', 'lachinata-core' ) . ' ' . implode( ' · ', $lines ) ), array_slice( $result['notes'], 0, 20 ) ) );
			Screen::redirect( self::TAB );
		}
		$messages = array();
		foreach ( array( 'list', 'gsc' ) as $field ) {
			$file = isset( $_FILES[ $field ]['tmp_name'] ) ? (string) $_FILES[ $field ]['tmp_name'] : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Screen::check(); a temporary path.
			if ( '' === $file || ! is_uploaded_file( $file ) ) {
				continue;
			}
			if ( 'list' === $field ) {
				$stats = Archive::import_list( $file );
				/* translators: 1: rows, 2: matched entries, 3: final decisions. */
				$messages[] = sprintf( __( 'Lista: %1$s filas, %2$s entradas, %3$s con decisión final.', 'lachinata-core' ), number_format_i18n( $stats['rows'] ), number_format_i18n( $stats['matched'] ), number_format_i18n( $stats['final'] ) );
			} else {
				$stats = Archive::import_gsc( $file );
				/* translators: 1: rows, 2: matched entries. */
				$messages[] = sprintf( __( 'Search Console: %1$s filas, %2$s entradas.', 'lachinata-core' ), number_format_i18n( $stats['rows'] ), number_format_i18n( $stats['matched'] ) );
			}
		}
		Archive::count_inbound();
		$proposed = Archive::propose();
		/* translators: %s: number of entries. */
		$messages[] = sprintf( __( 'Las reglas proponen para %s entradas que no están en la lista.', 'lachinata-core' ), number_format_i18n( array_sum( $proposed ) ) );
		Screen::flash( 'success', $messages );
		Screen::redirect( self::TAB );
	}
}
