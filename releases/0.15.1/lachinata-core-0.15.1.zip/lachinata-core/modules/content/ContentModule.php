<?php
/**
 * Module `content`: the blog and the recipes.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

use LaChinata\Core\Hooks;
use LaChinata\Core\Module;
use LaChinata\Core\Plugin;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Posts keep their URL (`/slug/`) and gain a format (recipe, article or news), sections
 * in `/blog/{section}/` (recipes have subsections by type of dish), up to 20 curated
 * topics, a short answer («En pocas palabras»), the date of the last real review and, for
 * health and beauty, linked sources. Recipes are data (block `lachinata/receta`): the
 * module prints them with the components of the system, generates their `Recipe`, scales
 * them, offers the cook mode and the products of the shop they use, and shows recipes on
 * the product page, the thank you page and the shipped email. Rank Math stays for titles,
 * descriptions, sitemaps and redirections; the module emits its own structured data where
 * Rank Math falls short and switches Rank Math's off there.
 */
final class ContentModule extends Module {

	/**
	 * Module id.
	 */
	public function id(): string {
		return 'content';
	}

	/**
	 * Module name.
	 */
	public function label(): string {
		return __( 'Blog y recetas', 'lachinata-core' );
	}

	/**
	 * Module description.
	 */
	public function description(): string {
		return __( 'Revista del blog con secciones y temas, recetas estructuradas con raciones que escalan, modo cocina y los productos de la tienda que usan, recetas en la ficha de producto, fechas de publicación y revisión, y datos estructurados propios.', 'lachinata-core' );
	}

	/**
	 * Version in which the module was added.
	 */
	public function since(): string {
		return '0.13.0';
	}

	/**
	 * Documentation.
	 */
	public function docs(): string {
		return 'plugin/modules/content/README.md';
	}

	/**
	 * Requirements.
	 *
	 * @return array{woocommerce: string}
	 */
	public function requires(): array {
		return array( 'woocommerce' => '10.0' );
	}

	/**
	 * Settings. Texts and thresholds travel in the JSON; the sections and categories go by
	 * slug so that they hold in another shop.
	 *
	 * @return array<string, array{type: 'bool'|'int'|'float'|'string'|'array', default: mixed, export?: bool}>
	 */
	public function settings(): array {
		$copy = static fn( string $type, $value, bool $export = true ): array => array(
			'type'    => $type,
			'default' => $value,
			'export'  => $export,
		);
		return array(
			'blog_eyebrow'        => $copy( 'string', '' ),
			'blog_title'          => $copy( 'string', '' ),
			'blog_lead'           => $copy( 'string', '' ),
			'recipe_section'      => $copy( 'string', '' ),
			'health_sections'     => $copy( 'array', array() ),
			'subsection_minimum'  => $copy( 'int', 6 ),
			'news_warning_months' => $copy( 'int', 12 ),
			'review_months'       => $copy( 'int', 12 ),
			'product_recipes'     => $copy( 'array', array() ),
			'category_sections'   => $copy( 'array', array() ),
			'own_hosts'           => $copy( 'array', array(), false ),
			'llms_about'          => $copy( 'string', '' ),
			'llms_pages'          => $copy( 'array', array(), false ),
			'llms_articles'       => $copy( 'int', 30 ),
			'llms_recipes'        => $copy( 'int', 30 ),
			'crawlers'            => $copy( 'array', array() ),
		);
	}

	/**
	 * A setting of the module.
	 *
	 * @param string $key Setting key.
	 * @return mixed
	 */
	public static function setting( string $key ) {
		$module = self::instance();
		return null === $module ? null : Settings::get( $module, $key );
	}

	/**
	 * The module, for Settings.
	 */
	public static function instance(): ?Module {
		return Plugin::instance()->modules()->get( 'content' );
	}

	/**
	 * Sections, recipes and posts that need a review.
	 *
	 * @return array{configured: bool, credentials: bool|null, notes: string[]}
	 */
	public function health(): array {
		$notes    = array();
		$sections = get_terms(
			array(
				'taxonomy'   => Model::SECTION,
				'parent'     => 0,
				'hide_empty' => false,
				'fields'     => 'ids',
			)
		);
		$sections = is_array( $sections ) ? $sections : array();
		$recipes  = Query::count_format( Model::RECIPE );
		/* translators: 1: number of sections, 2: number of recipes. */
		$notes[] = sprintf( __( '%1$s secciones, %2$s recetas', 'lachinata-core' ), number_format_i18n( count( $sections ) ), number_format_i18n( $recipes ) );
		$stale   = Freshness::stale_health_posts();
		if ( $stale ) {
			/* translators: 1: number of posts, 2: months. */
			$notes[] = sprintf( _n( '%1$s entrada de salud y belleza sin revisar en %2$s meses', '%1$s entradas de salud y belleza sin revisar en %2$s meses', count( $stale ), 'lachinata-core' ), number_format_i18n( count( $stale ) ), number_format_i18n( Freshness::review_months() ) );
		}
		$missing = Ai::missing_pages();
		if ( $missing ) {
			/* translators: %s: pages («Acerca de, Contacto»). */
			$notes[] = sprintf( __( 'llms.txt sin estas páginas clave (elígelas en la pestaña Blog): %s', 'lachinata-core' ), implode( ', ', $missing ) );
		}
		$broken = Retired::broken();
		if ( $broken ) {
			/* translators: %s: number of entries. */
			$notes[] = sprintf( _n( '%s entrada retirada cuyo destino ya no existe: responde con 301 a su sección', '%s entradas retiradas cuyo destino ya no existe: responden con 301 a su sección', count( $broken ), 'lachinata-core' ), number_format_i18n( count( $broken ) ) );
		}
		if ( ! Seo::rank_math() ) {
			$notes[] = __( 'Rank Math no está activo: títulos, descripciones y sitemaps quedan sin él.', 'lachinata-core' );
		}
		return array(
			'configured'  => (bool) $sections,
			'credentials' => null,
			'notes'       => $notes,
		);
	}

	/**
	 * Term meta of the sections and of the product and post categories. The posts and
	 * their fields are content of the site: «Borrar datos» never deletes them.
	 *
	 * @return array{term_meta: string[]}
	 */
	public function owned_data(): array {
		return array(
			'term_meta' => array( Fields::SECTION_PRODUCTS, Fields::SECTION_ORDER ),
		);
	}

	/**
	 * Registers the hooks.
	 */
	public function boot(): void {
		Model::boot();
		Hooks::add_filter( 'lachinata/translate/fields', array( Fields::class, 'translatable' ) );
		RecipeBlock::boot();
		Pages::boot();
		Redirects::boot();
		Seo::boot();
		ProductRecipes::boot();
		Mentions::boot();
		Retired::boot();
		Ai::boot();
		Freshness::boot();
		if ( is_admin() ) {
			Editor::boot();
			SectionFields::boot();
			ContentTab::boot();
			ArchiveTab::boot();
		}
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::add_command( 'lachinata content', Cli::class );
		}
	}
}
