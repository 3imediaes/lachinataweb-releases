<?php
/**
 * Publication and review dates.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

defined( 'ABSPATH' ) || exit;

/**
 * The publication date is always shown; «Actualizado el» only after a real review (the
 * date the editor marks, Fields::REVIEWED), never after any save. The same dates go to the
 * structured data (`datePublished`, `dateModified`).
 */
final class Dates {

	/**
	 * Dates of an entry: published, and updated when it was reviewed after publishing.
	 *
	 * @param \WP_Post $post Post.
	 * @return array{published: int, updated: int|null}
	 */
	public static function of( \WP_Post $post ): array {
		$published = (int) get_post_time( 'U', true, $post );
		$reviewed  = (string) get_post_meta( $post->ID, Fields::REVIEWED, true );
		$updated   = null;
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $reviewed ) ) {
			$date = date_create_immutable( $reviewed . ' 12:00:00', wp_timezone() );
			if ( $date && $date->getTimestamp() > $published + DAY_IN_SECONDS ) {
				$updated = $date->getTimestamp();
			}
		}
		return array(
			'published' => $published,
			'updated'   => $updated,
		);
	}

	/**
	 * Last real change of an entry: the review, or the publication.
	 *
	 * @param \WP_Post $post Post.
	 */
	public static function last( \WP_Post $post ): int {
		$dates = self::of( $post );
		return $dates['updated'] ?? $dates['published'];
	}
}
