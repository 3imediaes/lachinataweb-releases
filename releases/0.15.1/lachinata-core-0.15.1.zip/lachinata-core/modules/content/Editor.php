<?php
/**
 * The editor of the entries.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * The block of the recipe and the panel «Blog y recetas» of the entry (format, «En pocas
 * palabras», date of the review with «Revisado hoy», sources and the reasons to review)
 * share one script. Its data (formats, difficulties, reasons) go inline.
 */
final class Editor {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'enqueue_block_editor_assets', array( self::class, 'enqueue' ) );
	}

	/**
	 * The script and its data in the editor of an entry.
	 */
	public static function enqueue(): void {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( null === $screen || 'post' !== $screen->post_type ) {
			return;
		}
		$post = get_post();
		wp_enqueue_script( RecipeBlock::EDITOR );
		$difficulties = array();
		foreach ( Recipe::DIFFICULTIES as $difficulty ) {
			$difficulties[] = array(
				'value' => $difficulty,
				'label' => Recipe::difficulty( $difficulty ),
			);
		}
		$formats = array();
		foreach ( Model::formats() as $value => $label ) {
			$formats[] = array(
				'value' => $value,
				'label' => $label,
			);
		}
		$data = array(
			'formats'      => $formats,
			'difficulties' => $difficulties,
			'reasons'      => $post instanceof \WP_Post ? Freshness::reasons( $post->ID ) : array(),
			'tocFrom'      => Text::TOC_FROM,
		);
		wp_add_inline_script( RecipeBlock::EDITOR, 'window.lachinataContent = ' . wp_json_encode( $data, JSON_HEX_TAG | JSON_UNESCAPED_UNICODE ) . ';', 'before' );
	}
}
