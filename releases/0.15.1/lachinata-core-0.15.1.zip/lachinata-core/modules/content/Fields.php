<?php
/**
 * Meta keys of the module.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

defined( 'ABSPATH' ) || exit;

/**
 * Post meta of the entries and term meta of the sections. The recipe itself lives in the
 * block `lachinata/receta` of the post content; RECIPE, PRODUCT and MINUTES are an index
 * of it that the module rewrites on every save (cards, «Recetas con este producto»).
 */
final class Fields {

	/**
	 * Format of the entry: Model::RECIPE, Model::ARTICLE or Model::NEWS.
	 */
	public const FORMAT = '_lc_content_formato';

	/**
	 * «En pocas palabras»: the short answer, plain text (two or three sentences).
	 */
	public const SUMMARY = '_lc_content_resumen';

	/**
	 * Date of the last real review (Y-m-d), set by the editor; not any save.
	 */
	public const REVIEWED = '_lc_content_revisado';

	/**
	 * Linked sources of a health and beauty entry: list of {title, url}.
	 */
	public const SOURCES = '_lc_content_fuentes';

	/**
	 * Index of the recipe (Recipe::index()): servings, minutes, difficulty, dish, products.
	 */
	public const RECIPE = '_lc_content_receta';

	/**
	 * One row per product the recipe uses (local id), for «Recetas con este producto».
	 */
	public const PRODUCT = '_lc_content_producto';

	/**
	 * Total minutes of the recipe (computed), for the cards.
	 */
	public const MINUTES = '_lc_content_minutos';

	/**
	 * Words of the text (reading time and the table of contents from 1,200).
	 */
	public const WORDS = '_lc_content_palabras';

	/**
	 * Clicks of Search Console (imported from the CSV), for «Lo más leído».
	 */
	public const CLICKS = '_lc_content_clics';

	/**
	 * One row per product the text mentions (references `data-lc-product` and the recipe).
	 */
	public const MENTIONS = '_lc_content_menciona';

	/**
	 * One row per store the entry mentions (slug of its page), from its links and, in news,
	 * its title.
	 */
	public const STORES = '_lc_content_oleoteca';

	/**
	 * Reasons to review the entry (list of {code, text, at}), shown to the editor.
	 */
	public const REVIEW = '_lc_content_revisar';

	/**
	 * Section term: product category (slug) of the products shown with its articles.
	 */
	public const SECTION_PRODUCTS = '_lc_content_categoria';

	/**
	 * Section term: position in the magazine (lower first).
	 */
	public const SECTION_ORDER = '_lc_content_orden';

	/**
	 * What `translate` translates of the blog besides the title, entradilla and body of
	 * the entries: «En pocas palabras», the titles of the sources and the sections, with
	 * their own address (`/en/blog/{sección}/`).
	 *
	 * @param mixed $fields Translatable fields by kind.
	 * @return mixed
	 */
	public static function translatable( $fields ) {
		if ( ! is_array( $fields ) ) {
			return $fields;
		}
		$fields['post:post']['summary']     = array(
			'label'  => __( 'En pocas palabras', 'lachinata-core' ),
			'source' => 'meta',
			'key'    => self::SUMMARY,
		);
		$fields['post:post']['sources']     = array(
			'label'    => __( 'Fuentes', 'lachinata-core' ),
			'source'   => 'meta',
			'key'      => self::SOURCES,
			'format'   => 'json',
			'required' => false,
		);
		$fields[ 'term:' . Model::SECTION ] = array(
			'name'        => array(
				'label'  => __( 'Nombre', 'lachinata-core' ),
				'source' => 'term',
				'key'    => 'name',
			),
			'description' => array(
				'label'  => __( 'Descripción', 'lachinata-core' ),
				'source' => 'term',
				'key'    => 'description',
			),
			'slug'        => array(
				'label'    => __( 'Slug', 'lachinata-core' ),
				'source'   => 'term',
				'key'      => 'slug',
				'required' => false,
			),
		);
		return $fields;
	}
}
