<?php
/**
 * Analyser of ingredient lines.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

defined( 'ABSPATH' ) || exit;

/**
 * Splits a line written by hand («400 gramos de queso de untar», «125g harina», «Sal al
 * gusto», «1/2 cucharadita de pimentón (dulce)») into quantity, unit, ingredient and note,
 * with the metric units written the short way (g, kg, ml, cl, l). What it is not sure about
 * is marked as doubtful with the reason, for the report and for whoever reviews.
 *
 * @phpstan-type Parsed array{qty: string, unit: string, name: string, note: string, doubtful: bool, reason: string}
 */
final class Ingredients {

	/**
	 * Units: what is written → how it is written in the recipe.
	 */
	private const UNITS = array(
		'kilogramos'   => 'kg',
		'kilogramo'    => 'kg',
		'kilos'        => 'kg',
		'kilo'         => 'kg',
		'kgs'          => 'kg',
		'kg'           => 'kg',
		'gramos'       => 'g',
		'gramo'        => 'g',
		'grs'          => 'g',
		'gr'           => 'g',
		'g'            => 'g',
		'mililitros'   => 'ml',
		'mililitro'    => 'ml',
		'ml'           => 'ml',
		'centilitros'  => 'cl',
		'centilitro'   => 'cl',
		'cl'           => 'cl',
		'litros'       => 'l',
		'litro'        => 'l',
		'lt'           => 'l',
		'l'            => 'l',
		'cucharaditas' => 'cucharaditas',
		'cucharadita'  => 'cucharadita',
		'cdtas'        => 'cucharaditas',
		'cdta'         => 'cucharadita',
		'cucharadas'   => 'cucharadas',
		'cucharada'    => 'cucharada',
		'cdas'         => 'cucharadas',
		'cda'          => 'cucharada',
		'tazas'        => 'tazas',
		'taza'         => 'taza',
		'vasos'        => 'vasos',
		'vaso'         => 'vaso',
		'copas'        => 'copas',
		'copa'         => 'copa',
		'pizcas'       => 'pizcas',
		'pizca'        => 'pizca',
		'dientes'      => 'dientes',
		'diente'       => 'diente',
		'unidades'     => 'unidades',
		'unidad'       => 'unidad',
		'latas'        => 'latas',
		'lata'         => 'lata',
		'sobres'       => 'sobres',
		'sobre'        => 'sobre',
		'hojas'        => 'hojas',
		'hoja'         => 'hoja',
		'ramitas'      => 'ramitas',
		'ramita'       => 'ramita',
		'ramas'        => 'ramas',
		'rama'         => 'rama',
		'puñados'      => 'puñados',
		'puñado'       => 'puñado',
		'chorritos'    => 'chorritos',
		'chorrito'     => 'chorrito',
		'chorros'      => 'chorros',
		'chorro'       => 'chorro',
		'lonchas'      => 'lonchas',
		'loncha'       => 'loncha',
		'rebanadas'    => 'rebanadas',
		'rebanada'     => 'rebanada',
		'rodajas'      => 'rodajas',
		'rodaja'       => 'rodaja',
		'manojos'      => 'manojos',
		'manojo'       => 'manojo',
		'botes'        => 'botes',
		'bote'         => 'bote',
		'paquetes'     => 'paquetes',
		'paquete'      => 'paquete',
		'tarros'       => 'tarros',
		'tarro'        => 'tarro',
		'piezas'       => 'piezas',
		'pieza'        => 'pieza',
		'filetes'      => 'filetes',
		'filete'       => 'filete',
		'cabezas'      => 'cabezas',
		'cabeza'       => 'cabeza',
		'vainas'       => 'vainas',
		'vaina'        => 'vaina',
		'bolas'        => 'bolas',
		'bola'         => 'bola',
		'cubitos'      => 'cubitos',
		'cubito'       => 'cubito',
	);

	/**
	 * Quantities written as words.
	 */
	private const WORDS = array(
		'media'  => '1/2',
		'medio'  => '1/2',
		'un'     => '1',
		'una'    => '1',
		'uno'    => '1',
		'dos'    => '2',
		'tres'   => '3',
		'cuatro' => '4',
		'cinco'  => '5',
		'seis'   => '6',
		'siete'  => '7',
		'ocho'   => '8',
		'nueve'  => '9',
		'diez'   => '10',
		'doce'   => '12',
	);

	/**
	 * Notes that mean «as much as you like»: the line has no quantity and it is fine.
	 */
	private const TO_TASTE = array( 'al gusto', 'c/s', 'c.s.', 'cantidad suficiente', 'opcional', 'para decorar', 'para servir' );

	/**
	 * Splits a line.
	 *
	 * @param string $line Line as written.
	 * @return Parsed
	 */
	public static function parse( string $line ): array {
		// Old texts carry loose Latin-1 bytes (a middle dot as a bullet) that break /u.
		$line = (string) mb_convert_encoding( $line, 'UTF-8', 'UTF-8' );
		$line = (string) preg_replace( '/^\?\s*/', '', $line );
		$line = trim( (string) preg_replace( '/\s+/u', ' ', html_entity_decode( wp_strip_all_tags( $line ), ENT_QUOTES, 'UTF-8' ) ), " \t\n\r\0\x0B-*" );
		$line = rtrim( $line, '.;' );
		// List bullets of old texts («●», «», «-») and the fraction slash («1⁄2»).
		$line = trim( (string) preg_replace( '/^[^\p{L}\p{N}½¼¾⅓⅔]+/u', '', str_replace( '⁄', '/', $line ) ) );
		$note = '';
		// A note in brackets, or after the first comma.
		if ( preg_match( '/\s*\(([^)]*)\)\s*$/u', $line, $m ) ) {
			$note = trim( $m[1] );
			$line = trim( substr( $line, 0, -strlen( $m[0] ) ) );
		}
		foreach ( self::TO_TASTE as $phrase ) {
			if ( preg_match( '/[\s,]+' . preg_quote( $phrase, '/' ) . '$/iu', $line, $m ) ) {
				$note = trim( $phrase . ( '' !== $note ? ', ' . $note : '' ) );
				$line = trim( substr( $line, 0, -strlen( $m[0] ) ) );
				break;
			}
		}
		// A comma that is not a decimal one («1,5 l»).
		if ( preg_match( '/,(?!\d)/u', $line ) ) {
			list( $line, $rest ) = array_map( 'trim', (array) preg_split( '/,(?!\d)/u', $line, 2 ) );
			$note                = trim( $rest . ( '' !== $note ? ', ' . $note : '' ) );
		}
		$qty  = '';
		$unit = '';
		// Quantity: 1 1/2, 1/2, 1,5, 125, ½ … glued to a unit («125g») or not.
		$fraction = '½|¼|¾|⅓|⅔';
		if ( preg_match( '/^(\d+\s+\d+\/\d+|\d+\/\d+|\d+(?:[.,]\d+)?(?:\s*(?:-|o|a)\s*\d+(?:[.,]\d+)?(?=\s|\p{L}))?|' . $fraction . ')\s*/u', $line, $m ) ) {
			$qty  = str_replace( '.', ',', trim( $m[1] ) );
			$qty  = strtr(
				$qty,
				array(
					'½' => '1/2',
					'¼' => '1/4',
					'¾' => '3/4',
					'⅓' => '1/3',
					'⅔' => '2/3',
				)
			);
			$line = trim( substr( $line, strlen( $m[0] ) ) );
		} elseif ( preg_match( '/^(' . implode( '|', array_keys( self::WORDS ) ) . ')\s+/iu', $line, $m ) ) {
			$qty  = self::WORDS[ mb_strtolower( $m[1] ) ];
			$line = trim( substr( $line, strlen( $m[0] ) ) );
		}
		if ( preg_match( '/^([\p{L}.]+)\.?(?:\s+|$)/u', $line, $m ) && isset( self::UNITS[ mb_strtolower( rtrim( $m[1], '.' ) ) ] ) && ( '' !== $qty || in_array( mb_strtolower( $m[1] ), array( 'pizca', 'chorrito', 'chorro', 'puñado' ), true ) ) ) {
			$unit = self::UNITS[ mb_strtolower( rtrim( $m[1], '.' ) ) ];
			$line = trim( substr( $line, strlen( $m[0] ) ) );
		}
		$line = (string) preg_replace( '/^(de|del)\s+/iu', '', $line );
		$name = trim( $line );
		// «Queso de untar» → «queso de untar»; «AOVE» stays.
		$first  = mb_substr( $name, 0, 1 );
		$second = mb_substr( $name, 1, 1 );
		if ( '' !== $first && mb_strtolower( $first ) !== $first && mb_strtolower( $second ) === $second ) {
			$name = mb_strtolower( $first ) . mb_substr( $name, 1 );
		}

		$reason = '';
		if ( '' === $name ) {
			$reason = __( 'sin ingrediente', 'lachinata-core' );
		} elseif ( preg_match( '/\d/', $name ) ) {
			$reason = __( 'quedan números en el ingrediente', 'lachinata-core' );
		} elseif ( mb_strlen( $name ) > 90 ) {
			$reason = __( 'parece una frase, no un ingrediente', 'lachinata-core' );
		} elseif ( '' === $qty && '' === $note && ! self::is_seasoning( $name ) ) {
			$reason = __( 'sin cantidad', 'lachinata-core' );
		} elseif ( '' !== $qty && '' === $unit && preg_match( '/^(gramos?|gr|kilos?|litros?)\b/iu', $name ) ) {
			$reason = __( 'unidad sin reconocer', 'lachinata-core' );
		}
		return array(
			'qty'      => $qty,
			'unit'     => $unit,
			'name'     => $name,
			'note'     => $note,
			'doubtful' => '' !== $reason,
			'reason'   => $reason,
		);
	}

	/**
	 * Whether an ingredient usually goes without quantity (salt, pepper, water…).
	 *
	 * @param string $name Ingredient.
	 */
	private static function is_seasoning( string $name ): bool {
		return (bool) preg_match( '/^(sal|pimienta|agua|hielo|perejil|tomillo|orégano|romero|albahaca|cilantro|eneldo|azúcar glas)\b/iu', $name );
	}
}
