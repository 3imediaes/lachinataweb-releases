<?php
/**
 * The magazine (`/blog/`).
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

defined( 'ABSPATH' ) || exit;

/**
 * What the magazine shows, worked out once per request: the newest recipe big, the most
 * read (the clicks of Search Console when imported), and each root section in its order
 * with its newest entries (four recipe cards in the recipe section, three horizontal cards
 * in the rest). The big entry is not repeated.
 *
 * @phpstan-type Block array{section: \WP_Term, posts: \WP_Post[], recipes: bool, count: int}
 * @phpstan-type Layout array{feature: \WP_Post|null, most_read: \WP_Post[], sections: array<int, Block>}
 */
final class Magazine {

	/**
	 * Layout of this request.
	 *
	 * @var Layout|null
	 */
	private static ?array $layout = null;

	/**
	 * The layout of the magazine.
	 *
	 * @return Layout
	 */
	public static function layout(): array {
		if ( null !== self::$layout ) {
			return self::$layout;
		}
		$feature = Query::latest( Model::RECIPE );
		if ( null === $feature ) {
			$posts   = Query::posts( array( 'posts_per_page' => 1 ) );
			$feature = $posts[0] ?? null;
		}
		$shown = null === $feature ? array() : array( $feature->ID );
		// «Lo más leído» may repeat an entry of the sections (as in the board); never the big one.
		$most_read = Query::most_read( 3, $shown );
		$recipes   = Model::recipe_section();
		$sections  = array();
		foreach ( Model::roots() as $root ) {
			$is_recipes = null !== $recipes && $recipes->term_id === $root->term_id;
			$posts      = Query::in_section( $root, $is_recipes ? 4 : 3, $shown );
			if ( ! $posts ) {
				continue;
			}
			$shown      = array_merge( $shown, wp_list_pluck( $posts, 'ID' ) );
			$sections[] = array(
				'section' => $root,
				'posts'   => $posts,
				'recipes' => $is_recipes,
				'count'   => $is_recipes ? Query::count_format( Model::RECIPE, $root ) : 0,
			);
		}
		self::$layout = array(
			'feature'   => $feature,
			'most_read' => $most_read,
			'sections'  => $sections,
		);
		return self::$layout;
	}

	/**
	 * Every entry the magazine shows, in order (ItemList).
	 *
	 * @return \WP_Post[]
	 */
	public static function listed(): array {
		$layout = self::layout();
		$posts  = null === $layout['feature'] ? array() : array( $layout['feature'] );
		$posts  = array_merge( $posts, $layout['most_read'] );
		foreach ( $layout['sections'] as $block ) {
			$posts = array_merge( $posts, $block['posts'] );
		}
		return $posts;
	}

	/**
	 * Forgets the layout (tests).
	 */
	public static function reset(): void {
		self::$layout = null;
	}
}
