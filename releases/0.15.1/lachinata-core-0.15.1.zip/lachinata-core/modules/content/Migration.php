<?php
/**
 * Migration of the blog.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * From the old blog to the module, with a dry run and a report before touching anything.
 * The shop's choices come in a map (JSON, never in the code): its sections, where each old
 * category goes (format and section, by priority), the types of dish of Rank Math's
 * `recipeCategory` as subsections, the difficulties and the product categories with
 * recipes. Then, for each entry: format and section; for each recipe (Rank Math's `Recipe`
 * or the recipe category), the block from the schema and the text (an analyser splits the
 * ingredients and marks what is doubtful; the pieces of the text that the block now holds
 * go away), and the reasons to review it. Also: the 301 of the old categories, the clicks
 * of Search Console for «Lo más leído» and the shortcodes left in the texts. Running it
 * again changes nothing that is already done.
 *
 * @phpstan-type Map array{sections?: array<int, array<string, mixed>>, texts?: array<string, string>, not_recipe?: array{format?: string, section?: string}, overrides?: array<string, array<string, mixed>>, own_hosts?: string[], section_by_products?: array<string, mixed>, recipe_section?: string, health_sections?: string[], product_recipes?: string[], categories?: array<string, array{format?: string, section?: string}>, priority?: string[], dishes?: array<string, string>, difficulty?: array<string, string>}
 * @phpstan-import-type Data from Recipe
 */
final class Migration {

	/**
	 * Schema of Rank Math kept in each post.
	 */
	public const RANK_MATH_RECIPE = 'rank_math_schema_Recipe';

	/**
	 * Report of the run.
	 *
	 * @var array<string, mixed>
	 */
	private array $report = array(
		'posts'          => 0,
		'formats'        => array(),
		'sections'       => array(),
		'no_section'     => array(),
		'recipes'        => array(),
		'shortcodes'     => array(),
		'clicks'         => array(
			'rows'    => 0,
			'matched' => 0,
			'missing' => array(),
		),
		'created'        => array(),
		'not_recipes'    => array(),
		'overrides'      => array(),
		'links'          => array(
			'converted'  => 0,
			'unresolved' => array(),
		),
		'by_products'    => array(
			'moved'    => array(),
			'doubtful' => array(),
		),
		'stores_missing' => array(),
		'slugs'          => array(
			'changed'  => array(),
			'conflict' => array(),
		),
	);

	/**
	 * Report row of the recipe being migrated (doubtful lines, products, unresolved links).
	 *
	 * @var array<string, mixed>
	 */
	private array $row = array();

	/**
	 * Domains of the shop in the old texts: those of the map, also in a dry run.
	 *
	 * @var string[]
	 */
	private array $hosts = array();

	/**
	 * Runs the migration.
	 *
	 * @param array<string, mixed> $map     Choices of the shop.
	 * @phpstan-param Map $map
	 * @param bool                 $dry_run Whether nothing is written.
	 * @param string|null          $gsc     CSV of Search Console (pages), or null.
	 * @param string|null          $urls    CSV of the live address of each entry (post_id,
	 *                                      url_actual), or null.
	 * @return array<string, mixed> Report.
	 */
	public function run( array $map, bool $dry_run, ?string $gsc = null, ?string $urls = null ): array {
		if ( null !== $urls ) {
			$this->slugs( $urls, $dry_run );
		}
		$this->sections( $map, $dry_run );
		$this->settings( $map, $dry_run );
		$this->hosts = array_map( 'strval', (array) ( $map['own_hosts'] ?? ContentModule::setting( 'own_hosts' ) ) );
		$posts       = get_posts(
			array(
				'post_type'      => 'post',
				'post_status'    => array( 'publish', 'draft', 'pending', 'future', 'private' ),
				'posts_per_page' => -1,
				'orderby'        => 'ID',
				'order'          => 'ASC',
			)
		);
		foreach ( $posts as $post ) {
			if ( $post instanceof \WP_Post ) {
				$this->entry( $post, $map, $dry_run );
			}
		}
		if ( null !== $gsc ) {
			$this->clicks( $gsc, $dry_run );
		}
		return $this->report;
	}

	/**
	 * The live address of each entry as its slug: a plugin of the old site (Permalink
	 * Manager) answered some entries at an address that is not their slug. The old slug
	 * goes on answering with a 301 (`_wp_old_slug` of WordPress).
	 *
	 * @param string $file    CSV with post_id and url_actual.
	 * @param bool   $dry_run Dry run.
	 */
	private function slugs( string $file, bool $dry_run ): void {
		foreach ( Archive::csv( $file ) as $line ) {
			$post = get_post( absint( $line['post_id'] ?? 0 ) );
			$path = trim( (string) wp_parse_url( (string) ( $line['url_actual'] ?? '' ), PHP_URL_PATH ), '/' );
			if ( ! $post instanceof \WP_Post || 'post' !== $post->post_type || '' === $path || str_contains( $path, '/' ) ) {
				continue;
			}
			$slug = sanitize_title( rawurldecode( $path ) );
			if ( $slug === $post->post_name || rawurldecode( $post->post_name ) === $slug ) {
				continue;
			}
			$taken = get_page_by_path( $slug, OBJECT, array( 'post', 'page', 'product' ) );
			if ( $taken instanceof \WP_Post && $taken->ID !== $post->ID ) {
				$this->report['slugs']['conflict'][] = sprintf( '%1$s: /%2$s/ ya es de #%3$d', $this->label( $post ), $slug, $taken->ID );
				continue;
			}
			$this->report['slugs']['changed'][] = sprintf( '%1$s: /%2$s/ → /%3$s/', $this->label( $post ), rawurldecode( $post->post_name ), $slug );
			if ( ! $dry_run ) {
				// wp_update_post keeps the old slug in _wp_old_slug for a published entry.
				wp_update_post(
					array(
						'ID'        => $post->ID,
						'post_name' => $slug,
					)
				);
				if ( 'publish' !== $post->post_status ) {
					add_post_meta( $post->ID, '_wp_old_slug', $post->post_name );
				}
			}
		}
	}

	/**
	 * Creates the sections of the map that are missing, with their text, order and
	 * products.
	 *
	 * @param array<string, mixed> $map     Map.
	 * @phpstan-param Map $map
	 * @param bool                 $dry_run Dry run.
	 */
	private function sections( array $map, bool $dry_run ): void {
		foreach ( (array) ( $map['sections'] ?? array() ) as $section ) {
			$slug = sanitize_title( (string) ( $section['slug'] ?? '' ) );
			$name = (string) ( $section['name'] ?? '' );
			if ( '' === $slug || '' === $name ) {
				continue;
			}
			$term = get_term_by( 'slug', $slug, Model::SECTION );
			if ( ! $term instanceof \WP_Term ) {
				$this->report['created'][] = $name;
				if ( $dry_run ) {
					continue;
				}
				$made = wp_insert_term(
					$name,
					Model::SECTION,
					array(
						'slug'        => $slug,
						'description' => (string) ( $section['text'] ?? '' ),
					)
				);
				if ( is_wp_error( $made ) ) {
					continue;
				}
				$term = get_term( (int) $made['term_id'], Model::SECTION );
			}
			if ( ! $term instanceof \WP_Term || $dry_run ) {
				continue;
			}
			if ( isset( $section['order'] ) ) {
				update_term_meta( $term->term_id, Fields::SECTION_ORDER, (int) $section['order'] );
			}
			if ( ! empty( $section['products'] ) ) {
				update_term_meta( $term->term_id, Fields::SECTION_PRODUCTS, sanitize_title( (string) $section['products'] ) );
			}
		}
	}

	/**
	 * Settings of the module from the map.
	 *
	 * @param array<string, mixed> $map     Map.
	 * @phpstan-param Map $map
	 * @param bool                 $dry_run Dry run.
	 */
	private function settings( array $map, bool $dry_run ): void {
		$module = ContentModule::instance();
		if ( null === $module || $dry_run ) {
			return;
		}
		$categories = array();
		foreach ( (array) ( $map['categories'] ?? array() ) as $category => $target ) {
			if ( ! empty( $target['section'] ) ) {
				$categories[ sanitize_title( (string) $category ) ] = sanitize_title( (string) $target['section'] );
			}
		}
		Settings::set( $module, 'category_sections', $categories );
		if ( isset( $map['own_hosts'] ) ) {
			Settings::set( $module, 'own_hosts', array_values( array_filter( array_map( static fn( $host ): string => strtolower( trim( (string) $host ) ), (array) $map['own_hosts'] ) ) ) );
		}
		foreach ( array( 'health_sections', 'product_recipes' ) as $key ) {
			if ( isset( $map[ $key ] ) ) {
				Settings::set( $module, $key, array_values( array_map( 'sanitize_title', (array) $map[ $key ] ) ) );
			}
		}
		foreach ( array( 'blog_eyebrow', 'blog_title', 'blog_lead' ) as $key ) {
			if ( isset( $map['texts'][ $key ] ) ) {
				Settings::set( $module, $key, sanitize_text_field( (string) $map['texts'][ $key ] ) );
			}
		}
		if ( isset( $map['recipe_section'] ) ) {
			Settings::set( $module, 'recipe_section', sanitize_title( (string) $map['recipe_section'] ) );
		}
	}

	/**
	 * Format and section of an entry, and its recipe.
	 *
	 * @param \WP_Post             $post    Post.
	 * @param array<string, mixed> $map     Map.
	 * @phpstan-param Map $map
	 * @param bool                 $dry_run Dry run.
	 */
	private function entry( \WP_Post $post, array $map, bool $dry_run ): void {
		$override = (array) ( ( (array) ( $map['overrides'] ?? array() ) )[ (string) $post->ID ] ?? array() );
		if ( ! empty( $override['skip'] ) ) {
			$this->report['overrides'][] = sprintf( '%1$s: %2$s', $this->label( $post ), __( 'no se migra', 'lachinata-core' ) );
			return;
		}
		++$this->report['posts'];
		$target = $this->target( $post, $map );
		$schema = get_post_meta( $post->ID, self::RANK_MATH_RECIPE, true );
		$format = $target['format'];
		if ( is_array( $schema ) && $schema ) {
			$format = Model::RECIPE;
		}
		// Corrections by id of the map win over the rules.
		if ( isset( $override['format'] ) && isset( Model::formats()[ (string) $override['format'] ] ) ) {
			$format = (string) $override['format'];
		}
		if ( isset( $override['section'] ) ) {
			$target['section'] = sanitize_title( (string) $override['section'] );
		}
		$recipe = null;
		if ( Model::RECIPE === $format ) {
			$recipe = $this->recipe( $post, is_array( $schema ) ? $schema : array(), $map, isset( $override['format'] ) );
			if ( $recipe['not_recipe'] ) {
				// News of a contest or the press in the recipe category: not a recipe.
				$other                         = (array) ( $map['not_recipe'] ?? array() );
				$format                        = isset( Model::formats()[ (string) ( $other['format'] ?? '' ) ] ) ? (string) $other['format'] : Model::NEWS;
				$target['section']             = sanitize_title( (string) ( $other['section'] ?? $target['section'] ) );
				$this->report['not_recipes'][] = $this->label( $post );
				$recipe                        = null;
			}
		}
		// A recipe goes to the section of the recipes, whatever its old category.
		if ( Model::RECIPE === $format && ! empty( $map['recipe_section'] ) && ! isset( $override['section'] ) ) {
			$target['section'] = sanitize_title( (string) $map['recipe_section'] );
		}
		if ( $override ) {
			$this->report['overrides'][] = sprintf( '%1$s: %2$s', $this->label( $post ), implode( ', ', array_map( static fn( $key, $value ): string => $key . ' ' . ( is_scalar( $value ) ? (string) $value : '' ), array_keys( $override ), $override ) ) );
		}

		$content = null !== $recipe && null !== $recipe['content'] ? $recipe['content'] : $post->post_content;
		$content = $this->references( $post, $content );

		// The section of an old category that mixed subjects, by the products the entry links.
		$by_products = (array) ( $map['section_by_products'] ?? array() );
		if ( ! isset( $override['section'] ) && $by_products && in_array( (string) ( $by_products['category'] ?? '' ), (array) wp_get_post_categories( $post->ID, array( 'fields' => 'slugs' ) ), true ) && Model::RECIPE !== $format ) {
			$target['section'] = $this->section_by_products( $post, $content, (array) ( $by_products['sections'] ?? array() ), $target['section'] );
		}

		$this->report['formats'][ $format ] = ( $this->report['formats'][ $format ] ?? 0 ) + 1;
		if ( '' === $target['section'] ) {
			$this->report['no_section'][] = $this->label( $post );
		} else {
			$this->report['sections'][ $target['section'] ] = ( $this->report['sections'][ $target['section'] ] ?? 0 ) + 1;
		}
		$this->shortcodes( $post );

		$section = '' === $target['section'] ? false : get_term_by( 'slug', $target['section'], Model::SECTION );
		$terms   = $section instanceof \WP_Term ? array( $section->term_id ) : array();
		if ( null !== $recipe && $section instanceof \WP_Term && '' !== $recipe['dish'] ) {
			$sub = $this->subsection( $section, $recipe['dish'], $dry_run );
			if ( $sub instanceof \WP_Term ) {
				$terms = array( $sub->term_id );
			}
		}
		if ( $dry_run ) {
			return;
		}
		update_post_meta( $post->ID, Fields::FORMAT, $format );
		if ( $terms ) {
			wp_set_object_terms( $post->ID, $terms, Model::SECTION );
		}
		if ( $content !== $post->post_content ) {
			wp_update_post(
				array(
					'ID'           => $post->ID,
					'post_content' => wp_slash( $content ),
				)
			);
		}
		if ( null !== $recipe ) {
			foreach ( $recipe['reasons'] as $index => $text ) {
				Review::add( $post->ID, 'migration:' . $index, $text );
			}
		}
		$fresh = get_post( $post->ID );
		if ( $fresh instanceof \WP_Post ) {
			Model::on_save( $fresh->ID, $fresh );
			foreach ( Review::open( $fresh->ID ) as $reason ) {
				if ( str_starts_with( $reason['code'], 'store-missing:' ) ) {
					$this->report['stores_missing'][] = $this->label( $fresh ) . ' → ' . substr( $reason['code'], 14 );
				}
			}
		}
	}

	/**
	 * Links to products of the shop as references (`data-lc-product`): by the slug of an old
	 * `.html` page or of the product page, on this site or its production domain. Those that
	 * look like a product and cannot be found go to the report.
	 *
	 * @param \WP_Post $post    Post.
	 * @param string   $content Content.
	 */
	private function references( \WP_Post $post, string $content ): string {
		return (string) preg_replace_callback(
			'/<a\s([^>]*?)href=(["\'])([^"\']+)\2([^>]*)>/i',
			function ( array $link ) use ( $post ): string {
				if ( str_contains( $link[0], Mentions::ATTRIBUTE ) || ! self::looks_like_product( $link[3] ) || ! $this->own_link( $link[3] ) ) {
					return $link[0];
				}
				$product = self::product_from_url( $link[3] );
				if ( null === $product ) {
					$this->report['links']['unresolved'][ $link[3] ][] = $post->ID;
					return $link[0];
				}
				$this->report['links']['converted'] = (int) ( $this->report['links']['converted'] ?? 0 ) + 1;
				return '<a ' . $link[1] . 'href=' . $link[2] . esc_url( $product->get_permalink() ) . $link[2] . ' ' . Mentions::ATTRIBUTE . '="' . $product->get_id() . '"' . $link[4] . '>';
			},
			$content
		);
	}

	/**
	 * Whether a link is of this site or of its production domain (relative ones too).
	 *
	 * @param string $url Link.
	 */
	private function own_link( string $url ): bool {
		$host = (string) wp_parse_url( $url, PHP_URL_HOST );
		if ( '' === $host ) {
			return true;
		}
		$hosts = array_merge( array( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ), $this->hosts );
		$host  = (string) preg_replace( '/^www\./', '', strtolower( $host ) );
		return in_array( $host, array_map( static fn( string $item ): string => (string) preg_replace( '/^www\./', '', strtolower( $item ) ), $hosts ), true );
	}

	/**
	 * Section by the root categories of the products an entry links: the one most of them
	 * belong to; a tie or no product, the current one, to the report.
	 *
	 * @param \WP_Post             $post     Post.
	 * @param string               $content  Content with references.
	 * @param array<string, mixed> $sections Section by root product category slug.
	 * @param string               $current  Current section.
	 */
	private function section_by_products( \WP_Post $post, string $content, array $sections, string $current ): string {
		$votes = array();
		foreach ( Mentions::products_in( $content ) as $id ) {
			$product = wc_get_product( $id );
			$parent  = $product instanceof \WC_Product && $product->get_parent_id() ? $product->get_parent_id() : $id;
			foreach ( wc_get_product_term_ids( $parent, 'product_cat' ) as $term_id ) {
				$ancestors = get_ancestors( $term_id, 'product_cat', 'taxonomy' );
				$root      = get_term( $ancestors ? (int) end( $ancestors ) : $term_id, 'product_cat' );
				if ( $root instanceof \WP_Term && isset( $sections[ $root->slug ] ) ) {
					$section           = sanitize_title( (string) $sections[ $root->slug ] );
					$votes[ $section ] = ( $votes[ $section ] ?? 0 ) + 1;
					break;
				}
			}
		}
		arsort( $votes );
		$top = array_slice( $votes, 0, 2, true );
		if ( ! $top || ( 2 === count( $top ) && count( array_unique( $top ) ) === 1 ) ) {
			$this->report['by_products']['doubtful'][] = $this->label( $post ) . ( $top ? ' (' . implode( ', ', array_keys( $top ) ) . ')' : '' );
			return $current;
		}
		$section = (string) array_key_first( $top );
		if ( $section !== $current ) {
			$this->report['by_products']['moved'][] = $this->label( $post ) . ' → ' . $section;
		}
		return $section;
	}


	/**
	 * Format and section of the old categories of an entry: Rank Math's main category
	 * first, then the priority of the map.
	 *
	 * @param \WP_Post             $post Post.
	 * @param array<string, mixed> $map  Map.
	 * @phpstan-param Map $map
	 * @return array{format: string, section: string}
	 */
	public function target( \WP_Post $post, array $map ): array {
		$targets = (array) ( $map['categories'] ?? array() );
		$slugs   = wp_get_post_categories( $post->ID, array( 'fields' => 'slugs' ) );
		$slugs   = is_array( $slugs ) ? array_map( 'strval', $slugs ) : array();
		$primary = (int) get_post_meta( $post->ID, 'rank_math_primary_category', true );
		$main    = $primary ? get_term( $primary, 'category' ) : null;
		$order   = array_merge( $main instanceof \WP_Term ? array( $main->slug ) : array(), (array) ( $map['priority'] ?? array() ), $slugs );
		foreach ( $order as $slug ) {
			if ( in_array( $slug, $slugs, true ) && isset( $targets[ $slug ] ) ) {
				$format = (string) ( $targets[ $slug ]['format'] ?? Model::ARTICLE );
				return array(
					'format'  => isset( Model::formats()[ $format ] ) ? $format : Model::ARTICLE,
					'section' => sanitize_title( (string) ( $targets[ $slug ]['section'] ?? '' ) ),
				);
			}
		}
		return array(
			'format'  => Model::ARTICLE,
			'section' => '',
		);
	}

	/**
	 * Subsection of a type of dish (created when it is missing).
	 *
	 * @param \WP_Term $section Section of the recipes.
	 * @param string   $name    Type of dish.
	 * @param bool     $dry_run Dry run.
	 */
	private function subsection( \WP_Term $section, string $name, bool $dry_run ): ?\WP_Term {
		// By name inside its section: WordPress gives a repeated slug a suffix.
		$term = get_terms(
			array(
				'taxonomy'   => Model::SECTION,
				'name'       => $name,
				'parent'     => $section->term_id,
				'hide_empty' => false,
			)
		);
		if ( is_array( $term ) && isset( $term[0] ) && $term[0] instanceof \WP_Term ) {
			return $term[0];
		}
		if ( $dry_run ) {
			return null;
		}
		$made = wp_insert_term(
			$name,
			Model::SECTION,
			array(
				'slug'   => sanitize_title( $name ),
				'parent' => $section->term_id,
			)
		);
		$term = is_wp_error( $made ) ? null : get_term( (int) $made['term_id'], Model::SECTION );
		return $term instanceof \WP_Term ? $term : null;
	}

	/**
	 * The recipe of an entry: from Rank Math's schema and the text.
	 *
	 * @param \WP_Post             $post   Post.
	 * @param array<string, mixed> $schema Rank Math's `Recipe` (unserialized).
	 * @param array<string, mixed> $map    Map.
	 * @phpstan-param Map $map
	 * @param bool                 $force  A recipe by a correction of the map, even without data.
	 * @return array{dish: string, content: string|null, reasons: string[], not_recipe: bool}
	 */
	private function recipe( \WP_Post $post, array $schema, array $map, bool $force = false ): array {
		$this->row = array(
			'title'         => $this->label( $post ),
			'source'        => $schema ? 'schema' : 'texto',
			'lines'         => 0,
			'doubtful'      => array(),
			'products'      => 0,
			'steps'         => 0,
			'dish'          => '',
			'raw_dish'      => trim( (string) ( $schema['recipeCategory'] ?? '' ) ),
			'status'        => '',
			'cut'           => false,
			'unresolved'    => array(),
			'no_quantities' => 0,
		);
		$reasons   = array();
		if ( has_block( RecipeBlock::NAME, $post ) ) {
			$this->row['status']       = 'ya migrada';
			$this->report['recipes'][] = $this->row;
			$current                   = Model::section_of( $post );
			return array(
				'dish'       => null !== $current && $current->parent ? $current->name : '',
				'content'    => null,
				'reasons'    => array(),
				'not_recipe' => false,
			);
		}
		$text   = RecipeText::find( $post->post_content );
		$groups = array();
		$body   = array_sum( array_map( static fn( array $g ): int => count( $g['lines'] ), $text['groups'] ) );
		$listed = $this->list( $schema['recipeIngredient'] ?? array() );
		if ( $body >= 2 || ! $listed ) {
			foreach ( $text['groups'] as $group ) {
				$groups[] = array(
					'title' => $group['title'],
					'items' => array_map( fn( array $line ): array => $this->item( $line['text'], $line['href'] ), $group['lines'] ),
				);
			}
		} else {
			$groups[] = array(
				'title' => '',
				'items' => array_map( fn( string $line ): array => $this->item( $line, '' ), $listed ),
			);
		}
		$steps = array_values( array_filter( array_map( 'trim', (array) preg_split( '/\R+/u', trim( $this->instructions( $schema['recipeInstructions'] ?? '' ) ) ) ), static fn( string $value ): bool => '' !== $value ) );
		if ( ! $steps ) {
			$steps = $text['steps'];
		}
		$times    = array_map( array( self::class, 'minutes' ), array( $schema['prepTime'] ?? '', $schema['cookTime'] ?? '', $schema['totalTime'] ?? '' ) );
		$prep     = $times[0];
		$cook     = $times[1];
		$rest     = max( 0, $times[2] - $prep - $cook );
		$prep     = 0 === $prep && 0 === $cook ? $times[2] : $prep;
		$rest     = 0 === $times[0] && 0 === $cook ? 0 : $rest;
		$servings = (int) preg_replace( '/\D.*$/', '', trim( (string) ( $schema['recipeYield'] ?? '' ) ) );
		$level    = mb_strtolower( trim( (string) get_post_meta( $post->ID, 'Nivel de dificultad', true ) ) );
		$data     = Recipe::normalize(
			array(
				'servings'   => $servings ? $servings : $text['servings'],
				'prep'       => $prep,
				'cook'       => $cook,
				'rest'       => $rest,
				'difficulty' => (string) ( ( (array) ( $map['difficulty'] ?? array() ) )[ $level ] ?? '' ),
				'cuisine'    => trim( (string) ( $schema['recipeCuisine'] ?? '' ) ),
				'groups'     => $groups,
				'steps'      => array_map( static fn( string $step ): array => array( 'text' => $step ), $steps ),
			)
		);
		if ( ! $force && ! $schema && ! $data['groups'] && ! $data['steps'] && self::quantity_lines( $post->post_content ) < 3 ) {
			return array(
				'dish'       => '',
				'content'    => null,
				'reasons'    => array(),
				'not_recipe' => true,
			);
		}
		$raw               = mb_strtolower( trim( $this->row['raw_dish'] ) );
		$dishes            = array_change_key_case( (array) ( $map['dishes'] ?? array() ) );
		$this->row['dish'] = (string) ( $dishes[ $raw ] ?? ( '' === $raw ? '' : mb_strtoupper( mb_substr( $raw, 0, 1 ) ) . mb_substr( $raw, 1 ) ) );
		if ( '' !== $raw && ! isset( $dishes[ $raw ] ) ) {
			/* translators: %s: recipeCategory of Rank Math. */
			$reasons[] = sprintf( __( 'Tipo de plato sin equivalencia («%s»): revisa la subsección.', 'lachinata-core' ), $this->row['raw_dish'] );
		}
		$this->row['lines'] = array_sum( array_map( static fn( array $g ): int => count( $g['items'] ), $data['groups'] ) );
		$this->row['steps'] = count( $data['steps'] );
		if ( ! $schema ) {
			$reasons[] = __( 'Receta sin esquema: los ingredientes y los pasos salen del texto. Revísalos.', 'lachinata-core' );
		}
		$missing = $this->missing();
		if ( $missing ) {
			/* translators: %s: number of ingredients. */
			$reasons[] = sprintf( _n( '%s ingrediente sin cantidad: añádela.', '%s ingredientes sin cantidad: añádelas.', $missing, 'lachinata-core' ), number_format_i18n( $missing ) );
		}
		$doubtful = $this->doubtful();
		if ( $doubtful ) {
			/* translators: %s: number of lines. */
			$reasons[] = sprintf( _n( '%s ingrediente dudoso.', '%s ingredientes dudosos.', $doubtful, 'lachinata-core' ), number_format_i18n( $doubtful ) );
		}
		if ( ! $data['groups'] || ! $data['steps'] ) {
			$reasons[]           = __( 'Faltan ingredientes o pasos: complétalos en el bloque de la receta.', 'lachinata-core' );
			$this->row['status'] = ! $data['groups'] && ! $data['steps'] ? 'sin datos' : 'incompleta';
		} else {
			$this->row['status'] = $doubtful || ! $schema || $missing ? 'para revisar' : 'lista';
		}
		$content = $post->post_content;
		if ( $text['pieces'] && $data['groups'] ) {
			$content          = RecipeText::without( $content, $text['pieces'] );
			$this->row['cut'] = true;
		}
		$content                   = trim( (string) preg_replace( '/\[rank_math_rich_snippet[^\]]*\]/', '', $content ) );
		$block                     = serialize_block(
			array(
				'blockName'    => RecipeBlock::NAME,
				'attrs'        => array( 'recipe' => $data ),
				'innerBlocks'  => array(),
				'innerHTML'    => '',
				'innerContent' => array(),
			)
		);
		$this->report['recipes'][] = $this->row;
		return array(
			'dish'       => $this->row['dish'],
			'content'    => $block . "\n\n" . $content,
			'reasons'    => $reasons,
			'not_recipe' => false,
		);
	}

	/**
	 * Lines of a text that read as an ingredient with quantity and unit («200 g de harina»):
	 * a text with fewer than three is not a recipe without structure but something else (the
	 * news of a contest, a press clipping).
	 *
	 * @param string $content Content.
	 */
	public static function quantity_lines( string $content ): int {
		$count = 0;
		foreach ( RecipeText::pieces( $content ) as $piece ) {
			foreach ( RecipeText::lines( $piece ) as $line ) {
				if ( mb_strlen( $line['text'] ) > 80 ) {
					continue;
				}
				$parsed = Ingredients::parse( $line['text'] );
				if ( '' !== $parsed['qty'] && '' !== $parsed['unit'] && '' !== $parsed['name'] ) {
					++$count;
				}
			}
		}
		return $count;
	}

	/**
	 * Lines without quantity in the old recipe being migrated (item() counts them).
	 */
	private function missing(): int {
		return (int) ( $this->row['no_quantities'] ?? 0 );
	}

	/**
	 * Doubtful lines of the recipe being migrated (item() adds them).
	 */
	private function doubtful(): int {
		return count( (array) ( $this->row['doubtful'] ?? array() ) );
	}

	/**
	 * One ingredient: analysed, with its product when the line links to one.
	 *
	 * @param string $line   Line.
	 * @param string $href   Its first link.
	 * @return array<string, mixed>
	 */
	private function item( string $line, string $href ): array {
		$parsed = Ingredients::parse( $line );
		if ( __( 'sin cantidad', 'lachinata-core' ) === $parsed['reason'] ) {
			// Not an error of the analyser: the old recipe has no quantity there.
			$this->row['no_quantities'] = (int) ( $this->row['no_quantities'] ?? 0 ) + 1;
		} elseif ( $parsed['doubtful'] ) {
			$this->row['doubtful'][] = $line . ' → ' . $parsed['reason'];
		}
		$product = '' === $href ? null : self::product_from_url( $href );
		if ( '' !== $href && null === $product && self::looks_like_product( $href ) ) {
			$this->row['unresolved'][] = $href;
		}
		if ( null !== $product ) {
			++$this->row['products'];
		}
		return array(
			'qty'     => $parsed['qty'],
			'unit'    => $parsed['unit'],
			'name'    => $parsed['name'],
			'note'    => $parsed['note'],
			'product' => null === $product ? 0 : $product->get_id(),
			'sku'     => null === $product ? '' : $product->get_sku(),
		);
	}

	/**
	 * Whether a link looks like a product of the shop (an old `.html` page of this site).
	 *
	 * @param string $url Link.
	 */
	public static function looks_like_product( string $url ): bool {
		$path = (string) wp_parse_url( $url, PHP_URL_PATH );
		return str_ends_with( $path, '.html' ) || (bool) preg_match( '#/(product|producto)/#', $path );
	}

	/**
	 * Product of a link by its slug (`/miel-de-eucalipto.html`, `/producto/x/`).
	 *
	 * @param string $url Link.
	 */
	public static function product_from_url( string $url ): ?\WC_Product {
		$path = trim( (string) wp_parse_url( $url, PHP_URL_PATH ), '/' );
		$slug = sanitize_title( (string) preg_replace( '/\.html?$/i', '', basename( $path ) ) );
		if ( '' === $slug ) {
			return null;
		}
		$post = get_page_by_path( $slug, OBJECT, 'product' );
		$item = $post instanceof \WP_Post ? wc_get_product( $post->ID ) : null;
		return $item instanceof \WC_Product ? $item : null;
	}

	/**
	 * A list of Rank Math (array, or text with one per line).
	 *
	 * @param mixed $value Value.
	 * @return string[]
	 */
	private function list( $value ): array {
		$lines = is_array( $value ) ? array_map( 'strval', array_values( $value ) ) : ( (array) preg_split( '/\R/u', (string) $value ) );
		return array_values( array_filter( array_map( 'trim', $lines ), static fn( string $value ): bool => '' !== $value ) );
	}

	/**
	 * Steps of Rank Math: text, or HowToStep / HowToSection items.
	 *
	 * @param mixed $value Value.
	 */
	private function instructions( $value ): string {
		if ( ! is_array( $value ) ) {
			return wp_strip_all_tags( (string) $value );
		}
		$out = array();
		foreach ( $value as $step ) {
			if ( is_array( $step ) && isset( $step['itemListElement'] ) && is_array( $step['itemListElement'] ) ) {
				$out[] = $this->instructions( $step['itemListElement'] );
			} elseif ( is_array( $step ) ) {
				$out[] = wp_strip_all_tags( (string) ( $step['text'] ?? $step['name'] ?? '' ) );
			} else {
				$out[] = wp_strip_all_tags( (string) $step );
			}
		}
		return implode( "\n", $out );
	}

	/**
	 * Minutes of an ISO 8601 duration (« PT1H10M»), or 0.
	 *
	 * @param mixed $value Value.
	 */
	public static function minutes( $value ): int {
		if ( ! preg_match( '/^P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?/i', trim( (string) $value ), $m ) ) {
			return 0;
		}
		return (int) ( $m[1] ?? 0 ) * 1440 + (int) ( $m[2] ?? 0 ) * 60 + (int) ( $m[3] ?? 0 );
	}

	/**
	 * Shortcodes left in the text, for the report.
	 *
	 * @param \WP_Post $post Post.
	 */
	private function shortcodes( \WP_Post $post ): void {
		if ( ! preg_match_all( '/\[([a-z][a-z0-9_\-]*)[\s\]\/]/i', $post->post_content, $matches ) ) {
			return;
		}
		foreach ( array_unique( $matches[1] ) as $tag ) {
			$this->report['shortcodes'][ $tag ][] = $this->label( $post );
		}
	}

	/**
	 * Clicks of Search Console by URL, for «Lo más leído».
	 *
	 * @param string $file    CSV (URL, clicks, impressions…).
	 * @param bool   $dry_run Dry run.
	 */
	private function clicks( string $file, bool $dry_run ): void {
		$handle = is_readable( $file ) ? fopen( $file, 'r' ) : false; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- A local CSV of the command.
		if ( false === $handle ) {
			return;
		}
		fgetcsv( $handle, 0, ',', '"', '\\' );
		while ( ( $row = fgetcsv( $handle, 0, ',', '"', '\\' ) ) !== false ) { // phpcs:ignore Generic.CodeAnalysis.AssignmentInCondition.FoundInWhileCondition -- Reading a file.
			if ( count( $row ) < 2 ) {
				continue;
			}
			++$this->report['clicks']['rows'];
			$slug = basename( trim( (string) wp_parse_url( (string) $row[0], PHP_URL_PATH ), '/' ) );
			$post = '' === $slug ? null : get_page_by_path( $slug, OBJECT, 'post' );
			if ( ! $post instanceof \WP_Post ) {
				continue;
			}
			++$this->report['clicks']['matched'];
			if ( ! $dry_run ) {
				update_post_meta( $post->ID, Fields::CLICKS, (int) preg_replace( '/\D/', '', (string) $row[1] ) );
			}
		}
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- A local CSV of the command.
	}

	/**
	 * «Title (#id)».
	 *
	 * @param \WP_Post $post Post.
	 */
	private function label( \WP_Post $post ): string {
		return sprintf( '%1$s (#%2$d)', html_entity_decode( get_the_title( $post ), ENT_QUOTES, 'UTF-8' ), $post->ID );
	}

	/**
	 * The report in Markdown.
	 *
	 * @param array<string, mixed> $report  Report of run().
	 * @param bool                 $dry_run Dry run.
	 */
	public static function markdown( array $report, bool $dry_run ): string {
		$out   = array();
		$out[] = '# Migración del blog' . ( $dry_run ? ' (en seco)' : '' );
		$out[] = '';
		$out[] = sprintf( 'Generado el %s en %s. %d entradas.', gmdate( 'Y-m-d H:i' ), home_url(), (int) $report['posts'] );
		$out[] = '';
		$out[] = '## 1. Formato y sección';
		$out[] = '';
		foreach ( (array) $report['formats'] as $format => $count ) {
			$out[] = sprintf( '- %s: %d', $format, $count );
		}
		$out[] = '';
		foreach ( (array) $report['sections'] as $section => $count ) {
			$out[] = sprintf( '- Sección «%s»: %d', $section, $count );
		}
		if ( $report['created'] ) {
			$out[] = '';
			$out[] = 'Secciones creadas: ' . implode( ', ', (array) $report['created'] ) . '.';
		}
		$out[] = '';
		$out[] = sprintf( 'Sin sección (ninguna categoría con destino en el mapa): %d.', count( (array) $report['no_section'] ) );
		foreach ( array_slice( (array) $report['no_section'], 0, 50 ) as $label ) {
			$out[] = '- ' . $label;
		}
		$recipes = (array) $report['recipes'];
		$status  = array_count_values( array_map( static fn( array $row ): string => (string) $row['status'], $recipes ) );
		$out[]   = '';
		$out[]   = '## 2. Recetas';
		$out[]   = '';
		$out[]   = sprintf( '%d recetas: %d con el esquema de Rank Math, %d solo con el texto.', count( $recipes ), count( array_filter( $recipes, static fn( array $r ): bool => 'schema' === $r['source'] ) ), count( array_filter( $recipes, static fn( array $r ): bool => 'texto' === $r['source'] ) ) );
		foreach ( $status as $name => $count ) {
			$out[] = sprintf( '- %s: %d', $name, $count );
		}
		$lines    = array_sum( array_column( $recipes, 'lines' ) );
		$doubtful = array_sum( array_map( static fn( array $r ): int => count( $r['doubtful'] ), $recipes ) );
		$out[]    = '';
		$out[]    = sprintf( 'Ingredientes: %d; sin cantidad en el original %d; dudosos para el analizador %d; enlazados a producto %d. Pasos: %d. Texto de la receta sacado del cuerpo en %d.', $lines, array_sum( array_map( static fn( array $r ): int => (int) ( $r['no_quantities'] ?? 0 ), $recipes ) ), $doubtful, array_sum( array_column( $recipes, 'products' ) ), array_sum( array_column( $recipes, 'steps' ) ), count( array_filter( array_column( $recipes, 'cut' ) ) ) );
		if ( $report['not_recipes'] ) {
			$out[] = '';
			$out[] = sprintf( 'En la categoría de recetas sin ser recetas (sin esquema y sin ingredientes con cantidad en el texto): %d, pasadas al formato y la sección de `not_recipe` del mapa.', count( (array) $report['not_recipes'] ) );
			foreach ( (array) $report['not_recipes'] as $label ) {
				$out[] = '- ' . $label;
			}
		}
		$out[]  = '';
		$out[]  = '### Tipos de plato (subsecciones propuestas)';
		$out[]  = '';
		$dishes = array();
		foreach ( $recipes as $row ) {
			$key            = '' === $row['raw_dish'] ? '(sin tipo)' : $row['raw_dish'];
			$dishes[ $key ] = ( $row['dish'] ?? '' ) ? $row['dish'] : '—';
		}
		ksort( $dishes );
		$counts = array_count_values( array_map( static fn( array $row ): string => '' === $row['raw_dish'] ? '(sin tipo)' : $row['raw_dish'], $recipes ) );
		$out[]  = '| recipeCategory de Rank Math | Recetas | Subsección |';
		$out[]  = '| --- | --- | --- |';
		foreach ( $dishes as $raw => $dish ) {
			$out[] = sprintf( '| %s | %d | %s |', $raw, $counts[ $raw ] ?? 0, $dish );
		}
		$out[] = '';
		$out[] = '### Recetas para revisar';
		$out[] = '';
		foreach ( $recipes as $row ) {
			if ( 'lista' === $row['status'] || 'ya migrada' === $row['status'] ) {
				continue;
			}
			$out[] = sprintf( '- **%s** · %s · %s · %d ingredientes, %d pasos', $row['title'], $row['status'], $row['source'], $row['lines'], $row['steps'] );
			foreach ( $row['doubtful'] as $line ) {
				$out[] = '  - ' . $line;
			}
			foreach ( $row['unresolved'] as $href ) {
				$out[] = '  - enlace a producto sin resolver: ' . $href;
			}
		}
		$out[] = '';
		$out[] = '## 3. Códigos cortos que quedan en los textos';
		$out[] = '';
		foreach ( (array) $report['shortcodes'] as $tag => $posts ) {
			$out[] = sprintf( '- `[%1$s]`: %2$d entradas (%3$s%4$s)', $tag, count( $posts ), implode( '; ', array_slice( $posts, 0, 5 ) ), count( $posts ) > 5 ? '…' : '' );
		}
		$out[] = '';
		$out[] = '## 5. Correcciones por ID del mapa';
		$out[] = '';
		foreach ( (array) $report['overrides'] as $line ) {
			$out[] = '- ' . $line;
		}
		$links = (array) $report['links'];
		$out[] = '';
		$out[] = '## 6. Enlaces a producto';
		$out[] = '';
		$out[] = sprintf( 'Pasados a referencias (`data-lc-product`): %d. Sin producto: %d direcciones.', (int) ( $links['converted'] ?? 0 ), count( (array) ( $links['unresolved'] ?? array() ) ) );
		foreach ( (array) ( $links['unresolved'] ?? array() ) as $url => $posts ) {
			$out[] = sprintf( '- %1$s (entradas %2$s)', $url, implode( ', ', array_unique( array_map( 'strval', (array) $posts ) ) ) );
		}
		$by    = (array) $report['by_products'];
		$out[] = '';
		$out[] = '## 7. Sección por los productos que enlazan';
		$out[] = '';
		$out[] = sprintf( 'Cambian de sección: %1$d. Dudosas (empate o sin productos), en la de su categoría: %2$d.', count( (array) ( $by['moved'] ?? array() ) ), count( (array) ( $by['doubtful'] ?? array() ) ) );
		foreach ( (array) ( $by['moved'] ?? array() ) as $line ) {
			$out[] = '- ' . $line;
		}
		if ( ! empty( $by['doubtful'] ) ) {
			$out[] = '';
			$out[] = 'Dudosas:';
			foreach ( (array) $by['doubtful'] as $line ) {
				$out[] = '- ' . $line;
			}
		}
		$out[] = '';
		$out[] = '## 8. Oleotecas que ya no existen';
		$out[] = '';
		$out[] = sprintf( 'Entradas que enlazan a una oleoteca sin ficha (a «Revisar»): %d.', count( (array) $report['stores_missing'] ) );
		foreach ( (array) $report['stores_missing'] as $line ) {
			$out[] = '- ' . $line;
		}
		$out[] = '';
		$out[] = '## 9. Direcciones actuales';
		$out[] = '';
		$out[] = sprintf( 'Entradas cuyo slug pasa a ser su dirección actual (el slug antiguo responde con 301): %1$d. Conflictos: %2$d.', count( (array) $report['slugs']['changed'] ), count( (array) $report['slugs']['conflict'] ) );
		foreach ( array_merge( (array) $report['slugs']['changed'], (array) $report['slugs']['conflict'] ) as $line ) {
			$out[] = '- ' . $line;
		}
		$out[] = '';
		$out[] = '## 4. Search Console';
		$out[] = '';
		$out[] = sprintf( '%d filas, %d de entradas de este sitio (sus clics ordenan «Lo más leído»).', (int) $report['clicks']['rows'], (int) $report['clicks']['matched'] );
		return implode( "\n", $out ) . "\n";
	}
}
