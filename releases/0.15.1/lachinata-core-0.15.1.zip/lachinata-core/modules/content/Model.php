<?php
/**
 * Formats, sections and topics of the entries.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * Entries stay posts (`post`) with their URL (`/slug/`), their history and their id. On
 * top: a format (meta), sections (hierarchical, `/blog/{section}/` and, for the types of
 * dish, `/blog/{section}/{subsection}/`), up to 20 curated topics (`/blog/tema/{slug}/`)
 * and the magazine at `/blog/`. Comments are closed: there are none and the templates do
 * not print a section for them.
 */
final class Model {

	public const SECTION = 'lc_seccion';
	public const TOPIC   = 'lc_tema';

	public const RECIPE  = 'receta';
	public const ARTICLE = 'articulo';
	public const NEWS    = 'noticia';

	/**
	 * Most topics there can be (08-contenido-seo.md).
	 */
	public const MAX_TOPICS = 20;

	/**
	 * URL base of the magazine, the sections and the topics.
	 */
	public const BASE = 'blog';

	/**
	 * Section slugs that would clash with the URLs of the magazine.
	 */
	public const RESERVED = array( 'tema', 'page', 'feed' );

	/**
	 * Query var of the magazine (`/blog/`).
	 */
	public const HOME_VAR = 'lc_blog';

	/**
	 * Version of the rewrite rules; when it changes they are rebuilt once.
	 */
	private const REWRITE = '2';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'init', array( self::class, 'register' ), 5 );
		Hooks::add_filter( 'query_vars', array( self::class, 'query_vars' ) );
		Hooks::add_filter( 'comments_open', array( self::class, 'closed' ), 20, 2 );
		Hooks::add_filter( 'pings_open', array( self::class, 'closed' ), 20, 2 );
		Hooks::add_filter( 'pre_insert_term', array( self::class, 'check_term' ), 10, 2 );
		Hooks::add_action( 'save_post_post', array( self::class, 'on_save' ), 20, 2 );
	}

	/**
	 * Formats and their names.
	 *
	 * @return array<string, string>
	 */
	public static function formats(): array {
		return array(
			self::RECIPE  => __( 'Receta', 'lachinata-core' ),
			self::ARTICLE => __( 'Artículo', 'lachinata-core' ),
			self::NEWS    => __( 'Noticia', 'lachinata-core' ),
		);
	}

	/**
	 * Registers the taxonomies, the fields and the rule of the magazine. The topics go
	 * first: their rules (`blog/tema/…`) must win over the sections' (`blog/…`).
	 */
	public static function register(): void {
		register_taxonomy(
			self::TOPIC,
			'post',
			array(
				'labels'            => array(
					'name'          => __( 'Temas', 'lachinata-core' ),
					'singular_name' => __( 'Tema', 'lachinata-core' ),
					'add_new_item'  => __( 'Añadir tema', 'lachinata-core' ),
				),
				/* translators: %d: most topics there can be. */
				'description'       => sprintf( __( 'Como mucho %d temas curados, cada uno con su texto.', 'lachinata-core' ), self::MAX_TOPICS ),
				'hierarchical'      => false,
				'public'            => true,
				'show_in_rest'      => true,
				'show_admin_column' => true,
				'rewrite'           => array(
					'slug'       => self::BASE . '/tema',
					'with_front' => false,
				),
			)
		);
		register_taxonomy(
			self::SECTION,
			'post',
			array(
				'labels'            => array(
					'name'          => __( 'Secciones', 'lachinata-core' ),
					'singular_name' => __( 'Sección', 'lachinata-core' ),
					'parent_item'   => __( 'Sección superior', 'lachinata-core' ),
					'add_new_item'  => __( 'Añadir sección', 'lachinata-core' ),
				),
				'hierarchical'      => true,
				'public'            => true,
				'show_in_rest'      => true,
				'show_admin_column' => true,
				'rewrite'           => array(
					'slug'         => self::BASE,
					'with_front'   => false,
					'hierarchical' => true,
				),
			)
		);
		add_rewrite_rule( '^' . self::BASE . '/?$', 'index.php?' . self::HOME_VAR . '=1', 'top' );
		self::register_meta();
		if ( get_option( 'lachinata_content_rewrite' ) !== self::REWRITE ) {
			update_option( 'rewrite_rules', '' );
			update_option( 'lachinata_content_rewrite', self::REWRITE, false );
		}
	}

	/**
	 * Fields of the entries the editor's panel writes (REST).
	 */
	private static function register_meta(): void {
		$auth = static fn(): bool => current_user_can( 'edit_posts' );
		foreach (
			array(
				Fields::FORMAT   => array(
					'type' => 'string',
					'enum' => array( '', self::RECIPE, self::ARTICLE, self::NEWS ),
				),
				Fields::SUMMARY  => array( 'type' => 'string' ),
				Fields::REVIEWED => array(
					'type'   => 'string',
					'format' => 'date',
				),
			) as $key => $schema
		) {
			register_post_meta(
				'post',
				$key,
				array(
					'type'              => 'string',
					'single'            => true,
					'default'           => '',
					'show_in_rest'      => array( 'schema' => $schema + array( 'default' => '' ) ),
					'auth_callback'     => $auth,
					'sanitize_callback' => array( self::class, 'sanitize_meta' ),
				)
			);
		}
		register_post_meta(
			'post',
			Fields::SOURCES,
			array(
				'type'              => 'array',
				'single'            => true,
				'default'           => array(),
				'show_in_rest'      => array(
					'schema' => array(
						'type'  => 'array',
						'items' => array(
							'type'       => 'object',
							'properties' => array(
								'title' => array( 'type' => 'string' ),
								'url'   => array(
									'type'   => 'string',
									'format' => 'uri',
								),
							),
						),
					),
				),
				'auth_callback'     => $auth,
				'sanitize_callback' => array( self::class, 'sanitize_sources' ),
			)
		);
	}

	/**
	 * Sanitizes a text field of the panel.
	 *
	 * @param mixed  $value Value.
	 * @param string $key   Meta key.
	 */
	public static function sanitize_meta( $value, string $key = '' ): string {
		$value = is_scalar( $value ) ? (string) $value : '';
		if ( Fields::REVIEWED === $key ) {
			return preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ? $value : '';
		}
		if ( Fields::FORMAT === $key ) {
			return isset( self::formats()[ $value ] ) ? $value : '';
		}
		return sanitize_textarea_field( $value );
	}

	/**
	 * Sanitizes the sources: a title and an http(s) link each.
	 *
	 * @param mixed $value Value.
	 * @return array<int, array{title: string, url: string}>
	 */
	public static function sanitize_sources( $value ): array {
		$clean = array();
		foreach ( is_array( $value ) ? $value : array() as $row ) {
			$row = is_array( $row ) ? $row : array();
			$url = esc_url_raw( (string) ( $row['url'] ?? '' ), array( 'http', 'https' ) );
			if ( '' === $url ) {
				continue;
			}
			$title   = sanitize_text_field( (string) ( $row['title'] ?? '' ) );
			$clean[] = array(
				'title' => '' !== $title ? $title : $url,
				'url'   => $url,
			);
		}
		return $clean;
	}

	/**
	 * Query var of the magazine.
	 *
	 * @param string[] $vars Vars.
	 * @return string[]
	 */
	public static function query_vars( array $vars ): array {
		$vars[] = self::HOME_VAR;
		$vars[] = Pages::PRODUCT_VAR;
		return $vars;
	}

	/**
	 * Comments and pings closed on the entries.
	 *
	 * @param bool $open    Open.
	 * @param int  $post_id Post id.
	 */
	public static function closed( $open, $post_id ): bool {
		return 'post' === get_post_type( (int) $post_id ) ? false : (bool) $open;
	}

	/**
	 * Refuses a topic beyond the 20th and a section with a reserved slug.
	 *
	 * @param string|\WP_Error $term     Term name or error.
	 * @param string           $taxonomy Taxonomy.
	 * @return string|\WP_Error
	 */
	public static function check_term( $term, $taxonomy ) {
		if ( $term instanceof \WP_Error ) {
			return $term;
		}
		if ( self::TOPIC === $taxonomy && (int) wp_count_terms( array( 'taxonomy' => self::TOPIC ) ) >= self::MAX_TOPICS ) {
			/* translators: %d: most topics there can be. */
			return new \WP_Error( 'lachinata_content_topics', sprintf( __( 'Ya hay %d temas: es el máximo. Une o retira uno antes de crear otro.', 'lachinata-core' ), self::MAX_TOPICS ) );
		}
		if ( self::SECTION === $taxonomy && in_array( sanitize_title( (string) $term ), self::RESERVED, true ) ) {
			/* translators: %s: reserved words. */
			return new \WP_Error( 'lachinata_content_reserved', sprintf( __( 'Ese nombre está reservado para las direcciones del blog (%s).', 'lachinata-core' ), implode( ', ', self::RESERVED ) ) );
		}
		return $term;
	}

	/**
	 * Format of an entry: the saved one or, without it, recipe when it has the block.
	 *
	 * @param \WP_Post|int $post Post.
	 */
	public static function format_of( $post ): string {
		$post   = get_post( $post );
		$format = $post ? (string) get_post_meta( $post->ID, Fields::FORMAT, true ) : '';
		if ( isset( self::formats()[ $format ] ) ) {
			return $format;
		}
		return $post && has_block( RecipeBlock::NAME, $post ) ? self::RECIPE : self::ARTICLE;
	}

	/**
	 * Section of an entry: its deepest section (a subsection when it has one).
	 *
	 * @param \WP_Post|int $post Post.
	 */
	public static function section_of( $post ): ?\WP_Term {
		$terms = get_the_terms( $post, self::SECTION );
		if ( ! is_array( $terms ) || ! $terms ) {
			return null;
		}
		usort( $terms, static fn( \WP_Term $a, \WP_Term $b ): int => count( get_ancestors( $b->term_id, self::SECTION, 'taxonomy' ) ) <=> count( get_ancestors( $a->term_id, self::SECTION, 'taxonomy' ) ) );
		return $terms[0];
	}

	/**
	 * Root of a section.
	 *
	 * @param \WP_Term $term Section.
	 */
	public static function root( \WP_Term $term ): \WP_Term {
		$ancestors = get_ancestors( $term->term_id, self::SECTION, 'taxonomy' );
		if ( ! $ancestors ) {
			return $term;
		}
		$root = get_term( (int) end( $ancestors ), self::SECTION );
		return $root instanceof \WP_Term ? $root : $term;
	}

	/**
	 * Root sections, in the order of the magazine.
	 *
	 * @return \WP_Term[]
	 */
	public static function roots(): array {
		$terms = get_terms(
			array(
				'taxonomy'   => self::SECTION,
				'parent'     => 0,
				'hide_empty' => true,
			)
		);
		$terms = is_array( $terms ) ? array_values( array_filter( $terms, static fn( $term ): bool => $term instanceof \WP_Term ) ) : array();
		usort(
			$terms,
			static function ( \WP_Term $a, \WP_Term $b ): int {
				$order = static fn( \WP_Term $term ): int => '' === (string) get_term_meta( $term->term_id, Fields::SECTION_ORDER, true ) ? 999 : (int) get_term_meta( $term->term_id, Fields::SECTION_ORDER, true );
				return array( $order( $a ), $a->name ) <=> array( $order( $b ), $b->name );
			}
		);
		return $terms;
	}

	/**
	 * Section of the recipes (setting; without it, the root section with most recipes).
	 */
	public static function recipe_section(): ?\WP_Term {
		$slug = sanitize_title( (string) ContentModule::setting( 'recipe_section' ) );
		$term = '' !== $slug ? get_term_by( 'slug', $slug, self::SECTION ) : false;
		if ( $term instanceof \WP_Term ) {
			return $term;
		}
		$best = null;
		$most = 0;
		foreach ( self::roots() as $root ) {
			$count = Query::count_format( self::RECIPE, $root );
			if ( $count > $most ) {
				$best = $root;
				$most = $count;
			}
		}
		return $best;
	}

	/**
	 * Index of the entry on save: the recipe of its block and its words.
	 *
	 * @param int      $post_id Post id.
	 * @param \WP_Post $post    Post.
	 */
	public static function on_save( $post_id, $post ): void {
		if ( ! $post instanceof \WP_Post || wp_is_post_revision( (int) $post_id ) || wp_is_post_autosave( (int) $post_id ) ) {
			return;
		}
		Recipe::reindex( $post );
		Mentions::reindex( $post );
		update_post_meta( $post->ID, Fields::WORDS, Text::words( $post->post_content ) );
	}
}
