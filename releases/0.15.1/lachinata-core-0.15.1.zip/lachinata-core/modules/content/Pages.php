<?php
/**
 * The magazine, the sections, the topics and the entries.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

use LaChinata\Core\Hooks;
use LaChinata\Core\Templates;

defined( 'ABSPATH' ) || exit;

/**
 * Serves the module's templates (`templates/content/{blog,section,single,recipe}.php`,
 * which the theme can override in `lachinata/content/`), fills the theme's breadcrumb and
 * «Volver», loads the script of the entries only on an entry, sends a subsection without
 * enough recipes to its section, and filters a section by product
 * (`/blog/recetas/?producto={id}`, «Ver todas» of the product page) without indexing it.
 */
final class Pages {

	/**
	 * Script handle of the entries (scaling, cook mode, print, contents).
	 */
	public const SCRIPT = 'lachinata-content';

	/**
	 * Query var of the filter by product.
	 */
	public const PRODUCT_VAR = 'producto';

	/**
	 * Entries a page of a section or a topic.
	 */
	public const PAGE_SIZE = 12;

	/**
	 * Whether the module's recipe template is printing (the block then prints nothing).
	 *
	 * @var bool
	 */
	private static bool $recipe = false;

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'init', array( self::class, 'register_script' ) );
		Hooks::add_action( 'pre_get_posts', array( self::class, 'query' ) );
		Hooks::add_filter( 'template_include', array( self::class, 'template' ), 20 );
		Hooks::add_action( 'template_redirect', array( self::class, 'redirect' ) );
		Hooks::add_filter( 'lachinata/breadcrumb/items', array( self::class, 'breadcrumb' ) );
		Hooks::add_filter( 'lachinata/view/editorial', array( self::class, 'editorial' ) );
		Hooks::add_filter( 'lachinata/view/blog', array( self::class, 'editorial' ) );
		Hooks::add_filter( 'lachinata/view/secondary', array( self::class, 'secondary' ) );
		Hooks::add_filter( 'lachinata/view/back_url', array( self::class, 'back_url' ) );
		Hooks::add_filter( 'lachinata/app_bar/section', array( self::class, 'app_bar' ) );
		Hooks::add_filter( 'lachinata/robots/noindex', array( self::class, 'noindex' ) );
		Hooks::add_filter( 'document_title_parts', array( self::class, 'title' ) );
		AddMany::boot();
	}

	/**
	 * Registers the script of the entries.
	 */
	public static function register_script(): void {
		$file  = LACHINATA_CORE_DIR . '/modules/content/build/front.asset.php';
		$asset = is_readable( $file ) ? require $file : array(
			'dependencies' => array( 'wp-i18n' ),
			'version'      => LACHINATA_CORE_VERSION,
		);
		wp_register_script( self::SCRIPT, plugins_url( 'modules/content/build/front.js', LACHINATA_CORE_FILE ), (array) $asset['dependencies'], (string) $asset['version'], array( 'strategy' => 'defer' ) );
		wp_set_script_translations( self::SCRIPT, 'lachinata-core', LACHINATA_CORE_DIR . '/languages' );
	}

	/**
	 * Whether the request is the magazine.
	 */
	public static function is_home(): bool {
		return (bool) get_query_var( Model::HOME_VAR );
	}

	/**
	 * Whether the request is a page of the module.
	 */
	public static function is_view(): bool {
		return self::is_home() || is_tax( array( Model::SECTION, Model::TOPIC ) ) || is_singular( 'post' );
	}

	/**
	 * Whether the recipe template is printing.
	 */
	public static function in_recipe(): bool {
		return self::$recipe;
	}

	/**
	 * Marks the recipe template as printing (or done).
	 *
	 * @param bool $on On.
	 */
	public static function recipe_mode( bool $on ): void {
		self::$recipe = $on;
	}

	/**
	 * Product of the filter `?producto=`, when it is a product.
	 */
	public static function product_filter(): ?\WC_Product {
		$id      = absint( get_query_var( self::PRODUCT_VAR ) );
		$product = $id ? wc_get_product( $id ) : null;
		return $product instanceof \WC_Product ? $product : null;
	}

	/**
	 * Main query: 12 entries a page in the sections and topics, filtered by product when
	 * asked; the magazine asks for nothing (its template makes its own lists).
	 *
	 * @param \WP_Query $query Query.
	 */
	public static function query( $query ): void {
		if ( ! $query instanceof \WP_Query || is_admin() || ! $query->is_main_query() ) {
			return;
		}
		if ( $query->get( Model::HOME_VAR ) ) {
			$query->set( 'posts_per_page', 1 );
			$query->set( 'no_found_rows', true );
			return;
		}
		if ( ! $query->is_tax( array( Model::SECTION, Model::TOPIC ) ) ) {
			return;
		}
		$query->set( 'posts_per_page', self::PAGE_SIZE );
		$query->set( 'ignore_sticky_posts', true );
		$product = absint( $query->get( self::PRODUCT_VAR ) );
		if ( $product ) {
			$query->set(
				'meta_query',
				array(
					array(
						'key'   => Fields::PRODUCT,
						'value' => $product,
					),
				)
			);
		}
	}

	/**
	 * The module's template.
	 *
	 * @param mixed $template Template WordPress chose.
	 */
	public static function template( $template ): string {
		$name = '';
		if ( self::is_home() ) {
			$name = 'blog';
		} elseif ( is_tax( array( Model::SECTION, Model::TOPIC ) ) ) {
			$name = 'section';
		} elseif ( is_singular( 'post' ) ) {
			$name = Model::RECIPE === Model::format_of( (int) get_queried_object_id() ) && null !== Recipe::of( (int) get_queried_object_id() ) ? 'recipe' : 'single';
		}
		if ( '' === $name ) {
			return (string) $template;
		}
		$file = Templates::locate( 'content', $name );
		if ( '' === $file ) {
			return (string) $template;
		}
		if ( 'blog' !== $name && 'section' !== $name ) {
			wp_enqueue_script( self::SCRIPT );
		}
		return $file;
	}

	/**
	 * A subsection without its own page goes to its section (302: it gets one when it has
	 * enough recipes); the magazine never answers 404.
	 */
	public static function redirect(): void {
		if ( self::is_home() ) {
			global $wp_query;
			$wp_query->is_404 = false;
			status_header( 200 );
			return;
		}
		if ( ! is_tax( Model::SECTION ) ) {
			return;
		}
		$term = get_queried_object();
		if ( $term instanceof \WP_Term && ! Query::has_page( $term ) ) {
			$parent = get_term( $term->parent, Model::SECTION );
			$link   = $parent instanceof \WP_Term ? get_term_link( $parent ) : '';
			wp_safe_redirect( is_string( $link ) && '' !== $link ? $link : Query::home_url(), 302 );
			exit;
		}
	}

	/**
	 * Inicio › Blog › Sección › Subsección › (entry).
	 *
	 * @param mixed $items Items of the theme.
	 * @return mixed
	 */
	public static function breadcrumb( $items ) {
		if ( ! self::is_view() || ! is_array( $items ) || ! $items ) {
			return $items;
		}
		return self::trail( $items[0] );
	}

	/**
	 * The trail of the current page, starting with the home item.
	 *
	 * @param array{0: string, 1: string} $home Home item.
	 * @return array<int, array{0: string, 1: string}>
	 */
	public static function trail( array $home ): array {
		$blog = __( 'Blog', 'lachinata-core' );
		if ( self::is_home() ) {
			return array( $home, array( $blog, '' ) );
		}
		$out  = array( $home, array( $blog, Query::home_url() ) );
		$term = null;
		if ( is_singular( 'post' ) ) {
			$term = Model::section_of( (int) get_queried_object_id() );
		} elseif ( is_tax( Model::SECTION ) ) {
			$current = get_queried_object();
			$term    = $current instanceof \WP_Term && $current->parent ? get_term( $current->parent, Model::SECTION ) : null;
		}
		if ( $term instanceof \WP_Term ) {
			$chain = array_reverse( get_ancestors( $term->term_id, Model::SECTION, 'taxonomy' ) );
			foreach ( $chain as $ancestor ) {
				$ancestor = get_term( (int) $ancestor, Model::SECTION );
				if ( $ancestor instanceof \WP_Term ) {
					$out[] = array( $ancestor->name, Query::section_url( $ancestor ) );
				}
			}
			$out[] = array( $term->name, Query::section_url( $term ) );
		}
		if ( is_tax( array( Model::SECTION, Model::TOPIC ) ) ) {
			$out[] = array( single_term_title( '', false ), '' );
		} elseif ( is_singular( 'post' ) ) {
			$out[] = array( (string) get_the_title( (int) get_queried_object_id() ), '' );
		}
		return $out;
	}

	/**
	 * Editorial typography (Recoleta) and the blog styles on the module's pages.
	 *
	 * @param mixed $on Current value.
	 */
	public static function editorial( $on ): bool {
		return self::is_view() || (bool) $on;
	}

	/**
	 * AppBar with «Volver» on an entry.
	 *
	 * @param mixed $secondary Current value.
	 */
	public static function secondary( $secondary ): bool {
		return is_singular( 'post' ) || (bool) $secondary;
	}

	/**
	 * «Volver» of an entry: its section, or the magazine.
	 *
	 * @param mixed $url Current URL.
	 */
	public static function back_url( $url ): string {
		if ( ! is_singular( 'post' ) ) {
			return (string) $url;
		}
		$section = Model::section_of( (int) get_queried_object_id() );
		$link    = null === $section ? '' : Query::section_url( $section );
		return '' !== $link ? $link : Query::home_url();
	}

	/**
	 * «Blog» marked in the desktop AppBar on every page of the module.
	 *
	 * @param mixed $url Current URL.
	 */
	public static function app_bar( $url ): string {
		return self::is_view() ? Query::home_url() : (string) $url;
	}

	/**
	 * A section filtered by product is not indexed (its canonical is the section).
	 *
	 * @param mixed $noindex Whether the page is not indexed.
	 */
	public static function noindex( $noindex ): bool {
		return (bool) $noindex || ( is_tax( Model::SECTION ) && absint( get_query_var( self::PRODUCT_VAR ) ) );
	}

	/**
	 * Title of the magazine (WordPress has no title for a custom rule).
	 *
	 * @param array<string, string> $parts Parts.
	 * @return array<string, string>
	 */
	public static function title( $parts ): array {
		$parts = is_array( $parts ) ? $parts : array();
		if ( self::is_home() ) {
			$parts['title'] = Texts::blog_title();
		}
		return $parts;
	}

	/**
	 * Canonical of the current page of the module: the section without the product filter.
	 */
	public static function canonical(): string {
		if ( is_tax( array( Model::SECTION, Model::TOPIC ) ) ) {
			$term = get_queried_object();
			$link = $term instanceof \WP_Term ? get_term_link( $term ) : '';
			$page = max( 1, (int) get_query_var( 'paged' ) );
			if ( ! is_string( $link ) ) {
				return '';
			}
			return $page > 1 ? user_trailingslashit( trailingslashit( $link ) . 'page/' . $page ) : $link;
		}
		return self::is_home() ? Query::home_url() : '';
	}
}
