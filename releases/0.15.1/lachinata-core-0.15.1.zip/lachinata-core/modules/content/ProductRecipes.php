<?php
/**
 * Recipes with a product.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * «Recetas con este producto» (up to 3) on the product page, under everything that serves
 * to buy, and «Ideas para tu {producto}» on the thank you page and in the email of the
 * shipped order: only for products of the categories of the setting `product_recipes`
 * (kitchen ones; never cosmetics), and never in the bag or the checkout. Without recipes,
 * nothing is printed.
 */
final class ProductRecipes {

	/**
	 * Most recipes shown.
	 */
	public const MOST = 3;

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'lachinata/product/after', array( self::class, 'product_page' ) );
		Hooks::add_action( 'lachinata/thankyou/after', array( self::class, 'thank_you' ) );
		Hooks::add_action( 'woocommerce_email_after_order_table', array( self::class, 'email' ), 20, 4 );
	}

	/**
	 * Whether a product shows recipes: one of its categories (or their parents) is in the
	 * setting.
	 *
	 * @param \WC_Product $product Product.
	 */
	public static function allowed( \WC_Product $product ): bool {
		$slugs = array_filter( array_map( 'sanitize_title', (array) ContentModule::setting( 'product_recipes' ) ) );
		if ( ! $slugs ) {
			return false;
		}
		$id = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();
		foreach ( wc_get_product_term_ids( $id, 'product_cat' ) as $term_id ) {
			foreach ( array_merge( array( $term_id ), get_ancestors( $term_id, 'product_cat', 'taxonomy' ) ) as $category ) {
				$term = get_term( (int) $category, 'product_cat' );
				if ( $term instanceof \WP_Term && in_array( $term->slug, $slugs, true ) ) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Recipes of a product, when it shows them.
	 *
	 * @param \WC_Product $product Product.
	 * @return \WP_Post[]
	 */
	public static function recipes( \WC_Product $product ): array {
		return self::allowed( $product ) ? Query::recipes_with( $product->get_id(), self::MOST ) : array();
	}

	/**
	 * «Ver todas»: the recipe section filtered by the product.
	 *
	 * @param \WC_Product $product Product.
	 */
	public static function all_url( \WC_Product $product ): string {
		$section = Model::recipe_section();
		$link    = null === $section ? '' : get_term_link( $section );
		return is_string( $link ) && '' !== $link ? add_query_arg( Pages::PRODUCT_VAR, $product->get_id(), $link ) : '';
	}

	/**
	 * The section of recipes of a product («Recetas con este producto» or «Ideas para tu…»).
	 *
	 * @param \WC_Product $product Product.
	 * @param string      $title   Title.
	 * @param string      $id      Id of the title.
	 */
	public static function section( \WC_Product $product, string $title, string $id ): string {
		$recipes = self::recipes( $product );
		if ( ! $recipes ) {
			return '';
		}
		$all   = self::all_url( $product );
		$cards = '';
		foreach ( $recipes as $index => $recipe ) {
			$cards .= Html::card(
				$recipe,
				'vertical',
				array(
					'data-lc-entry' => $recipe->ID,
					'data-lc-list'  => $title,
					'data-lc-index' => $index + 1,
				)
			);
		}
		return sprintf(
			'<section class="lc-block lc-container lc-precipes" aria-labelledby="%1$s"><div class="lc-section"><div class="lc-section__titles"><h2 class="h2" id="%1$s">%2$s</h2></div>%3$s</div><div class="lc-precipes__grid">%4$s</div></section>',
			esc_attr( $id ),
			esc_html( $title ),
			'' === $all ? '' : sprintf( '<a href="%1$s" class="lc-section__more label">%2$s%3$s</a>', esc_url( $all ), esc_html__( 'Ver todas', 'lachinata-core' ), Html::icon( 'arrow-right', true ) ),
			$cards
		);
	}

	/**
	 * Product page.
	 *
	 * @param mixed $product Product.
	 */
	public static function product_page( $product ): void {
		if ( $product instanceof \WC_Product ) {
			echo self::section( $product, __( 'Recetas con este producto', 'lachinata-core' ), 'lc-product-recipes' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in section().
		}
	}

	/**
	 * The first product of an order that has recipes.
	 *
	 * @param \WC_Order $order Order.
	 */
	public static function first_with_recipes( \WC_Order $order ): ?\WC_Product {
		foreach ( $order->get_items() as $item ) {
			$product = $item instanceof \WC_Order_Item_Product ? $item->get_product() : null;
			if ( $product instanceof \WC_Product && self::recipes( $product ) ) {
				return $product;
			}
		}
		return null;
	}

	/**
	 * «Ideas para tu {producto}» on the thank you page.
	 *
	 * @param mixed $order Order.
	 */
	public static function thank_you( $order ): void {
		$product = $order instanceof \WC_Order ? self::first_with_recipes( $order ) : null;
		if ( null === $product ) {
			return;
		}
		/* translators: %s: product name. */
		echo self::section( $product, sprintf( __( 'Ideas para tu %s', 'lachinata-core' ), $product->get_name() ), 'lc-thanks-recipes' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in section().
	}

	/**
	 * «Ideas para tu {producto}» in the email of the shipped order: titles with their time,
	 * as links (an email has no cards).
	 *
	 * @param mixed $order         Order.
	 * @param mixed $sent_to_admin To the shop.
	 * @param mixed $plain_text    Plain text.
	 * @param mixed $email         Email.
	 */
	public static function email( $order, $sent_to_admin, $plain_text, $email = null ): void {
		if ( $sent_to_admin || $plain_text || ! $order instanceof \WC_Order || ! $email instanceof \WC_Email || 'customer_completed_order' !== $email->id ) {
			return;
		}
		$product = self::first_with_recipes( $order );
		if ( null === $product ) {
			return;
		}
		$items = '';
		foreach ( self::recipes( $product ) as $recipe ) {
			$card   = Recipe::card( $recipe->ID );
			$items .= sprintf(
				'<li><a href="%1$s">%2$s</a>%3$s</li>',
				esc_url( (string) get_permalink( $recipe ) ),
				esc_html( get_the_title( $recipe ) ),
				'' === $card['time'] ? '' : ' · ' . esc_html( $card['time'] )
			);
		}
		printf(
			'<h2>%1$s</h2><ul>%2$s</ul>',
			/* translators: %s: product name. */
			esc_html( sprintf( __( 'Ideas para tu %s', 'lachinata-core' ), $product->get_name() ) ),
			$items // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above.
		);
	}
}
