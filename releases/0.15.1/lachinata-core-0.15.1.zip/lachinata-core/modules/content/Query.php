<?php
/**
 * Lists of entries.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

defined( 'ABSPATH' ) || exit;

/**
 * The queries of the magazine, the sections, the related entries and the recipes of a
 * product. Only published posts; the index of the recipes (Fields::PRODUCT, MINUTES) keeps
 * them cheap.
 */
final class Query {

	/**
	 * Base arguments: published posts, without counting the total when not needed.
	 *
	 * @param array<string, mixed> $args Arguments.
	 * @return \WP_Post[]
	 */
	public static function posts( array $args ): array {
		$query = new \WP_Query(
			array_merge(
				array(
					'post_type'              => 'post',
					'post_status'            => 'publish',
					'ignore_sticky_posts'    => true,
					'no_found_rows'          => true,
					'update_post_term_cache' => true,
				),
				$args
			)
		);
		return array_values( array_filter( $query->posts, static fn( $post ): bool => $post instanceof \WP_Post ) );
	}

	/**
	 * Meta query of a format. Without a saved format, a post is an article.
	 *
	 * @param string $format Format.
	 * @return array<int|string, mixed>
	 */
	public static function format_query( string $format ): array {
		if ( Model::ARTICLE !== $format ) {
			return array(
				array(
					'key'   => Fields::FORMAT,
					'value' => $format,
				),
			);
		}
		return array(
			'relation' => 'OR',
			array(
				'key'   => Fields::FORMAT,
				'value' => Model::ARTICLE,
			),
			array(
				'key'     => Fields::FORMAT,
				'compare' => 'NOT EXISTS',
			),
		);
	}

	/**
	 * Tax query of a section and its subsections.
	 *
	 * @param \WP_Term $section Section.
	 * @return array<int, array<string, mixed>>
	 */
	public static function section_query( \WP_Term $section ): array {
		return array(
			array(
				'taxonomy'         => Model::SECTION,
				'terms'            => array( $section->term_id ),
				'include_children' => true,
			),
		);
	}

	/**
	 * Published entries of a format (in a section).
	 *
	 * @param string        $format  Format.
	 * @param \WP_Term|null $section Section.
	 */
	public static function count_format( string $format, ?\WP_Term $section = null ): int {
		$args = array(
			'post_type'      => 'post',
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'fields'         => 'ids',
			'meta_query'     => self::format_query( $format ), // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Indexed by key; a few thousand posts.
		);
		if ( null !== $section ) {
			$args['tax_query'] = self::section_query( $section ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- One term.
		}
		$query = new \WP_Query( $args );
		return (int) $query->found_posts;
	}

	/**
	 * The newest entry of a format (the big card of the magazine).
	 *
	 * @param string $format Format.
	 */
	public static function latest( string $format ): ?\WP_Post {
		$posts = self::posts(
			array(
				'posts_per_page' => 1,
				'meta_query'     => self::format_query( $format ), // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Indexed by key.
			)
		);
		return $posts[0] ?? null;
	}

	/**
	 * Newest entries of a section.
	 *
	 * @param \WP_Term $section Section.
	 * @param int      $count   How many.
	 * @param int[]    $exclude Posts to leave out.
	 * @return \WP_Post[]
	 */
	public static function in_section( \WP_Term $section, int $count, array $exclude = array() ): array {
		return self::posts(
			array(
				'posts_per_page' => $count,
				'post__not_in'   => $exclude, // phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_post__not_in -- A handful of ids.
				'tax_query'      => self::section_query( $section ), // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- One term.
			)
		);
	}

	/**
	 * Most read entries: by the clicks of Search Console when they were imported, else
	 * the newest.
	 *
	 * @param int   $count   How many.
	 * @param int[] $exclude Posts to leave out.
	 * @return \WP_Post[]
	 */
	public static function most_read( int $count, array $exclude = array() ): array {
		$posts = self::posts(
			array(
				'posts_per_page' => $count,
				'post__not_in'   => $exclude, // phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_post__not_in -- A handful of ids.
				'meta_key'       => Fields::CLICKS, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Indexed by key.
				'orderby'        => 'meta_value_num',
				'order'          => 'DESC',
			)
		);
		return $posts ? $posts : self::posts(
			array(
				'posts_per_page' => $count,
				'post__not_in'   => $exclude, // phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_post__not_in -- A handful of ids.
			)
		);
	}

	/**
	 * Related entries: same section (subsection first), newest first.
	 *
	 * @param \WP_Post $post  Post.
	 * @param int      $count How many.
	 * @return \WP_Post[]
	 */
	public static function related( \WP_Post $post, int $count ): array {
		$section = Model::section_of( $post );
		if ( null === $section ) {
			return array();
		}
		$posts = self::in_section( $section, $count, array( $post->ID ) );
		if ( count( $posts ) < $count && $section->parent ) {
			$root  = Model::root( $section );
			$posts = array_merge( $posts, self::in_section( $root, $count - count( $posts ), array_merge( array( $post->ID ), wp_list_pluck( $posts, 'ID' ) ) ) );
		}
		return $posts;
	}

	/**
	 * Recipes that use a product (or its parent, for a variation), newest first.
	 *
	 * @param int $product_id Product.
	 * @param int $count      How many (-1 for all).
	 * @return \WP_Post[]
	 */
	public static function recipes_with( int $product_id, int $count ): array {
		$product = wc_get_product( $product_id );
		$ids     = array( $product_id );
		if ( $product instanceof \WC_Product ) {
			$ids = array_merge( $ids, $product->get_children(), $product->get_parent_id() ? array( $product->get_parent_id() ) : array() );
		}
		return self::posts(
			array(
				'posts_per_page' => $count,
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Indexed by key.
					array(
						'key'     => Fields::PRODUCT,
						'value'   => array_map( 'intval', array_unique( $ids ) ),
						'compare' => 'IN',
					),
				),
			)
		);
	}

	/**
	 * Recipes of a section: whether a subsection has enough for its own page.
	 *
	 * @param \WP_Term $section Subsection.
	 */
	public static function has_page( \WP_Term $section ): bool {
		if ( ! $section->parent ) {
			return true;
		}
		$minimum = max( 1, (int) ContentModule::setting( 'subsection_minimum' ) );
		return self::count_format( Model::RECIPE, $section ) >= $minimum;
	}

	/**
	 * Link of a section, or '' for a subsection without its own page.
	 *
	 * @param \WP_Term $section Section.
	 */
	public static function section_url( \WP_Term $section ): string {
		if ( ! self::has_page( $section ) ) {
			return '';
		}
		$link = get_term_link( $section );
		return is_string( $link ) ? $link : '';
	}

	/**
	 * URL of the magazine.
	 */
	public static function home_url(): string {
		return home_url( user_trailingslashit( Model::BASE ) );
	}

	/**
	 * Tint behind a card without photo: the one of the product category of its section.
	 *
	 * @param \WP_Post $post Post.
	 */
	public static function tint( \WP_Post $post ): string {
		$section = Model::section_of( $post );
		$slug    = null === $section ? '' : (string) get_term_meta( Model::root( $section )->term_id, Fields::SECTION_PRODUCTS, true );
		$term    = '' === $slug ? false : get_term_by( 'slug', $slug, 'product_cat' );
		$tint    = '';
		if ( $term instanceof \WP_Term ) {
			/** This filter is documented in theme/inc/catalog.php */
			$tint = (string) apply_filters( 'lachinata/category/tint', '', $term ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingSinceComment -- The theme's hook.
		}
		return '' !== $tint ? sanitize_key( $tint ) : 'gourmet';
	}
}
