<?php
/**
 * A recipe as data.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

defined( 'ABSPATH' ) || exit;

/**
 * The data of the block `lachinata/receta`, normalized: servings; preparation, cooking and
 * resting time in minutes (the total is computed, never written); difficulty; cuisine;
 * groups of ingredients (quantity, unit, ingredient, note and, when it is one of the shop's,
 * the product by local id and SKU); steps with optional time and image; tips, variants,
 * storage and an optional video. No nutrition and no allergens: the block has no field for
 * them.
 *
 * @phpstan-type Item array{qty: string, unit: string, name: string, note: string, product: int, sku: string}
 * @phpstan-type Group array{title: string, items: array<int, Item>}
 * @phpstan-type Step array{text: string, time: int, image: int, alt: string}
 * @phpstan-type Data array{servings: int, prep: int, cook: int, rest: int, difficulty: string, cuisine: string, groups: array<int, Group>, steps: array<int, Step>, tips: string[], variants: string[], storage: string, video: string}
 */
final class Recipe {

	/**
	 * Difficulties.
	 */
	public const DIFFICULTIES = array( 'facil', 'media', 'dificil' );

	/**
	 * Name of a difficulty.
	 *
	 * @param string $difficulty facil, media or dificil.
	 */
	public static function difficulty( string $difficulty ): string {
		$names = array(
			'facil'   => __( 'Fácil', 'lachinata-core' ),
			'media'   => __( 'Media', 'lachinata-core' ),
			'dificil' => __( 'Difícil', 'lachinata-core' ),
		);
		return $names[ $difficulty ] ?? '';
	}

	/**
	 * The recipe of a post (its first block `lachinata/receta`), or null.
	 *
	 * @param \WP_Post|int $post Post.
	 * @return Data|null
	 */
	public static function of( $post ): ?array {
		$post = get_post( $post );
		if ( ! $post instanceof \WP_Post || ! has_block( RecipeBlock::NAME, $post ) ) {
			return null;
		}
		foreach ( parse_blocks( $post->post_content ) as $block ) {
			if ( RecipeBlock::NAME === ( $block['blockName'] ?? '' ) ) {
				return self::normalize( (array) ( $block['attrs']['recipe'] ?? array() ) );
			}
		}
		return null;
	}

	/**
	 * Clean data from the block attributes (or from the migration).
	 *
	 * @param array<string, mixed> $raw Raw data.
	 * @return Data
	 */
	public static function normalize( array $raw ): array {
		$minutes = static fn( $value ): int => max( 0, min( 60 * 24 * 7, (int) $value ) );
		$text    = static fn( $value ): string => trim( sanitize_text_field( is_scalar( $value ) ? (string) $value : '' ) );
		$lines   = static fn( $value ): array => array_values( array_filter( array_map( $text, is_array( $value ) ? $value : array() ), static fn( string $value ): bool => '' !== $value ) );
		$groups  = array();
		foreach ( is_array( $raw['groups'] ?? null ) ? $raw['groups'] : array() as $group ) {
			$group = is_array( $group ) ? $group : array();
			$items = array();
			foreach ( is_array( $group['items'] ?? null ) ? $group['items'] : array() as $item ) {
				$item = is_array( $item ) ? $item : array();
				$name = $text( $item['name'] ?? '' );
				if ( '' === $name ) {
					continue;
				}
				$items[] = array(
					'qty'     => $text( $item['qty'] ?? '' ),
					'unit'    => $text( $item['unit'] ?? '' ),
					'name'    => $name,
					'note'    => $text( $item['note'] ?? '' ),
					'product' => absint( $item['product'] ?? 0 ),
					'sku'     => $text( $item['sku'] ?? '' ),
				);
			}
			if ( $items ) {
				$groups[] = array(
					'title' => $text( $group['title'] ?? '' ),
					'items' => $items,
				);
			}
		}
		$steps = array();
		foreach ( is_array( $raw['steps'] ?? null ) ? $raw['steps'] : array() as $step ) {
			$step = is_array( $step ) ? $step : array( 'text' => $step );
			$body = trim( sanitize_textarea_field( is_scalar( $step['text'] ?? null ) ? (string) $step['text'] : '' ) );
			if ( '' === $body ) {
				continue;
			}
			$steps[] = array(
				'text'  => $body,
				'time'  => $minutes( $step['time'] ?? 0 ),
				'image' => absint( $step['image'] ?? 0 ),
				'alt'   => $text( $step['alt'] ?? '' ),
			);
		}
		$difficulty = (string) ( $raw['difficulty'] ?? '' );
		return array(
			'servings'   => max( 0, min( 99, (int) ( $raw['servings'] ?? 0 ) ) ),
			'prep'       => $minutes( $raw['prep'] ?? 0 ),
			'cook'       => $minutes( $raw['cook'] ?? 0 ),
			'rest'       => $minutes( $raw['rest'] ?? 0 ),
			'difficulty' => in_array( $difficulty, self::DIFFICULTIES, true ) ? $difficulty : '',
			'cuisine'    => $text( $raw['cuisine'] ?? '' ),
			'groups'     => $groups,
			'steps'      => $steps,
			'tips'       => $lines( $raw['tips'] ?? array() ),
			'variants'   => $lines( $raw['variants'] ?? array() ),
			'storage'    => trim( sanitize_textarea_field( is_scalar( $raw['storage'] ?? null ) ? (string) $raw['storage'] : '' ) ),
			'video'      => esc_url_raw( is_scalar( $raw['video'] ?? null ) ? (string) $raw['video'] : '', array( 'https' ) ),
		);
	}

	/**
	 * Total minutes: preparation, cooking and resting.
	 *
	 * @param array<string, mixed> $recipe Recipe.
	 * @phpstan-param Data $recipe
	 */
	public static function total( array $recipe ): int {
		return $recipe['prep'] + $recipe['cook'] + $recipe['rest'];
	}

	/**
	 * A time for people: «20 min», «1 h», «6 h 20 min», «2 días».
	 *
	 * @param int $minutes Minutes.
	 */
	public static function duration( int $minutes ): string {
		if ( $minutes <= 0 ) {
			return '';
		}
		$days  = intdiv( $minutes, 1440 );
		$hours = intdiv( $minutes % 1440, 60 );
		$rest  = $minutes % 60;
		$parts = array();
		if ( $days ) {
			/* translators: %s: number of days. */
			$parts[] = sprintf( _n( '%s día', '%s días', $days, 'lachinata-core' ), number_format_i18n( $days ) );
		}
		if ( $hours ) {
			/* translators: %s: number of hours. */
			$parts[] = sprintf( __( '%s h', 'lachinata-core' ), number_format_i18n( $hours ) );
		}
		if ( $rest ) {
			/* translators: %s: number of minutes. */
			$parts[] = sprintf( __( '%s min', 'lachinata-core' ), number_format_i18n( $rest ) );
		}
		return implode( ' ', $parts );
	}

	/**
	 * ISO 8601 duration for schema.org (PT6H20M), or ''.
	 *
	 * @param int $minutes Minutes.
	 */
	public static function iso( int $minutes ): string {
		if ( $minutes <= 0 ) {
			return '';
		}
		$hours = intdiv( $minutes, 60 );
		$rest  = $minutes % 60;
		return 'PT' . ( $hours ? $hours . 'H' : '' ) . ( $rest ? $rest . 'M' : '' );
	}

	/**
	 * Quantity as a number («1/2», «1,5», «1 1/2», «½»), or null when it is not one
	 * («una pizca», «al gusto»): those lines do not scale.
	 *
	 * @param string $qty Quantity.
	 */
	public static function number( string $qty ): ?float {
		$qty = trim(
			strtr(
				$qty,
				array(
					'½' => ' 1/2',
					'¼' => ' 1/4',
					'¾' => ' 3/4',
					'⅓' => ' 1/3',
					'⅔' => ' 2/3',
				)
			)
		);
		if ( preg_match( '/^(\d+)\s+(\d+)\/(\d+)$/', $qty, $m ) && (int) $m[3] > 0 ) {
			return (int) $m[1] + (int) $m[2] / (int) $m[3];
		}
		if ( preg_match( '/^(\d+)\/(\d+)$/', $qty, $m ) && (int) $m[2] > 0 ) {
			return (int) $m[1] / (int) $m[2];
		}
		if ( preg_match( '/^\d+(?:[.,]\d+)?$/', $qty ) ) {
			return (float) str_replace( ',', '.', $qty );
		}
		return null;
	}

	/**
	 * Product of an ingredient line, when it is still on sale: by local id and, when the id
	 * is not a product here (another shop, a migration), by SKU. Null when it is gone: the
	 * line stays as text, without link or purchase.
	 *
	 * @param array<string, mixed> $item Ingredient.
	 * @phpstan-param Item $item
	 */
	public static function product( array $item ): ?\WC_Product {
		$product = $item['product'] ? wc_get_product( $item['product'] ) : null;
		if ( ( ! $product instanceof \WC_Product || 'publish' !== $product->get_status() ) && '' !== $item['sku'] ) {
			$id      = wc_get_product_id_by_sku( $item['sku'] );
			$product = $id ? wc_get_product( $id ) : null;
		}
		if ( ! $product instanceof \WC_Product || 'publish' !== $product->get_status() || ! $product->is_visible() ) {
			return null;
		}
		return $product;
	}

	/**
	 * Products the recipe uses (published), once each, in the order of the ingredients.
	 *
	 * @param array<string, mixed> $recipe Recipe.
	 * @phpstan-param Data $recipe
	 * @return \WC_Product[]
	 */
	public static function products( array $recipe ): array {
		$products = array();
		foreach ( $recipe['groups'] as $group ) {
			foreach ( $group['items'] as $item ) {
				$product = self::product( $item );
				if ( null !== $product ) {
					$products[ $product->get_id() ] = $product;
				}
			}
		}
		return array_values( $products );
	}

	/**
	 * Rewrites the index of a post from its block: the summary for the cards, the total
	 * minutes and one row per product. Without the block, the index goes away.
	 *
	 * @param \WP_Post $post Post.
	 */
	public static function reindex( \WP_Post $post ): void {
		$recipe = self::of( $post );
		delete_post_meta( $post->ID, Fields::PRODUCT );
		if ( null === $recipe ) {
			delete_post_meta( $post->ID, Fields::RECIPE );
			delete_post_meta( $post->ID, Fields::MINUTES );
			return;
		}
		$ids = array();
		foreach ( $recipe['groups'] as $group ) {
			foreach ( $group['items'] as $item ) {
				$id = $item['product'];
				if ( ( ! $id || ! wc_get_product( $id ) ) && '' !== $item['sku'] ) {
					$id = (int) wc_get_product_id_by_sku( $item['sku'] );
				}
				if ( $id ) {
					$ids[ $id ] = $id;
				}
			}
		}
		foreach ( $ids as $id ) {
			add_post_meta( $post->ID, Fields::PRODUCT, $id );
		}
		update_post_meta(
			$post->ID,
			Fields::RECIPE,
			array(
				'servings'   => $recipe['servings'],
				'minutes'    => self::total( $recipe ),
				'difficulty' => $recipe['difficulty'],
				'products'   => array_values( $ids ),
			)
		);
		update_post_meta( $post->ID, Fields::MINUTES, self::total( $recipe ) );
	}

	/**
	 * Card data of a recipe from its index: total time and difficulty.
	 *
	 * @param int $post_id Post id.
	 * @return array{time: string, difficulty: string}
	 */
	public static function card( int $post_id ): array {
		$index = get_post_meta( $post_id, Fields::RECIPE, true );
		$index = is_array( $index ) ? $index : array();
		return array(
			'time'       => self::duration( (int) ( $index['minutes'] ?? 0 ) ),
			'difficulty' => self::difficulty( (string) ( $index['difficulty'] ?? '' ) ),
		);
	}
}
