<?php
/**
 * Block `lachinata/receta`.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * The recipe is stored as the attributes of one block in the post content. On the page of
 * the recipe the module's template places each part (header, ingredients, products, steps,
 * tips); anywhere else (the feed, another template) the block prints the whole recipe in
 * the same order.
 *
 * @phpstan-import-type Data from Recipe
 */
final class RecipeBlock {

	public const NAME = 'lachinata/receta';

	/**
	 * Editor script handle (block and the panel of the entries).
	 */
	public const EDITOR = 'lachinata-content-editor';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'init', array( self::class, 'register' ) );
	}

	/**
	 * Registers the editor script and the block.
	 */
	public static function register(): void {
		$file  = LACHINATA_CORE_DIR . '/modules/content/build/editor.asset.php';
		$asset = is_readable( $file ) ? require $file : array(
			'dependencies' => array( 'wp-api-fetch', 'wp-block-editor', 'wp-blocks', 'wp-components', 'wp-core-data', 'wp-data', 'wp-editor', 'wp-element', 'wp-i18n', 'wp-plugins' ),
			'version'      => LACHINATA_CORE_VERSION,
		);
		wp_register_script( self::EDITOR, plugins_url( 'modules/content/build/editor.js', LACHINATA_CORE_FILE ), (array) $asset['dependencies'], (string) $asset['version'], true );
		wp_set_script_translations( self::EDITOR, 'lachinata-core', LACHINATA_CORE_DIR . '/languages' );
		register_block_type(
			LACHINATA_CORE_DIR . '/modules/content/blocks/receta',
			array(
				'render_callback' => Hooks::wrap(
					static fn( $attributes ): string => Pages::in_recipe() ? '' : self::render( Recipe::normalize( (array) ( ( is_array( $attributes ) ? $attributes : array() )['recipe'] ?? array() ) ) ),
					''
				),
			)
		);
	}

	/**
	 * The whole recipe in the order of the page.
	 *
	 * @param array<string, mixed> $recipe Recipe.
	 * @phpstan-param Data $recipe
	 */
	public static function render( array $recipe ): string {
		return '<div class="lc-recipe">' . Html::recipe_header( $recipe ) . self::ingredients( $recipe ) . self::steps( $recipe ) . self::tips( $recipe ) . '</div>';
	}

	/**
	 * «Ingredientes», with the line of the servings.
	 *
	 * @param array<string, mixed> $recipe Recipe.
	 * @phpstan-param Data $recipe
	 */
	public static function ingredients( array $recipe ): string {
		if ( ! $recipe['groups'] ) {
			return '';
		}
		$note = $recipe['servings'] > 0
			? sprintf(
				/* translators: %s: servings. */
				_n( 'Para %s ración. Marca lo que ya tienes.', 'Para %s raciones. Marca lo que ya tienes.', $recipe['servings'], 'lachinata-core' ),
				'<span data-lc-servings-text>' . esc_html( number_format_i18n( $recipe['servings'] ) ) . '</span>'
			)
			: esc_html__( 'Marca lo que ya tienes.', 'lachinata-core' );
		return sprintf(
			'<section class="lc-recipe__ing" aria-labelledby="lc-recipe-ing"><h2 class="h2" id="lc-recipe-ing">%1$s</h2><p class="body-sm lc-recipe__note">%2$s</p>%3$s</section>',
			esc_html__( 'Ingredientes', 'lachinata-core' ),
			$note,
			Html::ingredients( $recipe )
		);
	}

	/**
	 * «Preparación».
	 *
	 * @param array<string, mixed> $recipe Recipe.
	 * @phpstan-param Data $recipe
	 */
	public static function steps( array $recipe ): string {
		if ( ! $recipe['steps'] ) {
			return '';
		}
		return sprintf(
			'<section class="lc-recipe__steps" aria-labelledby="lc-recipe-steps"><h2 class="h2" id="lc-recipe-steps">%1$s</h2>%2$s</section>',
			esc_html__( 'Preparación', 'lachinata-core' ),
			Html::steps( $recipe )
		);
	}

	/**
	 * «Consejos», «Variantes», «Conservación» and the video.
	 *
	 * @param array<string, mixed> $recipe Recipe.
	 * @phpstan-param Data $recipe
	 */
	public static function tips( array $recipe ): string {
		$html = '';
		foreach (
			array(
				'tips'     => __( 'Consejos', 'lachinata-core' ),
				'variants' => __( 'Variantes', 'lachinata-core' ),
			) as $key => $title
		) {
			if ( $recipe[ $key ] ) {
				$html .= sprintf( '<h2 class="h2">%1$s</h2><ul>%2$s</ul>', esc_html( $title ), implode( '', array_map( static fn( string $line ): string => '<li>' . esc_html( $line ) . '</li>', $recipe[ $key ] ) ) );
			}
		}
		if ( '' !== $recipe['storage'] ) {
			$html .= sprintf( '<h2 class="h2">%1$s</h2><p>%2$s</p>', esc_html__( 'Conservación', 'lachinata-core' ), nl2br( esc_html( $recipe['storage'] ) ) );
		}
		if ( '' !== $recipe['video'] ) {
			$html .= sprintf(
				'<h2 class="h2">%1$s</h2><p><a href="%2$s" rel="noopener" target="_blank">%3$s</a></p>',
				esc_html__( 'Vídeo', 'lachinata-core' ),
				esc_url( $recipe['video'] ),
				esc_html__( 'Ver el vídeo de la receta', 'lachinata-core' )
			);
		}
		return '' === $html ? '' : '<section class="lc-prose lc-recipe__tips body">' . $html . '</section>';
	}
}
