<?php
/**
 * Old archives of the blog.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * 301 by rule, without a row per URL: a category goes to its section (setting
 * `category_sections`, category slug → section slug, filled by the migration) or to the
 * magazine; a tag, to the section of its newest entry or to the magazine; an author, to
 * the magazine (no author pages: no user is exposed). The redirections of the archive
 * review go to Rank Math's (or the module's table without it), not here.
 */
final class Redirects {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'template_redirect', array( self::class, 'redirect' ), 1 );
	}

	/**
	 * Where an old archive goes, or '' when the request is not one.
	 */
	public static function target(): string {
		if ( is_author() ) {
			return Query::home_url();
		}
		if ( is_category() ) {
			$term = get_queried_object();
			$map  = (array) ContentModule::setting( 'category_sections' );
			$slug = $term instanceof \WP_Term ? sanitize_title( (string) ( $map[ $term->slug ] ?? '' ) ) : '';
			return self::section_link( $slug );
		}
		if ( is_tag() ) {
			$term    = get_queried_object();
			$posts   = $term instanceof \WP_Term ? Query::posts(
				array(
					'posts_per_page' => 1,
					'tag_id'         => $term->term_id,
				)
			) : array();
			$section = $posts ? Model::section_of( $posts[0] ) : null;
			return null === $section ? Query::home_url() : self::section_link( Model::root( $section )->slug );
		}
		return '';
	}

	/**
	 * Link of a section by slug, or the magazine.
	 *
	 * @param string $slug Section slug.
	 */
	private static function section_link( string $slug ): string {
		$term = '' === $slug ? false : get_term_by( 'slug', $slug, Model::SECTION );
		$link = $term instanceof \WP_Term ? get_term_link( $term ) : '';
		return is_string( $link ) && '' !== $link ? $link : Query::home_url();
	}

	/**
	 * Sends an old archive where it goes.
	 */
	public static function redirect(): void {
		$target = self::target();
		if ( '' === $target ) {
			return;
		}
		wp_safe_redirect( $target, 301, 'lachinata-core' );
		exit;
	}
}
