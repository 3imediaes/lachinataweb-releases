<?php
/**
 * Retired entries.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * «Retirada» is a status of its own, neither draft nor bin: the entry is not public and is
 * out of lists, searches and sitemaps, but keeps its content and its metrics. Its address
 * answers 410 or the 301 kept for it; publishing it again undoes it. The destination of a
 * 301 is kept by id (entry, section, store page or product), so it holds if the address
 * changes; if it disappears, the 301 goes to the entry's section and the health says so.
 * Nothing is deleted from the database by itself.
 *
 * @phpstan-type Target array{type: string, id: int, url: string}
 */
final class Retired {

	public const STATUS = 'lc_retirada';

	/**
	 * Where a retired entry goes: {type: post|section|store|product|url|gone, id, url}.
	 */
	public const TARGET = '_lc_content_destino';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'init', array( self::class, 'register' ) );
		Hooks::add_action( 'template_redirect', array( self::class, 'respond' ), 0 );
	}

	/**
	 * The status.
	 */
	public static function register(): void {
		register_post_status(
			self::STATUS,
			array(
				'label'                     => _x( 'Retirada', 'post status', 'lachinata-core' ),
				'public'                    => false,
				'internal'                  => false,
				'protected'                 => true,
				'exclude_from_search'       => true,
				'show_in_admin_all_list'    => false,
				'show_in_admin_status_list' => true,
				/* translators: %s: number of entries. */
				'label_count'               => _n_noop( 'Retirada <span class="count">(%s)</span>', 'Retiradas <span class="count">(%s)</span>', 'lachinata-core' ),
			)
		);
	}

	/**
	 * A retired entry: 301 to its destination, or 410.
	 */
	public static function respond(): void {
		if ( ! is_404() ) {
			return;
		}
		$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( (string) $_SERVER['REQUEST_URI'] ) ) : '', PHP_URL_PATH ), '/' );
		if ( '' === $path || str_contains( $path, '/' ) ) {
			return;
		}
		$posts = get_posts(
			array(
				'name'        => sanitize_title( $path ),
				'post_type'   => 'post',
				'post_status' => self::STATUS,
				'numberposts' => 1,
			)
		);
		if ( ! $posts || ! $posts[0] instanceof \WP_Post ) {
			return;
		}
		$url = self::url( $posts[0] );
		if ( '' !== $url ) {
			wp_safe_redirect( $url, 301, 'lachinata-core' );
			exit;
		}
		global $wp_query;
		$wp_query->set_404();
		status_header( 410 );
		nocache_headers();
	}

	/**
	 * Saved destination of an entry.
	 *
	 * @param int $post_id Post.
	 * @return Target
	 */
	public static function target( int $post_id ): array {
		$saved = get_post_meta( $post_id, self::TARGET, true );
		$saved = is_array( $saved ) ? $saved : array();
		return array(
			'type' => (string) ( $saved['type'] ?? 'gone' ),
			'id'   => (int) ( $saved['id'] ?? 0 ),
			'url'  => (string) ( $saved['url'] ?? '' ),
		);
	}

	/**
	 * Address of a destination now, or '' when it no longer exists.
	 *
	 * @param array<string, mixed> $target Destination.
	 * @phpstan-param Target $target
	 * @param int                  $depth  Retired entries followed so far (a chain ends).
	 */
	public static function resolve( array $target, int $depth = 0 ): string {
		switch ( $target['type'] ) {
			case 'post':
				$status = $target['id'] ? get_post_status( $target['id'] ) : false;
				if ( self::STATUS === $status && $depth < 3 ) {
					$entry = get_post( $target['id'] );
					return $entry instanceof \WP_Post ? self::url( $entry, $depth + 1 ) : '';
				}
				return 'publish' === $status ? (string) get_permalink( $target['id'] ) : '';
			case 'store':
				return $target['id'] && 'publish' === get_post_status( $target['id'] ) ? (string) get_permalink( $target['id'] ) : '';
			case 'product':
				$product = $target['id'] ? wc_get_product( $target['id'] ) : null;
				return $product instanceof \WC_Product && 'publish' === $product->get_status() ? $product->get_permalink() : '';
			case 'section':
				$term = $target['id'] ? get_term( $target['id'], Model::SECTION ) : null;
				return $term instanceof \WP_Term ? Query::section_url( $term ) : '';
			case 'url':
				// A path of this site (saved without its host, so it survives a copy of the database).
				return str_starts_with( $target['url'], '/' ) ? home_url( $target['url'] ) : $target['url'];
		}
		return '';
	}

	/**
	 * Where a retired entry answers: its destination, or its section when the destination
	 * is gone; '' for a 410.
	 *
	 * @param \WP_Post $post  Post.
	 * @param int      $depth Retired entries followed so far.
	 */
	public static function url( \WP_Post $post, int $depth = 0 ): string {
		$target = self::target( $post->ID );
		if ( 'gone' === $target['type'] ) {
			return '';
		}
		$url = self::resolve( $target, $depth );
		if ( '' !== $url ) {
			return $url;
		}
		$section = Model::section_of( $post );
		$url     = null === $section ? '' : Query::section_url( Model::root( $section ) );
		return '' !== $url ? $url : Query::home_url();
	}

	/**
	 * Retired entries whose destination is gone (they fall back to their section).
	 *
	 * @return int[]
	 */
	public static function broken(): array {
		$ids = get_posts(
			array(
				'post_type'   => 'post',
				'post_status' => self::STATUS,
				'numberposts' => -1,
				'fields'      => 'ids',
			)
		);
		return array_values(
			array_filter(
				array_map( 'intval', $ids ),
				static function ( int $id ): bool {
					$target = self::target( $id );
					return 'gone' !== $target['type'] && '' === self::resolve( $target );
				}
			)
		);
	}

	/**
	 * Destination of a post id (an entry, page, product or store), or null when there is
	 * no such post.
	 *
	 * @param int $id Post id.
	 * @return Target|null
	 */
	public static function target_by_id( int $id ): ?array {
		$type = $id ? get_post_type( $id ) : false;
		if ( ! $type || 'attachment' === $type ) {
			return null;
		}
		return array(
			'type' => 'product' === $type ? 'product' : ( 'post' === $type || 'page' === $type ? 'post' : 'store' ),
			'id'   => $id,
			'url'  => '',
		);
	}

	/**
	 * Destination of an address of this shop (on this site or on its production domain): the
	 * entry, product, store page or section it is now, or its path here; '410' is a 410.
	 *
	 * @param string $url Address («410» for a 410).
	 * @return Target
	 */
	public static function target_of( string $url ): array {
		$url = trim( $url );
		if ( '' === $url || '410' === $url ) {
			return array(
				'type' => 'gone',
				'id'   => 0,
				'url'  => '',
			);
		}
		$path  = (string) wp_parse_url( $url, PHP_URL_PATH );
		$local = home_url( user_trailingslashit( '/' . trim( $path, '/' ) ) );
		$id    = url_to_postid( $local );
		if ( $id ) {
			$type = get_post_type( $id );
			return array(
				'type' => 'product' === $type ? 'product' : ( 'post' === $type || 'page' === $type ? 'post' : 'store' ),
				'id'   => $id,
				'url'  => '',
			);
		}
		// An address of the old shop (`/miel-de-flores.html`): the product it is now.
		$product = Migration::looks_like_product( $url ) ? Migration::product_from_url( $url ) : null;
		if ( null !== $product ) {
			return array(
				'type' => 'product',
				'id'   => $product->get_id(),
				'url'  => '',
			);
		}
		// An entry retired in the same list is not found by its address.
		$entry = str_contains( trim( $path, '/' ), '/' ) || '' === trim( $path, '/' ) ? null : get_page_by_path( trim( $path, '/' ), OBJECT, 'post' );
		if ( $entry instanceof \WP_Post ) {
			return array(
				'type' => 'post',
				'id'   => $entry->ID,
				'url'  => '',
			);
		}
		$slug = sanitize_title( basename( trim( $path, '/' ) ) );
		$term = '' === $slug ? false : get_term_by( 'slug', $slug, Model::SECTION );
		if ( ! $term instanceof \WP_Term && preg_match( '#(?:^|/)category/([^/]+)#', $path, $match ) ) {
			$map  = (array) ContentModule::setting( 'category_sections' );
			$term = isset( $map[ $match[1] ] ) ? get_term_by( 'slug', (string) $map[ $match[1] ], Model::SECTION ) : false;
		}
		if ( $term instanceof \WP_Term ) {
			return array(
				'type' => 'section',
				'id'   => $term->term_id,
				'url'  => '',
			);
		}
		// Addresses of the list are of this shop (perhaps on its production domain): the path
		// on this site.
		return array(
			'type' => 'url',
			'id'   => 0,
			'url'  => user_trailingslashit( '/' . trim( $path, '/' ) ),
		);
	}
}
