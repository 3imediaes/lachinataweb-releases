<?php
/**
 * Reasons to review an entry.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

defined( 'ABSPATH' ) || exit;

/**
 * An entry goes to «Revisar» with a reason (the migration, a product that changed, a store
 * that closed or no longer exists, a merge). Each reason has a code, so it is not repeated,
 * and a date: a real review of the entry after that date settles it.
 *
 * @phpstan-type Reason array{code: string, text: string, at: string}
 */
final class Review {

	/**
	 * Saved reasons.
	 *
	 * @param int $post_id Post.
	 * @return array<int, Reason>
	 */
	public static function all( int $post_id ): array {
		$saved = get_post_meta( $post_id, Fields::REVIEW, true );
		$out   = array();
		foreach ( is_array( $saved ) ? $saved : array() as $reason ) {
			if ( is_array( $reason ) && '' !== (string) ( $reason['text'] ?? '' ) ) {
				$out[] = array(
					'code' => (string) ( $reason['code'] ?? '' ),
					'text' => (string) $reason['text'],
					'at'   => (string) ( $reason['at'] ?? '' ),
				);
			}
		}
		return $out;
	}

	/**
	 * Reasons still open: those after the last real review.
	 *
	 * @param int $post_id Post.
	 * @return array<int, Reason>
	 */
	public static function open( int $post_id ): array {
		$reviewed = (string) get_post_meta( $post_id, Fields::REVIEWED, true );
		return array_values( array_filter( self::all( $post_id ), static fn( array $reason ): bool => '' === $reviewed || $reason['at'] > $reviewed ) );
	}

	/**
	 * Adds a reason (once per code; a new one replaces the old with the same code).
	 *
	 * @param int    $post_id Post.
	 * @param string $code    Code.
	 * @param string $text    Text for whoever reviews.
	 */
	public static function add( int $post_id, string $code, string $text ): void {
		$reasons   = array_values( array_filter( self::all( $post_id ), static fn( array $reason ): bool => $reason['code'] !== $code ) );
		$reasons[] = array(
			'code' => $code,
			'text' => $text,
			'at'   => wp_date( 'Y-m-d' ),
		);
		update_post_meta( $post_id, Fields::REVIEW, $reasons );
	}

	/**
	 * Whether an entry has open reasons.
	 *
	 * @param int $post_id Post.
	 */
	public static function pending( int $post_id ): bool {
		return (bool) self::open( $post_id );
	}
}
