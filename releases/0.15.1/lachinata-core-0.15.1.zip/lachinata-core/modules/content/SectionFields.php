<?php
/**
 * Fields of a section.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * The description of the section is its header text. Two fields more: the position in the
 * magazine and the product category of the products shown with its articles (and the tint
 * of its cards without photo).
 */
final class SectionFields {

	/**
	 * Nonce action.
	 */
	private const NONCE = 'lachinata_content_section';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( Model::SECTION . '_add_form_fields', array( self::class, 'add' ) );
		Hooks::add_action( Model::SECTION . '_edit_form_fields', array( self::class, 'edit' ) );
		Hooks::add_action( 'created_' . Model::SECTION, array( self::class, 'save' ) );
		Hooks::add_action( 'edited_' . Model::SECTION, array( self::class, 'save' ) );
	}

	/**
	 * Fields on «Añadir sección».
	 */
	public static function add(): void {
		wp_nonce_field( self::NONCE, 'lc_content_section_nonce' );
		printf(
			'<div class="form-field"><label for="lc-section-order">%1$s</label><input type="number" min="0" id="lc-section-order" name="lc_section[order]"></div><div class="form-field"><label for="lc-section-products">%2$s</label><input type="text" id="lc-section-products" name="lc_section[products]"><p>%3$s</p></div>',
			esc_html__( 'Orden en la revista', 'lachinata-core' ),
			esc_html__( 'Categoría de productos', 'lachinata-core' ),
			esc_html__( 'Slug de la categoría de productos que acompaña a sus artículos.', 'lachinata-core' )
		);
	}

	/**
	 * Fields on the edit screen.
	 *
	 * @param mixed $term Term.
	 */
	public static function edit( $term ): void {
		if ( ! $term instanceof \WP_Term ) {
			return;
		}
		wp_nonce_field( self::NONCE, 'lc_content_section_nonce' );
		printf(
			'<tr class="form-field"><th scope="row"><label for="lc-section-order">%1$s</label></th><td><input type="number" min="0" id="lc-section-order" name="lc_section[order]" value="%2$s"></td></tr><tr class="form-field"><th scope="row"><label for="lc-section-products">%3$s</label></th><td><input type="text" id="lc-section-products" name="lc_section[products]" value="%4$s"><p class="description">%5$s</p></td></tr>',
			esc_html__( 'Orden en la revista', 'lachinata-core' ),
			esc_attr( (string) get_term_meta( $term->term_id, Fields::SECTION_ORDER, true ) ),
			esc_html__( 'Categoría de productos', 'lachinata-core' ),
			esc_attr( (string) get_term_meta( $term->term_id, Fields::SECTION_PRODUCTS, true ) ),
			esc_html__( 'Slug de la categoría de productos que acompaña a sus artículos.', 'lachinata-core' )
		);
	}

	/**
	 * Saves the fields.
	 *
	 * @param mixed $term_id Term id.
	 */
	public static function save( $term_id ): void {
		if ( ! isset( $_POST['lc_content_section_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( (string) $_POST['lc_content_section_nonce'] ) ), self::NONCE ) || ! current_user_can( 'manage_categories' ) ) {
			return;
		}
		$values = isset( $_POST['lc_section'] ) && is_array( $_POST['lc_section'] ) ? (array) wp_unslash( $_POST['lc_section'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized below.
		$order  = trim( (string) ( $values['order'] ?? '' ) );
		if ( '' === $order ) {
			delete_term_meta( (int) $term_id, Fields::SECTION_ORDER );
		} else {
			update_term_meta( (int) $term_id, Fields::SECTION_ORDER, absint( $order ) );
		}
		$products = sanitize_title( (string) ( $values['products'] ?? '' ) );
		if ( '' === $products ) {
			delete_term_meta( (int) $term_id, Fields::SECTION_PRODUCTS );
		} else {
			update_term_meta( (int) $term_id, Fields::SECTION_PRODUCTS, $products );
		}
	}
}
