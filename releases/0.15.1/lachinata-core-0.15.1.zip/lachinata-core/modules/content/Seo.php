<?php
/**
 * Structured data of the blog and the brand.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

use LaChinata\Core\Company;
use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * Rank Math stays for titles, descriptions, sitemaps and redirections. The module emits:
 * `Organization` and `WebSite` on the whole site (from «Datos de la empresa», with its
 * networks as `sameAs`, and the same `@id` Rank Math uses, so its other entities still
 * point to them); on its pages, `BreadcrumbList`, `BlogPosting` (articles and news) or
 * `Recipe` (without rating, review or nutrition), and `ItemList` on the magazine, the
 * sections and the topics. The author is always the organization. Rank Math's entities
 * of those types are taken out where the module's replace them.
 *
 * @phpstan-import-type Data from Recipe
 */
final class Seo {

	/**
	 * Types of Rank Math the module replaces on the whole site.
	 */
	private const SITE_TYPES = array( 'Organization', 'WebSite', 'Person' );

	/**
	 * Types of Rank Math the module replaces on its pages.
	 */
	private const PAGE_TYPES = array( 'BreadcrumbList', 'Article', 'BlogPosting', 'NewsArticle', 'Recipe', 'Review', 'CollectionPage', 'ItemList' );

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'wp_head', array( self::class, 'head' ), 30 );
		Hooks::add_filter( 'rank_math/json_ld', array( self::class, 'rank_math_schema' ), 99 );
		Hooks::add_filter( 'rank_math/frontend/canonical', array( self::class, 'rank_math_canonical' ) );
		Hooks::add_filter( 'rank_math/frontend/description', array( self::class, 'rank_math_description' ) );
		Hooks::add_filter( 'rank_math/frontend/title', array( self::class, 'rank_math_title' ) );
	}

	/**
	 * Whether Rank Math is active.
	 */
	public static function rank_math(): bool {
		return defined( 'RANK_MATH_VERSION' );
	}

	/**
	 * Takes Rank Math's entities that the module replaces out of its graph.
	 *
	 * @param mixed $data Rank Math's entities, by key.
	 * @return mixed
	 */
	public static function rank_math_schema( $data ) {
		if ( ! is_array( $data ) ) {
			return $data;
		}
		$drop = Pages::is_view() ? array_merge( self::SITE_TYPES, self::PAGE_TYPES ) : self::SITE_TYPES;
		foreach ( $data as $key => $entity ) {
			$types = is_array( $entity ) ? (array) ( $entity['@type'] ?? array() ) : array();
			if ( array_intersect( $types, $drop ) ) {
				unset( $data[ $key ] );
			}
		}
		return $data;
	}

	/**
	 * Canonical of a section filtered by product and of the magazine for Rank Math.
	 *
	 * @param mixed $canonical Rank Math's.
	 * @return mixed
	 */
	public static function rank_math_canonical( $canonical ) {
		$own = Pages::is_view() ? Pages::canonical() : '';
		return '' !== $own ? $own : $canonical;
	}

	/**
	 * Description of an entry without its own written in Rank Math: «En pocas palabras»
	 * (Rank Math would make one up from the text).
	 *
	 * @param mixed $description Rank Math's.
	 * @return mixed
	 */
	public static function rank_math_description( $description ) {
		if ( ! is_singular( 'post' ) ) {
			return $description;
		}
		$id      = (int) get_queried_object_id();
		$summary = self::description( $id );
		return '' === $summary || '' !== trim( (string) get_post_meta( $id, 'rank_math_description', true ) ) ? $description : $summary;
	}

	/**
	 * Title of the magazine (Rank Math does not know the rule).
	 *
	 * @param mixed $title Rank Math's.
	 * @return mixed
	 */
	public static function rank_math_title( $title ) {
		return Pages::is_home() ? Texts::blog_title() . ' - ' . Company::trade_name() : $title;
	}

	/**
	 * Description of an entry: its summary, in one line, up to 160 characters.
	 *
	 * @param int $post_id Post.
	 */
	public static function description( int $post_id ): string {
		$summary = trim( (string) preg_replace( '/\s+/', ' ', (string) get_post_meta( $post_id, Fields::SUMMARY, true ) ) );
		return mb_strlen( $summary ) > 160 ? rtrim( mb_substr( $summary, 0, 157 ) ) . '…' : $summary;
	}

	/**
	 * Prints the graph and, without Rank Math, the description and the canonical of the
	 * module's pages.
	 */
	public static function head(): void {
		if ( ! self::rank_math() && Pages::is_view() ) {
			$description = is_singular( 'post' ) ? self::description( (int) get_queried_object_id() ) : '';
			if ( '' !== $description ) {
				printf( '<meta name="description" content="%s">' . "\n", esc_attr( $description ) );
			}
			$canonical = Pages::canonical();
			if ( '' !== $canonical ) {
				printf( '<link rel="canonical" href="%s">' . "\n", esc_url( $canonical ) );
			}
		}
		printf( '<script type="application/ld+json">%s</script>' . "\n", wp_json_encode( self::graph(), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG ) );
	}

	/**
	 * The graph of the current page.
	 *
	 * @return array<string, mixed>
	 */
	public static function graph(): array {
		$graph = array( self::organization(), self::website() );
		if ( Pages::is_view() ) {
			$crumbs = self::breadcrumb();
			if ( null !== $crumbs ) {
				$graph[] = $crumbs;
			}
			if ( is_singular( 'post' ) ) {
				$post = get_post( (int) get_queried_object_id() );
				if ( $post instanceof \WP_Post ) {
					$recipe  = Model::RECIPE === Model::format_of( $post ) ? Recipe::of( $post ) : null;
					$graph[] = null === $recipe ? self::posting( $post ) : self::recipe( $post, $recipe );
				}
			} else {
				$list = self::item_list();
				if ( null !== $list ) {
					$graph[] = $list;
				}
			}
		}
		return array(
			'@context' => 'https://schema.org',
			'@graph'   => $graph,
		);
	}

	/**
	 * `Organization` from «Datos de la empresa»: name, legal name, logo and networks.
	 *
	 * @return array<string, mixed>
	 */
	public static function organization(): array {
		$company = Company::get();
		$logo    = (int) get_theme_mod( 'custom_logo' );
		$logo    = $logo ? wp_get_attachment_image_url( $logo, 'full' ) : get_site_icon_url( 512 );
		return array_filter(
			array(
				'@type'     => 'Organization',
				'@id'       => home_url( '/#organization' ),
				'name'      => Company::trade_name(),
				'legalName' => $company['legal_name'],
				'url'       => home_url( '/' ),
				'logo'      => is_string( $logo ) && '' !== $logo ? $logo : null,
				'sameAs'    => array_values( array_column( Company::social(), 'url' ) ),
			)
		);
	}

	/**
	 * `WebSite`.
	 *
	 * @return array<string, mixed>
	 */
	public static function website(): array {
		return array(
			'@type'      => 'WebSite',
			'@id'        => home_url( '/#website' ),
			'url'        => home_url( '/' ),
			'name'       => Company::trade_name(),
			'publisher'  => array( '@id' => home_url( '/#organization' ) ),
			'inLanguage' => get_bloginfo( 'language' ),
		);
	}

	/**
	 * `BreadcrumbList` of the trail the theme prints.
	 *
	 * @return array<string, mixed>|null
	 */
	public static function breadcrumb(): ?array {
		$trail = Pages::trail( array( __( 'Inicio', 'lachinata-core' ), home_url( '/' ) ) );
		$items = array();
		$url   = self::url();
		foreach ( $trail as $index => $item ) {
			$link    = '' !== $item[1] ? $item[1] : ( count( $trail ) - 1 === $index ? $url : '' );
			$items[] = array_filter(
				array(
					'@type'    => 'ListItem',
					'position' => $index + 1,
					'name'     => $item[0],
					'item'     => '' !== $link ? $link : null,
				)
			);
		}
		return count( $items ) > 1 ? array(
			'@type'           => 'BreadcrumbList',
			'itemListElement' => $items,
		) : null;
	}

	/**
	 * URL of the current page.
	 */
	private static function url(): string {
		if ( is_singular() ) {
			return (string) get_permalink( (int) get_queried_object_id() );
		}
		$canonical = Pages::canonical();
		return '' !== $canonical ? $canonical : home_url( '/' );
	}

	/**
	 * What every entry carries: dates, image, author and publisher (the organization).
	 *
	 * @param \WP_Post $post Post.
	 * @return array<string, mixed>
	 */
	private static function common( \WP_Post $post ): array {
		$dates = Dates::of( $post );
		$image = get_the_post_thumbnail_url( $post, 'full' );
		return array_filter(
			array(
				'@id'              => get_permalink( $post ) . '#main',
				'url'              => get_permalink( $post ),
				'headline'         => get_the_title( $post ),
				'name'             => get_the_title( $post ),
				'description'      => self::description( $post->ID ),
				'image'            => is_string( $image ) ? $image : null,
				'datePublished'    => gmdate( 'c', $dates['published'] ),
				'dateModified'     => gmdate( 'c', $dates['updated'] ?? $dates['published'] ),
				'author'           => array( '@id' => home_url( '/#organization' ) ),
				'publisher'        => array( '@id' => home_url( '/#organization' ) ),
				'inLanguage'       => get_bloginfo( 'language' ),
				'mainEntityOfPage' => get_permalink( $post ),
			)
		);
	}

	/**
	 * `BlogPosting` of an article or a news item, with its sources as `citation`.
	 *
	 * @param \WP_Post $post Post.
	 * @return array<string, mixed>
	 */
	public static function posting( \WP_Post $post ): array {
		$section = Model::section_of( $post );
		$sources = get_post_meta( $post->ID, Fields::SOURCES, true );
		return array_filter(
			array_merge(
				array( '@type' => 'BlogPosting' ),
				self::common( $post ),
				array(
					'articleSection' => null === $section ? null : $section->name,
					'wordCount'      => (int) get_post_meta( $post->ID, Fields::WORDS, true ) ? (int) get_post_meta( $post->ID, Fields::WORDS, true ) : null,
					'citation'       => is_array( $sources ) && $sources ? array_values( array_column( $sources, 'url' ) ) : null,
				)
			)
		);
	}

	/**
	 * `Recipe`: times, servings, ingredients, steps, type of dish (its subsection) and
	 * cuisine. Never rating, review or nutrition.
	 *
	 * @param \WP_Post             $post   Post.
	 * @param array<string, mixed> $recipe Recipe.
	 * @phpstan-param Data $recipe
	 * @return array<string, mixed>
	 */
	public static function recipe( \WP_Post $post, array $recipe ): array {
		$section     = Model::section_of( $post );
		$ingredients = array();
		foreach ( $recipe['groups'] as $group ) {
			foreach ( $group['items'] as $item ) {
				$ingredients[] = trim( implode( ' ', array_filter( array( $item['qty'], $item['unit'], $item['name'] ) ) ) . ( '' !== $item['note'] ? ', ' . $item['note'] : '' ) );
			}
		}
		$steps = array();
		foreach ( $recipe['steps'] as $index => $step ) {
			$image   = $step['image'] ? wp_get_attachment_image_url( $step['image'], 'large' ) : '';
			$steps[] = array_filter(
				array(
					'@type' => 'HowToStep',
					'text'  => $step['text'],
					'url'   => get_permalink( $post ) . '#paso-' . ( $index + 1 ),
					'image' => is_string( $image ) && '' !== $image ? $image : null,
				)
			);
		}
		$keywords = get_the_terms( $post, Model::TOPIC );
		return array_filter(
			array_merge(
				array( '@type' => 'Recipe' ),
				self::common( $post ),
				array(
					'prepTime'           => Recipe::iso( $recipe['prep'] ),
					'cookTime'           => Recipe::iso( $recipe['cook'] ),
					'totalTime'          => Recipe::iso( Recipe::total( $recipe ) ),
					'recipeYield'        => $recipe['servings'] > 0 ? (string) $recipe['servings'] : null,
					'recipeCategory'     => null !== $section && $section->parent ? $section->name : null,
					'recipeCuisine'      => $recipe['cuisine'],
					'keywords'           => is_array( $keywords ) && $keywords ? implode( ', ', wp_list_pluck( $keywords, 'name' ) ) : null,
					'recipeIngredient'   => $ingredients,
					'recipeInstructions' => $steps,
					'video'              => '' !== $recipe['video'] ? array(
						'@type'      => 'VideoObject',
						'name'       => get_the_title( $post ),
						'contentUrl' => $recipe['video'],
					) : null,
				)
			)
		);
	}

	/**
	 * `ItemList` of the entries of the magazine, a section or a topic.
	 *
	 * @return array<string, mixed>|null
	 */
	public static function item_list(): ?array {
		global $wp_query;
		$posts = Pages::is_home() ? Magazine::listed() : ( $wp_query instanceof \WP_Query ? $wp_query->posts : array() );
		$items = array();
		foreach ( array_values( array_filter( (array) $posts, static fn( $post ): bool => $post instanceof \WP_Post ) ) as $index => $post ) {
			$items[] = array(
				'@type'    => 'ListItem',
				'position' => $index + 1,
				'url'      => get_permalink( $post ),
			);
		}
		return $items ? array(
			'@type'           => 'ItemList',
			'url'             => self::url(),
			'itemListElement' => $items,
		) : null;
	}
}
