<?php
/**
 * Words, reading time and table of contents.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

defined( 'ABSPATH' ) || exit;

/**
 * The reading time comes from the text (about 200 words a minute); the table of contents
 * from its `h2` and `h3`, only from 1,200 words. The headings get an anchor when they do
 * not have one, so the contents are plain links and work without JavaScript.
 */
final class Text {

	/**
	 * Words a minute.
	 */
	public const PACE = 200;

	/**
	 * Words from which an entry has a table of contents.
	 */
	public const TOC_FROM = 1200;

	/**
	 * Words of a text (HTML or blocks).
	 *
	 * @param string $content Content.
	 */
	public static function words( string $content ): int {
		$text = trim( (string) preg_replace( '/\s+/u', ' ', wp_strip_all_tags( strip_shortcodes( (string) preg_replace( '/<!--.*?-->/s', '', $content ) ) ) ) );
		return '' === $text ? 0 : count( (array) preg_split( '/\s+/u', $text ) );
	}

	/**
	 * «6 min de lectura».
	 *
	 * @param int $words Words.
	 */
	public static function reading_time( int $words ): string {
		if ( $words <= 0 ) {
			return '';
		}
		$minutes = max( 1, (int) round( $words / self::PACE ) );
		/* translators: %s: minutes. */
		return sprintf( __( '%s min de lectura', 'lachinata-core' ), number_format_i18n( $minutes ) );
	}

	/**
	 * Gives every `h2` and `h3` an anchor and returns the items of the table of contents.
	 *
	 * @param string $html Rendered content.
	 * @return array{html: string, items: array<int, array{text: string, href: string, level: int}>}
	 */
	public static function anchors( string $html ): array {
		$items = array();
		$used  = array();
		$html  = (string) preg_replace_callback(
			'/<h([23])(\s[^>]*)?>(.*?)<\/h\1>/is',
			static function ( array $heading ) use ( &$items, &$used ): string {
				$attrs = (string) $heading[2];
				$text  = trim( html_entity_decode( wp_strip_all_tags( $heading[3] ), ENT_QUOTES, 'UTF-8' ) );
				if ( '' === $text ) {
					return $heading[0];
				}
				if ( preg_match( '/\sid=["\']([^"\']+)["\']/i', $attrs, $id ) ) {
					$anchor = $id[1];
				} else {
					$base   = sanitize_title( $text );
					$base   = '' === $base ? 'seccion' : $base;
					$anchor = $base;
					$n      = 2;
					while ( isset( $used[ $anchor ] ) ) {
						$anchor = $base . '-' . ( $n++ );
					}
					$attrs .= ' id="' . esc_attr( $anchor ) . '"';
				}
				$used[ $anchor ] = true;
				$items[]         = array(
					'text'  => $text,
					'href'  => '#' . $anchor,
					'level' => (int) $heading[1],
				);
				return '<h' . $heading[1] . $attrs . '>' . $heading[3] . '</h' . $heading[1] . '>';
			},
			$html
		);
		return array(
			'html'  => $html,
			'items' => $items,
		);
	}

	/**
	 * Plain text of the first sentences of a content, for the excerpt of a card.
	 *
	 * @param string $content Content.
	 * @param int    $words   Most words.
	 */
	public static function excerpt( string $content, int $words = 30 ): string {
		return wp_trim_words( wp_strip_all_tags( strip_shortcodes( excerpt_remove_blocks( $content ) ) ), $words, '…' );
	}
}
