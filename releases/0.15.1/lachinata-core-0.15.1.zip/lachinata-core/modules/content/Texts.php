<?php
/**
 * Texts of the magazine.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

defined( 'ABSPATH' ) || exit;

/**
 * What the magazine says is a setting or comes from «Datos de la empresa» (the brand);
 * nothing of a shop is written in the code.
 */
final class Texts {

	/**
	 * Eyebrow of the magazine («LA REVISTA DE LA CHINATA»).
	 */
	public static function blog_eyebrow(): string {
		$text = trim( (string) ContentModule::setting( 'blog_eyebrow' ) );
		/* translators: %s: brand («La Chinata»). */
		return '' !== $text ? $text : sprintf( __( 'La revista de %s', 'lachinata-core' ), Html::brand() );
	}

	/**
	 * Title of the magazine.
	 */
	public static function blog_title(): string {
		$text = trim( (string) ContentModule::setting( 'blog_title' ) );
		return '' !== $text ? $text : __( 'Blog', 'lachinata-core' );
	}

	/**
	 * Lead of the magazine ('' for none).
	 */
	public static function blog_lead(): string {
		return trim( (string) ContentModule::setting( 'blog_lead' ) );
	}

	/**
	 * The fixed line at the foot of every entry.
	 */
	public static function signature(): string {
		/* translators: %s: brand («La Chinata»). */
		return sprintf( __( 'Contenido elaborado y revisado por el equipo de %s.', 'lachinata-core' ), Html::brand() );
	}
}
