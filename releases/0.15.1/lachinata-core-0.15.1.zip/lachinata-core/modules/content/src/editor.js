/**
 * Editor of the entries: the block `lachinata/receta` (the recipe as data, edited in the
 * canvas) and the panel «Blog y recetas» (format, «En pocas palabras», date of the review,
 * sources and the reasons to review). The data of the module come inline
 * (`window.lachinataContent`).
 */
import { __, sprintf } from '@wordpress/i18n';
import { registerBlockType } from '@wordpress/blocks';
import {
	useBlockProps,
	MediaUpload,
	MediaUploadCheck,
} from '@wordpress/block-editor';
import {
	Button,
	ComboboxControl,
	Notice,
	PanelBody,
	SelectControl,
	TextControl,
	TextareaControl,
} from '@wordpress/components';
import { useState } from '@wordpress/element';
import { useDispatch, useSelect } from '@wordpress/data';
import { PluginDocumentSettingPanel } from '@wordpress/editor';
import { registerPlugin } from '@wordpress/plugins';
import apiFetch from '@wordpress/api-fetch';
import metadata from '../blocks/receta/block.json';

const DATA = window.lachinataContent || {
	formats: [],
	difficulties: [],
	reasons: [],
};

const EMPTY_ITEM = {
	qty: '',
	unit: '',
	name: '',
	note: '',
	product: 0,
	sku: '',
};

/**
 * Replaces one element of a list.
 *
 * @param {Array}  list  List.
 * @param {number} index Index.
 * @param {Object} value New value.
 */
const replace = (list, index, value) =>
	list.map((item, i) => (i === index ? value : item));

/**
 * Moves one element of a list up or down.
 *
 * @param {Array}  list  List.
 * @param {number} index Index.
 * @param {number} by    -1 or 1.
 */
const move = (list, index, by) => {
	const to = index + by;
	if (to < 0 || to >= list.length) {
		return list;
	}
	const copy = [...list];
	[copy[index], copy[to]] = [copy[to], copy[index]];
	return copy;
};

/**
 * Search of a product of the shop (Store API): its id and SKU go with the ingredient.
 *
 * @param {Object}                 props
 * @param {Object}                 props.item     Ingredient.
 * @param {(item: Object) => void} props.onChange Change.
 */
const ProductPicker = ({ item, onChange }) => {
	const [options, setOptions] = useState(
		item.product
			? [
					{
						value: String(item.product),
						label: item.sku
							? `#${item.product} · ${item.sku}`
							: `#${item.product}`,
					},
				]
			: []
	);
	const search = (term) => {
		if (!term || term.length < 3) {
			return;
		}
		apiFetch({
			path: `/wc/store/v1/products?per_page=10&search=${encodeURIComponent(term)}`,
		})
			.then((products) =>
				setOptions(
					products.map((product) => ({
						value: String(product.id),
						label: product.sku
							? `${product.name} · ${product.sku}`
							: product.name,
						sku: product.sku || '',
					}))
				)
			)
			.catch(() => {});
	};
	return (
		<ComboboxControl
			__next40pxDefaultSize
			__nextHasNoMarginBottom
			label={__('Producto de la tienda', 'lachinata-core')}
			help={__(
				'Si el ingrediente es de la tienda. Se guarda su ID y su SKU, nunca su dirección.',
				'lachinata-core'
			)}
			value={item.product ? String(item.product) : null}
			options={options}
			onFilterValueChange={search}
			onChange={(value) => {
				const option = options.find((o) => o.value === value);
				onChange({
					...item,
					product: value ? Number(value) : 0,
					sku: value ? option?.sku || item.sku : '',
				});
			}}
		/>
	);
};

const Ingredients = ({ groups, onChange }) => (
	<PanelBody title={__('Ingredientes', 'lachinata-core')}>
		{groups.map((group, g) => (
			<div key={g} className="lc-recipe-editor__group">
				<TextControl
					__next40pxDefaultSize
					__nextHasNoMarginBottom
					label={__('Grupo (opcional)', 'lachinata-core')}
					placeholder={__('Para la base', 'lachinata-core')}
					value={group.title || ''}
					onChange={(title) =>
						onChange(replace(groups, g, { ...group, title }))
					}
				/>
				{(group.items || []).map((item, i) => {
					const set = (value) =>
						onChange(
							replace(groups, g, {
								...group,
								items: replace(group.items, i, value),
							})
						);
					return (
						<fieldset key={i} className="lc-recipe-editor__row">
							<legend>
								{sprintf(
									/* translators: %d: line number. */
									__('Ingrediente %d', 'lachinata-core'),
									i + 1
								)}
							</legend>
							<div className="lc-recipe-editor__cols">
								<TextControl
									__next40pxDefaultSize
									__nextHasNoMarginBottom
									label={__('Cantidad', 'lachinata-core')}
									help={__(
										'200, 1/2, 1,5…',
										'lachinata-core'
									)}
									value={item.qty}
									onChange={(qty) => set({ ...item, qty })}
								/>
								<TextControl
									__next40pxDefaultSize
									__nextHasNoMarginBottom
									label={__('Unidad', 'lachinata-core')}
									help={__(
										'g, ml, cucharada…',
										'lachinata-core'
									)}
									value={item.unit}
									onChange={(unit) => set({ ...item, unit })}
								/>
								<TextControl
									__next40pxDefaultSize
									__nextHasNoMarginBottom
									label={__('Ingrediente', 'lachinata-core')}
									value={item.name}
									onChange={(name) => set({ ...item, name })}
								/>
								<TextControl
									__next40pxDefaultSize
									__nextHasNoMarginBottom
									label={__('Nota', 'lachinata-core')}
									placeholder={__(
										'a temperatura ambiente',
										'lachinata-core'
									)}
									value={item.note}
									onChange={(note) => set({ ...item, note })}
								/>
							</div>
							<ProductPicker item={item} onChange={set} />
							<div className="lc-recipe-editor__actions">
								<Button
									variant="tertiary"
									onClick={() =>
										onChange(
											replace(groups, g, {
												...group,
												items: move(group.items, i, -1),
											})
										)
									}
								>
									{__('Subir', 'lachinata-core')}
								</Button>
								<Button
									variant="tertiary"
									isDestructive
									onClick={() =>
										onChange(
											replace(groups, g, {
												...group,
												items: group.items.filter(
													(_, j) => j !== i
												),
											})
										)
									}
								>
									{__('Quitar', 'lachinata-core')}
								</Button>
							</div>
						</fieldset>
					);
				})}
				<Button
					variant="secondary"
					onClick={() =>
						onChange(
							replace(groups, g, {
								...group,
								items: [
									...(group.items || []),
									{ ...EMPTY_ITEM },
								],
							})
						)
					}
				>
					{__('Añadir ingrediente', 'lachinata-core')}
				</Button>
			</div>
		))}
		<Button
			variant="tertiary"
			onClick={() =>
				onChange([...groups, { title: '', items: [{ ...EMPTY_ITEM }] }])
			}
		>
			{__('Añadir grupo', 'lachinata-core')}
		</Button>
	</PanelBody>
);

const Steps = ({ steps, onChange }) => (
	<PanelBody title={__('Pasos', 'lachinata-core')}>
		{steps.map((step, i) => {
			const set = (value) => onChange(replace(steps, i, value));
			return (
				<fieldset key={i} className="lc-recipe-editor__row">
					<legend>
						{sprintf(
							/* translators: %d: step number. */
							__('Paso %d', 'lachinata-core'),
							i + 1
						)}
					</legend>
					<TextareaControl
						__nextHasNoMarginBottom
						label={__('Qué se hace (una acción)', 'lachinata-core')}
						value={step.text}
						onChange={(text) => set({ ...step, text })}
					/>
					<TextControl
						__next40pxDefaultSize
						__nextHasNoMarginBottom
						type="number"
						min={0}
						label={__(
							'Tiempo del paso, en minutos (opcional)',
							'lachinata-core'
						)}
						value={step.time || ''}
						onChange={(time) =>
							set({ ...step, time: Number(time) || 0 })
						}
					/>
					<MediaUploadCheck>
						<MediaUpload
							allowedTypes={['image']}
							value={step.image || 0}
							onSelect={(media) =>
								set({
									...step,
									image: media.id,
									alt: media.alt || step.alt || '',
								})
							}
							render={({ open }) => (
								<Button variant="secondary" onClick={open}>
									{step.image
										? __(
												'Cambiar la foto',
												'lachinata-core'
											)
										: __(
												'Foto del paso (opcional)',
												'lachinata-core'
											)}
								</Button>
							)}
						/>
					</MediaUploadCheck>
					{step.image ? (
						<TextControl
							__next40pxDefaultSize
							__nextHasNoMarginBottom
							label={__(
								'Texto alternativo de la foto',
								'lachinata-core'
							)}
							value={step.alt || ''}
							onChange={(alt) => set({ ...step, alt })}
						/>
					) : null}
					<div className="lc-recipe-editor__actions">
						<Button
							variant="tertiary"
							onClick={() => onChange(move(steps, i, -1))}
						>
							{__('Subir', 'lachinata-core')}
						</Button>
						<Button
							variant="tertiary"
							isDestructive
							onClick={() =>
								onChange(steps.filter((_, j) => j !== i))
							}
						>
							{__('Quitar', 'lachinata-core')}
						</Button>
					</div>
				</fieldset>
			);
		})}
		<Button
			variant="secondary"
			onClick={() =>
				onChange([...steps, { text: '', time: 0, image: 0, alt: '' }])
			}
		>
			{__('Añadir paso', 'lachinata-core')}
		</Button>
	</PanelBody>
);

const minutes = (value) => Number(value) || 0;

const Edit = ({ attributes, setAttributes }) => {
	const recipe = attributes.recipe || {};
	const set = (changes) =>
		setAttributes({ recipe: { ...recipe, ...changes } });
	const total =
		minutes(recipe.prep) + minutes(recipe.cook) + minutes(recipe.rest);
	const lines = (value) => (value || []).join('\n');
	const split = (value) => value.split('\n');
	return (
		<div {...useBlockProps({ className: 'lc-recipe-editor' })}>
			<h2>{__('Receta', 'lachinata-core')}</h2>
			<PanelBody title={__('Datos', 'lachinata-core')}>
				<div className="lc-recipe-editor__cols">
					<TextControl
						__next40pxDefaultSize
						__nextHasNoMarginBottom
						type="number"
						min={0}
						label={__('Raciones', 'lachinata-core')}
						value={recipe.servings || ''}
						onChange={(value) =>
							set({ servings: Number(value) || 0 })
						}
					/>
					<TextControl
						__next40pxDefaultSize
						__nextHasNoMarginBottom
						type="number"
						min={0}
						label={__('Preparación (min)', 'lachinata-core')}
						value={recipe.prep || ''}
						onChange={(value) => set({ prep: minutes(value) })}
					/>
					<TextControl
						__next40pxDefaultSize
						__nextHasNoMarginBottom
						type="number"
						min={0}
						label={__('Cocción (min)', 'lachinata-core')}
						value={recipe.cook || ''}
						onChange={(value) => set({ cook: minutes(value) })}
					/>
					<TextControl
						__next40pxDefaultSize
						__nextHasNoMarginBottom
						type="number"
						min={0}
						label={__('Reposo (min)', 'lachinata-core')}
						value={recipe.rest || ''}
						onChange={(value) => set({ rest: minutes(value) })}
					/>
				</div>
				<p>
					{sprintf(
						/* translators: %d: minutes. */
						__('Total: %d min (se calcula).', 'lachinata-core'),
						total
					)}
				</p>
				<div className="lc-recipe-editor__cols">
					<SelectControl
						__next40pxDefaultSize
						__nextHasNoMarginBottom
						label={__('Dificultad', 'lachinata-core')}
						value={recipe.difficulty || ''}
						options={[
							{ value: '', label: '—' },
							...DATA.difficulties,
						]}
						onChange={(difficulty) => set({ difficulty })}
					/>
					<TextControl
						__next40pxDefaultSize
						__nextHasNoMarginBottom
						label={__('Cocina', 'lachinata-core')}
						placeholder={__('Mediterránea', 'lachinata-core')}
						value={recipe.cuisine || ''}
						onChange={(cuisine) => set({ cuisine })}
					/>
				</div>
				<p className="description">
					{__(
						'El tipo de plato es la subsección (panel Secciones). Sin nutrición ni alérgenos: no se inventan.',
						'lachinata-core'
					)}
				</p>
			</PanelBody>
			<Ingredients
				groups={recipe.groups || []}
				onChange={(groups) => set({ groups })}
			/>
			<Steps
				steps={recipe.steps || []}
				onChange={(steps) => set({ steps })}
			/>
			<PanelBody title={__('Consejos y más', 'lachinata-core')}>
				<TextareaControl
					__nextHasNoMarginBottom
					label={__('Consejos (uno por línea)', 'lachinata-core')}
					value={lines(recipe.tips)}
					onChange={(value) => set({ tips: split(value) })}
				/>
				<TextareaControl
					__nextHasNoMarginBottom
					label={__('Variantes (una por línea)', 'lachinata-core')}
					value={lines(recipe.variants)}
					onChange={(value) => set({ variants: split(value) })}
				/>
				<TextareaControl
					__nextHasNoMarginBottom
					label={__('Conservación', 'lachinata-core')}
					value={recipe.storage || ''}
					onChange={(storage) => set({ storage })}
				/>
				<TextControl
					__next40pxDefaultSize
					__nextHasNoMarginBottom
					type="url"
					label={__(
						'Vídeo (dirección https, opcional)',
						'lachinata-core'
					)}
					value={recipe.video || ''}
					onChange={(video) => set({ video })}
				/>
			</PanelBody>
		</div>
	);
};

registerBlockType(metadata.name, {
	edit: Edit,
	save: () => null,
});

const today = () => new Date().toISOString().slice(0, 10);

const EntryPanel = () => {
	const { type, meta } = useSelect(
		(select) => ({
			type: select('core/editor').getCurrentPostType(),
			meta: select('core/editor').getEditedPostAttribute('meta'),
		}),
		[]
	);
	const { editPost } = useDispatch('core/editor');
	const setMeta = (value) => editPost({ meta: value });
	const reasons = DATA.reasons || [];
	if ('post' !== type || !meta) {
		return null;
	}
	const set = (key, value) => setMeta({ ...meta, [key]: value });
	const sources = meta._lc_content_fuentes || [];
	const summary = meta._lc_content_resumen || '';
	return (
		<PluginDocumentSettingPanel
			name="lachinata-content"
			title={__('Blog y recetas', 'lachinata-core')}
		>
			{reasons.map((reason, i) => (
				<Notice key={i} status="warning" isDismissible={false}>
					{reason}
				</Notice>
			))}
			<SelectControl
				__next40pxDefaultSize
				__nextHasNoMarginBottom
				label={__('Formato', 'lachinata-core')}
				value={meta._lc_content_formato || ''}
				options={[{ value: '', label: '—' }, ...DATA.formats]}
				onChange={(value) => set('_lc_content_formato', value)}
			/>
			<TextareaControl
				__nextHasNoMarginBottom
				label={__('En pocas palabras', 'lachinata-core')}
				help={__(
					'Dos o tres frases que responden a la pregunta del título. Se ve arriba del todo y es la base de la meta descripción.',
					'lachinata-core'
				)}
				value={summary}
				onChange={(value) => set('_lc_content_resumen', value)}
			/>
			<TextControl
				__next40pxDefaultSize
				__nextHasNoMarginBottom
				type="date"
				label={__('Revisado el', 'lachinata-core')}
				help={__(
					'Solo cuando se revisa de verdad: sale como «Actualizado el…». Guardar no cuenta.',
					'lachinata-core'
				)}
				value={meta._lc_content_revisado || ''}
				onChange={(value) => set('_lc_content_revisado', value)}
			/>
			<Button
				variant="secondary"
				onClick={() => set('_lc_content_revisado', today())}
			>
				{__('Revisado hoy', 'lachinata-core')}
			</Button>
			<SelectControl
				__next40pxDefaultSize
				__nextHasNoMarginBottom
				label={__('En llms.txt', 'lachinata-core')}
				help={__(
					'Entran solas las que más clics tienen y llevan «En pocas palabras». Fijada: siempre, delante. Excluida: nunca.',
					'lachinata-core'
				)}
				value={meta._lc_content_llms || ''}
				options={[
					{
						value: '',
						label: __('Según los clics', 'lachinata-core'),
					},
					{ value: 'fijar', label: __('Fijada', 'lachinata-core') },
					{
						value: 'excluir',
						label: __('Excluida', 'lachinata-core'),
					},
				]}
				onChange={(value) => set('_lc_content_llms', value)}
			/>
			<h3>{__('Fuentes', 'lachinata-core')}</h3>
			{sources.map((source, i) => (
				<div key={i} className="lc-recipe-editor__row">
					<TextControl
						__next40pxDefaultSize
						__nextHasNoMarginBottom
						label={__('Título', 'lachinata-core')}
						value={source.title || ''}
						onChange={(title) =>
							set(
								'_lc_content_fuentes',
								replace(sources, i, { ...source, title })
							)
						}
					/>
					<TextControl
						__next40pxDefaultSize
						__nextHasNoMarginBottom
						type="url"
						label={__('Enlace', 'lachinata-core')}
						value={source.url || ''}
						onChange={(url) =>
							set(
								'_lc_content_fuentes',
								replace(sources, i, { ...source, url })
							)
						}
					/>
					<Button
						variant="tertiary"
						isDestructive
						onClick={() =>
							set(
								'_lc_content_fuentes',
								sources.filter((_, j) => j !== i)
							)
						}
					>
						{__('Quitar', 'lachinata-core')}
					</Button>
				</div>
			))}
			<Button
				variant="tertiary"
				onClick={() =>
					set('_lc_content_fuentes', [
						...sources,
						{ title: '', url: '' },
					])
				}
			>
				{__('Añadir fuente', 'lachinata-core')}
			</Button>
		</PluginDocumentSettingPanel>
	);
};

registerPlugin('lachinata-content', { render: EntryPanel });
