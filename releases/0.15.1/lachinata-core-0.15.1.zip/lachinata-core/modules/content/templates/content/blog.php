<?php
/**
 * The magazine (`/blog/`): header, chips of the sections, the newest recipe big with the
 * most read, and each section with its newest entries (Blog.dc.html, BlogDesktop.dc.html).
 *
 * The theme can override it with `lachinata/content/blog.php`.
 *
 * @package LaChinata\Core
 */

use LaChinata\Core\Modules\Content\Html;
use LaChinata\Core\Modules\Content\Magazine;
use LaChinata\Core\Modules\Content\Model;
use LaChinata\Core\Modules\Content\Query;
use LaChinata\Core\Modules\Content\Texts;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- The pieces come escaped from Html; the rest is escaped where it is printed.

$lachinata_layout = Magazine::layout();
$lachinata_lead   = Texts::blog_lead();
$lachinata_list   = static fn( string $name ): callable => static fn( WP_Post $post, int $index ): array => array(
	'data-lc-entry' => $post->ID,
	'data-lc-list'  => $name,
	'data-lc-index' => $index + 1,
);

get_header();
?>
<div class="lc-blog">
	<header class="lc-blog__hero">
		<div class="lc-container">
			<span class="eyebrow lc-blog__eyebrow"><?php echo esc_html( Texts::blog_eyebrow() ); ?></span>
			<h1 class="editorial-h1 lc-blog__title"><?php echo esc_html( Texts::blog_title() ); ?></h1>
			<?php if ( '' !== $lachinata_lead ) : ?>
				<p class="editorial-lead lc-blog__lead"><?php echo esc_html( $lachinata_lead ); ?></p>
			<?php endif; ?>
		</div>
	</header>

	<?php $lachinata_roots = Model::roots(); ?>
	<?php if ( $lachinata_roots ) : ?>
		<nav class="lc-container lc-blog__chips" aria-label="<?php esc_attr_e( 'Secciones del blog', 'lachinata-core' ); ?>">
			<div class="lc-chiprow">
				<a href="<?php echo esc_url( Query::home_url() ); ?>" class="lc-chip label lc-chip--on" aria-current="page"><?php esc_html_e( 'Todo', 'lachinata-core' ); ?></a>
				<?php foreach ( $lachinata_roots as $lachinata_root ) : ?>
					<a href="<?php echo esc_url( Query::section_url( $lachinata_root ) ); ?>" class="lc-chip label"><?php echo esc_html( $lachinata_root->name ); ?></a>
				<?php endforeach; ?>
			</div>
		</nav>
	<?php endif; ?>

	<?php if ( null !== $lachinata_layout['feature'] || $lachinata_layout['most_read'] ) : ?>
		<section class="lc-container lc-blog__top" aria-label="<?php esc_attr_e( 'Destacado', 'lachinata-core' ); ?>">
			<?php if ( null !== $lachinata_layout['feature'] ) : ?>
				<div class="lc-blog__feature"><?php echo Html::card( $lachinata_layout['feature'], 'feature', $lachinata_list( __( 'Revista: destacado', 'lachinata-core' ) )( $lachinata_layout['feature'], 0 ) ); ?></div>
			<?php endif; ?>
			<?php if ( $lachinata_layout['most_read'] ) : ?>
				<div class="lc-blog__most">
					<h2 class="h3 lc-blog__most-title"><?php esc_html_e( 'Lo más leído', 'lachinata-core' ); ?></h2>
					<?php foreach ( $lachinata_layout['most_read'] as $lachinata_index => $lachinata_post ) : ?>
						<?php echo Html::card( $lachinata_post, 'horizontal', $lachinata_list( __( 'Lo más leído', 'lachinata-core' ) )( $lachinata_post, $lachinata_index ) ); ?>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</section>
	<?php endif; ?>

	<div class="lc-blog__sections">
		<?php foreach ( $lachinata_layout['sections'] as $lachinata_block ) : ?>
			<?php
			$lachinata_section = $lachinata_block['section'];
			$lachinata_id      = 'lc-blog-' . $lachinata_section->slug;
			$lachinata_more    = $lachinata_block['recipes'] && $lachinata_block['count'] > 0
				/* translators: %s: number of recipes. */
				? sprintf( __( 'Ver las %s', 'lachinata-core' ), number_format_i18n( $lachinata_block['count'] ) )
				: __( 'Ver todo', 'lachinata-core' );
			$lachinata_text = trim( wp_strip_all_tags( $lachinata_section->description ) );
			?>
			<section class="lc-blog__section<?php echo $lachinata_block['recipes'] ? ' lc-blog__section--recipes' : ''; ?>" aria-labelledby="<?php echo esc_attr( $lachinata_id ); ?>">
				<div class="lc-container">
					<div class="lc-section">
						<div class="lc-section__titles">
							<h2 class="h2" id="<?php echo esc_attr( $lachinata_id ); ?>"><?php echo esc_html( $lachinata_section->name ); ?></h2>
							<?php if ( '' !== $lachinata_text ) : ?>
								<p class="body-sm lc-section__text"><?php echo esc_html( $lachinata_text ); ?></p>
							<?php endif; ?>
						</div>
						<a href="<?php echo esc_url( Query::section_url( $lachinata_section ) ); ?>" class="lc-section__more label"><?php echo esc_html( $lachinata_more ); ?><?php echo Html::icon( 'arrow-right', true ); ?></a>
					</div>
					<div class="<?php echo $lachinata_block['recipes'] ? 'lc-blog__grid' : 'lc-blog__list'; ?>">
						<?php foreach ( $lachinata_block['posts'] as $lachinata_index => $lachinata_post ) : ?>
							<?php echo Html::card( $lachinata_post, $lachinata_block['recipes'] ? 'vertical' : 'horizontal', $lachinata_list( $lachinata_section->name )( $lachinata_post, $lachinata_index ) ); ?>
						<?php endforeach; ?>
					</div>
				</div>
			</section>
		<?php endforeach; ?>
	</div>
</div>
<?php
get_footer();
