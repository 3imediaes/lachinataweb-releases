<?php
/**
 * A section (`/blog/{section}/`, a subsection of the recipes) or a topic
 * (`/blog/tema/{slug}/`): header with its own text, the subsections that have a page,
 * the grid and «Cargar más» (a link to the next page without JavaScript). Filtered by
 * product (`?producto=`), it says so and offers to see them all.
 *
 * The theme can override it with `lachinata/content/section.php`.
 *
 * @package LaChinata\Core
 */

use LaChinata\Core\Modules\Content\Html;
use LaChinata\Core\Modules\Content\Model;
use LaChinata\Core\Modules\Content\Pages;
use LaChinata\Core\Modules\Content\Query;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- The pieces come escaped from Html; the rest is escaped where it is printed.

$lachinata_term    = get_queried_object();
$lachinata_term    = $lachinata_term instanceof WP_Term ? $lachinata_term : null;
$lachinata_product = Pages::product_filter();
$lachinata_text    = null === $lachinata_term ? '' : trim( (string) term_description( $lachinata_term->term_id ) );
$lachinata_subs    = array();
if ( null !== $lachinata_term && Model::SECTION === $lachinata_term->taxonomy ) {
	$lachinata_parent = $lachinata_term->parent ? get_term( $lachinata_term->parent, Model::SECTION ) : $lachinata_term;
	$lachinata_parent = $lachinata_parent instanceof WP_Term ? $lachinata_parent : $lachinata_term;
	$lachinata_kids   = get_terms(
		array(
			'taxonomy'   => Model::SECTION,
			'parent'     => $lachinata_parent->term_id,
			'hide_empty' => true,
		)
	);
	foreach ( is_array( $lachinata_kids ) ? $lachinata_kids : array() as $lachinata_kid ) {
		if ( $lachinata_kid instanceof WP_Term && Query::has_page( $lachinata_kid ) ) {
			$lachinata_subs[] = $lachinata_kid;
		}
	}
	if ( $lachinata_subs ) {
		array_unshift( $lachinata_subs, $lachinata_parent );
	}
}
$lachinata_title = null === $lachinata_term ? '' : $lachinata_term->name;
$lachinata_list  = null === $lachinata_term ? '' : $lachinata_term->name;

get_header();
?>
<div class="lc-blog lc-blog--section">
	<header class="lc-blog__hero">
		<div class="lc-container">
			<?php get_template_part( 'template-parts/breadcrumb' ); ?>
			<h1 class="editorial-h1 lc-blog__title"><?php echo esc_html( $lachinata_title ); ?></h1>
			<?php if ( '' !== $lachinata_text ) : ?>
				<div class="body lc-blog__lead"><?php echo wp_kses_post( $lachinata_text ); ?></div>
			<?php endif; ?>
		</div>
	</header>

	<?php if ( $lachinata_subs ) : ?>
		<nav class="lc-container lc-blog__chips" aria-label="<?php esc_attr_e( 'Tipos de plato', 'lachinata-core' ); ?>">
			<div class="lc-chiprow">
				<?php foreach ( $lachinata_subs as $lachinata_index => $lachinata_sub ) : ?>
					<?php $lachinata_on = $lachinata_sub->term_id === $lachinata_term->term_id; ?>
					<a href="<?php echo esc_url( Query::section_url( $lachinata_sub ) ); ?>" class="lc-chip label<?php echo $lachinata_on ? ' lc-chip--on' : ''; ?>"<?php echo $lachinata_on ? ' aria-current="page"' : ''; ?>><?php echo esc_html( 0 === $lachinata_index ? __( 'Todas', 'lachinata-core' ) : $lachinata_sub->name ); ?></a>
				<?php endforeach; ?>
			</div>
		</nav>
	<?php endif; ?>

	<div class="lc-container lc-blog__results">
		<?php if ( null !== $lachinata_product && null !== $lachinata_term ) : ?>
			<?php
			$lachinata_all = get_term_link( $lachinata_term );
			echo Html::notice(
				sprintf(
					/* translators: 1: product name, 2: link «Ver todas». */
					esc_html__( 'Recetas con %1$s. %2$s', 'lachinata-core' ),
					'<strong>' . esc_html( $lachinata_product->get_name() ) . '</strong>',
					is_string( $lachinata_all ) ? '<a href="' . esc_url( $lachinata_all ) . '">' . esc_html__( 'Ver todas las recetas', 'lachinata-core' ) . '</a>' : ''
				),
				'info',
				'leaf'
			);
			?>
		<?php endif; ?>

		<?php if ( have_posts() ) : ?>
			<div class="lc-blog__grid" data-lc-grid>
				<?php
				$lachinata_index = (int) max( 0, ( (int) get_query_var( 'paged' ) - 1 ) * Pages::PAGE_SIZE );
				while ( have_posts() ) :
					the_post();
					$lachinata_post = get_post();
					if ( $lachinata_post instanceof WP_Post ) {
						echo Html::card(
							$lachinata_post,
							'vertical',
							array(
								'data-lc-entry' => $lachinata_post->ID,
								'data-lc-list'  => $lachinata_list,
								'data-lc-index' => ++$lachinata_index,
							)
						);
					}
				endwhile;
				?>
			</div>
			<?php $lachinata_next = get_next_posts_page_link(); ?>
			<?php if ( $GLOBALS['wp_query']->max_num_pages > max( 1, (int) get_query_var( 'paged' ) ) && $lachinata_next ) : ?>
				<p class="lc-blog__more">
					<?php
					echo Html::button(
						__( 'Cargar más', 'lachinata-core' ),
						array(
							'variant' => 'secondary',
							'href'    => $lachinata_next,
							'attrs'   => array( 'data-lc-more' => '' ),
						)
					);
					?>
				</p>
			<?php endif; ?>
		<?php else : ?>
			<p class="body lc-blog__empty"><?php esc_html_e( 'Todavía no hay nada aquí.', 'lachinata-core' ); ?></p>
		<?php endif; ?>
	</div>
</div>
<?php
get_footer();
