<?php
/**
 * Delivery dates on the product page, the order confirmation and the emails.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Eta;

use LaChinata\Core\Shipping\Destination;
use LaChinata\Core\Delivery\Format;
use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * Product page: the server prints the date for the visitor's destination (no countdown,
 * the page may be cached) and a small script refreshes it from the REST endpoint, adding
 * the countdown to the cut-off once the answer arrives. If the request fails, the
 * server's date stays.
 */
final class Storefront {

	/**
	 * Script handle.
	 */
	public const SCRIPT = 'lachinata-eta';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/product/availability', array( self::class, 'availability' ), 10, 2 );
		Hooks::add_filter( 'lachinata/thankyou/delivery', array( self::class, 'thankyou' ), 10, 2 );
		Hooks::add_action( 'woocommerce_email_after_order_table', array( self::class, 'email' ), 5, 3 );
		Hooks::add_filter( 'lachinata/catalog/marker_conditions', array( self::class, 'marker_conditions' ), 20, 2 );
	}

	/**
	 * The days a shipping class leaves or is delivered, for its notice on the product page
	 * («Sale de lunes a miércoles.»), from the rules of the class.
	 *
	 * @param string[]|mixed $sentences Sentences so far.
	 * @param string|mixed   $slug      Shipping class slug.
	 * @return string[]|mixed
	 */
	public static function marker_conditions( $sentences, $slug ) {
		if ( ! is_array( $sentences ) || '' === (string) $slug ) {
			return $sentences;
		}
		$rule = Estimator::config()->rules_for( array( (string) $slug ) );
		if ( null === $rule ) {
			return $sentences;
		}
		if ( null !== $rule['ship_days'] ) {
			/* translators: %s: weekdays («de lunes a miércoles», «en lunes o jueves»). */
			$sentences[] = sprintf( __( 'Sale %s.', 'lachinata-core' ), self::weekdays( $rule['ship_days'] ) );
		}
		if ( null !== $rule['delivery_days'] ) {
			/* translators: %s: weekdays («en viernes», «de martes a jueves»). */
			$sentences[] = sprintf( __( 'Se entrega %s.', 'lachinata-core' ), self::weekdays( $rule['delivery_days'] ) );
		}
		return $sentences;
	}

	/**
	 * Weekdays as people say them: «de lunes a miércoles» for three or more in a row, «en
	 * lunes o jueves» otherwise.
	 *
	 * @param int[] $days ISO weekdays (1 Monday … 7 Sunday).
	 */
	public static function weekdays( array $days ): string {
		global $wp_locale;
		$days = array_values( array_unique( array_map( 'intval', $days ) ) );
		sort( $days );
		$name = static fn( int $day ): string => (string) $wp_locale->get_weekday( $day % 7 );
		if ( count( $days ) >= 3 && count( $days ) - 1 === end( $days ) - $days[0] ) {
			/* translators: 1: first weekday, 2: last weekday. */
			return sprintf( __( 'de %1$s a %2$s', 'lachinata-core' ), $name( $days[0] ), $name( (int) end( $days ) ) );
		}
		$names = array_map( $name, $days );
		$last  = array_pop( $names );
		return $names
			/* translators: 1: weekdays separated by commas, 2: the last one. */
			? sprintf( __( 'en %1$s o %2$s', 'lachinata-core' ), implode( ', ', $names ), $last )
			/* translators: %s: weekday. */
			: sprintf( __( 'en %s', 'lachinata-core' ), $last );
	}

	/**
	 * Adds the delivery sentence after the stock line.
	 *
	 * @param array{tone: string, text: string} $availability Tone and sentence.
	 * @param \WC_Product                       $product      Product.
	 * @return array{tone: string, text: string}
	 */
	public static function availability( array $availability, \WC_Product $product ): array {
		if ( ! $product->is_in_stock() || ! $product->is_purchasable() ) {
			return $availability;
		}
		$estimate = Estimator::for_product( $product, Destination::visitor() );
		if ( null === $estimate ) {
			return $availability;
		}
		$sentence             = Format::product( $estimate );
		$availability['text'] = rtrim( (string) $availability['text'], '. ' ) . '. ' . $sentence;
		self::enqueue( $product, $sentence );
		return $availability;
	}

	/**
	 * Loads the refresh script with what it needs.
	 *
	 * @param \WC_Product $product  Product.
	 * @param string      $sentence Sentence printed by the server.
	 */
	private static function enqueue( \WC_Product $product, string $sentence ): void {
		wp_enqueue_script(
			self::SCRIPT,
			plugins_url( 'assets/eta.js', __FILE__ ),
			array( 'wp-i18n' ),
			LACHINATA_CORE_VERSION,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
		wp_set_script_translations( self::SCRIPT, 'lachinata-core', LACHINATA_CORE_DIR . '/languages' );
		wp_add_inline_script(
			self::SCRIPT,
			'window.lachinataEta = ' . wp_json_encode(
				array(
					'endpoint' => rest_url( Rest::NAMESPACE . Rest::ROUTE ),
					'product'  => $product->get_id(),
					'sentence' => $sentence,
				)
			) . ';',
			'before'
		);
	}

	/**
	 * Headline of the delivery block on the order received page: «Llega jue 24 – vie 25 oct».
	 *
	 * @param string    $title Current headline (the shipping method).
	 * @param \WC_Order $order Order.
	 */
	public static function thankyou( string $title, \WC_Order $order ): string {
		$estimate = Rates::of_order( $order );
		return null === $estimate ? $title : Format::range( $estimate );
	}

	/**
	 * Line in the plain text customer emails, after the order table. The HTML emails of the
	 * theme's frame carry the dates in their key facts (Emails).
	 *
	 * @param \WC_Order $order         Order.
	 * @param bool      $sent_to_admin Whether it goes to the store.
	 * @param bool      $plain_text    Plain text email.
	 */
	public static function email( \WC_Order $order, bool $sent_to_admin, bool $plain_text ): void {
		$estimate = Rates::of_order( $order );
		if ( $sent_to_admin || ! $plain_text || null === $estimate ) {
			return;
		}
		echo "\n" . esc_html( Format::order( $estimate ) ) . "\n\n";
	}
}
