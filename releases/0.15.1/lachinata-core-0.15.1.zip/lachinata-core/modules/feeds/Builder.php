<?php
/**
 * Writes a feed.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Feeds;

use LaChinata\Core\Company;
use LaChinata\Core\Services;

defined( 'ABSPATH' ) || exit;

/**
 * Goes through the catalogue in pages and writes the RSS 2.0 of a feed, streamed to a
 * temporary file that replaces the old one at the end. Each item is kept in a cache next to
 * the feed (`<id>.cache.json`), so a partial generation (some products changed) rebuilds
 * only those and copies the rest. The full one, daily, rebuilds everything.
 *
 * @phpstan-import-type Feed from Feeds
 * @phpstan-import-type State from Feeds
 */
final class Builder {

	/**
	 * Products read per query.
	 */
	private const PAGE = 100;

	/**
	 * Left-out products and notices kept in the state (the rest are only counted).
	 */
	private const KEEP = 200;

	/**
	 * Generates a feed.
	 *
	 * @param array<string, string> $feed   Feed.
	 * @param int[]|null            $dirty  Product ids that changed (partial generation), or null for all.
	 * @param int                   $sample Stop after this many items (0: all). A sample does not touch the state or the cache.
	 * @param string                $output Write here instead of the feed's file (with a sample).
	 * @return State|\WP_Error
	 */
	public static function generate( array $feed, ?array $dirty = null, int $sample = 0, string $output = '' ) {
		$started = microtime( true );
		$lock    = 'lachinata_feeds_lock_' . $feed['id'];
		if ( '' === $output && get_transient( $lock ) ) {
			return new \WP_Error( 'lachinata_feeds_running', __( 'Ese feed se está generando ahora.', 'lachinata-core' ) );
		}
		if ( '' === $output ) {
			set_transient( $lock, 1, 10 * MINUTE_IN_SECONDS );
		}
		// Texts, attributes and links in the language of the feed (`translate`).
		Services::languages()->switch_to( (string) ( $feed['language'] ?? '' ) );
		try {
			return self::run( $feed, $dirty, $sample, $output, $started );
		} finally {
			Services::languages()->restore();
			if ( '' === $output ) {
				delete_transient( $lock );
			}
		}
	}

	/**
	 * The generation itself.
	 *
	 * @param array<string, string> $feed    Feed.
	 * @param int[]|null            $dirty   Changed products, or null.
	 * @param int                   $sample  Items of a sample.
	 * @param string                $output  Path of a sample.
	 * @param float                 $started Start time.
	 * @return State|\WP_Error
	 */
	private static function run( array $feed, ?array $dirty, int $sample, string $output, float $started ) {
		if ( '' !== $output ) {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- streamed sample file.
			$handle = fopen( $output, 'wb' );
			$handle = false === $handle ? null : $handle;
		} else {
			$handle = Files::open( $feed );
		}
		if ( null === $handle ) {
			FeedsModule::gaps()->record( 'write:' . $feed['id'], __( 'No se pudo escribir el archivo del feed: revisa los permisos de wp-content/uploads.', 'lachinata-core' ) );
			return new \WP_Error( 'lachinata_feeds_write', __( 'No se pudo escribir el archivo del feed.', 'lachinata-core' ) );
		}

		$cache_file = Files::path( $feed ) . '.cache.json';
		$cache      = array();
		if ( null !== $dirty && '' === $output && file_exists( $cache_file ) ) {
			$cache = json_decode( (string) file_get_contents( $cache_file ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local cache file.
			$cache = is_array( $cache ) ? $cache : array();
		}
		$dirty    = null === $dirty ? null : array_map( 'intval', $dirty );
		$excluded = self::excluded_categories();
		$catalog  = array( 'bestsellers' => self::bestsellers() );
		$fresh    = array();
		$state    = array(
			'at'            => time(),
			'items'         => 0,
			'excluded'      => 0,
			'warnings'      => 0,
			'bytes'         => 0,
			'seconds'       => 0.0,
			'excluded_list' => array(),
			'notices'       => array(),
		);

		fwrite( $handle, self::head( $feed ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite -- streamed.
		$page = 1;
		do {
			$ids = wc_get_products(
				array(
					'status'  => 'publish',
					'type'    => array( 'simple', 'variable' ),
					'limit'   => self::PAGE,
					'page'    => $page,
					'orderby' => 'ID',
					'order'   => 'ASC',
					'return'  => 'ids',
				)
			);
			$ids = is_array( $ids ) ? $ids : array();
			foreach ( $ids as $id ) {
				$product = wc_get_product( (int) $id );
				if ( ! $product instanceof \WC_Product ) {
					continue;
				}
				$items = $product->is_type( 'variable' ) ? array_map( 'intval', $product->get_children() ) : array( (int) $id );
				foreach ( $items as $item_id ) {
					$key   = (string) $item_id;
					$entry = null;
					if ( null !== $dirty && isset( $cache[ $key ] ) && ! in_array( $item_id, $dirty, true ) && ! in_array( (int) $id, $dirty, true ) ) {
						$entry = $cache[ $key ];
					}
					if ( null === $entry ) {
						$item  = (int) $id === $item_id ? $product : wc_get_product( $item_id );
						$entry = $item instanceof \WC_Product ? self::entry( $item, $feed, $excluded, $catalog ) : null;
					}
					if ( null === $entry ) {
						continue;
					}
					$fresh[ $key ] = $entry;
					if ( '' !== $entry['r'] ) {
						++$state['excluded'];
						if ( count( $state['excluded_list'] ) < self::KEEP ) {
							$state['excluded_list'][] = array(
								'id'     => $item_id,
								'name'   => (string) $entry['name'],
								'reason' => (string) $entry['r'],
							);
						}
						continue;
					}
					fwrite( $handle, (string) $entry['x'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite -- streamed.
					++$state['items'];
					foreach ( (array) $entry['n'] as $notice ) {
						++$state['warnings'];
						if ( count( $state['notices'] ) < self::KEEP ) {
							$state['notices'][] = array(
								'id'     => $item_id,
								'name'   => (string) $entry['name'],
								'notice' => (string) $notice,
							);
						}
					}
					if ( $sample > 0 && $state['items'] >= $sample ) {
						break 3;
					}
				}
			}
			++$page;
			$full = count( $ids ) === self::PAGE;
		} while ( $full );
		fwrite( $handle, "</channel>\n</rss>\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite -- streamed.

		if ( '' !== $output ) {
			fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- streamed.
			$state['bytes']   = (int) filesize( $output );
			$state['seconds'] = round( microtime( true ) - $started, 2 );
			return $state;
		}
		if ( ! Files::commit( $feed, $handle ) ) {
			FeedsModule::gaps()->record( 'write:' . $feed['id'], __( 'No se pudo sustituir el archivo del feed.', 'lachinata-core' ) );
			return new \WP_Error( 'lachinata_feeds_write', __( 'No se pudo sustituir el archivo del feed.', 'lachinata-core' ) );
		}
		file_put_contents( $cache_file, (string) wp_json_encode( $fresh ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- local cache file.
		$state['bytes']   = (int) filesize( Files::path( $feed ) );
		$state['seconds'] = round( microtime( true ) - $started, 2 );
		Feeds::save_state( $feed['id'], $state );
		return $state;
	}

	/**
	 * One product of the feed: its XML or why it is left out, and its notices.
	 *
	 * @param \WC_Product           $product  Product or variation.
	 * @param array<string, string> $feed     Feed.
	 * @param int[]                 $excluded Excluded categories.
	 * @param array<string, mixed>  $catalog  Shared data.
	 * @return array{x: string, r: string, n: string[], name: string}
	 */
	public static function entry( \WC_Product $product, array $feed, array $excluded, array $catalog ): array {
		$name   = wp_strip_all_tags( $product->get_name() );
		$reason = Item::reason( $product, $excluded, (string) ( $feed['language'] ?? '' ) );
		if ( '' !== $reason ) {
			return array(
				'x'    => '',
				'r'    => $reason,
				'n'    => array(),
				'name' => $name,
			);
		}
		$built = Item::build( $product, $feed, $catalog );
		$xml   = "<item>\n";
		foreach ( $built['fields'] as $field ) {
			$xml .= sprintf( "\t<%1\$s>%2\$s</%1\$s>\n", $field[0], self::escape( $field[1] ) );
		}
		$xml .= "</item>\n";
		return array(
			'x'    => $xml,
			'r'    => '',
			'n'    => $built['notices'],
			'name' => $name,
		);
	}

	/**
	 * Start of the RSS.
	 *
	 * @param array<string, string> $feed Feed.
	 */
	private static function head( array $feed ): string {
		return sprintf(
			"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<rss version=\"2.0\" xmlns:g=\"http://base.google.com/ns/1.0\">\n<channel>\n<title>%1\$s</title>\n<link>%2\$s</link>\n<description>%3\$s</description>\n",
			self::escape( Company::trade_name() . ' · ' . Feeds::label( $feed ) ),
			self::escape( Services::languages()->url( home_url( '/' ), $feed['language'] ) ),
			self::escape( html_entity_decode( (string) get_bloginfo( 'description' ) ) )
		);
	}

	/**
	 * Text for XML: escaped, without the control characters XML forbids.
	 *
	 * @param string $text Text.
	 */
	public static function escape( string $text ): string {
		$text = (string) preg_replace( '/[^\x{9}\x{A}\x{D}\x{20}-\x{D7FF}\x{E000}-\x{FFFD}]/u', '', $text );
		return htmlspecialchars( $text, ENT_XML1 | ENT_QUOTES, 'UTF-8' );
	}

	/**
	 * Excluded categories with all their subcategories.
	 *
	 * @return int[]
	 */
	public static function excluded_categories(): array {
		$out = array();
		foreach ( (array) FeedsModule::setting( 'exclude_categories' ) as $id ) {
			$id = (int) $id;
			if ( $id <= 0 ) {
				continue;
			}
			$out[] = $id;
			$kids  = get_term_children( $id, 'product_cat' );
			if ( is_array( $kids ) ) {
				$out = array_merge( $out, array_map( 'intval', $kids ) );
			}
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * The best sellers of the shop (for a custom label).
	 *
	 * @return int[]
	 */
	private static function bestsellers(): array {
		$limit = max( 0, (int) FeedsModule::setting( 'bestsellers' ) );
		if ( 0 === $limit || ! in_array( 'bestseller', (array) FeedsModule::setting( 'labels' ), true ) ) {
			return array();
		}
		$ids = wc_get_products(
			array(
				'status'  => 'publish',
				'limit'   => $limit,
				'orderby' => 'popularity',
				'order'   => 'DESC',
				'return'  => 'ids',
			)
		);
		return is_array( $ids ) ? array_map( 'intval', $ids ) : array();
	}
}
