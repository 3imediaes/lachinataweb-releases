<?php
/**
 * `wp lachinata feeds`.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Feeds;

defined( 'ABSPATH' ) || exit;

/**
 * The feeds from the command line.
 */
final class Cli {

	/**
	 * Lists the feeds with their URL and last generation.
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata feeds list
	 *
	 * @subcommand list
	 *
	 * @param array<int, string>         $args       Positional arguments.
	 * @param array<string, string|bool> $assoc_args Flags.
	 */
	public function list_( array $args, array $assoc_args ): void {
		unset( $args, $assoc_args );
		$rows = array();
		foreach ( Feeds::all() as $feed ) {
			$state  = Feeds::state( $feed['id'] );
			$rows[] = array(
				'id'        => $feed['id'],
				'url'       => Files::url( $feed ),
				'generado'  => null === $state ? '—' : wp_date( 'Y-m-d H:i', (int) $state['at'] ),
				'items'     => null === $state ? 0 : (int) $state['items'],
				'excluidos' => null === $state ? 0 : (int) $state['excluded'],
				'avisos'    => null === $state ? 0 : (int) $state['warnings'],
			);
		}
		\WP_CLI\Utils\format_items( 'table', $rows, array( 'id', 'url', 'generado', 'items', 'excluidos', 'avisos' ) );
	}

	/**
	 * Adds a feed.
	 *
	 * ## OPTIONS
	 *
	 * --destination=<destination>
	 * : google or meta.
	 *
	 * [--language=<locale>]
	 * : One of the shop's languages. Default: the site's.
	 *
	 * [--country=<country>]
	 * : Country code. Default: the shop's.
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata feeds add --destination=google
	 *
	 * @param array<int, string>         $args       Positional arguments.
	 * @param array<string, string|bool> $assoc_args Flags.
	 */
	public function add( array $args, array $assoc_args ): void {
		unset( $args );
		$errors = Feeds::add(
			array(
				'destination' => (string) ( $assoc_args['destination'] ?? '' ),
				'language'    => (string) ( $assoc_args['language'] ?? \LaChinata\Core\Services::languages()->default_language() ),
				'country'     => (string) ( $assoc_args['country'] ?? WC()->countries->get_base_country() ),
			)
		);
		if ( $errors ) {
			\WP_CLI::error( implode( ' ', $errors ) );
		}
		\WP_CLI::success( __( 'Feed añadido. Genéralo con wp lachinata feeds generate.', 'lachinata-core' ) );
	}

	/**
	 * Generates the feeds now (or a sample to a file).
	 *
	 * ## OPTIONS
	 *
	 * [--feed=<id>]
	 * : Only this feed.
	 *
	 * [--sample=<items>]
	 * : Only this many products, to --output (the feed's file and state stay as they are).
	 *
	 * [--output=<path>]
	 * : File of the sample.
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata feeds generate
	 *     wp lachinata feeds generate --feed=google-es_ES-ES --sample=10 --output=dist/feed-ejemplo.xml
	 *
	 * @param array<int, string>         $args       Positional arguments.
	 * @param array<string, string|bool> $assoc_args Flags.
	 */
	public function generate( array $args, array $assoc_args ): void {
		unset( $args );
		$only   = (string) ( $assoc_args['feed'] ?? '' );
		$sample = (int) ( $assoc_args['sample'] ?? 0 );
		$output = (string) ( $assoc_args['output'] ?? '' );
		if ( $sample > 0 && '' === $output ) {
			\WP_CLI::error( __( 'Una muestra necesita --output.', 'lachinata-core' ) );
		}
		foreach ( Feeds::all() as $feed ) {
			if ( '' !== $only && $feed['id'] !== $only ) {
				continue;
			}
			$result = Builder::generate( $feed, null, $sample, $output );
			if ( is_wp_error( $result ) ) {
				\WP_CLI::warning( $feed['id'] . ': ' . $result->get_error_message() );
				continue;
			}
			/* translators: 1: feed, 2: items, 3: left out, 4: notices, 5: seconds. */
			\WP_CLI::success( sprintf( __( '%1$s: %2$d productos, %3$d excluidos, %4$d avisos (%5$s s).', 'lachinata-core' ), $feed['id'], $result['items'], $result['excluded'], $result['warnings'], $result['seconds'] ) );
			if ( $sample > 0 ) {
				return;
			}
		}
	}
}
