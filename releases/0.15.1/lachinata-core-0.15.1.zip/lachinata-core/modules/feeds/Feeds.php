<?php
/**
 * The feeds of the shop.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Feeds;

use LaChinata\Core\Services;

defined( 'ABSPATH' ) || exit;

/**
 * Each feed: a destination (google, meta), a language (one of Contracts\Languages), a
 * country and the currency of the shop, with a random segment of its public URL
 * (`uploads/lachinata-feeds/<segment>/<id>.xml`). Its last generation is kept apart.
 *
 * @phpstan-type Feed array{id: string, destination: string, language: string, country: string, currency: string, segment: string}
 * @phpstan-type State array{at: int, items: int, excluded: int, warnings: int, bytes: int, seconds: float, excluded_list: list<array{id: int, name: string, reason: string}>, notices: list<array{id: int, name: string, notice: string}>}
 */
final class Feeds {

	/**
	 * Option with the feeds.
	 */
	public const OPTION = 'lachinata_feeds_feeds';

	/**
	 * Option with the last generation of each feed.
	 */
	public const STATE = 'lachinata_feeds_state';

	/**
	 * Destinations.
	 */
	public const DESTINATIONS = array( 'google', 'meta' );

	/**
	 * The feeds.
	 *
	 * @return list<Feed>
	 */
	public static function all(): array {
		$saved = get_option( self::OPTION, array() );
		$out   = array();
		foreach ( is_array( $saved ) ? $saved : array() as $feed ) {
			if ( is_array( $feed ) && array() === self::validate( $feed ) && preg_match( '/^[a-f0-9]{32}$/', (string) ( $feed['segment'] ?? '' ) ) ) {
				$out[] = array(
					'id'          => self::id( $feed ),
					'destination' => (string) $feed['destination'],
					'language'    => (string) $feed['language'],
					'country'     => (string) $feed['country'],
					'currency'    => (string) $feed['currency'],
					'segment'     => (string) $feed['segment'],
				);
			}
		}
		return $out;
	}

	/**
	 * A feed by id.
	 *
	 * @param string $id Feed id.
	 * @return Feed|null
	 */
	public static function get( string $id ): ?array {
		foreach ( self::all() as $feed ) {
			if ( $feed['id'] === $id ) {
				return $feed;
			}
		}
		return null;
	}

	/**
	 * Id of a feed: destination, language and country («google-es_ES-ES»).
	 *
	 * @param array<string, mixed> $feed Feed.
	 */
	public static function id( array $feed ): string {
		return sanitize_key( (string) ( $feed['destination'] ?? '' ) ) . '-' . preg_replace( '/[^A-Za-z_]/', '', (string) ( $feed['language'] ?? '' ) ) . '-' . preg_replace( '/[^A-Z]/', '', (string) ( $feed['country'] ?? '' ) );
	}

	/**
	 * Name of a feed for people («Google · Español · España»).
	 *
	 * @param array<string, mixed> $feed Feed.
	 */
	public static function label( array $feed ): string {
		$countries = function_exists( 'WC' ) && WC()->countries ? WC()->countries->get_countries() : array();
		return sprintf(
			'%1$s · %2$s · %3$s',
			'meta' === ( $feed['destination'] ?? '' ) ? 'Meta' : 'Google',
			Services::languages()->label( (string) ( $feed['language'] ?? '' ) ),
			html_entity_decode( (string) ( $countries[ $feed['country'] ?? '' ] ?? ( $feed['country'] ?? '' ) ) )
		);
	}

	/**
	 * Problems of a feed definition. Empty when it can be saved.
	 *
	 * @param array<mixed> $feed Feed.
	 * @return string[]
	 */
	public static function validate( array $feed ): array {
		$errors = array();
		if ( ! in_array( $feed['destination'] ?? '', self::DESTINATIONS, true ) ) {
			$errors[] = __( 'El destino es Google o Meta.', 'lachinata-core' );
		}
		if ( ! in_array( $feed['language'] ?? '', Services::languages()->languages(), true ) ) {
			$errors[] = __( 'Ese idioma no es de esta tienda.', 'lachinata-core' );
		}
		$countries = function_exists( 'WC' ) && WC()->countries ? WC()->countries->get_countries() : array();
		if ( ! is_string( $feed['country'] ?? null ) || ( $countries && ! isset( $countries[ $feed['country'] ] ) ) ) {
			$errors[] = __( 'Elige un país de la lista.', 'lachinata-core' );
		}
		if ( ( $feed['currency'] ?? '' ) !== get_woocommerce_currency() ) {
			/* translators: %s: currency of the shop. */
			$errors[] = sprintf( __( 'La moneda de un feed es la de la tienda (%s): los precios salen de WooCommerce.', 'lachinata-core' ), get_woocommerce_currency() );
		}
		return $errors;
	}

	/**
	 * Adds a feed (its random segment is created here).
	 *
	 * @param array{destination: string, language: string, country: string} $feed Feed.
	 * @return string[] Errors; nothing is saved when there are any.
	 */
	public static function add( array $feed ): array {
		$feed['currency'] = get_woocommerce_currency();
		$errors           = self::validate( $feed );
		if ( ! $errors && null !== self::get( self::id( $feed ) ) ) {
			$errors[] = __( 'Ya hay un feed con ese destino, idioma y país.', 'lachinata-core' );
		}
		if ( $errors ) {
			return $errors;
		}
		$all   = self::all();
		$all[] = array(
			'id'          => self::id( $feed ),
			'destination' => $feed['destination'],
			'language'    => $feed['language'],
			'country'     => $feed['country'],
			'currency'    => $feed['currency'],
			'segment'     => self::segment(),
		);
		update_option( self::OPTION, $all, false );
		return array();
	}

	/**
	 * Removes a feed and its file.
	 *
	 * @param string $id Feed id.
	 */
	public static function remove( string $id ): void {
		$feed = self::get( $id );
		if ( null === $feed ) {
			return;
		}
		Files::delete( $feed );
		update_option( self::OPTION, array_values( array_filter( self::all(), static fn( array $item ): bool => $item['id'] !== $id ) ), false );
		$state = self::states();
		unset( $state[ $id ] );
		update_option( self::STATE, $state, false );
	}

	/**
	 * Replaces the feeds with imported ones: the ones that already exist keep their URL.
	 *
	 * @param array<int, array<string, mixed>> $feeds Feeds.
	 */
	public static function replace( array $feeds ): void {
		$current = array();
		foreach ( self::all() as $feed ) {
			$current[ $feed['id'] ] = $feed;
		}
		$out = array();
		foreach ( $feeds as $feed ) {
			$feed['currency'] = get_woocommerce_currency();
			if ( self::validate( $feed ) ) {
				continue;
			}
			$id         = self::id( $feed );
			$out[ $id ] = array(
				'id'          => $id,
				'destination' => (string) $feed['destination'],
				'language'    => (string) $feed['language'],
				'country'     => (string) $feed['country'],
				'currency'    => (string) $feed['currency'],
				'segment'     => $current[ $id ]['segment'] ?? self::segment(),
			);
		}
		foreach ( array_diff_key( $current, $out ) as $gone ) {
			self::remove( $gone['id'] );
		}
		update_option( self::OPTION, array_values( $out ), false );
	}

	/**
	 * A new random segment for a public URL.
	 */
	private static function segment(): string {
		return bin2hex( random_bytes( 16 ) );
	}

	/**
	 * The last generation of every feed.
	 *
	 * @return array<string, State>
	 */
	public static function states(): array {
		$saved = get_option( self::STATE, array() );
		return is_array( $saved ) ? $saved : array();
	}

	/**
	 * The last generation of a feed, or null.
	 *
	 * @param string $id Feed id.
	 * @return State|null
	 */
	public static function state( string $id ): ?array {
		return self::states()[ $id ] ?? null;
	}

	/**
	 * Saves the last generation of a feed.
	 *
	 * @param string               $id    Feed id.
	 * @param array<string, mixed> $state Generation.
	 */
	public static function save_state( string $id, array $state ): void {
		$all        = self::states();
		$all[ $id ] = $state;
		update_option( self::STATE, $all, false );
	}
}
