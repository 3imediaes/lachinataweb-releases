<?php
/**
 * Module `feeds`: product feeds for Google Merchant Center and Meta's catalog.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Feeds;

use LaChinata\Core\GapLog;
use LaChinata\Core\Module;
use LaChinata\Core\Plugin;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * XML feeds in Google's format (RSS 2.0 with `g:`), valid also for Meta, generated in the
 * background to a file with a random public URL. Each shop sets one or more feeds
 * (destination, language and country), what is left out (categories, products, rules) and
 * how each field is filled. The ids are those of the destination in ProductIds (core), the
 * same as the measurement events, so campaigns and history keep their products. Replaces
 * WooCommerce Google Product Feed and the catalog sync of Facebook for WooCommerce.
 */
final class FeedsModule extends Module {

	/**
	 * Module id.
	 */
	public function id(): string {
		return 'feeds';
	}

	/**
	 * Module name.
	 */
	public function label(): string {
		return __( 'Feeds de producto', 'lachinata-core' );
	}

	/**
	 * Module description.
	 */
	public function description(): string {
		return __( 'Feeds XML para Google Merchant Center y el catálogo de Meta, por destino, idioma y país, con exclusiones, IDs estables y avisos de calidad. Se generan en segundo plano.', 'lachinata-core' );
	}

	/**
	 * Version in which the module was added.
	 */
	public function since(): string {
		return '0.10.0';
	}

	/**
	 * Documentation.
	 */
	public function docs(): string {
		return 'plugin/modules/feeds/README.md';
	}

	/**
	 * Requirements.
	 *
	 * @return array{woocommerce: string}
	 */
	public function requires(): array {
		return array( 'woocommerce' => '10.0' );
	}

	/**
	 * Settings: all of them describe how the feeds are built, so they travel with the
	 * configuration. The feeds themselves (with their random URL) are data of the site.
	 *
	 * @return array<string, array{type: 'bool'|'int'|'float'|'string'|'array', default: mixed, export?: bool}>
	 */
	public function settings(): array {
		$copy = static fn( string $type, $value ): array => array(
			'type'    => $type,
			'default' => $value,
			'export'  => true,
		);
		return array(
			'exclude_out_of_stock' => $copy( 'bool', true ),
			'exclude_no_image'     => $copy( 'bool', true ),
			'exclude_no_price'     => $copy( 'bool', true ),
			'exclude_categories'   => $copy( 'array', array() ),
			'mpn'                  => $copy( 'string', 'sku' ),
			'labels'               => $copy( 'array', array( 'category', 'bestseller', 'campaign', '', '' ) ),
			'bestsellers'          => $copy( 'int', 20 ),
		);
	}

	/**
	 * A setting of the module.
	 *
	 * @param string $key Setting key.
	 * @return mixed
	 */
	public static function setting( string $key ) {
		$module = self::instance();
		return null === $module ? null : Settings::get( $module, $key );
	}

	/**
	 * The module, for Settings.
	 */
	public static function instance(): ?Module {
		return Plugin::instance()->modules()->get( 'feeds' );
	}

	/**
	 * Problems of the generation (a feed that could not be written).
	 */
	public static function gaps(): GapLog {
		return new GapLog( 'lachinata_feeds_gaps', 'lachinata-feeds' );
	}

	/**
	 * The feeds (destination, language, country, currency), for the JSON. Without their
	 * random segment: the URL is of each site.
	 *
	 * @return array<string, mixed>
	 */
	public function export_data(): array {
		$feeds = array_map(
			static function ( array $feed ): array {
				unset( $feed['segment'] );
				return $feed;
			},
			Feeds::all()
		);
		return $feeds ? array( 'feeds' => array_values( $feeds ) ) : array();
	}

	/**
	 * Problems with an imported `data` section.
	 *
	 * @param array<string, mixed> $data Section.
	 * @return string[]
	 */
	public function validate_data( array $data ): array {
		$errors = array();
		foreach ( (array) ( $data['feeds'] ?? array() ) as $index => $feed ) {
			foreach ( Feeds::validate( is_array( $feed ) ? $feed : array() ) as $message ) {
				/* translators: 1: feed number, 2: problem. */
				$errors[] = sprintf( __( 'Feed %1$d: %2$s', 'lachinata-core' ), (int) $index + 1, $message );
			}
		}
		$unknown = array_diff( array_keys( $data ), array( 'feeds' ) );
		if ( $unknown ) {
			/* translators: %s: keys. */
			$errors[] = sprintf( __( 'Claves desconocidas: %s.', 'lachinata-core' ), implode( ', ', $unknown ) );
		}
		return $errors;
	}

	/**
	 * Writes the imported feeds: the ones with the same destination, language and country
	 * keep their URL; the new ones get one.
	 *
	 * @param array<string, mixed> $data Section.
	 */
	public function import_data( array $data ): void {
		Feeds::replace( array_values( array_filter( (array) ( $data['feeds'] ?? array() ), 'is_array' ) ) );
	}

	/**
	 * Last generation of each feed, products, left out and quality notices.
	 *
	 * @return array{configured: bool, credentials: null, notes: string[]}
	 */
	public function health(): array {
		$notes = array();
		foreach ( Feeds::all() as $feed ) {
			$state   = Feeds::state( $feed['id'] );
			$notes[] = null === $state
				/* translators: %s: feed name. */
				? sprintf( __( '%s: aún no generado', 'lachinata-core' ), Feeds::label( $feed ) )
				: sprintf(
					/* translators: 1: feed name, 2: date, 3: products, 4: left out, 5: notices. */
					__( '%1$s: %2$s, %3$d productos, %4$d excluidos, %5$d avisos', 'lachinata-core' ),
					Feeds::label( $feed ),
					wp_date( 'j M H:i', (int) $state['at'] ),
					(int) $state['items'],
					(int) $state['excluded'],
					(int) $state['warnings']
				);
		}
		if ( ! $notes ) {
			$notes[] = __( 'Sin feeds: añade uno en WooCommerce → La Chinata → Feeds.', 'lachinata-core' );
		}
		return array(
			'configured'  => (bool) Feeds::all(),
			'credentials' => null,
			'notes'       => $notes,
		);
	}

	/**
	 * Product and category fields of the module, and the generated files (as options).
	 *
	 * @return array{product_meta: string[], term_meta: string[]}
	 */
	public function owned_data(): array {
		return array(
			'product_meta' => array( ProductFields::EXCLUDE, ProductFields::CAMPAIGN ),
			'term_meta'    => array( ProductFields::GOOGLE_CATEGORY ),
		);
	}

	/**
	 * Registers the hooks.
	 */
	public function boot(): void {
		ProductFields::boot();
		Schedule::boot();
		if ( is_admin() ) {
			FeedsTab::boot();
		}
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::add_command( 'lachinata feeds', Cli::class );
		}
	}
}
