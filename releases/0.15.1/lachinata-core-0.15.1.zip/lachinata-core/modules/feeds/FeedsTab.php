<?php
/**
 * WooCommerce → La Chinata → Feeds.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Feeds;

use LaChinata\Core\Admin\ProductIdsTab;
use LaChinata\Core\Admin\Screen;
use LaChinata\Core\Hooks;
use LaChinata\Core\Services;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * The feeds with their URL and last generation, what is left out and why, the quality
 * notices, and how the feeds are built.
 */
final class FeedsTab {

	/**
	 * Tab id.
	 */
	public const TAB = 'feeds';

	/**
	 * Actions of admin-post.php, also nonce actions; SAVE and ADD are also form ids.
	 */
	private const SAVE     = 'lachinata_feeds_settings';
	private const ADD      = 'lachinata_feeds_add';
	private const REMOVE   = 'lachinata_feeds_remove';
	private const GENERATE = 'lachinata_feeds_generate';
	private const VALIDATE = 'lachinata_feeds_validate';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/core/admin_tabs', array( self::class, 'tab' ), 35 );
		foreach ( array( self::SAVE, self::ADD, self::REMOVE, self::GENERATE, self::VALIDATE ) as $action ) {
			Hooks::add_action( 'admin_post_' . $action, array( self::class, 'handle' ) );
		}
	}

	/**
	 * Adds the tab before Exportar/importar.
	 *
	 * @param array<string, array{label: string, render: callable}> $tabs Tabs.
	 * @return array<string, array{label: string, render: callable}>
	 */
	public static function tab( array $tabs ): array {
		$tab      = array(
			self::TAB => array(
				'label'  => __( 'Feeds', 'lachinata-core' ),
				'render' => array( self::class, 'render' ),
			),
		);
		$position = array_search( 'transfer', array_keys( $tabs ), true );
		$position = false === $position ? count( $tabs ) : $position;
		return array_slice( $tabs, 0, $position, true ) + $tab + $tabs;
	}

	/**
	 * A one-button form.
	 *
	 * @param string $action  Action.
	 * @param string $label   Button text.
	 * @param string $feed_id Feed.
	 */
	private static function button( string $action, string $label, string $feed_id ): void {
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block;margin:0 6px 6px 0">
			<input type="hidden" name="action" value="<?php echo esc_attr( $action ); ?>">
			<input type="hidden" name="feed" value="<?php echo esc_attr( $feed_id ); ?>">
			<?php wp_nonce_field( $action ); ?>
			<?php submit_button( $label, self::REMOVE === $action ? 'delete' : 'secondary', 'submit', false ); ?>
		</form>
		<?php
	}

	/**
	 * Prints the tab.
	 */
	public static function render(): void {
		$module = FeedsModule::instance();
		if ( null === $module ) {
			return;
		}
		$values    = Settings::all( $module );
		$feeds     = Feeds::all();
		$languages = Services::languages();
		$countries = WC()->countries->get_countries();
		$labels    = (array) $values['labels'];
		$reasons   = Item::reasons();
		$kept      = Screen::take_field_errors( self::ADD );
		?>
		<p>
			<?php esc_html_e( 'Feeds XML en el formato de Google (RSS 2.0), que también lee Meta. Se generan solos cada noche y dos minutos después de cambiar un producto. Copia la URL de cada uno en Merchant Center (Productos → Fuentes de datos → Archivo → URL) o en el catálogo de Meta (Orígenes de datos → Lista de datos → URL programada).', 'lachinata-core' ); ?>
			<a href="<?php echo esc_url( Screen::guide_url( 'feeds' ) ); ?>"><?php esc_html_e( 'Guía', 'lachinata-core' ); ?></a>
		</p>
		<p class="description">
			<?php
			echo wp_kses(
				sprintf(
					/* translators: 1: link to the product ids tab, 2: link to the company data tab. */
					__( 'El ID de cada producto sale de <a href="%1$s">IDs de producto</a> (el mismo que usan los eventos de medición) y la marca, de <a href="%2$s">Datos de la empresa</a> o de la marca de WooCommerce. La categoría de Google se pone en cada categoría de productos y la heredan sus subcategorías.', 'lachinata-core' ),
					esc_url( Screen::url( ProductIdsTab::TAB ) ),
					esc_url( Screen::url( 'company' ) )
				),
				array( 'a' => array( 'href' => array() ) )
			);
			?>
		</p>

		<?php if ( $feeds ) : ?>
			<table class="widefat striped" style="max-width:1100px">
				<thead><tr><th><?php esc_html_e( 'Feed', 'lachinata-core' ); ?></th><th><?php esc_html_e( 'URL', 'lachinata-core' ); ?></th><th><?php esc_html_e( 'Última generación', 'lachinata-core' ); ?></th><th></th></tr></thead>
				<tbody>
					<?php foreach ( $feeds as $feed ) : ?>
						<?php $state = Feeds::state( $feed['id'] ); ?>
						<tr>
							<td><strong><?php echo esc_html( Feeds::label( $feed ) ); ?></strong><br><code><?php echo esc_html( $feed['currency'] ); ?></code></td>
							<td><input type="text" readonly class="large-text code" value="<?php echo esc_attr( Files::url( $feed ) ); ?>" aria-label="<?php esc_attr_e( 'URL del feed', 'lachinata-core' ); ?>" onfocus="this.select()"></td>
							<td>
								<?php
								if ( null === $state ) {
									esc_html_e( 'Aún no generado', 'lachinata-core' );
								} else {
									echo esc_html(
										sprintf(
											/* translators: 1: date, 2: products, 3: left out, 4: notices, 5: seconds. */
											__( '%1$s · %2$d productos · %3$d excluidos · %4$d avisos · %5$s s', 'lachinata-core' ),
											wp_date( 'j M Y H:i', (int) $state['at'] ),
											(int) $state['items'],
											(int) $state['excluded'],
											(int) $state['warnings'],
											number_format_i18n( (float) $state['seconds'], 1 )
										)
									);
								}
								?>
							</td>
							<td style="white-space:nowrap">
								<?php
								self::button( self::GENERATE, __( 'Generar ahora', 'lachinata-core' ), $feed['id'] );
								self::button( self::VALIDATE, __( 'Descargar y validar', 'lachinata-core' ), $feed['id'] );
								self::button( self::REMOVE, __( 'Quitar', 'lachinata-core' ), $feed['id'] );
								?>
							</td>
						</tr>
						<?php if ( null !== $state && ( $state['excluded_list'] || $state['notices'] ) ) : ?>
							<tr>
								<td colspan="4">
									<?php if ( $state['excluded_list'] ) : ?>
										<details>
											<summary><?php echo esc_html( sprintf( /* translators: %d: products. */ __( 'Excluidos (%d) y por qué', 'lachinata-core' ), (int) $state['excluded'] ) ); ?></summary>
											<ul>
												<?php foreach ( $state['excluded_list'] as $row ) : ?>
													<li><a href="<?php echo esc_url( (string) get_edit_post_link( (int) wp_get_post_parent_id( $row['id'] ) ? (int) wp_get_post_parent_id( $row['id'] ) : $row['id'] ) ); ?>"><?php echo esc_html( $row['name'] ); ?></a> — <?php echo esc_html( $reasons[ $row['reason'] ] ?? $row['reason'] ); ?></li>
												<?php endforeach; ?>
											</ul>
										</details>
									<?php endif; ?>
									<?php if ( $state['notices'] ) : ?>
										<details>
											<summary><?php echo esc_html( sprintf( /* translators: %d: notices. */ __( 'Avisos de calidad (%d)', 'lachinata-core' ), (int) $state['warnings'] ) ); ?></summary>
											<ul>
												<?php foreach ( $state['notices'] as $row ) : ?>
													<li><a href="<?php echo esc_url( (string) get_edit_post_link( (int) wp_get_post_parent_id( $row['id'] ) ? (int) wp_get_post_parent_id( $row['id'] ) : $row['id'] ) ); ?>"><?php echo esc_html( $row['name'] ); ?></a> — <?php echo esc_html( $row['notice'] ); ?></li>
												<?php endforeach; ?>
											</ul>
										</details>
									<?php endif; ?>
								</td>
							</tr>
						<?php endif; ?>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>

		<h2><?php esc_html_e( 'Añadir un feed', 'lachinata-core' ); ?></h2>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::ADD ); ?>">
			<?php wp_nonce_field( self::ADD ); ?>
			<p>
				<label for="lc-feeds-destination"><?php esc_html_e( 'Destino', 'lachinata-core' ); ?></label>
				<select id="lc-feeds-destination" name="destination"><option value="google">Google Merchant Center</option><option value="meta"><?php esc_html_e( 'Catálogo de Meta', 'lachinata-core' ); ?></option></select>
				<label for="lc-feeds-language"><?php esc_html_e( 'Idioma', 'lachinata-core' ); ?></label>
				<select id="lc-feeds-language" name="language">
					<?php foreach ( $languages->languages() as $language ) : ?>
						<option value="<?php echo esc_attr( $language ); ?>"><?php echo esc_html( $languages->label( $language ) ); ?></option>
					<?php endforeach; ?>
				</select>
				<label for="lc-feeds-country"><?php esc_html_e( 'País', 'lachinata-core' ); ?></label>
				<select id="lc-feeds-country" name="country">
					<?php foreach ( $countries as $code => $name ) : ?>
						<option value="<?php echo esc_attr( $code ); ?>" <?php selected( WC()->countries->get_base_country(), $code ); ?>><?php echo esc_html( html_entity_decode( $name ) ); ?></option>
					<?php endforeach; ?>
				</select>
				<?php submit_button( __( 'Añadir', 'lachinata-core' ), 'secondary', 'submit', false ); ?>
			</p>
			<?php Screen::field_error( $kept['errors'], 'feed', 'lc-feeds-destination' ); ?>
			<p class="description">
				<?php
				/* translators: %s: currency. */
				echo esc_html( sprintf( __( 'Moneda: la de la tienda (%s). Un feed por cada combinación de destino, idioma y país; los idiomas son los de la tienda (con el módulo de traducción, cada uno con sus textos y URLs).', 'lachinata-core' ), get_woocommerce_currency() ) );
				?>
			</p>
		</form>

		<h2><?php esc_html_e( 'Cómo se forman', 'lachinata-core' ); ?></h2>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE ); ?>">
			<?php wp_nonce_field( self::SAVE ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Dejar fuera', 'lachinata-core' ); ?></th>
					<td>
						<label><input type="checkbox" name="exclude_out_of_stock" value="1" <?php checked( (bool) $values['exclude_out_of_stock'] ); ?>> <?php esc_html_e( 'Sin stock', 'lachinata-core' ); ?></label><br>
						<label><input type="checkbox" name="exclude_no_image" value="1" <?php checked( (bool) $values['exclude_no_image'] ); ?>> <?php esc_html_e( 'Sin imagen', 'lachinata-core' ); ?></label><br>
						<label><input type="checkbox" name="exclude_no_price" value="1" <?php checked( (bool) $values['exclude_no_price'] ); ?>> <?php esc_html_e( 'Sin precio', 'lachinata-core' ); ?></label>
						<p class="description"><?php esc_html_e( 'Además, los productos marcados «No enviar a los feeds» en su ficha y los ocultos o sin publicar.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Categorías excluidas', 'lachinata-core' ); ?></th>
					<td>
						<fieldset style="max-height:200px;overflow:auto">
							<?php
							$terms = get_terms(
								array(
									'taxonomy'   => 'product_cat',
									'hide_empty' => false,
								)
							);
							foreach ( is_array( $terms ) ? $terms : array() as $term ) :
								$depth = count( get_ancestors( $term->term_id, 'product_cat', 'taxonomy' ) );
								?>
								<label style="display:block;margin-left:<?php echo esc_attr( (string) ( $depth * 16 ) ); ?>px"><input type="checkbox" name="exclude_categories[]" value="<?php echo esc_attr( (string) $term->term_id ); ?>" <?php checked( in_array( $term->term_id, array_map( 'intval', (array) $values['exclude_categories'] ), true ) ); ?>> <?php echo esc_html( $term->name ); ?></label>
							<?php endforeach; ?>
						</fieldset>
						<p class="description"><?php esc_html_e( 'Con sus subcategorías.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="lc-feeds-mpn"><?php esc_html_e( 'MPN', 'lachinata-core' ); ?></label></th>
					<td>
						<select id="lc-feeds-mpn" name="mpn">
							<option value="sku" <?php selected( $values['mpn'], 'sku' ); ?>><?php esc_html_e( 'El SKU', 'lachinata-core' ); ?></option>
							<option value="none" <?php selected( $values['mpn'], 'none' ); ?>><?php esc_html_e( 'No enviar', 'lachinata-core' ); ?></option>
						</select>
						<p class="description"><?php esc_html_e( 'El GTIN es el de WooCommerce (Inventario → GTIN, UPC, EAN o ISBN). Sin GTIN ni MPN, Google recibe identifier_exists = no.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
				<?php for ( $index = 0; $index <= 4; $index++ ) : ?>
					<tr>
						<th scope="row"><label for="lc-feeds-label-<?php echo esc_attr( (string) $index ); ?>"><?php echo esc_html( sprintf( 'custom_label_%d', $index ) ); ?></label></th>
						<td>
							<select id="lc-feeds-label-<?php echo esc_attr( (string) $index ); ?>" name="labels[<?php echo esc_attr( (string) $index ); ?>]">
								<?php foreach ( Item::label_sources() as $source => $name ) : ?>
									<option value="<?php echo esc_attr( $source ); ?>" <?php selected( (string) ( $labels[ $index ] ?? '' ), $source ); ?>><?php echo esc_html( $name ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
				<?php endfor; ?>
				<tr>
					<th scope="row"><label for="lc-feeds-bestsellers"><?php esc_html_e( 'Más vendidos', 'lachinata-core' ); ?></label></th>
					<td><input type="number" min="1" max="500" class="small-text" id="lc-feeds-bestsellers" name="bestsellers" value="<?php echo esc_attr( (string) $values['bestsellers'] ); ?>"> <?php esc_html_e( 'productos con la etiqueta «bestseller»', 'lachinata-core' ); ?></td>
				</tr>
			</table>
			<p class="description"><?php esc_html_e( 'Estos ajustes y los feeds (sin su URL) entran en la exportación de configuración.', 'lachinata-core' ); ?></p>
			<?php submit_button( __( 'Guardar', 'lachinata-core' ) ); ?>
		</form>
		<?php
	}

	/**
	 * Saves the settings or runs a button.
	 */
	public static function handle(): void {
		$action = (string) preg_replace( '/^admin_post_/', '', current_action() );
		Screen::check( $action );
		$module = FeedsModule::instance();
		if ( null === $module ) {
			Screen::redirect( self::TAB );
		}
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Screen::check().
		$feed_id = isset( $_POST['feed'] ) ? sanitize_text_field( wp_unslash( $_POST['feed'] ) ) : '';
		$feed    = Feeds::get( $feed_id );
		switch ( $action ) {
			case self::ADD:
				$errors = Feeds::add(
					array(
						'destination' => isset( $_POST['destination'] ) ? sanitize_key( wp_unslash( $_POST['destination'] ) ) : '',
						'language'    => isset( $_POST['language'] ) ? sanitize_text_field( wp_unslash( $_POST['language'] ) ) : '',
						'country'     => isset( $_POST['country'] ) ? strtoupper( sanitize_key( wp_unslash( $_POST['country'] ) ) ) : '',
					)
				);
				if ( $errors ) {
					Screen::field_errors( self::ADD, array( 'feed' => implode( ' ', $errors ) ) );
					Screen::flash( 'error', $errors );
				} else {
					Schedule::soon();
					Screen::flash( 'success', array( __( 'Feed añadido: se genera en segundo plano en unos segundos.', 'lachinata-core' ) ) );
				}
				Screen::redirect( self::TAB );
				// No break: redirect() stops.
			case self::REMOVE:
				Feeds::remove( $feed_id );
				Screen::flash( 'success', array( __( 'Feed quitado y su archivo borrado. Quítalo también de Merchant Center o de Meta.', 'lachinata-core' ) ) );
				Screen::redirect( self::TAB );
				// No break: redirect() stops.
			case self::GENERATE:
				$result = null === $feed ? new \WP_Error( 'lachinata_feeds_unknown', __( 'Feed desconocido.', 'lachinata-core' ) ) : Builder::generate( $feed );
				Screen::flash(
					is_wp_error( $result ) ? 'error' : 'success',
					/* translators: 1: products, 2: left out, 3: notices. */
					array( is_wp_error( $result ) ? $result->get_error_message() : sprintf( __( 'Generado: %1$d productos, %2$d excluidos, %3$d avisos.', 'lachinata-core' ), $result['items'], $result['excluded'], $result['warnings'] ) )
				);
				Screen::redirect( self::TAB );
				// No break: redirect() stops.
			case self::VALIDATE:
				$result = null === $feed ? array(
					'ok'       => false,
					'messages' => array( __( 'Feed desconocido.', 'lachinata-core' ) ),
				) : Validator::check( $feed );
				Screen::flash( $result['ok'] ? 'success' : 'error', $result['messages'] );
				Screen::redirect( self::TAB );
		}

		foreach ( array( 'exclude_out_of_stock', 'exclude_no_image', 'exclude_no_price' ) as $key ) {
			Settings::set( $module, $key, ! empty( $_POST[ $key ] ) );
		}
		$categories = isset( $_POST['exclude_categories'] ) ? array_values( array_filter( array_map( 'absint', (array) wp_unslash( $_POST['exclude_categories'] ) ) ) ) : array();
		Settings::set( $module, 'exclude_categories', $categories );
		$mpn = isset( $_POST['mpn'] ) ? sanitize_key( wp_unslash( $_POST['mpn'] ) ) : 'sku';
		Settings::set( $module, 'mpn', in_array( $mpn, array( 'sku', 'none' ), true ) ? $mpn : 'sku' );
		$labels = array();
		$posted = isset( $_POST['labels'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['labels'] ) ) : array();
		for ( $index = 0; $index <= 4; $index++ ) {
			$source           = sanitize_key( (string) ( $posted[ $index ] ?? '' ) );
			$labels[ $index ] = isset( Item::label_sources()[ $source ] ) ? $source : '';
		}
		Settings::set( $module, 'labels', $labels );
		Settings::set( $module, 'bestsellers', max( 1, min( 500, isset( $_POST['bestsellers'] ) ? absint( $_POST['bestsellers'] ) : 20 ) ) );
		// phpcs:enable
		Schedule::soon();
		Screen::flash( 'success', array( __( 'Ajustes guardados: los feeds se regeneran en segundo plano.', 'lachinata-core' ) ) );
		Screen::redirect( self::TAB );
	}
}
