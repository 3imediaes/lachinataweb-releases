<?php
/**
 * Where the feeds are written.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Feeds;

defined( 'ABSPATH' ) || exit;

/**
 * `uploads/lachinata-feeds/<segment>/<id>.xml`: a static file the web server hands out
 * without PHP, under a random segment so that nobody finds it without the URL. Written to a
 * temporary file and renamed, so Merchant Center never reads half a feed.
 */
final class Files {

	/**
	 * Folder in uploads.
	 */
	public const FOLDER = 'lachinata-feeds';

	/**
	 * Path of a feed's file.
	 *
	 * @param array{id: string, segment: string} $feed Feed.
	 */
	public static function path( array $feed ): string {
		$uploads = wp_upload_dir( null, false );
		return trailingslashit( (string) $uploads['basedir'] ) . self::FOLDER . '/' . $feed['segment'] . '/' . $feed['id'] . '.xml';
	}

	/**
	 * Public URL of a feed.
	 *
	 * @param array{id: string, segment: string} $feed Feed.
	 */
	public static function url( array $feed ): string {
		$uploads = wp_upload_dir( null, false );
		return trailingslashit( (string) $uploads['baseurl'] ) . self::FOLDER . '/' . $feed['segment'] . '/' . $feed['id'] . '.xml';
	}

	/**
	 * Opens the temporary file of a feed for writing.
	 *
	 * @param array{id: string, segment: string} $feed Feed.
	 * @return resource|null
	 */
	public static function open( array $feed ) {
		$path = self::path( $feed );
		if ( ! wp_mkdir_p( dirname( $path ) ) ) {
			return null;
		}
		$index = dirname( $path, 2 ) . '/index.html';
		if ( ! file_exists( $index ) ) {
			// No listing of the folder of the feeds on servers that would show it.
			file_put_contents( $index, '' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- empty guard file.
		}
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- streamed: a feed can be large.
		$handle = fopen( $path . '.tmp', 'wb' );
		return false === $handle ? null : $handle;
	}

	/**
	 * Closes the temporary file and puts it in place.
	 *
	 * @param array{id: string, segment: string} $feed   Feed.
	 * @param resource                           $handle Handle from open().
	 */
	public static function commit( array $feed, $handle ): bool {
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- streamed.
		$path = self::path( $feed );
		return rename( $path . '.tmp', $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename -- atomic replace.
	}

	/**
	 * Deletes a feed's file and its folder.
	 *
	 * @param array{id: string, segment: string} $feed Feed.
	 */
	public static function delete( array $feed ): void {
		$path = self::path( $feed );
		foreach ( array( $path, $path . '.tmp' ) as $file ) {
			if ( file_exists( $file ) ) {
				wp_delete_file( $file );
			}
		}
		if ( is_dir( dirname( $path ) ) ) {
			@rmdir( dirname( $path ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.file_system_operations_rmdir -- only when empty.
		}
	}
}
