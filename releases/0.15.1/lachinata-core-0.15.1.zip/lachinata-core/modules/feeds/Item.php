<?php
/**
 * A product in a feed.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Feeds;

use LaChinata\Core\Company;
use LaChinata\Core\Gtin;
use LaChinata\Core\ProductIds;
use LaChinata\Core\Services;

defined( 'ABSPATH' ) || exit;

/**
 * Why a product is left out of a feed, or its fields in Google's format (valid for Meta)
 * with its quality notices. A variable product is not an item: its variations are, with
 * `item_group_id`. Titles and descriptions are the product's own, in the language of the
 * feed: nothing is added to them (no «free shipping»: Google forbids promotional text; the
 * shipping goes in Merchant Center).
 *
 * @phpstan-import-type Feed from Feeds
 */
final class Item {

	/**
	 * Longest title Google takes.
	 */
	public const TITLE_LENGTH = 150;

	/**
	 * Longest description Google takes.
	 */
	public const DESCRIPTION_LENGTH = 5000;

	/**
	 * Promotional text Google forbids in titles and descriptions.
	 */
	private const PROMO = '/\b(env[ií]os?\s+gratis|gratis|free\s+shipping|ofertas?|descuentos?|rebajas?|promoci[oó]n|black\s+friday)\b/iu';

	/**
	 * A percentage, promotional in a title («-20 %»); in a description it is often a fact
	 * («100 % natural»), so it is only looked for in titles.
	 */
	private const PERCENT = '/\d+\s?%/u';

	/**
	 * Why a product (or variation) does not go to the feeds, or an empty string.
	 *
	 * @param \WC_Product $product   Product or variation.
	 * @param int[]       $excluded  Excluded category ids, with their subcategories.
	 * @param string      $language  Language of the feed, '' for any.
	 */
	public static function reason( \WC_Product $product, array $excluded, string $language = '' ): string {
		$parent = $product->is_type( 'variation' ) ? wc_get_product( $product->get_parent_id() ) : $product;
		$parent = $parent instanceof \WC_Product ? $parent : $product;
		if ( 'publish' !== $parent->get_status() || '' !== (string) get_post_field( 'post_password', $parent->get_id() ) || 'hidden' === $parent->get_catalog_visibility() || ( $product->is_type( 'variation' ) && 'publish' !== $product->get_status() ) ) {
			return 'hidden';
		}
		if ( '' !== $language && ! Services::languages()->available( 'post', $parent->get_id(), $language ) ) {
			// A feed in another language only with what exists in it (`translate`).
			return 'not_translated';
		}
		if ( get_post_meta( $parent->get_id(), ProductFields::EXCLUDE, true ) || get_post_meta( $product->get_id(), ProductFields::EXCLUDE, true ) ) {
			return 'excluded_product';
		}
		if ( $excluded && array_intersect( $parent->get_category_ids(), $excluded ) ) {
			return 'excluded_category';
		}
		if ( FeedsModule::setting( 'exclude_no_price' ) && '' === (string) $product->get_price() ) {
			return 'no_price';
		}
		if ( FeedsModule::setting( 'exclude_out_of_stock' ) && ! $product->is_in_stock() ) {
			return 'out_of_stock';
		}
		if ( FeedsModule::setting( 'exclude_no_image' ) && 0 === self::image_id( $product ) ) {
			return 'no_image';
		}
		return '';
	}

	/**
	 * Reasons for people.
	 *
	 * @return array<string, string>
	 */
	public static function reasons(): array {
		return array(
			'hidden'            => __( 'No está publicado o está oculto en el catálogo', 'lachinata-core' ),
			'not_translated'    => __( 'Sin traducir al idioma del feed', 'lachinata-core' ),
			'excluded_product'  => __( 'Marcado «No enviar a los feeds»', 'lachinata-core' ),
			'excluded_category' => __( 'Su categoría está excluida', 'lachinata-core' ),
			'no_price'          => __( 'Sin precio', 'lachinata-core' ),
			'out_of_stock'      => __( 'Sin stock', 'lachinata-core' ),
			'no_image'          => __( 'Sin imagen', 'lachinata-core' ),
		);
	}

	/**
	 * Fields of an item, in order, and its notices.
	 *
	 * @param \WC_Product           $product    Product or variation.
	 * @param array<string, string> $feed       Feed.
	 * @param array<string, mixed>  $catalog    Shared data of the generation (`bestsellers`).
	 * @return array{fields: list<array{0: string, 1: string}>, notices: string[]}
	 */
	public static function build( \WC_Product $product, array $feed, array $catalog = array() ): array {
		$languages = Services::languages();
		$language  = $feed['language'];
		$google    = 'google' === $feed['destination'];
		$parent    = $product->is_type( 'variation' ) ? wc_get_product( $product->get_parent_id() ) : $product;
		$parent    = $parent instanceof \WC_Product ? $parent : $product;
		$texts     = $languages->product_texts( $parent, $language );
		$notices   = array();
		$fields    = array();
		$add       = static function ( string $name, $value ) use ( &$fields ): void {
			$value = trim( (string) $value );
			if ( '' !== $value ) {
				$fields[] = array( $name, $value );
			}
		};

		$title = self::plain( $texts['title'] );
		if ( $product instanceof \WC_Product_Variation ) {
			$variant = self::plain( wc_get_formatted_variation( $product, true, false, false ) );
			$title   = '' === $variant ? $title : $title . ' ' . $variant;
		}
		$description = self::plain( '' !== trim( $texts['description'] ) ? $texts['description'] : $texts['short_description'] );
		if ( $product instanceof \WC_Product_Variation && '' !== trim( (string) $product->get_description() ) ) {
			$description = self::plain( (string) $product->get_description() ) . ' ' . $description;
		}
		$description = '' === $description ? $title : $description;
		if ( mb_strlen( $title ) > self::TITLE_LENGTH ) {
			/* translators: %d: maximum length. */
			$notices[] = sprintf( __( 'Título de más de %d caracteres: Google lo corta', 'lachinata-core' ), self::TITLE_LENGTH );
		}
		if ( preg_match( self::PROMO, $title ) || preg_match( self::PERCENT, $title ) || preg_match( self::PROMO, $description ) ) {
			$notices[] = __( 'Texto promocional en el título o la descripción (envío gratis, oferta, descuento, %): Google lo rechaza', 'lachinata-core' );
		}

		$add( 'g:id', ProductIds::get( $product, $feed['destination'] ) );
		$add( 'g:title', mb_substr( $title, 0, self::TITLE_LENGTH ) );
		$add( 'g:description', mb_substr( $description, 0, self::DESCRIPTION_LENGTH ) );
		$add( 'g:link', $languages->url( (string) $product->get_permalink(), $language ) );

		$image = self::image_id( $product );
		if ( $image ) {
			$add( 'g:image_link', (string) wp_get_attachment_image_url( $image, 'full' ) );
		} else {
			$notices[] = __( 'Sin imagen', 'lachinata-core' );
		}
		foreach ( array_slice( array_diff( array_map( 'intval', $parent->get_gallery_image_ids() ), array( $image ) ), 0, 10 ) as $extra ) {
			$add( 'g:additional_image_link', (string) wp_get_attachment_image_url( $extra, 'full' ) );
		}

		$add( 'g:availability', self::availability( $product, $google ) );
		$regular = (float) wc_get_price_including_tax( $product, array( 'price' => (float) ( '' !== (string) $product->get_regular_price() ? $product->get_regular_price() : $product->get_price() ) ) );
		$add( 'g:price', self::money( $regular, $feed['currency'] ) );
		if ( $product->is_on_sale() && '' !== (string) $product->get_sale_price() ) {
			$add( 'g:sale_price', self::money( (float) wc_get_price_including_tax( $product, array( 'price' => (float) $product->get_sale_price() ) ), $feed['currency'] ) );
			$from = $product->get_date_on_sale_from();
			$to   = $product->get_date_on_sale_to();
			if ( $from || $to ) {
				$add( 'g:sale_price_effective_date', ( $from ? $from->format( 'Y-m-d\TH:iO' ) : gmdate( 'Y-m-d\T00:00O' ) ) . '/' . ( $to ? $to->format( 'Y-m-d\TH:iO' ) : gmdate( 'Y-m-d\T23:59O', time() + YEAR_IN_SECONDS ) ) );
			}
		}

		$add( 'g:brand', Company::brand( $product ) );
		$gtin = Gtin::digits( (string) $product->get_global_unique_id() );
		if ( '' !== $gtin && ! Gtin::valid_length( $gtin ) ) {
			$notices[] = __( 'GTIN con un número de cifras que no existe (8, 12, 13 o 14): no se envía', 'lachinata-core' );
			$gtin      = '';
		} elseif ( '' !== $gtin && ! Gtin::valid_check_digit( $gtin ) ) {
			$notices[] = __( 'GTIN con el dígito de control mal: no se envía', 'lachinata-core' );
			$gtin      = '';
		}
		if ( '' === $gtin ) {
			$notices[] = __( 'Sin GTIN', 'lachinata-core' );
		}
		$add( 'g:gtin', $gtin );
		$mpn = 'sku' === FeedsModule::setting( 'mpn' ) ? (string) $product->get_sku() : '';
		$add( 'g:mpn', $mpn );
		if ( $google && '' === $gtin && '' === $mpn ) {
			$add( 'g:identifier_exists', 'no' );
		}
		$add( 'g:condition', 'new' );
		$add( 'g:item_group_id', ProductIds::group( $product, $feed['destination'] ) );

		$add( 'g:google_product_category', ProductFields::google_category( $parent ) );
		$path = self::category_path( $parent, $language );
		$add( 'g:product_type', implode( ' > ', $path ) );

		$weight = (float) $product->get_weight();
		if ( $weight > 0 ) {
			$unit = get_option( 'woocommerce_weight_unit', 'kg' );
			$add( 'g:shipping_weight', wc_format_decimal( $weight ) . ' ' . ( 'lbs' === $unit ? 'lb' : $unit ) );
		}

		$content = Services::product_content();
		if ( null !== $content ) {
			$amount    = $content->content( $product );
			$reference = $content->reference( $product );
			if ( null !== $amount && null !== $reference ) {
				$add( 'g:unit_pricing_measure', self::measure( $amount ) );
				$add( 'g:unit_pricing_base_measure', self::measure( $reference ) );
			}
		}

		foreach ( self::labels( $product, $parent, $path, $catalog ) as $index => $label ) {
			$add( 'g:custom_label_' . $index, $label );
		}

		return array(
			'fields'  => $fields,
			'notices' => $notices,
		);
	}

	/**
	 * Image of a product or its parent's.
	 *
	 * @param \WC_Product $product Product or variation.
	 */
	public static function image_id( \WC_Product $product ): int {
		$image = (int) $product->get_image_id();
		if ( 0 === $image && $product->is_type( 'variation' ) ) {
			$parent = wc_get_product( $product->get_parent_id() );
			$image  = $parent instanceof \WC_Product ? (int) $parent->get_image_id() : 0;
		}
		return $image;
	}

	/**
	 * Availability in the words of each destination.
	 *
	 * @param \WC_Product $product Product.
	 * @param bool        $google  Google (or Meta).
	 */
	private static function availability( \WC_Product $product, bool $google ): string {
		if ( $product->is_on_backorder() ) {
			return $google ? 'backorder' : 'available for order';
		}
		if ( $product->is_in_stock() ) {
			return $google ? 'in_stock' : 'in stock';
		}
		return $google ? 'out_of_stock' : 'out of stock';
	}

	/**
	 * «12.50 EUR».
	 *
	 * @param float  $amount   Amount.
	 * @param string $currency Currency.
	 */
	private static function money( float $amount, string $currency ): string {
		return number_format( $amount, 2, '.', '' ) . ' ' . $currency;
	}

	/**
	 * «500 ml», «1 l», «6 ct».
	 *
	 * @param array{amount: float, unit: string} $quantity Quantity.
	 */
	private static function measure( array $quantity ): string {
		$unit = 'ud' === $quantity['unit'] ? 'ct' : $quantity['unit'];
		return wc_format_decimal( $quantity['amount'] ) . ' ' . $unit;
	}

	/**
	 * Text without markup, shortcodes or repeated spaces.
	 *
	 * @param string $text Text.
	 */
	private static function plain( string $text ): string {
		$text = wp_strip_all_tags( strip_shortcodes( $text ) );
		return trim( (string) preg_replace( '/\s+/u', ' ', html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) );
	}

	/**
	 * Path of the deepest category, from the top, in the language of the feed.
	 *
	 * @param \WC_Product $product  Product (not a variation).
	 * @param string      $language Locale.
	 * @return string[]
	 */
	public static function category_path( \WC_Product $product, string $language ): array {
		$deepest = 0;
		$depth   = -1;
		foreach ( $product->get_category_ids() as $id ) {
			$count = count( get_ancestors( (int) $id, 'product_cat', 'taxonomy' ) );
			if ( $count > $depth ) {
				$depth   = $count;
				$deepest = (int) $id;
			}
		}
		if ( 0 === $deepest ) {
			return array();
		}
		$out = array();
		foreach ( array_reverse( array_merge( array( $deepest ), get_ancestors( $deepest, 'product_cat', 'taxonomy' ) ) ) as $id ) {
			$term = get_term( (int) $id, 'product_cat' );
			if ( $term instanceof \WP_Term ) {
				$out[] = self::plain( Services::languages()->term_name( $term, $language ) );
			}
		}
		return $out;
	}

	/**
	 * Sources of the custom labels.
	 *
	 * @return array<string, string>
	 */
	public static function label_sources(): array {
		return array(
			''            => __( 'Ninguna', 'lachinata-core' ),
			'category'    => __( 'Categoría principal', 'lachinata-core' ),
			'subcategory' => __( 'Subcategoría (la más concreta)', 'lachinata-core' ),
			'bestseller'  => __( 'Más vendidos («bestseller»)', 'lachinata-core' ),
			'sale'        => __( 'En oferta («sale»)', 'lachinata-core' ),
			'campaign'    => __( 'Campaña (campo del producto)', 'lachinata-core' ),
			'price_band'  => __( 'Franja de precio', 'lachinata-core' ),
		);
	}

	/**
	 * Custom labels 0–4 from their sources (WooCommerce → La Chinata → Feeds).
	 *
	 * @param \WC_Product          $product Product or variation.
	 * @param \WC_Product          $main    Parent (or the product).
	 * @param string[]             $path    Category path.
	 * @param array<string, mixed> $catalog Shared data (`bestsellers`: ids).
	 * @return array<int, string>
	 */
	private static function labels( \WC_Product $product, \WC_Product $main, array $path, array $catalog ): array {
		$sources = (array) FeedsModule::setting( 'labels' );
		$out     = array();
		for ( $index = 0; $index <= 4; $index++ ) {
			$source = (string) ( $sources[ $index ] ?? '' );
			$value  = '';
			switch ( $source ) {
				case 'category':
					$value = $path[0] ?? '';
					break;
				case 'subcategory':
					$value = (string) end( $path );
					break;
				case 'bestseller':
					$value = in_array( $main->get_id(), (array) ( $catalog['bestsellers'] ?? array() ), true ) ? 'bestseller' : '';
					break;
				case 'sale':
					$value = $product->is_on_sale() ? 'sale' : '';
					break;
				case 'campaign':
					$value = (string) get_post_meta( $main->get_id(), ProductFields::CAMPAIGN, true );
					break;
				case 'price_band':
					$price = (float) $product->get_price();
					$value = $price < 10 ? '0-10' : ( $price < 25 ? '10-25' : ( $price < 50 ? '25-50' : '50+' ) );
					break;
			}
			if ( '' !== $value ) {
				$out[ $index ] = mb_substr( $value, 0, 100 );
			}
		}
		return $out;
	}
}
