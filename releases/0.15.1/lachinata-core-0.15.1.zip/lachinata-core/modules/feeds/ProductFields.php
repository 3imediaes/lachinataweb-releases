<?php
/**
 * Fields of the feeds in the product and the category.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Feeds;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * «No enviar a los feeds» and «Campaña» (a custom label) in the La Chinata tab of the
 * product (`lachinata/catalog/product_fields`; without `catalog`, in the Advanced tab of
 * WooCommerce), and the Google product category of each WooCommerce category, which its
 * subcategories inherit.
 */
final class ProductFields {

	/**
	 * Product meta: left out of every feed.
	 */
	public const EXCLUDE = '_lc_feeds_exclude';

	/**
	 * Product meta: campaign, for a custom label.
	 */
	public const CAMPAIGN = '_lc_feeds_campaign';

	/**
	 * Term meta of `product_cat`: Google product category (id or path of Google's taxonomy).
	 */
	public const GOOGLE_CATEGORY = '_lc_feeds_google_category';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		if ( ! is_admin() ) {
			return;
		}
		Hooks::add_action( 'lachinata/catalog/product_fields', array( self::class, 'fields' ) );
		Hooks::add_action( 'woocommerce_product_options_advanced', array( self::class, 'fallback' ) );
		Hooks::add_action( 'woocommerce_admin_process_product_object', array( self::class, 'save' ) );
		Hooks::add_action( 'product_cat_add_form_fields', array( self::class, 'category_add' ), 20 );
		Hooks::add_action( 'product_cat_edit_form_fields', array( self::class, 'category_edit' ), 20 );
		Hooks::add_action( 'created_product_cat', array( self::class, 'save_category' ) );
		Hooks::add_action( 'edited_product_cat', array( self::class, 'save_category' ) );
	}

	/**
	 * The product fields, once per screen.
	 *
	 * @param mixed $product Product being edited.
	 */
	public static function fields( $product = null ): void {
		static $printed = false;
		if ( $printed ) {
			return;
		}
		$printed = true;
		$id      = $product instanceof \WC_Product ? $product->get_id() : 0;
		echo '<div class="options_group">';
		wp_nonce_field( 'lachinata_feeds_product', 'lachinata_feeds_product_nonce' );
		woocommerce_wp_checkbox(
			array(
				'id'          => 'lc_feeds_exclude',
				'label'       => __( 'No enviar a los feeds', 'lachinata-core' ),
				'value'       => $id && get_post_meta( $id, self::EXCLUDE, true ) ? 'yes' : 'no',
				'description' => __( 'Ni Google Merchant Center ni el catálogo de Meta lo reciben.', 'lachinata-core' ),
			)
		);
		woocommerce_wp_text_input(
			array(
				'id'          => 'lc_feeds_campaign',
				'label'       => __( 'Campaña', 'lachinata-core' ),
				'value'       => $id ? (string) get_post_meta( $id, self::CAMPAIGN, true ) : '',
				'desc_tip'    => true,
				'description' => __( 'Etiqueta personalizada de los feeds (Navidad, Black Friday…) para agrupar productos en las campañas.', 'lachinata-core' ),
			)
		);
		echo '</div>';
	}

	/**
	 * Without the La Chinata tab (module `catalog` off), the fields go to Advanced.
	 */
	public static function fallback(): void {
		if ( ! function_exists( 'lachinata_module' ) || ! lachinata_module( 'catalog' ) ) {
			global $product_object;
			self::fields( $product_object );
		}
	}

	/**
	 * Saves the product fields.
	 *
	 * @param \WC_Product $product Product being saved.
	 */
	public static function save( \WC_Product $product ): void {
		if ( ! isset( $_POST['lachinata_feeds_product_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['lachinata_feeds_product_nonce'] ) ), 'lachinata_feeds_product' ) || ! current_user_can( 'edit_post', $product->get_id() ) ) {
			return;
		}
		if ( ! empty( $_POST['lc_feeds_exclude'] ) ) {
			$product->update_meta_data( self::EXCLUDE, '1' );
		} else {
			$product->delete_meta_data( self::EXCLUDE );
		}
		$campaign = isset( $_POST['lc_feeds_campaign'] ) ? substr( sanitize_text_field( wp_unslash( $_POST['lc_feeds_campaign'] ) ), 0, 100 ) : '';
		if ( '' === $campaign ) {
			$product->delete_meta_data( self::CAMPAIGN );
		} else {
			$product->update_meta_data( self::CAMPAIGN, $campaign );
		}
	}

	/**
	 * The category field input.
	 *
	 * @param string $value Current value.
	 */
	private static function category_input( string $value ): void {
		printf(
			'<input type="text" name="lc_feeds_google_category" id="lc-feeds-google-category" value="%1$s" class="regular-text" placeholder="%2$s" aria-describedby="lc-feeds-google-category-hint"><p class="description" id="lc-feeds-google-category-hint">%3$s</p>',
			esc_attr( $value ),
			esc_attr__( '2916 o Alimentación, bebida y tabaco > Alimentos > Condimentos y salsas', 'lachinata-core' ),
			esc_html__( 'Número o ruta de la taxonomía de productos de Google. Vacío: la de la categoría padre.', 'lachinata-core' )
		);
	}

	/**
	 * Field on the new category screen.
	 */
	public static function category_add(): void {
		echo '<div class="form-field"><label for="lc-feeds-google-category">' . esc_html__( 'Categoría de Google', 'lachinata-core' ) . '</label>';
		wp_nonce_field( 'lachinata_feeds_category', 'lachinata_feeds_category_nonce' );
		self::category_input( '' );
		echo '</div>';
	}

	/**
	 * Field on the edit category screen.
	 *
	 * @param \WP_Term $term Category.
	 */
	public static function category_edit( \WP_Term $term ): void {
		echo '<tr class="form-field"><th scope="row"><label for="lc-feeds-google-category">' . esc_html__( 'Categoría de Google', 'lachinata-core' ) . '</label></th><td>';
		wp_nonce_field( 'lachinata_feeds_category', 'lachinata_feeds_category_nonce' );
		self::category_input( (string) get_term_meta( $term->term_id, self::GOOGLE_CATEGORY, true ) );
		echo '</td></tr>';
	}

	/**
	 * Saves the category field.
	 *
	 * @param int $term_id Category id.
	 */
	public static function save_category( $term_id ): void {
		if ( ! isset( $_POST['lachinata_feeds_category_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['lachinata_feeds_category_nonce'] ) ), 'lachinata_feeds_category' ) || ! current_user_can( 'manage_product_terms' ) ) {
			return;
		}
		$value = isset( $_POST['lc_feeds_google_category'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['lc_feeds_google_category'] ) ) ) : '';
		if ( '' === $value ) {
			delete_term_meta( (int) $term_id, self::GOOGLE_CATEGORY );
			return;
		}
		update_term_meta( (int) $term_id, self::GOOGLE_CATEGORY, substr( $value, 0, 250 ) );
	}

	/**
	 * Google product category of a product: that of its deepest category, or the nearest
	 * ancestor that has one.
	 *
	 * @param \WC_Product $product Product (not a variation).
	 */
	public static function google_category( \WC_Product $product ): string {
		$best  = '';
		$depth = -1;
		foreach ( $product->get_category_ids() as $id ) {
			$chain = array_merge( array( (int) $id ), get_ancestors( (int) $id, 'product_cat', 'taxonomy' ) );
			foreach ( $chain as $level => $term_id ) {
				$value = (string) get_term_meta( (int) $term_id, self::GOOGLE_CATEGORY, true );
				if ( '' !== $value ) {
					$here = count( $chain ) - $level;
					if ( $here > $depth ) {
						$depth = $here;
						$best  = $value;
					}
					break;
				}
			}
		}
		return $best;
	}
}
