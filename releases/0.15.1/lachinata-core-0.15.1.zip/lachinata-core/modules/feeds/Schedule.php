<?php
/**
 * When the feeds are generated.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Feeds;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * A full generation every day (Action Scheduler, at night in the shop's time zone) and a
 * partial one two minutes after a product changes (its data, its stock or its price), with
 * every change of those minutes together.
 */
final class Schedule {

	/**
	 * Daily full generation.
	 */
	public const FULL = 'lachinata_feeds_full';

	/**
	 * Partial generation after changes.
	 */
	public const PARTIAL = 'lachinata_feeds_partial';

	/**
	 * Group of the scheduled actions.
	 */
	public const GROUP = 'lachinata-feeds';

	/**
	 * Option with the products that changed since the last generation.
	 */
	public const DIRTY = 'lachinata_feeds_dirty';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'action_scheduler_init', array( self::class, 'schedule' ) );
		Hooks::add_action( self::FULL, array( self::class, 'full' ) );
		Hooks::add_action( self::PARTIAL, array( self::class, 'partial' ) );
		foreach ( array( 'woocommerce_update_product', 'woocommerce_new_product', 'woocommerce_update_product_variation', 'woocommerce_new_product_variation', 'woocommerce_product_set_stock', 'woocommerce_variation_set_stock', 'woocommerce_product_set_stock_status', 'woocommerce_variation_set_stock_status', 'before_delete_post', 'wp_trash_post' ) as $hook ) {
			Hooks::add_action( $hook, array( self::class, 'changed' ) );
		}
	}

	/**
	 * The daily generation, once.
	 */
	public static function schedule(): void {
		// Looked at once a day, not on every request.
		if ( get_transient( 'lachinata_feeds_full_scheduled' ) ) {
			return;
		}
		set_transient( 'lachinata_feeds_full_scheduled', 1, DAY_IN_SECONDS );
		if ( function_exists( 'as_has_scheduled_action' ) && function_exists( 'as_schedule_recurring_action' ) && ! as_has_scheduled_action( self::FULL, array(), self::GROUP ) ) {
			$night = ( new \DateTimeImmutable( 'tomorrow 03:30', wp_timezone() ) )->getTimestamp();
			as_schedule_recurring_action( $night, DAY_IN_SECONDS, self::FULL, array(), self::GROUP );
		}
	}

	/**
	 * A product changed: notes it and asks for a partial generation.
	 *
	 * @param mixed $product Product, variation or post id (or the product).
	 */
	public static function changed( $product ): void {
		$id = $product instanceof \WC_Product ? $product->get_id() : (int) $product;
		if ( $id <= 0 || ! in_array( get_post_type( $id ), array( 'product', 'product_variation' ), true ) || ! Feeds::all() ) {
			return;
		}
		$dirty   = (array) get_option( self::DIRTY, array() );
		$dirty[] = $id;
		$parent  = (int) wp_get_post_parent_id( $id );
		if ( $parent > 0 ) {
			$dirty[] = $parent;
		}
		update_option( self::DIRTY, array_values( array_unique( array_map( 'intval', $dirty ) ) ), false );
		if ( function_exists( 'as_has_scheduled_action' ) && function_exists( 'as_schedule_single_action' ) && ! as_has_scheduled_action( self::PARTIAL, array(), self::GROUP ) ) {
			as_schedule_single_action( time() + 2 * MINUTE_IN_SECONDS, self::PARTIAL, array(), self::GROUP );
		}
	}

	/**
	 * A full generation in the background, now (after adding a feed or saving settings).
	 */
	public static function soon(): void {
		if ( function_exists( 'as_enqueue_async_action' ) ) {
			as_enqueue_async_action( self::FULL, array(), self::GROUP );
			return;
		}
		self::full();
	}

	/**
	 * Every feed, from scratch.
	 */
	public static function full(): void {
		delete_option( self::DIRTY );
		foreach ( Feeds::all() as $feed ) {
			$result = Builder::generate( $feed );
			if ( is_wp_error( $result ) ) {
				FeedsModule::gaps()->record( 'generate:' . $feed['id'], $result->get_error_message() );
			}
		}
	}

	/**
	 * Every feed, rebuilding only the products that changed.
	 */
	public static function partial(): void {
		$dirty = array_map( 'intval', (array) get_option( self::DIRTY, array() ) );
		delete_option( self::DIRTY );
		foreach ( Feeds::all() as $feed ) {
			$result = Builder::generate( $feed, Feeds::state( $feed['id'] ) ? $dirty : null );
			if ( is_wp_error( $result ) ) {
				FeedsModule::gaps()->record( 'generate:' . $feed['id'], $result->get_error_message() );
			}
		}
	}
}
