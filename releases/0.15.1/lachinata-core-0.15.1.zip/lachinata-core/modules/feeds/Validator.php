<?php
/**
 * «Descargar y validar» a feed.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Feeds;

defined( 'ABSPATH' ) || exit;

/**
 * Downloads a feed from its public URL, as Merchant Center and Meta will, and checks that
 * it is XML, that it has items and that each item has the fields both destinations need.
 */
final class Validator {

	/**
	 * Fields every item must have.
	 */
	public const REQUIRED = array( 'id', 'title', 'description', 'link', 'image_link', 'availability', 'price', 'brand' );

	/**
	 * Checks a feed's public URL.
	 *
	 * @param array{id: string, segment: string} $feed Feed.
	 * @return array{ok: bool, messages: string[]}
	 */
	public static function check( array $feed ): array {
		$response = wp_remote_get( Files::url( $feed ), array( 'timeout' => 30 ) );
		if ( is_wp_error( $response ) ) {
			return array(
				'ok'       => false,
				/* translators: %s: error. */
				'messages' => array( sprintf( __( 'No se pudo descargar el feed: %s', 'lachinata-core' ), $response->get_error_message() ) ),
			);
		}
		$status = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 !== $status ) {
			return array(
				'ok'       => false,
				/* translators: %d: HTTP status. */
				'messages' => array( sprintf( __( 'La URL del feed responde %d: Merchant Center y Meta no podrán leerla.', 'lachinata-core' ), $status ) ),
			);
		}
		return self::xml( (string) wp_remote_retrieve_body( $response ) );
	}

	/**
	 * Checks the XML of a feed.
	 *
	 * @param string $xml Feed.
	 * @return array{ok: bool, messages: string[]}
	 */
	public static function xml( string $xml ): array {
		$previous = libxml_use_internal_errors( true );
		$document = simplexml_load_string( $xml );
		libxml_use_internal_errors( $previous );
		if ( false === $document || ! isset( $document->channel ) ) {
			return array(
				'ok'       => false,
				'messages' => array( __( 'El feed no es un RSS válido.', 'lachinata-core' ) ),
			);
		}
		$items    = $document->channel->item;
		$count    = count( $items );
		$missing  = array();
		$ids      = array();
		$repeated = 0;
		foreach ( $items as $item ) {
			$fields = $item->children( 'http://base.google.com/ns/1.0' );
			foreach ( self::REQUIRED as $name ) {
				if ( '' === trim( (string) $fields->{$name} ) ) {
					$missing[ $name ] = ( $missing[ $name ] ?? 0 ) + 1;
				}
			}
			$id = (string) $fields->id;
			if ( isset( $ids[ $id ] ) ) {
				++$repeated;
			}
			$ids[ $id ] = true;
		}
		/* translators: %d: items. */
		$messages = array( sprintf( _n( 'XML válido con %d producto.', 'XML válido con %d productos.', $count, 'lachinata-core' ), $count ) );
		foreach ( $missing as $name => $times ) {
			/* translators: 1: field, 2: products. */
			$messages[] = sprintf( __( 'Falta %1$s en %2$d productos.', 'lachinata-core' ), $name, $times );
		}
		if ( $repeated ) {
			/* translators: %d: products. */
			$messages[] = sprintf( __( '%d IDs repetidos: cada producto necesita uno distinto.', 'lachinata-core' ), $repeated );
		}
		return array(
			'ok'       => $count > 0 && ! $missing && 0 === $repeated,
			'messages' => $messages,
		);
	}
}
