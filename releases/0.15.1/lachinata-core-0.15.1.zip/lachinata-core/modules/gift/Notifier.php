<?php
/**
 * The notice to the recipient when the order is shipped.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Gift;

use LaChinata\Core\Company;
use LaChinata\Core\Contracts\Notice;
use LaChinata\Core\Contracts\NoticeResult;
use LaChinata\Core\Contracts\Notifier as Notifications;
use LaChinata\Core\GapLog;
use LaChinata\Core\Hooks;
use LaChinata\Core\Plugin;
use LaChinata\Core\Rest\OrderData;
use LaChinata\Core\Services;
use LaChinata\Core\Settings;
use LaChinata\Core\Tracking\Tracking;

defined( 'ABSPATH' ) || exit;

/**
 * When the order reaches one of the module's statuses («completado» by default: the one
 * Odoo sets when the parcel leaves), the recipient gets the notice by email, WhatsApp or SMS
 * (WhatsApp and SMS through the `notify` module, which may fall back to SMS), once per order. With tracking at that moment (WooCommerce Shipment Tracking, written by Odoo)
 * the notice carries the link; without it, only the dates, counted from the real dispatch
 * day. If the notice fails it is recorded (order note, Huecos de configuración, log) and the
 * order goes on: nothing here may stop a status change.
 */
final class Notifier {

	/**
	 * Runs before WooCommerce's own emails of the same status (priority 10), so the shipping
	 * email to the buyer can say the recipient was notified.
	 */
	private const PRIORITY = 5;

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		foreach ( self::statuses() as $status ) {
			Hooks::add_action( 'woocommerce_order_status_' . $status, array( self::class, 'on_status' ), self::PRIORITY, 2 );
		}
		Hooks::add_action( 'lachinata/notify/fallback', array( self::class, 'on_fallback' ), 10, 3 );
	}

	/**
	 * Statuses that send the notice (setting, without the `wc-` prefix).
	 *
	 * @return string[]
	 */
	public static function statuses(): array {
		$module   = Plugin::instance()->modules()->get( 'gift' );
		$statuses = null === $module ? array() : (array) Settings::get( $module, 'notify_statuses' );
		$statuses = array_values( array_filter( array_map( static fn( $status ): string => sanitize_key( str_replace( 'wc-', '', (string) $status ) ), $statuses ) ) );
		return $statuses ? $statuses : array( 'completed' );
	}

	/**
	 * Status hook.
	 *
	 * @param int   $order_id Order id.
	 * @param mixed $order    Order.
	 */
	public static function on_status( $order_id, $order = null ): void {
		$order = $order instanceof \WC_Order ? $order : wc_get_order( (int) $order_id );
		if ( $order instanceof \WC_Order ) {
			self::notify( $order );
		}
	}

	/**
	 * Sends the notice of an order if it is due.
	 *
	 * @param \WC_Order $order Order.
	 * @return array{at: int, via: string, ok: bool, error: string, link: bool}|null What was done, null when nothing was due.
	 */
	public static function notify( \WC_Order $order ): ?array {
		$gift = Gift::of( $order );
		if ( null === $gift || $gift['legacy'] || 'none' === $gift['via'] || '' === $gift['contact'] || null !== Gift::notified( $order ) ) {
			return null;
		}

		$result   = array(
			'at'    => time(),
			'via'   => $gift['via'],
			'ok'    => false,
			'error' => '',
			'link'  => false,
			'ref'   => '',
		);
		$estimate = null;
		try {
			$tracking       = self::tracking( $order );
			$link           = null !== $tracking ? $tracking['url'] : '';
			$result['link'] = '' !== $link;
			$estimate       = self::estimate( $order, $tracking );
			$carrier        = OrderData::carrier( $order );
			$message        = new Message( $gift['to'], $gift['from'], self::brand(), $estimate, $carrier, self::address( $order ), $link );

			if ( 'email' === $gift['via'] ) {
				$result['error'] = self::email( $order, $message, $gift['contact'] );
			} else {
				$sent            = self::short( $order, $gift, $message, '' !== $link );
				$result['via']   = $sent->channel;
				$result['ref']   = $sent->ref;
				$result['error'] = $sent->error;
				if ( null === $carrier && $sent->ok ) {
					self::carrier_unknown( $order );
				}
			}
			$result['ok'] = '' === $result['error'];
		} catch ( \Throwable $error ) {
			$result['error'] = $error->getMessage();
		}

		$order->update_meta_data( Gift::META_NOTIFIED, $result );
		$order->save_meta_data();
		self::note( $order, $gift, $result );
		Privacy::schedule_erase( $order, $estimate );
		return Gift::notified( $order );
	}

	/**
	 * Sends the notice by email.
	 *
	 * @param \WC_Order $order     Order.
	 * @param Message   $message   Texts.
	 * @param string    $recipient Recipient's email.
	 * @return string Why it did not leave, or empty.
	 */
	private static function email( \WC_Order $order, Message $message, string $recipient ): string {
		$email = WC()->mailer()->get_emails()[ RecipientEmail::ID ] ?? null;
		if ( ! $email instanceof RecipientEmail || ! $email->is_enabled() ) {
			return __( 'el correo «Aviso de regalo» está desactivado en WooCommerce → Ajustes → Correos', 'lachinata-core' );
		}
		return $email->trigger( $order, $message, $recipient ) ? '' : __( 'WordPress no pudo enviar el correo', 'lachinata-core' );
	}

	/**
	 * Latest tracking of the order (core: WooCommerce Shipment Tracking), or null.
	 *
	 * @param \WC_Order $order Order.
	 * @return array{carrier: string, number: string, url: string, shipped: int|null}|null
	 */
	public static function tracking( \WC_Order $order ): ?array {
		return Tracking::of( $order );
	}

	/**
	 * Sends the notice by WhatsApp or SMS through the `notify` module: the template
	 * `lc_regalo_aviso` (Hola, {{1}}. {{2}} te envía un regalo de La Chinata: llega {{3}} con
	 * {{4}}…) with the short link as its button, or the SMS of Message::sms().
	 *
	 * @param \WC_Order                                                                                    $order   Order.
	 * @param array{to: string, message: string, via: string, contact: string, from: string, legacy: bool} $gift    Gift.
	 * @param Message                                                                                      $message Texts.
	 * @param bool                                                                                         $link    With tracking.
	 */
	private static function short( \WC_Order $order, array $gift, Message $message, bool $link ): NoticeResult {
		$notifier = Services::notifier();
		if ( null === $notifier ) {
			return new NoticeResult( $gift['via'], false, '', __( 'el módulo Avisos está apagado', 'lachinata-core' ) );
		}
		$notice = new Notice(
			Notice::GIFT,
			$order,
			$gift['contact'],
			$message->whatsapp_params(),
			$link,
			$message->sms( $link ? $notifier->short_link( $order ) : '' ),
			'gift'
		);
		return $notifier->send( 'sms' === $gift['via'] ? Notifications::SMS : Notifications::WHATSAPP, $notice );
	}

	/**
	 * The notice went with «nuestro transportista»: a gap of the map instance → carrier.
	 *
	 * @param \WC_Order $order Order.
	 */
	public static function carrier_unknown( \WC_Order $order ): void {
		$line = current( $order->get_items( 'shipping' ) );
		/**
		 * A notice left without the carrier's name: the shipping instance of the order has no
		 * carrier in the map (module `odoo`).
		 *
		 * @since 0.8.0
		 *
		 * @param int       $instance_id Shipping instance id.
		 * @param \WC_Order $order       Order.
		 */
		do_action( 'lachinata/order/carrier_unknown', $line instanceof \WC_Order_Item_Shipping ? (int) $line->get_instance_id() : 0, $order );
	}

	/**
	 * WhatsApp could not deliver the notice and `notify` sent it by SMS: the note and the
	 * record say so.
	 *
	 * @param mixed $order  Order.
	 * @param mixed $kind   Notice kind.
	 * @param mixed $result What happened to the SMS.
	 */
	public static function on_fallback( $order, $kind = '', $result = null ): void {
		if ( ! $order instanceof \WC_Order || Notice::GIFT !== $kind || ! $result instanceof NoticeResult ) {
			return;
		}
		$gift = Gift::of( $order );
		$sent = Gift::notified( $order );
		if ( null === $gift || null === $sent ) {
			return;
		}
		if ( $result->ok ) {
			$order->update_meta_data( Gift::META_NOTIFIED, array_merge( (array) $order->get_meta( Gift::META_NOTIFIED ), array( 'via' => 'sms' ) ) );
			$order->save_meta_data();
		}
		$order->add_order_note(
			$result->ok
				/* translators: %s: recipient. */
				? sprintf( __( 'Regalo: el WhatsApp a %s no se pudo entregar; el aviso ha salido por SMS.', 'lachinata-core' ), $gift['to'] )
				/* translators: 1: recipient, 2: reason. */
				: sprintf( __( 'Regalo: el WhatsApp a %1$s no se pudo entregar y el SMS tampoco salió (%2$s).', 'lachinata-core' ), $gift['to'], $result->error )
		);
	}

	/**
	 * «+34600•••233»: a mobile in notes.
	 *
	 * @param string $number Mobile.
	 */
	public static function mask( string $number ): string {
		return strlen( $number ) > 6 ? substr( $number, 0, -6 ) . '•••' . substr( $number, -3 ) : '•••';
	}

	/**
	 * Configuration gaps of the module.
	 */
	public static function gaps(): GapLog {
		return new GapLog( 'lachinata_gift_gaps', 'lachinata-gift' );
	}

	/**
	 * Delivery dates counted from the real dispatch day (the tracking's, or today), with the
	 * eta module; null without it.
	 *
	 * @param \WC_Order                                                                   $order    Order.
	 * @param array{carrier: string, number: string, url: string, shipped: int|null}|null $tracking Tracking.
	 */
	private static function estimate( \WC_Order $order, ?array $tracking ): ?\LaChinata\Core\Delivery\Estimate {
		$delivery = Services::delivery();
		if ( null === $delivery ) {
			return null;
		}
		$zone  = wp_timezone();
		$ships = null !== $tracking && null !== $tracking['shipped']
			? ( new \DateTimeImmutable( '@' . $tracking['shipped'] ) )->setTimezone( $zone )
			: new \DateTimeImmutable( 'now', $zone );
		return $delivery->shipped( $order, $ships );
	}

	/**
	 * Name of the shop in the emails («La Chinata»): the trade name of Datos de la empresa,
	 * else the sender of WooCommerce's emails, else the site name.
	 */
	public static function brand(): string {
		$company = Company::get()['trade_name'];
		if ( '' !== $company ) {
			return $company;
		}
		$name = trim( wp_specialchars_decode( (string) get_option( 'woocommerce_email_from_name' ), ENT_QUOTES ) );
		return '' !== $name ? $name : Company::trade_name();
	}

	/**
	 * «Calle Mayor 3, Plasencia».
	 *
	 * @param \WC_Order $order Order.
	 */
	private static function address( \WC_Order $order ): string {
		return implode( ', ', array_filter( array( trim( $order->get_shipping_address_1() ), trim( $order->get_shipping_city() ) ) ) );
	}

	/**
	 * Order note (private) and, on failure, a configuration gap.
	 *
	 * @param \WC_Order                                                $order  Order.
	 * @param array{to: string, via: string, contact: string}          $gift   Gift.
	 * @param array{ok: bool, error: string, link: bool, via?: string} $result Result.
	 */
	private static function note( \WC_Order $order, array $gift, array $result ): void {
		$via     = (string) ( $result['via'] ?? $gift['via'] );
		$channel = array(
			'sms'      => __( 'SMS', 'lachinata-core' ),
			'whatsapp' => __( 'WhatsApp', 'lachinata-core' ),
		)[ $via ] ?? __( 'correo', 'lachinata-core' );
		$contact = 'email' === $via ? $gift['contact'] : self::mask( $gift['contact'] );
		if ( $result['ok'] ) {
			$order->add_order_note(
				$result['link']
					/* translators: 1: recipient, 2: channel (correo, SMS), 3: email or masked mobile. */
					? sprintf( __( 'Regalo: aviso enviado a %1$s por %2$s (%3$s), con el enlace de seguimiento.', 'lachinata-core' ), $gift['to'], $channel, $contact )
					/* translators: 1: recipient, 2: channel (correo, SMS), 3: email or masked mobile. */
					: sprintf( __( 'Regalo: aviso enviado a %1$s por %2$s (%3$s), sin seguimiento: solo con la fecha.', 'lachinata-core' ), $gift['to'], $channel, $contact )
			);
			return;
		}
		/* translators: 1: recipient, 2: channel (correo, SMS), 3: reason. */
		$text = sprintf( __( 'Regalo: no se pudo avisar a %1$s por %2$s (%3$s). El pedido sigue su curso; no se volverá a intentar.', 'lachinata-core' ), $gift['to'], $channel, $result['error'] );
		$order->add_order_note( $text );
		self::gaps()->record(
			'notify|' . $gift['via'] . '|' . md5( $result['error'] ),
			/* translators: 1: channel, 2: reason. */
			sprintf( __( 'Un aviso de regalo por %1$s no salió: %2$s.', 'lachinata-core' ), $channel, $result['error'] ),
			array( 'order' => $order->get_id() )
		);
	}
}
