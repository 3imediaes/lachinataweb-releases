# Módulo `gift`

«¿Es un regalo?» en el checkout: nombre de quien lo recibe, mensaje escrito a mano en la tarjeta y **aviso al destinatario** por correo, WhatsApp o SMS cuando sale el paquete, para que nadie rechace un paquete que no ha pedido. Sin contenido ni precio.

Especificación: `design-system/sistema/04-envios-entrega.md` («Regalos»), componente `GiftOption`, tableros Regalo, Checkout y CheckoutDesktop. Decisiones del 24/10/2026 en `design-system/docs/decisiones.md` («Regalo y Odoo»): no hay albarán ni «sin precios» (ningún paquete lleva precios), «De parte de» vacío para invitados, un solo aviso por pedido, SMS por OVH.

Necesita los módulos `checkout` (pinta el hueco de la tarjeta) y `notify` (dice qué canales están activos y envía el WhatsApp y el SMS; 0.8.0). Ajustes: WooCommerce → La Chinata → Regalo; canales y credenciales, en Avisos. Paso a producción: `docs/despliegue-gift-odoo.md` y `docs/despliegue-notify-tracking.md`.

## Qué hace
| Pieza | Cómo | Dónde |
| --- | --- | --- |
| Tarjeta «¿Es un regalo?» entre Envío y Facturación: `CheckoutSection` plegada (`lc-chk lc-chk--quiet`, borde discontinuo) con `GiftOption` dentro, el marcado `.lc-gift*` del bundle. Al marcar «Es un regalo» se abre y deja de ser `--quiet`. Sin una bolsa que se envíe, no se pinta | *Fill* del *slot* `lachinata/checkout/gift` del módulo `checkout` (`registerPlugin`, ámbito `woocommerce-checkout`). El `Fill` de WooCommerce clona su hijo con los props del hueco (`cart`, `extensions`) y lo envuelve en un `div`; el tema lo hace transparente (`display: contents`) | `src/index.js`, `Integration.php`; `theme/assets/css/checkout.css` |
| **Para** (precargado con el nombre de la dirección de entrega y lo sigue mientras no se toque), **Tu mensaje** (200 caracteres), **Avisar a quien lo recibe**: un chip por canal activo en Avisos (Por correo · Por WhatsApp · Por SMS, en ese orden) y No avisar (chips con `aria-pressed`; sin ningún canal activo, el bloque no se pinta), correo o móvil («Le escribiremos desde el WhatsApp de La Chinata.» bajo el móvil con WhatsApp), **De parte de** (vacío con su placeholder; con sesión, el nombre de la cuenta) y «Solo usaremos este dato para el aviso del regalo.» | Datos de extensión de la Store API (`setExtensionData( 'lachinata-gift', … )`); errores en el store de validación de WooCommerce (`wc/store/validation`): bloquean «Pagar» y salen bajo cada campo | `src/index.js` |
| Validación en el servidor: canal entre los activos; Para obligatorio; correo válido; móvil en formato internacional (en España, solo móviles 6/7); De parte de obligatorio si se avisa; mensaje ≤ 200. «No avisar» + De parte de vacío = regalo anónimo | `woocommerce_store_api_checkout_update_order_from_request`; un campo mal para el pedido con `RouteException` y la misma frase de la tarjeta | `Checkout.php`, `Gift::validate()`, `LaChinata\Core\Phone` |
| Sugerencia (`Notice` info, «¿Es un regalo? Podemos avisar a María…») mientras la casilla está sin marcar: con sesión, si la entrega no es la dirección guardada del cliente; sin sesión, si la facturación es «Usar otra dirección» distinta de la entrega | Direcciones del store de la bolsa y `getUseShippingAsBilling()` | `src/index.js` |
| Metadatos del pedido: `_lc_regalo` (`yes`), `_lc_regalo_para`, `_lc_regalo_mensaje`, `_lc_regalo_aviso` (`email`/`whatsapp`/`sms`/`none`), `_lc_regalo_contacto`, `_lc_regalo_de`; `_lc_regalo_consentimiento` (registro del consentimiento: canal elegido, cuándo y canales ofrecidos); internos `_lc_regalo_avisado` (cuándo, vía, resultado, si llevaba enlace) y `_lc_regalo_contacto_borrado`. El enlace corto es de `notify` (`_lc_enlace`; se sigue leyendo `_lc_regalo_enlace`) | `Gift::store()` | `Gift.php` |
| Pedidos de la web actual: el campo ACF `nota_cliente` (grupo Pedido; no hay casilla de regalo) se lee como regalo sin aviso, con esa nota como mensaje (`legacy: true` en la API) | `Gift::of()` | `Gift.php` |
| API para Odoo: `lachinata.gift` (información del pedido; no pide ninguna acción) | Filtro `lachinata/rest/order` | `Gift::rest_data()`; contrato en `docs/api-odoo.md` |
| Marca «Regalo» en la lista de pedidos (HPOS y entradas) y, en el pedido, bajo la dirección de envío: Para, mensaje para la tarjeta y estado del aviso | `manage_woocommerce_page_wc-orders_*`, `manage_edit-shop_order_columns`, `woocommerce_admin_order_data_after_shipping_address` | `Orders.php` |
| Correos, con el marco del tema (`06-correos.md`): en el interno, etiqueta «Regalo», «· regalo» en el asunto y la nota «Regalo para María · aviso por WhatsApp» con el mensaje y «De parte de»; al comprador, en la confirmación la nota «Es un regalo para María López» («Llevará tu mensaje escrito a mano. Avisaremos a María por WhatsApp cuando salga el paquete.») y en el de enviado «Hemos avisado a María López» (solo si el aviso salió). Con otro tema, la misma nota al principio del detalle del pedido de WooCommerce | Huecos del tema `lachinata/email/before_lines`, `after_title`, `subject`; sin marco (`lachinata/email/frame`), `woocommerce_email_order_details` prioridad 5 | `Emails.php` |
| Gracias: «Es un regalo para María», «Con tu mensaje escrito a mano en la tarjeta.» y «Le avisaremos por correo cuando salga el paquete.», bajo la fecha de entrega (tablero Regalo, 7) | Hueco del tema `lachinata/thankyou/gift` (`theme/HOOKS.md`), clases `lc-thanks__when lc-thanks__gift` | `Orders::thankyou()`; tinta `tint-regalos` en `theme/assets/css/theme.css` |
| **Aviso al destinatario** al pasar el pedido a uno de los estados del ajuste (por defecto «Completado», el que pone Odoo). Uno por pedido; si falla, nota en el pedido, Huecos de configuración y registro `lachinata-gift`, y el pedido sigue | `woocommerce_order_status_<estado>`, prioridad 5 (antes de los correos de WooCommerce del mismo estado) | `Notifier.php` |
| Correo «{De parte de} te envía un regalo de {tienda}» (tablero «Correos transaccionales», 3): eyebrow «Un regalo para ti», saludo con el nombre de pila, «No tienes que pagar nada ni hacer nada: solo recogerlo», datos clave **Llega** (fechas, «Con Correos Express») y **A** (dirección), botón secundario «Seguir el paquete» solo con seguimiento, «Si no vas a estar…» y por qué recibe el correo; sin nada del pedido ni «¿Alguna duda?». Sale por la salida y el remitente de WooCommerce y se puede apagar o retitular en WooCommerce → Ajustes → Correos («Aviso de regalo»). Con otro tema, el texto completo en frases | `WC_Email` propio sobre el marco (filtros `lachinata/email/intro`, `facts`, `button`, `layout`, `footer_note`) | `RecipientEmail.php`, `Emails.php`, `templates/emails/` |
| **WhatsApp** con la plantilla aprobada `lc_regalo_aviso` (o `_sin_enlace` sin seguimiento): nombre de pila, «De parte de», fechas («en los próximos días» sin `eta`) y transportista («nuestro transportista» si falta en el mapa; se anota con `lachinata/order/carrier_unknown` y lo ve el panel de Odoo); el botón lleva el enlace corto. Si WhatsApp no puede entregarlo, `notify` lo manda por SMS una vez y la nota del pedido lo cuenta | `Contracts\Notifier::send()` (`notify`) | `Notifier.php`, `Message::whatsapp_params()` |
| SMS con el mismo texto corto, como mucho dos segmentos UCS-2 (≤ 134 caracteres), por `notify` (OVH) | `Message::sms()`: si no cabe, quita el transportista, luego «No tienes que pagar nada.», luego el saludo y por último acorta «De parte de»; nunca la fecha ni el enlace | `Message.php` |
| Fecha del aviso: el plazo del método desde el día real de salida (la fecha de salida del seguimiento o hoy), con los festivos y días sin reparto del motor; sin plan, la guardada en el pedido. Sin el módulo `eta`, sin fecha | `Eta\Rates::shipped()`, `Eta\Calculator::from_dispatch()` | `Notifier::estimate()` |
| Transportista del texto: el del mapa del módulo `odoo` | Filtro del núcleo `lachinata/order/carrier` (`OrderData::carrier()`) | — |
| Seguimiento: el de WooCommerce Shipment Tracking (lo escribe Odoo por su API REST), leído por el núcleo (`LaChinata\Core\Tracking\Tracking`, fuentes en `lachinata/shipment/sources`; `lachinata/tracking/sources` y `lachinata/gift/tracking_sources` quedan obsoletos) | `_wc_shipment_tracking_items`, último elemento; el enlace que forma la extensión o, sin ella, la plantilla del proveedor propio rellenada igual (`%1$s` número, `%2$s` CP, `%3$s` país, `%4$s` pedido) | `plugin/src/Tracking/` |
| Datos personales: el contacto del destinatario solo en el pedido (no crea cuenta, no va a ninguna lista). Se borra N días (ajuste, 30) después de la última fecha de entrega, o del cierre si el pedido se cancela, se reembolsa o falla. Texto para la guía de privacidad de WordPress (borrador provisional, `{dias}` se sustituye) y borrador de datos personales: por el correo del comprador borra los contactos de sus regalos; por el del destinatario, también su nombre | Action Scheduler (`lachinata/gift/erase_contact`), `wp_add_privacy_policy_content`, `wp_privacy_personal_data_erasers`; también el móvil del registro de `notify` (`forget()`) | `Privacy.php` |

Casos límite: un regalo por pedido; entrega al propio comprador sin detección automática (lo cubre «No avisar»); un pedido que pasa de nuevo a «Completado» no repite el aviso.

## Seguimiento que llega después del cambio de estado
WooCommerce Shipment Tracking 2.6.3 no dispara ninguna acción propia al añadir un seguimiento: su API REST llama a `add_tracking_item()`, que pasa el filtro `wc_shipment_tracking_before_add_tracking_items` y guarda el pedido (`woocommerce_update_order`). Según lo decidido, el aviso sale al cambiar de estado con lo que haya en ese momento: si Odoo escribe el seguimiento después de marcar «Completado», el aviso lleva solo la fecha. Para que lleve el enlace, Odoo debe escribir el seguimiento **antes** de cambiar el estado (`docs/despliegue-gift-odoo.md`). Si hiciera falta esperar al seguimiento, el punto de enganche sería `woocommerce_update_order`.

## Depende de

- `checkout` (pinta el hueco de la tarjeta) y `notify` (canales y envío del WhatsApp y el SMS, por `Contracts\Notifier`): los dos en `requires`.
- `eta`, opcional, por `Contracts\DeliveryEstimator` (`Services::delivery()`): la fecha desde la salida real. Sin él, la fecha guardada en el pedido (`_lc_eta`) o ninguna.
- `odoo`, opcional, por el filtro `lachinata/order/carrier`: el nombre del transportista. Sin él, «nuestro transportista».
- Seguimiento: núcleo (`Tracking`).

## Hooks que escucha

- Checkout: `woocommerce_blocks_checkout_block_registration` (script), `woocommerce_blocks_loaded` (datos de la Store API `lachinata-gift`), `woocommerce_store_api_checkout_update_order_from_request` (valida y guarda).
- Pedido: `woocommerce_order_status_<estado>` (prioridad 5, el aviso), columnas y caja del pedido en el panel, `woocommerce_email_classes`, `woocommerce_email_order_details` (sin marco).
- Del tema: `lachinata/email/*` (intro, facts, button, layout, subject, footer_note, footer_line, footer_links, after_title, before_lines) y `lachinata/thankyou/gift`.
- De otros módulos y del núcleo: `lachinata/notify/fallback`, `lachinata/rest/order`, `lachinata/core/admin_tabs`.
- Privacidad: `admin_init` (texto de la guía), `wp_privacy_personal_data_erasers`, la tarea `lachinata/gift/erase_contact`.

## Hooks que emite

| Hook | Tipo | Para qué |
| --- | --- | --- |
| `lachinata/order/carrier_unknown` `( int $instance_id, WC_Order $order )` | acción | El aviso salió con «nuestro transportista» (`odoo` lo anota) |
| `lachinata/email/frame` | filtro (lo lee) | Si el tema pinta el marco; sin él, el aviso va completo en frases |

Catálogo: `plugin/HOOKS.md`.

## Datos que guarda

- Metadatos de pedido `_lc_regalo*` (tabla de arriba; catálogo en `plugin/HOOKS.md`). `shipment` lee `_lc_regalo` para no mandar nunca su WhatsApp a un regalo.
- Opciones `lachinata_gift_*`: ajustes y registro de huecos (`lachinata_gift_gaps`). Las credenciales de OVH de la 0.7 (`lachinata_gift_ovh_*`) se quedan donde estaban: la 0.8.0 las copió a `notify` sin borrarlas.
- Fecha de borrado del contacto en el pedido: `_lc_gift_erase_at` (0.9.0; la primera meta con la convención `_lc_<módulo>_*`).
- Action Scheduler, grupo `lachinata-gift`: el borrado de cada contacto en su fecha (`lachinata/gift/erase_contact`) y un barrido diario (`lachinata/gift/erase_due`) que borra los contactos vencidos, también los que vencieron con el módulo apagado.
- Versión de datos 2 (0.9.0). La migración 2 pone `_lc_gift_erase_at` a los borrados programados antes de la 0.9.0. Es idempotente y no borra nada.

## REST y API para Odoo

- `lachinata.gift` del objeto de la API de pedidos (información del pedido, sin acción en Odoo): `docs/api-odoo.md`.
- Datos de extensión de la Store API `lachinata-gift` en el checkout. Sin rutas propias.

## Ajustes y exportación
| Ajuste | Por defecto | En el JSON |
| --- | --- | --- |
| Estados que envían el aviso (`notify_statuses`) | `completed` | sí |
| Días hasta borrar el contacto (`erase_days`) | 30 | sí |
| Texto de privacidad (`privacy_text`) | vacío = borrador provisional (`Privacy::DRAFT`) | sí |
| Enlace «¿Qué es La Chinata?» del correo (`about_url`) | vacío = portada | no |

Los canales, sus credenciales y la prueba están en Avisos (módulo `notify`); las credenciales de OVH de la 0.7.0 pasan allí al actualizar.


El módulo no tiene `export_data()`: solo viajan los ajustes marcados.

## Qué pasa al apagarlo

La tarjeta «¿Es un regalo?» desaparece del checkout (el hueco queda vacío), no salen avisos y las notas de regalo dejan de salir en correos y gracias. Los pedidos conservan sus metadatos y Odoo sigue viendo `lachinata.gift` de los antiguos. Un borrado de contacto que vence con el módulo apagado se pierde en Action Scheduler (nadie escucha), pero la fecha está en el pedido: al encenderlo, el barrido diario lo hace. Si el módulo se queda apagado para siempre, los contactos pendientes siguen en los pedidos: enciéndelo un día para que el barrido los borre. «Borrar datos» quita los ajustes, nunca los datos de los pedidos.

## Pruebas
- PHP: `tests/GiftTest.php` (validación, metadatos con sus nombres, API, `nota_cliente`, móviles, SMS en dos segmentos con la cascada, textos del correo, plantilla del enlace de seguimiento), `tests/NotifierTest.php` (aviso una sola vez al completar, WhatsApp con su plantilla y «nuestro transportista», canal apagado rechazado, correo con seguimiento y transportista con y sin el marco del tema, enlace corto, fallo que no bloquea, nada que enviar, correos a la tienda y al comprador, piezas del marco, borrado diferido, borrador de datos personales); el proveedor de OVH, en `notify`; en `eta`, `CalculatorTest::test_from_dispatch_counts_only_transit`; en el núcleo, `OrderDataTest::test_object_with_gift_and_carrier`.
- e2e: `tests/e2e/gift.spec.mjs` (activar, validar, pagar y gracias; regalo anónimo; sugerencia) y la tarjeta en `tests/e2e/checkout-cards.spec.mjs` (orden, separación y radios a 390 y 1440).

Desde la 0.9.0 los tests del módulo usan un doble de `Contracts\Notifier` (`plugin/tests/Doubles/FakeNotifier.php`) y el transportista por el filtro, sin clases de `notify` ni de `odoo`. La pareja real (SMS y WhatsApp en registro, plantillas, enlace corto, proveedor de OVH que falla, mapa de `odoo`) está en `tests/profiles/GiftNotifyTest.php`; el objeto de la API con el regalo, en `tests/profiles/OrderDataTest.php`.

## Huecos conocidos

- Segundo aviso el día de la entrega y aviso al comprador por entrega fallida: dependen de una fuente de datos del transportista (`shipment`, apagado).
- Texto de privacidad: borrador provisional, lo revisa Alberto.
- Las plantillas Regalo, Checkout y CheckoutDesktop del sistema aún dicen «sin precios» (pendiente del equipo de diseño).
