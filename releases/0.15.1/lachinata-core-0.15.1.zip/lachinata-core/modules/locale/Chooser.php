<?php
/**
 * Choosing a destination: the picker's form and the arrival from another shop.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Locale;

use LaChinata\Core\Hooks;
use LaChinata\Core\Services;

defined( 'ABSPATH' ) || exit;

/**
 * The picker is a POST form, with and without JavaScript. A destination of this shop is
 * kept and the page reloads; one of another shop redirects (302) to the same path in that
 * shop with `?destino=<id>`, which the other shop accepts if the destination is its own.
 * The host always comes from the saved configuration, never from the request; the path is
 * only a path. Without a nonce (the page is cached and it is only a preference): a request
 * whose Origin or Referer is another site is ignored.
 */
final class Chooser {

	/**
	 * Field that marks the picker's form.
	 */
	public const ACTION = 'lc_locale';

	/**
	 * Arrival parameter.
	 */
	public const ARRIVAL = 'destino';

	/**
	 * Parameter that opens the picker without JavaScript.
	 */
	public const OPEN = 'lc-destino';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'wp_loaded', array( self::class, 'handle' ), 20 );
		Hooks::add_action( 'template_redirect', array( self::class, 'arrival' ), 1 );
		Hooks::add_filter( 'allowed_redirect_hosts', array( self::class, 'allowed_hosts' ) );
	}

	/**
	 * The picker's form.
	 */
	public static function handle(): void {
		$method = isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_key( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- A preference on cached pages: same_origin() instead of a nonce (decisiones.md, incremento 8).
		if ( 'post' !== $method || empty( $_POST[ self::ACTION ] ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- As above; every field is validated in resolve().
		wp_safe_redirect( self::resolve( wp_unslash( $_POST ) ), 302 );
		exit;
	}

	/**
	 * Keeps what the form chose and says where to go: «Otro país» wins over the list.
	 *
	 * @param array<string, mixed> $post Posted fields, unslashed.
	 */
	public static function resolve( array $post ): string {
		$field       = static fn( string $key ): string => isset( $post[ $key ] ) && is_string( $post[ $key ] ) ? sanitize_text_field( $post[ $key ] ) : '';
		$path        = self::return_path( '' === $field( 'lc_ruta' ) ? '/' : $field( 'lc_ruta' ) );
		$other       = $field( 'lc_destino_otro' );
		$destination = self::same_origin() ? Config::find( '' !== $other ? $other : $field( 'lc_destino' ) ) : null;
		if ( null !== $destination && '' === $destination['store'] ) {
			Visitor::choose( $destination );
		}
		$language = $field( Visitor::LANGUAGE );
		if ( self::same_origin() && in_array( $language, Services::languages()->languages(), true ) ) {
			Visitor::set_cookie( Visitor::LANGUAGE, $language, YEAR_IN_SECONDS );
		}
		return self::target( $destination, $path, $language );
	}

	/**
	 * Where the visitor goes after choosing: the same path here, or in the other shop with
	 * the destination in the address.
	 *
	 * @param array{id: string, store: string}|null $destination Destination, null to stay.
	 * @param string                                $path        Path relative to the home.
	 * @param string                                $language    Language chosen, '' for none.
	 */
	public static function target( ?array $destination, string $path, string $language = '' ): string {
		$store = null === $destination || '' === $destination['store'] ? null : Config::store( $destination['store'] );
		if ( null === $store ) {
			$url       = home_url( $path );
			$languages = Services::languages();
			return '' !== $language && in_array( $language, $languages->languages(), true ) ? $languages->url( $url, $language ) : $url;
		}
		return esc_url_raw( add_query_arg( self::ARRIVAL, rawurlencode( (string) $destination['id'] ), $store['url'] . $path ) );
	}

	/**
	 * A path relative to the home, without our parameters; «/» for anything that is not a
	 * plain path (another host, a scheme, «//»).
	 *
	 * @param string $raw Path and query as posted.
	 */
	public static function return_path( string $raw ): string {
		$parts = wp_parse_url( $raw );
		if ( ! is_array( $parts ) || isset( $parts['scheme'] ) || isset( $parts['host'] ) ) {
			return '/';
		}
		$path = (string) ( $parts['path'] ?? '/' );
		if ( '' === $path || '/' !== $path[0] || str_starts_with( $path, '//' ) || str_contains( $path, '\\' ) ) {
			return '/';
		}
		$home = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		if ( '' !== $home && '/' !== $home && str_starts_with( $path, $home ) ) {
			$path = '/' . substr( $path, strlen( $home ) );
		}
		$query = array();
		wp_parse_str( (string) ( $parts['query'] ?? '' ), $query );
		unset( $query[ self::ARRIVAL ], $query[ self::OPEN ] );
		return $path . ( $query ? '?' . http_build_query( $query ) : '' );
	}

	/**
	 * Whether the request comes from this site: an Origin or, without it, a Referer of
	 * another host makes it foreign. Without either (a privacy setting), it is accepted.
	 */
	public static function same_origin(): bool {
		$home = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		foreach ( array( 'HTTP_ORIGIN', 'HTTP_REFERER' ) as $header ) {
			if ( empty( $_SERVER[ $header ] ) ) {
				continue;
			}
			$host = wp_parse_url( sanitize_text_field( wp_unslash( $_SERVER[ $header ] ) ), PHP_URL_HOST );
			return is_string( $host ) && strtolower( $host ) === strtolower( $home );
		}
		return true;
	}

	/**
	 * Arrival from another shop (`?destino=ES-CN`): a destination of this shop is kept;
	 * then the address loses the parameter (302), or goes to the home when the path does
	 * not exist here.
	 */
	public static function arrival(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only a preference, validated against the configuration.
		$raw = isset( $_GET[ self::ARRIVAL ] ) ? sanitize_text_field( wp_unslash( $_GET[ self::ARRIVAL ] ) ) : '';
		if ( '' === $raw || is_admin() ) {
			return;
		}
		$destination = Config::find( $raw );
		if ( null !== $destination && '' === $destination['store'] ) {
			Visitor::choose( $destination );
		}
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/';
		wp_safe_redirect( is_404() ? home_url( '/' ) : home_url( self::return_path( $uri ) ), 302 );
		exit;
	}

	/**
	 * The other shops are the only hosts the picker redirects to.
	 *
	 * @param string[] $hosts Allowed hosts.
	 * @return string[]
	 */
	public static function allowed_hosts( $hosts ): array {
		return array_merge( is_array( $hosts ) ? $hosts : array(), Config::hosts() );
	}
}
