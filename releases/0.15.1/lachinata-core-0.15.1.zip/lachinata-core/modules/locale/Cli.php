<?php
/**
 * WP-CLI: wp lachinata locale.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Locale;

defined( 'ABSPATH' ) || exit;

/**
 * Destinations and the catalogue by destination.
 */
final class Cli {

	/**
	 * Lists the destinations: id, label, shop, list and WooCommerce place.
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata locale list
	 *
	 * @subcommand list
	 *
	 * @param string[]              $args       Positional arguments.
	 * @param array<string, string> $assoc_args Options.
	 */
	public function list_( array $args, array $assoc_args ): void {
		unset( $args, $assoc_args );
		$rows = array();
		foreach ( Config::destinations() as $destination ) {
			$store  = '' === $destination['store'] ? null : Config::store( $destination['store'] );
			$place  = Config::location( $destination );
			$rows[] = array(
				'id'          => $destination['id'],
				'label'       => $destination['label'],
				'tienda'      => null === $store ? __( 'esta', 'lachinata-core' ) : $store['url'],
				'lista'       => $destination['list'],
				'woocommerce' => $place['country'] . ( '' === $place['state'] ? '' : ':' . implode( ',', $destination['states'] ) ),
			);
		}
		\WP_CLI\Utils\format_items( 'table', $rows, array( 'id', 'label', 'tienda', 'lista', 'woocommerce' ) );
	}

	/**
	 * Recalculates which products do not ship to each destination.
	 *
	 * ## OPTIONS
	 *
	 * [--now]
	 * : Recalculates here instead of in the background.
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata locale reindex --now
	 *
	 * @param string[]              $args       Positional arguments.
	 * @param array<string, string> $assoc_args Options.
	 */
	public function reindex( array $args, array $assoc_args ): void {
		unset( $args );
		if ( ! isset( $assoc_args['now'] ) ) {
			Catalog::schedule();
			\WP_CLI::success( __( 'El catálogo se recalculará en segundo plano.', 'lachinata-core' ) );
			return;
		}
		$offset = 0;
		do {
			$done    = Catalog::run_batch( $offset, false );
			$offset += $done;
		} while ( Catalog::BATCH === $done );
		/* translators: %d: number of products. */
		\WP_CLI::success( sprintf( __( 'Catálogo recalculado: %d productos.', 'lachinata-core' ), $offset ) );
	}
}
