<?php
/**
 * Destinations and other shops of the site.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Locale;

defined( 'ABSPATH' ) || exit;

/**
 * What the visitor can choose. A destination is an ISO 3166-1 or 3166-2 id («PT», «ES-IB»),
 * with its label, an optional note, the shop it belongs to (this one, or one of the other
 * shops) and whether it goes in the main list or in «Otro país». A country row without
 * subdivision («ES») means the country except the subdivisions that have their own row.
 * Each row resolves to WooCommerce's country and states («ES-CN» → ES:GC, ES:TF), which is
 * what the cart, the zones and the delivery estimate understand.
 *
 * Nothing of any shop is here: without a saved configuration, the destinations are the
 * countries WooCommerce sells to, with no notes and no other shops.
 */
final class Config {

	/**
	 * Option with the destinations.
	 */
	public const DESTINATIONS = 'lachinata_locale_destinations';

	/**
	 * Option with the other shops.
	 */
	public const STORES = 'lachinata_locale_stores';

	/**
	 * Rows of the main list.
	 */
	public const MAIN_MAX = 8;

	/**
	 * ISO 3166-2 communities of Spain and WooCommerce's provinces in each one. Standard
	 * data, not a shop's: any other subdivision maps to the WooCommerce state with its code.
	 */
	private const ES_REGIONS = array(
		'AN' => array( 'AL', 'CA', 'CO', 'GR', 'H', 'J', 'MA', 'SE' ),
		'AR' => array( 'HU', 'TE', 'Z' ),
		'AS' => array( 'O' ),
		'CB' => array( 'S' ),
		'CE' => array( 'CE' ),
		'CL' => array( 'AV', 'BU', 'LE', 'P', 'SA', 'SG', 'SO', 'VA', 'ZA' ),
		'CM' => array( 'AB', 'CR', 'CU', 'GU', 'TO' ),
		'CN' => array( 'GC', 'TF' ),
		'CT' => array( 'B', 'GI', 'L', 'T' ),
		'EX' => array( 'BA', 'CC' ),
		'GA' => array( 'C', 'LU', 'OR', 'PO' ),
		'IB' => array( 'PM' ),
		'MC' => array( 'MU' ),
		'MD' => array( 'M' ),
		'ML' => array( 'ML' ),
		'NC' => array( 'NA' ),
		'PV' => array( 'BI', 'SS', 'VI' ),
		'RI' => array( 'LO' ),
		'VC' => array( 'A', 'CS', 'V' ),
	);

	/**
	 * Memo of the destinations for the request.
	 *
	 * @var array<int, array{id: string, label: string, note: string, store: string, list: string, states: string[]}>|null
	 */
	private static ?array $memo = null;

	/**
	 * Every destination, in the order of the panel.
	 *
	 * @return array<int, array{id: string, label: string, note: string, store: string, list: string, states: string[]}>
	 */
	public static function destinations(): array {
		if ( null === self::$memo ) {
			$saved      = get_option( self::DESTINATIONS, null );
			self::$memo = is_array( $saved ) ? self::clean( $saved, self::stores() )['destinations'] : self::defaults();
		}
		return self::$memo;
	}

	/**
	 * The other shops: id, name and address.
	 *
	 * @return array<int, array{id: string, name: string, url: string}>
	 */
	public static function stores(): array {
		$saved = get_option( self::STORES, array() );
		return is_array( $saved ) ? self::clean_stores( $saved ) : array();
	}

	/**
	 * Forgets the memo (after saving, and in the tests).
	 */
	public static function forget(): void {
		self::$memo = null;
	}

	/**
	 * A destination by id, or null.
	 *
	 * @param string $id Id.
	 * @return array{id: string, label: string, note: string, store: string, list: string, states: string[]}|null
	 */
	public static function find( string $id ): ?array {
		$id = self::normalize_id( $id );
		foreach ( self::destinations() as $destination ) {
			if ( $destination['id'] === $id ) {
				return $destination;
			}
		}
		return null;
	}

	/**
	 * A shop by id, or null.
	 *
	 * @param string $id Id.
	 * @return array{id: string, name: string, url: string}|null
	 */
	public static function store( string $id ): ?array {
		foreach ( self::stores() as $store ) {
			if ( $store['id'] === $id ) {
				return $store;
			}
		}
		return null;
	}

	/**
	 * Destinations of this shop.
	 *
	 * @return array<int, array{id: string, label: string, note: string, store: string, list: string, states: string[]}>
	 */
	public static function own(): array {
		return array_values( array_filter( self::destinations(), static fn( array $d ): bool => '' === $d['store'] ) );
	}

	/**
	 * Whether the visitor has anything to choose: more than one destination or more than one
	 * language. Without it there is no picker, no badge and no footer link.
	 *
	 * @param int $languages Languages of the shop.
	 */
	public static function selectable( int $languages = 1 ): bool {
		return count( self::destinations() ) > 1 || $languages > 1;
	}

	/**
	 * WooCommerce's place for a destination: its country and its first state («ES-IB» →
	 * ES, PM; «ES» → ES, no state).
	 *
	 * @param array{id: string, states: string[]} $destination Destination.
	 * @return array{country: string, state: string, postcode: string}
	 */
	public static function location( array $destination ): array {
		return array(
			'country'  => substr( $destination['id'], 0, 2 ),
			'state'    => (string) ( $destination['states'][0] ?? '' ),
			'postcode' => '',
		);
	}

	/**
	 * The destination of a WooCommerce place: the row with that state, or the country row.
	 *
	 * @param string $country Country code.
	 * @param string $state   State code.
	 * @return array{id: string, label: string, note: string, store: string, list: string, states: string[]}|null
	 */
	public static function for_location( string $country, string $state = '' ): ?array {
		$country = strtoupper( $country );
		$state   = strtoupper( $state );
		$whole   = null;
		foreach ( self::destinations() as $destination ) {
			if ( substr( $destination['id'], 0, 2 ) !== $country ) {
				continue;
			}
			if ( '' !== $state && strlen( $destination['id'] ) > 2 && in_array( $state, $destination['states'], true ) ) {
				return $destination;
			}
			if ( 2 === strlen( $destination['id'] ) ) {
				$whole = $destination;
			}
		}
		return $whole;
	}

	/**
	 * WooCommerce's states of an ISO 3166-2 subdivision: the provinces of a Spanish
	 * community, or the state with the same code. Empty for a whole country.
	 *
	 * @param string $id Id.
	 * @return string[]
	 */
	public static function default_states( string $id ): array {
		$parts = explode( '-', self::normalize_id( $id ) );
		if ( 2 !== count( $parts ) ) {
			return array();
		}
		if ( 'ES' === $parts[0] && isset( self::ES_REGIONS[ $parts[1] ] ) ) {
			return self::ES_REGIONS[ $parts[1] ];
		}
		$states = function_exists( 'WC' ) ? WC()->countries->get_states( $parts[0] ) : array();
		return is_array( $states ) && isset( $states[ $parts[1] ] ) ? array( $parts[1] ) : array();
	}

	/**
	 * Without a saved configuration: the countries WooCommerce sells to, the shop's own
	 * country first; all in the main list when they fit, otherwise the rest in «Otro país».
	 *
	 * @return array<int, array{id: string, label: string, note: string, store: string, list: string, states: string[]}>
	 */
	public static function defaults(): array {
		if ( ! function_exists( 'WC' ) ) {
			return array();
		}
		$countries = WC()->countries->get_allowed_countries();
		$base      = WC()->countries->get_base_country();
		if ( isset( $countries[ $base ] ) ) {
			$countries = array( $base => $countries[ $base ] ) + $countries;
		}
		$fits = count( $countries ) <= self::MAIN_MAX;
		$out  = array();
		foreach ( $countries as $code => $name ) {
			$out[] = array(
				'id'     => (string) $code,
				'label'  => html_entity_decode( (string) $name ),
				'note'   => '',
				'store'  => '',
				'list'   => $fits || $code === $base ? 'main' : 'more',
				'states' => array(),
			);
		}
		return $out;
	}

	/**
	 * «es-ib» → «ES-IB»; '' when it is not an ISO 3166-1 or 3166-2 id.
	 *
	 * @param string $id Id.
	 */
	public static function normalize_id( string $id ): string {
		$id = strtoupper( trim( $id ) );
		return 1 === preg_match( '/^[A-Z]{2}(-[A-Z0-9]{1,3})?$/', $id ) ? $id : '';
	}

	/**
	 * Problems of a configuration (from the panel or an import), as sentences.
	 *
	 * @param array<string, mixed> $data `destinations` and `stores`.
	 * @return string[]
	 */
	public static function validate( array $data ): array {
		$errors       = array();
		$stores       = is_array( $data['stores'] ?? null ) ? $data['stores'] : array();
		$destinations = is_array( $data['destinations'] ?? null ) ? $data['destinations'] : array();
		$store_ids    = array();
		foreach ( $stores as $store ) {
			$store = is_array( $store ) ? $store : array();
			$url   = (string) ( $store['url'] ?? '' );
			$id    = sanitize_key( (string) ( $store['id'] ?? '' ) );
			if ( '' === $id || ! self::valid_url( $url ) ) {
				/* translators: %s: shop name or address as typed. */
				$errors[] = sprintf( __( 'La tienda «%s» necesita un nombre y una dirección https:// completa.', 'lachinata-core' ), (string) ( $store['name'] ?? $url ) );
				continue;
			}
			$store_ids[] = $id;
		}
		$seen = array();
		$main = 0;
		foreach ( $destinations as $destination ) {
			$destination = is_array( $destination ) ? $destination : array();
			$raw         = (string) ( $destination['id'] ?? '' );
			$id          = self::normalize_id( $raw );
			if ( '' === $id ) {
				/* translators: %s: id as typed. */
				$errors[] = sprintf( __( '«%s» no es un código ISO 3166-1 o 3166-2 (PT, ES-IB…).', 'lachinata-core' ), $raw );
				continue;
			}
			if ( isset( $seen[ $id ] ) ) {
				/* translators: %s: destination id. */
				$errors[] = sprintf( __( 'El destino %s está repetido.', 'lachinata-core' ), $id );
			}
			$seen[ $id ] = true;
			if ( '' === trim( (string) ( $destination['label'] ?? '' ) ) ) {
				/* translators: %s: destination id. */
				$errors[] = sprintf( __( 'Falta la etiqueta del destino %s.', 'lachinata-core' ), $id );
			}
			$store = (string) ( $destination['store'] ?? '' );
			if ( '' !== $store && ! in_array( $store, $store_ids, true ) ) {
				/* translators: %s: destination id. */
				$errors[] = sprintf( __( 'El destino %s pertenece a una tienda que no está en la lista de otras tiendas.', 'lachinata-core' ), $id );
			}
			$main += 'more' === ( $destination['list'] ?? 'main' ) ? 0 : 1;
		}
		if ( $main > self::MAIN_MAX ) {
			/* translators: %d: maximum number of rows. */
			$errors[] = sprintf( __( 'La lista principal admite %d destinos como máximo; pasa el resto a «Otro país».', 'lachinata-core' ), self::MAIN_MAX );
		}
		if ( $destinations && ! array_filter( $destinations, static fn( $d ): bool => is_array( $d ) && '' === (string) ( $d['store'] ?? '' ) ) ) {
			$errors[] = __( 'Al menos un destino tiene que ser de esta tienda.', 'lachinata-core' );
		}
		return $errors;
	}

	/**
	 * A valid configuration in its stored shape.
	 *
	 * @param array<int|string, mixed>                                 $destinations Rows.
	 * @param array<int, array{id: string, name: string, url: string}> $stores       Clean shops.
	 * @return array{destinations: array<int, array{id: string, label: string, note: string, store: string, list: string, states: string[]}>, stores: array<int, array{id: string, name: string, url: string}>}
	 */
	public static function clean( array $destinations, array $stores ): array {
		$store_ids = array_column( $stores, 'id' );
		$out       = array();
		foreach ( $destinations as $destination ) {
			if ( ! is_array( $destination ) ) {
				continue;
			}
			$id = self::normalize_id( (string) ( $destination['id'] ?? '' ) );
			if ( '' === $id ) {
				continue;
			}
			$store  = (string) ( $destination['store'] ?? '' );
			$states = $destination['states'] ?? null;
			$states = is_string( $states ) ? explode( ',', $states ) : $states;
			$states = is_array( $states ) ? array_values( array_filter( array_map( static fn( $s ): string => strtoupper( trim( (string) $s ) ), $states ) ) ) : array();
			$out[]  = array(
				'id'     => $id,
				'label'  => sanitize_text_field( (string) ( $destination['label'] ?? $id ) ),
				'note'   => sanitize_text_field( (string) ( $destination['note'] ?? '' ) ),
				'store'  => in_array( $store, $store_ids, true ) ? $store : '',
				'list'   => 'more' === ( $destination['list'] ?? 'main' ) ? 'more' : 'main',
				'states' => $states ? $states : self::default_states( $id ),
			);
		}
		return array(
			'destinations' => $out,
			'stores'       => $stores,
		);
	}

	/**
	 * Clean shops: a key, a name and an https address without path, query or fragment
	 * beyond the shop's own subdirectory.
	 *
	 * @param array<int|string, mixed> $stores Rows.
	 * @return array<int, array{id: string, name: string, url: string}>
	 */
	public static function clean_stores( array $stores ): array {
		$out = array();
		foreach ( $stores as $store ) {
			if ( ! is_array( $store ) ) {
				continue;
			}
			$url  = untrailingslashit( esc_url_raw( (string) ( $store['url'] ?? '' ), array( 'https', 'http' ) ) );
			$name = sanitize_text_field( (string) ( $store['name'] ?? '' ) );
			$id   = sanitize_key( (string) ( $store['id'] ?? $name ) );
			if ( '' === $id || ! self::valid_url( $url ) ) {
				continue;
			}
			$out[] = array(
				'id'   => $id,
				'name' => '' === $name ? (string) wp_parse_url( $url, PHP_URL_HOST ) : $name,
				'url'  => $url,
			);
		}
		return $out;
	}

	/**
	 * Saves a configuration that passed validate().
	 *
	 * @param array<string, mixed> $data `destinations` and `stores`.
	 */
	public static function save( array $data ): void {
		$stores = self::clean_stores( is_array( $data['stores'] ?? null ) ? $data['stores'] : array() );
		$clean  = self::clean( is_array( $data['destinations'] ?? null ) ? $data['destinations'] : array(), $stores );
		update_option( self::STORES, $clean['stores'], false );
		update_option( self::DESTINATIONS, $clean['destinations'], false );
		self::forget();
		/**
		 * The destinations or the other shops have changed (the catalogue is indexed again).
		 *
		 * @since 0.11.0
		 */
		do_action( 'lachinata/locale/changed' );
	}

	/**
	 * Hosts of the other shops, for wp_safe_redirect().
	 *
	 * @return string[]
	 */
	public static function hosts(): array {
		return array_values( array_filter( array_map( static fn( array $s ): string => (string) wp_parse_url( $s['url'], PHP_URL_HOST ), self::stores() ) ) );
	}

	/**
	 * A full address with a host, http(s) and nothing after the path.
	 *
	 * @param string $url Address.
	 */
	private static function valid_url( string $url ): bool {
		$parts = wp_parse_url( $url );
		return is_array( $parts ) && ! empty( $parts['host'] ) && in_array( $parts['scheme'] ?? '', array( 'https', 'http' ), true ) && empty( $parts['query'] ) && empty( $parts['fragment'] );
	}
}
