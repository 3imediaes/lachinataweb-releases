<?php
/**
 * WooCommerce → La Chinata → Destino.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Locale;

use LaChinata\Core\Admin\Screen;
use LaChinata\Core\Hooks;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Destinations (id, label, note, shop, list and WooCommerce states), the other shops, the
 * page cache mode and the geolocation header; «Recalcular el catálogo».
 */
final class LocaleTab {

	/**
	 * Tab id.
	 */
	public const TAB = 'locale';

	/**
	 * Actions of admin-post.php, also nonce actions.
	 */
	private const SAVE    = 'lachinata_locale_save';
	private const REINDEX = 'lachinata_locale_reindex';

	/**
	 * Empty rows for new destinations and shops.
	 */
	private const BLANK = 3;

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/core/admin_tabs', array( self::class, 'tab' ), 30 );
		Hooks::add_action( 'admin_post_' . self::SAVE, array( self::class, 'handle' ) );
		Hooks::add_action( 'admin_post_' . self::REINDEX, array( self::class, 'handle' ) );
	}

	/**
	 * Adds the tab after Envíos (or first among the modules' tabs).
	 *
	 * @param array<string, array{label: string, render: callable}> $tabs Tabs.
	 * @return array<string, array{label: string, render: callable}>
	 */
	public static function tab( array $tabs ): array {
		$position = array_search( 'shipping', array_keys( $tabs ), true );
		$position = false === $position ? 1 : $position + 1;
		$tab      = array(
			self::TAB => array(
				'label'  => __( 'Destino', 'lachinata-core' ),
				'render' => array( self::class, 'render' ),
			),
		);
		return array_slice( $tabs, 0, $position, true ) + $tab + $tabs;
	}

	/**
	 * Prints the tab.
	 */
	public static function render(): void {
		$destinations = Config::destinations();
		$stores       = Config::stores();
		$mode         = (string) LocaleModule::setting( 'cache_mode' );
		$header       = (string) LocaleModule::setting( 'geo_header' );
		$saved        = is_array( get_option( Config::DESTINATIONS, null ) );
		$indexed      = (int) get_option( 'lachinata_locale_indexed', 0 );
		?>
		<p><?php esc_html_e( 'Dónde puede recibir el pedido quien visita la tienda. Con más de un destino, la primera visita pregunta con el selector y la cabecera muestra el destino elegido; con uno solo, no se pregunta nada.', 'lachinata-core' ); ?> <a href="<?php echo esc_url( Screen::guide_url( 'locale' ) ); ?>"><?php esc_html_e( 'Guía', 'lachinata-core' ); ?></a></p>
		<?php if ( ! $saved ) : ?>
			<div class="notice notice-info inline"><p><?php esc_html_e( 'Sin configurar: los destinos son los países de venta de WooCommerce (Ajustes → Generales), sin notas ni otras tiendas. Al guardar se quedan como están aquí.', 'lachinata-core' ); ?></p></div>
		<?php endif; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE ); ?>">
			<?php wp_nonce_field( self::SAVE ); ?>
			<h2><?php esc_html_e( 'Otras tiendas', 'lachinata-core' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Tiendas a las que se lleva a quien elige uno de sus destinos (con su permiso: solo al pulsar). Se lleva a la misma página en esa tienda, con el destino en la dirección para que no vuelva a preguntar. Solo a estas direcciones.', 'lachinata-core' ); ?></p>
			<table class="widefat striped lc-admin__table">
				<thead><tr><th scope="col"><?php esc_html_e( 'Nombre', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Dirección', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Quitar', 'lachinata-core' ); ?></th></tr></thead>
				<tbody>
					<?php foreach ( array_merge( $stores, array_fill( 0, self::BLANK, null ) ) as $index => $store ) : ?>
						<tr>
							<td>
								<input type="hidden" name="stores[<?php echo (int) $index; ?>][id]" value="<?php echo esc_attr( $store['id'] ?? '' ); ?>">
								<input type="text" class="regular-text" name="stores[<?php echo (int) $index; ?>][name]" value="<?php echo esc_attr( $store['name'] ?? '' ); ?>" placeholder="<?php esc_attr_e( 'Canarias', 'lachinata-core' ); ?>" aria-label="<?php esc_attr_e( 'Nombre de la tienda', 'lachinata-core' ); ?>">
							</td>
							<td><input type="url" class="regular-text" name="stores[<?php echo (int) $index; ?>][url]" value="<?php echo esc_attr( $store['url'] ?? '' ); ?>" placeholder="https://" aria-label="<?php esc_attr_e( 'Dirección de la tienda', 'lachinata-core' ); ?>"></td>
							<td>
							<?php
							if ( null !== $store ) :
								?>
								<input type="checkbox" name="stores[<?php echo (int) $index; ?>][delete]" value="1" aria-label="<?php esc_attr_e( 'Quitar la tienda', 'lachinata-core' ); ?>"><?php endif; ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<h2><?php esc_html_e( 'Destinos', 'lachinata-core' ); ?></h2>
			<p class="description">
				<?php
				printf(
					/* translators: %d: maximum rows of the main list. */
					esc_html__( 'Código ISO 3166-1 (PT) o 3166-2 (ES-IB). Una fila de país sin subdivisión (ES) es ese país salvo las subdivisiones que tienen fila propia. La lista principal admite %d filas; el resto va en «Otro país». En la nota, {envio_gratis} se cambia por el umbral de envío gratis del destino. Las provincias o estados de WooCommerce se rellenan solos para las subdivisiones habituales; la primera es la que se usa para calcular envíos y fechas.', 'lachinata-core' ),
					(int) Config::MAIN_MAX
				);
				?>
			</p>
			<table class="widefat striped lc-admin__table">
				<thead>
					<tr>
						<th scope="col"><?php esc_html_e( 'Código', 'lachinata-core' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Etiqueta', 'lachinata-core' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Nota', 'lachinata-core' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Tienda', 'lachinata-core' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Lista', 'lachinata-core' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Provincias o estados', 'lachinata-core' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Quitar', 'lachinata-core' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( array_merge( $destinations, array_fill( 0, self::BLANK, null ) ) as $index => $row ) : ?>
						<?php $name = 'destinations[' . (int) $index . ']'; ?>
						<tr>
							<td><input type="text" size="6" name="<?php echo esc_attr( $name ); ?>[id]" value="<?php echo esc_attr( $row['id'] ?? '' ); ?>" aria-label="<?php esc_attr_e( 'Código ISO', 'lachinata-core' ); ?>"></td>
							<td><input type="text" name="<?php echo esc_attr( $name ); ?>[label]" value="<?php echo esc_attr( $row['label'] ?? '' ); ?>" aria-label="<?php esc_attr_e( 'Etiqueta', 'lachinata-core' ); ?>"></td>
							<td><input type="text" class="regular-text" name="<?php echo esc_attr( $name ); ?>[note]" value="<?php echo esc_attr( $row['note'] ?? '' ); ?>" aria-label="<?php esc_attr_e( 'Nota', 'lachinata-core' ); ?>"></td>
							<td>
								<select name="<?php echo esc_attr( $name ); ?>[store]" aria-label="<?php esc_attr_e( 'Tienda', 'lachinata-core' ); ?>">
									<option value=""><?php esc_html_e( 'Esta tienda', 'lachinata-core' ); ?></option>
									<?php foreach ( $stores as $store ) : ?>
										<option value="<?php echo esc_attr( $store['id'] ); ?>"<?php selected( $store['id'], $row['store'] ?? '' ); ?>><?php echo esc_html( $store['name'] ); ?></option>
									<?php endforeach; ?>
								</select>
							</td>
							<td>
								<select name="<?php echo esc_attr( $name ); ?>[list]" aria-label="<?php esc_attr_e( 'Lista', 'lachinata-core' ); ?>">
									<option value="main"<?php selected( 'main', $row['list'] ?? 'main' ); ?>><?php esc_html_e( 'Principal', 'lachinata-core' ); ?></option>
									<option value="more"<?php selected( 'more', $row['list'] ?? 'main' ); ?>><?php esc_html_e( 'Otro país', 'lachinata-core' ); ?></option>
								</select>
							</td>
							<td><input type="text" size="10" name="<?php echo esc_attr( $name ); ?>[states]" value="<?php echo esc_attr( implode( ', ', $row['states'] ?? array() ) ); ?>" aria-label="<?php esc_attr_e( 'Provincias o estados de WooCommerce', 'lachinata-core' ); ?>"></td>
							<td>
							<?php
							if ( null !== $row ) :
								?>
								<input type="checkbox" name="<?php echo esc_attr( $name ); ?>[delete]" value="1" aria-label="<?php esc_attr_e( 'Quitar el destino', 'lachinata-core' ); ?>"><?php endif; ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<h2><?php esc_html_e( 'Caché de página y ubicación', 'lachinata-core' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Caché de página', 'lachinata-core' ); ?></th>
					<td>
						<fieldset>
							<label><input type="radio" name="cache_mode" value="vary"<?php checked( 'none' !== $mode ); ?>> <?php esc_html_e( 'Varía por la cookie lc_destino (o no hay caché)', 'lachinata-core' ); ?></label><br>
							<label><input type="radio" name="cache_mode" value="none"<?php checked( 'none', $mode ); ?>> <?php esc_html_e( 'La misma página para todos (caché sin destino)', 'lachinata-core' ); ?></label>
							<p class="description"><?php esc_html_e( 'Con la primera, el servidor pinta cada página para el destino del visitante. Con la segunda (SiteGround y cualquier caché que no pueda variar por cookie), las páginas salen iguales para todos y el navegador oculta lo que no se envía y pone el umbral y la fecha del destino; los listados no muestran el número de productos.', 'lachinata-core' ); ?></p>
						</fieldset>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="lc-geo-header"><?php esc_html_e( 'Cabecera de país del CDN', 'lachinata-core' ); ?></label></th>
					<td>
						<input type="text" class="regular-text" id="lc-geo-header" name="geo_header" value="<?php echo esc_attr( $header ); ?>" placeholder="CF-IPCountry">
						<p class="description"><?php esc_html_e( 'Opcional. Sin ella se usa la geolocalización de WooCommerce (Ajustes → Integración → MaxMind, o las cabeceras de CDN que ya conoce).', 'lachinata-core' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>

		<h2><?php esc_html_e( 'Catálogo por destino', 'lachinata-core' ); ?></h2>
		<p class="description">
			<?php
			if ( Catalog::pending() ) {
				esc_html_e( 'Recalculando qué productos no se envían a cada destino…', 'lachinata-core' );
			} elseif ( $indexed ) {
				/* translators: %s: date and time. */
				echo esc_html( sprintf( __( 'Calculado por última vez el %s. Se recalcula solo al guardar un producto y al cambiar los envíos o los destinos.', 'lachinata-core' ), wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $indexed ) ) );
			} else {
				esc_html_e( 'Aún sin calcular.', 'lachinata-core' );
			}
			?>
		</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::REINDEX ); ?>">
			<?php wp_nonce_field( self::REINDEX ); ?>
			<?php submit_button( __( 'Recalcular el catálogo', 'lachinata-core' ), 'secondary' ); ?>
		</form>
		<?php
	}

	/**
	 * Rows of the form without the ones marked to go and the empty ones.
	 *
	 * @param mixed  $rows Posted rows.
	 * @param string $key Field that makes a row not empty.
	 * @return array<int, array<string, mixed>>
	 */
	private static function rows( $rows, string $key ): array {
		$out = array();
		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			if ( ! is_array( $row ) || ! empty( $row['delete'] ) || '' === trim( (string) ( $row[ $key ] ?? '' ) ) ) {
				continue;
			}
			$out[] = array_map( static fn( $value ) => is_string( $value ) ? sanitize_text_field( $value ) : '', $row );
		}
		return $out;
	}

	/**
	 * The configuration of the form.
	 *
	 * @param array<string, mixed> $post Posted fields, unslashed.
	 * @return array{destinations: array<int, array<string, mixed>>, stores: array<int, array<string, mixed>>}
	 */
	public static function posted( array $post ): array {
		$stores = self::rows( $post['stores'] ?? array(), 'url' );
		foreach ( $stores as &$store ) {
			$store['id'] = '' !== (string) ( $store['id'] ?? '' ) ? (string) $store['id'] : sanitize_key( remove_accents( (string) ( $store['name'] ?? '' ) ) );
		}
		unset( $store );
		return array(
			'destinations' => self::rows( $post['destinations'] ?? array(), 'id' ),
			'stores'       => $stores,
		);
	}

	/**
	 * Saves the configuration or schedules the catalogue.
	 */
	public static function handle(): void {
		$action = current_action() === 'admin_post_' . self::SAVE ? self::SAVE : self::REINDEX;
		Screen::check( $action );
		if ( self::REINDEX === $action ) {
			Catalog::schedule();
			Screen::flash( 'success', array( __( 'El catálogo se está recalculando; tarda unos minutos.', 'lachinata-core' ) ) );
			Screen::redirect( self::TAB );
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Screen::check().
		$post   = wp_unslash( $_POST );
		$data   = self::posted( is_array( $post ) ? $post : array() );
		$errors = Config::validate( $data );
		if ( $errors ) {
			Screen::flash( 'error', $errors );
			Screen::redirect( self::TAB );
		}
		Config::save( $data );
		Catalog::schedule();
		$module = LocaleModule::instance();
		if ( null !== $module ) {
			$mode = (string) ( $post['cache_mode'] ?? '' );
			Settings::set( $module, 'cache_mode', 'none' === $mode ? 'none' : 'vary' );
			Settings::set( $module, 'geo_header', sanitize_text_field( (string) ( $post['geo_header'] ?? '' ) ) );
		}
		Screen::flash( 'success', array( __( 'Destinos guardados. El catálogo se recalcula en unos minutos.', 'lachinata-core' ) ) );
		Screen::redirect( self::TAB );
	}
}
