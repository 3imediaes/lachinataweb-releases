<?php
/**
 * REST: suggestion, what changes with a destination, and choosing without reloading.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Locale;

use LaChinata\Core\Hooks;
use LaChinata\Core\Services;

defined( 'ABSPATH' ) || exit;

/**
 * `GET /lachinata/v1/locale` gives the destination suggested by the visitor's location
 * (`sugerir=1`) and, for a destination (`destino=ES-IB`), its free shipping threshold. `POST` keeps a destination of this shop (the picker
 * closed without choosing applies its preselection). Never cached.
 */
final class Rest {

	/**
	 * Namespace.
	 */
	public const NAMESPACE = 'lachinata/v1';

	/**
	 * Route.
	 */
	public const ROUTE = '/locale';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'rest_api_init', array( self::class, 'register' ) );
	}

	/**
	 * Registers the route.
	 */
	public static function register(): void {
		register_rest_route(
			self::NAMESPACE,
			self::ROUTE,
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => Hooks::rest( array( self::class, 'read' ) ),
					'permission_callback' => '__return_true',
					'args'                => array(
						'destino' => array(
							'type'    => 'string',
							'default' => '',
						),
						'sugerir' => array(
							'type'    => 'boolean',
							'default' => false,
						),
					),
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => Hooks::rest( array( self::class, 'choose' ) ),
					'permission_callback' => '__return_true',
					'args'                => array(
						'destino' => array(
							'type'     => 'string',
							'required' => true,
						),
					),
				),
			)
		);
	}

	/**
	 * Suggestion and threshold.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @phpstan-param \WP_REST_Request<array<string, mixed>> $request
	 */
	public static function read( \WP_REST_Request $request ): \WP_REST_Response {
		$data = array();
		if ( $request->get_param( 'sugerir' ) ) {
			$data['suggestion'] = self::suggestion( self::country() );
		}
		$destination = Config::find( (string) $request->get_param( 'destino' ) );
		if ( null !== $destination && '' === $destination['store'] ) {
			$data['threshold'] = self::threshold( $destination );
		}
		return self::private( new \WP_REST_Response( $data ) );
	}

	/**
	 * Keeps a destination of this shop.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @phpstan-param \WP_REST_Request<array<string, mixed>> $request
	 */
	public static function choose( \WP_REST_Request $request ): \WP_REST_Response {
		$destination = Config::find( (string) $request->get_param( 'destino' ) );
		if ( ! Chooser::same_origin() || null === $destination || '' !== $destination['store'] ) {
			return self::private( new \WP_REST_Response( array( 'message' => __( 'Destino no válido.', 'lachinata-core' ) ), 400 ) );
		}
		Visitor::choose( $destination );
		return self::private(
			new \WP_REST_Response(
				array(
					'destino' => $destination['id'],
					'reload'  => Visitor::server_renders(),
				)
			)
		);
	}

	/**
	 * Country of the visitor: the CDN header set in the panel, or WooCommerce's
	 * geolocation (its MaxMind base or the usual CDN headers), without calling outside
	 * services. '' when unknown.
	 */
	public static function country(): string {
		$header = strtoupper( str_replace( '-', '_', (string) LocaleModule::setting( 'geo_header' ) ) );
		$key    = '' === $header ? '' : 'HTTP_' . preg_replace( '/^HTTP_/', '', $header );
		if ( '' !== $key && ! empty( $_SERVER[ $key ] ) ) {
			$country = strtoupper( sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) ) );
			if ( 1 === preg_match( '/^[A-Z]{2}$/', $country ) ) {
				return $country;
			}
		}
		if ( ! class_exists( \WC_Geolocation::class ) ) {
			return '';
		}
		// MaxMind and the CDN headers WooCommerce knows; never its external lookup services
		// (they would receive the visitor's address).
		$place = \WC_Geolocation::geolocate_ip( '', false, false );
		return strtoupper( (string) ( $place['country'] ?? '' ) );
	}

	/**
	 * The destination of a country, with the sentence that says where it comes from.
	 *
	 * @param string $country Country code, '' when unknown.
	 * @return array{id: string, hint: string, store: string}|null
	 */
	public static function suggestion( string $country ): ?array {
		$destination = '' === $country ? null : Config::for_location( $country );
		if ( null === $destination ) {
			return null;
		}
		$store = '' === $destination['store'] ? null : Config::store( $destination['store'] );
		return array(
			'id'    => $destination['id'],
			/* translators: %s: destination («España · Península»). */
			'hint'  => sprintf( __( 'Te hemos situado en %s por tu conexión. Cámbialo si envías a otro sitio.', 'lachinata-core' ), $destination['label'] ),
			'store' => null === $store ? '' : $store['name'],
		);
	}

	/**
	 * Free shipping threshold of a destination, as a plain price in the shop's currency;
	 * null for «no free shipping». The browser puts it, with the destination's label, in
	 * the texts of the PromoBar and the UspBar that carry `data-lc-free`.
	 *
	 * @param array{id: string, states: string[]} $destination Destination.
	 * @return array{value: string|null}
	 */
	public static function threshold( array $destination ): array {
		$rules = Services::shipping_rules();
		$value = null === $rules ? null : $rules->free_shipping_from( Config::location( $destination ) );
		return array( 'value' => null === $value ? null : self::plain_price( $value ) );
	}

	/**
	 * Price as plain text («60 €», «1 500 Kč»), as `shipping` writes it in the PromoBar.
	 *
	 * @param float $amount Amount.
	 */
	public static function plain_price( float $amount ): string {
		$decimals = abs( $amount - round( $amount ) ) < 0.005 ? 0 : wc_get_price_decimals();
		return html_entity_decode( wp_strip_all_tags( wc_price( $amount, array( 'decimals' => $decimals ) ) ) );
	}

	/**
	 * Never in a cache: the answer depends on the visitor.
	 *
	 * @param \WP_REST_Response $response Response.
	 */
	private static function private( \WP_REST_Response $response ): \WP_REST_Response {
		$response->header( 'Cache-Control', 'private, no-store, max-age=0' );
		$response->header( 'Vary', 'Cookie' );
		return $response;
	}
}
