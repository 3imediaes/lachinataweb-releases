<?php
/**
 * WooCommerce → La Chinata → Newsletter.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Newsletter;

use LaChinata\Core\Admin\Screen;
use LaChinata\Core\Hooks;
use LaChinata\Core\Plugin;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Which provider is on and with what, the footer form, and the sign-ups that failed.
 */
final class NewsletterTab {

	/**
	 * Tab id.
	 */
	public const TAB = 'newsletter';

	/**
	 * Actions of admin-post.php, also nonce actions.
	 */
	private const SAVE       = 'lachinata_newsletter_settings';
	private const CLEAR_GAPS = 'lachinata_newsletter_clear_gaps';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/core/admin_tabs', array( self::class, 'tab' ), 33 );
		foreach ( array( self::SAVE, self::CLEAR_GAPS ) as $action ) {
			Hooks::add_action( 'admin_post_' . $action, array( self::class, 'handle' ) );
		}
	}

	/**
	 * Adds the tab.
	 *
	 * @param array<string, array{label: string, render: callable}> $tabs Tabs.
	 * @return array<string, array{label: string, render: callable}>
	 */
	public static function tab( array $tabs ): array {
		$tab      = array(
			self::TAB => array(
				'label'  => __( 'Newsletter', 'lachinata-core' ),
				'render' => array( self::class, 'render' ),
			),
		);
		$position = array_search( 'transfer', array_keys( $tabs ), true );
		$position = false === $position ? count( $tabs ) : $position;
		return array_slice( $tabs, 0, $position, true ) + $tab + $tabs;
	}

	/**
	 * Prints the tab.
	 */
	public static function render(): void {
		$module = Plugin::instance()->modules()->get( 'newsletter' );
		if ( null === $module ) {
			return;
		}
		$values   = Settings::all( $module );
		$service  = new Service();
		$provider = $service->provider();
		$log      = NewsletterModule::gaps()->all();
		?>
		<p>
			<?php
			if ( $provider->configured() ) {
				/* translators: %s: provider name. */
				echo esc_html( sprintf( __( 'Proveedor: %s, listo.', 'lachinata-core' ), $provider->label() ) );
			} else {
				/* translators: %s: provider name. */
				echo esc_html( sprintf( __( 'Proveedor: %s, sin configurar: el formulario del pie no se muestra.', 'lachinata-core' ), $provider->label() ) );
			}
			echo ' ';
			echo esc_html(
				Checkout::mailchimp_plugin()
					? __( 'Mailchimp for WooCommerce está activo: aporta la clave y la audiencia, sigue sincronizando la tienda y recibe la casilla de novedades del checkout (la suya queda oculta).', 'lachinata-core' )
					: __( 'Sin Mailchimp for WooCommerce: la casilla del checkout da de alta con doble confirmación, con la clave y la audiencia de aquí abajo.', 'lachinata-core' )
			);
			?>
		</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE ); ?>">
			<?php wp_nonce_field( self::SAVE ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Formulario del pie', 'lachinata-core' ); ?></th>
					<td><label><input type="checkbox" name="footer_form" value="1" <?php checked( (bool) $values['footer_form'] ); ?>> <?php esc_html_e( 'Mostrarlo (siempre con doble confirmación)', 'lachinata-core' ); ?></label></td>
				</tr>
				<tr>
					<th scope="row"><label for="lc-news-title"><?php esc_html_e( 'Título', 'lachinata-core' ); ?></label></th>
					<td><input type="text" class="regular-text" id="lc-news-title" name="footer_title" value="<?php echo esc_attr( (string) $values['footer_title'] ); ?>" placeholder="<?php echo esc_attr( __( 'Suscríbete a la newsletter', 'lachinata-core' ) ); ?>"></td>
				</tr>
				<tr>
					<th scope="row"><label for="lc-news-text"><?php esc_html_e( 'Texto', 'lachinata-core' ); ?></label></th>
					<td><input type="text" class="large-text" id="lc-news-text" name="footer_text" value="<?php echo esc_attr( (string) $values['footer_text'] ); ?>" placeholder="<?php echo esc_attr( FooterForm::text() ); ?>"></td>
				</tr>
				<tr>
					<th scope="row"><label for="lc-news-key"><?php esc_html_e( 'Clave de la API de Mailchimp', 'lachinata-core' ); ?></label></th>
					<td>
						<input type="password" class="regular-text" id="lc-news-key" name="mailchimp_api_key" value="" autocomplete="off" placeholder="<?php echo '' !== (string) $values['mailchimp_api_key'] ? esc_attr__( 'Guardada (escribe otra para cambiarla)', 'lachinata-core' ) : ''; ?>">
						<p class="description"><?php esc_html_e( 'Solo si no está Mailchimp for WooCommerce o se quiere otra cuenta. Termina en el centro de datos (…-us21).', 'lachinata-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="lc-news-list"><?php esc_html_e( 'ID de la audiencia', 'lachinata-core' ); ?></label></th>
					<td><input type="text" class="regular-text" id="lc-news-list" name="mailchimp_list" value="<?php echo esc_attr( (string) $values['mailchimp_list'] ); ?>" autocomplete="off"></td>
				</tr>
			</table>
			<p class="description"><?php esc_html_e( 'La clave y la audiencia se guardan solo en este sitio: no salen en la exportación de configuración.', 'lachinata-core' ); ?></p>
			<?php submit_button(); ?>
		</form>
		<h2><?php esc_html_e( 'Altas que no se hicieron', 'lachinata-core' ); ?></h2>
		<?php if ( $log ) : ?>
			<ul>
				<?php foreach ( $log as $entry ) : ?>
					<li><?php echo esc_html( $entry['message'] . ' (' . number_format_i18n( $entry['count'] ) . ')' ); ?></li>
				<?php endforeach; ?>
			</ul>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::CLEAR_GAPS ); ?>">
				<?php wp_nonce_field( self::CLEAR_GAPS ); ?>
				<?php submit_button( __( 'Vaciar la lista', 'lachinata-core' ), 'secondary' ); ?>
			</form>
		<?php else : ?>
			<p><?php esc_html_e( 'Ninguna registrada.', 'lachinata-core' ); ?></p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Saves the settings or empties the gap log.
	 */
	public static function handle(): void {
		$action = (string) preg_replace( '/^admin_post_/', '', current_action() );
		Screen::check( $action );
		$module = Plugin::instance()->modules()->get( 'newsletter' );
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Screen::check().
		if ( self::SAVE === $action && null !== $module ) {
			Settings::set( $module, 'footer_form', ! empty( $_POST['footer_form'] ) );
			foreach ( array( 'footer_title', 'footer_text', 'mailchimp_list' ) as $key ) {
				Settings::set( $module, $key, isset( $_POST[ $key ] ) ? trim( sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) ) : '' );
			}
			$api_key = isset( $_POST['mailchimp_api_key'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['mailchimp_api_key'] ) ) ) : '';
			if ( '' !== $api_key ) {
				Settings::set( $module, 'mailchimp_api_key', $api_key );
			}
			Screen::flash( 'success', array( __( 'Ajustes guardados.', 'lachinata-core' ) ) );
			Screen::redirect( self::TAB );
		}
		// phpcs:enable
		NewsletterModule::gaps()->clear();
		Screen::flash( 'success', array( __( 'Lista vaciada.', 'lachinata-core' ) ) );
		Screen::redirect( self::TAB );
	}
}
