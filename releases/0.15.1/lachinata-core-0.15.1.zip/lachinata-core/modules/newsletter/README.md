# Módulo `newsletter`

El consentimiento de novedades: la casilla del checkout «Quiero recibir novedades y ofertas por correo» y el formulario del pie, detrás de un proveedor intercambiable: **Mailchimp** hoy; Brevo u otro, con su adaptador. El módulo solo gestiona el consentimiento y el formulario. La sincronización de productos, pedidos y carritos sigue en **Mailchimp for WooCommerce**, que convive con él.

Especificación: `design-system/sistema/03-implementacion.md` (tabla de módulos), componente `Footer` (newsletter arriba, solo el correo, consentimiento en `caption` con enlace a privacidad). Decisiones: `design-system/docs/decisiones.md` (incremento 6): doble confirmación en el pie; en el checkout, la que tenga configurada el plugin del proveedor. Ajustes: WooCommerce → La Chinata → Newsletter.

## Qué hace
| Pieza | Cómo | Dónde |
| --- | --- | --- |
| **Una sola casilla** en el checkout de bloques: la de Mailchimp for WooCommerce se oculta (su ajuste `mailchimp_checkbox_defaults` queda en `hide` mientras el módulo está encendido) | `option_mailchimp-woocommerce` | `Checkout.php` |
| El valor de nuestra casilla se le da a Mailchimp for WooCommerce como si fuera la suya (`extensions['mailchimp-newsletter']['optin']`), antes de que la lea (prioridad 5 frente a su 10): el plugin hace el resto (pedido, cliente, alta con su doble confirmación) | `woocommerce_store_api_checkout_update_order_from_request` | `Checkout.php` |
| Sin Mailchimp for WooCommerce: quien marcó la casilla se da de alta con el proveedor del módulo, con doble confirmación | `woocommerce_store_api_checkout_order_processed`, prioridad 20 (después de guardar `_lc_newsletter_optin`, prioridad 10) | `Checkout.php` |
| **Formulario del pie** en el hueco del tema `lachinata/footer/newsletter`: título, texto, correo y botón de flecha (`Footer` del bundle), «Te pediremos que lo confirmes por correo…» con enlace a Privacidad y el resultado. Sin JavaScript: `POST` a `admin-post.php` y vuelta a la misma página (`?lc-news=ok|error#lc-news`). Sin nonce (las páginas van en caché): un campo trampa para robots y **doble confirmación siempre**. Solo se pinta con el proveedor configurado | `admin_post(_nopriv)_lachinata_newsletter` | `FooterForm.php`; estilos en `theme/assets/css/theme.css` |
| Proveedor **Mailchimp** (Marketing API 3.0): `PUT /lists/{audiencia}/members/{md5}` con `status_if_new` (`pending` con doble confirmación, `subscribed`, o `transactional` para un contacto que no recibe campañas) y `POST …/tags`. Clave y audiencia de Mailchimp for WooCommerce o, sin él, las del panel | `wp_remote_request` | `Providers/MailchimpProvider.php` |
| Servicio para otros módulos (`Contracts\Newsletter`, `Services::newsletter()`): alta con nombre, suscripción o no, doble confirmación y etiquetas. Lo usará el formulario de franquicias de `blocks` (contacto con la etiqueta «franquicia», sin suscribir salvo que marque la casilla) | `lachinata/newsletter/service` | `Service.php` |
| Un alta que falla no bloquea nada: queda en Huecos del panel y el pie dice «No hemos podido apuntarte…» | `GapLog` | `Service.php` |


Desde la 0.9.0 la casilla es del módulo (`Optin.php`; hasta la 0.8 la pintaba `checkout`): sin `newsletter` no hay casilla, porque un consentimiento sin proveedor no sirve. El campo (`lachinata/newsletter`) y la clave del pedido (`_lc_newsletter_optin`) no cambian.

## Paso a producción
1. Mailchimp for WooCommerce conectado a la audiencia de la tienda (como hoy). Su opción de casilla en el checkout da igual: el módulo la oculta. Su doble confirmación (ajustes de la audiencia en Mailchimp) es la del checkout.
2. WooCommerce → La Chinata → Módulos: **Newsletter**. En su pestaña, comprobar «Proveedor: Mailchimp, listo».
3. En staging: pedido con la casilla marcada → el contacto aparece en Mailchimp (o pendiente de confirmar); sin marcar → no se suscribe. En el checkout, una sola casilla de novedades.
4. Pie: suscribirse con un correo propio → llega el correo de confirmación de Mailchimp; «Gracias. Te hemos enviado un correo…».
5. Política de privacidad publicada (Ajustes → Privacidad): el pie enlaza a ella.

## Depende de

Ningún módulo (desde la 0.9.0 ya no necesita `checkout`: la casilla es un campo adicional del checkout de bloques de WooCommerce y funciona también sin el módulo `checkout`). WooCommerce 10. Convive con Mailchimp for WooCommerce si está.

## Hooks que escucha

- `woocommerce_init` (registra la casilla), `woocommerce_store_api_checkout_update_order_from_request` (prioridad 5: la pasa a Mailchimp for WooCommerce), `woocommerce_store_api_checkout_order_processed` (guarda el consentimiento y, sin Mailchimp for WooCommerce, da de alta con prioridad 20).
- `option_mailchimp-woocommerce` (oculta su casilla), `admin_post(_nopriv)_lachinata_newsletter` (formulario del pie).
- Del tema: `lachinata/footer/newsletter`. Del núcleo: `lachinata/rest/order`, `lachinata/newsletter/service` (lo sirve), `lachinata/core/admin_tabs`.

## Hooks que emite

| Hook | Tipo | Para qué |
| --- | --- | --- |
| `lachinata/newsletter/provider` | filtro | Otro proveedor (interfaz `Providers\Provider`) |
| `lachinata/newsletter/mailchimp_plugin` | filtro | Si Mailchimp for WooCommerce recibe la casilla (por defecto, si está cargado) |

Sirve `Contracts\Newsletter` con `lachinata/newsletter/service`. Catálogo: `plugin/HOOKS.md`.

## Datos que guarda

- Metadato de pedido `_lc_newsletter_optin` (marca de tiempo del consentimiento).
- Opciones `lachinata_newsletter_*`: ajustes y registro de huecos (`lachinata_newsletter_gaps`). Los contactos viven en el proveedor, no en WordPress.

## REST y API para Odoo

`lachinata.newsletter` del objeto de la API de pedidos: `opt_in` y `at` (ISO 8601, UTC). `null` en un sitio sin el módulo. Contrato en `docs/api-odoo.md`. Sin rutas propias.

## Ajustes y exportación
| Ajuste | Por defecto | En el JSON |
| --- | --- | --- |
| Formulario del pie (`footer_form`) | sí | sí |
| Título y texto del pie (`footer_title`, `footer_text`) | vacíos = «Suscríbete a la newsletter» / «Novedades y ofertas de {nombre comercial} en tu correo.» | sí |
| Clave de la API y audiencia de Mailchimp (`mailchimp_api_key`, `mailchimp_list`) | vacías = las de Mailchimp for WooCommerce | **no** |


El módulo no tiene `export_data()`: solo viajan los ajustes marcados.

## Qué pasa al apagarlo

No hay casilla de novedades en el checkout ni formulario en el pie (el tema no pinta el bloque si nadie engancha `lachinata/footer/newsletter`). Mailchimp for WooCommerce, si está, vuelve a mostrar su propia casilla según su ajuste: revisarlo (`docs/despliegue-checkout.md`). Los pedidos guardan su `_lc_newsletter_optin` y Odoo recibe `newsletter: null` en los nuevos.

## Pruebas
- `tests/NewsletterTest.php`: pie con doble confirmación (`pending`) al centro de datos de la clave y por el md5 del correo, robot que no envía nada, error anotado, contacto sin suscripción con etiqueta para otros módulos, proveedor sin configurar, casilla de Mailchimp oculta, valor de nuestra casilla en los datos de extensión de Mailchimp for WooCommerce.
- La casilla en Contacto y el consentimiento guardado: `test_checkout_box_and_consent` (antes en `checkout`).
- En cada perfil con el módulo, arranque, exportación e importación: `tests/profiles/ProfileBootTest.php`.

## Huecos conocidos

- Mailchimp for WooCommerce no debe mostrar una segunda casilla: comprobarlo en staging (`docs/despliegue-checkout.md`).
- El adaptador de Brevo está preparado (interfaz), no escrito.
