<?php
/**
 * WooCommerce → La Chinata → Odoo.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Odoo;

use LaChinata\Core\Admin\Screen;
use LaChinata\Core\Hooks;
use LaChinata\Core\Plugin;
use LaChinata\Core\Rest\OrderData;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * The map shipping instance → carrier with every instance of every zone, the retired ids
 * and their warnings, the regions that are not countries (Baleares) and the `lachinata`
 * object of an order, as Odoo receives it.
 */
final class OdooTab {

	/**
	 * Tab id.
	 */
	public const TAB = 'odoo';

	/**
	 * Action of admin-post.php, also nonce action.
	 */
	private const SAVE = 'lachinata_odoo_carriers';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/core/admin_tabs', array( self::class, 'tab' ), 32 );
		Hooks::add_action( 'admin_post_' . self::SAVE, array( self::class, 'handle' ) );
	}

	/**
	 * Adds the tab before the core tabs.
	 *
	 * @param array<string, array{label: string, render: callable}> $tabs Tabs.
	 * @return array<string, array{label: string, render: callable}>
	 */
	public static function tab( array $tabs ): array {
		$keys     = array_keys( $tabs );
		$position = false;
		foreach ( array( 'gift', 'checkout', 'eta', 'shipping' ) as $after ) {
			$position = array_search( $after, $keys, true );
			if ( false !== $position ) {
				break;
			}
		}
		$position = false === $position ? 1 : $position + 1;
		$tab      = array(
			self::TAB => array(
				'label'  => __( 'Odoo', 'lachinata-core' ),
				'render' => array( self::class, 'render' ),
			),
		);
		return array_slice( $tabs, 0, $position, true ) + $tab + $tabs;
	}

	/**
	 * Prints the tab.
	 */
	public static function render(): void {
		$sections = array(
			'carriers' => __( 'Transportistas', 'lachinata-core' ),
			'order'    => __( 'Objeto de un pedido', 'lachinata-core' ),
		);
		$current  = isset( $_GET['section'] ) ? sanitize_key( wp_unslash( $_GET['section'] ) ) : 'carriers'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Navigation only.
		$current  = isset( $sections[ $current ] ) ? $current : 'carriers';
		Screen::section_links( self::TAB, $sections, $current );
		if ( 'order' === $current ) {
			self::render_order();
		} else {
			self::render_carriers();
		}
	}

	/**
	 * Map, retired ids and warnings.
	 */
	private static function render_carriers(): void {
		$instances = Carriers::instances();
		$map       = Carriers::map();
		$retired   = Carriers::retired();
		$warnings  = Carriers::warnings();
		?>
		<p><?php esc_html_e( 'Odoo recibe el ID de instancia del método de envío de cada pedido y lo asocia él a su transportista. Este mapa es la copia de la tienda: da el nombre del transportista al objeto lachinata (informativo) y al correo de regalo. Odoo no depende de él.', 'lachinata-core' ); ?></p>
		<p><strong><?php esc_html_e( 'Los IDs de instancia se conservan en cualquier migración, también el de «Tarifa en vivo». Si uno cambia, hay que avisar a quien lleva Odoo.', 'lachinata-core' ); ?></strong></p>
		<?php if ( $warnings ) : ?>
			<div class="notice notice-warning inline"><ul class="ul-disc">
				<?php foreach ( $warnings as $warning ) : ?>
					<li><?php echo esc_html( $warning ); ?></li>
				<?php endforeach; ?>
			</ul></div>
		<?php endif; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE ); ?>">
			<?php wp_nonce_field( self::SAVE ); ?>
			<table class="widefat striped">
				<thead><tr>
					<th scope="col"><?php esc_html_e( 'ID', 'lachinata-core' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Zona', 'lachinata-core' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Método', 'lachinata-core' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Transportista', 'lachinata-core' ); ?></th>
				</tr></thead>
				<tbody>
					<?php foreach ( $instances as $id => $instance ) : ?>
						<tr>
							<td data-no-translation><?php echo esc_html( (string) $id ); ?><?php echo in_array( $id, $retired, true ) ? ' <strong>' . esc_html__( '(retirado)', 'lachinata-core' ) . '</strong>' : ''; ?></td>
							<td><?php echo esc_html( $instance['zone'] ); ?></td>
							<td><?php echo esc_html( $instance['title'] ); ?><?php echo $instance['enabled'] ? '' : ' <em>' . esc_html__( '(desactivado)', 'lachinata-core' ) . '</em>'; ?> <code><?php echo esc_html( $instance['method'] ); ?></code></td>
							<td><label class="screen-reader-text" for="lc-carrier-<?php echo esc_attr( (string) $id ); ?>"><?php esc_html_e( 'Transportista', 'lachinata-core' ); ?></label><input type="text" class="regular-text" id="lc-carrier-<?php echo esc_attr( (string) $id ); ?>" name="carriers[<?php echo esc_attr( (string) $id ); ?>]" value="<?php echo esc_attr( $map[ $id ] ?? '' ); ?>" placeholder="Transportes Ejemplo"></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="lc-odoo-retired"><?php esc_html_e( 'IDs retirados en Odoo', 'lachinata-core' ); ?></label></th>
					<td>
						<input type="text" class="regular-text" id="lc-odoo-retired" name="retired_ids" value="<?php echo esc_attr( implode( ', ', $retired ) ); ?>" placeholder="12, 15">
						<p class="description"><?php esc_html_e( 'Instancias que Odoo ya no asocia a ningún transportista. Separados por comas. Si alguna sigue activa en WooCommerce, se avisa arriba.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
		<?php self::render_regions(); ?>
		<p class="description"><?php esc_html_e( 'El mapa y los IDs retirados salen en Exportar e importar (módulo odoo).', 'lachinata-core' ); ?></p>
		<?php
	}

	/**
	 * Regions that are not countries: an order to Baleares has country ES and province PM,
	 * with the instance ids of its zone (there is no fictitious country).
	 */
	private static function render_regions(): void {
		$rows = array();
		foreach ( \WC_Shipping_Zones::get_zones() as $data ) {
			$zone  = new \WC_Shipping_Zone( (int) $data['id'] );
			$codes = array_map( static fn( $location ): string => (string) $location->code, $zone->get_zone_locations() );
			if ( ! array_intersect( $codes, array( 'ES:PM', 'ES:GC', 'ES:TF', 'ES:CE', 'ES:ML' ) ) ) {
				continue;
			}
			$ids    = array_map( static fn( $method ): int => (int) $method->get_instance_id(), $zone->get_shipping_methods() );
			$rows[] = array(
				'zone'  => $zone->get_zone_name(),
				'codes' => implode( ', ', $codes ),
				'ids'   => implode( ', ', $ids ),
			);
		}
		if ( ! $rows ) {
			return;
		}
		?>
		<h2><?php esc_html_e( 'Regiones de España con zona propia', 'lachinata-core' ); ?></h2>
		<p><?php esc_html_e( 'En el pedido son país ES y su provincia (Baleares: PM). No hay países ficticios como BL: Odoo las distingue por la provincia o por el ID de instancia.', 'lachinata-core' ); ?></p>
		<table class="widefat striped">
			<thead><tr><th scope="col"><?php esc_html_e( 'Zona', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Región', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'IDs de instancia', 'lachinata-core' ); ?></th></tr></thead>
			<tbody>
				<?php foreach ( $rows as $row ) : ?>
					<tr><td><?php echo esc_html( $row['zone'] ); ?></td><td data-no-translation><?php echo esc_html( $row['codes'] ); ?></td><td data-no-translation><?php echo esc_html( $row['ids'] ); ?></td></tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * The `lachinata` object of an order.
	 */
	private static function render_order(): void {
		$id    = isset( $_GET['order'] ) ? absint( $_GET['order'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read only.
		$order = $id ? wc_get_order( $id ) : false;
		?>
		<p><?php esc_html_e( 'Lo que recibe Odoo en el objeto lachinata de un pedido (GET /wp-json/wc/v3/orders/<id>), además de los campos de WooCommerce. Contrato: docs/api-odoo.md.', 'lachinata-core' ); ?></p>
		<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>">
			<input type="hidden" name="page" value="<?php echo esc_attr( Screen::SLUG ); ?>">
			<input type="hidden" name="tab" value="<?php echo esc_attr( self::TAB ); ?>">
			<input type="hidden" name="section" value="order">
			<label for="lc-odoo-order"><?php esc_html_e( 'Pedido', 'lachinata-core' ); ?></label>
			<input type="number" min="1" id="lc-odoo-order" name="order" value="<?php echo esc_attr( $id ? (string) $id : '' ); ?>">
			<?php submit_button( __( 'Ver', 'lachinata-core' ), 'secondary', '', false ); ?>
		</form>
		<?php if ( $order instanceof \WC_Order ) : ?>
			<pre data-no-translation style="max-width:60rem;overflow:auto;padding:1em;background:#fff;border:1px solid #c3c4c7"><?php echo esc_html( (string) wp_json_encode( OrderData::of( $order ), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ); ?></pre>
		<?php elseif ( $id ) : ?>
			<p><?php esc_html_e( 'No hay ningún pedido con ese número.', 'lachinata-core' ); ?></p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Saves the map and the retired ids.
	 */
	public static function handle(): void {
		Screen::check( self::SAVE );
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Screen::check().
		$carriers = isset( $_POST['carriers'] ) ? array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['carriers'] ) ) : array();
		$retired  = isset( $_POST['retired_ids'] ) ? sanitize_text_field( wp_unslash( $_POST['retired_ids'] ) ) : '';
		// phpcs:enable
		Carriers::save( $carriers );
		$module = Plugin::instance()->modules()->get( 'odoo' );
		if ( null !== $module ) {
			$ids = array_values( array_unique( array_filter( array_map( 'intval', preg_split( '/[\s,;]+/', $retired ) ? preg_split( '/[\s,;]+/', $retired ) : array() ) ) ) );
			Settings::set( $module, 'retired_ids', $ids );
		}
		Screen::flash( 'success', array( __( 'Mapa guardado.', 'lachinata-core' ) ) );
		Screen::redirect( self::TAB, array( 'section' => 'carriers' ) );
	}
}
