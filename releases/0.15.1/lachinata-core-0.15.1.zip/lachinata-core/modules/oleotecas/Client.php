<?php
/**
 * The finder of a client shop.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * In client mode there is no post type and no zones: the finder lives on a rule of its own
 * (`/<slug_archive>/`) with the same template and script as the master's, and its cards go
 * to the master's store pages (absolute URLs of the document). Store pages and zones of its
 * own do not exist in this version.
 */
final class Client {

	/**
	 * Query var of the finder.
	 */
	public const QUERY_VAR = 'lc_oleotecas';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'init', array( self::class, 'rewrite' ) );
		Hooks::add_filter( 'query_vars', array( self::class, 'query_vars' ) );
		Hooks::add_action( 'parse_query', array( self::class, 'parse' ) );
		Hooks::add_filter( 'posts_pre_query', array( self::class, 'no_posts' ), 10, 2 );
		Hooks::add_filter( 'pre_handle_404', array( self::class, 'not_404' ) );
	}

	/**
	 * The rule of the finder.
	 */
	public static function rewrite(): void {
		add_rewrite_rule( '^' . preg_quote( Model::archive_slug(), '/' ) . '/?$', 'index.php?' . self::QUERY_VAR . '=finder', 'top' );
	}

	/**
	 * Adds the query var.
	 *
	 * @param mixed $vars Public query vars.
	 * @return mixed
	 */
	public static function query_vars( $vars ) {
		if ( is_array( $vars ) ) {
			$vars[] = self::QUERY_VAR;
		}
		return $vars;
	}

	/**
	 * Whether the request is the finder.
	 */
	public static function is_finder(): bool {
		return 'finder' === get_query_var( self::QUERY_VAR );
	}

	/**
	 * The finder is not the blog's home.
	 *
	 * @param mixed $query Query.
	 */
	public static function parse( $query ): void {
		if ( $query instanceof \WP_Query && $query->is_main_query() && 'finder' === $query->get( self::QUERY_VAR ) ) {
			$query->is_home = false;
		}
	}

	/**
	 * The finder asks no posts of the database.
	 *
	 * @param mixed $posts Posts (null to query).
	 * @param mixed $query Query.
	 * @return mixed
	 */
	public static function no_posts( $posts, $query ) {
		return $query instanceof \WP_Query && $query->is_main_query() && 'finder' === $query->get( self::QUERY_VAR ) ? array() : $posts;
	}

	/**
	 * Nor is it a 404 for having none.
	 *
	 * @param mixed $handled Whether WordPress should skip its check.
	 * @return mixed
	 */
	public static function not_404( $handled ) {
		return self::is_finder() ? true : $handled;
	}
}
