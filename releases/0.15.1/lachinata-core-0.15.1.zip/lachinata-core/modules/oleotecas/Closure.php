<?php
/**
 * Stores that close for good.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * A store that closes is not deleted: it gets the date of its closing (`Cerrada desde`).
 * From that day it leaves the finder, the map, the zones, the JSON and the sitemaps; its
 * page stays at its URL with `noindex`, a notice and the three stores nearest, for the
 * months of the setting (6 by default), and then goes with a 301 to its zone or the finder.
 * The partners' tokens stop working for it at once (410); if it opens again, it needs a new
 * token. Who mentions it (the blog) learns it through `lachinata/oleotecas/closed` and asks
 * `lachinata/oleotecas/status`. The temporary closure (holidays) has nothing to do with this.
 */
final class Closure {

	/**
	 * Event of a closing date in the future: that day the store leaves the lists.
	 */
	public const EVENT = 'lachinata_oleotecas_closing';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( self::EVENT, array( self::class, 'on_day' ) );
		Hooks::add_action( 'added_post_meta', array( self::class, 'on_meta' ), 10, 4 );
		Hooks::add_action( 'updated_post_meta', array( self::class, 'on_meta' ), 10, 4 );
		Hooks::add_action( 'deleted_post_meta', array( self::class, 'on_meta' ), 10, 4 );
		Hooks::add_action( 'template_redirect', array( self::class, 'redirect' ), 5 );
		Hooks::add_filter( 'lachinata/robots/noindex', array( self::class, 'noindex' ) );
		Hooks::add_filter( 'rank_math/sitemap/entry', array( self::class, 'rank_math_entry' ), 10, 3 );
		Hooks::add_filter( 'wp_sitemaps_posts_query_args', array( self::class, 'sitemap_posts' ), 10, 2 );
		Hooks::add_filter( 'lachinata/oleotecas/status', array( self::class, 'status' ), 10, 2 );
		Hooks::add_filter( 'lachinata/oleotecas/slug_of', array( self::class, 'slug_of' ), 10, 2 );
		Hooks::add_filter( 'lachinata/oleotecas/names', array( self::class, 'names' ) );
	}

	/**
	 * Date of the closing (Y-m-d), or ''.
	 *
	 * @param int $post_id Store.
	 */
	public static function date( int $post_id ): string {
		return Fields::date( get_post_meta( $post_id, Fields::CLOSED, true ) );
	}

	/**
	 * Whether a store is closed today.
	 *
	 * @param int $post_id Store.
	 */
	public static function closed( int $post_id ): bool {
		$date = self::date( $post_id );
		return '' !== $date && $date <= wp_date( 'Y-m-d' );
	}

	/**
	 * Months the page of a closed store stays before the 301.
	 */
	public static function months(): int {
		return max( 0, (int) OleotecasModule::setting( 'closed_months' ) );
	}

	/**
	 * Whether the page of a closed store has already gone (the 301 applies).
	 *
	 * @param int $post_id Store.
	 */
	public static function gone( int $post_id ): bool {
		$date = self::date( $post_id );
		return self::closed( $post_id ) && $date <= wp_date( 'Y-m-d', (int) strtotime( '-' . self::months() . ' months' ) );
	}

	/**
	 * When the closing date is set: the moment (for the tokens) and the notice to whoever
	 * listens.
	 *
	 * @param mixed $meta_id  Meta id.
	 * @param mixed $post_id  Post id.
	 * @param mixed $meta_key Key.
	 * @param mixed $value    Value.
	 */
	public static function on_meta( $meta_id, $post_id, $meta_key, $value ): void {
		unset( $meta_id );
		if ( Fields::CLOSED !== $meta_key || ! is_numeric( $post_id ) || Model::POST_TYPE !== get_post_type( (int) $post_id ) ) {
			return;
		}
		$post_id = (int) $post_id;
		if ( 'deleted_post_meta' === current_action() || '' === Fields::date( $value ) ) {
			// Open again: back in the sitemap.
			self::sitemaps( $post_id );
			return;
		}
		if ( ! get_post_meta( $post_id, Fields::CLOSED_AT, true ) ) {
			update_post_meta( $post_id, Fields::CLOSED_AT, time() );
		}
		if ( ! self::closed( $post_id ) ) {
			// Closes another day: then it leaves the lists and the blog learns it.
			$day = date_create_immutable( Fields::date( $value ) . ' 00:05:00', wp_timezone() );
			if ( $day && ! wp_next_scheduled( self::EVENT, array( $post_id ) ) ) {
				wp_schedule_single_event( $day->getTimestamp(), self::EVENT, array( $post_id ) );
			}
			return;
		}
		self::announce( $post_id );
	}

	/**
	 * The day of a closing set in advance.
	 *
	 * @param mixed $post_id Store.
	 */
	public static function on_day( $post_id ): void {
		if ( self::closed( (int) $post_id ) ) {
			Data::touch();
			self::announce( (int) $post_id );
		}
	}

	/**
	 * Tells whoever listens that a store has closed.
	 *
	 * @param int $post_id Store.
	 */
	private static function announce( int $post_id ): void {
		Directory::reset();
		self::sitemaps( $post_id );
		/**
		 * A store has closed for good (or got a new closing date). The blog marks the entries
		 * that mention it.
		 *
		 * @since 0.13.1
		 *
		 * @param int    $post_id Store.
		 * @param string $slug    Slug of its page (`/oleoteca/{slug}/`).
		 * @param string $name    Its short name.
		 */
		do_action( 'lachinata/oleotecas/closed', $post_id, (string) get_post_field( 'post_name', $post_id ), (string) get_post_meta( $post_id, Fields::NAME, true ) );
	}

	/**
	 * The sitemap of Rank Math is cached: a store that closes or opens again changes it.
	 *
	 * @param int $post_id Store.
	 */
	private static function sitemaps( int $post_id ): void {
		do_action( 'rank_math/sitemap/invalidate_object_type', 'post', $post_id ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound, WooCommerce.Commenting.CommentHooks.MissingHookComment -- Rank Math hook.
	}

	/**
	 * Whether a token can act on a store: not when the store is closed, nor with a token
	 * older than its last closing (the store opened again: a new token is needed).
	 *
	 * @param int $post_id Store.
	 * @param int $created When the token was created.
	 */
	public static function token_allowed( int $post_id, int $created ): bool {
		if ( self::closed( $post_id ) ) {
			return false;
		}
		$at = (int) get_post_meta( $post_id, Fields::CLOSED_AT, true );
		return ! $at || $created > $at;
	}

	/**
	 * Stores a token no longer works for (closed, or reopened after it was created), by name.
	 *
	 * @param int $created When the token was created.
	 * @return string[]
	 */
	public static function revoked_for( int $created ): array {
		$ids   = get_posts(
			array(
				'post_type'   => Model::POST_TYPE,
				'post_status' => 'publish',
				'numberposts' => -1,
				'fields'      => 'ids',
				'meta_key'    => Fields::CLOSED_AT, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- A handful of stores.
			)
		);
		$names = array();
		foreach ( $ids as $id ) {
			if ( ! self::token_allowed( (int) $id, $created ) ) {
				$name    = (string) get_post_meta( (int) $id, Fields::NAME, true );
				$names[] = '' !== $name ? $name : get_the_title( (int) $id );
			}
		}
		return $names;
	}

	/**
	 * The page of a store closed longer than the setting goes to its zone, or the finder.
	 */
	public static function redirect(): void {
		if ( ! is_singular( Model::POST_TYPE ) ) {
			return;
		}
		$id = (int) get_queried_object_id();
		if ( ! self::gone( $id ) ) {
			return;
		}
		$post  = get_post( $id );
		$store = $post instanceof \WP_Post ? Store::from_post( $post ) : null;
		$place = null === $store ? null : Directory::place( $store );
		$url   = Pages::archive_url();
		if ( null !== $place && $place['zone'] && $place['zone']['page'] ) {
			$url = $place['zone']['url'];
		} elseif ( null !== $place && $place['country'] && $place['country']['page'] ) {
			$url = $place['country']['url'];
		}
		wp_safe_redirect( $url, 301, 'lachinata-core' );
		exit;
	}

	/**
	 * The page of a closed store is not indexed.
	 *
	 * @param mixed $noindex Current value.
	 */
	public static function noindex( $noindex ): bool {
		return (bool) $noindex || ( is_singular( Model::POST_TYPE ) && self::closed( (int) get_queried_object_id() ) );
	}

	/**
	 * Sitemap of Rank Math: closed stores are left out.
	 *
	 * @param mixed $url  Entry.
	 * @param mixed $type Type of object.
	 * @param mixed $item Row of the post (ID, post_type…).
	 * @return mixed
	 */
	public static function rank_math_entry( $url, $type, $item ) {
		// Rank Math passes a row of the database (ID, post_type…), not a WP_Post.
		return 'post' === $type && is_object( $item ) && isset( $item->ID, $item->post_type ) && Model::POST_TYPE === $item->post_type && self::closed( (int) $item->ID ) ? false : $url;
	}

	/**
	 * Sitemap of WordPress: closed stores are left out.
	 *
	 * @param mixed $args      Query arguments.
	 * @param mixed $post_type Post type.
	 * @return mixed
	 */
	public static function sitemap_posts( $args, $post_type ) {
		if ( Model::POST_TYPE !== $post_type || ! is_array( $args ) ) {
			return $args;
		}
		$closed = self::closed_ids();
		if ( $closed ) {
			$args['post__not_in'] = array_merge( (array) ( $args['post__not_in'] ?? array() ), $closed ); // phpcs:ignore WordPressVIPMinimum.Performance.WPQueryParams.PostNotIn_post__not_in -- A handful of stores.
		}
		return $args;
	}

	/**
	 * Ids of the closed stores.
	 *
	 * @return int[]
	 */
	public static function closed_ids(): array {
		$ids = get_posts(
			array(
				'post_type'   => Model::POST_TYPE,
				'post_status' => 'publish',
				'numberposts' => -1,
				'fields'      => 'ids',
				'meta_key'    => Fields::CLOSED, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- A handful of stores.
			)
		);
		return array_values( array_filter( array_map( 'intval', $ids ), array( self::class, 'closed' ) ) );
	}

	/**
	 * `lachinata/oleotecas/status`: what the module knows of the store of a slug.
	 *
	 * @param mixed $status Current value (null).
	 * @param mixed $slug   Slug of the store's page.
	 * @return array{exists: bool, closed: bool, name: string, url: string, finder: string}|mixed
	 */
	public static function status( $status, $slug ) {
		$post = get_page_by_path( sanitize_title( (string) $slug ), OBJECT, Model::POST_TYPE );
		if ( ! $post instanceof \WP_Post || 'publish' !== $post->post_status ) {
			return array(
				'exists'  => false,
				'closed'  => false,
				'name'    => '',
				'subject' => '',
				'plural'  => Texts::noun( true ),
				'url'     => '',
				'finder'  => Pages::archive_url(),
			);
		}
		$name = (string) get_post_meta( $post->ID, Fields::NAME, true );
		return array(
			'exists'  => true,
			'closed'  => self::closed( $post->ID ),
			'name'    => Texts::store_title( '' !== $name ? $name : $post->post_title ),
			'subject' => Texts::store_subject( '' !== $name ? $name : $post->post_title ),
			'plural'  => Texts::noun( true ),
			'url'     => (string) get_permalink( $post ),
			'finder'  => Pages::archive_url(),
		);
	}

	/**
	 * `lachinata/oleotecas/slug_of`: the slug of a store from a link to its page
	 * (`/oleoteca/{slug}/`, on this site or an old domain of it), or ''.
	 *
	 * @param mixed $slug Current value ('').
	 * @param mixed $url  Link.
	 */
	public static function slug_of( $slug, $url ): string {
		$path = trim( (string) wp_parse_url( (string) $url, PHP_URL_PATH ), '/' );
		$base = Model::single_slug();
		return preg_match( '#^' . preg_quote( $base, '#' ) . '/([a-z0-9-]+)$#', $path, $match ) ? $match[1] : (string) $slug;
	}

	/**
	 * `lachinata/oleotecas/names`: short name of every published store, by slug (closed ones
	 * too: who mentions them must find them).
	 *
	 * @param mixed $names Current value.
	 * @return array<string, string>
	 */
	public static function names( $names ): array {
		$out   = is_array( $names ) ? $names : array();
		$posts = get_posts(
			array(
				'post_type'   => Model::POST_TYPE,
				'post_status' => 'publish',
				'numberposts' => -1,
			)
		);
		foreach ( $posts as $post ) {
			$name                             = (string) get_post_meta( $post->ID, Fields::NAME, true );
			$out[ (string) $post->post_name ] = '' !== $name ? $name : $post->post_title;
		}
		return $out;
	}
}
