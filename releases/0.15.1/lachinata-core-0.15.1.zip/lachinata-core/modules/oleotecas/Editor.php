<?php
/**
 * The store's panel in the editor.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * A panel of its own in the editor of each store (src/editor.js): address with «Buscar en
 * el mapa» and a marker that can be dragged (the geocoder proposes, the person corrects),
 * the hours with «copiar a toda la semana», two slots per day and the special days,
 * profiles as a list, photos, own text and favourites. It saves the registered fields
 * through the REST API.
 */
final class Editor {

	/**
	 * Script handle.
	 */
	public const SCRIPT = 'lachinata-oleotecas-editor';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'enqueue_block_editor_assets', array( self::class, 'enqueue' ) );
	}

	/**
	 * Loads the panel in the editor of a store.
	 */
	public static function enqueue(): void {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( null === $screen || Model::POST_TYPE !== $screen->post_type ) {
			return;
		}
		$file  = LACHINATA_CORE_DIR . '/modules/oleotecas/build/editor.asset.php';
		$asset = is_readable( $file ) ? require $file : array(
			'dependencies' => array( 'wp-plugins', 'wp-editor', 'wp-components', 'wp-data', 'wp-core-data', 'wp-element', 'wp-i18n', 'wp-api-fetch', 'wp-block-editor' ),
			'version'      => LACHINATA_CORE_VERSION,
		);
		wp_enqueue_script( self::SCRIPT, plugins_url( 'modules/oleotecas/build/editor.js', LACHINATA_CORE_FILE ), (array) $asset['dependencies'], (string) $asset['version'], true );
		if ( is_readable( LACHINATA_CORE_DIR . '/modules/oleotecas/build/editor.css' ) ) {
			wp_enqueue_style( self::SCRIPT, plugins_url( 'modules/oleotecas/build/editor.css', LACHINATA_CORE_FILE ), array(), (string) $asset['version'] );
		}
		wp_set_script_translations( self::SCRIPT, 'lachinata-core', LACHINATA_CORE_DIR . '/languages' );
		$countries = function_exists( 'WC' ) && WC()->countries ? WC()->countries->get_countries() : array();
		$codes     = array();
		foreach ( array_keys( $countries ) as $code ) {
			$codes[ $code ] = StorePhone::calling_code( (string) $code );
		}
		wp_add_inline_script(
			self::SCRIPT,
			'window.lcStoresEditor = ' . wp_json_encode(
				array(
					'countries'   => array_map( static fn( $name ): string => html_entity_decode( (string) $name, ENT_QUOTES ), $countries ),
					'callingCode' => $codes,
					'timezones'   => \DateTimeZone::listIdentifiers(),
					'tiles'       => Tiles::url(),
					'attribution' => (string) OleotecasModule::setting( 'tiles_attribution' ),
					'networks'    => Fields::NETWORKS,
					'maxPhotos'   => Fields::MAX_PHOTOS,
					'maxFavs'     => Fields::MAX_FAVORITES,
					'base'        => function_exists( 'WC' ) && WC()->countries ? WC()->countries->get_base_country() : '',
				)
			) . ';',
			'before'
		);
	}
}
