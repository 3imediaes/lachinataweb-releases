<?php
/**
 * Geocoder adapter.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas\Geocoder;

defined( 'ABSPATH' ) || exit;

/**
 * Turns an address or a place into coordinates. One adapter per provider (Nominatim by
 * default); another one comes in through `lachinata/oleotecas/geocoder`. Called only from
 * the server, through Geocoding (limit and cache).
 */
interface Geocoder {

	/**
	 * Provider name, for the health and the settings.
	 */
	public function name(): string;

	/**
	 * The best match, or null when there is none.
	 *
	 * @param string $query    Address or place.
	 * @param string $country  ISO code to narrow the search ('' for any).
	 * @param string $language Language of the answer («es»).
	 * @return array{lat: float, lng: float, label: string, country: string}|null
	 * @throws \RuntimeException When the provider cannot be reached or answers with an error.
	 */
	public function search( string $query, string $country = '', string $language = '' ): ?array;
}
