<?php
/**
 * Nominatim (OpenStreetMap) adapter.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas\Geocoder;

defined( 'ABSPATH' ) || exit;

/**
 * Nominatim's search API (or a compatible one at another URL). Its usage policy asks for an
 * identifying User-Agent, at most one request per second and caching the answers: the
 * User-Agent carries the plugin, the site and the contact of the settings, and Geocoding
 * does the rest.
 */
final class Nominatim implements Geocoder {

	/**
	 * Default endpoint.
	 */
	public const URL = 'https://nominatim.openstreetmap.org/search';

	/**
	 * Adapter for an endpoint and a contact (an email for the provider).
	 *
	 * @param string $url     Search endpoint.
	 * @param string $contact Contact for the User-Agent.
	 */
	public function __construct( private string $url = self::URL, private string $contact = '' ) {
	}

	/**
	 * Provider name.
	 */
	public function name(): string {
		return 'Nominatim';
	}

	/**
	 * The User-Agent: plugin, version, site and contact.
	 */
	public function user_agent(): string {
		$contact = '' === $this->contact ? '' : '; ' . $this->contact;
		return sprintf( 'lachinata-core/%1$s (+%2$s%3$s)', LACHINATA_CORE_VERSION, home_url( '/' ), $contact );
	}

	/**
	 * The best match.
	 *
	 * @param string $query    Address or place.
	 * @param string $country  ISO code.
	 * @param string $language Language.
	 * @return array{lat: float, lng: float, label: string, country: string}|null
	 * @throws \RuntimeException When the provider fails.
	 */
	public function search( string $query, string $country = '', string $language = '' ): ?array {
		$args = array(
			'q'              => $query,
			'format'         => 'jsonv2',
			'limit'          => '1',
			'addressdetails' => '1',
		);
		if ( '' !== $country ) {
			$args['countrycodes'] = strtolower( $country );
		}
		if ( '' !== $language ) {
			$args['accept-language'] = $language;
		}
		$response = wp_remote_get(
			add_query_arg( array_map( 'rawurlencode', $args ), '' === $this->url ? self::URL : $this->url ),
			array(
				'timeout'    => 6,
				'user-agent' => $this->user_agent(),
				'headers'    => array( 'Accept' => 'application/json' ),
			)
		);
		if ( is_wp_error( $response ) ) {
			throw new \RuntimeException( esc_html( $response->get_error_message() ) );
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			/* translators: %d: HTTP status. */
			throw new \RuntimeException( esc_html( sprintf( __( 'El geocodificador respondió %d.', 'lachinata-core' ), $code ) ) );
		}
		$data  = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		$first = is_array( $data ) && isset( $data[0] ) && is_array( $data[0] ) ? $data[0] : null;
		if ( null === $first || ! is_numeric( $first['lat'] ?? null ) || ! is_numeric( $first['lon'] ?? null ) ) {
			return null;
		}
		$address = is_array( $first['address'] ?? null ) ? $first['address'] : array();
		$label   = (string) ( $address['city'] ?? $address['town'] ?? $address['village'] ?? $address['municipality'] ?? $first['name'] ?? '' );
		return array(
			'lat'     => round( (float) $first['lat'], 6 ),
			'lng'     => round( (float) $first['lon'], 6 ),
			'label'   => '' === $label ? $query : $label,
			'country' => strtoupper( (string) ( $address['country_code'] ?? '' ) ),
		);
	}
}
