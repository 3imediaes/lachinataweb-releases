<?php
/**
 * Geocoding with a limit and a cache.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

use LaChinata\Core\Modules\Oleotecas\Geocoder\Geocoder;
use LaChinata\Core\Modules\Oleotecas\Geocoder\Nominatim;

defined( 'ABSPATH' ) || exit;

/**
 * Every call to the geocoder goes through here: the answer is cached (found: 30 days; not
 * found: one day), at most one request per second leaves the site (the provider's policy),
 * and the last failure is kept for the health. The visitor's IP never reaches the
 * provider: the request is the server's.
 */
final class Geocoding {

	/**
	 * Option with the last failure (time and message).
	 */
	public const FAILURE = 'lachinata_oleotecas_geocoder_failure';

	/**
	 * Transient that holds the time of the last request (one per second).
	 */
	private const LOCK = 'lachinata_oleotecas_geocoder_lock';

	/**
	 * The adapter of the settings, or the one of `lachinata/oleotecas/geocoder`.
	 */
	public static function geocoder(): Geocoder {
		$default = new Nominatim( (string) OleotecasModule::setting( 'geocoder_url' ), (string) OleotecasModule::setting( 'geocoder_contact' ) );
		/**
		 * The geocoder of the module: any adapter of the Geocoder interface (another provider,
		 * a test double).
		 *
		 * @since 0.12.0
		 *
		 * @param Geocoder $geocoder Nominatim, with the URL and contact of the settings.
		 */
		$geocoder = apply_filters( 'lachinata/oleotecas/geocoder', $default );
		return $geocoder instanceof Geocoder ? $geocoder : $default;
	}

	/**
	 * Coordinates of a query, cached, or null when there is none or the provider failed.
	 *
	 * @param string $query   Address or place.
	 * @param string $country ISO code ('' for any).
	 * @return array{lat: float, lng: float, label: string, country: string}|null
	 */
	public static function search( string $query, string $country = '' ): ?array {
		$query = trim( (string) preg_replace( '/\s+/u', ' ', $query ) );
		if ( '' === $query || mb_strlen( $query ) > 200 ) {
			return null;
		}
		$language = substr( (string) get_locale(), 0, 2 );
		$key      = 'lachinata_oleotecas_geo_' . md5( mb_strtolower( $query ) . '|' . $country . '|' . $language );
		$cached   = get_transient( $key );
		if ( is_array( $cached ) ) {
			return isset( $cached['lat'] ) ? $cached : null;
		}
		if ( ! self::wait_turn() ) {
			return null;
		}
		try {
			$result = self::geocoder()->search( $query, $country, $language );
		} catch ( \RuntimeException $error ) {
			update_option(
				self::FAILURE,
				array(
					'at'      => time(),
					'message' => $error->getMessage(),
				),
				false
			);
			return null;
		}
		delete_option( self::FAILURE );
		set_transient( $key, $result ?? array( 'none' => true ), null === $result ? DAY_IN_SECONDS : 30 * DAY_IN_SECONDS );
		return $result;
	}

	/**
	 * One request per second: waits up to a second for its turn.
	 */
	private static function wait_turn(): bool {
		for ( $try = 0; $try < 2; $try++ ) {
			$last = (float) get_transient( self::LOCK );
			$wait = $last + 1.0 - microtime( true );
			if ( $wait <= 0 ) {
				set_transient( self::LOCK, (string) microtime( true ), 10 );
				return true;
			}
			usleep( (int) ( min( $wait, 1.0 ) * 1000000 ) );
		}
		return false;
	}

	/**
	 * The last failure in the last day, for the health.
	 *
	 * @return array{at: int, message: string}|null
	 */
	public static function last_failure(): ?array {
		$failure = get_option( self::FAILURE );
		if ( ! is_array( $failure ) || (int) ( $failure['at'] ?? 0 ) < time() - DAY_IN_SECONDS ) {
			return null;
		}
		return array(
			'at'      => (int) $failure['at'],
			'message' => (string) ( $failure['message'] ?? '' ),
		);
	}
}
