<?php
/**
 * Reader of the hand-written hours of the old fields.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

defined( 'ABSPATH' ) || exit;

/**
 * Each day of the old fields has a «morning» and an «afternoon» text, written by hand in
 * many ways: «10.00h-14.00h», «10:00 AM - 01:30 PM», «10:00 a 14:00», «10.30 - 14.00»,
 * «19:00 h», «Cerrado». A field with a range is a slot. When each field has a single time,
 * they are the opening and the closing of a continuous day («10.30h» and «21.00h»). A
 * marked day without times is closed. What it cannot read is returned as an error and
 * never guessed; what it reads with a correction («17:300h» → 17:30) comes with a note.
 */
final class HoursParser {

	/**
	 * One time: hours, optional minutes (with «:» or «.»), optional AM/PM and «h».
	 */
	private const TIME = '(\d{1,2})(?:\s*[:.]\s*(\d{1,3}))?\s*(a\.?\s?m\.?|p\.?\s?m\.?)?\s*(?:h(?:rs?|oras?)?\.?)?';

	/**
	 * Reads one day.
	 *
	 * @param string $morning   Morning text.
	 * @param string $afternoon Afternoon text.
	 * @return array{slots: list<array{0: string, 1: string}>|null, notes: list<string>, error: string}
	 */
	public static function day( string $morning, string $afternoon ): array {
		$notes = array();
		$first = self::field( $morning, $notes );
		$last  = self::field( $afternoon, $notes );
		if ( null === $first || null === $last ) {
			return self::fail( $notes, self::quote( null === $first ? $morning : $afternoon ) );
		}
		if ( 'closed' === $first || 'closed' === $last ) {
			return array(
				'slots' => array(),
				'notes' => $notes,
				'error' => '',
			);
		}
		// Two single times: opening and closing of a continuous day.
		if ( 1 === count( $first ) && 1 === count( $last ) ) {
			$slots = array( array( $first[0], $last[0] ) );
		} elseif ( 1 === count( $first ) || 1 === count( $last ) ) {
			return self::fail( $notes, self::quote( 1 === count( $first ) ? $morning : $afternoon ) );
		} else {
			$slots = array_values( array_filter( array( $first, $last ) ) );
		}
		$valid = Schedule::slots( $slots );
		if ( null === $valid ) {
			return self::fail( $notes, self::quote( trim( $morning . ' / ' . $afternoon, ' /' ) ) );
		}
		return array(
			'slots' => $valid,
			'notes' => $notes,
			'error' => '',
		);
	}

	/**
	 * Reads one field: an empty list when empty, «closed», one time or a range, or null
	 * when it cannot.
	 *
	 * @param string   $text  Text.
	 * @param string[] $notes Notes of corrections (by reference).
	 * @phpstan-param list<string> $notes
	 * @return list<string>|'closed'|null
	 */
	public static function field( string $text, array &$notes ) {
		$text = trim( (string) preg_replace( '/\s+/u', ' ', $text ) );
		if ( '' === $text ) {
			return array();
		}
		if ( preg_match( '/^cerrad[oa]s?\.?$/iu', $text ) ) {
			return 'closed';
		}
		$separator = '\s*(?:-|–|—|\ba\b|\bhasta\b)\s*';
		if ( preg_match( '/^' . self::TIME . $separator . self::TIME . '$/iu', $text, $match ) ) {
			$from = self::to_time( $match[1], $match[2], $match[3], $text, $notes );
			$to   = self::to_time( $match[4], $match[5] ?? '', $match[6] ?? '', $text, $notes, true );
			return null === $from || null === $to ? null : array( $from, $to );
		}
		if ( preg_match( '/^' . self::TIME . '$/iu', $text, $match ) ) {
			$time = self::to_time( $match[1], $match[2] ?? '', $match[3] ?? '', $text, $notes, true );
			return null === $time ? null : array( $time );
		}
		return null;
	}

	/**
	 * «HH:MM» from the parts, or null.
	 *
	 * @param string   $hours    Hours.
	 * @param string   $minutes  Minutes (1 to 3 digits).
	 * @param string   $meridiem AM/PM marker.
	 * @param string   $text     Whole text, for the note.
	 * @param string[] $notes    Notes (by reference).
	 * @phpstan-param list<string> $notes
	 * @param bool     $end      Whether it may be 24:00.
	 */
	private static function to_time( string $hours, string $minutes, string $meridiem, string $text, array &$notes, bool $end = false ): ?string {
		$h = (int) $hours;
		if ( 3 === strlen( $minutes ) ) {
			// «17:300h»: a typed zero too many. Only when the first two make a valid minute.
			if ( '0' !== substr( $minutes, 2 ) || (int) substr( $minutes, 0, 2 ) > 59 ) {
				return null;
			}
			$minutes = substr( $minutes, 0, 2 );
			$notes[] = sprintf(
				/* translators: 1: text as written, 2: time read. */
				__( '«%1$s»: leído como %2$s', 'lachinata-core' ),
				$text,
				sprintf( '%02d:%s', $h, $minutes )
			);
		}
		$m = '' === $minutes ? 0 : (int) str_pad( $minutes, 2, '0' );
		if ( '' !== $meridiem ) {
			$pm = 'p' === strtolower( $meridiem[0] );
			if ( $h < 1 || $h > 12 ) {
				return null;
			}
			$h = $pm ? ( 12 === $h ? 12 : $h + 12 ) : ( 12 === $h ? 0 : $h );
		}
		return Schedule::time( sprintf( '%d:%02d', $h, $m ), $end );
	}

	/**
	 * A failed day.
	 *
	 * @param string[] $notes Notes.
	 * @phpstan-param list<string> $notes
	 * @param string   $what  What could not be read.
	 * @return array{slots: null, notes: list<string>, error: string}
	 */
	private static function fail( array $notes, string $what ): array {
		return array(
			'slots' => null,
			'notes' => $notes,
			/* translators: %s: text as written. */
			'error' => sprintf( __( 'No se entiende %s', 'lachinata-core' ), $what ),
		);
	}

	/**
	 * A text between quotes.
	 *
	 * @param string $text Text.
	 */
	private static function quote( string $text ): string {
		return '«' . trim( $text ) . '»';
	}
}
