<?php
/**
 * Migration from the old fields (ACF) to the module's fields.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

defined( 'ABSPATH' ) || exit;

/**
 * Reads the old fields of each published store (they are in post meta with their ACF name),
 * converts what it can and reports the rest: hand-written hours (HoursParser), address by
 * parts, phone and WhatsApp in E.164, email, profiles, photos, Click & Collect as a service,
 * the time zone (the nearest of the country's zones to the coordinates), the country as a
 * zone of the first level and, from the map of the shop, the zones and the corrections of
 * each store. The old fields are never touched; a store already migrated is skipped unless
 * forced. Nothing is guessed: what cannot be read goes to the report and is left empty.
 *
 * The map is content of each shop (a JSON file, not code):
 * `countries` (text of the old field → ISO), `zones` (country, name, slug, group, stores by
 * slug) and `stores` (by slug: name, city, street, whatsapp_from_phone).
 *
 * @phpstan-type Issue array{level: string, field: string, message: string}
 * @phpstan-type Result array{slug: string, fields: array<string, mixed>, country: string, services: list<string>, zone: string, issues: list<Issue>}
 */
final class Migration {

	/**
	 * Days of the old fields, in order.
	 */
	public const OLD_DAYS = array(
		'mon' => 'lunes',
		'tue' => 'martes',
		'wed' => 'miercoles',
		'thu' => 'jueves',
		'fri' => 'viernes',
		'sat' => 'sabado',
		'sun' => 'domingo',
	);

	/**
	 * Old networks → networks of SocialLinks ('' = not supported).
	 */
	private const OLD_SOCIAL = array(
		'link_facebook'  => 'facebook',
		'link_twitter'   => 'x',
		'link_instagram' => 'instagram',
		'link_tiktok'    => 'tiktok',
		'link_youtube'   => 'youtube',
		'link_pinterest' => '',
	);

	/**
	 * Name of the service of the old «click_and_colleckt».
	 */
	public const CLICK_COLLECT = 'Click & Collect';

	/**
	 * Converts one store. Pure: no writes, so the dry run and the tests use it as is.
	 *
	 * @param string               $slug    Slug.
	 * @param string               $title   Title.
	 * @param string               $content Post content.
	 * @param array<string, mixed> $meta    Old fields (single values).
	 * @param array<string, mixed> $map     Map of the shop.
	 * @return Result
	 */
	public static function convert( string $slug, string $title, string $content, array $meta, array $map = array() ): array {
		$issues  = array();
		$fix     = (array) ( ( (array) ( $map['stores'] ?? array() ) )[ $slug ] ?? array() );
		$text    = static fn( string $key ): string => trim( (string) preg_replace( '/\s+/u', ' ', (string) ( $meta[ $key ] ?? '' ) ) );
		$issue   = static function ( string $level, string $field, string $message ) use ( &$issues ): void {
			$issues[] = array(
				'level'   => $level,
				'field'   => $field,
				'message' => $message,
			);
		};
		$country = self::country( $text( 'pais' ), (array) ( $map['countries'] ?? array() ) );
		if ( '' === $country ) {
			/* translators: %s: country as written. */
			$issue( 'error', 'pais', sprintf( __( 'País sin reconocer: «%s»', 'lachinata-core' ), $text( 'pais' ) ) );
		}

		// Name.
		$name = isset( $fix['name'] ) ? Fields::text_line( $fix['name'] ) : self::short_name( $title );

		// Address.
		$street = isset( $fix['street'] ) ? Fields::text_line( $fix['street'] ) : self::street( $text( 'direccion' ), $country );
		$city   = isset( $fix['city'] ) ? Fields::text_line( $fix['city'] ) : self::city( $text( 'poblacion' ) );
		if ( ! isset( $fix['city'] ) && str_contains( $text( 'poblacion' ), ',' ) ) {
			/* translators: %s: city as written. */
			$issue( 'warning', 'poblacion', sprintf( __( 'Ciudad con varias partes, revísala: «%s»', 'lachinata-core' ), $text( 'poblacion' ) ) );
		}
		if ( '' === $street ) {
			$issue( 'error', 'direccion', __( 'Sin dirección', 'lachinata-core' ) );
		} elseif ( $street !== $text( 'direccion' ) ) {
			/* translators: 1: before, 2: after. */
			$issue( 'info', 'direccion', sprintf( __( '«%1$s» → «%2$s»', 'lachinata-core' ), $text( 'direccion' ), $street ) );
		}

		// Coordinates and time zone.
		$lat = Fields::latitude( $meta['lat_meta_key'] ?? '' );
		$lng = Fields::longitude( $meta['lng_meta_key'] ?? '' );
		if ( null === $lat || null === $lng ) {
			$issue( 'error', 'lat_meta_key', __( 'Sin coordenadas válidas', 'lachinata-core' ) );
		}
		$timezone = self::timezone( $country, $lat, $lng );
		if ( '' === $timezone && '' !== $country ) {
			$issue( 'error', 'timezone', __( 'No se pudo deducir la zona horaria', 'lachinata-core' ) );
		}

		// Phone and WhatsApp.
		$phone = '';
		if ( '' !== $text( 'link_telefono' ) ) {
			$phone = (string) StorePhone::normalize( $text( 'link_telefono' ), $country );
			if ( '' === $phone ) {
				/* translators: %s: phone as written. */
				$issue( 'warning', 'link_telefono', sprintf( __( 'Teléfono sin convertir: «%s»', 'lachinata-core' ), $text( 'link_telefono' ) ) );
			}
		}
		$whatsapp = '';
		if ( '' !== $text( 'link_whatsapp' ) ) {
			$whatsapp = (string) StorePhone::normalize( (string) preg_replace( '#^https?://(wa\.me|api\.whatsapp\.com/send\?phone=)/?#', '', $text( 'link_whatsapp' ) ), $country );
			if ( '' === $whatsapp ) {
				/* translators: %s: number as written. */
				$issue( 'warning', 'link_whatsapp', sprintf( __( 'WhatsApp sin convertir: «%s»', 'lachinata-core' ), $text( 'link_whatsapp' ) ) );
			}
		} elseif ( ! empty( $fix['whatsapp_from_phone'] ) && '' !== $phone ) {
			$whatsapp = $phone;
			$issue( 'warning', 'link_whatsapp', __( 'WhatsApp copiado del teléfono (la tienda lo dice en su texto): que la central lo confirme', 'lachinata-core' ) );
		} else {
			$issue( 'info', 'link_whatsapp', __( 'Sin WhatsApp', 'lachinata-core' ) );
		}

		// Email.
		$email = '';
		foreach ( array( 'link_mensajeria', 'link_mail' ) as $key ) {
			$candidate = sanitize_email( (string) preg_replace( '/^mailto:/i', '', $text( $key ) ) );
			if ( '' === $email && is_email( $candidate ) ) {
				$email = $candidate;
			} elseif ( '' !== $text( $key ) && ! is_email( $candidate ) ) {
				/* translators: %s: value as written. */
				$issue( 'warning', $key, sprintf( __( 'Correo sin convertir: «%s»', 'lachinata-core' ), $text( $key ) ) );
			}
		}

		// Profiles.
		$social = array();
		foreach ( self::OLD_SOCIAL as $key => $network ) {
			$url = $text( $key );
			if ( '' === $url ) {
				continue;
			}
			if ( '' === $network ) {
				/* translators: 1: field, 2: URL. */
				$issue( 'warning', $key, sprintf( __( 'Red no admitida (%1$s): %2$s', 'lachinata-core' ), $key, $url ) );
				continue;
			}
			$social[] = array(
				'network' => $network,
				'url'     => $url,
			);
		}

		// Photos.
		$photos = array();
		$raw    = (string) ( $meta['galeria'] ?? '' );
		if ( '' !== $raw ) {
			$ids    = is_serialized( $raw ) ? @unserialize( $raw, array( 'allowed_classes' => false ) ) : array(); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_unserialize,WordPress.PHP.NoSilencedErrors.Discouraged -- ACF's own format, without objects.
			$photos = array_values( array_filter( array_map( 'absint', is_array( $ids ) ? $ids : array() ) ) );
		}

		// Hours.
		$week   = array();
		$failed = false;
		foreach ( self::OLD_DAYS as $day => $old ) {
			$read = HoursParser::day( (string) ( $meta[ 'horarios_0_' . $old . '_0_manana' ] ?? '' ), (string) ( $meta[ 'horarios_0_' . $old . '_0_tarde' ] ?? '' ) );
			foreach ( $read['notes'] as $note ) {
				$issue( 'warning', 'horarios', Schedule::day_names()[ $day ] . ': ' . $note );
			}
			if ( null === $read['slots'] ) {
				$failed = true;
				$issue( 'error', 'horarios', Schedule::day_names()[ $day ] . ': ' . $read['error'] );
				continue;
			}
			$week[ $day ] = $read['slots'];
		}
		if ( ! $failed && ! Schedule::has_hours( $week ) ) {
			$issue( 'error', 'horarios', __( 'Sin horario', 'lachinata-core' ) );
		}

		// What is not migrated.
		if ( '' !== trim( wp_strip_all_tags( $content ) ) || str_contains( $content, '<table' ) ) {
			/* translators: %s: start of the old text. */
			$issue( 'warning', 'content', sprintf( __( 'El contenido de la entrada no se migra al texto propio: «%s»', 'lachinata-core' ), wp_trim_words( wp_strip_all_tags( $content ), 12, '…' ) ) );
		}
		if ( '' !== $text( 'otros_servicios_0_titulo' ) ) {
			/* translators: %s: old service. */
			$issue( 'warning', 'otros_servicios', sprintf( __( 'Otro servicio sin migrar: «%s»', 'lachinata-core' ), $text( 'otros_servicios_0_titulo' ) ) );
		}

		$services = 'si' === strtolower( remove_accents( $text( 'click_and_colleckt' ) ) ) ? array( self::CLICK_COLLECT ) : array();

		$fields = array(
			Fields::NAME     => $name,
			Fields::ADDRESS  => array(
				'street'   => $street,
				'postcode' => $text( 'codigo_postal' ),
				'city'     => $city,
				'region'   => '',
				'country'  => $country,
			),
			Fields::TIMEZONE => $timezone,
			Fields::PHONE    => $phone,
			Fields::WHATSAPP => $whatsapp,
			Fields::EMAIL    => $email,
			Fields::SOCIAL   => $social,
			Fields::PHOTOS   => $photos,
		);
		if ( null !== $lat && null !== $lng ) {
			$fields[ Fields::LAT ] = $lat;
			$fields[ Fields::LNG ] = $lng;
		}
		if ( ! $failed ) {
			$fields[ Fields::HOURS ] = Schedule::sanitize_week( $week );
		}
		return array(
			'slug'     => $slug,
			'fields'   => $fields,
			'country'  => $country,
			'services' => $services,
			'zone'     => self::zone_of( $slug, $map ),
			'issues'   => $issues,
		);
	}

	/**
	 * ISO code of a country as written («España», «NORUEGA»): the map first, then the
	 * country names of WooCommerce.
	 *
	 * @param string                $text Country as written.
	 * @param array<string, string> $map  Text → ISO.
	 */
	public static function country( string $text, array $map = array() ): string {
		$fold = static fn( string $value ): string => trim( mb_strtolower( remove_accents( html_entity_decode( $value, ENT_QUOTES ) ) ) );
		$key  = $fold( $text );
		if ( '' === $key ) {
			return '';
		}
		foreach ( $map as $name => $code ) {
			if ( $fold( (string) $name ) === $key ) {
				return strtoupper( (string) $code );
			}
		}
		if ( function_exists( 'WC' ) && WC()->countries ) {
			foreach ( WC()->countries->get_countries() as $code => $name ) {
				if ( $fold( (string) $name ) === $key || strtolower( (string) $code ) === $key ) {
					return (string) $code;
				}
			}
		}
		return '';
	}

	/**
	 * Short name from the old title: «Madrid - Sol» → «Madrid · Sol».
	 *
	 * @param string $title Title.
	 */
	public static function short_name( string $title ): string {
		$name = (string) preg_replace( '/\s*-\s*/u', ' · ', trim( $title ) );
		return Fields::text_line( $name );
	}

	/**
	 * City: trimmed, and in title case when it was written in capitals.
	 *
	 * @param string $city City as written.
	 */
	public static function city( string $city ): string {
		$city = trim( $city, " \t\n\r\0\x0B," );
		return self::is_upper( $city ) ? self::title_case( $city ) : $city;
	}

	/**
	 * Street normalised: spaces, title case when in capitals and, in Spain, the usual
	 * abbreviations («C/ Hermosilla 88» → «Calle Hermosilla, 88»; «nº 6» → «6»; «LOCAL 3» →
	 * «local 3»).
	 *
	 * @param string $street  Street as written.
	 * @param string $country ISO code.
	 */
	public static function street( string $street, string $country ): string {
		$street = trim( (string) preg_replace( '/\s+/u', ' ', $street ), " ,\t" );
		if ( '' === $street ) {
			return '';
		}
		if ( self::is_upper( $street ) ) {
			$street = self::title_case( $street );
		}
		if ( 'ES' !== $country ) {
			return $street;
		}
		$street = (string) preg_replace( '#^c\s*/\s*\.?\s*#iu', 'Calle ', $street );
		$street = (string) preg_replace( '#^c\.\s+(?!c\.)#iu', 'Calle ', $street );
		$street = (string) preg_replace( '#^(calle\s+)?avda\.?\s+#iu', 'Avenida ', $street );
		$street = (string) preg_replace( '#\s*\bn[º°]\.?\s*(\d)#iu', ' $1', $street );
		// «LOCAL 3», «bajo» after the number: «, local 3». Not after a full stop.
		$street = (string) preg_replace_callback( '#(?<=[\p{L}\d])\s+(local|bajo)\b#iu', static fn( array $found ): string => ', ' . mb_strtolower( $found[1] ), $street );
		// A comma before the number of a street without one: «Calle Hermosilla 88».
		$street = (string) preg_replace( '/^((?:Calle|Avenida|Plaza|Paseo|Carrer|Passeig|Ronda|Camino)\s[^,\d]+?)\s(\d+[a-zA-Z]?)\b/u', '$1, $2', $street, 1 );
		$street = (string) preg_replace( '/\s*,(\s*,)*\s*/u', ', ', $street );
		return trim( $street, ' ,' );
	}

	/**
	 * Whether a text has letters and none in lower case.
	 *
	 * @param string $text Text.
	 */
	private static function is_upper( string $text ): bool {
		return (bool) preg_match( '/\p{L}/u', $text ) && ! preg_match( '/\p{Ll}/u', $text );
	}

	/**
	 * Title case with the small words in lower case («Santa Engracia», «de la Fama»).
	 *
	 * @param string $text Text.
	 */
	private static function title_case( string $text ): string {
		$text = mb_convert_case( mb_strtolower( $text ), MB_CASE_TITLE );
		return (string) preg_replace_callback( '/(?<=\s)(De|Del|La|Las|Los|El|Y|E)(?=\s)/u', static fn( array $found ): string => mb_strtolower( $found[1] ), $text );
	}

	/**
	 * Time zone of a store: of the country's IANA zones, the one whose reference city is the
	 * nearest to the coordinates (Atlantic/Canary for Las Palmas, America/Mexico_City for
	 * Puebla); the only one when the country has one.
	 *
	 * @param string     $country ISO code.
	 * @param float|null $lat     Latitude.
	 * @param float|null $lng     Longitude.
	 */
	public static function timezone( string $country, ?float $lat, ?float $lng ): string {
		if ( '' === $country ) {
			return '';
		}
		$zones = \DateTimeZone::listIdentifiers( \DateTimeZone::PER_COUNTRY, $country );
		if ( ! $zones ) {
			return '';
		}
		if ( 1 === count( $zones ) || null === $lat || null === $lng ) {
			return 1 === count( $zones ) ? $zones[0] : '';
		}
		$best = '';
		$min  = INF;
		foreach ( $zones as $identifier ) {
			$location = ( new \DateTimeZone( $identifier ) )->getLocation();
			if ( ! is_array( $location ) ) {
				continue;
			}
			$distance = Store::distance( $lat, $lng, (float) $location['latitude'], (float) $location['longitude'] );
			if ( $distance < $min ) {
				$min  = $distance;
				$best = $identifier;
			}
		}
		return $best;
	}

	/**
	 * The zone of a store in the map (its slug), or ''.
	 *
	 * @param string               $slug Slug.
	 * @param array<string, mixed> $map  Map.
	 */
	private static function zone_of( string $slug, array $map ): string {
		foreach ( (array) ( $map['zones'] ?? array() ) as $zone ) {
			if ( is_array( $zone ) && in_array( $slug, (array) ( $zone['stores'] ?? array() ), true ) ) {
				return (string) ( $zone['slug'] ?? sanitize_title( (string) ( $zone['name'] ?? '' ) ) );
			}
		}
		return '';
	}

	/**
	 * Runs the migration over the published stores.
	 *
	 * @param array<string, mixed> $map   Map of the shop.
	 * @param bool                 $write False for a dry run.
	 * @param bool                 $force Migrate again the stores already migrated.
	 * @return list<array{slug: string, state: string, issues: list<Issue>}>
	 */
	public static function run( array $map, bool $write, bool $force = false ): array {
		$report = array();
		$posts  = get_posts(
			array(
				'post_type'   => Model::POST_TYPE,
				'post_status' => 'publish',
				'numberposts' => -1,
				'orderby'     => 'ID',
				'order'       => 'ASC',
			)
		);
		$zones  = $write ? self::zone_terms( $map ) : array();
		foreach ( $posts as $post ) {
			if ( ! $force && '' !== (string) get_post_meta( $post->ID, Fields::MIGRATED, true ) ) {
				$report[] = array(
					'slug'   => $post->post_name,
					'state'  => 'skipped',
					'issues' => array(),
				);
				continue;
			}
			$meta = array();
			foreach ( (array) get_post_meta( $post->ID ) as $key => $values ) {
				$meta[ (string) $key ] = is_array( $values ) ? (string) ( $values[0] ?? '' ) : '';
			}
			$result = self::convert( $post->post_name, $post->post_title, $post->post_content, $meta, $map );
			$photos = array_values( array_filter( (array) $result['fields'][ Fields::PHOTOS ], static fn( $id ): bool => wp_attachment_is_image( (int) $id ) ) );
			if ( count( $photos ) !== count( (array) $result['fields'][ Fields::PHOTOS ] ) ) {
				$result['issues'][] = array(
					'level'   => 'warning',
					'field'   => 'galeria',
					'message' => __( 'Algunas fotos de la galería no existen', 'lachinata-core' ),
				);
			}
			$result['fields'][ Fields::PHOTOS ] = $photos;
			if ( $write ) {
				self::write( $post, $result, $zones );
			}
			$report[] = array(
				'slug'   => $post->post_name,
				'state'  => $write ? 'migrated' : 'dry-run',
				'issues' => $result['issues'],
			);
		}
		if ( $write ) {
			Data::touch();
		}
		return $report;
	}

	/**
	 * Writes one converted store.
	 *
	 * @param \WP_Post             $post   Post.
	 * @param array<string, mixed> $result Conversion.
	 * @phpstan-param Result $result
	 * @param array<string, int>   $zones  Zone slug → term id.
	 */
	private static function write( \WP_Post $post, array $result, array $zones ): void {
		foreach ( $result['fields'] as $key => $value ) {
			update_post_meta( $post->ID, $key, $value );
		}
		$terms = array();
		if ( '' !== $result['country'] ) {
			$terms[] = self::country_term( $result['country'] );
		}
		if ( '' !== $result['zone'] && isset( $zones[ $result['zone'] ] ) ) {
			$terms[] = $zones[ $result['zone'] ];
		}
		$terms = array_values( array_filter( $terms ) );
		if ( $terms ) {
			wp_set_object_terms( $post->ID, $terms, Model::ZONE );
		}
		if ( $result['services'] ) {
			wp_set_object_terms( $post->ID, $result['services'], Model::SERVICE );
		}
		update_post_meta( $post->ID, Fields::MIGRATED, gmdate( 'c' ) . ' ' . LACHINATA_CORE_VERSION );
	}

	/**
	 * Term of a country (first level of the zones), created with the name of WooCommerce.
	 *
	 * @param string $country ISO code.
	 */
	public static function country_term( string $country ): int {
		$name = Store::country_name( $country );
		$term = get_term_by( 'slug', sanitize_title( $name ), Model::ZONE );
		if ( $term instanceof \WP_Term ) {
			return (int) $term->term_id;
		}
		$created = wp_insert_term( $name, Model::ZONE );
		return is_array( $created ) ? (int) $created['term_id'] : 0;
	}

	/**
	 * Zone terms of the map, under their country, with their grouping label.
	 *
	 * @param array<string, mixed> $map Map.
	 * @return array<string, int> Slug → term id.
	 */
	private static function zone_terms( array $map ): array {
		$out = array();
		foreach ( (array) ( $map['zones'] ?? array() ) as $zone ) {
			if ( ! is_array( $zone ) || empty( $zone['name'] ) ) {
				continue;
			}
			$slug   = (string) ( $zone['slug'] ?? sanitize_title( (string) $zone['name'] ) );
			$parent = empty( $zone['country'] ) ? 0 : self::country_term( strtoupper( (string) $zone['country'] ) );
			$term   = get_term_by( 'slug', $slug, Model::ZONE );
			$id     = $term instanceof \WP_Term ? (int) $term->term_id : 0;
			if ( ! $id ) {
				$created = wp_insert_term(
					(string) $zone['name'],
					Model::ZONE,
					array(
						'slug'   => $slug,
						'parent' => $parent,
					)
				);
				$id      = is_array( $created ) ? (int) $created['term_id'] : 0;
			}
			if ( $id && ! empty( $zone['group'] ) && '' === (string) get_term_meta( $id, Fields::ZONE_GROUP, true ) ) {
				update_term_meta( $id, Fields::ZONE_GROUP, Fields::text_line( $zone['group'] ) );
			}
			if ( $id ) {
				$out[ $slug ] = $id;
			}
		}
		return $out;
	}
}
