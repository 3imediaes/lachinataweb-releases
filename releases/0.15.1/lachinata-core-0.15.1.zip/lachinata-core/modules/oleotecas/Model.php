<?php
/**
 * Post type of the stores, zones and services.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * The post type keeps its name and its URLs (`/oleoteca/{slug}/`, without the front of the
 * permalinks), so ids, links and what they rank for stay. The archive is the finder
 * (`/oleotecas/`); each zone (Country › Zone, hierarchical) has `/oleotecas/{zone}/`, flat.
 * The old archive (`/oleoteca/`) goes to the finder with a 301.
 */
final class Model {

	public const POST_TYPE = 'oleoteca';
	public const ZONE      = 'lc_oleoteca_zona';
	public const SERVICE   = 'lc_oleoteca_servicio';

	/**
	 * Whether another plugin had registered the post type before the module (health).
	 *
	 * @var bool
	 */
	private static bool $taken = false;

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'init', array( self::class, 'register' ), 5 );
		Hooks::add_action( 'template_redirect', array( self::class, 'redirect_old_archive' ), 1 );
	}

	/**
	 * URL segment of each store (`/oleoteca/{slug}/`).
	 */
	public static function single_slug(): string {
		$slug = sanitize_title( (string) OleotecasModule::setting( 'slug_single' ) );
		return '' === $slug ? self::POST_TYPE : $slug;
	}

	/**
	 * URL segment of the finder and the zones (`/oleotecas/`).
	 */
	public static function archive_slug(): string {
		$slug = sanitize_title( (string) OleotecasModule::setting( 'slug_archive' ) );
		return '' === $slug ? self::POST_TYPE . 's' : $slug;
	}

	/**
	 * Registers the post type, the taxonomies and the fields.
	 */
	public static function register(): void {
		self::$taken = post_type_exists( self::POST_TYPE );
		$singular    = Texts::noun();
		$plural      = Texts::noun( true );
		register_post_type(
			self::POST_TYPE,
			array(
				'labels'          => array(
					'name'          => ucfirst( $plural ),
					'singular_name' => ucfirst( $singular ),
					'menu_name'     => ucfirst( $plural ),
					/* translators: %s: name of a store («oleoteca»). */
					'add_new_item'  => sprintf( __( 'Añadir %s', 'lachinata-core' ), $singular ),
					/* translators: %s: name of a store («oleoteca»). */
					'edit_item'     => sprintf( __( 'Editar %s', 'lachinata-core' ), $singular ),
					'all_items'     => ucfirst( $plural ),
				),
				'public'          => true,
				'show_in_rest'    => true,
				'menu_icon'       => 'dashicons-store',
				'menu_position'   => 56,
				// The block editor (for the store's panel) needs `editor`; the page does not print
				// the content, so the canvas is locked and empty.
				'supports'        => array( 'title', 'editor', 'custom-fields', 'revisions' ),
				'template'        => array(),
				'template_lock'   => 'all',
				'has_archive'     => self::archive_slug(),
				'rewrite'         => array(
					'slug'       => self::single_slug(),
					'with_front' => false,
					'feeds'      => false,
				),
				'capability_type' => 'post',
			)
		);
		register_taxonomy(
			self::ZONE,
			self::POST_TYPE,
			array(
				'labels'            => array(
					'name'          => __( 'Zonas', 'lachinata-core' ),
					'singular_name' => __( 'Zona', 'lachinata-core' ),
					'parent_item'   => __( 'País (zona superior)', 'lachinata-core' ),
					'add_new_item'  => __( 'Añadir zona o país', 'lachinata-core' ),
				),
				'hierarchical'      => true,
				'public'            => true,
				'show_in_rest'      => true,
				'show_admin_column' => true,
				'rewrite'           => array(
					'slug'         => self::archive_slug(),
					'with_front'   => false,
					'hierarchical' => false,
				),
			)
		);
		register_taxonomy(
			self::SERVICE,
			self::POST_TYPE,
			array(
				'labels'            => array(
					'name'          => __( 'Servicios', 'lachinata-core' ),
					'singular_name' => __( 'Servicio', 'lachinata-core' ),
					'add_new_item'  => __( 'Añadir servicio', 'lachinata-core' ),
				),
				'hierarchical'      => false,
				'public'            => false,
				'show_ui'           => true,
				'show_in_rest'      => true,
				'show_admin_column' => true,
				'rewrite'           => false,
			)
		);
		Fields::register();
	}

	/**
	 * Whether the post type was already registered by someone else when the module did.
	 */
	public static function taken(): bool {
		return self::$taken;
	}

	/**
	 * The old archive (`/oleoteca/`) moves to the finder.
	 */
	public static function redirect_old_archive(): void {
		$path = trim( (string) wp_parse_url( (string) wp_unslash( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH ), '/' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Only compared.
		$home = trim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
		$path = '' !== $home && str_starts_with( $path, $home ) ? trim( substr( $path, strlen( $home ) ), '/' ) : $path;
		if ( self::single_slug() === $path && self::single_slug() !== self::archive_slug() ) {
			wp_safe_redirect( (string) get_post_type_archive_link( self::POST_TYPE ), 301 );
			exit;
		}
	}
}
