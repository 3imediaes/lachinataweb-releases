<?php
/**
 * The partners' API: the hours of one store, for the franchises' panel.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * `GET` and `PUT /lachinata/v1/oleotecas/partner/<slug>` with `Authorization: Bearer <token>`
 * (Partners). Only the weekly hours, the specials and the temporary closure of that store
 * are read and written; anything else in the body is ignored and said so. The same
 * validation as the editor (Schedule), with readable errors by field and nothing saved when
 * one fails. `X-LC-Actor` (the email of the person, as the panel knows it) is required to
 * write and goes to the record (ChangeLog). `ETag` and an optional `If-Match` (412) keep two
 * people from overwriting each other. The finder's JSON is written again at once. The
 * contract, with examples, is in docs/guias/oleotecas.md.
 *
 * @phpstan-import-type Special from Schedule
 */
final class PartnerApi {

	/**
	 * Fields of the body that are read; anything else is ignored.
	 */
	public const ALLOWED = array( 'hours', 'specials', 'closure' );

	/**
	 * Most specials of a store.
	 */
	public const MAX_SPECIALS = 100;

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'rest_api_init', array( self::class, 'routes' ) );
	}

	/**
	 * Registers the routes.
	 */
	public static function routes(): void {
		register_rest_route(
			Rest::NAMESPACE,
			'/oleotecas/partner/(?P<slug>[a-z0-9-]+)',
			array(
				array(
					'methods'             => 'GET',
					'callback'            => Hooks::rest( array( self::class, 'show' ) ),
					'permission_callback' => Hooks::wrap( array( self::class, 'permission' ), false ),
				),
				array(
					'methods'             => 'PUT',
					'callback'            => Hooks::rest( array( self::class, 'update' ) ),
					'permission_callback' => Hooks::wrap( array( self::class, 'permission' ), false ),
				),
			)
		);
	}

	/**
	 * Token of this request, once verified.
	 *
	 * @var array{id: string, created: int}|null
	 */
	private static ?array $token = null;

	/**
	 * A valid token.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @phpstan-param \WP_REST_Request<array<string, mixed>> $request
	 * @return true|\WP_Error
	 */
	public static function permission( \WP_REST_Request $request ) {
		$token = Partners::verify( (string) $request->get_header( 'authorization' ) );
		if ( null === $token ) {
			return new \WP_Error( 'lachinata_oleotecas_token', __( 'Falta el token o no es válido (Authorization: Bearer …).', 'lachinata-core' ), array( 'status' => 401 ) );
		}
		self::$token = $token;
		return true;
	}

	/**
	 * 429 with `Retry-After` when the token is over its limit, or null.
	 */
	private static function limited(): ?\WP_REST_Response {
		$wait = null === self::$token ? null : Partners::throttle( self::$token['id'] );
		if ( null === $wait ) {
			return null;
		}
		$response = new \WP_REST_Response(
			array(
				'code'    => 'lachinata_oleotecas_limit',
				/* translators: %d: requests. */
				'message' => sprintf( __( 'Demasiadas peticiones: como mucho %d cada 10 minutos por token.', 'lachinata-core' ), Partners::LIMIT ),
				'data'    => array( 'status' => 429 ),
			),
			429
		);
		$response->header( 'Retry-After', (string) $wait );
		return $response;
	}

	/**
	 * The published store of a slug.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @phpstan-param \WP_REST_Request<array<string, mixed>> $request
	 */
	private static function post( \WP_REST_Request $request ): ?\WP_Post {
		$post = get_page_by_path( sanitize_title( (string) $request['slug'] ), OBJECT, Model::POST_TYPE );
		return $post instanceof \WP_Post && 'publish' === $post->post_status ? $post : null;
	}

	/**
	 * 410 for a store closed for good; 403 for a token older than its last closing (the store
	 * opened again: it needs a new token). Null when the token may act on it.
	 *
	 * @param \WP_Post $post Store.
	 */
	private static function gone( \WP_Post $post ): ?\WP_Error {
		if ( Closure::closed( $post->ID ) ) {
			return new \WP_Error( 'lachinata_oleotecas_closed', __( 'Esta oleoteca ha cerrado: su ficha ya no se puede cambiar.', 'lachinata-core' ), array( 'status' => 410 ) );
		}
		if ( null !== self::$token && ! Closure::token_allowed( $post->ID, (int) self::$token['created'] ) ) {
			return new \WP_Error( 'lachinata_oleotecas_token_closed', __( 'Este token es anterior al cierre de la oleoteca: crea uno nuevo para ella.', 'lachinata-core' ), array( 'status' => 403 ) );
		}
		return null;
	}

	/**
	 * 404 for a slug without a store.
	 */
	private static function not_found(): \WP_Error {
		return new \WP_Error( 'lachinata_oleotecas_not_found', __( 'No existe esa oleoteca.', 'lachinata-core' ), array( 'status' => 404 ) );
	}

	/**
	 * What the API says of a store.
	 *
	 * @param \WP_Post $post Store.
	 * @return array<string, mixed>
	 */
	public static function data( \WP_Post $post ): array {
		$week     = Schedule::sanitize_week( get_post_meta( $post->ID, Fields::HOURS, true ) );
		$specials = Schedule::sanitize_specials( get_post_meta( $post->ID, Fields::SPECIAL, true ) );
		$name     = Fields::text_line( get_post_meta( $post->ID, Fields::NAME, true ) );
		return array(
			'slug'     => $post->post_name,
			'name'     => '' === $name ? get_the_title( $post ) : $name,
			'timezone' => (string) get_post_meta( $post->ID, Fields::TIMEZONE, true ),
			'hours'    => $week,
			'specials' => array_map( array( self::class, 'public_special' ), Schedule::without_closure( $specials ) ),
			'closure'  => Schedule::closure( $specials ),
			'modified' => mysql2date( 'c', $post->post_modified_gmt . '+00:00', false ),
			'version'  => self::version( $week, $specials ),
		);
	}

	/**
	 * A special as the API gives it (without its kind).
	 *
	 * @param array<string, mixed> $special Special.
	 * @phpstan-param Special $special
	 * @return array{from: string, to: string, slots: array<int, mixed>, note: string}
	 */
	private static function public_special( array $special ): array {
		return array(
			'from'  => $special['from'],
			'to'    => $special['to'],
			'slots' => $special['slots'],
			'note'  => $special['note'],
		);
	}

	/**
	 * Version of the hours (ETag): changes with any of the three fields.
	 *
	 * @param array<string, mixed> $week     Week.
	 * @param array<int, mixed>    $specials Specials, with the closure.
	 */
	public static function version( array $week, array $specials ): string {
		return substr( md5( (string) wp_json_encode( array( $week, $specials ) ) ), 0, 16 );
	}

	/**
	 * A response with the store, its ETag and no cache.
	 *
	 * @param array<string, mixed> $data   Store.
	 * @param int                  $status Status.
	 */
	private static function respond( array $data, int $status = 200 ): \WP_REST_Response {
		$response = new \WP_REST_Response( $data, $status );
		$response->header( 'ETag', '"' . $data['version'] . '"' );
		$response->header( 'Cache-Control', 'no-store' );
		return $response;
	}

	/**
	 * `GET`: the hours of the store.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @phpstan-param \WP_REST_Request<array<string, mixed>> $request
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function show( \WP_REST_Request $request ) {
		$limited = self::limited();
		if ( null !== $limited ) {
			return $limited;
		}
		$post = self::post( $request );
		if ( null === $post ) {
			return self::not_found();
		}
		$gone = self::gone( $post );
		return null === $gone ? self::respond( self::data( $post ) ) : $gone;
	}

	/**
	 * `PUT`: replaces the fields that come (each one whole); the others stay.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @phpstan-param \WP_REST_Request<array<string, mixed>> $request
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function update( \WP_REST_Request $request ) {
		$limited = self::limited();
		if ( null !== $limited ) {
			return $limited;
		}
		$post = self::post( $request );
		if ( null === $post ) {
			return self::not_found();
		}
		$gone = self::gone( $post );
		if ( null !== $gone ) {
			return $gone;
		}
		$actor = sanitize_email( (string) $request->get_header( 'x_lc_actor' ) );
		if ( '' === $actor || ! is_email( $actor ) ) {
			return new \WP_Error( 'lachinata_oleotecas_actor', __( 'Falta X-LC-Actor con el correo de quien hace el cambio.', 'lachinata-core' ), array( 'status' => 400 ) );
		}
		$body = $request->get_json_params();
		if ( ! is_array( $body ) ) {
			return new \WP_Error( 'lachinata_oleotecas_body', __( 'El cuerpo va en JSON (Content-Type: application/json).', 'lachinata-core' ), array( 'status' => 400 ) );
		}
		$current = self::data( $post );
		$match   = trim( (string) $request->get_header( 'if_match' ) );
		if ( '' !== $match && '*' !== $match && trim( (string) preg_replace( '/^W\//', '', $match ), '"' ) !== $current['version'] ) {
			return new \WP_Error(
				'lachinata_oleotecas_changed',
				__( 'Alguien ha cambiado el horario mientras tanto: vuelve a leerlo antes de guardar.', 'lachinata-core' ),
				array(
					'status'  => 412,
					'current' => $current,
				)
			);
		}

		$errors  = array();
		$week    = null;
		$list    = null;
		$closure = false;
		if ( array_key_exists( 'hours', $body ) ) {
			$week = self::week( $body['hours'], $errors );
		}
		if ( array_key_exists( 'specials', $body ) ) {
			$list = self::specials( $body['specials'], $errors );
		}
		if ( array_key_exists( 'closure', $body ) ) {
			$closure = self::closure( $body['closure'], $errors );
		}
		if ( $errors ) {
			return new \WP_Error(
				'lachinata_oleotecas_invalid',
				__( 'Revisa los datos: no se ha guardado nada.', 'lachinata-core' ),
				array(
					'status' => 422,
					'errors' => $errors,
				)
			);
		}

		ChangeLog::act_as( $actor, 'api' );
		if ( null !== $week ) {
			update_post_meta( $post->ID, Fields::HOURS, $week );
		}
		if ( null !== $list || false !== $closure ) {
			$stored = Schedule::sanitize_specials( get_post_meta( $post->ID, Fields::SPECIAL, true ) );
			$list   = $list ?? Schedule::without_closure( $stored );
			$keep   = false === $closure ? Schedule::closure( $stored ) : $closure;
			if ( null !== $keep ) {
				$list[] = $keep + array(
					'slots' => array(),
					'kind'  => Schedule::CLOSURE,
				);
			}
			update_post_meta( $post->ID, Fields::SPECIAL, $list );
		}
		ChangeLog::flush();
		ChangeLog::reset();
		clean_post_cache( $post->ID );
		Data::touch();
		Data::flush();

		$data            = self::data( $post );
		$data['ignored'] = array_values( array_diff( array_keys( $body ), self::ALLOWED ) );
		return self::respond( $data );
	}

	/**
	 * The week of the body, or null with its errors.
	 *
	 * @param mixed                 $value  Value.
	 * @param array<string, string> $errors Errors, by field.
	 * @return array<string, mixed>|null
	 */
	private static function week( $value, array &$errors ): ?array {
		if ( ! is_array( $value ) || ( $value && array_is_list( $value ) ) ) {
			$errors['hours'] = __( 'El horario semanal es un objeto con los días mon, tue, wed, thu, fri, sat y sun.', 'lachinata-core' );
			return null;
		}
		$unknown = array_diff( array_keys( $value ), Schedule::DAYS );
		if ( $unknown ) {
			/* translators: %s: keys. */
			$errors['hours'] = sprintf( __( 'Días desconocidos: %s. Usa mon, tue, wed, thu, fri, sat y sun.', 'lachinata-core' ), implode( ', ', $unknown ) );
			return null;
		}
		foreach ( Schedule::week_errors( $value ) as $day => $message ) {
			$errors[ 'hours.' . $day ] = $message;
		}
		return Schedule::sanitize_week( $value );
	}

	/**
	 * The specials of the body (without closures), or null with their errors.
	 *
	 * @param mixed                 $value  Value.
	 * @param array<string, string> $errors Errors, by field.
	 * @return list<Special>|null
	 */
	private static function specials( $value, array &$errors ): ?array {
		if ( ! is_array( $value ) || ! array_is_list( $value ) || count( $value ) > self::MAX_SPECIALS ) {
			/* translators: %d: most. */
			$errors['specials'] = sprintf( __( 'Los horarios especiales son una lista de como mucho %d.', 'lachinata-core' ), self::MAX_SPECIALS );
			return null;
		}
		$out = array();
		foreach ( $value as $index => $item ) {
			$error = Schedule::special_error( $item );
			if ( '' !== $error ) {
				$errors[ 'specials.' . $index ] = $error;
				continue;
			}
			$special = Schedule::special( array_diff_key( (array) $item, array( 'kind' => true ) ) );
			if ( null !== $special ) {
				$out[] = $special;
			}
		}
		return $out;
	}

	/**
	 * The closure of the body: null to remove it, a range with its note, or false with its
	 * error.
	 *
	 * @param mixed                 $value  Value.
	 * @param array<string, string> $errors Errors, by field.
	 * @return array{from: string, to: string, note: string}|false|null
	 */
	private static function closure( $value, array &$errors ) {
		if ( null === $value ) {
			return null;
		}
		if ( ! is_array( $value ) || empty( $value['to'] ) ) {
			$errors['closure'] = __( 'El cierre temporal es un objeto con «from», «to» (AAAA-MM-DD) y, si quieres, «note».', 'lachinata-core' );
			return false;
		}
		$value = array_diff_key( $value, array( 'slots' => true ) );
		$error = Schedule::special_error( $value );
		if ( '' !== $error ) {
			$errors['closure'] = $error;
			return false;
		}
		$special = (array) Schedule::special( $value );
		return array(
			'from' => (string) $special['from'],
			'to'   => (string) $special['to'],
			'note' => (string) $special['note'],
		);
	}
}
