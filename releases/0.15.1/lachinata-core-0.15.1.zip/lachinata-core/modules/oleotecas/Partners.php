<?php
/**
 * Tokens of the partners' API.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

defined( 'ABSPATH' ) || exit;

/**
 * Server tokens of the partners' API (the franchises' panel is one client): each one with a
 * name, kept only as its SHA-256 (the token is shown once, when it is created), with the
 * date it was last used. Revoking takes effect at once; rotating creates a new one and
 * leaves the old one valid 24 hours, so the panel can be updated without a cut. They are
 * credentials of this site: never in the exported JSON.
 *
 * @phpstan-type Token array{id: string, name: string, hash: string, hint: string, created: int, used: int, expires: int}
 */
final class Partners {

	/**
	 * Option with the tokens.
	 */
	public const OPTION = 'lachinata_oleotecas_partner_tokens';

	/**
	 * Prefix of every token (recognisable in a leak scanner).
	 */
	public const PREFIX = 'lcp_';

	/**
	 * Requests per token and window before answering 429.
	 */
	public const LIMIT = 120;

	/**
	 * Window of the limit, in seconds.
	 */
	public const WINDOW = 600;

	/**
	 * Hours an old token keeps working after a rotation.
	 */
	public const GRACE = DAY_IN_SECONDS;

	/**
	 * The saved tokens, without the expired ones.
	 *
	 * @return list<Token>
	 */
	public static function all(): array {
		$out = array();
		foreach ( (array) get_option( self::OPTION, array() ) as $token ) {
			if ( ! is_array( $token ) || empty( $token['id'] ) || empty( $token['hash'] ) ) {
				continue;
			}
			$token = array(
				'id'      => (string) $token['id'],
				'name'    => (string) ( $token['name'] ?? '' ),
				'hash'    => (string) $token['hash'],
				'hint'    => (string) ( $token['hint'] ?? '' ),
				'created' => (int) ( $token['created'] ?? 0 ),
				'used'    => (int) ( $token['used'] ?? 0 ),
				'expires' => (int) ( $token['expires'] ?? 0 ),
			);
			if ( $token['expires'] && $token['expires'] <= time() ) {
				continue;
			}
			$out[] = $token;
		}
		return $out;
	}

	/**
	 * Saves the tokens.
	 *
	 * @param array<int, mixed> $tokens Tokens.
	 * @phpstan-param list<Token> $tokens
	 */
	private static function save( array $tokens ): void {
		update_option( self::OPTION, array_values( $tokens ), false );
	}

	/**
	 * Creates a token and returns it in clear (the only time it exists as such).
	 *
	 * @param string $name Name («Panel de oleotecas»).
	 */
	public static function create( string $name ): string {
		$secret   = self::PREFIX . rtrim( strtr( base64_encode( random_bytes( 32 ) ), '+/', '-_' ), '=' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- A random token, not obfuscation.
		$tokens   = self::all();
		$tokens[] = array(
			'id'      => bin2hex( random_bytes( 4 ) ),
			'name'    => '' === trim( $name ) ? __( 'Sin nombre', 'lachinata-core' ) : Fields::text_line( $name ),
			'hash'    => hash( 'sha256', $secret ),
			'hint'    => substr( $secret, -4 ),
			'created' => time(),
			'used'    => 0,
			'expires' => 0,
		);
		self::save( $tokens );
		return $secret;
	}

	/**
	 * Rotates a token: a new one with the same name; the old one works 24 hours more.
	 *
	 * @param string $id Token id.
	 * @return string|null The new token in clear, or null when there is no such token.
	 */
	public static function rotate( string $id ): ?string {
		$tokens = self::all();
		$name   = null;
		foreach ( $tokens as $index => $token ) {
			if ( $token['id'] === $id ) {
				$name                        = $token['name'];
				$tokens[ $index ]['expires'] = $token['expires'] ? $token['expires'] : time() + self::GRACE;
			}
		}
		if ( null === $name ) {
			return null;
		}
		self::save( $tokens );
		return self::create( $name );
	}

	/**
	 * Revokes a token at once.
	 *
	 * @param string $id Token id.
	 */
	public static function revoke( string $id ): bool {
		$tokens = self::all();
		$kept   = array_values( array_filter( $tokens, static fn( array $token ): bool => $token['id'] !== $id ) );
		self::save( $kept );
		return count( $kept ) !== count( $tokens );
	}

	/**
	 * The token of an `Authorization: Bearer` header, or null. Marks it as used (at most
	 * once a minute, so a busy panel does not write on every request).
	 *
	 * @param string $header Value of the header.
	 * @return Token|null
	 */
	public static function verify( string $header ): ?array {
		if ( ! preg_match( '/^Bearer\s+(\S+)$/i', trim( $header ), $match ) || ! str_starts_with( $match[1], self::PREFIX ) ) {
			return null;
		}
		$hash   = hash( 'sha256', $match[1] );
		$tokens = self::all();
		foreach ( $tokens as $index => $token ) {
			if ( hash_equals( $token['hash'], $hash ) ) {
				if ( time() - $token['used'] >= MINUTE_IN_SECONDS ) {
					$tokens[ $index ]['used'] = time();
					self::save( $tokens );
				}
				return $tokens[ $index ];
			}
		}
		return null;
	}

	/**
	 * Counts a request of a token. Null when it may go on; otherwise, the seconds to wait.
	 *
	 * @param string $id Token id.
	 */
	public static function throttle( string $id ): ?int {
		$key    = 'lachinata_oleotecas_partner_rate_' . $id;
		$window = get_transient( $key );
		$now    = time();
		if ( ! is_array( $window ) || (int) ( $window['start'] ?? 0 ) + self::WINDOW <= $now ) {
			$window = array(
				'start' => $now,
				'count' => 0,
			);
		}
		if ( (int) $window['count'] >= self::LIMIT ) {
			return max( 1, (int) $window['start'] + self::WINDOW - $now );
		}
		++$window['count'];
		set_transient( $key, $window, self::WINDOW );
		return null;
	}
}
