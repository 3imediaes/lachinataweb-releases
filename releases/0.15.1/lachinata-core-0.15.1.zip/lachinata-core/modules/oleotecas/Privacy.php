<?php
/**
 * The map's provider in the privacy and cookies policy.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * The tiles of the map come from a third party (CARTO by default) when the visitor asks for
 * the map: it sees the visitor's IP but sets no cookies, so it is a provider of the policy
 * and not part of the cookie notice. Declared to `tracking` through its registry; nothing
 * happens without that module.
 */
final class Privacy {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/tracking/services', array( self::class, 'services' ) );
	}

	/**
	 * `lachinata/tracking/services`: the map's tiles, a necessary service without cookies.
	 *
	 * @param mixed $services Services.
	 * @return mixed
	 */
	public static function services( $services ) {
		if ( ! is_array( $services ) ) {
			return $services;
		}
		$company    = trim( (string) OleotecasModule::setting( 'tiles_company' ) );
		$services[] = array(
			'id'          => 'oleotecas-map',
			/* translators: %s: «oleotecas». */
			'name'        => sprintf( __( 'Mapa de %s', 'lachinata-core' ), Texts::noun( true ) ),
			'provider'    => '' === $company ? (string) OleotecasModule::setting( 'tiles_provider' ) : $company,
			'company'     => $company,
			'category'    => 'necessary',
			'configured'  => Tiles::available(),
			'cookies'     => array(),
			'handles'     => array(),
			'privacy_url' => (string) OleotecasModule::setting( 'tiles_privacy_url' ),
		);
		return $services;
	}
}
