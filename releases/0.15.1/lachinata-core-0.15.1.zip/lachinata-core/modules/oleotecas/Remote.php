<?php
/**
 * The stores of the master site, in client mode.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * A client shop (`mode` = `client`) shows the stores of the master site: the server reads
 * the master's document (`GET <master_url>/wp-json/lachinata/v1/oleotecas`) once an hour
 * (WP-Cron, and in the background when a page finds it older), keeps the last good copy as
 * a backup for when the master does not answer, and writes it to its own uploads like the
 * master does (Data), so the browser reads it from the same domain. Only a site without any
 * copy waits for the master in a page request.
 */
final class Remote {

	/**
	 * Option with the copy: document, when it was read, the last attempt and its error.
	 */
	public const OPTION = 'lachinata_oleotecas_remote';

	/**
	 * Event of WP-Cron that reads the master.
	 */
	public const EVENT = 'lachinata_oleotecas_remote_refresh';

	/**
	 * Age of the copy before it is read again.
	 */
	public const TTL = HOUR_IN_SECONDS;

	/**
	 * Wait after a failed attempt.
	 */
	public const RETRY = 5 * MINUTE_IN_SECONDS;

	/**
	 * Age of the copy the health warns about.
	 */
	public const OLD = 2 * DAY_IN_SECONDS;

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( self::EVENT, array( self::class, 'refresh' ) );
		Hooks::add_action( 'init', array( self::class, 'schedule' ) );
	}

	/**
	 * Reads the master every hour.
	 */
	public static function schedule(): void {
		if ( ! wp_next_scheduled( self::EVENT ) ) {
			wp_schedule_event( time() + self::TTL, 'hourly', self::EVENT );
		}
	}

	/**
	 * URL of the master's document: the setting is the master site («https://lachinata.es»)
	 * or, if it already says so, the document itself.
	 */
	public static function endpoint(): string {
		$master = trim( (string) OleotecasModule::setting( 'master_url' ) );
		if ( '' === $master ) {
			return '';
		}
		return str_contains( $master, '/wp-json/' ) ? $master : untrailingslashit( $master ) . '/wp-json/' . Rest::NAMESPACE . '/oleotecas';
	}

	/**
	 * The saved copy.
	 *
	 * @return array{document: array<string, mixed>|null, at: int, checked: int, error: string}
	 */
	public static function state(): array {
		$state = get_option( self::OPTION );
		$state = is_array( $state ) ? $state : array();
		return array(
			'document' => isset( $state['document'] ) && is_array( $state['document'] ) ? $state['document'] : null,
			'at'       => (int) ( $state['at'] ?? 0 ),
			'checked'  => (int) ( $state['checked'] ?? 0 ),
			'error'    => (string) ( $state['error'] ?? '' ),
		);
	}

	/**
	 * The document of the finder: the copy (read now only when there is none; when it is old,
	 * read again in the background), or an empty one.
	 *
	 * @return array<string, mixed>
	 */
	public static function document(): array {
		$state = self::state();
		$now   = time();
		if ( null === $state['document'] && $now - $state['checked'] >= self::RETRY ) {
			self::refresh();
			$state = self::state();
		} elseif ( null !== $state['document'] && $now - $state['at'] >= self::TTL && $now - $state['checked'] >= self::RETRY && ! wp_next_scheduled( self::EVENT, array( 'now' ) ) ) {
			wp_schedule_single_event( $now, self::EVENT, array( 'now' ) );
		}
		return $state['document'] ?? self::empty_document();
	}

	/**
	 * A document without stores (no master yet).
	 *
	 * @return array<string, mixed>
	 */
	public static function empty_document(): array {
		return array(
			'version'  => Data::VERSION,
			'lang'     => '',
			'finder'   => '',
			'noun'     => array( Texts::noun(), Texts::noun( true ) ),
			'nearKm'   => max( 1, (int) OleotecasModule::setting( 'near_km' ) ),
			'stores'   => array(),
			'zones'    => array(),
			'services' => (object) array(),
		);
	}

	/**
	 * Reads the master. A good answer replaces the copy and writes the browser's file; a
	 * failure keeps the copy and says why (health).
	 */
	public static function refresh(): bool {
		$url   = self::endpoint();
		$state = self::state();
		$error = '';
		$doc   = null;
		if ( '' === $url ) {
			$error = __( 'Falta la URL del maestro.', 'lachinata-core' );
		} else {
			$response = wp_remote_get(
				$url,
				array(
					'timeout' => 8,
					'headers' => array( 'Accept' => 'application/json' ),
				)
			);
			if ( is_wp_error( $response ) ) {
				$error = $response->get_error_message();
			} elseif ( 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
				/* translators: %d: HTTP status. */
				$error = sprintf( __( 'El maestro respondió %d.', 'lachinata-core' ), (int) wp_remote_retrieve_response_code( $response ) );
			} else {
				$doc = self::valid( json_decode( (string) wp_remote_retrieve_body( $response ), true ) );
				if ( null === $doc ) {
					$error = __( 'El maestro no devolvió un documento de tiendas válido.', 'lachinata-core' );
				}
			}
		}
		$now = time();
		update_option(
			self::OPTION,
			array(
				'document' => $doc ?? $state['document'],
				'at'       => null === $doc ? $state['at'] : $now,
				'checked'  => $now,
				'error'    => $error,
			),
			false
		);
		if ( null !== $doc ) {
			Data::write();
		}
		return null !== $doc;
	}

	/**
	 * The document if it has the shape of the finder's (the version this code reads, the
	 * stores as a list), or null.
	 *
	 * @param mixed $doc Decoded body.
	 * @return array<string, mixed>|null
	 */
	public static function valid( $doc ): ?array {
		if ( ! is_array( $doc ) || Data::VERSION !== (int) ( $doc['version'] ?? 0 ) || ! isset( $doc['stores'] ) || ! is_array( $doc['stores'] ) || ! array_is_list( $doc['stores'] ) ) {
			return null;
		}
		foreach ( $doc['stores'] as $store ) {
			if ( ! is_array( $store ) || empty( $store['slug'] ) || ! preg_match( '#^https?://[^/\s]+/#', (string) ( $store['url'] ?? '' ) ) ) {
				return null;
			}
		}
		$doc['zones']    = isset( $doc['zones'] ) && is_array( $doc['zones'] ) ? array_values( $doc['zones'] ) : array();
		$doc['services'] = (object) ( isset( $doc['services'] ) && is_array( $doc['services'] ) ? $doc['services'] : array() );
		$doc['lang']     = (string) ( $doc['lang'] ?? '' );
		$doc['finder']   = (string) ( $doc['finder'] ?? '' );
		return $doc;
	}

	/**
	 * What the health says: no master, the master not answering, a copy older than two days.
	 *
	 * @return list<string>
	 */
	public static function notes(): array {
		$notes = array();
		$state = self::state();
		if ( '' === self::endpoint() ) {
			$notes[] = __( 'Modo cliente sin URL del maestro (WooCommerce → La Chinata → Oleotecas).', 'lachinata-core' );
			return $notes;
		}
		if ( '' !== $state['error'] ) {
			$notes[] = null === $state['document']
				/* translators: 1: date, 2: error. */
				? sprintf( __( 'El maestro no responde (%1$s: %2$s) y no hay copia: el buscador sale vacío.', 'lachinata-core' ), Html::when( $state['checked'] ), $state['error'] )
				/* translators: 1: date, 2: error, 3: date of the copy. */
				: sprintf( __( 'El maestro no responde (%1$s: %2$s): se muestra la copia del %3$s.', 'lachinata-core' ), Html::when( $state['checked'] ), $state['error'], Html::when( $state['at'] ) );
		}
		if ( null !== $state['document'] && time() - $state['at'] > self::OLD ) {
			/* translators: %s: date. */
			$notes[] = sprintf( __( 'La copia de las tiendas del maestro es del %s: tiene más de 48 horas.', 'lachinata-core' ), Html::when( $state['at'] ) );
		}
		return $notes;
	}
}
