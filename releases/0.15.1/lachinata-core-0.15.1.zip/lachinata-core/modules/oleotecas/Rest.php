<?php
/**
 * REST routes of the stores.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * `GET /lachinata/v1/oleotecas`: the document of the finder (Data), with CORS for the client
 * domains and a year of cache when it is asked by its version (`?v=<hash>`).
 * `GET /lachinata/v1/oleotecas/geocode?q=`: coordinates of a place that is not in our data,
 * from the server (cached, limited per visitor; the editors' panel uses it too).
 * `GET /lachinata/v1/oleotecas/<slug>`: one store in full (without its email).
 *
 * @phpstan-import-type StoreData from Store
 */
final class Rest {

	public const NAMESPACE = 'lachinata/v1';

	/**
	 * Searches per visitor and 10 minutes before answering 429.
	 */
	public const LIMIT = 20;

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'rest_api_init', array( self::class, 'routes' ) );
		Hooks::add_filter( 'rest_pre_serve_request', array( self::class, 'strip_cors' ), 20, 3 );
	}

	/**
	 * WordPress answers every REST request with CORS for any origin; these routes only for
	 * the client domains.
	 *
	 * @param mixed $served  Whether the request was served.
	 * @param mixed $result  Result.
	 * @param mixed $request Request.
	 * @return mixed
	 */
	public static function strip_cors( $served, $result, $request ) {
		if ( $request instanceof \WP_REST_Request && str_starts_with( $request->get_route(), '/' . self::NAMESPACE . '/oleotecas' ) && ! headers_sent() ) {
			$origin = strtolower( rtrim( (string) $request->get_header( 'origin' ), '/' ) );
			if ( ! in_array( $origin, Data::origins(), true ) ) {
				header_remove( 'Access-Control-Allow-Origin' );
				header_remove( 'Access-Control-Allow-Credentials' );
			}
		}
		return $served;
	}

	/**
	 * Registers the routes (geocode first: it would match the slug).
	 */
	public static function routes(): void {
		register_rest_route(
			self::NAMESPACE,
			'/oleotecas/geocode',
			array(
				'methods'             => 'GET',
				'callback'            => Hooks::rest( array( self::class, 'geocode' ) ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'q'       => array(
						'type'     => 'string',
						'required' => true,
					),
					'country' => array(
						'type'    => 'string',
						'default' => '',
					),
				),
			)
		);
		// A client shop has no stores of its own: its browser reads the copy in its uploads.
		if ( Source::client() ) {
			return;
		}
		register_rest_route(
			self::NAMESPACE,
			'/oleotecas',
			array(
				'methods'             => 'GET',
				'callback'            => Hooks::rest( array( self::class, 'index' ) ),
				'permission_callback' => '__return_true',
			)
		);
		register_rest_route(
			self::NAMESPACE,
			'/oleotecas/(?P<slug>[a-z0-9-]+)',
			array(
				'methods'             => 'GET',
				'callback'            => Hooks::rest( array( self::class, 'show' ) ),
				'permission_callback' => '__return_true',
			)
		);
	}

	/**
	 * The document of the finder.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @phpstan-param \WP_REST_Request<array<string, mixed>> $request
	 */
	public static function index( \WP_REST_Request $request ): \WP_REST_Response {
		$response = new \WP_REST_Response( Source::document() );
		$state    = Data::current();
		$version  = (string) $request->get_param( 'v' );
		$response->header( 'Cache-Control', null !== $state && '' !== $version && $version === $state['hash'] ? 'public, max-age=31536000, immutable' : 'public, max-age=300' );
		self::cors( $request, $response );
		return $response;
	}

	/**
	 * One store in full.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @phpstan-param \WP_REST_Request<array<string, mixed>> $request
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function show( \WP_REST_Request $request ) {
		$slug = sanitize_title( (string) $request->get_param( 'slug' ) );
		foreach ( Directory::stores() as $store ) {
			if ( $store['slug'] === $slug ) {
				$response = new \WP_REST_Response( self::full( $store ) );
				$response->header( 'Cache-Control', 'public, max-age=300' );
				self::cors( $request, $response );
				return $response;
			}
		}
		return new \WP_Error( 'lachinata_oleotecas_not_found', __( 'No existe esa oleoteca.', 'lachinata-core' ), array( 'status' => 404 ) );
	}

	/**
	 * A store in full: the short form plus the weekly hours and all the specials that have
	 * not ended, the photos, the own text, the profiles, WhatsApp and the favourites (local
	 * id and SKU, so another shop can find them by SKU). Never the email.
	 *
	 * @param array<string, mixed> $store Store.
	 * @phpstan-param StoreData $store
	 * @return array<string, mixed>
	 */
	public static function full( array $store ): array {
		$today  = gmdate( 'Y-m-d', time() - DAY_IN_SECONDS );
		$data   = Data::summary( $store, $today );
		$photos = array();
		foreach ( $store['photos'] as $id ) {
			$url = wp_get_attachment_image_url( $id, 'large' );
			if ( is_string( $url ) ) {
				$photos[] = array(
					'url' => $url,
					'alt' => (string) get_post_meta( $id, '_wp_attachment_image_alt', true ),
				);
			}
		}
		$favorites = array();
		foreach ( $store['favorites'] as $id ) {
			$product = function_exists( 'wc_get_product' ) ? wc_get_product( $id ) : null;
			if ( $product instanceof \WC_Product && 'publish' === $product->get_status() ) {
				$favorites[] = array(
					'id'  => $product->get_id(),
					'sku' => $product->get_sku(),
				);
			}
		}
		return array_merge(
			$data,
			array(
				'specials'  => Schedule::upcoming( $store['specials'], $today, 50 ),
				'region'    => $store['region'],
				'whatsapp'  => $store['whatsapp'],
				'social'    => $store['social'],
				'text'      => $store['text'],
				'photos'    => $photos,
				'favorites' => $favorites,
				'modified'  => mysql2date( 'c', $store['modified'], false ),
			)
		);
	}

	/**
	 * Coordinates of a place, from the server.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @phpstan-param \WP_REST_Request<array<string, mixed>> $request
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function geocode( \WP_REST_Request $request ) {
		if ( ! current_user_can( 'edit_posts' ) && ! self::allow() ) {
			return new \WP_Error( 'lachinata_oleotecas_limit', __( 'Demasiadas búsquedas seguidas. Prueba dentro de unos minutos.', 'lachinata-core' ), array( 'status' => 429 ) );
		}
		$country = strtoupper( substr( (string) preg_replace( '/[^A-Za-z]/', '', (string) $request->get_param( 'country' ) ), 0, 2 ) );
		$result  = Geocoding::search( (string) $request->get_param( 'q' ), $country );
		if ( null === $result ) {
			return new \WP_Error( 'lachinata_oleotecas_no_place', __( 'No encontramos ese sitio.', 'lachinata-core' ), array( 'status' => 404 ) );
		}
		$response = new \WP_REST_Response( $result );
		$response->header( 'Cache-Control', 'private, max-age=3600' );
		return $response;
	}

	/**
	 * Counts a search of this visitor (by a hash of the IP that is never stored as such).
	 */
	private static function allow(): bool {
		$ip    = (string) wp_unslash( $_SERVER['REMOTE_ADDR'] ?? '' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Only hashed.
		$key   = 'lachinata_oleotecas_rate_' . substr( hash_hmac( 'sha256', $ip, wp_salt( 'nonce' ) ), 0, 20 );
		$count = (int) get_transient( $key );
		if ( $count >= self::LIMIT ) {
			return false;
		}
		set_transient( $key, $count + 1, 10 * MINUTE_IN_SECONDS );
		return true;
	}

	/**
	 * CORS for the client domains of the settings.
	 *
	 * @param \WP_REST_Request  $request  Request.
	 * @param \WP_REST_Response $response Response.
	 * @phpstan-param \WP_REST_Request<array<string, mixed>> $request
	 */
	private static function cors( \WP_REST_Request $request, \WP_REST_Response $response ): void {
		$origin = (string) $request->get_header( 'origin' );
		if ( '' !== $origin && in_array( strtolower( rtrim( $origin, '/' ) ), Data::origins(), true ) ) {
			$response->header( 'Access-Control-Allow-Origin', $origin );
			$response->header( 'Vary', 'Origin' );
		}
	}
}
