<?php
/**
 * Where the finder takes its stores from.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

defined( 'ABSPATH' ) || exit;

/**
 * The finder (its template, the block and the browser) works on the document of Data, as an
 * array, whoever produces it: the stores of this site (master mode, `mode` = `master`) or
 * the JSON of the master read with a cache and a local copy (client mode, Remote). The
 * adapter is chosen by the setting `mode`.
 */
final class Source {

	/**
	 * Modes of the setting `mode`.
	 */
	public const MASTER = 'master';
	public const CLIENT = 'client';

	/**
	 * The mode of this site.
	 */
	public static function mode(): string {
		return self::CLIENT === OleotecasModule::setting( 'mode' ) ? self::CLIENT : self::MASTER;
	}

	/**
	 * Whether this site shows the stores of another one.
	 */
	public static function client(): bool {
		return self::CLIENT === self::mode();
	}

	/**
	 * The document of the finder.
	 *
	 * @return array<string, mixed>
	 */
	public static function document(): array {
		return self::client() ? Remote::document() : Data::document();
	}

	/**
	 * URL the browser reads the same document from (versioned).
	 */
	public static function url(): string {
		return Data::url();
	}
}
