<?php
/**
 * Phones of the stores.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

defined( 'ABSPATH' ) || exit;

/**
 * Any phone (landline or mobile) of a store to E.164 with its country's calling code,
 * and back to how people read it. The core's Phone is for mobiles that receive notices;
 * a store's number is usually a landline («91 143 12 88»).
 */
final class StorePhone {

	/**
	 * E.164 (+34911431288), or null when it cannot be one.
	 *
	 * @param string $number  As typed («91 143 12 88», «420770698886», «+82 51 790 1541»).
	 * @param string $country ISO code of the store's country.
	 */
	public static function normalize( string $number, string $country ): ?string {
		$number = trim( $number );
		$plus   = str_starts_with( $number, '+' );
		$digits = (string) preg_replace( '/\D/', '', $number );
		if ( '' === $digits ) {
			return null;
		}
		if ( ! $plus && str_starts_with( $digits, '00' ) ) {
			$digits = substr( $digits, 2 );
			$plus   = true;
		}
		if ( ! $plus ) {
			$code = self::calling_code( $country );
			if ( '' === $code ) {
				return null;
			}
			// Written with the country code but without the plus («420770698886»).
			$digits = str_starts_with( $digits, $code ) && strlen( $digits ) - strlen( $code ) >= 8 && ! str_starts_with( $digits, '0' )
				? $digits
				: $code . ltrim( $digits, '0' );
		}
		$e164 = '+' . $digits;
		if ( ! preg_match( '/^\+[1-9]\d{7,14}$/', $e164 ) ) {
			return null;
		}
		// Spain: nine digits starting with 6, 7, 8 or 9.
		if ( str_starts_with( $e164, '+34' ) && ! preg_match( '/^\+34[6-9]\d{8}$/', $e164 ) ) {
			return null;
		}
		return $e164;
	}

	/**
	 * As people read it: without the code in the shop's own country, in groups of three
	 * («911 431 288»); with the code elsewhere («+420 770 698 886»).
	 *
	 * @param string $e164    Number.
	 * @param string $country ISO code of the store's country.
	 */
	public static function display( string $e164, string $country ): string {
		$code = self::calling_code( $country );
		if ( '' === $e164 ) {
			return '';
		}
		$digits = substr( $e164, 1 );
		$base   = function_exists( 'WC' ) && WC()->countries ? WC()->countries->get_base_country() : '';
		$local  = '' !== $code && str_starts_with( $digits, $code ) ? substr( $digits, strlen( $code ) ) : '';
		if ( '' === $local ) {
			return $e164;
		}
		$groups = trim( (string) chunk_split( $local, 3, ' ' ) );
		return strtoupper( $country ) === $base ? $groups : '+' . $code . ' ' . $groups;
	}

	/**
	 * Calling code without the plus («34»), from WooCommerce.
	 *
	 * @param string $country ISO code.
	 */
	public static function calling_code( string $country ): string {
		if ( '' === $country || ! function_exists( 'WC' ) || ! WC()->countries ) {
			return '';
		}
		$code = WC()->countries->get_country_calling_code( strtoupper( $country ) );
		$code = is_array( $code ) ? (string) reset( $code ) : (string) $code;
		return preg_match( '/^\+(\d+)$/', $code, $match ) ? $match[1] : '';
	}
}
