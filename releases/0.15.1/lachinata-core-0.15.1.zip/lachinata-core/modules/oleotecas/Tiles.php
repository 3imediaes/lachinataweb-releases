<?php
/**
 * The map's tiles.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

defined( 'ABSPATH' ) || exit;

/**
 * The tile URL of the settings, with the provider's key in place of `{key}` (CARTO asks for
 * it since 23/09/2026). The key is a credential of each shop: a setting of its own, out of
 * the exported configuration. When the URL needs a key and there is none, there is no map:
 * the button is not offered and the health says so.
 */
final class Tiles {

	/**
	 * Whether the configured URL needs a key.
	 */
	public static function needs_key(): bool {
		return str_contains( (string) OleotecasModule::setting( 'tiles_url' ), '{key}' );
	}

	/**
	 * Whether the key is saved.
	 */
	public static function has_key(): bool {
		return '' !== trim( (string) OleotecasModule::setting( 'tiles_key' ) );
	}

	/**
	 * Whether the map can be offered.
	 */
	public static function available(): bool {
		return '' !== self::url();
	}

	/**
	 * Tile URL for Leaflet, with the key; '' when there are no tiles or the key is missing.
	 */
	public static function url(): string {
		$url = trim( (string) OleotecasModule::setting( 'tiles_url' ) );
		if ( '' === $url ) {
			return '';
		}
		if ( ! str_contains( $url, '{key}' ) ) {
			return $url;
		}
		$key = trim( (string) OleotecasModule::setting( 'tiles_key' ) );
		return '' === $key ? '' : str_replace( '{key}', rawurlencode( $key ), $url );
	}
}
