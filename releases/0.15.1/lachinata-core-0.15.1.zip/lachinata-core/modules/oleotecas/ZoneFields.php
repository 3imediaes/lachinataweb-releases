<?php
/**
 * Fields of a zone in Oleotecas → Zonas.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * Own text of the zone (under its title; it is translated), the label of the stores outside
 * the main city when the zone groups by city («Comunidad de Madrid»), and its questions.
 */
final class ZoneFields {

	/**
	 * Empty rows of questions shown after the filled ones.
	 */
	private const SPARE = 3;

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( Model::ZONE . '_edit_form_fields', array( self::class, 'render' ) );
		Hooks::add_action( 'edited_' . Model::ZONE, array( self::class, 'save' ) );
	}

	/**
	 * Prints the fields.
	 *
	 * @param mixed $term Term.
	 */
	public static function render( $term ): void {
		if ( ! $term instanceof \WP_Term ) {
			return;
		}
		$text  = (string) get_term_meta( $term->term_id, Fields::ZONE_TEXT, true );
		$group = (string) get_term_meta( $term->term_id, Fields::ZONE_GROUP, true );
		$faq   = Fields::faq( get_term_meta( $term->term_id, Fields::ZONE_FAQ, true ) );
		$rows  = array_merge(
			$faq,
			array_fill(
				0,
				self::SPARE,
				array(
					'question' => '',
					'answer'   => '',
				)
			)
		);
		wp_nonce_field( 'lachinata_oleotecas_zone', 'lachinata_oleotecas_zone_nonce' );
		?>
		<tr class="form-field">
			<th scope="row"><label for="lc-zone-text"><?php esc_html_e( 'Texto de la zona', 'lachinata-core' ); ?></label></th>
			<td>
				<textarea id="lc-zone-text" name="lc_zone[text]" rows="4"><?php echo esc_textarea( $text ); ?></textarea>
				<p class="description"><?php esc_html_e( 'Dos o tres frases bajo el título de la página de la zona. Sin texto, no sale nada.', 'lachinata-core' ); ?></p>
			</td>
		</tr>
		<tr class="form-field">
			<th scope="row"><label for="lc-zone-group"><?php esc_html_e( 'Agrupar por ciudad', 'lachinata-core' ); ?></label></th>
			<td>
				<input type="text" id="lc-zone-group" name="lc_zone[group]" value="<?php echo esc_attr( $group ); ?>">
				<p class="description"><?php esc_html_e( 'Nombre del grupo de las tiendas fuera de la ciudad principal («Comunidad de Madrid»). Las de la ciudad con más tiendas van en «Madrid ciudad». Vacío: sin grupos.', 'lachinata-core' ); ?></p>
			</td>
		</tr>
		<tr class="form-field">
			<th scope="row"><?php esc_html_e( 'Preguntas frecuentes', 'lachinata-core' ); ?></th>
			<td>
				<?php foreach ( $rows as $index => $row ) : ?>
					<p>
						<label class="screen-reader-text" for="lc-zone-q-<?php echo esc_attr( (string) $index ); ?>"><?php esc_html_e( 'Pregunta', 'lachinata-core' ); ?></label>
						<input type="text" id="lc-zone-q-<?php echo esc_attr( (string) $index ); ?>" name="lc_zone[faq][<?php echo esc_attr( (string) $index ); ?>][question]" value="<?php echo esc_attr( $row['question'] ); ?>" placeholder="<?php esc_attr_e( 'Pregunta', 'lachinata-core' ); ?>">
						<label class="screen-reader-text" for="lc-zone-a-<?php echo esc_attr( (string) $index ); ?>"><?php esc_html_e( 'Respuesta', 'lachinata-core' ); ?></label>
						<textarea id="lc-zone-a-<?php echo esc_attr( (string) $index ); ?>" name="lc_zone[faq][<?php echo esc_attr( (string) $index ); ?>][answer]" rows="2" placeholder="<?php esc_attr_e( 'Respuesta', 'lachinata-core' ); ?>"><?php echo esc_textarea( $row['answer'] ); ?></textarea>
					</p>
				<?php endforeach; ?>
				<p class="description"><?php esc_html_e( 'Salen en la página de la zona y en sus datos estructurados (FAQPage). Para más, guarda y vuelve: siempre quedan tres huecos libres.', 'lachinata-core' ); ?></p>
			</td>
		</tr>
		<?php
	}

	/**
	 * Saves the fields.
	 *
	 * @param mixed $term_id Term id.
	 */
	public static function save( $term_id ): void {
		if ( ! isset( $_POST['lachinata_oleotecas_zone_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['lachinata_oleotecas_zone_nonce'] ) ), 'lachinata_oleotecas_zone' ) || ! current_user_can( 'manage_categories' ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Each value is sanitized by the registered meta.
		$values = isset( $_POST['lc_zone'] ) && is_array( $_POST['lc_zone'] ) ? (array) wp_unslash( $_POST['lc_zone'] ) : array();
		update_term_meta( (int) $term_id, Fields::ZONE_TEXT, (string) ( $values['text'] ?? '' ) );
		update_term_meta( (int) $term_id, Fields::ZONE_GROUP, (string) ( $values['group'] ?? '' ) );
		update_term_meta( (int) $term_id, Fields::ZONE_FAQ, array_values( (array) ( $values['faq'] ?? array() ) ) );
		Data::touch();
	}
}
