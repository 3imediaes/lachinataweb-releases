/**
 * Block `lachinata/oleotecas`: the finder in any page, previewed with the server's HTML.
 */
import { registerBlockType } from '@wordpress/blocks';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { PanelBody, TextControl } from '@wordpress/components';
import { __ } from '@wordpress/i18n';
import ServerSideRender from '@wordpress/server-side-render';

import metadata from '../blocks/finder/block.json';

/**
 * Editor of the block: an optional title and the server's preview.
 *
 * @param {Object}   props               Props.
 * @param {Object}   props.attributes    Attributes.
 * @param {Function} props.setAttributes Setter.
 */
const Edit = ({ attributes, setAttributes }) => (
	<div {...useBlockProps()}>
		<InspectorControls>
			<PanelBody title={__('Buscador', 'lachinata-core')}>
				<TextControl
					label={__('Título (opcional)', 'lachinata-core')}
					value={attributes.title}
					onChange={(title) => setAttributes({ title })}
					__nextHasNoMarginBottom
					__next40pxDefaultSize
				/>
			</PanelBody>
		</InspectorControls>
		<ServerSideRender block={metadata.name} attributes={attributes} />
	</div>
);

registerBlockType(metadata.name, {
	edit: Edit,
	save: () => null,
});
