/**
 * Finder and store page of the module `oleotecas`.
 *
 * The server prints the list and the hours as they are (the page comes from the cache);
 * this script fills what depends on the moment or on the visitor: OpenStatus with each
 * store's time zone, today in the hours, «Cerca de mí» (location only when asked), the
 * search (our data first, then our server's geocoder), filters, order by distance, «Ver
 * más», the map on demand (Leaflet is loaded only then, src/map.js), Apple Maps on Apple
 * devices, the email out of the HTML and the measurement (`window.lachinata.track`), never
 * with the visitor's location.
 */
import { __, _n, sprintf } from '@wordpress/i18n';

import { openState } from './open';
import {
	byDistance,
	centre,
	fold,
	formatKm,
	mainGroup,
	matchStores,
} from './geo';
import { card, directionsUrl, esc } from './render';

const configNode = document.getElementById('lc-stores-config');
const config = configNode ? JSON.parse(configNode.textContent) : {};
const locale = document.documentElement.lang || 'es';
const PAGE = 10;

/**
 * Measurement: the bus of `tracking`, when it is there.
 *
 * @param {string} name Event.
 * @param {Object} data Parameters.
 */
const track = (name, data) => {
	const send = () => window.lachinata?.track?.(name, data);
	if (document.readyState === 'complete') {
		send();
	} else {
		window.addEventListener('load', send, { once: true });
	}
};

/**
 * The JSON of the stores, once per page.
 */
let documentPromise = null;
const loadDocument = (src) => {
	if (!documentPromise) {
		documentPromise = window
			.fetch(src, { credentials: 'omit' })
			.then((response) => (response.ok ? response.json() : null))
			.catch(() => null);
	}
	return documentPromise;
};

/**
 * «Cierra a las 20:00», «Abre mañana a las 10:00»…
 *
 * @param {Object} state State of openState().
 * @return {string} Text.
 */
const stateText = (state) => {
	if (state.closes) {
		/* translators: %s: time («20:00»). */
		return sprintf(__('Cierra a las %s', 'lachinata-core'), state.closes);
	}
	if (!state.opens) {
		return '';
	}
	const { inDays, time, ymd } = state.opens;
	if (inDays === 0) {
		/* translators: %s: time. */
		return sprintf(__('Abre a las %s', 'lachinata-core'), time);
	}
	if (inDays === 1) {
		/* translators: %s: time. */
		return sprintf(__('Abre mañana a las %s', 'lachinata-core'), time);
	}
	const date = new Date(`${ymd}T12:00:00Z`);
	const when =
		inDays < 7
			? new Intl.DateTimeFormat(locale, {
					weekday: 'long',
					timeZone: 'UTC',
				}).format(date)
			: new Intl.DateTimeFormat(locale, {
					day: 'numeric',
					month: 'short',
					timeZone: 'UTC',
				}).format(date);
	/* translators: 1: day («el lunes», «el 24 ago»), 2: time. */
	return sprintf(__('Abre el %1$s a las %2$s', 'lachinata-core'), when, time);
};

const WORDS = () => ({
	open: __('Abierta', 'lachinata-core'),
	closing: __('Cierra pronto', 'lachinata-core'),
	closed: __('Cerrada', 'lachinata-core'),
	unknown: __('Consulta el horario', 'lachinata-core'),
});

/**
 * Fills an OpenStatus element.
 *
 * @param {Element} element OpenStatus.
 * @param {Object}  store   Store.
 * @return {string} State.
 */
const paintStatus = (element, store) => {
	const state = openState(store);
	element.className = `lc-open lc-open--${state.state} body-sm`;
	element.querySelector('.lc-open__word').textContent = WORDS()[state.state];
	const text = element.querySelector('.lc-open__text');
	if (text) {
		text.textContent = state.state === 'unknown' ? '' : stateText(state);
	}
	return state.state;
};

/**
 * Apple Maps on Apple devices: the links of «Cómo llegar» printed by the server.
 *
 * @param {Element} root Root.
 */
const fixDirections = (root) => {
	root.querySelectorAll('[data-lc-directions]').forEach((link) => {
		const value = link.getAttribute('data-lc-directions');
		if (value) {
			try {
				link.href = directionsUrl(JSON.parse(value));
			} catch {
				// Keep Google Maps.
			}
		}
	});
};

/**
 * Measures the outgoing actions of the cards and the store page.
 *
 * @param {Element}  root  Root.
 * @param {Function} about Store of an element → {store, zone}.
 */
const measureClicks = (root, about) => {
	root.addEventListener('click', (event) => {
		const map = {
			'[data-lc-directions]': 'lc_store_directions',
			'[data-lc-store-call]': 'lc_store_call',
			'[data-lc-store-whatsapp]': 'lc_store_whatsapp',
			'[data-lc-store-web]': 'lc_store_web',
		};
		for (const [selector, name] of Object.entries(map)) {
			const target = event.target.closest(selector);
			if (target) {
				track(name, about(target));
				return;
			}
		}
	});
};

/**
 * One finder (page, zone or block).
 *
 * @param {HTMLElement} root `[data-lc-finder]`.
 */
const initFinder = async (root) => {
	const options = JSON.parse(root.getAttribute('data-lc-finder') || '{}');
	const data = await loadDocument(options.src);
	if (!data || !Array.isArray(data.stores)) {
		return;
	}
	const cards = root.querySelector('[data-lc-cards]');
	const status = root.querySelector('[data-lc-status]');
	const form = root.querySelector('[data-lc-finder-form]');
	const input = form?.querySelector('input[type="search"]');
	const near = root.querySelector('[data-lc-near]');
	const more = root.querySelector('[data-lc-more]');
	const [noun, nouns] = data.noun || ['tienda', 'tiendas'];
	const all = options.zone
		? data.stores.filter((store) =>
				(store.zones || []).includes(options.zone)
			)
		: data.stores;
	const bySlug = Object.fromEntries(all.map((store) => [store.slug, store]));
	const state = {
		origin: null,
		label: '',
		filters: new Set(),
		limit: options.limit || 0,
		selected: '',
	};
	const count = (n) =>
		`${n.toLocaleString(locale)} ${n === 1 ? noun : nouns}`;

	const paintAll = () => {
		let openNow = 0;
		root.querySelectorAll('[data-lc-store]').forEach((element) => {
			const store = bySlug[element.getAttribute('data-lc-store')];
			const badge = element.querySelector('[data-lc-open]');
			if (store && badge) {
				const painted = paintStatus(badge, store);
				openNow += painted === 'open' || painted === 'closing' ? 1 : 0;
			}
		});
		fixDirections(root);
		return openNow;
	};

	// Zone: «11 oleotecas · 9 abiertas ahora».
	if (options.zone) {
		const openNow = all.filter((store) =>
			['open', 'closing'].includes(openState(store).state)
		).length;
		status.textContent = sprintf(
			/* translators: 1: «11 oleotecas», 2: number open now. */
			_n(
				'%1$s · %2$s abierta ahora',
				'%1$s · %2$s abiertas ahora',
				openNow,
				'lachinata-core'
			),
			count(all.length),
			openNow.toLocaleString(locale)
		);
	}
	paintAll();

	/**
	 * Applies the filters; never zero results: without matches, the list without filters.
	 *
	 * @return {{list: Array<Object>, empty: boolean}} Stores and whether the filters left none.
	 */
	const filtered = () => {
		const list = all.filter((store) =>
			[...state.filters].every((filter) => {
				if (filter === 'open') {
					return ['open', 'closing'].includes(openState(store).state);
				}
				return (store.services || []).includes(
					filter.replace('service:', '')
				);
			})
		);
		return list.length
			? { list, empty: false }
			: { list: all, empty: true };
	};

	/**
	 * What the map frames: the chosen store; with a place or the location, the closest
	 * ones; otherwise, the main group of the country with most stores in the list (the
	 * stores far from that group, such as islands, stay out of the first frame).
	 *
	 * @param {Array<Object>} list Stores as the list shows them (sorted when there is an origin).
	 * @return {Array<Object>} Stores to frame.
	 */
	const frameOf = (list) => {
		const located = list.filter(
			(store) => store.lat !== null && store.lng !== null
		);
		const chosen = located.find((store) => store.slug === state.selected);
		if (chosen) {
			return [chosen];
		}
		if (state.origin) {
			const close = located.filter(
				(store) => store.km <= (data.nearKm || 150)
			);
			return close.length ? close.slice(0, 10) : located.slice(0, 3);
		}
		const counts = {};
		located.forEach((store) => {
			counts[store.country] = (counts[store.country] || 0) + 1;
		});
		const top = Object.keys(counts).sort(
			(a, b) => counts[b] - counts[a]
		)[0];
		return mainGroup(
			located.filter((store) => store.country === top),
			data.nearKm || 150
		);
	};

	const render = (message) => {
		const { list, empty } = filtered();
		const sorted = state.origin ? byDistance(list, state.origin) : list;
		const shown = state.limit ? sorted.slice(0, state.limit) : sorted;
		cards.innerHTML = shown
			.map((store) =>
				card(store, {
					distance:
						state.origin && Number.isFinite(store.km)
							? formatKm(store.km, locale)
							: '',
					selected: store.slug === state.selected,
				})
			)
			.join('');
		paintAll();
		if (more) {
			more.hidden = !state.limit || sorted.length <= state.limit;
		}
		if (empty && state.filters.size) {
			status.textContent = __(
				'Ninguna cumple esos filtros ahora. Estas son todas:',
				'lachinata-core'
			);
		} else if (message) {
			status.textContent = message;
		} else if (state.filters.size) {
			status.textContent = count(list.length);
		}
		root.dispatchEvent(
			new CustomEvent('lachinata:stores:list', {
				detail: {
					stores: sorted,
					origin: state.origin,
					frame: frameOf(sorted),
				},
			})
		);
		return sorted;
	};

	// «Ver más»: ten more, without leaving the page.
	more?.addEventListener('click', (event) => {
		event.preventDefault();
		state.limit = state.limit ? state.limit + PAGE : 0;
		render(status.textContent);
	});

	// Filters.
	root.querySelectorAll('[data-lc-filter]').forEach((chip) => {
		chip.addEventListener('click', () => {
			const filter = chip.getAttribute('data-lc-filter');
			const on = !state.filters.has(filter);
			chip.setAttribute('aria-pressed', String(on));
			chip.classList.toggle('lc-chip--on', on);
			if (on) {
				state.filters.add(filter);
			} else {
				state.filters.delete(filter);
			}
			render();
		});
	});

	/**
	 * Orders by distance to a point and says so.
	 *
	 * @param {{lat: number, lng: number}} origin Point.
	 * @param {string}                     label  Place («Bilbao») or '' (your location).
	 * @param {string}                     source `near`, `search` (our data) or `geocode`.
	 */
	const orderFrom = (origin, label, source) => {
		state.origin = origin;
		state.label = label;
		const sorted = byDistance(filtered().list, origin);
		const nearKm = data.nearKm || 150;
		const close = sorted.filter((store) => store.km <= nearKm).length;
		let message;
		if (source === 'near') {
			message = __(
				'Ordenadas por cercanía a tu ubicación',
				'lachinata-core'
			);
		} else if (close && source === 'search') {
			message = sprintf(
				/* translators: 1: «3 oleotecas», 2: place. */
				__('%1$s cerca de %2$s', 'lachinata-core'),
				count(close),
				label
			);
		} else if (sorted.length) {
			message = sprintf(
				/* translators: 1: «oleotecas», 2: place, 3: the closest store, 4: its distance. */
				__(
					'No hay %1$s en %2$s. La más cercana está en %3$s, a %4$s',
					'lachinata-core'
				),
				nouns,
				label,
				sorted[0].city || sorted[0].name,
				formatKm(sorted[0].km, locale)
			);
		}
		render(message);
		track('lc_store_search', {
			search_term: source === 'near' ? '' : label,
			source,
			results: source === 'geocode' ? 0 : close,
		});
	};

	near?.addEventListener('click', () => {
		if (near.getAttribute('aria-pressed') === 'true') {
			near.setAttribute('aria-pressed', 'false');
			near.classList.remove('lc-chip--on');
			state.origin = null;
			render(count(all.length));
			return;
		}
		if (!navigator.geolocation) {
			status.textContent = __(
				'Tu navegador no da la ubicación. Busca por ciudad o código postal.',
				'lachinata-core'
			);
			return;
		}
		status.textContent = __('Buscando tu ubicación…', 'lachinata-core');
		navigator.geolocation.getCurrentPosition(
			(position) => {
				near.setAttribute('aria-pressed', 'true');
				near.classList.add('lc-chip--on');
				if (input) {
					input.value = '';
				}
				orderFrom(
					{
						lat: position.coords.latitude,
						lng: position.coords.longitude,
					},
					'',
					'near'
				);
			},
			() => {
				status.textContent = __(
					'No hemos podido usar tu ubicación. Busca por ciudad o código postal.',
					'lachinata-core'
				);
				input?.focus();
			},
			{ timeout: 10000, maximumAge: 300000 }
		);
	});

	// Search on submit: our data first, then our server's geocoder.
	form?.addEventListener('submit', async (event) => {
		event.preventDefault();
		const query = (input?.value || '').trim();
		if (!query) {
			return;
		}
		near?.setAttribute('aria-pressed', 'false');
		near?.classList.remove('lc-chip--on');
		const found = matchStores(data.stores, data.zones, query);
		if (found.length) {
			const point = centre(found);
			const zone = (data.zones || []).find(
				(item) => fold(item.name) === fold(query)
			);
			const label = zone ? zone.name : found[0].city || query;
			if (point) {
				orderFrom(point, label, 'search');
				return;
			}
		}
		status.textContent = __('Buscando…', 'lachinata-core');
		try {
			const url = new URL(config.geocode, window.location.href);
			url.searchParams.set('q', query);
			const response = await window.fetch(url.toString(), {
				credentials: 'same-origin',
			});
			if (response.ok) {
				const place = await response.json();
				// Not in our data: there is no store there; the closest ones come first.
				orderFrom(
					{ lat: place.lat, lng: place.lng },
					place.label || query,
					'geocode'
				);
				return;
			}
		} catch {
			// Falls through to the message.
		}
		status.textContent = sprintf(
			/* translators: %s: what was searched. */
			__(
				'No encontramos «%s». Prueba con una ciudad o un código postal.',
				'lachinata-core'
			),
			query
		);
		track('lc_store_search', {
			search_term: query,
			source: 'search',
			results: 0,
		});
	});

	// The map, only when asked.
	const openMap = async (opener, inline) => {
		const { showMap } = await import(/* webpackChunkName: "map" */ './map');
		showMap({
			root,
			config,
			nouns,
			stores: () =>
				state.origin
					? byDistance(filtered().list, state.origin)
					: filtered().list,
			frame: () =>
				frameOf(
					state.origin
						? byDistance(filtered().list, state.origin)
						: filtered().list
				),
			inline,
			opener,
			form,
			onSelect: (slug) => {
				state.selected = slug;
				root.querySelectorAll('[data-lc-store]').forEach((element) => {
					element.classList.toggle(
						'lc-store--on',
						element.getAttribute('data-lc-store') === slug
					);
				});
				const element = root.querySelector(
					`[data-lc-store="${window.CSS.escape(slug)}"]`
				);
				element?.scrollIntoView({
					block: 'nearest',
					behavior: 'smooth',
				});
			},
			renderCard: (slug) => {
				const store = bySlug[slug];
				const point =
					state.origin && store
						? byDistance([store], state.origin)[0]
						: null;
				const html = store
					? card(store, {
							selected: true,
							distance:
								point && Number.isFinite(point.km)
									? formatKm(point.km, locale)
									: '',
						})
					: '';
				return html;
			},
			paint: (element) => {
				element.querySelectorAll('[data-lc-store]').forEach((item) => {
					const store = bySlug[item.getAttribute('data-lc-store')];
					const badge = item.querySelector('[data-lc-open]');
					if (store && badge) {
						paintStatus(badge, store);
					}
				});
			},
		});
		track('lc_store_map', {
			page: options.zone || 'finder',
			stores: all.length,
		});
	};
	const desktop = () => window.matchMedia('(min-width: 1024px)').matches;
	// «Ver en el mapa» under the search: next to the list on the desktop, full screen on a
	// phone. Once the desktop map is there, the button has nothing left to do.
	const opener = root.querySelector('[data-lc-map-open]');
	const loaded = () => {
		if (desktop() && opener) {
			opener.hidden = true;
		}
	};
	root.querySelectorAll('[data-lc-map-load]').forEach((button) => {
		button.addEventListener('click', () =>
			openMap(button, desktop()).then(loaded)
		);
	});
	opener?.addEventListener('click', () =>
		openMap(opener, desktop()).then(loaded)
	);
	// Once asked in this session, the map of the desktop stays loaded.
	try {
		if (
			desktop() &&
			window.sessionStorage.getItem('lc-stores-map') === '1'
		) {
			const button = root.querySelector(
				'.lc-finder__map [data-lc-map-load]'
			);
			if (button) {
				openMap(button, true).then(loaded);
			}
		}
	} catch {
		// Storage blocked: the map waits for the button.
	}

	// Listeners in place: the finder answers from now on (the e2e wait for it).
	root.setAttribute('data-lc-ready', '');

	measureClicks(root, (target) => {
		const slug =
			target.closest('[data-lc-store]')?.getAttribute('data-lc-store') ||
			'';
		return { store: slug, zone: bySlug[slug]?.zone || '' };
	});
};

/**
 * The page of a store.
 *
 * @param {HTMLElement} page `[data-lc-store-page]`.
 */
const initStorePage = (page) => {
	let store;
	try {
		store = JSON.parse(page.getAttribute('data-lc-store-page'));
	} catch {
		return;
	}
	page.querySelectorAll('[data-lc-open]').forEach((element) =>
		paintStatus(element, store)
	);
	fixDirections(page);

	// Today in the hours, with the store's clock; specials already past go away.
	const hours = page.querySelector('[data-lc-hours]');
	if (hours) {
		const state = openState(store);
		if (state.state !== 'unknown') {
			const today = new Intl.DateTimeFormat('en-US', {
				weekday: 'short',
				timeZone: store.timezone || undefined,
			})
				.format(new Date())
				.toLowerCase()
				.slice(0, 3);
			const row = hours.querySelector(`[data-lc-day="${today}"]`);
			if (row) {
				row.classList.add('lc-hours__today');
				row.setAttribute('aria-current', 'date');
				row.querySelector('th').insertAdjacentHTML(
					'beforeend',
					` <span class="lc-hours__hoy badge">${esc(__('HOY', 'lachinata-core'))}</span>`
				);
			}
			const ymd = new Intl.DateTimeFormat('en-CA', {
				timeZone: store.timezone || undefined,
			}).format(new Date());
			hours.querySelectorAll('[data-lc-special-to]').forEach((item) => {
				if (item.getAttribute('data-lc-special-to') < ymd) {
					item.remove();
				}
			});
			const list = hours.querySelector('.lc-hours__ex');
			if (list && !list.querySelector('li')) {
				list.remove();
			}
		}
	}

	// The email, never in the HTML.
	page.querySelectorAll('[data-lc-mail]').forEach((element) => {
		try {
			const address = atob(element.getAttribute('data-lc-mail'))
				.split('')
				.reverse()
				.join('');
			const link = element.querySelector('a');
			link.href = `mailto:${address}`;
			element.hidden = false;
		} catch {
			// Stays hidden.
		}
	});

	// Photo counter.
	const gallery = page.querySelector('.lc-store-page__gallery');
	const counter = gallery?.querySelector('[data-lc-gallery-count]');
	if (gallery && counter) {
		const total = gallery.querySelectorAll('.lc-store-page__photo').length;
		gallery.addEventListener(
			'scroll',
			() => {
				const index =
					Math.round(gallery.scrollLeft / gallery.clientWidth) + 1;
				counter.textContent = `${Math.min(index, total)} / ${total}`;
			},
			{ passive: true }
		);
	}

	// The map of the store, only when asked.
	page.querySelectorAll('[data-lc-map-load]').forEach((button) => {
		button.addEventListener('click', async () => {
			const { showStore } = await import(
				/* webpackChunkName: "map" */ './map'
			);
			showStore({ element: button.closest('.lc-map'), config, store });
			track('lc_store_map', { store: store.slug, zone: store.zone });
		});
	});

	track('lc_store_view', { store: store.slug, zone: store.zone });
	measureClicks(page, (target) => {
		const slug = target
			.closest('[data-lc-store]')
			?.getAttribute('data-lc-store');
		return slug
			? { store: slug, zone: '' }
			: { store: store.slug, zone: store.zone };
	});
};

const start = () => {
	document.querySelectorAll('[data-lc-finder]').forEach((root) => {
		initFinder(root);
	});
	const page = document.querySelector('[data-lc-store-page]');
	if (page) {
		initStorePage(page);
	}
};

if (document.readyState === 'loading') {
	document.addEventListener('DOMContentLoaded', start);
} else {
	start();
}
