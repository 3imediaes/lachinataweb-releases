/**
 * The map on demand (StoreMap «cargado»): Leaflet with clusters, loaded only after «Ver en
 * el mapa». Tiles and attribution come from the settings (CARTO Positron by default).
 * Pins and clusters are buttons with a name; the selected pin is yellow. On the desktop the
 * map stays next to the list and the pin and the card follow each other; on a phone it
 * opens full screen with the card in a bottom sheet (focus kept inside, Escape closes).
 */
import { __, sprintf } from '@wordpress/i18n';

import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

let clusterReady = null;

/**
 * Zoom when the map frames a single store, and the most when it frames several.
 */
const STORE_ZOOM = 16;
const FRAME_MAX_ZOOM = 15;

/**
 * Leaflet's clusters need `L` as a global.
 *
 * @return {Promise<void>} Ready.
 */
const loadClusters = () => {
	if (!clusterReady) {
		window.L = window.L || L;
		clusterReady = import(
			/* webpackChunkName: "map" */ 'leaflet.markercluster'
		).then(() => undefined);
	}
	return clusterReady;
};

/**
 * Pin icon of the system.
 *
 * @param {boolean} selected Selected.
 * @return {L.DivIcon} Icon.
 */
const pin = (selected) =>
	L.divIcon({
		className: `lc-map__pin${selected ? ' lc-map__pin--on' : ''}`,
		html: '<span class="lc-map__drop" aria-hidden="true"></span>',
		iconSize: [44, 44],
		iconAnchor: [22, 40],
	});

/**
 * A Leaflet map inside a StoreMap element.
 *
 * @param {HTMLElement} element `.lc-map`.
 * @param {Object}      config  Tiles and attribution.
 * @return {L.Map} Map.
 */
const createMap = (element, config) => {
	element.classList.add('lc-map--on');
	element.querySelector('.lc-map__idle')?.remove();
	const holder = document.createElement('div');
	holder.style.position = 'absolute';
	holder.style.inset = '0';
	element.appendChild(holder);
	const map = L.map(holder, {
		zoomControl: false,
		attributionControl: true,
		scrollWheelZoom: false,
	});
	L.control
		.zoom({
			position: 'topright',
			zoomInTitle: __('Acercar', 'lachinata-core'),
			zoomOutTitle: __('Alejar', 'lachinata-core'),
		})
		.addTo(map);
	map.attributionControl.setPrefix(false);
	L.tileLayer(config.tiles, {
		attribution: config.attribution,
		subdomains: 'abcd',
		maxZoom: 19,
		detectRetina: true,
	}).addTo(map);
	// Never the world view: the least zoom whose tiles fill the panel (no grey bands).
	map.setMaxBounds([
		[-85, -540],
		[85, 540],
	]);
	const fill = () =>
		map.setMinZoom(
			Math.max(
				1,
				Math.ceil(
					Math.log2(
						Math.max(holder.clientWidth, holder.clientHeight) / 256
					)
				)
			)
		);
	fill();
	map.on('resize', fill);
	locateControl().addTo(map);
	map.on('focus', () => map.scrollWheelZoom.enable());
	map.on('blur', () => map.scrollWheelZoom.disable());
	return map;
};

/**
 * «Centrar en mi ubicación», under + and − (StoreMap). The location is asked only when it
 * is pressed and never leaves the browser.
 *
 * @return {L.Control} Control.
 */
const locateControl = () => {
	const Control = L.Control.extend({
		options: { position: 'topright' },
		onAdd: (map) => {
			const bar = L.DomUtil.create('div', 'leaflet-bar leaflet-control');
			const button = L.DomUtil.create('a', 'lc-map__locate', bar);
			button.href = '#';
			button.setAttribute('role', 'button');
			button.setAttribute(
				'aria-label',
				__('Centrar en mi ubicación', 'lachinata-core')
			);
			button.title = __('Centrar en mi ubicación', 'lachinata-core');
			button.innerHTML =
				'<svg class="lc-icon lc-icon--sm" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><use href="#lc-icon-locate"></use></svg>';
			L.DomEvent.disableClickPropagation(bar);
			L.DomEvent.on(button, 'click', (event) => {
				L.DomEvent.preventDefault(event);
				window.navigator.geolocation?.getCurrentPosition(
					(position) =>
						map.setView(
							[
								position.coords.latitude,
								position.coords.longitude,
							],
							12
						),
					() => {},
					{ timeout: 10000, maximumAge: 300000 }
				);
			});
			return bar;
		},
	});
	return new Control();
};

/**
 * Frames some stores: one, at its zoom; several, all of them with a margin.
 *
 * @param {L.Map}         map    Map.
 * @param {Array<Object>} stores Stores to frame.
 */
const frame = (map, stores) => {
	const located = stores.filter(
		(store) => store.lat !== null && store.lng !== null
	);
	if (1 === located.length) {
		map.setView([located[0].lat, located[0].lng], STORE_ZOOM);
		return;
	}
	if (located.length) {
		map.fitBounds(
			L.latLngBounds(located.map((store) => [store.lat, store.lng])),
			{ padding: [48, 48], maxZoom: FRAME_MAX_ZOOM }
		);
	}
};

/**
 * Gives the clusters their name («11 oleotecas. Acercar»).
 *
 * @param {HTMLElement} element Map.
 */
let plural = '';

const nameClusters = (element) => {
	element.querySelectorAll('.lc-map__cluster').forEach((cluster) => {
		const count = cluster.textContent.trim();
		cluster.setAttribute('role', 'button');
		cluster.setAttribute(
			'aria-label',
			/* translators: 1: number of stores in the group, 2: «oleotecas». */
			sprintf(__('%1$s %2$s. Acercar', 'lachinata-core'), count, plural)
		);
	});
};

/**
 * Markers of some stores, in clusters, each one a button with the store's name.
 *
 * @param {L.Map}         map      Map.
 * @param {Array<Object>} stores   Stores.
 * @param {Function}      onSelect Called with the slug of the chosen pin.
 * @param {Array<Object>} framed   Stores to frame (the ones the list puts first).
 * @return {{group: Object, markers: Map<string, L.Marker>}} Layer and markers.
 */
const addStores = (map, stores, onSelect, framed) => {
	const group = L.markerClusterGroup({
		showCoverageOnHover: false,
		spiderfyOnMaxZoom: true,
		maxClusterRadius: 50,
		iconCreateFunction: (cluster) =>
			L.divIcon({
				className: 'lc-map__cluster label',
				html: String(cluster.getChildCount()),
				iconSize: [40, 40],
			}),
	});
	const markers = new Map();
	stores
		.filter((store) => store.lat !== null && store.lng !== null)
		.forEach((store) => {
			const marker = L.marker([store.lat, store.lng], {
				icon: pin(false),
				title: store.name,
				alt: store.name,
				keyboard: true,
				riseOnHover: true,
			});
			marker.on('click', () => onSelect(store.slug));
			marker.on('add', () => {
				const icon = marker.getElement();
				icon?.setAttribute('role', 'button');
				icon?.setAttribute('aria-label', store.name);
			});
			markers.set(store.slug, marker);
			group.addLayer(marker);
		});
	map.addLayer(group);
	frame(map, framed && framed.length ? framed : stores);
	map.on('zoomend moveend', () => nameClusters(map.getContainer()));
	nameClusters(map.getContainer());
	return { group, markers };
};

/**
 * The map of a finder: next to the list (desktop, inline) or full screen (phone).
 *
 * @param {Object} options root, config, stores(), frame(), inline, opener, form, onSelect, renderCard, paint.
 */
export const showMap = async (options) => {
	await loadClusters();
	const { root, config } = options;
	plural = options.nouns || '';
	let selected = '';
	let state;
	const select = (slug) => {
		if (selected && state.markers.get(selected)) {
			state.markers.get(selected).setIcon(pin(false));
		}
		selected = slug;
		state.markers.get(slug)?.setIcon(pin(true));
		options.onSelect(slug);
	};

	if (options.inline) {
		const element = root.querySelector('.lc-finder__map .lc-map');
		if (!element || element.classList.contains('lc-map--on')) {
			return;
		}
		const map = createMap(element, config);
		state = addStores(map, options.stores(), select, options.frame());
		try {
			window.sessionStorage.setItem('lc-stores-map', '1');
		} catch {
			// Only a convenience.
		}
		// The list changes (search, filters): the pins follow.
		root.addEventListener('lachinata:stores:list', (event) => {
			map.removeLayer(state.group);
			state = addStores(
				map,
				event.detail.stores,
				select,
				event.detail.frame
			);
		});
		// A card under the pointer marks its pin.
		root.addEventListener('pointerover', (event) => {
			const slug = event.target
				.closest('[data-lc-store]')
				?.getAttribute('data-lc-store');
			if (slug && slug !== selected && state.markers.get(slug)) {
				select(slug);
			}
		});
		return;
	}

	// Phone: full screen with the list button, the field and the bottom sheet.
	const overlay = document.createElement('div');
	overlay.className = 'lc-finder-overlay';
	overlay.setAttribute('role', 'dialog');
	overlay.setAttribute('aria-modal', 'true');
	overlay.setAttribute('aria-label', __('Mapa', 'lachinata-core'));
	overlay.innerHTML = `<div class="lc-map lc-map--full"><div class="lc-map__tiles" aria-hidden="true"></div></div>
		<div class="lc-finder-overlay__bar"><button type="button" class="lc-btn button lc-btn--secondary" data-lc-map-close><svg class="lc-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><use href="#lc-icon-chevron-left"></use></svg>${__('Lista', 'lachinata-core')}</button></div>
		<div class="lc-finder-overlay__sheet" hidden data-lc-map-sheet></div>`;
	if (options.form) {
		const clone = options.form.cloneNode(true);
		clone.addEventListener('submit', (event) => {
			event.preventDefault();
			const field = options.form.querySelector('input[type="search"]');
			field.value = clone.querySelector('input[type="search"]').value;
			options.form.requestSubmit();
		});
		overlay.querySelector('.lc-finder-overlay__bar').appendChild(clone);
	}
	document.body.appendChild(overlay);
	document.body.style.overflow = 'hidden';
	const element = overlay.querySelector('.lc-map');
	const map = createMap(element, config);
	map.scrollWheelZoom.enable();
	const sheet = overlay.querySelector('[data-lc-map-sheet]');
	const showCard = (slug) => {
		sheet.innerHTML = options.renderCard(slug);
		sheet.hidden = !sheet.innerHTML;
		options.paint(sheet);
	};
	const choose = (slug) => {
		select(slug);
		showCard(slug);
	};
	state = addStores(map, options.stores(), choose, options.frame());
	const update = (event) => {
		map.removeLayer(state.group);
		state = addStores(map, event.detail.stores, choose, event.detail.frame);
	};
	root.addEventListener('lachinata:stores:list', update);

	const close = () => {
		root.removeEventListener('lachinata:stores:list', update);
		document.removeEventListener('keydown', keys);
		map.remove();
		overlay.remove();
		document.body.style.overflow = '';
		options.opener?.focus();
	};
	const keys = (event) => {
		if (event.key === 'Escape') {
			close();
			return;
		}
		if (event.key !== 'Tab') {
			return;
		}
		const focusable = [
			...overlay.querySelectorAll(
				'a[href], button, input, [tabindex="0"]'
			),
		].filter(
			(item) => !item.closest('[hidden]') && item.offsetParent !== null
		);
		if (!focusable.length) {
			return;
		}
		const first = focusable[0];
		const last = focusable[focusable.length - 1];
		if (event.shiftKey && overlay.ownerDocument.activeElement === first) {
			event.preventDefault();
			last.focus();
		} else if (
			!event.shiftKey &&
			overlay.ownerDocument.activeElement === last
		) {
			event.preventDefault();
			first.focus();
		}
	};
	document.addEventListener('keydown', keys);
	overlay
		.querySelector('[data-lc-map-close]')
		.addEventListener('click', close);
	overlay.querySelector('[data-lc-map-close]').focus();
};

/**
 * The map of one store (its page), in place.
 *
 * @param {Object} options element, config, store.
 */
export const showStore = (options) => {
	const { element, config, store } = options;
	if (!element || store.lat === null || store.lng === null) {
		return;
	}
	const map = createMap(element, config);
	L.marker([store.lat, store.lng], {
		icon: pin(true),
		title: store.title,
		alt: store.title,
		keyboard: false,
	}).addTo(map);
	map.setView([store.lat, store.lng], STORE_ZOOM);
};
