/**
 * «Abierta ahora» in the store's own time zone (Canarias, Busan, Puebla), never the
 * visitor's: the page comes from the cache and the browser computes it. Special days rule
 * over the week; «cierra pronto» at 60 minutes or less from closing.
 */

export const DAYS = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];

const WEEKDAY = { Mon: 0, Tue: 1, Wed: 2, Thu: 3, Fri: 4, Sat: 5, Sun: 6 };

/**
 * Minutes since midnight of «HH:MM».
 *
 * @param {string} time Time.
 * @return {number} Minutes.
 */
export const minutes = (time) => {
	const [hours, mins] = time.split(':').map(Number);
	return hours * 60 + mins;
};

/**
 * Date, weekday and minutes in a time zone.
 *
 * @param {string} timeZone IANA zone ('' = the visitor's).
 * @param {Date}   now      Moment.
 * @return {{ymd: string, day: number, minutes: number}} Local clock.
 */
export const localNow = (timeZone, now = new Date()) => {
	const options = {
		year: 'numeric',
		month: '2-digit',
		day: '2-digit',
		hour: '2-digit',
		minute: '2-digit',
		weekday: 'short',
		hourCycle: 'h23',
	};
	if (timeZone) {
		options.timeZone = timeZone;
	}
	const parts = {};
	new Intl.DateTimeFormat('en-US', options)
		.formatToParts(now)
		.forEach((part) => {
			parts[part.type] = part.value;
		});
	return {
		ymd: `${parts.year}-${parts.month}-${parts.day}`,
		day: WEEKDAY[parts.weekday],
		minutes: (Number(parts.hour) % 24) * 60 + Number(parts.minute),
	};
};

/**
 * A calendar date plus some days («2026-12-31» + 1 = «2027-01-01»).
 *
 * @param {string} ymd  Date.
 * @param {number} days Days to add.
 * @return {string} Date.
 */
export const addDays = (ymd, days) => {
	const [year, month, day] = ymd.split('-').map(Number);
	const date = new Date(Date.UTC(year, month - 1, day + days));
	return date.toISOString().slice(0, 10);
};

/**
 * Weekday (0 = Monday) of a calendar date.
 *
 * @param {string} ymd Date.
 * @return {number} Day.
 */
export const weekday = (ymd) => {
	const [year, month, day] = ymd.split('-').map(Number);
	return (new Date(Date.UTC(year, month - 1, day)).getUTCDay() + 6) % 7;
};

/**
 * Slots of a date: the special day that covers it, or the week.
 *
 * @param {Object} store Store (hours, specials).
 * @param {string} ymd   Date.
 * @return {{slots: Array<Array<string>>, special: Object|null}} Slots.
 */
export const slotsOn = (store, ymd) => {
	const special = (store.specials || []).find(
		(item) => item.from <= ymd && ymd <= item.to
	);
	if (special) {
		return { slots: special.slots || [], special };
	}
	return {
		slots: (store.hours || {})[DAYS[weekday(ymd)]] || [],
		special: null,
	};
};

/**
 * State of a store at a moment.
 *
 * @param {Object} store Store (hours, specials, timezone).
 * @param {Date}   now   Moment.
 * @return {{state: string, closes?: string, opens?: {ymd: string, time: string, inDays: number}}} State.
 */
export const openState = (store, now = new Date()) => {
	const hasWeek = DAYS.some((day) => ((store.hours || {})[day] || []).length);
	if (!hasWeek && !(store.specials || []).length) {
		return { state: 'unknown' };
	}
	let clock;
	try {
		clock = localNow(store.timezone || '', now);
	} catch {
		return { state: 'unknown' };
	}
	const today = slotsOn(store, clock.ymd).slots;
	for (const [from, to] of today) {
		const start = minutes(from);
		const end = minutes(to);
		if (clock.minutes >= start && clock.minutes < end) {
			return {
				state: end - clock.minutes <= 60 ? 'closing' : 'open',
				closes: to,
			};
		}
		if (clock.minutes < start) {
			return {
				state: 'closed',
				opens: { ymd: clock.ymd, time: from, inDays: 0 },
			};
		}
	}
	for (let inDays = 1; inDays <= 60; inDays++) {
		const ymd = addDays(clock.ymd, inDays);
		const { slots } = slotsOn(store, ymd);
		if (slots.length) {
			return {
				state: 'closed',
				opens: { ymd, time: slots[0][0], inDays },
			};
		}
	}
	return { state: 'closed' };
};
