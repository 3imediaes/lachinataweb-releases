/**
 * The HTML of StoreCard and OpenStatus, the same the server prints (Html.php), for the
 * lists the finder recomputes in the browser.
 */
import { __, sprintf } from '@wordpress/i18n';

/**
 * Escapes text for HTML.
 *
 * @param {*} value Value.
 * @return {string} Escaped.
 */
export const esc = (value) =>
	String(value ?? '').replace(
		/[&<>"']/g,
		(char) =>
			({
				'&': '&amp;',
				'<': '&lt;',
				'>': '&gt;',
				'"': '&quot;',
				"'": '&#39;',
			})[char]
	);

/**
 * Icon of the theme's sprite.
 *
 * @param {string}  name  Icon.
 * @param {boolean} small Small.
 * @return {string} SVG.
 */
export const icon = (name, small = false) =>
	`<svg class="lc-icon${small ? ' lc-icon--sm' : ''}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><use href="#lc-icon-${esc(name)}"></use></svg>`;

/**
 * Whether the visitor is on an Apple device (Apple Maps).
 *
 * @return {boolean} Apple.
 */
export const isApple = () =>
	/iPhone|iPad|iPod|Macintosh/.test(window.navigator.userAgent || '');

/**
 * «Cómo llegar»: Apple Maps on Apple devices, Google Maps elsewhere.
 *
 * @param {Object} store Store (lat, lng, title, line).
 * @return {string} URL.
 */
export const directionsUrl = (store) => {
	const located = store.lat !== null && store.lng !== null;
	if (isApple()) {
		const daddr = located ? `${store.lat},${store.lng}` : store.line;
		return `https://maps.apple.com/?q=${encodeURIComponent(
			store.title
		)}&daddr=${encodeURIComponent(daddr)}`;
	}
	return located
		? `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(
				`${store.lat},${store.lng}`
			)}`
		: `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
				`${store.title}, ${store.line}`
			)}`;
};

/**
 * StoreCard.
 *
 * @param {Object} store   Store in short form.
 * @param {Object} options distance (text), selected.
 * @return {string} HTML.
 */
export const card = (store, options = {}) => {
	const hasHours = Object.values(store.hours || {}).some(
		(slots) => slots.length
	);
	const parts = [];
	parts.push('<div class="lc-store__body"><div class="lc-store__head">');
	parts.push(
		`<a href="${esc(store.url)}" class="lc-store__name h4">${esc(
			store.name
		)}</a>`
	);
	if (options.distance) {
		parts.push(
			`<span class="lc-store__dist body-sm" data-no-translation>${esc(
				options.distance
			)}</span>`
		);
	}
	parts.push('</div>');
	parts.push(
		`<span class="lc-store__addr body-sm" data-no-translation>${esc(
			store.line
		)}</span>`
	);
	if (hasHours) {
		parts.push(
			`<span class="lc-open lc-open--unknown body-sm" data-lc-open=""><span class="lc-open__dot" aria-hidden="true"></span><span class="lc-open__word label">${esc(
				__('Consulta el horario', 'lachinata-core')
			)}</span><span class="lc-open__text"></span></span>`
		);
	}
	if (store.web && store.web.url) {
		parts.push(
			`<a href="${esc(
				store.web.url
			)}" class="lc-store__web body-sm" data-lc-store-web>${icon(
				'bag',
				true
			)}<span>${esc(
				__('Tienda online:', 'lachinata-core')
			)} <span class="label" data-no-translation>${esc(
				store.web.label
			)}</span></span></a>`
		);
	}
	parts.push('<div class="lc-store__actions">');
	parts.push(
		`<a class="lc-btn button lc-btn--secondary lc-btn--sm" href="${esc(
			directionsUrl(store)
		)}" aria-label="${esc(
			/* translators: %s: store name. */
			sprintf(__('Cómo llegar a %s', 'lachinata-core'), store.name)
		)}" data-lc-directions="" target="_blank" rel="noopener">${icon(
			'navigation'
		)}${esc(__('Cómo llegar', 'lachinata-core'))}</a>`
	);
	if (store.phone) {
		parts.push(
			`<a class="lc-btn button lc-btn--ghost lc-btn--sm" href="tel:${esc(
				store.phone
			)}" aria-label="${esc(
				/* translators: %s: store name. */
				sprintf(__('Llamar a %s', 'lachinata-core'), store.name)
			)}" data-lc-store-call="">${icon('phone')}${esc(
				__('Llamar', 'lachinata-core')
			)}</a>`
		);
	}
	parts.push('</div></div>');
	return `<article class="lc-store${
		options.selected ? ' lc-store--on' : ''
	}" data-lc-store="${esc(store.slug)}">${parts.join('')}</article>`;
};
