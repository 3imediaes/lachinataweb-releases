<?php
/**
 * The finder: StoreSearch, the list of StoreCard and the map on demand.
 *
 * Shared by the finder page, the zone pages and the block. Works without JavaScript (the
 * search is a GET form, «Ver más» a link); the script (src/finder.js) recomputes the list
 * in the browser from the JSON of the stores.
 *
 * @package LaChinata\Core
 *
 * @var array<string, mixed> $args stores (short form), groups (label + stores, optional),
 *      status (line of results), limit (0 = all), more_url, zone (slug), filters (services),
 *      src (URL of the JSON), map_cta, id.
 */

use LaChinata\Core\Modules\Oleotecas\Html;
use LaChinata\Core\Modules\Oleotecas\Texts;
use LaChinata\Core\Modules\Oleotecas\Tiles;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- The pieces come escaped from Html; the rest is escaped where it is printed.

$lachinata_stores  = (array) ( $args['stores'] ?? array() );
$lachinata_groups  = (array) ( $args['groups'] ?? array() );
$lachinata_limit   = (int) ( $args['limit'] ?? 0 );
$lachinata_shown   = 0;
$lachinata_id      = (string) ( $args['id'] ?? 'lc-finder' );
$lachinata_plural  = Texts::noun( true );
$lachinata_filters = (array) ( $args['filters'] ?? array() );
$lachinata_map     = Tiles::available();
if ( ! $lachinata_groups ) {
	$lachinata_groups = array(
		array(
			'label'  => '',
			'stores' => $lachinata_stores,
		),
	);
}
?>
<div class="lc-finder" id="<?php echo esc_attr( $lachinata_id ); ?>" data-lc-finder="
<?php
echo esc_attr(
	(string) wp_json_encode(
		array(
			'src'   => (string) ( $args['src'] ?? '' ),
			'zone'  => (string) ( $args['zone'] ?? '' ),
			'limit' => $lachinata_limit,
		)
	)
);
?>
">
	<div class="lc-finder__list">
		<div class="lc-locsearch" role="search">
			<form class="lc-locsearch__row" method="get" action="<?php echo esc_url( (string) ( $args['action'] ?? '' ) ); ?>#<?php echo esc_attr( $lachinata_id ); ?>" data-lc-finder-form>
				<div class="lc-field lc-field--icon">
					<div class="lc-field__box">
						<?php echo Html::icon( 'search', true ); ?>
						<input type="search" name="q" value="<?php echo esc_attr( (string) ( $args['query'] ?? '' ) ); ?>" placeholder="<?php esc_attr_e( 'Ciudad o código postal', 'lachinata-core' ); ?>" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: «oleoteca». */ __( 'Buscar %s por ciudad o código postal', 'lachinata-core' ), Texts::noun() ) ); ?>" autocomplete="off" inputmode="search" enterkeyhint="search">
					</div>
				</div>
			</form>
			<div class="lc-chiprow lc-locsearch__chips" role="group" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: «oleotecas». */ __( 'Ordenar y filtrar %s', 'lachinata-core' ), $lachinata_plural ) ); ?>">
				<button type="button" class="lc-chip label lc-locsearch__near" aria-pressed="false" data-lc-near><?php echo Html::icon( 'locate', true ); ?><?php esc_html_e( 'Cerca de mí', 'lachinata-core' ); ?></button>
				<button type="button" class="lc-chip label" aria-pressed="false" data-lc-filter="open"><?php esc_html_e( 'Abierta ahora', 'lachinata-core' ); ?></button>
				<?php foreach ( $lachinata_filters as $lachinata_slug => $lachinata_label ) : ?>
					<button type="button" class="lc-chip label" aria-pressed="false" data-lc-filter="<?php echo esc_attr( 'service:' . $lachinata_slug ); ?>"><?php echo esc_html( (string) $lachinata_label ); ?></button>
				<?php endforeach; ?>
			</div>
			<p class="lc-locsearch__count body-sm" role="status" data-lc-status><?php echo esc_html( (string) ( $args['status'] ?? '' ) ); ?></p>
		</div>
		<?php if ( $lachinata_map ) : ?>
			<?php
			echo Html::button(
				__( 'Ver en el mapa', 'lachinata-core' ),
				array(
					'variant'   => 'secondary',
					'icon_left' => 'map',
					'block'     => true,
					'class'     => 'lc-finder__open',
					'attrs'     => array( 'data-lc-map-open' => '' ),
				)
			);
			?>
		<?php endif; ?>
		<div class="lc-finder__cards" data-lc-cards>
			<?php foreach ( $lachinata_groups as $lachinata_group ) : ?>
				<?php if ( '' !== (string) $lachinata_group['label'] ) : ?>
					<h2 class="h4 lc-finder__group"><?php echo esc_html( (string) $lachinata_group['label'] ); ?></h2>
				<?php endif; ?>
				<?php
				foreach ( (array) $lachinata_group['stores'] as $lachinata_store ) {
					if ( $lachinata_limit && $lachinata_shown >= $lachinata_limit ) {
						break 2;
					}
					++$lachinata_shown;
					echo Html::card( (array) $lachinata_store, array( 'layout' => (string) ( $args['layout'] ?? '' ) ) );
				}
				?>
			<?php endforeach; ?>
		</div>
		<?php if ( $lachinata_limit && count( $lachinata_stores ) > $lachinata_limit ) : ?>
			<?php
			echo Html::button(
				sprintf( /* translators: %s: «oleotecas». */ __( 'Ver más %s', 'lachinata-core' ), $lachinata_plural ),
				array(
					'variant' => 'secondary',
					'block'   => true,
					'href'    => (string) ( $args['more_url'] ?? '' ),
					'attrs'   => array( 'data-lc-more' => '' ),
				)
			);
			?>
		<?php endif; ?>
	</div>
	<?php if ( $lachinata_map ) : ?>
	<div class="lc-finder__map">
		<?php
		echo Html::map(
			array(
				'cta'  => (string) ( $args['map_cta'] ?? '' ),
				'note' => Html::map_note(),
			)
		);
		?>
	</div>
	<?php endif; ?>
</div>
