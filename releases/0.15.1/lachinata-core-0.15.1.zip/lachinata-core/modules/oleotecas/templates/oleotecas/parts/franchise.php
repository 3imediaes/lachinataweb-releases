<?php
/**
 * Franchise block at the end of the pages: content of the settings; nothing when empty.
 *
 * @package LaChinata\Core
 */

use LaChinata\Core\Modules\Oleotecas\Html;
use LaChinata\Core\Modules\Oleotecas\OleotecasModule;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- The pieces come escaped from Html; the rest is escaped where it is printed.

$lachinata_title = trim( (string) OleotecasModule::setting( 'franchise_title' ) );
$lachinata_url   = trim( (string) OleotecasModule::setting( 'franchise_url' ) );
if ( '' === $lachinata_title || '' === $lachinata_url ) {
	return;
}
$lachinata_eyebrow = trim( (string) OleotecasModule::setting( 'franchise_eyebrow' ) );
$lachinata_text    = trim( (string) OleotecasModule::setting( 'franchise_text' ) );
$lachinata_cta     = trim( (string) OleotecasModule::setting( 'franchise_cta' ) );
?>
<section class="lc-stores-franchise">
	<div class="lc-stores-franchise__text">
		<?php if ( '' !== $lachinata_eyebrow ) : ?>
			<span class="eyebrow"><?php echo esc_html( $lachinata_eyebrow ); ?></span>
		<?php endif; ?>
		<h2 class="h3"><?php echo esc_html( $lachinata_title ); ?></h2>
		<?php if ( '' !== $lachinata_text ) : ?>
			<p class="body-sm"><?php echo esc_html( $lachinata_text ); ?></p>
		<?php endif; ?>
	</div>
	<?php
	echo Html::button(
		'' === $lachinata_cta ? __( 'Más información', 'lachinata-core' ) : $lachinata_cta,
		array(
			'variant' => 'secondary',
			'icon'    => 'arrow-right',
			'href'    => $lachinata_url,
		)
	);
	?>
</section>
