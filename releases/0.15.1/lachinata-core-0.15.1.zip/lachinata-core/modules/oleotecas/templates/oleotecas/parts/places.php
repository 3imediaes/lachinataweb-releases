<?php
/**
 * «Por país y ciudad»: the shop's country with its zones and the rest of its stores, then
 * the other countries. A place with one store links to its page.
 *
 * @package LaChinata\Core
 *
 * @var array<string, mixed> $args places (Pages::places()).
 */

use LaChinata\Core\Modules\Oleotecas\Html;

defined( 'ABSPATH' ) || exit;

$lachinata_places = (array) ( $args['places'] ?? array() );
if ( ! $lachinata_places ) {
	return;
}
?>
<section class="lc-stores-places">
	<h2 class="h3"><?php esc_html_e( 'Por país y ciudad', 'lachinata-core' ); ?></h2>
	<div class="lc-stores-places__grid">
		<?php foreach ( $lachinata_places as $lachinata_block ) : ?>
			<div>
				<h3 class="label lc-stores-places__title"><?php echo esc_html( (string) $lachinata_block['title'] ); ?></h3>
				<div class="lc-stores-places__list">
					<?php foreach ( (array) $lachinata_block['links'] as $lachinata_link ) : ?>
						<a class="lc-stores-places__link body" href="<?php echo esc_url( (string) $lachinata_link['url'] ); ?>">
							<span><?php echo esc_html( (string) $lachinata_link['name'] ); ?></span>
							<span class="body-sm"><?php echo esc_html( (string) $lachinata_link['count'] ); ?> <?php echo Html::icon( 'chevron-right', true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in Html. ?></span>
						</a>
					<?php endforeach; ?>
				</div>
			</div>
		<?php endforeach; ?>
	</div>
</section>
