<?php
/**
 * Zone (`/oleotecas/{zona}/`): breadcrumb, title and own text, the zone's finder (grouped by
 * city if the zone says so), the map at rest, questions, other zones and the franchise
 * block (OleotecasZona.dc.html).
 *
 * The theme can override it with `lachinata/oleotecas/zone.php`.
 *
 * @package LaChinata\Core
 */

use LaChinata\Core\Modules\Oleotecas\Directory;
use LaChinata\Core\Modules\Oleotecas\Html;
use LaChinata\Core\Modules\Oleotecas\Pages;
use LaChinata\Core\Modules\Oleotecas\Texts;
use LaChinata\Core\Templates;

defined( 'ABSPATH' ) || exit;

$lachinata_term = get_queried_object();
$lachinata_zone = $lachinata_term instanceof WP_Term ? Directory::zone( (int) $lachinata_term->term_id ) : null;

get_header();
if ( null !== $lachinata_zone ) :
	$lachinata_others = array_filter( Directory::zones(), static fn( array $zone ): bool => $zone['page'] && $zone['id'] !== $lachinata_zone['id'] && $zone['id'] !== $lachinata_zone['parent'] && $zone['parent'] !== $lachinata_zone['id'] );
	?>
<div class="lc-stores lc-stores--zone">
	<header class="lc-stores-hero lc-stores-hero--crumbs">
		<div class="lc-stores-hero__inner">
			<?php get_template_part( 'template-parts/breadcrumb' ); ?>
			<h1 class="editorial-h1"><?php echo esc_html( Texts::zone_title( $lachinata_zone['name'] ) ); ?></h1>
			<?php if ( '' !== $lachinata_zone['text'] ) : ?>
				<p class="body"><?php echo esc_html( $lachinata_zone['text'] ); ?></p>
			<?php endif; ?>
		</div>
	</header>
	<div class="lc-stores__inner">
		<?php Templates::part( 'oleotecas', 'parts/finder', Pages::zone_args( $lachinata_zone ) ); ?>

		<?php if ( $lachinata_zone['faq'] ) : ?>
			<section class="lc-stores-section">
				<h2 class="h3"><?php esc_html_e( 'Preguntas frecuentes', 'lachinata-core' ); ?></h2>
				<div class="lc-acc">
					<?php foreach ( $lachinata_zone['faq'] as $lachinata_index => $lachinata_item ) : ?>
						<div class="lc-acc__item">
							<button type="button" class="lc-acc__btn h4" aria-expanded="false" aria-controls="lc-faq-<?php echo esc_attr( (string) $lachinata_index ); ?>" data-lc-toggle>
								<?php echo esc_html( $lachinata_item['question'] ); ?>
								<?php echo Html::icon( 'chevron-down' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in Html. ?>
							</button>
							<div class="lc-acc__panel body-sm" id="lc-faq-<?php echo esc_attr( (string) $lachinata_index ); ?>" hidden>
								<?php echo wp_kses_post( wpautop( $lachinata_item['answer'] ) ); ?>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			</section>
		<?php endif; ?>

		<?php if ( $lachinata_others ) : ?>
			<section class="lc-stores-section">
				<h2 class="h3"><?php esc_html_e( 'Otras zonas', 'lachinata-core' ); ?></h2>
				<div class="lc-stores-section__chips">
					<?php foreach ( $lachinata_others as $lachinata_other ) : ?>
						<a class="lc-chip label" href="<?php echo esc_url( $lachinata_other['url'] ); ?>"><?php echo esc_html( $lachinata_other['name'] . ' · ' . number_format_i18n( count( $lachinata_other['stores'] ) ) ); ?></a>
					<?php endforeach; ?>
				</div>
			</section>
		<?php endif; ?>

		<?php Templates::part( 'oleotecas', 'parts/franchise' ); ?>
	</div>
</div>
	<?php
endif;
get_footer();
