<?php
/**
 * Shipping configuration: zone rules, restrictions and instance conditions.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping;

use LaChinata\Core\Plugin;
use LaChinata\Core\Settings;
use LaChinata\Core\Shipping\Zones;
use LaChinata\Core\Shipping\Package;

defined( 'ABSPATH' ) || exit;

/**
 * Reads and writes what the module stores and evaluates WooCommerce packages with it.
 * Instance conditions live in each instance's own WooCommerce settings (`lc_*` keys), so
 * they go away with the instance; zone rules and restrictions are module options.
 */
final class Config {

	/**
	 * Option with the rules per zone id.
	 */
	public const ZONES = 'lachinata_shipping_zones';

	/**
	 * Option with the product restrictions.
	 */
	public const RESTRICTIONS = 'lachinata_shipping_restrictions';

	/**
	 * Decisions of this request, by package hash.
	 *
	 * @var array<string, array{Decision, \WC_Shipping_Zone, ZoneRules, Package}>
	 */
	private static array $memo = array();

	/**
	 * Rules of a zone (empty rules when it has none).
	 *
	 * @param int $zone_id Zone id.
	 */
	public static function zone_rules( int $zone_id ): ZoneRules {
		$all = self::all_zone_rules();
		return $all[ $zone_id ] ?? new ZoneRules( $zone_id );
	}

	/**
	 * Rules of every zone that has some.
	 *
	 * @return array<int, ZoneRules>
	 */
	public static function all_zone_rules(): array {
		$stored = get_option( self::ZONES, array() );
		$rules  = array();
		foreach ( is_array( $stored ) ? $stored : array() as $zone_id => $data ) {
			if ( is_array( $data ) ) {
				$rules[ (int) $zone_id ] = ZoneRules::from_array( (int) $zone_id, $data );
			}
		}
		return $rules;
	}

	/**
	 * Saves the rules of every zone.
	 *
	 * @param ZoneRules[] $rules Rules.
	 */
	public static function save_zone_rules( array $rules ): void {
		$stored = array();
		foreach ( $rules as $rule ) {
			$stored[ $rule->zone_id ] = $rule->to_array();
		}
		update_option( self::ZONES, $stored );
		self::changed();
	}

	/**
	 * Product restrictions.
	 *
	 * @return Restriction[]
	 */
	public static function restrictions(): array {
		$stored = get_option( self::RESTRICTIONS, array() );
		$list   = array();
		foreach ( is_array( $stored ) ? $stored : array() as $data ) {
			$restriction = is_array( $data ) ? Restriction::from_array( $data ) : null;
			if ( null !== $restriction ) {
				$list[] = $restriction;
			}
		}
		return $list;
	}

	/**
	 * Saves the product restrictions.
	 *
	 * @param Restriction[] $restrictions Restrictions.
	 */
	public static function save_restrictions( array $restrictions ): void {
		update_option( self::RESTRICTIONS, array_map( static fn( Restriction $r ): array => $r->to_array(), array_values( $restrictions ) ) );
		self::changed();
	}

	/**
	 * Notice of a product page when the product does not ship to the visitor's destination
	 * ('' = the default text).
	 */
	public static function unavailable_text(): string {
		$module = Plugin::instance()->modules()->get( 'shipping' );
		return null === $module ? '' : trim( (string) Settings::get( $module, 'unavailable_text' ) );
	}

	/**
	 * Zone used when the visitor's destination is not known (PromoBar, product page).
	 */
	public static function default_zone_id(): int {
		$module = Plugin::instance()->modules()->get( 'shipping' );
		return null === $module ? 0 : (int) Settings::get( $module, 'default_zone' );
	}

	/**
	 * Every zone, the rest of the world (id 0) last.
	 *
	 * @return array<int, \WC_Shipping_Zone>
	 */
	public static function zones(): array {
		return Zones::all();
	}

	/**
	 * Zone matching a destination.
	 *
	 * @param array{country: string, state?: string, postcode?: string} $destination Destination.
	 */
	public static function zone_for( array $destination ): \WC_Shipping_Zone {
		return Zones::for_destination( $destination );
	}

	/**
	 * Enabled instances of a zone with their conditions, in zone order.
	 *
	 * @param \WC_Shipping_Zone $zone Zone.
	 * @return Candidate[]
	 */
	public static function candidates( \WC_Shipping_Zone $zone ): array {
		$candidates = array();
		foreach ( $zone->get_shipping_methods( true ) as $method ) {
			if ( ! $method instanceof \WC_Shipping_Method || ! $method->get_instance_id() ) {
				continue;
			}
			$candidates[] = new Candidate( (int) $method->get_instance_id(), (string) $method->get_title(), Conditions::from_settings( self::instance_settings( $method ) ) );
		}
		return $candidates;
	}

	/**
	 * Settings of an instance as WooCommerce stores them.
	 *
	 * @param \WC_Shipping_Method $method Instance.
	 * @return array<string, mixed>
	 */
	public static function instance_settings( \WC_Shipping_Method $method ): array {
		return Zones::instance_settings( $method );
	}

	/**
	 * Every instance of every zone, by instance id.
	 *
	 * @return array<int, array{zone: \WC_Shipping_Zone, method: \WC_Shipping_Method}>
	 */
	public static function instances(): array {
		return Zones::instances();
	}

	/**
	 * Decision for a package, with its zone, the zone rules and the package as the rules see it.
	 *
	 * @param Package $package Package.
	 * @return array{Decision, \WC_Shipping_Zone, ZoneRules, Package}
	 */
	public static function evaluate( Package $package ): array {
		$key = md5( (string) wp_json_encode( $package ) );
		if ( ! isset( self::$memo[ $key ] ) ) {
			$zone               = self::zone_for(
				array(
					'country'  => $package->country,
					'state'    => $package->state,
					'postcode' => $package->postcode,
				)
			);
			$rules              = self::zone_rules( (int) $zone->get_id() );
			self::$memo[ $key ] = array( Evaluator::decide( $package, $rules, self::candidates( $zone ), self::restrictions() ), $zone, $rules, $package );
		}
		return self::$memo[ $key ];
	}

	/**
	 * Free shipping threshold for a destination, or null.
	 *
	 * @param array{country: string, state?: string, postcode?: string} $destination Destination.
	 */
	public static function threshold_for( array $destination ): ?float {
		return self::zone_rules( (int) self::zone_for( $destination )->get_id() )->free_threshold;
	}

	/**
	 * Whether the amount for the threshold ignores discounts in a zone: the setting of the
	 * first instance whose minimum is the zone threshold, so the notice and the method agree.
	 *
	 * @param \WC_Shipping_Zone $zone Zone.
	 */
	public static function threshold_ignores_discounts( \WC_Shipping_Zone $zone ): bool {
		foreach ( self::candidates( $zone ) as $candidate ) {
			if ( Conditions::ZONE_THRESHOLD === $candidate->conditions->amount_min ) {
				return $candidate->conditions->ignore_discounts;
			}
		}
		return false;
	}

	/**
	 * Forgets cached decisions and WooCommerce's cached rates after a configuration change.
	 */
	public static function changed(): void {
		self::forget();
		Zones::changed();
	}

	/**
	 * Forgets the decisions and live rates memoised in this request
	 * (`lachinata/shipping/changed`).
	 */
	public static function forget(): void {
		self::$memo = array();
		Live\LiveRates::reset();
	}
}
