<?php
/**
 * Shipping decision: which instances a package gets, or why it gets none.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping;

use LaChinata\Core\Shipping\Package;

defined( 'ABSPATH' ) || exit;

/**
 * Pure logic, without WordPress: the same input always gives the same decision.
 *
 * 1. A zone without methods does not cover the destination (`zona_no_cubierta`).
 * 2. A product restricted for the destination blocks the package (`producto_restringido`).
 * 3. Above the zone's maximum weight the package is blocked (`peso_max`).
 * 4. Each instance is offered when the package meets its conditions.
 * 5. Offered instances are sorted by priority (ties keep the zone order) and, in that
 *    order, each one that is still offered hides the instances in its list. A hidden
 *    instance hides nothing.
 * 6. With nothing offered, the cause is `peso_max` or `importe` when every instance fails
 *    on weight or on amount; otherwise `sin_metodo` (a gap in the configuration).
 */
final class Evaluator {

	/**
	 * Decides.
	 *
	 * @param Package       $package      Package.
	 * @param ZoneRules     $zone         Rules of the zone that matches the destination.
	 * @param Candidate[]   $candidates   Enabled instances of the zone, in zone order.
	 * @param Restriction[] $restrictions Product restrictions.
	 */
	public static function decide( Package $package, ZoneRules $zone, array $candidates, array $restrictions ): Decision {
		if ( ! $candidates ) {
			return new Decision( array(), array(), 'zona_no_cubierta' );
		}

		$restricted = self::restricted( $package, $restrictions );
		if ( $restricted ) {
			return new Decision( array(), array(), 'producto_restringido', true, $restricted );
		}

		if ( null !== $zone->max_weight && $package->weight > $zone->max_weight ) {
			return new Decision( array(), array(), 'peso_max', true, array(), $zone->max_weight );
		}

		$rejected   = array();
		$applicable = array();
		foreach ( array_values( $candidates ) as $position => $candidate ) {
			$failures = $candidate->conditions->failures( $package, $zone->free_threshold );
			if ( $failures ) {
				$rejected[ $candidate->instance_id ] = $failures;
				continue;
			}
			$applicable[] = array( $candidate, $position );
		}

		usort(
			$applicable,
			static fn( array $a, array $b ): int => array( $a[0]->conditions->priority, $a[1] ) <=> array( $b[0]->conditions->priority, $b[1] )
		);

		$hidden = array();
		foreach ( $applicable as list( $candidate ) ) {
			if ( isset( $hidden[ $candidate->instance_id ] ) ) {
				continue;
			}
			foreach ( $candidate->conditions->hides as $target ) {
				if ( $target !== $candidate->instance_id && ! isset( $hidden[ $target ] ) ) {
					$hidden[ $target ] = $candidate->instance_id;
				}
			}
		}

		$offered = array();
		foreach ( $applicable as list( $candidate ) ) {
			if ( isset( $hidden[ $candidate->instance_id ] ) ) {
				$rejected[ $candidate->instance_id ] = array( 'hidden:' . $hidden[ $candidate->instance_id ] );
				continue;
			}
			$offered[] = $candidate->instance_id;
		}

		if ( $offered ) {
			return new Decision( $offered, $rejected, null );
		}

		$all_fail = static fn( string $failure ): bool => count( array_filter( $rejected, static fn( array $reasons ): bool => in_array( $failure, $reasons, true ) ) ) === count( $rejected );
		if ( $all_fail( 'weight' ) ) {
			$limits = array_filter( array_map( static fn( Candidate $c ): ?float => $c->conditions->weight_max, $candidates ), 'is_float' );
			return new Decision( array(), $rejected, 'peso_max', false, array(), $limits ? max( $limits ) : null );
		}
		if ( $all_fail( 'amount' ) ) {
			return new Decision( array(), $rejected, 'importe' );
		}
		return new Decision( array(), $rejected, 'sin_metodo' );
	}

	/**
	 * Products that cannot ship to the package destination.
	 *
	 * @param Package       $package      Package.
	 * @param Restriction[] $restrictions Restrictions.
	 * @return array<int, string> Product id → name.
	 */
	public static function restricted( Package $package, array $restrictions ): array {
		$restricted = array();
		foreach ( $package->products as $id => $product ) {
			foreach ( Restriction::for_product( $product, $restrictions ) as $restriction ) {
				if ( ! $restriction->allows( $package->country, $package->state ) ) {
					$restricted[ $id ] = $product['name'];
					break;
				}
			}
		}
		return $restricted;
	}
}
