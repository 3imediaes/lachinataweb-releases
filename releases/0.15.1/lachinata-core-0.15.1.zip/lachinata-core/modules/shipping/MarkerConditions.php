<?php
/**
 * Shipping conditions of a class for its notice on the product page.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping;

use LaChinata\Core\Hooks;
use LaChinata\Core\Shipping\Package;

defined( 'ABSPATH' ) || exit;

/**
 * «Solo a España peninsular; por 10 €, gratis desde 60 €.»: where the products of a
 * shipping class go (its restriction and the product's own), what shipping costs and from
 * which amount it is free, worked out with the same rules as the cart for a package with
 * only that class. Nothing is written by hand: change the zones, the methods or the
 * restriction and the sentence follows.
 */
final class MarkerConditions {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/catalog/marker_conditions', array( self::class, 'sentences' ), 10, 3 );
	}

	/**
	 * Adds the shipping sentence.
	 *
	 * @param string[]|mixed $sentences Sentences so far.
	 * @param string|mixed   $slug      Shipping class slug.
	 * @param mixed          $product   Product.
	 * @return string[]|mixed
	 */
	public static function sentences( $sentences, $slug, $product ) {
		if ( ! is_array( $sentences ) || ! $product instanceof \WC_Product ) {
			return $sentences;
		}
		$text = self::sentence( (string) $slug, $product );
		if ( '' !== $text ) {
			$sentences[] = $text;
		}
		return $sentences;
	}

	/**
	 * The sentence for a class and a product, or '' when there is nothing to say.
	 *
	 * @param string      $slug    Shipping class slug.
	 * @param \WC_Product $product Product.
	 */
	public static function sentence( string $slug, \WC_Product $product ): string {
		$entry            = Package::product_entry( $product, 0.5 );
		$entry['classes'] = '' === $slug ? array() : array( $slug );
		$restrictions     = Restriction::for_product( $entry, Config::restrictions() );
		$places           = self::places( $restrictions );
		$destination      = self::destination( $restrictions );
		$price            = null === $destination ? null : self::price( $entry, $destination, 0.01 );
		$free             = null === $destination ? null : self::free_from( $entry, $destination );

		$money = static function ( float $amount ): string {
			$decimals = floor( $amount ) === $amount ? 0 : wc_get_price_decimals();
			return html_entity_decode( wp_strip_all_tags( wc_price( $amount, array( 'decimals' => $decimals ) ) ) );
		};
		$cost  = match ( true ) {
			null !== $price && $price > 0 && null !== $free => sprintf(
				/* translators: 1: shipping price, 2: order amount from which it is free. */
				__( 'por %1$s, gratis desde %2$s', 'lachinata-core' ),
				$money( $price ),
				$money( $free )
			),
			null !== $free => sprintf(
				/* translators: %s: order amount from which shipping is free. */
				__( 'gratis desde %s', 'lachinata-core' ),
				$money( $free )
			),
			null !== $price && $price > 0 => sprintf(
				/* translators: %s: shipping price. */
				__( 'por %s', 'lachinata-core' ),
				$money( $price )
			),
			default => '',
		};

		if ( '' !== $places && '' !== $cost ) {
			/* translators: 1: places («España peninsular»), 2: price and free shipping. */
			return sprintf( __( 'Solo a %1$s; %2$s.', 'lachinata-core' ), $places, $cost );
		}
		if ( '' !== $places ) {
			/* translators: %s: places («España peninsular»). */
			return sprintf( __( 'Solo a %s.', 'lachinata-core' ), $places );
		}
		return '' === $cost ? '' : ucfirst( $cost ) . '.';
	}

	/**
	 * The places a product may go to, for people: «España peninsular», «España y Portugal».
	 * With several restrictions, the first one that limits it (the class before the
	 * product's own).
	 *
	 * @param Restriction[] $restrictions Restrictions of the product.
	 */
	public static function places( array $restrictions ): string {
		$restriction = $restrictions[0] ?? null;
		if ( null === $restriction ) {
			return '';
		}
		$countries = WC()->countries;
		$names     = array();
		foreach ( $restriction->allowed as $place ) {
			[ $country, $state ] = array_pad( explode( ':', $place, 2 ), 2, '' );
			$country_name        = html_entity_decode( (string) ( $countries->get_countries()[ $country ] ?? $country ) );
			if ( '' !== $state ) {
				$states  = $countries->get_states( $country );
				$names[] = html_entity_decode( (string) ( is_array( $states ) && isset( $states[ $state ] ) ? $states[ $state ] : $place ) );
				continue;
			}
			$except = array_values(
				array_map(
					static fn( string $code ): string => substr( $code, strlen( $country ) + 1 ),
					array_filter( $restriction->except, static fn( string $code ): bool => str_starts_with( $code, $country . ':' ) )
				)
			);
			if ( ! $except ) {
				$names[] = $country_name;
			} elseif ( 'ES' === $country && ! array_diff( array( 'PM', 'GC', 'TF', 'CE', 'ML' ), $except ) ) {
				// The islands, Ceuta and Melilla out: the Peninsula, as people say it.
				$names[] = __( 'España peninsular', 'lachinata-core' );
			} else {
				$states  = $countries->get_states( $country );
				$skipped = array_map( static fn( string $code ): string => html_entity_decode( (string) ( is_array( $states ) && isset( $states[ $code ] ) ? $states[ $code ] : $code ) ), $except );
				/* translators: 1: country, 2: states left out. */
				$names[] = sprintf( __( '%1$s (salvo %2$s)', 'lachinata-core' ), $country_name, wp_sprintf_l( '%l', $skipped ) );
			}
		}
		return wp_sprintf_l( '%l', $names );
	}

	/**
	 * A destination the product can go to, for the price: the first place of its
	 * restriction, or the default zone's.
	 *
	 * @param Restriction[] $restrictions Restrictions of the product.
	 * @return array{country: string, state: string}|null
	 */
	private static function destination( array $restrictions ): ?array {
		$place = $restrictions[0]->allowed[0] ?? '';
		if ( '' !== $place ) {
			[ $country, $state ] = array_pad( explode( ':', $place, 2 ), 2, '' );
			return array(
				'country' => $country,
				'state'   => $state,
			);
		}
		$zones = \LaChinata\Core\Shipping\Destination::of_zone( new \WC_Shipping_Zone( Config::default_zone_id() ) );
		return '' === $zones['country'] ? null : array(
			'country' => $zones['country'],
			'state'   => $zones['state'],
		);
	}

	/**
	 * Cheapest paid method offered for a package with only this product, with tax, or null.
	 *
	 * @param array<string, mixed>                  $entry       Product entry.
	 * @param array{country: string, state: string} $destination Destination.
	 * @param float                                 $amount      Order amount.
	 */
	private static function price( array $entry, array $destination, float $amount ): ?float {
		[ $decision ] = Config::evaluate( self::package( $entry, $destination, $amount ) );
		$prices       = array();
		foreach ( $decision->offered as $instance_id ) {
			$method = Config::instances()[ $instance_id ]['method'] ?? null;
			$cost   = $method instanceof \WC_Shipping_Method ? $method->get_option( 'cost', '' ) : '';
			if ( is_numeric( $cost ) ) {
				$taxes    = 'taxable' === $method->get_option( 'tax_status', 'taxable' ) ? \WC_Tax::calc_shipping_tax( (float) $cost, self::tax_rates( $destination ) ) : array();
				$prices[] = (float) $cost + (float) array_sum( $taxes );
			}
		}
		return $prices ? round( min( $prices ), wc_get_price_decimals() ) : null;
	}

	/**
	 * Tax rates of shipping to a destination, when the shop shows prices with tax. The
	 * shipping tax class «based on the cart items» has no cart here: the standard rate.
	 *
	 * @param array{country: string, state: string} $destination Destination.
	 * @return array<int, array<string, mixed>>
	 */
	private static function tax_rates( array $destination ): array {
		if ( ! wc_tax_enabled() || 'incl' !== get_option( 'woocommerce_tax_display_shop' ) ) {
			return array();
		}
		$class = (string) get_option( 'woocommerce_shipping_tax_class', 'inherit' );
		return \WC_Tax::find_shipping_rates(
			array(
				'country'   => $destination['country'],
				'state'     => $destination['state'],
				'postcode'  => '',
				'city'      => '',
				'tax_class' => 'inherit' === $class ? '' : $class,
			)
		);
	}

	/**
	 * Order amount from which shipping is free for a package with only this product: the
	 * minimum of the free shipping methods offered for a large order, or null.
	 *
	 * @param array<string, mixed>                  $entry       Product entry.
	 * @param array{country: string, state: string} $destination Destination.
	 */
	private static function free_from( array $entry, array $destination ): ?float {
		[ $decision, $zone, $rules ] = Config::evaluate( self::package( $entry, $destination, 1000000.0 ) );
		$candidates                  = array();
		foreach ( Config::candidates( $zone ) as $candidate ) {
			$candidates[ $candidate->instance_id ] = $candidate;
		}
		$from = array();
		foreach ( $decision->offered as $instance_id ) {
			$method = Config::instances()[ $instance_id ]['method'] ?? null;
			if ( ! $method instanceof \WC_Shipping_Free_Shipping || ! isset( $candidates[ $instance_id ] ) ) {
				continue;
			}
			$min = $candidates[ $instance_id ]->conditions->amount_min;
			$min = Conditions::ZONE_THRESHOLD === $min ? $rules->free_threshold : $min;
			if ( null !== $min ) {
				$from[] = (float) $min;
			}
		}
		return $from ? min( $from ) : null;
	}

	/**
	 * Package with only the product.
	 *
	 * @param array<string, mixed>                  $entry       Product entry.
	 * @param array{country: string, state: string} $destination Destination.
	 * @param float                                 $amount      Order amount.
	 */
	private static function package( array $entry, array $destination, float $amount ): Package {
		return new Package( $destination['country'], $destination['state'], '', 0.5, $amount, $amount, array( 1 => $entry ) );
	}
}
