<?php
/**
 * «Solo se envía a»: the places a product alone ships to.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * A restriction of a single product, on top of those of its shipping class: a list of
 * WooCommerce locations (a country, or a country and state) in the Envío tab of the
 * product. Replaces the per-product rules of Country Based Restrictions
 * (`_restricted_countries`), which `wp lachinata shipping migrate-restrictions` copies.
 */
final class ProductPlaces {

	/**
	 * Product meta: list of location codes.
	 */
	public const META = '_lc_shipping_solo_a';

	/**
	 * Meta of Country Based Restrictions: countries and the type of the rule.
	 */
	public const LEGACY_COUNTRIES = '_restricted_countries';
	public const LEGACY_TYPE      = '_fz_country_restriction_type';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/shipping/only_to', array( self::class, 'only_to' ), 10, 2 );
		if ( is_admin() ) {
			Hooks::add_action( 'woocommerce_product_options_shipping_product_data', array( self::class, 'field' ) );
			Hooks::add_action( 'woocommerce_admin_process_product_object', array( self::class, 'save' ) );
		}
	}

	/**
	 * Places of a product, clean.
	 *
	 * @param int $product_id Product id.
	 * @return string[]
	 */
	public static function get( int $product_id ): array {
		return Restriction::places( get_post_meta( $product_id, self::META, true ) );
	}

	/**
	 * The product's places for the shipping rules.
	 *
	 * @param string[]|mixed $places     Current places.
	 * @param int|mixed      $product_id Product id.
	 * @return string[]
	 */
	public static function only_to( $places, $product_id ): array {
		$own = self::get( (int) $product_id );
		return $own ? $own : ( is_array( $places ) ? $places : array() );
	}

	/**
	 * Field in the Envío tab of the product.
	 */
	public static function field(): void {
		global $product_object;
		$id      = $product_object instanceof \WC_Product ? $product_object->get_id() : 0;
		$current = $id ? self::get( $id ) : array();
		wp_nonce_field( 'lachinata_shipping_places', 'lachinata_shipping_places_nonce' );
		echo '<p class="form-field"><label for="lc_solo_a">' . esc_html__( 'Solo se envía a', 'lachinata-core' ) . '</label>';
		echo '<select id="lc_solo_a" name="lc_solo_a[]" multiple class="wc-enhanced-select" style="width:50%" data-placeholder="' . esc_attr__( 'A todos los destinos de su clase', 'lachinata-core' ) . '">';
		foreach ( self::options() as $code => $label ) {
			printf( '<option value="%1$s"%2$s>%3$s</option>', esc_attr( $code ), selected( in_array( $code, $current, true ), true, false ), esc_html( $label ) );
		}
		echo '</select>';
		echo wc_help_tip( __( 'Restricción de este producto, además de la de su clase de envío. Vacío: sin restricción propia. Fuera de estos destinos no se puede comprar y la ficha lo avisa.', 'lachinata-core' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wc_help_tip() escapes.
		echo '</p>';
	}

	/**
	 * Countries and their states, as WooCommerce names them.
	 *
	 * @return array<string, string>
	 */
	private static function options(): array {
		$options = array();
		foreach ( WC()->countries->get_countries() as $code => $name ) {
			$options[ $code ] = html_entity_decode( (string) $name );
			$states           = WC()->countries->get_states( $code );
			foreach ( is_array( $states ) ? $states : array() as $state => $state_name ) {
				$options[ $code . ':' . $state ] = html_entity_decode( $name . ' — ' . $state_name );
			}
		}
		return $options;
	}

	/**
	 * Saves the field.
	 *
	 * @param \WC_Product $product Product being saved.
	 */
	public static function save( \WC_Product $product ): void {
		if ( ! isset( $_POST['lachinata_shipping_places_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['lachinata_shipping_places_nonce'] ) ), 'lachinata_shipping_places' ) ) {
			return;
		}
		$places = Restriction::places( isset( $_POST['lc_solo_a'] ) ? array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['lc_solo_a'] ) ) : array() );
		if ( $places ) {
			$product->update_meta_data( self::META, $places );
		} else {
			$product->delete_meta_data( self::META );
		}
	}

	/**
	 * Copies the per-product rules of Country Based Restrictions: «specific» (only these
	 * countries) to «Solo se envía a». Products that already have places are left as they
	 * are; «excluded» rules (all but these) are reported, not copied.
	 *
	 * @param bool $dry_run Report only.
	 * @return array{copied: int, problems: string[]}
	 */
	public static function migrate( bool $dry_run ): array {
		global $wpdb;
		$report = array(
			'copied'   => 0,
			'problems' => array(),
		);
		$ids    = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s", self::LEGACY_COUNTRIES ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- One-off migration.
		foreach ( array_map( 'intval', $ids ) as $id ) {
			$countries = Restriction::places( get_post_meta( $id, self::LEGACY_COUNTRIES, true ) );
			$type      = (string) get_post_meta( $id, self::LEGACY_TYPE, true );
			if ( ! $countries || 'all' === $type ) {
				continue;
			}
			if ( 'specific' !== $type ) {
				/* translators: 1: product id, 2: rule type, 3: countries. */
				$report['problems'][] = sprintf( __( '#%1$d regla «%2$s» (%3$s): solo se copian las de «solo estos países».', 'lachinata-core' ), $id, '' !== $type ? $type : '—', implode( ', ', $countries ) );
				continue;
			}
			if ( self::get( $id ) ) {
				continue;
			}
			++$report['copied'];
			if ( ! $dry_run ) {
				update_post_meta( $id, self::META, $countries );
			}
		}
		return $report;
	}
}
