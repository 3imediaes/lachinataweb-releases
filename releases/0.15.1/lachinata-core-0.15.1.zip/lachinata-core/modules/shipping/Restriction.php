<?php
/**
 * Product restriction by destination.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping;

defined( 'ABSPATH' ) || exit;

/**
 * Products of a shipping class, or with the international exclusion field, only ship to
 * the allowed places. Places are WooCommerce location codes: a country («DE») or a
 * country and state («ES:PM»). `except` removes places from `allowed` («ES» except
 * «ES:PM», «ES:GC»… is the Peninsula).
 */
final class Restriction {

	/**
	 * Source: the international exclusion field of the product (`_lc_excluir_internacional`).
	 */
	public const SOURCE_FLAG = 'flag';

	/**
	 * Prefix of a shipping class source: `class:<slug>`.
	 */
	public const SOURCE_CLASS = 'class:';

	/**
	 * Builds the restriction.
	 *
	 * @param string   $source  SOURCE_FLAG or `class:<slug>`.
	 * @param string[] $allowed Places products of the source ship to.
	 * @param string[] $except  Places taken out of `allowed`.
	 */
	public function __construct(
		public readonly string $source,
		public readonly array $allowed,
		public readonly array $except = array(),
	) {}

	/**
	 * Restriction from its stored form, or null when it is not valid.
	 *
	 * @param array<string, mixed> $data Stored restriction.
	 */
	public static function from_array( array $data ): ?self {
		$source = (string) ( $data['source'] ?? '' );
		if ( self::SOURCE_FLAG !== $source && ( ! str_starts_with( $source, self::SOURCE_CLASS ) || self::SOURCE_CLASS === $source ) ) {
			return null;
		}
		return new self( $source, self::places( $data['allowed'] ?? array() ), self::places( $data['except'] ?? array() ) );
	}

	/**
	 * Stored form.
	 *
	 * @return array{source: string, allowed: string[], except: string[]}
	 */
	public function to_array(): array {
		return array(
			'source'  => $this->source,
			'allowed' => $this->allowed,
			'except'  => $this->except,
		);
	}

	/**
	 * Shipping class slug of the source, or '' for the field.
	 */
	public function class_slug(): string {
		return str_starts_with( $this->source, self::SOURCE_CLASS ) ? substr( $this->source, strlen( self::SOURCE_CLASS ) ) : '';
	}

	/**
	 * Whether a product falls under the restriction.
	 *
	 * @param array{classes: string[], flag: bool, only?: string[]} $product Product entry of a Package.
	 */
	public function applies_to( array $product ): bool {
		return self::SOURCE_FLAG === $this->source ? $product['flag'] : in_array( $this->class_slug(), $product['classes'], true );
	}

	/**
	 * Whether the place is allowed.
	 *
	 * @param string $country Country code.
	 * @param string $state   State code, or ''.
	 */
	public function allows( string $country, string $state ): bool {
		$places = '' === $state ? array( $country ) : array( $country, $country . ':' . $state );
		return (bool) array_intersect( $places, $this->allowed ) && ! array_intersect( $places, $this->except );
	}

	/**
	 * The product's own restriction («Solo se envía a»), or null when it has none.
	 *
	 * @param array{only?: string[]} $product Product entry of a Package.
	 */
	public static function of_product( array $product ): ?self {
		$places = self::places( $product['only'] ?? array() );
		return $places ? new self( 'product', $places ) : null;
	}

	/**
	 * Restrictions that apply to a product: the configured ones that cover it and its own.
	 *
	 * @param array{classes: string[], flag: bool, only?: string[]} $product      Product entry of a Package.
	 * @param Restriction[]                                         $restrictions Configured restrictions.
	 * @return Restriction[]
	 */
	public static function for_product( array $product, array $restrictions ): array {
		$list = array_values( array_filter( $restrictions, static fn( self $restriction ): bool => $restriction->applies_to( $product ) ) );
		$own  = self::of_product( $product );
		return null === $own ? $list : array_merge( $list, array( $own ) );
	}

	/**
	 * Clean list of location codes.
	 *
	 * @param mixed $value Raw value.
	 * @return string[]
	 */
	public static function places( mixed $value ): array {
		$places = array();
		foreach ( (array) $value as $place ) {
			$place = strtoupper( trim( (string) $place ) );
			if ( 1 === preg_match( '/^[A-Z]{2}(:[A-Z0-9-]{1,10})?$/', $place ) ) {
				$places[] = $place;
			}
		}
		return array_values( array_unique( $places ) );
	}
}
