<?php
/**
 * WooCommerce → La Chinata → Envíos.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping;

use LaChinata\Core\Admin\Screen;
use LaChinata\Core\Hooks;
use LaChinata\Core\Modules\Shipping\Live\LiveOptions;
use LaChinata\Core\Modules\Shipping\Live\LiveRateMethod;
use LaChinata\Core\Modules\Shipping\Live\LiveRates;
use LaChinata\Core\Plugin;
use LaChinata\Core\Settings;
use LaChinata\Core\Shipping\Package;
use LaChinata\Core\Shipping\Destination;

defined( 'ABSPATH' ) || exit;

/**
 * Four sections: zones (limits, threshold, notice, messages, default zone), product
 * restrictions, configuration gaps and the simulator. Conditions per method are set in
 * each method of WooCommerce → Ajustes → Envío.
 */
final class ShippingTab {

	/**
	 * Tab id.
	 */
	public const TAB = 'shipping';

	/**
	 * Actions of admin-post.php, also nonce actions.
	 */
	private const SAVE_ZONES        = 'lachinata_shipping_zones';
	private const SAVE_RESTRICTIONS = 'lachinata_shipping_restrictions';
	private const CLEAR_GAPS        = 'lachinata_shipping_clear_gaps';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/core/admin_tabs', array( self::class, 'tab' ) );
		Hooks::add_filter( 'woocommerce_screen_ids', array( self::class, 'screen_ids' ) );
		Hooks::add_action( 'admin_post_' . self::SAVE_ZONES, array( self::class, 'save_zones' ) );
		Hooks::add_action( 'admin_post_' . self::SAVE_RESTRICTIONS, array( self::class, 'save_restrictions' ) );
		Hooks::add_action( 'admin_post_' . self::CLEAR_GAPS, array( self::class, 'clear_gaps' ) );
		WeightCheck::boot();
	}

	/**
	 * Adds the tab after Módulos.
	 *
	 * @param array<string, array{label: string, render: callable}> $tabs Tabs.
	 * @return array<string, array{label: string, render: callable}>
	 */
	public static function tab( array $tabs ): array {
		$tab = array(
			self::TAB => array(
				'label'  => __( 'Envíos', 'lachinata-core' ),
				'render' => array( self::class, 'render' ),
			),
		);
		return array_slice( $tabs, 0, 1, true ) + $tab + $tabs;
	}

	/**
	 * Loads WooCommerce's admin styles and select boxes on the La Chinata screen.
	 *
	 * @param string[] $ids Screen ids.
	 * @return string[]
	 */
	public static function screen_ids( array $ids ): array {
		$ids[] = 'woocommerce_page_' . Screen::SLUG;
		return $ids;
	}

	/**
	 * Sections of the tab.
	 *
	 * @return array<string, string>
	 */
	private static function sections(): array {
		return array(
			'zones'        => __( 'Zonas', 'lachinata-core' ),
			'restrictions' => __( 'Restricciones de producto', 'lachinata-core' ),
			'gaps'         => __( 'Huecos de configuración', 'lachinata-core' ),
			'simulator'    => __( 'Probador', 'lachinata-core' ),
		);
	}

	/**
	 * Prints the tab.
	 */
	public static function render(): void {
		$sections = self::sections();
		$current  = isset( $_GET['section'] ) ? sanitize_key( wp_unslash( $_GET['section'] ) ) : 'zones'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Navigation only.
		$current  = isset( $sections[ $current ] ) ? $current : 'zones';

		self::section_links( self::TAB, $sections, $current );
		echo '<p>' . wp_kses(
			sprintf(
				/* translators: %s: URL of WooCommerce shipping settings. */
				__( 'Las zonas y los métodos se crean en <a href="%s">WooCommerce → Ajustes → Envío</a>; cada método tiene allí sus condiciones (peso, importe, clases, prioridad y a quién oculta). Aquí van los límites y mensajes de cada zona, las restricciones de producto, los huecos y el probador.', 'lachinata-core' ),
				esc_url( admin_url( 'admin.php?page=wc-settings&tab=shipping' ) )
			),
			array( 'a' => array( 'href' => array() ) )
		) . '</p>';

		match ( $current ) {
			'restrictions' => self::render_restrictions(),
			'gaps'         => self::render_gaps(),
			'simulator'    => self::render_simulator(),
			default        => self::render_zones(),
		};
	}

	/**
	 * Links between the sections of a tab.
	 *
	 * @param string                $tab      Tab id.
	 * @param array<string, string> $sections Sections.
	 * @param string                $current  Current section.
	 */
	public static function section_links( string $tab, array $sections, string $current ): void {
		Screen::section_links( $tab, $sections, $current );
	}

	/**
	 * Zones section.
	 */
	private static function render_zones(): void {
		$module  = Plugin::instance()->modules()->get( 'shipping' );
		$default = Config::default_zone_id();
		$labels  = Messages::cause_labels();
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_ZONES ); ?>">
			<?php wp_nonce_field( self::SAVE_ZONES ); ?>
			<p class="description">
				<?php
				/* translators: %s: list of placeholders. */
				echo esc_html( sprintf( __( 'Los mensajes pueden usar %s. Vacío: el texto por defecto. Si una causa no tiene mensaje propio, se usa el mensaje genérico de la zona.', 'lachinata-core' ), implode( ' ', Messages::PLACEHOLDERS ) ) );
				?>
			</p>
			<?php foreach ( Config::zones() as $zone_id => $zone ) : ?>
				<?php
				$rules   = Config::zone_rules( $zone_id );
				$methods = $zone->get_shipping_methods();
				$prefix  = 'zones[' . $zone_id . ']';
				?>
				<div class="lc-admin__card">
					<h2>
						<?php echo esc_html( (string) $zone->get_zone_name() ); ?>
						<span class="lc-admin__muted">
							<?php
							/* translators: %d: zone id. */
							echo esc_html( sprintf( __( 'zona %d', 'lachinata-core' ), $zone_id ) );
							?>
						</span>
					</h2>
					<p class="lc-admin__muted">
						<?php echo esc_html( 0 === $zone_id ? __( 'Destinos que no están en ninguna otra zona.', 'lachinata-core' ) : wp_strip_all_tags( (string) $zone->get_formatted_location( 10 ) ) ); ?>
						—
						<?php
						$names = array();
						foreach ( $methods as $method ) {
							/* translators: 1: method title, 2: instance id. */
							$names[] = sprintf( __( '%1$s (ID %2$d)', 'lachinata-core' ), $method->get_title(), $method->get_instance_id() ) . ( $method->is_enabled() ? '' : ' ' . __( '[desactivado]', 'lachinata-core' ) );
						}
						echo esc_html( $names ? implode( ', ', $names ) : __( 'Sin métodos: la zona no está cubierta.', 'lachinata-core' ) );
						?>
					</p>
					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><?php esc_html_e( 'Zona por defecto', 'lachinata-core' ); ?></th>
							<td><label><input type="radio" name="default_zone" value="<?php echo esc_attr( (string) $zone_id ); ?>"<?php checked( $default, $zone_id ); ?>> <?php esc_html_e( 'Usar esta zona cuando no se conoce el destino del visitante (PromoBar, UspBar, ficha).', 'lachinata-core' ); ?></label></td>
						</tr>
						<tr>
							<th scope="row"><label for="lc-zone-<?php echo esc_attr( (string) $zone_id ); ?>-weight"><?php esc_html_e( 'Peso máximo (kg)', 'lachinata-core' ); ?></label></th>
							<td><input type="number" min="0" step="any" class="small-text" id="lc-zone-<?php echo esc_attr( (string) $zone_id ); ?>-weight" name="<?php echo esc_attr( $prefix ); ?>[max_weight]" value="<?php echo esc_attr( null === $rules->max_weight ? '' : (string) $rules->max_weight ); ?>"> <span class="description"><?php esc_html_e( 'Incluido. Por encima, ningún método de la zona se ofrece (causa «peso_max»).', 'lachinata-core' ); ?></span></td>
						</tr>
						<tr>
							<th scope="row"><label for="lc-zone-<?php echo esc_attr( (string) $zone_id ); ?>-threshold"><?php esc_html_e( 'Umbral de envío gratis', 'lachinata-core' ); ?></label></th>
							<td><input type="number" min="0" step="any" class="small-text" id="lc-zone-<?php echo esc_attr( (string) $zone_id ); ?>-threshold" name="<?php echo esc_attr( $prefix ); ?>[free_threshold]" value="<?php echo esc_attr( null === $rules->free_threshold ? '' : (string) $rules->free_threshold ); ?>"> <?php echo esc_html( html_entity_decode( get_woocommerce_currency_symbol() ) ); ?> <span class="description"><?php esc_html_e( 'Lo anuncian la PromoBar, la UspBar ({envio_gratis}) y la bolsa, y lo usan los métodos con «Umbral de envío gratis de la zona».', 'lachinata-core' ); ?></span></td>
						</tr>
						<tr>
							<th scope="row"><label for="lc-zone-<?php echo esc_attr( (string) $zone_id ); ?>-notice"><?php esc_html_e( 'Aviso informativo', 'lachinata-core' ); ?></label></th>
							<td><input type="text" class="large-text" id="lc-zone-<?php echo esc_attr( (string) $zone_id ); ?>-notice" name="<?php echo esc_attr( $prefix ); ?>[notice]" value="<?php echo esc_attr( $rules->notice ); ?>"><p class="description"><?php esc_html_e( 'Se muestra en la bolsa a quien envía a esta zona.', 'lachinata-core' ); ?></p></td>
						</tr>
					</table>
					<details class="lc-admin__details"<?php echo array_filter( $rules->messages ) ? ' open' : ''; ?>>
						<summary><?php esc_html_e( 'Mensajes cuando no hay envío', 'lachinata-core' ); ?></summary>
						<table class="form-table" role="presentation">
						<?php foreach ( ZoneRules::CAUSES as $cause ) : ?>
							<tr>
								<th scope="row"><label for="lc-zone-<?php echo esc_attr( $zone_id . '-' . $cause ); ?>"><?php echo esc_html( $labels[ $cause ] ); ?></label><br><code><?php echo esc_html( $cause ); ?></code></th>
								<td><textarea class="large-text" rows="2" id="lc-zone-<?php echo esc_attr( $zone_id . '-' . $cause ); ?>" name="<?php echo esc_attr( $prefix ); ?>[messages][<?php echo esc_attr( $cause ); ?>]"><?php echo esc_textarea( $rules->message( $cause ) ); ?></textarea></td>
							</tr>
						<?php endforeach; ?>
						</table>
					</details>
				</div>
			<?php endforeach; ?>
			<?php if ( null !== $module ) : ?>
				<p class="description">
					<?php
					/* translators: %s: option name. */
					echo esc_html( sprintf( __( 'La zona por defecto se guarda en %s.', 'lachinata-core' ), Settings::option( $module, 'default_zone' ) ) );
					?>
				</p>
			<?php endif; ?>
			<?php submit_button( __( 'Guardar zonas', 'lachinata-core' ) ); ?>
		</form>
		<?php
	}

	/**
	 * Saves the zones section.
	 */
	public static function save_zones(): void {
		Screen::check( self::SAVE_ZONES );
		$posted = isset( $_POST['zones'] ) && is_array( $_POST['zones'] ) ? wp_unslash( $_POST['zones'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.NonceVerification.Missing -- Screen::check(); sanitised below.
		$known  = array_keys( Config::zones() );
		$rules  = array();
		foreach ( $posted as $zone_id => $data ) {
			if ( ! in_array( (int) $zone_id, $known, true ) || ! is_array( $data ) ) {
				continue;
			}
			$messages = array();
			foreach ( ZoneRules::CAUSES as $cause ) {
				$messages[ $cause ] = sanitize_textarea_field( (string) ( $data['messages'][ $cause ] ?? '' ) );
			}
			$rules[] = ZoneRules::from_array(
				(int) $zone_id,
				array(
					'max_weight'     => sanitize_text_field( (string) ( $data['max_weight'] ?? '' ) ),
					'free_threshold' => sanitize_text_field( (string) ( $data['free_threshold'] ?? '' ) ),
					'notice'         => sanitize_text_field( (string) ( $data['notice'] ?? '' ) ),
					'messages'       => $messages,
				)
			);
		}
		Config::save_zone_rules( $rules );

		$module = Plugin::instance()->modules()->get( 'shipping' );
		if ( null !== $module && isset( $_POST['default_zone'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Screen::check().
			Settings::set( $module, 'default_zone', absint( $_POST['default_zone'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Screen::check().
		}
		Screen::flash( 'success', array( __( 'Zonas guardadas.', 'lachinata-core' ) ) );
		Screen::redirect( self::TAB, array( 'section' => 'zones' ) );
	}

	/**
	 * Restrictions section.
	 */
	private static function render_restrictions(): void {
		$restrictions = Config::restrictions();
		$sources      = array( Restriction::SOURCE_FLAG => __( 'Campo «Exclusión internacional» del producto', 'lachinata-core' ) );
		foreach ( InstanceFields::class_options() as $slug => $name ) {
			/* translators: %s: shipping class name. */
			$sources[ Restriction::SOURCE_CLASS . $slug ] = sprintf( __( 'Clase de envío «%s»', 'lachinata-core' ), $name );
		}
		$places = self::place_options();
		$rows   = array_merge( $restrictions, array( null ) );
		?>
		<p><?php esc_html_e( 'Los productos de cada origen solo se envían a los destinos permitidos (menos las excepciones). Si un pedido lleva uno a otro destino, no hay envío y la causa es «producto_restringido». La misma lista decidirá qué se ve en el catálogo de cada destino.', 'lachinata-core' ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_RESTRICTIONS ); ?>">
			<?php wp_nonce_field( self::SAVE_RESTRICTIONS ); ?>
			<table class="widefat striped lc-admin__restrictions">
				<thead>
					<tr>
						<th scope="col"><?php esc_html_e( 'Origen', 'lachinata-core' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Solo se envía a', 'lachinata-core' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Excepto', 'lachinata-core' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Quitar', 'lachinata-core' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $rows as $index => $restriction ) : ?>
						<tr>
							<td>
								<select name="restrictions[<?php echo esc_attr( (string) $index ); ?>][source]" aria-label="<?php esc_attr_e( 'Origen', 'lachinata-core' ); ?>">
									<?php if ( null === $restriction ) : ?>
										<option value=""><?php esc_html_e( 'Añadir una restricción…', 'lachinata-core' ); ?></option>
									<?php endif; ?>
									<?php foreach ( $sources as $value => $label ) : ?>
										<option value="<?php echo esc_attr( $value ); ?>"<?php selected( null !== $restriction && $restriction->source === $value ); ?>><?php echo esc_html( $label ); ?></option>
									<?php endforeach; ?>
								</select>
							</td>
							<?php foreach ( array( 'allowed', 'except' ) as $key ) : ?>
								<td>
									<select multiple class="wc-enhanced-select" style="width:100%" name="restrictions[<?php echo esc_attr( (string) $index ); ?>][<?php echo esc_attr( $key ); ?>][]" aria-label="<?php echo esc_attr( 'allowed' === $key ? __( 'Solo se envía a', 'lachinata-core' ) : __( 'Excepto', 'lachinata-core' ) ); ?>">
										<?php
										$chosen = null === $restriction ? array() : $restriction->{$key};
										foreach ( $places as $code => $label ) {
											printf( '<option value="%1$s"%2$s>%3$s</option>', esc_attr( $code ), selected( in_array( $code, $chosen, true ), true, false ), esc_html( $label ) );
										}
										?>
									</select>
								</td>
							<?php endforeach; ?>
							<td>
							<?php
							if ( null !== $restriction ) :
								?>
								<input type="checkbox" name="restrictions[<?php echo esc_attr( (string) $index ); ?>][delete]" value="1" aria-label="<?php esc_attr_e( 'Quitar', 'lachinata-core' ); ?>"><?php endif; ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<p class="description"><?php esc_html_e( 'Además, cada producto puede tener su propia lista en la pestaña Envío de su ficha («Solo se envía a»).', 'lachinata-core' ); ?></p>
			<h2><label for="lc-unavailable-text"><?php esc_html_e( 'Aviso en la ficha', 'lachinata-core' ); ?></label></h2>
			<p class="description"><?php esc_html_e( 'Lo que lee, encima del título del producto, quien visita la ficha desde un destino al que no se envía (lo pinta el módulo Destino). Vacío: «Lo sentimos, este producto no está disponible en tu país.».', 'lachinata-core' ); ?></p>
			<p><textarea class="large-text" rows="2" id="lc-unavailable-text" name="unavailable_text"><?php echo esc_textarea( Config::unavailable_text() ); ?></textarea></p>
			<?php submit_button( __( 'Guardar restricciones', 'lachinata-core' ) ); ?>
		</form>
		<?php
	}

	/**
	 * Saves the restrictions.
	 */
	public static function save_restrictions(): void {
		Screen::check( self::SAVE_RESTRICTIONS );
		$posted = isset( $_POST['restrictions'] ) && is_array( $_POST['restrictions'] ) ? wp_unslash( $_POST['restrictions'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.NonceVerification.Missing -- Screen::check(); sanitised by Restriction::from_array().
		$list   = array();
		foreach ( $posted as $row ) {
			if ( ! is_array( $row ) || ! empty( $row['delete'] ) ) {
				continue;
			}
			$restriction = Restriction::from_array(
				array(
					'source'  => sanitize_text_field( (string) ( $row['source'] ?? '' ) ),
					'allowed' => array_map( 'sanitize_text_field', (array) ( $row['allowed'] ?? array() ) ),
					'except'  => array_map( 'sanitize_text_field', (array) ( $row['except'] ?? array() ) ),
				)
			);
			if ( null !== $restriction ) {
				$list[] = $restriction;
			}
		}
		Config::save_restrictions( $list );
		$module = Plugin::instance()->modules()->get( 'shipping' );
		if ( null !== $module ) {
			Settings::set( $module, 'unavailable_text', sanitize_textarea_field( wp_unslash( (string) ( $_POST['unavailable_text'] ?? '' ) ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Screen::check().
		}
		Screen::flash( 'success', array( __( 'Restricciones guardadas.', 'lachinata-core' ) ) );
		Screen::redirect( self::TAB, array( 'section' => 'restrictions' ) );
	}

	/**
	 * Gaps section: what the configuration does not cover.
	 */
	private static function render_gaps(): void {
		$static = self::static_gaps();
		$weight = WeightCheck::missing_ids();
		$log    = Rates::gaps()->all();
		?>
		<h2><?php esc_html_e( 'Revisión de la configuración', 'lachinata-core' ); ?></h2>
		<?php if ( $static ) : ?>
			<ul class="ul-disc">
				<?php foreach ( $static as $line ) : ?>
					<li><?php echo esc_html( $line ); ?></li>
				<?php endforeach; ?>
			</ul>
		<?php else : ?>
			<p><?php esc_html_e( 'Sin problemas en la configuración de zonas y métodos.', 'lachinata-core' ); ?></p>
		<?php endif; ?>

		<h2><?php esc_html_e( 'Productos sin peso', 'lachinata-core' ); ?></h2>
		<p>
			<?php
			if ( $weight ) {
				printf(
					'%1$s <a href="%2$s">%3$s</a>',
					esc_html(
						sprintf(
							/* translators: %s: number of products. */
							_n( '%s producto se envía sin peso y cuenta como 0 kg en las condiciones.', '%s productos se envían sin peso y cuentan como 0 kg en las condiciones.', count( $weight ), 'lachinata-core' ),
							number_format_i18n( count( $weight ) )
						)
					),
					esc_url( WeightCheck::list_url() ),
					esc_html__( 'Ver la lista para corregirlos', 'lachinata-core' )
				);
			} else {
				esc_html_e( 'Todos los productos con envío tienen peso.', 'lachinata-core' );
			}
			?>
		</p>

		<h2><?php esc_html_e( 'Pedidos sin envío y tarifas en vivo que no llegaron', 'lachinata-core' ); ?></h2>
		<p class="description"><?php esc_html_e( 'Carritos que no recibieron ningún método sin una causa conocida (peso, importe, producto o zona; el cliente ve el mensaje genérico de la zona) y proveedores de tarifa en vivo que no encontraron la tarifa del método configurado, con los IDs de tarifa que sí había en el paquete. Se registran también en WooCommerce → Estado → Registros (lachinata-shipping).', 'lachinata-core' ); ?></p>
		<?php if ( $log ) : ?>
			<table class="widefat striped">
				<thead>
					<tr>
						<th scope="col"><?php esc_html_e( 'Qué pasó', 'lachinata-core' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Datos', 'lachinata-core' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Veces', 'lachinata-core' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Última', 'lachinata-core' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $log as $entry ) : ?>
						<tr>
							<td><?php echo esc_html( $entry['message'] ); ?></td>
							<td><?php echo esc_html( Screen::format_value( $entry['context'] ) ); ?></td>
							<td><?php echo esc_html( number_format_i18n( $entry['count'] ) ); ?></td>
							<td><?php echo esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $entry['last'] ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::CLEAR_GAPS ); ?>">
				<?php wp_nonce_field( self::CLEAR_GAPS ); ?>
				<?php submit_button( __( 'Vaciar la lista', 'lachinata-core' ), 'secondary' ); ?>
			</form>
		<?php else : ?>
			<p><?php esc_html_e( 'Ninguno registrado.', 'lachinata-core' ); ?></p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Problems visible from the configuration alone.
	 *
	 * @return string[]
	 */
	public static function static_gaps(): array {
		$lines = array();
		foreach ( ConflictNotice::active() as $name ) {
			/* translators: %s: plugin name. */
			$lines[] = sprintf( __( 'El plugin «%s» sigue activo y hace el mismo trabajo.', 'lachinata-core' ), $name );
		}
		foreach ( Config::zones() as $zone_id => $zone ) {
			$rules = Config::zone_rules( $zone_id );
			foreach ( $zone->get_shipping_methods( true ) as $method ) {
				$settings   = Config::instance_settings( $method );
				$conditions = Conditions::from_settings( $settings );
				if ( Conditions::ZONE_THRESHOLD === $conditions->amount_min && null === $rules->free_threshold ) {
					/* translators: 1: method title, 2: instance id, 3: zone name. */
					$lines[] = sprintf( __( '%1$s (ID %2$d) usa el umbral de envío gratis de la zona «%3$s», que no tiene umbral: nunca se ofrece.', 'lachinata-core' ), $method->get_title(), $method->get_instance_id(), $zone->get_zone_name() );
				}
				if ( LiveRateMethod::ID === $method->id && null === LiveRates::provider( LiveOptions::from_settings( $settings )->provider ) ) {
					/* translators: 1: method title, 2: instance id. */
					$lines[] = sprintf( __( '%1$s (ID %2$d) no tiene un proveedor de tarifas disponible.', 'lachinata-core' ), $method->get_title(), $method->get_instance_id() );
				}
				foreach ( $conditions->hides as $hidden ) {
					if ( ! isset( $zone->get_shipping_methods()[ $hidden ] ) ) {
						/* translators: 1: method title, 2: instance id, 3: hidden instance id. */
						$lines[] = sprintf( __( '%1$s (ID %2$d) oculta el ID %3$d, que no está en su zona: no tiene efecto.', 'lachinata-core' ), $method->get_title(), $method->get_instance_id(), $hidden );
					}
				}
			}
		}
		return $lines;
	}

	/**
	 * Forgets the gap log.
	 */
	public static function clear_gaps(): void {
		Screen::check( self::CLEAR_GAPS );
		Rates::gaps()->clear();
		Screen::flash( 'success', array( __( 'Lista vaciada.', 'lachinata-core' ) ) );
		Screen::redirect( self::TAB, array( 'section' => 'gaps' ) );
	}

	/**
	 * Simulator section (a GET form: the result can be linked).
	 */
	private static function render_simulator(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only simulation.
		$place   = isset( $_GET['sim_place'] ) ? sanitize_text_field( wp_unslash( $_GET['sim_place'] ) ) : '';
		$post    = isset( $_GET['sim_postcode'] ) ? sanitize_text_field( wp_unslash( $_GET['sim_postcode'] ) ) : '';
		$weight  = isset( $_GET['sim_weight'] ) ? (float) str_replace( ',', '.', sanitize_text_field( wp_unslash( $_GET['sim_weight'] ) ) ) : 1.0;
		$amount  = isset( $_GET['sim_amount'] ) ? (float) str_replace( ',', '.', sanitize_text_field( wp_unslash( $_GET['sim_amount'] ) ) ) : 30.0;
		$classes = isset( $_GET['sim_classes'] ) ? array_map( 'sanitize_title', (array) wp_unslash( $_GET['sim_classes'] ) ) : array();
		$flag    = ! empty( $_GET['sim_flag'] );
		// phpcs:enable
		$places = self::place_options();
		?>
		<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="lc-admin__card">
			<input type="hidden" name="page" value="<?php echo esc_attr( Screen::SLUG ); ?>">
			<input type="hidden" name="tab" value="<?php echo esc_attr( self::TAB ); ?>">
			<input type="hidden" name="section" value="simulator">
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="lc-sim-place"><?php esc_html_e( 'Destino', 'lachinata-core' ); ?></label></th>
					<td>
						<select id="lc-sim-place" name="sim_place" class="wc-enhanced-select" style="min-width:20em">
							<?php foreach ( $places as $code => $label ) : ?>
								<option value="<?php echo esc_attr( $code ); ?>"<?php selected( $place, $code ); ?>><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
						<input type="text" name="sim_postcode" class="small-text" value="<?php echo esc_attr( $post ); ?>" placeholder="<?php esc_attr_e( 'CP', 'lachinata-core' ); ?>" aria-label="<?php esc_attr_e( 'Código postal', 'lachinata-core' ); ?>">
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="lc-sim-weight"><?php esc_html_e( 'Peso (kg)', 'lachinata-core' ); ?></label></th>
					<td><input type="number" min="0" step="any" id="lc-sim-weight" name="sim_weight" class="small-text" value="<?php echo esc_attr( (string) $weight ); ?>"></td>
				</tr>
				<tr>
					<th scope="row"><label for="lc-sim-amount"><?php esc_html_e( 'Importe', 'lachinata-core' ); ?></label></th>
					<td><input type="number" min="0" step="any" id="lc-sim-amount" name="sim_amount" class="small-text" value="<?php echo esc_attr( (string) $amount ); ?>"> <span class="description"><?php esc_html_e( 'Subtotal de productos con impuestos, después de descuentos.', 'lachinata-core' ); ?></span></td>
				</tr>
				<tr>
					<th scope="row"><label for="lc-sim-classes"><?php esc_html_e( 'Clases de envío', 'lachinata-core' ); ?></label></th>
					<td>
						<select multiple id="lc-sim-classes" name="sim_classes[]" class="wc-enhanced-select" style="min-width:20em">
							<?php foreach ( InstanceFields::class_options() as $slug => $name ) : ?>
								<option value="<?php echo esc_attr( $slug ); ?>"<?php selected( in_array( $slug, $classes, true ) ); ?>><?php echo esc_html( $name ); ?></option>
							<?php endforeach; ?>
						</select>
						<label class="lc-admin__check"><input type="checkbox" name="sim_flag" value="1"<?php checked( $flag ); ?>> <?php esc_html_e( 'Lleva un producto con exclusión internacional', 'lachinata-core' ); ?></label>
					</td>
				</tr>
			</table>
			<?php submit_button( __( 'Probar', 'lachinata-core' ), 'primary', '', false ); ?>
		</form>
		<?php
		if ( '' === $place ) {
			return;
		}
		$destination = Destination::parse( $place );
		if ( null === $destination ) {
			return;
		}
		self::render_result(
			Simulator::run(
				array(
					'country'  => $destination['country'],
					'state'    => $destination['state'],
					'postcode' => $post,
					'weight'   => $weight,
					'amount'   => $amount,
					'classes'  => $classes,
					'flag'     => $flag,
				)
			)
		);
	}

	/**
	 * Result of a simulation.
	 *
	 * @param array{package: Package, zone: \WC_Shipping_Zone, rules: ZoneRules, decision: Decision, candidates: Candidate[], message: string, eta: array<int, string>} $result Result.
	 */
	private static function render_result( array $result ): void {
		$decision = $result['decision'];
		?>
		<h2>
			<?php
			/* translators: 1: zone name, 2: zone id. */
			echo esc_html( sprintf( __( 'Zona: %1$s (zona %2$d)', 'lachinata-core' ), $result['zone']->get_zone_name(), $result['zone']->get_id() ) );
			?>
		</h2>
		<?php if ( null !== $decision->cause ) : ?>
			<div class="notice notice-error inline"><p><strong><code><?php echo esc_html( $decision->cause ); ?></code></strong> — <?php echo esc_html( $result['message'] ); ?></p></div>
		<?php endif; ?>
		<?php if ( '' !== $result['rules']->notice ) : ?>
			<div class="notice notice-info inline"><p><?php echo esc_html( $result['rules']->notice ); ?></p></div>
		<?php endif; ?>
		<table class="widefat striped">
			<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'Método', 'lachinata-core' ); ?></th>
					<th scope="col"><?php esc_html_e( 'ID', 'lachinata-core' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Resultado', 'lachinata-core' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Entrega estimada', 'lachinata-core' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $result['candidates'] as $candidate ) : ?>
					<?php
					$id      = $candidate->instance_id;
					$offered = $decision->offers( $id );
					$reasons = array_map( array( Simulator::class, 'reason_label' ), $decision->rejected[ $id ] ?? array() );
					if ( $offered ) {
						/* translators: %d: position in the list. */
						$text = sprintf( __( 'Se ofrece (posición %d)', 'lachinata-core' ), array_search( $id, $decision->offered, true ) + 1 );
					} elseif ( $reasons ) {
						/* translators: %s: reasons. */
						$text = sprintf( __( 'No se ofrece: %s', 'lachinata-core' ), implode( ', ', $reasons ) );
					} else {
						$text = __( 'No se ofrece: el pedido no se puede enviar a la zona', 'lachinata-core' );
					}
					?>
					<tr>
						<td><?php echo esc_html( $candidate->title ); ?></td>
						<td><?php echo esc_html( (string) $id ); ?></td>
						<td><?php echo $offered ? '<strong>' . esc_html( $text ) . '</strong>' : esc_html( $text ); ?></td>
						<td><?php echo esc_html( $result['eta'][ $id ] ?? '' ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<p class="description"><?php esc_html_e( 'El probador aplica las condiciones de La Chinata. El precio y las condiciones propias de cada método de WooCommerce (por ejemplo, el mínimo de un envío gratuito) se ven al probar la bolsa.', 'lachinata-core' ); ?></p>
		<?php
	}

	/**
	 * Countries the store ships to and their states, as location codes.
	 *
	 * @return array<string, string>
	 */
	public static function place_options(): array {
		$countries = WC()->countries;
		$options   = array();
		foreach ( $countries->get_shipping_countries() as $code => $name ) {
			$name             = html_entity_decode( (string) $name );
			$options[ $code ] = $name;
			$states           = $countries->get_states( $code );
			foreach ( is_array( $states ) ? $states : array() as $state => $state_name ) {
				$options[ $code . ':' . $state ] = $name . ' — ' . html_entity_decode( (string) $state_name );
			}
		}
		return $options;
	}
}
