<?php
/**
 * WP-CLI: wp lachinata shipping simulate.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping;

use WP_CLI;
use LaChinata\Core\Shipping\Destination;

defined( 'ABSPATH' ) || exit;

/**
 * The simulator of La Chinata → Envíos from the command line.
 */
final class SimulateCommand {

	/**
	 * Shows which methods a package gets, or why it gets none.
	 *
	 * ## OPTIONS
	 *
	 * --to=<place>
	 * : Destination: country («DE») or country and state («ES:PM»).
	 *
	 * [--postcode=<postcode>]
	 * : Postcode.
	 *
	 * [--weight=<kg>]
	 * : Weight in kg.
	 * ---
	 * default: 1
	 * ---
	 *
	 * [--amount=<amount>]
	 * : Product subtotal with tax, after discounts.
	 * ---
	 * default: 30
	 * ---
	 *
	 * [--classes=<slugs>]
	 * : Shipping class slugs, separated by commas.
	 *
	 * [--flag]
	 * : The package carries a product with the international exclusion field.
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata shipping simulate --to=DE --weight=30 --amount=120
	 *     wp lachinata shipping simulate --to=ES:M --classes=frio --amount=70
	 *
	 * @param string[]             $args       Positional arguments.
	 * @param array<string, mixed> $assoc_args Named arguments.
	 */
	public function simulate( array $args, array $assoc_args ): void {
		$destination = Destination::parse( (string) ( $assoc_args['to'] ?? '' ) );
		if ( null === $destination ) {
			WP_CLI::error( 'Destino no válido: usa «DE» o «ES:PM».' );
		}
		$result = Simulator::run(
			array(
				'country'  => $destination['country'],
				'state'    => $destination['state'],
				'postcode' => (string) ( $assoc_args['postcode'] ?? '' ),
				'weight'   => (float) str_replace( ',', '.', (string) ( $assoc_args['weight'] ?? 1 ) ),
				'amount'   => (float) str_replace( ',', '.', (string) ( $assoc_args['amount'] ?? 30 ) ),
				'classes'  => array_filter( array_map( 'trim', explode( ',', (string) ( $assoc_args['classes'] ?? '' ) ) ) ),
				'flag'     => (bool) WP_CLI\Utils\get_flag_value( $assoc_args, 'flag', false ),
			)
		);

		$decision = $result['decision'];
		WP_CLI::log( sprintf( 'Zona: %1$s (%2$d)', $result['zone']->get_zone_name(), $result['zone']->get_id() ) );
		$rows = array();
		foreach ( $result['candidates'] as $candidate ) {
			$id     = $candidate->instance_id;
			$rows[] = array(
				'id'        => $id,
				'metodo'    => $candidate->title,
				'resultado' => $decision->offers( $id )
					? 'ofrecido #' . ( (int) array_search( $id, $decision->offered, true ) + 1 )
					: implode( ', ', array_map( array( Simulator::class, 'reason_label' ), $decision->rejected[ $id ] ?? array( 'zona' ) ) ),
				'entrega'   => $result['eta'][ $id ] ?? '',
			);
		}
		if ( $rows ) {
			WP_CLI\Utils\format_items( 'table', $rows, array( 'id', 'metodo', 'resultado', 'entrega' ) );
		}
		if ( null !== $decision->cause ) {
			WP_CLI::warning( sprintf( '%1$s: %2$s', $decision->cause, $result['message'] ) );
		} else {
			WP_CLI::success( sprintf( 'Ofrecidos: %s', implode( ', ', $decision->offered ) ) );
		}
	}

	/**
	 * Copies the per-product rules of Country Based Restrictions (`_restricted_countries`
	 * with «solo estos países») to «Solo se envía a». Idempotent: products that already
	 * have places are left as they are.
	 *
	 * ## OPTIONS
	 *
	 * [--dry-run]
	 * : Report only.
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata shipping migrate-restrictions --dry-run
	 *
	 * @subcommand migrate-restrictions
	 *
	 * @param string[]             $args       Positional arguments.
	 * @param array<string, mixed> $assoc_args Named arguments.
	 */
	public function migrate_restrictions( array $args, array $assoc_args ): void {
		$dry_run = (bool) WP_CLI\Utils\get_flag_value( $assoc_args, 'dry-run', false );
		$report  = ProductPlaces::migrate( $dry_run );
		foreach ( $report['problems'] as $line ) {
			WP_CLI::warning( $line );
		}
		WP_CLI::success( sprintf( '%1$s: %2$d productos con «Solo se envía a».', $dry_run ? 'Simulación' : 'Copiado', $report['copied'] ) );
	}
}
