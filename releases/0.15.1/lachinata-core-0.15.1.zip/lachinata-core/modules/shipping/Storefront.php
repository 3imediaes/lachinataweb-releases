<?php
/**
 * Fills the theme hooks with the shipping data.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping;

use LaChinata\Core\Hooks;
use LaChinata\Core\Shipping\Package;
use LaChinata\Core\Shipping\Destination;

defined( 'ABSPATH' ) || exit;

/**
 * Free shipping threshold in the PromoBar and the UspBar, notices of the bag, a note on
 * lines that cannot ship and the shipping line of the bag summary.
 */
final class Storefront {

	/**
	 * Placeholder replaced by the free shipping threshold in menu texts.
	 */
	public const THRESHOLD_PLACEHOLDER = '{envio_gratis}';

	/**
	 * Placeholder replaced by the visitor's destination in the texts that use the threshold.
	 */
	public const DESTINATION_PLACEHOLDER = '{destino}';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/promo_bar/messages', array( self::class, 'promo_messages' ) );
		Hooks::add_filter( 'lachinata/usp/items', array( self::class, 'usp_items' ) );
		Hooks::add_action( 'lachinata/cart/notices', array( self::class, 'cart_notices' ) );
		Hooks::add_filter( 'lachinata/cart/line_note', array( self::class, 'line_note' ), 10, 2 );
		Hooks::add_filter( 'lachinata/cart/shipping_summary', array( self::class, 'shipping_summary' ), 10, 2 );
	}

	/**
	 * Adds «Envío gratis a Portugal desde 60 €» to the PromoBar (short, «Envío gratis desde
	 * 60 €», next to the destination badge), unless a menu item already uses the placeholder,
	 * which is then filled in. Without free shipping to the visitor's destination, the
	 * message goes.
	 *
	 * @param array<int, array{title: string, url: string, icon: string}> $messages Messages.
	 * @return array<int, array<string, mixed>>
	 */
	public static function promo_messages( array $messages ): array {
		$has_token = (bool) array_filter( $messages, static fn( array $m ): bool => str_contains( (string) $m['title'], self::THRESHOLD_PLACEHOLDER ) );
		if ( ! $has_token ) {
			array_unshift(
				$messages,
				array(
					/* translators: 1: destination («Portugal»), 2: free shipping threshold with currency. */
					'title' => sprintf( __( 'Envío gratis a %1$s desde %2$s', 'lachinata-core' ), self::DESTINATION_PLACEHOLDER, self::THRESHOLD_PLACEHOLDER ),
					/* translators: %s: free shipping threshold with currency. Shown next to the destination badge, which already says where. */
					'short' => sprintf( __( 'Envío gratis desde %s', 'lachinata-core' ), self::THRESHOLD_PLACEHOLDER ),
					'url'   => '',
					'icon'  => 'truck',
				)
			);
		}
		return self::fill( $messages, array( 'title', 'short' ), array() );
	}

	/**
	 * Fills the placeholders in the UspBar texts. Without free shipping to the visitor's
	 * destination, the item says where it ships, without an amount.
	 *
	 * @param array<int, array{title: string, text?: string, icon?: string}> $items Items.
	 * @return array<int, array<string, mixed>>
	 */
	public static function usp_items( array $items ): array {
		return self::fill(
			$items,
			array( 'title', 'text' ),
			array(
				/* translators: %s: destination («Alemania»). */
				'title' => sprintf( __( 'Envío a %s', 'lachinata-core' ), self::DESTINATION_PLACEHOLDER ),
				'text'  => __( 'Gastos calculados en la bolsa', 'lachinata-core' ),
			)
		);
	}

	/**
	 * Replaces the placeholders in the given keys with the visitor's destination and its
	 * threshold; without threshold, an item that uses it takes `$without` or, empty, goes.
	 * The item carries both templates (`data-lc-free`), so a page that is the same for
	 * every visitor is completed in the browser (`locale`).
	 *
	 * @param array<int, array<string, mixed>> $items   Items.
	 * @param string[]                         $keys    Keys with text.
	 * @param array<string, string>            $without Texts without free shipping, by key.
	 * @return array<int, array<string, mixed>>
	 */
	private static function fill( array $items, array $keys, array $without ): array {
		$destination = Destination::visitor();
		$threshold   = Config::threshold_for( $destination );
		$label       = self::destination_label( $destination );
		$filled      = array();
		foreach ( $items as $item ) {
			$with = array();
			foreach ( $keys as $key ) {
				$with[ $key ] = (string) ( $item[ $key ] ?? '' );
			}
			if ( ! array_filter( $with, static fn( string $text ): bool => str_contains( $text, self::THRESHOLD_PLACEHOLDER ) ) ) {
				$filled[] = $item;
				continue;
			}
			$texts = null === $threshold ? $without : $with;
			if ( ! $texts ) {
				continue;
			}
			foreach ( $keys as $key ) {
				$item[ $key ] = self::compose( $texts[ $key ] ?? '', $label, $threshold );
			}
			$item['attrs']                 = (array) ( $item['attrs'] ?? array() );
			$item['attrs']['data-lc-free'] = (string) wp_json_encode(
				array(
					'with'    => $with,
					'without' => $without ? $without : null,
				)
			);
			$filled[]                      = $item;
		}
		return $filled;
	}

	/**
	 * A text with the destination and the threshold.
	 *
	 * @param string     $text      Text with placeholders.
	 * @param string     $label     Destination.
	 * @param float|null $threshold Threshold.
	 */
	private static function compose( string $text, string $label, ?float $threshold ): string {
		return str_replace(
			array( self::DESTINATION_PLACEHOLDER, self::THRESHOLD_PLACEHOLDER ),
			array( $label, null === $threshold ? '' : self::plain_price( $threshold ) ),
			$text
		);
	}

	/**
	 * Name of the visitor's destination in the PromoBar and the UspBar.
	 *
	 * @param array{country: string, state: string, postcode: string} $destination Destination.
	 */
	public static function destination_label( array $destination ): string {
		$name = Destination::name( $destination['country'], $destination['state'], Config::zone_for( $destination ) );
		/**
		 * Name of a destination in the free shipping texts («Portugal»).
		 *
		 * @since 0.11.0
		 *
		 * @param string                                                 $name        Country or region of WooCommerce.
		 * @param array{country: string, state: string, postcode: string} $destination Destination.
		 */
		return (string) apply_filters( 'lachinata/shipping/destination_label', $name, $destination );
	}

	/**
	 * What the customer needs to know about the shipping of the bag: the zone notice, the
	 * cause when nothing ships (with the products that cannot travel) and how much is left
	 * for free shipping. The bag prints it as notices; the checkout reads it from the Store
	 * API (StoreApi).
	 *
	 * @return array{notice: string, cause: string|null, message: string, restricted: array<int, string>, free: array{tone: string, text: string}|null}
	 */
	public static function state(): array {
		$state = array(
			'notice'     => '',
			'cause'      => null,
			'message'    => '',
			'restricted' => array(),
			'free'       => null,
		);
		$cart  = WC()->cart;
		if ( ! $cart instanceof \WC_Cart || $cart->is_empty() || ! $cart->needs_shipping() ) {
			return $state;
		}
		$destination     = Destination::customer() ?? Destination::visitor();
		$zone            = Config::zone_for( $destination );
		$rules           = Config::zone_rules( (int) $zone->get_id() );
		$state['notice'] = $rules->notice;

		$cause = Rates::current_cause();
		if ( null !== $cause ) {
			$state['cause']      = $cause['cause'];
			$state['message']    = $cause['message'];
			$state['restricted'] = $cause['restricted'];
			return $state;
		}

		if ( null === $rules->free_threshold ) {
			return $state;
		}
		$packages = $cart->get_shipping_packages();
		$package  = $packages ? Package::from_wc( (array) reset( $packages ) ) : null;
		if ( null === $package ) {
			return $state;
		}
		$missing       = $rules->free_threshold - $package->amount( Config::threshold_ignores_discounts( $zone ) );
		$state['free'] = $missing > 0
			? array(
				'tone' => 'info',
				/* translators: %s: amount left with currency. */
				'text' => sprintf( __( 'Te faltan %s para el envío gratis.', 'lachinata-core' ), self::plain_price( $missing ) ),
			)
			: array(
				'tone' => 'success',
				'text' => __( 'Tu pedido tiene envío gratis.', 'lachinata-core' ),
			);
		return $state;
	}

	/**
	 * Notices above the bag summary: zone notice, cause when nothing ships, the note of the
	 * chosen method and how much is left for free shipping.
	 */
	public static function cart_notices(): void {
		$state = self::state();
		if ( '' !== $state['notice'] ) {
			echo self::notice( $state['notice'], 'info' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- notice() escapes.
		}
		if ( null !== $state['cause'] ) {
			echo self::notice( $state['message'], 'error' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- notice() escapes.
			return;
		}
		$chosen = self::chosen_rate();
		if ( null !== $chosen && '' !== (string) $chosen->get_description() ) {
			echo self::notice( (string) $chosen->get_description(), 'info' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- notice() escapes.
		}
		if ( null !== $state['free'] ) {
			echo self::notice( $state['free']['text'], $state['free']['tone'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- notice() escapes.
		}
	}

	/**
	 * «No se envía a Alemania» under a line that cannot ship to the customer's destination;
	 * when the order is over the weight limit, the weight of each line, so the customer
	 * knows what to take out («Dividir el pedido» in the checkout leads here).
	 *
	 * @param string               $note Current note.
	 * @param array<string, mixed> $item Cart item.
	 */
	public static function line_note( string $note, array $item ): string {
		$product     = $item['data'] ?? null;
		$destination = Destination::customer();
		if ( '' !== $note || ! $product instanceof \WC_Product || null === $destination ) {
			return $note;
		}
		$entry = Package::product_entry( $product );
		foreach ( Config::restrictions() as $restriction ) {
			if ( $restriction->applies_to( $entry ) && ! $restriction->allows( $destination['country'], $destination['state'] ) ) {
				/* translators: %s: country or region. */
				return sprintf( __( 'No se envía a %s', 'lachinata-core' ), Destination::name( $destination['country'], $destination['state'], Config::zone_for( $destination ) ) );
			}
		}
		$cause = Rates::current_cause();
		if ( null !== $cause && 'peso_max' === $cause['cause'] && $product->needs_shipping() ) {
			$weight = (float) $product->get_weight() * (float) ( $item['quantity'] ?? 1 );
			/* translators: %s: weight of the line («2,4 kg»). */
			return sprintf( __( 'Pesa %s', 'lachinata-core' ), Messages::weight( wc_get_weight( $weight, 'kg' ) ) );
		}
		return $note;
	}

	/**
	 * Shipping line of the bag summary: the chosen rate with its price and delivery time.
	 *
	 * @param string   $html Current HTML.
	 * @param \WC_Cart $cart Cart.
	 */
	public static function shipping_summary( string $html, \WC_Cart $cart ): string {
		if ( null === Destination::customer() ) {
			return $html;
		}
		$packages = Rates::packages();
		$package  = $packages ? reset( $packages ) : null;
		if ( ! is_array( $package ) ) {
			return $html;
		}
		if ( empty( $package['rates'] ) ) {
			return esc_html__( 'Sin envío disponible', 'lachinata-core' );
		}

		$rate = self::chosen_rate();
		if ( null === $rate ) {
			return $html;
		}
		$cost     = (float) $rate->get_cost() + ( $cart->display_prices_including_tax() ? (float) array_sum( $rate->get_taxes() ) : 0.0 );
		$price    = $cost > 0 ? '<span data-no-translation>' . wp_kses_post( wc_price( $cost ) ) . '</span>' : esc_html__( 'Gratis', 'lachinata-core' );
		$parts    = array( esc_html( $rate->get_label() ), $price );
		$delivery = (string) $rate->get_delivery_time();
		if ( '' !== $delivery ) {
			// Mid-sentence after «·»: «Gratis · llega jue 24 – vie 25 oct».
			$parts[] = esc_html( mb_strtolower( mb_substr( $delivery, 0, 1 ) ) . mb_substr( $delivery, 1 ) );
		}
		return implode( ' · ', $parts );
	}

	/**
	 * Rate chosen for the first package (or its first rate), once rates are calculated.
	 */
	private static function chosen_rate(): ?\WC_Shipping_Rate {
		if ( null === Destination::customer() ) {
			return null;
		}
		$packages = Rates::packages();
		$rates    = $packages ? (array) ( reset( $packages )['rates'] ?? array() ) : array();
		if ( ! $rates ) {
			return null;
		}
		$chosen = WC()->session ? (array) WC()->session->get( 'chosen_shipping_methods', array() ) : array();
		$rate   = $rates[ $chosen[0] ?? '' ] ?? reset( $rates );
		return $rate instanceof \WC_Shipping_Rate ? $rate : null;
	}

	/**
	 * Notice HTML: the theme's component when it is there, the same classes otherwise.
	 *
	 * @param string $text Plain text.
	 * @param string $tone info, success, warning or error.
	 */
	public static function notice( string $text, string $tone ): string {
		if ( function_exists( 'lachinata_notice' ) ) {
			return lachinata_notice( esc_html( $text ), $tone );
		}
		return sprintf(
			'<div class="lc-notice body-sm lc-notice--%1$s" role="%2$s"><span>%3$s</span></div>',
			esc_attr( $tone ),
			'error' === $tone ? 'alert' : 'status',
			esc_html( $text )
		);
	}

	/**
	 * Price as plain text («60 €»), for places that escape their text.
	 *
	 * @param float $amount Amount.
	 */
	public static function plain_price( float $amount ): string {
		$decimals = abs( $amount - round( $amount ) ) < 0.005 ? 0 : wc_get_price_decimals();
		return html_entity_decode( wp_strip_all_tags( wc_price( $amount, array( 'decimals' => $decimals ) ) ) );
	}
}
