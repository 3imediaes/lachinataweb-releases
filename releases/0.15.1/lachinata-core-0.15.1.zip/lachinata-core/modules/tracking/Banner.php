<?php
/**
 * The cookie notice and its panel.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Tracking;

use LaChinata\Core\Company;
use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * ConsentBanner with the exact HTML of the system: the bar and the «Configurar cookies»
 * panel, with the categories of the services this shop has configured. Both are printed
 * hidden on every page (cached pages serve everyone the same HTML) and consent.js shows
 * the bar when there is no valid choice. Before anything else in the `<head>`: Google's
 * consent mode in «denied» (only with a Google service) and the visitor's choice read from
 * the cookie, so no measurement script runs before choosing. Without any optional service
 * nothing of this is printed. Without JavaScript nothing optional loads, so there is no
 * notice either.
 */
final class Banner {

	/**
	 * Handle of consent.js.
	 */
	public const SCRIPT = 'lachinata-tracking-consent';

	/**
	 * Registers the hooks.
	 *
	 * @param Registry $registry Services.
	 */
	public static function boot( Registry $registry ): void {
		Hooks::add_action( 'wp_head', static fn() => self::head( $registry ), 1 );
		Hooks::add_action( 'wp_enqueue_scripts', static fn() => self::enqueue( $registry ) );
		Hooks::add_action( 'wp_footer', static fn() => self::render( $registry ), 5 );
		Hooks::add_action( 'lachinata/footer/consent', static fn() => self::footer_link( $registry ) );
	}

	/**
	 * Whether this request shows the notice: a page of the shop with an optional service.
	 *
	 * @param Registry $registry Services.
	 */
	public static function applies( Registry $registry ): bool {
		/**
		 * Whether the cookie notice and the consent scripts are printed on this page
		 * (false for a page that must stay bare, as a payment iframe).
		 *
		 * @since 0.10.0
		 *
		 * @param bool $applies True on every front-end page with an optional service.
		 */
		return (bool) apply_filters( 'lachinata/tracking/banner', ! is_admin() && ! wp_is_json_request() && (bool) $registry->optional() );
	}

	/**
	 * The first script of the page: the choice from the cookie and, with a Google
	 * service, the consent mode defaults (and the update when there is a choice).
	 *
	 * @param Registry $registry Services.
	 */
	public static function head( Registry $registry ): void {
		if ( ! self::applies( $registry ) ) {
			return;
		}
		$google = $registry->google() ? 'g("consent","default",{ad_storage:"denied",analytics_storage:"denied",ad_user_data:"denied",ad_personalization:"denied",security_storage:"granted",wait_for_update:500});g("set","ads_data_redaction",true);if(o){g("consent","update",{analytics_storage:c.analytics?"granted":"denied",ad_storage:c.marketing?"granted":"denied",ad_user_data:c.marketing?"granted":"denied",ad_personalization:c.marketing?"granted":"denied"});}' : '';
		$script = sprintf(
			'(function(){var v=%1$s,m=document.cookie.match(/(?:^|; )%2$s=([^;]*)/),p=m?decodeURIComponent(m[1]).split("."):[],o=p.length===4&&p[0]===v&&(Date.now()/1e3-p[3])<%3$d,c=window.lcConsent={version:v,given:o,analytics:o&&p[1].charAt(0)==="1",marketing:o&&p[1].charAt(1)==="1",id:o?p[2]:""};window.dataLayer=window.dataLayer||[];var g=window.gtag=window.gtag||function(){window.dataLayer.push(arguments);};%4$s})();',
			wp_json_encode( $registry->version() ),
			Consent::COOKIE,
			Consent::MAX_AGE,
			$google
		);
		wp_print_inline_script_tag( $script, array( 'id' => 'lc-consent-head' ) );
	}

	/**
	 * The script of the notice (consent.js), deferred.
	 *
	 * @param Registry $registry Services.
	 */
	public static function enqueue( Registry $registry ): void {
		if ( ! self::applies( $registry ) ) {
			return;
		}
		$asset = TrackingModule::asset( 'consent' );
		wp_enqueue_script(
			self::SCRIPT,
			plugins_url( 'modules/tracking/build/consent.js', LACHINATA_CORE_FILE ),
			$asset['dependencies'],
			$asset['version'],
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
	}

	/**
	 * Configuration of consent.js.
	 *
	 * @param Registry $registry Services.
	 * @return array<string, mixed>
	 */
	public static function config( Registry $registry ): array {
		$cookies = array();
		foreach ( $registry->categories() as $category ) {
			$cookies[ $category ] = $registry->cookie_names( $category );
		}
		return array(
			'version'    => $registry->version(),
			'categories' => $registry->categories(),
			'cookie'     => Consent::COOKIE,
			'maxAge'     => Consent::MAX_AGE,
			'rest'       => rest_url( ConsentLog::ROUTE_NAMESPACE . ConsentLog::ROUTE ),
			'google'     => $registry->google(),
			'cookies'    => $cookies,
			// The checkout shows no bar: nothing there may cover «Pagar» or distract from it,
			// and it loads no tag. The choice waits for the next page.
			'quiet'      => function_exists( 'is_checkout' ) && is_checkout() && ! is_wc_endpoint_url( 'order-received' ),
		);
	}

	/**
	 * Bar text: what the categories of this shop are for.
	 *
	 * @param string[] $categories analytics and/or marketing.
	 */
	private static function bar_text( array $categories ): string {
		if ( array( 'analytics', 'marketing' ) === $categories ) {
			return __( 'Las necesarias hacen funcionar la tienda; con tu permiso, usamos también cookies de analítica y de publicidad para mejorarla y medir nuestras campañas.', 'lachinata-core' );
		}
		if ( array( 'analytics' ) === $categories ) {
			return __( 'Las necesarias hacen funcionar la tienda; con tu permiso, usamos también cookies de analítica para mejorarla.', 'lachinata-core' );
		}
		return __( 'Las necesarias hacen funcionar la tienda; con tu permiso, usamos también cookies de publicidad para medir nuestras campañas.', 'lachinata-core' );
	}

	/**
	 * What a category does for whoever buys, with the names of its services.
	 *
	 * @param Registry $registry Services.
	 * @param string   $category Category.
	 */
	public static function category_text( Registry $registry, string $category ): string {
		if ( 'necessary' === $category ) {
			return __( 'Bolsa, sesión, pago seguro y tu elección de cookies. Sin ellas la tienda no funciona.', 'lachinata-core' );
		}
		if ( 'analytics' === $category ) {
			return __( 'Nos dicen qué páginas y productos se ven y dónde se atasca la compra, para mejorar la tienda.', 'lachinata-core' );
		}
		$providers = array_values( array_unique( array_map( static fn( array $service ): string => $service['provider'], $registry->of( 'marketing' ) ) ) );
		return sprintf(
			/* translators: 1: list of providers («Google y Meta»), 2: shop name. */
			__( 'Miden nuestras campañas en %1$s y te muestran anuncios de %2$s que te interesen.', 'lachinata-core' ),
			wp_sprintf_l( '%l', $providers ),
			Company::trade_name()
		);
	}

	/**
	 * «política de cookies» linked to the policy page, or the words alone without it.
	 */
	private static function policy_link(): string {
		$url = Policy::url();
		return '' === $url
			? esc_html__( 'política de cookies', 'lachinata-core' )
			: sprintf( '<a href="%1$s">%2$s</a>', esc_url( $url ), esc_html__( 'política de cookies', 'lachinata-core' ) );
	}

	/**
	 * A secondary button of the system.
	 *
	 * @param string $text   Text.
	 * @param string $action accept, reject, save or configure.
	 */
	private static function button( string $text, string $action ): string {
		return sprintf( '<button class="lc-btn button lc-btn--secondary" type="button" data-lc-consent-action="%1$s">%2$s</button>', esc_attr( $action ), esc_html( $text ) );
	}

	/**
	 * The bar and the panel, hidden, and the configuration of consent.js.
	 *
	 * @param Registry $registry Services.
	 */
	public static function render( Registry $registry ): void {
		if ( ! self::applies( $registry ) ) {
			return;
		}
		$categories = $registry->categories();
		$labels     = Registry::labels();
		$link       = self::policy_link();
		?>
		<div class="lc-consent-root" data-lc-consent hidden>
			<div class="lc-consent-bar" data-lc-consent-bar hidden>
				<section class="lc-consent" aria-label="<?php esc_attr_e( 'Cookies', 'lachinata-core' ); ?>">
					<p class="body-sm lc-consent__text"><strong class="label"><?php esc_html_e( 'Usamos cookies.', 'lachinata-core' ); ?> </strong><?php echo esc_html( self::bar_text( $categories ) ); ?>
						<?php
						echo wp_kses(
							/* translators: %s: «política de cookies», linked to the policy page. */
							sprintf( __( 'Más en la %s.', 'lachinata-core' ), $link ),
							array( 'a' => array( 'href' => array() ) )
						);
						?>
					</p>
					<div class="lc-consent__actions">
						<?php
						// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- button() escapes.
						echo self::button( __( 'Configurar', 'lachinata-core' ), 'configure' );
						echo self::button( __( 'Rechazar todo', 'lachinata-core' ), 'reject' );
						echo self::button( __( 'Aceptar todo', 'lachinata-core' ), 'accept' );
						// phpcs:enable
						?>
					</div>
				</section>
			</div>
			<div class="lc-consent-layer" data-lc-consent-layer hidden>
				<div class="lc-consent-layer__overlay" data-lc-consent-action="close"></div>
				<div class="lc-consent lc-consent--panel" role="dialog" aria-modal="true" aria-labelledby="lc-consent-t" tabindex="-1">
					<div class="lc-consent__head">
						<h2 class="h3" id="lc-consent-t"><?php esc_html_e( 'Configurar cookies', 'lachinata-core' ); ?></h2>
						<button type="button" class="lc-btn lc-btn--icon" aria-label="<?php esc_attr_e( 'Cerrar', 'lachinata-core' ); ?>" data-lc-consent-action="close"><svg class="lc-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><use href="#lc-icon-close"></use></svg></button>
					</div>
					<p class="body-sm lc-consent__text">
						<?php
						echo wp_kses(
							/* translators: %s: «política de cookies», linked to the policy page. */
							sprintf( __( 'Elige qué cookies aceptas. Puedes cambiarlo cuando quieras desde «Configurar cookies», al pie de cada página. Más detalle en la %s.', 'lachinata-core' ), $link ),
							array( 'a' => array( 'href' => array() ) )
						);
						?>
					</p>
					<ul class="lc-consent__list">
						<li class="lc-consent__cat">
							<div class="lc-consent__cattext"><span class="label"><?php echo esc_html( $labels['necessary'] ); ?></span><span class="body-sm"><?php echo esc_html( self::category_text( $registry, 'necessary' ) ); ?></span></div>
							<span class="caption lc-consent__always"><?php esc_html_e( 'Siempre activas', 'lachinata-core' ); ?></span>
						</li>
						<?php foreach ( $categories as $category ) : ?>
							<li class="lc-consent__cat">
								<div class="lc-consent__cattext"><span class="label"><?php echo esc_html( $labels[ $category ] ); ?></span><span class="body-sm"><?php echo esc_html( self::category_text( $registry, $category ) ); ?></span></div>
								<button type="button" role="switch" aria-checked="false" aria-label="<?php echo esc_attr( $labels[ $category ] ); ?>" class="lc-switch" data-lc-consent-switch="<?php echo esc_attr( $category ); ?>"><span class="lc-switch__dot"></span></button>
							</li>
						<?php endforeach; ?>
					</ul>
					<div class="lc-consent__actions">
						<?php
						// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- button() escapes.
						echo self::button( __( 'Rechazar todo', 'lachinata-core' ), 'reject' );
						echo self::button( __( 'Guardar mi elección', 'lachinata-core' ), 'save' );
						echo self::button( __( 'Aceptar todo', 'lachinata-core' ), 'accept' );
						// phpcs:enable
						?>
					</div>
				</div>
			</div>
			<script type="application/json" id="lc-consent-config"><?php echo wp_json_encode( self::config( $registry ), JSON_HEX_TAG | JSON_UNESCAPED_SLASHES ); ?></script>
		</div>
		<?php
	}

	/**
	 * «Configurar cookies» in the legal line of the footer: opens the panel; without
	 * JavaScript, the policy.
	 *
	 * @param Registry $registry Services.
	 */
	public static function footer_link( Registry $registry ): void {
		if ( ! self::applies( $registry ) ) {
			return;
		}
		$url = Policy::url();
		printf( '<a href="%1$s" data-lc-consent-open>%2$s</a>', esc_url( '' === $url ? '#lc-consent' : $url ), esc_html__( 'Configurar cookies', 'lachinata-core' ) );
	}
}
