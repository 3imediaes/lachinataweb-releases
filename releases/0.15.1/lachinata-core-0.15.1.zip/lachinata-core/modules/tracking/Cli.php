<?php
/**
 * `wp lachinata tracking`.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Tracking;

defined( 'ABSPATH' ) || exit;

/**
 * Cookie policy and proof of consent from the command line.
 */
final class Cli {

	/**
	 * Creates the cookie policy page (a draft for legal review) from the template, with the
	 * company data of WooCommerce → La Chinata → Datos de la empresa.
	 *
	 * ## OPTIONS
	 *
	 * [--update]
	 * : Rewrite the text of the existing policy page (it is marked for review again).
	 *
	 * [--dry-run]
	 * : Print the content without writing anything.
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata tracking policy
	 *     wp lachinata tracking policy --update
	 *
	 * @param array<int, string>         $args       Positional arguments.
	 * @param array<string, string|bool> $assoc_args Flags.
	 */
	public function policy( array $args, array $assoc_args ): void {
		unset( $args );
		if ( ! empty( $assoc_args['dry-run'] ) ) {
			$built = Policy::content();
			\WP_CLI::log( $built['content'] );
			$this->missing( $built['missing'] );
			return;
		}
		$result = Policy::install( ! empty( $assoc_args['update'] ) );
		if ( is_wp_error( $result ) ) {
			\WP_CLI::error( $result->get_error_message() );
		}
		$this->missing( $result['missing'] );
		\WP_CLI::success(
			sprintf(
				/* translators: 1: page id, 2: edit link. */
				$result['created'] ? __( 'Página %1$d creada como borrador, pendiente de revisión legal: %2$s', 'lachinata-core' ) : __( 'Texto de la página %1$d reescrito y marcado para revisión legal: %2$s', 'lachinata-core' ),
				$result['page'],
				admin_url( 'post.php?post=' . $result['page'] . '&action=edit' )
			)
		);
	}

	/**
	 * Deletes the proofs of consent older than the retention of the settings.
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata tracking purge
	 *
	 * @param array<int, string>         $args       Positional arguments.
	 * @param array<string, string|bool> $assoc_args Flags.
	 */
	public function purge( array $args, array $assoc_args ): void {
		unset( $args, $assoc_args );
		/* translators: %d: rows deleted. */
		\WP_CLI::success( sprintf( __( '%d pruebas de consentimiento borradas.', 'lachinata-core' ), ConsentLog::purge() ) );
	}

	/**
	 * Warns about the company data that the text still lacks.
	 *
	 * @param string[] $missing Missing data.
	 */
	private function missing( array $missing ): void {
		if ( $missing ) {
			/* translators: %s: list of missing company data. */
			\WP_CLI::warning( sprintf( __( 'Faltan datos de la empresa (quedan entre corchetes en el texto): %s.', 'lachinata-core' ), implode( ', ', $missing ) ) );
		}
	}
}
