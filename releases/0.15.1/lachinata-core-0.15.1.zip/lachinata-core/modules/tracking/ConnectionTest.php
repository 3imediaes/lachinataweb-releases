<?php
/**
 * «Probar conexión» of each service.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Tracking;

defined( 'ABSPATH' ) || exit;

/**
 * A test event without anyone's data: to GA4's validation endpoint (it checks the event,
 * not the secret: arrival is seen in DebugView) and to Meta's «Probar eventos» with the
 * test code (a real event otherwise, so the code is required).
 */
final class ConnectionTest {

	/**
	 * Runs the test of a service.
	 *
	 * @param string $service ga4 or meta.
	 * @return array{message: string, error: string}
	 */
	public static function run( string $service ): array {
		if ( 'ga4' === $service ) {
			return self::ga4();
		}
		if ( 'meta' === $service ) {
			return self::meta();
		}
		return array(
			'message' => '',
			'error'   => __( 'Servicio desconocido.', 'lachinata-core' ),
		);
	}

	/**
	 * GA4: Measurement Protocol validation.
	 *
	 * @return array{message: string, error: string}
	 */
	private static function ga4(): array {
		$id     = Fields::value( 'ga4_id' );
		$secret = Fields::value( 'ga4_api_secret' );
		if ( '' === $id || '' === $secret ) {
			return array(
				'message' => '',
				'error'   => __( 'GA4: faltan el ID de medición o el secreto de la API.', 'lachinata-core' ),
			);
		}
		$result = Http::post(
			add_query_arg(
				array(
					'measurement_id' => rawurlencode( $id ),
					'api_secret'     => rawurlencode( $secret ),
				),
				Http::GA4_DEBUG
			),
			array(
				'client_id' => '0.' . time(),
				'events'    => array(
					array(
						'name'   => 'lc_connection_test',
						'params' => array( 'engagement_time_msec' => 1 ),
					),
				),
			)
		);
		if ( '' !== $result['error'] ) {
			return array(
				'message' => '',
				/* translators: %s: error. */
				'error'   => sprintf( __( 'GA4: %s', 'lachinata-core' ), $result['error'] ),
			);
		}
		$messages = (array) ( $result['body']['validationMessages'] ?? array() );
		if ( $messages ) {
			$first = is_array( $messages[0] ) ? (string) ( $messages[0]['description'] ?? '' ) : '';
			return array(
				'message' => '',
				/* translators: %s: validation message of Google. */
				'error'   => sprintf( __( 'GA4 rechaza el evento de prueba: %s', 'lachinata-core' ), $first ),
			);
		}
		return array(
			'message' => __( 'GA4: el evento de prueba es válido. Google no comprueba el secreto en la validación: confírmalo en Administrar → DebugView cuando llegue una compra.', 'lachinata-core' ),
			'error'   => '',
		);
	}

	/**
	 * Meta: a test event to «Probar eventos».
	 *
	 * @return array{message: string, error: string}
	 */
	private static function meta(): array {
		$pixel = Fields::value( 'meta_pixel_id' );
		$token = Fields::value( 'meta_capi_token' );
		$code  = Fields::value( 'meta_test_code' );
		if ( '' === $pixel || '' === $token || '' === $code ) {
			return array(
				'message' => '',
				'error'   => __( 'Meta: hacen falta el ID del píxel, el token de la API de conversiones y el código de prueba de «Probar eventos».', 'lachinata-core' ),
			);
		}
		$result = Http::post(
			Http::GRAPH . Http::graph_version() . '/' . rawurlencode( $pixel ) . '/events?access_token=' . rawurlencode( $token ),
			array(
				'test_event_code' => $code,
				'data'            => array(
					array(
						'event_name'    => 'PageView',
						'event_time'    => time(),
						'action_source' => 'website',
						'event_id'      => 'lc-test-' . wp_generate_uuid4(),
						'user_data'     => array( 'client_user_agent' => 'lachinata-connection-test' ),
					),
				),
			)
		);
		if ( '' !== $result['error'] ) {
			return array(
				'message' => '',
				/* translators: %s: error. */
				'error'   => sprintf( __( 'Meta: %s', 'lachinata-core' ), $result['error'] ),
			);
		}
		return array(
			/* translators: %d: events received. */
			'message' => sprintf( __( 'Meta ha recibido %d evento de prueba: míralo en el Administrador de eventos → Probar eventos.', 'lachinata-core' ), (int) ( $result['body']['events_received'] ?? 0 ) ),
			'error'   => '',
		);
	}
}
