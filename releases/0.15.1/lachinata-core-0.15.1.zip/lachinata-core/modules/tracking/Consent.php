<?php
/**
 * The visitor's choice about cookies.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Tracking;

defined( 'ABSPATH' ) || exit;

/**
 * Cookie `lc_consent`: `<version>.<analytics><marketing>.<id>.<unix time>`, as
 * «9f3a1c2b.10.4f1c…(32 hex).1761475200». The browser writes it (pages are cached, so the
 * server never decides who sees the notice); the server reads it only where PHP runs for
 * that visitor (a cookie another plugin wants to set, an order). A cookie of an older
 * version counts as no choice: the notice asks again.
 */
final class Consent {

	/**
	 * Cookie name.
	 */
	public const COOKIE = 'lc_consent';

	/**
	 * Lifetime of the choice: 12 months.
	 */
	public const MAX_AGE = YEAR_IN_SECONDS;

	/**
	 * Parses a cookie value.
	 *
	 * @param string $value Cookie value.
	 * @return array{version: string, analytics: bool, marketing: bool, id: string, time: int}|null
	 */
	public static function parse( string $value ): ?array {
		if ( ! preg_match( '/^([a-f0-9]{8})\.([01])([01])\.([a-f0-9]{32})\.(\d{9,11})$/', $value, $match ) ) {
			return null;
		}
		return array(
			'version'   => $match[1],
			'analytics' => '1' === $match[2],
			'marketing' => '1' === $match[3],
			'id'        => $match[4],
			'time'      => (int) $match[5],
		);
	}

	/**
	 * The choice of the current visitor for this version of the policy, or null.
	 *
	 * @param Registry $registry Services.
	 * @return array{version: string, analytics: bool, marketing: bool, id: string, time: int}|null
	 */
	public static function current( Registry $registry ): ?array {
		$raw    = isset( $_COOKIE[ self::COOKIE ] ) ? sanitize_text_field( wp_unslash( $_COOKIE[ self::COOKIE ] ) ) : '';
		$choice = self::parse( $raw );
		if ( null === $choice || $choice['version'] !== $registry->version() || $choice['time'] < time() - self::MAX_AGE ) {
			return null;
		}
		return $choice;
	}

	/**
	 * Whether the current visitor accepted a category (server side).
	 *
	 * @param Registry $registry Services.
	 * @param string   $category analytics or marketing.
	 */
	public static function allows( Registry $registry, string $category ): bool {
		$choice = self::current( $registry );
		return null !== $choice && ! empty( $choice[ $category ] );
	}
}
