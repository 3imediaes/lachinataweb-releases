<?php
/**
 * Proof of consent.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Tracking;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * Each choice of the notice, without personal data: the random id of the browser's
 * cookie, the date, the version of the policy, what was accepted, how (accept all, reject
 * all, save) and which services were on. Enough to show that a consent was given for a
 * version of the policy, and nothing that identifies anyone (no IP, no user, no agent).
 * Rows older than the retention of the settings (36 months by default) are deleted daily.
 */
final class ConsentLog {

	/**
	 * Table, without the WordPress prefix.
	 */
	public const TABLE = 'lc_tracking_consent';

	/**
	 * REST route.
	 */
	public const ROUTE_NAMESPACE = 'lachinata/v1';
	public const ROUTE           = '/consent';

	/**
	 * Daily purge (Action Scheduler).
	 */
	public const PURGE_HOOK = 'lachinata_tracking_purge_consent';

	/**
	 * Group of the scheduled actions.
	 */
	public const GROUP = 'lachinata-tracking';

	/**
	 * Ways of choosing.
	 */
	public const ACTIONS = array( 'accept', 'reject', 'save' );

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'rest_api_init', array( self::class, 'routes' ) );
		Hooks::add_action( self::PURGE_HOOK, array( self::class, 'purge' ) );
		Hooks::add_action( 'action_scheduler_init', array( self::class, 'schedule' ) );
	}

	/**
	 * Full table name.
	 */
	public static function table(): string {
		global $wpdb;
		return $wpdb->prefix . self::TABLE;
	}

	/**
	 * Creates the table (migration 1; idempotent).
	 */
	public static function install(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table   = self::table();
		$charset = $wpdb->get_charset_collate();
		dbDelta(
			"CREATE TABLE {$table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				consent_id char(32) NOT NULL,
				created_at datetime NOT NULL,
				version char(8) NOT NULL,
				analytics tinyint(1) NOT NULL DEFAULT 0,
				marketing tinyint(1) NOT NULL DEFAULT 0,
				method varchar(10) NOT NULL,
				services varchar(255) NOT NULL DEFAULT '',
				PRIMARY KEY  (id),
				KEY consent_id (consent_id),
				KEY created_at (created_at)
			) {$charset};"
		);
	}

	/**
	 * The daily purge, once.
	 */
	public static function schedule(): void {
		// Looked at once a day, not on every request.
		if ( get_transient( 'lachinata_tracking_purge_scheduled' ) ) {
			return;
		}
		set_transient( 'lachinata_tracking_purge_scheduled', 1, DAY_IN_SECONDS );
		if ( function_exists( 'as_has_scheduled_action' ) && function_exists( 'as_schedule_recurring_action' ) && ! as_has_scheduled_action( self::PURGE_HOOK, array(), self::GROUP ) ) {
			as_schedule_recurring_action( time() + HOUR_IN_SECONDS, DAY_IN_SECONDS, self::PURGE_HOOK, array(), self::GROUP );
		}
	}

	/**
	 * `POST /lachinata/v1/consent`. Public by nature (visitors without an account choose),
	 * so it takes nothing that identifies anyone and checks everything it takes.
	 */
	public static function routes(): void {
		register_rest_route(
			self::ROUTE_NAMESPACE,
			self::ROUTE,
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'args'                => array(
					'id'        => array(
						'type'     => 'string',
						'required' => true,
						'pattern'  => '^[a-f0-9]{32}$',
					),
					'version'   => array(
						'type'     => 'string',
						'required' => true,
						'pattern'  => '^[a-f0-9]{8}$',
					),
					'analytics' => array(
						'type'     => 'boolean',
						'required' => true,
					),
					'marketing' => array(
						'type'     => 'boolean',
						'required' => true,
					),
					'method'    => array(
						'type'     => 'string',
						'required' => true,
						'enum'     => self::ACTIONS,
					),
				),
				'callback'            => Hooks::rest(
					static function ( \WP_REST_Request $request ) {
						$registry = new Registry();
						if ( $request['version'] !== $registry->version() ) {
							return new \WP_Error( 'lachinata_consent_version', __( 'La política de cookies ha cambiado: vuelve a elegir.', 'lachinata-core' ), array( 'status' => 409 ) );
						}
						$saved = self::record(
							(string) $request['id'],
							(string) $request['version'],
							(bool) $request['analytics'],
							(bool) $request['marketing'],
							(string) $request['method'],
							array_map( static fn( array $service ): string => $service['id'], $registry->optional() )
						);
						return rest_ensure_response( array( 'saved' => $saved ) );
					}
				),
			)
		);
	}

	/**
	 * Writes a choice. The same choice of the same browser twice in a minute (a double
	 * click, a retry) is written once.
	 *
	 * @param string   $id        Random id of the cookie.
	 * @param string   $version   Version of the policy.
	 * @param bool     $analytics Analytics accepted.
	 * @param bool     $marketing Advertising accepted.
	 * @param string   $method    accept, reject or save.
	 * @param string[] $services  Ids of the services that needed consent.
	 */
	public static function record( string $id, string $version, bool $analytics, bool $marketing, string $method, array $services ): bool {
		global $wpdb;
		$table = self::table();
		// phpcs:disable WordPress.DB.DirectDatabaseQuery -- own table, written once per choice.
		$recent = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT id FROM %i WHERE consent_id = %s AND version = %s AND analytics = %d AND marketing = %d AND created_at > %s LIMIT 1',
				$table,
				$id,
				$version,
				$analytics ? 1 : 0,
				$marketing ? 1 : 0,
				gmdate( 'Y-m-d H:i:s', time() - MINUTE_IN_SECONDS )
			)
		);
		if ( null !== $recent ) {
			return true;
		}
		$written = $wpdb->insert(
			$table,
			array(
				'consent_id' => $id,
				'created_at' => gmdate( 'Y-m-d H:i:s' ),
				'version'    => $version,
				'analytics'  => $analytics ? 1 : 0,
				'marketing'  => $marketing ? 1 : 0,
				'method'     => $method,
				'services'   => substr( implode( ',', $services ), 0, 255 ),
			),
			array( '%s', '%s', '%s', '%d', '%d', '%s', '%s' )
		);
		// phpcs:enable
		if ( false === $written ) {
			TrackingModule::gaps()->record( 'consent:write', __( 'No se pudo guardar una prueba de consentimiento (¿falta la tabla?). Desactiva y activa el módulo para crearla.', 'lachinata-core' ) );
		}
		return false !== $written;
	}

	/**
	 * Deletes the rows older than the retention.
	 *
	 * @return int Rows deleted.
	 */
	public static function purge(): int {
		global $wpdb;
		$months = max( 1, (int) TrackingModule::setting( 'retention_months' ) );
		$before = gmdate( 'Y-m-d H:i:s', (int) strtotime( '-' . $months . ' months' ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- own table.
		return (int) $wpdb->query( $wpdb->prepare( 'DELETE FROM %i WHERE created_at < %s', self::table(), $before ) );
	}

	/**
	 * Count of choices of the last days, by method, for the settings screen.
	 *
	 * @param int $days Days back.
	 * @return array{accept: int, reject: int, save: int}
	 */
	public static function summary( int $days = 30 ): array {
		global $wpdb;
		$out = array_fill_keys( self::ACTIONS, 0 );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery -- own table, admin screen.
		$rows = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT method, COUNT(*) AS total FROM %i WHERE created_at > %s GROUP BY method', self::table(), gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS ) ), ARRAY_A );
		foreach ( $rows as $row ) {
			if ( isset( $out[ $row['method'] ] ) ) {
				$out[ $row['method'] ] = (int) $row['total'];
			}
		}
		/**
		 * The three methods are there.
		 *
		 * @var array{accept: int, reject: int, save: int} $out
		 */
		return $out;
	}
}
