<?php
/**
 * Ids and credentials of the measurement services.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Tracking;

defined( 'ABSPATH' ) || exit;

/**
 * Each field with its service, its format and its help. A service is on only when its
 * required fields are filled and well formed: a wrong value turns the service off and
 * shows in the health, it never prints a broken tag.
 */
final class Fields {

	/**
	 * Fields: service, whether it is required for the service to run, secret (never shown
	 * back or exported) and the pattern it must match.
	 */
	private const FIELDS = array(
		'ga4_id'                => array( 'ga4', true, false, '/^G-[A-Z0-9]{4,15}$/' ),
		'ga4_api_secret'        => array( 'ga4', false, true, '/^[A-Za-z0-9_\-]{16,64}$/' ),
		'ads_id'                => array( 'ads', true, false, '/^AW-\d{6,12}$/' ),
		'ads_label_purchase'    => array( 'ads', true, false, '/^[A-Za-z0-9_\-]{6,40}$/' ),
		'ads_label_add_to_cart' => array( 'ads', false, false, '/^[A-Za-z0-9_\-]{6,40}$/' ),
		'ads_label_checkout'    => array( 'ads', false, false, '/^[A-Za-z0-9_\-]{6,40}$/' ),
		'ads_label_lead'        => array( 'ads', false, false, '/^[A-Za-z0-9_\-]{6,40}$/' ),
		'meta_pixel_id'         => array( 'meta', true, false, '/^\d{10,20}$/' ),
		'meta_capi_token'       => array( 'meta', false, true, '/^[A-Za-z0-9]{40,512}$/' ),
		'meta_test_code'        => array( 'meta', false, false, '/^TEST\d{3,10}$/' ),
	);

	/**
	 * Service names.
	 *
	 * @return array<string, string>
	 */
	public static function services(): array {
		return array(
			'ga4'  => __( 'Google Analytics 4', 'lachinata-core' ),
			'ads'  => __( 'Google Ads', 'lachinata-core' ),
			'meta' => __( 'Píxel de Meta', 'lachinata-core' ),
		);
	}

	/**
	 * Field keys with their definition.
	 *
	 * @return array<string, array{service: string, required: bool, secret: bool, pattern: string}>
	 */
	public static function all(): array {
		$out = array();
		foreach ( self::FIELDS as $key => $field ) {
			$out[ $key ] = array(
				'service'  => $field[0],
				'required' => $field[1],
				'secret'   => $field[2],
				'pattern'  => $field[3],
			);
		}
		return $out;
	}

	/**
	 * Label and help of a field, for the settings screen.
	 *
	 * @param string $key Field key.
	 * @return array{label: string, help: string, placeholder: string}
	 */
	public static function text( string $key ): array {
		$texts = array(
			'ga4_id'                => array( __( 'ID de medición', 'lachinata-core' ), __( 'En GA4 → Administrar → Flujos de datos → tu web. Empieza por G-.', 'lachinata-core' ), 'G-XXXXXXXXXX' ),
			'ga4_api_secret'        => array( __( 'Secreto de la API de Measurement Protocol', 'lachinata-core' ), __( 'En el mismo flujo de datos → Secretos de la API de Measurement Protocol. Sin él, la compra y el reembolso solo salen del navegador y no hay eventos del checkout.', 'lachinata-core' ), '' ),
			'ads_id'                => array( __( 'ID de conversión', 'lachinata-core' ), __( 'En Google Ads → Objetivos → Conversiones → la acción → Configuración de etiquetas. Empieza por AW-.', 'lachinata-core' ), 'AW-123456789' ),
			'ads_label_purchase'    => array( __( 'Etiqueta de la compra', 'lachinata-core' ), __( 'Obligatoria para activar Google Ads: es lo que va tras la barra en «send_to» (AW-…/etiqueta).', 'lachinata-core' ), '' ),
			'ads_label_add_to_cart' => array( __( 'Etiqueta de añadir a la bolsa', 'lachinata-core' ), __( 'Opcional. Vacía: no se envía esa conversión.', 'lachinata-core' ), '' ),
			'ads_label_checkout'    => array( __( 'Etiqueta de inicio del checkout', 'lachinata-core' ), __( 'Opcional. Como el checkout no carga etiquetas de terceros, se envía al pasar de la bolsa al pago.', 'lachinata-core' ), '' ),
			'ads_label_lead'        => array( __( 'Etiqueta del lead', 'lachinata-core' ), __( 'Opcional: formularios de contacto o de franquicias.', 'lachinata-core' ), '' ),
			'meta_pixel_id'         => array( __( 'ID del píxel', 'lachinata-core' ), __( 'En el Administrador de eventos de Meta → tu conjunto de datos. Solo números.', 'lachinata-core' ), '' ),
			'meta_capi_token'       => array( __( 'Token de la API de conversiones', 'lachinata-core' ), __( 'En el conjunto de datos → Configuración → API de conversiones → Generar token de acceso. Sin él, los eventos solo salen del navegador.', 'lachinata-core' ), '' ),
			'meta_test_code'        => array( __( 'Código de prueba (Test Events)', 'lachinata-core' ), __( 'Solo mientras pruebas: los eventos del servidor salen en «Probar eventos». Vacíalo al terminar.', 'lachinata-core' ), 'TEST12345' ),
		);
		$row   = $texts[ $key ] ?? array( $key, '', '' );
		return array(
			'label'       => $row[0],
			'help'        => $row[1],
			'placeholder' => $row[2],
		);
	}

	/**
	 * Why a value cannot be saved in a field, or an empty string. Empty is always valid.
	 *
	 * @param string $key   Field key.
	 * @param string $value Value.
	 */
	public static function error( string $key, string $value ): string {
		$field = self::all()[ $key ] ?? null;
		if ( null === $field || '' === $value || preg_match( $field['pattern'], $value ) ) {
			return '';
		}
		$messages = array(
			'ga4_id'          => __( 'El ID de medición empieza por G- y sigue con letras mayúsculas y números (G-AB12CD34EF).', 'lachinata-core' ),
			'ga4_api_secret'  => __( 'El secreto tiene entre 16 y 64 letras, números, guiones o guiones bajos, sin espacios.', 'lachinata-core' ),
			'ads_id'          => __( 'El ID de conversión empieza por AW- y sigue con números (AW-123456789).', 'lachinata-core' ),
			'meta_pixel_id'   => __( 'El ID del píxel son solo números, entre 10 y 20.', 'lachinata-core' ),
			'meta_capi_token' => __( 'El token son letras y números, sin espacios: cópialo entero desde Meta.', 'lachinata-core' ),
			'meta_test_code'  => __( 'El código de prueba empieza por TEST y sigue con números (TEST12345).', 'lachinata-core' ),
		);
		return $messages[ $key ] ?? __( 'La etiqueta son letras, números, guiones o guiones bajos, sin espacios ni la parte AW-…/.', 'lachinata-core' );
	}

	/**
	 * Saved value of a field when it is well formed; an empty string otherwise.
	 *
	 * @param string $key Field key.
	 */
	public static function value( string $key ): string {
		$value = trim( (string) TrackingModule::setting( $key ) );
		return '' === self::error( $key, $value ) ? $value : '';
	}

	/**
	 * State of a service: `ok` (on), `off` (none of its required fields is filled) or
	 * `broken` (a value with the wrong format, or the required fields only half filled, as
	 * a Google Ads id without the purchase label): off until fixed, with a health notice.
	 *
	 * @param string $service ga4, ads or meta.
	 */
	public static function state( string $service ): string {
		$generation = Registry::generation();
		if ( isset( self::$states[ $service ] ) && self::$states[ $service ][0] === $generation ) {
			return self::$states[ $service ][1];
		}
		$state                    = self::compute( $service );
		self::$states[ $service ] = array( $generation, $state );
		return $state;
	}

	/**
	 * States of this request, with the settings generation they were read with.
	 *
	 * @var array<string, array{0: int, 1: string}>
	 */
	private static array $states = array();

	/**
	 * Reads the state of a service from its settings.
	 *
	 * @param string $service ga4, ads or meta.
	 */
	private static function compute( string $service ): string {
		$required = 0;
		$filled   = 0;
		foreach ( self::all() as $key => $field ) {
			if ( $field['service'] !== $service ) {
				continue;
			}
			$raw = trim( (string) TrackingModule::setting( $key ) );
			if ( '' !== self::error( $key, $raw ) ) {
				return 'broken';
			}
			if ( $field['required'] ) {
				++$required;
				$filled += '' === $raw ? 0 : 1;
			}
		}
		if ( 0 === $filled ) {
			return 'off';
		}
		return $filled === $required ? 'ok' : 'broken';
	}

	/**
	 * Whether a service is on.
	 *
	 * @param string $service ga4, ads or meta.
	 */
	public static function on( string $service ): bool {
		return 'ok' === self::state( $service );
	}

	/**
	 * Whether the secrets of a service are there (never their value), by field.
	 *
	 * @param string $service Service.
	 * @return array<string, bool>
	 */
	public static function secrets( string $service ): array {
		$out = array();
		foreach ( self::all() as $key => $field ) {
			if ( $field['service'] === $service && $field['secret'] ) {
				$out[ $key ] = '' !== self::value( $key );
			}
		}
		return $out;
	}
}
