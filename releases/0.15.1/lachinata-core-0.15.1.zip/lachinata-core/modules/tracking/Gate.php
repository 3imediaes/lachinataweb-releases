<?php
/**
 * Scripts that wait for consent.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Tracking;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * The scripts that services declare (`handles`) are printed inert, as
 * `type="text/plain" data-lc-consent="<category>"`, with their inline parts: the browser
 * neither downloads nor runs them. consent.js turns them into real scripts, in order, once
 * the visitor accepts their category. It is done in the page and not on the server
 * because pages are cached: the same HTML serves whoever has chosen and whoever has not.
 */
final class Gate {

	/**
	 * Registers the hooks.
	 *
	 * @param Registry $registry Services.
	 */
	public static function boot( Registry $registry ): void {
		Hooks::add_filter(
			'script_loader_tag',
			static function ( $tag, $handle ) use ( $registry ) {
				$category = $registry->handles()[ (string) $handle ] ?? null;
				return null === $category ? $tag : self::inert( (string) $tag, $category );
			},
			20,
			2
		);
		Mailchimp::boot( $registry );
	}

	/**
	 * Makes every `<script>` of an HTML fragment inert until a category is accepted.
	 * Data blocks (JSON) are left as they are.
	 *
	 * @param string $html     Fragment.
	 * @param string $category analytics or marketing.
	 */
	public static function inert( string $html, string $category ): string {
		return (string) preg_replace_callback(
			'/<script\b([^>]*)>/i',
			static function ( array $found ) use ( $category ): string {
				$attributes = $found[1];
				if ( preg_match( '/\btype=(["\'])([^"\']*)\1/i', $attributes, $type ) && ! in_array( strtolower( $type[2] ), array( 'text/javascript', 'module', 'application/javascript' ), true ) ) {
					return $found[0];
				}
				$module     = isset( $type[2] ) && 'module' === strtolower( $type[2] );
				$attributes = (string) preg_replace( '/\s*\btype=(["\'])[^"\']*\1/i', '', $attributes );
				return sprintf( '<script type="text/plain" data-lc-consent="%1$s"%2$s%3$s>', esc_attr( $category ), $module ? ' data-lc-module' : '', $attributes );
			},
			$html
		);
	}
}
