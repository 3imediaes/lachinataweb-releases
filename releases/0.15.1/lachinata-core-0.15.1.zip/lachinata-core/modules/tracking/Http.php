<?php
/**
 * Requests to the measurement services.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Tracking;

defined( 'ABSPATH' ) || exit;

/**
 * JSON over HTTPS with the WordPress HTTP API (tests answer through `pre_http_request`).
 * Never logs a secret: the URL of a failure is reported without its query.
 */
final class Http {

	/**
	 * Endpoint of GA4's Measurement Protocol.
	 */
	public const GA4 = 'https://www.google-analytics.com/mp/collect';

	/**
	 * Validation endpoint of GA4's Measurement Protocol.
	 */
	public const GA4_DEBUG = 'https://www.google-analytics.com/debug/mp/collect';

	/**
	 * Graph API of Meta (Conversions API).
	 */
	public const GRAPH = 'https://graph.facebook.com/';

	/**
	 * Version of the Graph API.
	 */
	public static function graph_version(): string {
		/**
		 * Version of Meta's Graph API for the Conversions API.
		 *
		 * @since 0.10.0
		 *
		 * @param string $version «v23.0».
		 */
		return (string) apply_filters( 'lachinata/tracking/graph_version', 'v23.0' );
	}

	/**
	 * POSTs JSON and decodes the answer.
	 *
	 * @param string               $url  URL (with its query).
	 * @param array<string, mixed> $body Body.
	 * @return array{status: int, body: array<mixed>, error: string}
	 */
	public static function post( string $url, array $body ): array {
		$response = wp_remote_post(
			$url,
			array(
				'timeout' => 8,
				'headers' => array( 'Content-Type' => 'application/json' ),
				'body'    => (string) wp_json_encode( $body ),
			)
		);
		if ( is_wp_error( $response ) ) {
			return array(
				'status' => 0,
				'body'   => array(),
				'error'  => $response->get_error_message(),
			);
		}
		$status  = (int) wp_remote_retrieve_response_code( $response );
		$decoded = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		$decoded = is_array( $decoded ) ? $decoded : array();
		$error   = '';
		if ( $status < 200 || $status >= 300 ) {
			$message = is_array( $decoded['error'] ?? null ) ? (string) ( $decoded['error']['message'] ?? '' ) : '';
			/* translators: 1: HTTP status, 2: host and path, 3: message of the service. */
			$error = trim( sprintf( __( 'Respuesta %1$d de %2$s. %3$s', 'lachinata-core' ), $status, (string) strtok( $url, '?' ), $message ) );
		}
		return array(
			'status' => $status,
			'body'   => $decoded,
			'error'  => $error,
		);
	}
}
