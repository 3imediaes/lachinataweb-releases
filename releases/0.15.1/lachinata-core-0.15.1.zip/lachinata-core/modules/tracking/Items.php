<?php
/**
 * The products of the events.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Tracking;

use LaChinata\Core\Company;
use LaChinata\Core\ProductIds;

defined( 'ABSPATH' ) || exit;

/**
 * One shape for every product in every event (GA4 names): `item_id`, `item_name`,
 * `item_brand`, `item_category` to `item_category3` (path from the top category),
 * `item_variant`, `price`, `quantity`, `discount`, and `item_list_id`, `item_list_name`
 * and `index` where there is a list. `item_id` is the GA4 id of ProductIds;
 * `ids` carries the ids of the other destinations (Google for Ads remarketing, Meta for
 * the pixel and CAPI) and the WooCommerce id, and never reaches GA4.
 *
 * Money: `price` is the unit price the customer pays, VAT included, after discounts;
 * `discount` is what is taken off the regular price per unit. The `value` of an event is
 * the sum of `price × quantity`: products with VAT, without shipping. Shipping and taxes
 * go apart (`shipping`, `tax`) in the purchase. Defined in README.md: it does not change.
 *
 * @phpstan-type Item array{item_id: string, item_name: string, item_brand: string, item_category?: string, item_category2?: string, item_category3?: string, item_variant?: string, price: float, quantity: int, discount?: float, item_list_id?: string, item_list_name?: string, index?: int, ids: array{google: string, meta: string, product: int}}
 */
final class Items {

	/**
	 * A product (or variation) at its current price.
	 *
	 * @param \WC_Product                                    $product  Product or variation.
	 * @param int                                            $quantity Units.
	 * @param array{id?: string, name?: string, index?: int} $shown_in List the product is shown in.
	 * @return Item
	 */
	public static function product( \WC_Product $product, int $quantity = 1, array $shown_in = array() ): array {
		$price   = (float) wc_get_price_including_tax( $product );
		$regular = (float) wc_get_price_including_tax( $product, array( 'price' => (float) $product->get_regular_price() ) );
		return self::shape( $product, $price, max( 0.0, $regular - $price ), $quantity, $shown_in );
	}

	/**
	 * A line of the cart, at the price it has in the cart (with its coupons).
	 *
	 * @param array<string, mixed> $line Cart item.
	 * @return Item|null
	 */
	public static function cart_line( array $line ): ?array {
		$product  = $line['data'] ?? null;
		$quantity = max( 1, (int) ( $line['quantity'] ?? 1 ) );
		if ( ! $product instanceof \WC_Product ) {
			return null;
		}
		$paid    = ( (float) ( $line['line_total'] ?? 0 ) + (float) ( $line['line_tax'] ?? 0 ) ) / $quantity;
		$regular = (float) wc_get_price_including_tax( $product, array( 'price' => (float) $product->get_regular_price() ) );
		return self::shape( $product, $paid, max( 0.0, $regular - $paid ), $quantity, array() );
	}

	/**
	 * The lines of the current cart.
	 *
	 * @return list<Item>
	 */
	public static function cart(): array {
		if ( ! function_exists( 'WC' ) || null === WC()->cart ) {
			return array();
		}
		$out = array();
		foreach ( WC()->cart->get_cart() as $line ) {
			$item = self::cart_line( (array) $line );
			if ( null !== $item ) {
				$out[] = $item;
			}
		}
		return $out;
	}

	/**
	 * A line of an order, at what was paid.
	 *
	 * @param \WC_Order_Item_Product $line Order line.
	 * @return Item|null
	 */
	public static function order_line( \WC_Order_Item_Product $line ): ?array {
		$product  = $line->get_product();
		$quantity = max( 1, (int) $line->get_quantity() );
		if ( ! $product instanceof \WC_Product ) {
			return null;
		}
		$paid     = ( (float) $line->get_total() + (float) $line->get_total_tax() ) / $quantity;
		$subtotal = ( (float) $line->get_subtotal() + (float) $line->get_subtotal_tax() ) / $quantity;
		$regular  = (float) wc_get_price_including_tax( $product, array( 'price' => (float) $product->get_regular_price() ) );
		return self::shape( $product, $paid, max( 0.0, max( $regular, $subtotal ) - $paid ), $quantity, array() );
	}

	/**
	 * The lines of an order.
	 *
	 * @param \WC_Order $order Order.
	 * @return list<Item>
	 */
	public static function order( \WC_Order $order ): array {
		$out = array();
		foreach ( $order->get_items() as $line ) {
			$item = $line instanceof \WC_Order_Item_Product ? self::order_line( $line ) : null;
			if ( null !== $item ) {
				$out[] = $item;
			}
		}
		return $out;
	}

	/**
	 * Value of some items: products with VAT, without shipping.
	 *
	 * @param array<int, array<string, mixed>> $items Items.
	 */
	public static function value( array $items ): float {
		$total = 0.0;
		foreach ( $items as $item ) {
			$total += (float) $item['price'] * (int) $item['quantity'];
		}
		return round( $total, wc_get_price_decimals() );
	}

	/**
	 * Items as GA4 takes them (without the ids of the other destinations).
	 *
	 * @param array<int, array<string, mixed>> $items Items.
	 * @return list<array<string, mixed>>
	 */
	public static function for_ga4( array $items ): array {
		return array_values(
			array_map(
				static function ( array $item ): array {
					unset( $item['ids'] );
					return $item;
				},
				$items
			)
		);
	}

	/**
	 * Builds the item.
	 *
	 * @param \WC_Product                                    $product  Product or variation.
	 * @param float                                          $price    Unit price paid, VAT included.
	 * @param float                                          $discount Taken off the regular price, per unit.
	 * @param int                                            $quantity Units.
	 * @param array{id?: string, name?: string, index?: int} $shown_in List.
	 * @return Item
	 */
	private static function shape( \WC_Product $product, float $price, float $discount, int $quantity, array $shown_in ): array {
		$decimals = wc_get_price_decimals();
		$parent   = $product->is_type( 'variation' ) ? wc_get_product( $product->get_parent_id() ) : $product;
		$parent   = $parent instanceof \WC_Product ? $parent : $product;
		$item     = array(
			'item_id'    => ProductIds::get( $product, 'ga4' ),
			'item_name'  => html_entity_decode( wp_strip_all_tags( $parent->get_name() ) ),
			'item_brand' => Company::brand( $product ),
		);
		foreach ( array_slice( self::categories( $parent ), 0, 3 ) as $level => $name ) {
			$item[ 0 === $level ? 'item_category' : 'item_category' . ( $level + 1 ) ] = $name;
		}
		if ( $product instanceof \WC_Product_Variation ) {
			$item['item_variant'] = html_entity_decode( wp_strip_all_tags( wc_get_formatted_variation( $product, true, false, false ) ) );
		}
		$item['price']    = round( $price, $decimals );
		$item['quantity'] = $quantity;
		if ( $discount > 0.004 ) {
			$item['discount'] = round( $discount, $decimals );
		}
		if ( isset( $shown_in['id'] ) ) {
			$item['item_list_id']   = (string) $shown_in['id'];
			$item['item_list_name'] = (string) ( $shown_in['name'] ?? $shown_in['id'] );
		}
		if ( isset( $shown_in['index'] ) ) {
			$item['index'] = (int) $shown_in['index'];
		}
		$item['ids'] = array(
			'google'  => ProductIds::get( $product, 'google' ),
			'meta'    => ProductIds::get( $product, 'meta' ),
			'product' => $product->get_id(),
		);
		/**
		 * Item ids and params are all there.
		 *
		 * @var array{item_id: string, item_name: string, item_brand: string, item_category?: string, item_category2?: string, item_category3?: string, item_variant?: string, price: float, quantity: int, discount?: float, item_list_id?: string, item_list_name?: string, index?: int, ids: array{google: string, meta: string, product: int}} $item
		 */
		return $item;
	}

	/**
	 * Path of the deepest category of a product, from the top («Cosmética», «Rostro», «Cremas»).
	 *
	 * @param \WC_Product $product Product (not a variation).
	 * @return string[]
	 */
	public static function categories( \WC_Product $product ): array {
		$deepest = null;
		$depth   = -1;
		foreach ( $product->get_category_ids() as $id ) {
			$ancestors = get_ancestors( (int) $id, 'product_cat', 'taxonomy' );
			if ( count( $ancestors ) > $depth ) {
				$depth   = count( $ancestors );
				$deepest = (int) $id;
			}
		}
		if ( null === $deepest ) {
			return array();
		}
		$path = array_reverse( array_merge( array( $deepest ), get_ancestors( $deepest, 'product_cat', 'taxonomy' ) ) );
		$out  = array();
		foreach ( $path as $id ) {
			$term = get_term( $id, 'product_cat' );
			if ( $term instanceof \WP_Term ) {
				$out[] = html_entity_decode( $term->name );
			}
		}
		return $out;
	}
}
