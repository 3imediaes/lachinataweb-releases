<?php
/**
 * Mailchimp for WooCommerce behind the consent.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Tracking;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * Mailchimp for WooCommerce keeps syncing products, orders, customers and carts
 * (decisiones.md, incremento 7). What it does in the visitor's browser is advertising and
 * waits for that consent: its public script (email capture for abandoned carts), its pixel
 * and the connected-site script (`mcjs`). Its cookies, also the ones it sets from PHP on a
 * campaign landing and when it captures the email of a cart (AJAX and block checkout), go
 * through `mailchimp_allowed_to_use_cookie`, which answers with `lc_consent`.
 */
final class Mailchimp {

	/**
	 * Script handles of Mailchimp for WooCommerce 6.x that track the visitor.
	 */
	public const HANDLES = array( 'mailchimp-woocommerce', 'mailchimp-woocommerce-pixel-tracking', 'mailchimp-woocommerce-pixel-tracking-blocks' );

	/**
	 * Whether Mailchimp for WooCommerce is active.
	 */
	public static function active(): bool {
		return function_exists( 'mailchimp_environment_variables' );
	}

	/**
	 * Registers the hooks, only while its service is in the registry (the plugin is
	 * active and the setting «Mailchimp solo con consentimiento» is on).
	 *
	 * @param Registry $registry Services.
	 */
	public static function boot( Registry $registry ): void {
		if ( ! self::active() ) {
			return;
		}
		Hooks::add_filter(
			'mailchimp_allowed_to_use_cookie',
			static fn( $cookie ) => self::gated( $registry ) ? Consent::allows( $registry, 'marketing' ) : $cookie,
			20
		);
		Hooks::add_filter( 'mailchimp_add_inline_footer_script', static fn( $add ) => self::gated( $registry ) ? false : $add, 20 );
		Hooks::add_action( 'wp_footer', static fn() => self::gated( $registry ) ? self::print_fragment() : null, 30 );
	}

	/**
	 * Whether Mailchimp is under the consent in this shop.
	 *
	 * @param Registry $registry Services.
	 */
	private static function gated( Registry $registry ): bool {
		foreach ( $registry->optional() as $service ) {
			if ( 'mailchimp' === $service['id'] ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * The connected-site script of Mailchimp, inert until the visitor accepts advertising.
	 */
	private static function print_fragment(): void {
		if ( ! function_exists( 'mailchimp_get_connected_site_script_fragment' ) ) {
			return;
		}
		$fragment = (string) mailchimp_get_connected_site_script_fragment();
		if ( '' === $fragment ) {
			return;
		}
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Mailchimp's own markup, as its plugin prints it, made inert.
		echo Gate::inert( $fragment, 'marketing' );
	}
}
