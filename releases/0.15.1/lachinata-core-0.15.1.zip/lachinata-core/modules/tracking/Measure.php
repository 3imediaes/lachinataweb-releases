<?php
/**
 * The measurement of the pages.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Tracking;

use LaChinata\Core\Hooks;
use LaChinata\Core\Services;

defined( 'ABSPATH' ) || exit;

/**
 * What measure.js needs: which adapters are on, the events of the page (view_item,
 * view_cart, search, purchase), the products of the cards and the bag lines
 * (`data-lc-item`) and the events of the previous request (sign-up, login, newsletter, or
 * any module with `lachinata/tracking/event`), which travel in a short cookie. Nothing of
 * this is printed when no measurement service is on.
 */
final class Measure {

	/**
	 * Handle of measure.js.
	 */
	public const SCRIPT = 'lachinata-tracking-measure';

	/**
	 * Cookie with the events for the next page.
	 */
	public const NEXT_COOKIE = 'lc_track_next';

	/**
	 * Services.
	 *
	 * @var Registry|null
	 */
	private static ?Registry $registry = null;

	/**
	 * Events for the next page, of this request.
	 *
	 * @var array<int, array{n: string, p: array<string, mixed>}>
	 */
	private static array $next = array();

	/**
	 * Registers the hooks.
	 *
	 * @param Registry $registry Services.
	 */
	public static function boot( Registry $registry ): void {
		self::$registry = $registry;
		Hooks::add_action( 'wp_enqueue_scripts', array( self::class, 'enqueue' ) );
		Hooks::add_action( 'wp_footer', array( self::class, 'render' ), 6 );
		Hooks::add_filter( 'lachinata/product_card/attributes', array( self::class, 'card' ), 10, 3 );
		Hooks::add_filter( 'lachinata/cart/line_attributes', array( self::class, 'line' ), 10, 2 );
		Hooks::add_action( 'woocommerce_created_customer', static fn() => self::next( 'sign_up', array( 'method' => 'account' ) ) );
		Hooks::add_action( 'wp_login', static fn() => self::next( 'login', array( 'method' => 'password' ) ) );
		Hooks::add_action( 'lachinata/newsletter/subscribed', static fn() => self::next( 'sign_up', array( 'method' => 'newsletter' ) ) );
		Hooks::add_action( 'lachinata/tracking/event', array( self::class, 'next' ), 10, 2 );
	}

	/**
	 * Whether any measurement service is on.
	 */
	public static function active(): bool {
		return Fields::on( 'ga4' ) || Fields::on( 'ads' ) || Fields::on( 'meta' );
	}

	/**
	 * Whether this page measures: a service on and the notice applies. On the checkout,
	 * only when the server can send something (it has no tags).
	 */
	private static function applies(): bool {
		if ( ! self::active() || ! Banner::applies( self::$registry ?? new Registry() ) ) {
			return false;
		}
		return ! self::is_checkout() || Server::ga4() || Server::meta();
	}

	/**
	 * The checkout form (not the order received page).
	 */
	private static function is_checkout(): bool {
		return function_exists( 'is_checkout' ) && is_checkout() && ! is_wc_endpoint_url( 'order-received' ) && ! is_wc_endpoint_url( 'order-pay' );
	}

	/**
	 * The script of the measurement (measure.js), deferred (wp-hooks and wp-data are only used on the checkout, where
	 * WooCommerce loads them).
	 */
	public static function enqueue(): void {
		if ( ! self::applies() ) {
			return;
		}
		$asset = TrackingModule::asset( 'measure' );
		wp_enqueue_script(
			self::SCRIPT,
			plugins_url( 'modules/tracking/build/measure.js', LACHINATA_CORE_FILE ),
			array_values( array_diff( $asset['dependencies'], array( 'wp-hooks', 'wp-data' ) ) ),
			$asset['version'],
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
	}

	/**
	 * `data-lc-item` of a product card.
	 *
	 * @param mixed                $attributes Attributes.
	 * @param mixed                $product    Product.
	 * @param array<string, mixed> $args       Card arguments (list).
	 * @return array<string, string>
	 */
	public static function card( $attributes, $product, $args = array() ): array {
		$attributes = is_array( $attributes ) ? $attributes : array();
		if ( ! $product instanceof \WC_Product || ! self::active() ) {
			return $attributes;
		}
		$list                       = is_array( $args['list'] ?? null ) ? $args['list'] : array();
		$attributes['data-lc-item'] = (string) wp_json_encode( Items::product( $product, 1, $list ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		return $attributes;
	}

	/**
	 * `data-lc-item` of a line of the bag.
	 *
	 * @param mixed $attributes Attributes.
	 * @param mixed $line       Cart item.
	 * @return array<string, string>
	 */
	public static function line( $attributes, $line ): array {
		$attributes = is_array( $attributes ) ? $attributes : array();
		$item       = is_array( $line ) && self::active() ? Items::cart_line( $line ) : null;
		if ( null !== $item ) {
			$attributes['data-lc-item'] = (string) wp_json_encode( $item, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		}
		return $attributes;
	}

	/**
	 * An event for the next page the visitor sees (the one after a login, a sign-up or a
	 * form). Only with a consent: without it nothing is written.
	 *
	 * @param mixed $name   Event (GA4 name: sign_up, login, generate_lead…).
	 * @param mixed $params Parameters (no personal data).
	 */
	public static function next( $name, $params = array() ): void {
		$registry = self::$registry ?? new Registry();
		if ( ! self::active() || headers_sent() || ! ( Consent::allows( $registry, 'analytics' ) || Consent::allows( $registry, 'marketing' ) ) ) {
			return;
		}
		$name = sanitize_key( (string) $name );
		if ( '' === $name ) {
			return;
		}
		$clean = array();
		foreach ( is_array( $params ) ? $params : array() as $key => $value ) {
			if ( is_scalar( $value ) ) {
				$clean[ sanitize_key( (string) $key ) ] = substr( sanitize_text_field( (string) $value ), 0, 100 );
			}
		}
		self::$next[] = array(
			'n' => $name,
			'p' => $clean,
		);
		setcookie(
			self::NEXT_COOKIE,
			rawurlencode( (string) wp_json_encode( array_slice( self::$next, -5 ) ) ),
			array(
				'expires'  => time() + 5 * MINUTE_IN_SECONDS,
				'path'     => '/',
				'secure'   => is_ssl(),
				'httponly' => false,
				'samesite' => 'Lax',
			)
		);
	}

	/**
	 * Configuration of measure.js.
	 *
	 * @return array<string, mixed>
	 */
	public static function config(): array {
		$labels = array();
		foreach ( array(
			'purchase'    => 'ads_label_purchase',
			'add_to_cart' => 'ads_label_add_to_cart',
			'checkout'    => 'ads_label_checkout',
			'lead'        => 'ads_label_lead',
		) as $key => $field ) {
			if ( '' !== Fields::value( $field ) ) {
				$labels[ $key ] = Fields::value( $field );
			}
		}
		return array(
			'ga4'        => Fields::on( 'ga4' ) ? Fields::value( 'ga4_id' ) : '',
			'ga4Server'  => Server::ga4(),
			'ads'        => Fields::on( 'ads' ) ? array(
				'id'          => Fields::value( 'ads_id' ),
				'labels'      => $labels,
				'enhanced'    => (bool) TrackingModule::setting( 'ads_enhanced' ),
				'remarketing' => (bool) TrackingModule::setting( 'ads_remarketing' ),
			) : null,
			'meta'       => Fields::on( 'meta' ) ? Fields::value( 'meta_pixel_id' ) : '',
			'metaServer' => Server::meta(),
			'cookieless' => (bool) TrackingModule::setting( 'google_cookieless' ),
			'currency'   => get_woocommerce_currency(),
			'language'   => Services::languages()->code( Services::languages()->current() ),
			'rest'       => rest_url( ConsentLog::ROUTE_NAMESPACE . '/event' ),
			'checkout'   => self::is_checkout(),
		);
	}

	/**
	 * Events of this page.
	 *
	 * @return array{page: list<array{name: string, data: array<string, mixed>}>, products: array<int, array<string, mixed>>}
	 */
	public static function page(): array {
		$page     = array();
		$products = array();
		if ( is_product() ) {
			$product = wc_get_product( get_queried_object_id() );
			if ( $product instanceof \WC_Product ) {
				$item                           = Items::product( $product );
				$page[]                         = array(
					'name' => 'view_item',
					'data' => array(
						'value' => $item['price'],
						'items' => array( $item ),
					),
				);
				$products[ $product->get_id() ] = $item;
				foreach ( array_slice( $product->get_children(), 0, 50 ) as $child ) {
					$variation = wc_get_product( $child );
					if ( $variation instanceof \WC_Product ) {
						$products[ (int) $child ] = Items::product( $variation );
					}
				}
			}
		} elseif ( function_exists( 'is_cart' ) && is_cart() ) {
			$items  = Items::cart();
			$page[] = array(
				'name' => 'view_cart',
				'data' => array(
					'value' => Items::value( $items ),
					'items' => $items,
				),
			);
		} elseif ( is_search() ) {
			global $wp_query;
			$page[] = array(
				'name' => 'search',
				'data' => array(
					'search_term' => get_search_query( false ),
					'results'     => (int) $wp_query->found_posts,
				),
			);
		} elseif ( function_exists( 'is_order_received_page' ) && is_order_received_page() ) {
			$purchase = self::purchase();
			if ( null !== $purchase ) {
				$page[] = $purchase;
			}
		}
		return array(
			'page'     => $page,
			'products' => $products,
		);
	}

	/**
	 * The purchase of the order received page, once per order (a reload does not repeat
	 * it), only for whoever has the order key.
	 *
	 * @return array{name: string, data: array<string, mixed>}|null
	 */
	private static function purchase(): ?array {
		$order_id = absint( get_query_var( 'order-received' ) );
		$order    = $order_id ? wc_get_order( $order_id ) : null;
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- the order key is the proof, as on WooCommerce's page.
		$key = isset( $_GET['key'] ) ? sanitize_text_field( wp_unslash( $_GET['key'] ) ) : '';
		if ( ! $order instanceof \WC_Order || ! hash_equals( $order->get_order_key(), $key ) || $order->has_status( array( 'failed', 'cancelled', 'pending' ) ) || isset( Server::sent( $order )['browser'] ) ) {
			return null;
		}
		Server::mark( $order, array( 'browser' => time() ) );
		$items = Items::order( $order );
		$data  = Server::purchase_params( $order, $items ) + array(
			'items'    => $items,
			'event_id' => Server::purchase_event_id( $order ),
		);
		if ( TrackingModule::setting( 'ads_enhanced' ) && Consent::allows( self::$registry ?? new Registry(), 'marketing' ) && '' !== $order->get_billing_email() ) {
			$data['user_data'] = array( 'sha256_email_address' => hash( 'sha256', strtolower( trim( $order->get_billing_email() ) ) ) );
		}
		return array(
			'name' => 'purchase',
			'data' => $data,
		);
	}

	/**
	 * The configuration and the events of the page.
	 */
	public static function render(): void {
		if ( ! self::applies() ) {
			return;
		}
		$data = self::config() + self::page();
		printf( '<script type="application/json" id="lc-measure">%s</script>', wp_json_encode( $data, JSON_HEX_TAG | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) );
	}
}
