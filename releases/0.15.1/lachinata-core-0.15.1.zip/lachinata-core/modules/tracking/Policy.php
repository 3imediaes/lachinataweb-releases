<?php
/**
 * The cookie policy.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Tracking;

use LaChinata\Core\Company;
use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * The page is created once from the template (`wp lachinata tracking policy`), with the
 * company data filled in, as a draft marked for legal review. What depends on the services
 * of the shop is never written in it: the block `lachinata/cookie-table` paints, on each
 * visit, the cookie table and the parts of the text that name services (categories,
 * cookieless measurement, recipients and the date of the last change), so the policy
 * stays true when a service is switched on or off.
 */
final class Policy {

	/**
	 * Block name.
	 */
	public const BLOCK = 'lachinata/cookie-table';

	/**
	 * Parts the block can paint.
	 */
	public const SECTIONS = array( 'table', 'categories', 'cookieless', 'recipients', 'updated' );

	/**
	 * Page meta: the text is a draft pending legal review.
	 */
	public const REVIEW_META = '_lc_tracking_review';

	/**
	 * Option with the version of the policy and when it last changed.
	 */
	public const CHANGED_OPTION = 'lachinata_tracking_policy_changed';

	/**
	 * Handle of the editor script of the block.
	 */
	private const EDITOR = 'lachinata-tracking-policy-editor';

	/**
	 * Services of the request.
	 *
	 * @var Registry|null
	 */
	private static ?Registry $registry = null;

	/**
	 * Registers the hooks.
	 *
	 * @param Registry $registry Services.
	 */
	public static function boot( Registry $registry ): void {
		self::$registry = $registry;
		Hooks::add_action( 'init', array( self::class, 'register_block' ) );
		Hooks::add_action( 'admin_init', array( self::class, 'track_version' ) );
	}

	/**
	 * Services, also when booted from WP-CLI or a test.
	 */
	private static function registry(): Registry {
		return self::$registry ?? new Registry();
	}

	/**
	 * Link of the policy (Datos de la empresa → Política de cookies), or empty.
	 */
	public static function url(): string {
		return Company::url( 'cookies_page' );
	}

	/**
	 * Whether the policy page is still marked for legal review.
	 */
	public static function pending_review(): bool {
		$page = (int) Company::get()['cookies_page'];
		return $page > 0 && '1' === get_post_meta( $page, self::REVIEW_META, true );
	}

	/**
	 * Notes the date when the version of the policy changes (a service switched on or
	 * off), for «Última actualización».
	 */
	public static function track_version(): void {
		$version = self::registry()->version();
		$saved   = get_option( self::CHANGED_OPTION );
		if ( ! is_array( $saved ) || ( $saved['version'] ?? '' ) !== $version ) {
			update_option(
				self::CHANGED_OPTION,
				array(
					'version' => $version,
					'at'      => time(),
				),
				false
			);
		}
	}

	/**
	 * Registers the block (rendered on the server; the editor shows that render).
	 */
	public static function register_block(): void {
		$asset = TrackingModule::asset( 'policy' );
		wp_register_script( self::EDITOR, plugins_url( 'modules/tracking/build/policy.js', LACHINATA_CORE_FILE ), $asset['dependencies'], $asset['version'], true );
		wp_set_script_translations( self::EDITOR, 'lachinata-core', LACHINATA_CORE_DIR . '/languages' );
		register_block_type(
			__DIR__ . '/blocks/cookie-table',
			array(
				'editor_script'   => self::EDITOR,
				'render_callback' => Hooks::wrap(
					static fn( $attributes ): string => self::render( is_array( $attributes ) ? (string) ( $attributes['section'] ?? 'table' ) : 'table' ),
					''
				),
			)
		);
	}

	/**
	 * HTML of a part of the policy.
	 *
	 * @param string $section One of SECTIONS.
	 */
	public static function render( string $section ): string {
		$registry = self::registry();
		switch ( $section ) {
			case 'categories':
				return self::categories( $registry );
			case 'cookieless':
				return self::cookieless( $registry );
			case 'recipients':
				return self::recipients( $registry );
			case 'updated':
				$saved = get_option( self::CHANGED_OPTION );
				$at    = is_array( $saved ) && isset( $saved['at'] ) ? (int) $saved['at'] : time();
				/* translators: %s: date. */
				return '<p>' . esc_html( sprintf( __( 'Última actualización: %s', 'lachinata-core' ), wp_date( get_option( 'date_format' ), $at ) ) ) . '</p>';
			default:
				return self::table( $registry );
		}
	}

	/**
	 * Service names of a category as a phrase («Google Analytics», «Google Ads, Meta y Mailchimp»).
	 *
	 * @param Registry $registry Services.
	 * @param string   $category Category.
	 */
	private static function names( Registry $registry, string $category ): string {
		return wp_sprintf_l( '%l', array_map( static fn( array $service ): string => $service['name'], $registry->of( $category ) ) );
	}

	/**
	 * «Qué cookies usamos y para qué»: one paragraph per category of this shop.
	 *
	 * @param Registry $registry Services.
	 */
	private static function categories( Registry $registry ): string {
		$html  = '<p>' . esc_html__( 'Las agrupamos por su finalidad. Solo las necesarias se activan sin preguntarte; las demás, únicamente si las aceptas.', 'lachinata-core' ) . '</p>';
		$html .= '<p><strong>' . esc_html__( 'Necesarias.', 'lachinata-core' ) . '</strong> ' . esc_html__( 'Hacen que la tienda funcione: recordar lo que tienes en la bolsa, mantener tu sesión si entras en tu cuenta, procesar el pago de forma segura y prevenir el fraude, y guardar tu elección sobre las cookies. No necesitan tu consentimiento porque sin ellas no podríamos darte el servicio que pides.', 'lachinata-core' ) . '</p>';
		if ( $registry->of( 'analytics' ) ) {
			/* translators: %s: analytics services («Google Analytics»). */
			$html .= '<p><strong>' . esc_html__( 'Analítica.', 'lachinata-core' ) . '</strong> ' . esc_html( sprintf( __( 'Nos dicen, de forma agregada, cuántas personas visitan la tienda, qué páginas y productos ven, desde dónde llegan y en qué paso de la compra se quedan, para mejorar la web. Usamos %s.', 'lachinata-core' ), self::names( $registry, 'analytics' ) ) ) . '</p>';
		}
		if ( $registry->of( 'marketing' ) ) {
			/* translators: 1: shop name, 2: advertising services («Google Ads, Meta y Mailchimp»). */
			$html .= '<p><strong>' . esc_html__( 'Publicidad.', 'lachinata-core' ) . '</strong> ' . esc_html( sprintf( __( 'Miden el resultado de nuestras campañas y nos permiten mostrarte anuncios de %1$s relacionados con lo que has visto. Usamos %2$s.', 'lachinata-core' ), Company::trade_name(), self::names( $registry, 'marketing' ) ) ) . '</p>';
		}
		$html .= '<p>' . esc_html__( 'El detalle de cada cookie (nombre, quién la instala, para qué sirve y cuánto dura) está en la tabla del final.', 'lachinata-core' ) . '</p>';
		return $html;
	}

	/**
	 * «Medición sin cookies cuando las rechazas»: only with the cookieless setting on (and a
	 * Google service); otherwise nothing is measured without consent and there is nothing to say.
	 *
	 * @param Registry $registry Services.
	 */
	private static function cookieless( Registry $registry ): string {
		$parts = array();
		if ( $registry->google() && TrackingModule::setting( 'google_cookieless' ) ) {
			$parts[] = __( 'Si rechazas la analítica o la publicidad, no instalamos esas cookies. Google puede recibir de nuestra web avisos sin identificadores (sin cookies ni datos tuyos) que solo sirven para estimar de forma estadística cuántas visitas y compras hay en total; es lo que Google llama «modo de consentimiento».', 'lachinata-core' );
		}
		return implode( '', array_map( static fn( string $text ): string => '<p>' . esc_html( $text ) . '</p>', $parts ) );
	}

	/**
	 * «Quién recibe los datos y transferencias internacionales».
	 *
	 * @param Registry $registry Services.
	 */
	private static function recipients( Registry $registry ): string {
		$optional  = $registry->optional();
		$companies = array();
		$dpf       = true;
		$links     = array();
		foreach ( $optional as $service ) {
			$name               = '' === $service['company'] ? $service['provider'] : $service['company'];
			$companies[ $name ] = $name;
			$dpf                = $dpf && $service['dpf'];
			if ( '' !== $service['privacy_url'] ) {
				$links[ $service['provider'] ] = $service['privacy_url'];
			}
		}
		$html = '';
		if ( $companies ) {
			$list  = wp_sprintf_l( '%l', array_values( $companies ) );
			$count = count( $companies );
			$html .= '<p>' . esc_html(
				$dpf
					/* translators: %s: companies («Google Ireland Ltd. y Meta Platforms Ireland Ltd.»). */
					? sprintf( _n( '%s puede tratar los datos de sus cookies como responsable independiente y transferirlos a Estados Unidos. Está adherida al Marco de Privacidad de Datos UE-EE. UU., que la Comisión Europea considera que ofrece garantías adecuadas.', '%s pueden tratar los datos de sus cookies como responsables independientes y transferirlos a Estados Unidos. Están adheridas al Marco de Privacidad de Datos UE-EE. UU., que la Comisión Europea considera que ofrece garantías adecuadas.', $count, 'lachinata-core' ), $list )
					/* translators: %s: companies. */
					: sprintf( _n( '%s puede tratar los datos de sus cookies como responsable independiente y, en algunos casos, transferirlos fuera del Espacio Económico Europeo con las garantías que exige el RGPD.', '%s pueden tratar los datos de sus cookies como responsables independientes y, en algunos casos, transferirlos fuera del Espacio Económico Europeo con las garantías que exige el RGPD.', $count, 'lachinata-core' ), $list )
			) . '</p>';
			$html .= '<p>' . esc_html__( 'Puedes consultar cómo tratan los datos en sus propias políticas:', 'lachinata-core' ) . '</p><ul>';
			foreach ( $links as $provider => $url ) {
				$html .= sprintf( '<li>%1$s: <a href="%2$s" data-no-translation>%3$s</a></li>', esc_html( $provider ), esc_url( $url ), esc_html( (string) preg_replace( '#^https?://(www\.)?#', '', $url ) ) );
			}
			$html .= '</ul>';
		}
		$payments = array_filter( $registry->of( 'necessary' ), static fn( array $service ): bool => '' !== $service['company'] );
		if ( $payments ) {
			/* translators: %s: payment services («Stripe y PayPal»). */
			$html .= '<p>' . esc_html( sprintf( __( 'Los pagos los procesan %s, que instalan sus propias cookies necesarias para la seguridad del pago.', 'lachinata-core' ), wp_sprintf_l( '%l', array_map( static fn( array $service ): string => $service['name'], array_values( $payments ) ) ) ) ) . '</p>';
		}
		return $html;
	}

	/**
	 * The cookie table of the configured services.
	 *
	 * @param Registry $registry Services.
	 */
	private static function table( Registry $registry ): string {
		$labels = array(
			'necessary' => _x( 'Necesaria', 'cookie type', 'lachinata-core' ),
			'analytics' => _x( 'Analítica', 'cookie type', 'lachinata-core' ),
			'marketing' => _x( 'Publicidad', 'cookie type', 'lachinata-core' ),
		);
		$rows   = '';
		foreach ( $registry->all() as $service ) {
			foreach ( $service['cookies'] as $cookie ) {
				$names = array_map( static fn( string $name ): string => '<code data-no-translation>' . esc_html( trim( $name ) ) . '</code>', explode( ',', $cookie['name'] ) );
				$rows .= sprintf(
					'<tr><td>%1$s</td><td data-no-translation>%2$s</td><td>%3$s</td><td>%4$s</td><td>%5$s</td></tr>',
					implode( ', ', $names ),
					esc_html( $cookie['provider'] ),
					esc_html( $cookie['purpose'] ),
					esc_html( $labels[ $service['category'] ] ),
					esc_html( $cookie['duration'] )
				);
			}
		}
		return sprintf(
			'<figure class="wp-block-table lc-cookie-table"><table><thead><tr><th scope="col">%1$s</th><th scope="col">%2$s</th><th scope="col">%3$s</th><th scope="col">%4$s</th><th scope="col">%5$s</th></tr></thead><tbody>%6$s</tbody></table></figure>',
			esc_html__( 'Cookie', 'lachinata-core' ),
			esc_html__( 'Quién la instala', 'lachinata-core' ),
			esc_html__( 'Para qué', 'lachinata-core' ),
			esc_html__( 'Tipo', 'lachinata-core' ),
			esc_html__( 'Duración', 'lachinata-core' ),
			$rows
		);
	}

	/**
	 * The data protection authority of the shop's country, for «Tus derechos».
	 */
	private static function authority(): string {
		$country = function_exists( 'WC' ) && WC()->countries ? WC()->countries->get_base_country() : '';
		$known   = array(
			'ES' => __( 'la Agencia Española de Protección de Datos (aepd.es)', 'lachinata-core' ),
			'CZ' => __( 'la Oficina para la Protección de Datos Personales de la República Checa (uoou.gov.cz)', 'lachinata-core' ),
			'PT' => __( 'la Comissão Nacional de Proteção de Dados (cnpd.pt)', 'lachinata-core' ),
		);
		return $known[ $country ] ?? __( 'la autoridad de protección de datos de tu país', 'lachinata-core' );
	}

	/**
	 * The page content: fixed text with the company data, and the block where the text
	 * depends on the services.
	 *
	 * @return array{content: string, missing: string[]}
	 */
	public static function content(): array {
		$company = Company::get();
		$missing = array();
		$value   = static function ( string $key, string $label ) use ( $company, &$missing ): string {
			$text = trim( (string) ( $company[ $key ] ?? '' ) );
			if ( '' === $text ) {
				$missing[] = $label;
				return '[' . $label . ']';
			}
			return $text;
		};
		$domain  = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		$name    = $value( 'legal_name', __( 'razón social', 'lachinata-core' ) );
		$tax_id  = $value( 'tax_id', __( 'NIF', 'lachinata-core' ) );
		$address = $value( 'address', __( 'domicilio', 'lachinata-core' ) );
		$email   = $value( 'privacy_email', __( 'correo de privacidad', 'lachinata-core' ) );
		$privacy = Company::url( 'privacy_page' );
		if ( '' === $privacy ) {
			$missing[] = __( 'página de privacidad', 'lachinata-core' );
		}

		$block     = static fn( string $section ): string => sprintf( "<!-- wp:%1\$s {\"section\":\"%2\$s\"} /-->\n\n", self::BLOCK, $section );
		$heading   = static fn( string $text ): string => "<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">" . esc_html( $text ) . "</h2>\n<!-- /wp:heading -->\n\n";
		$paragraph = static fn( string $html ): string => "<!-- wp:paragraph -->\n<p>" . $html . "</p>\n<!-- /wp:paragraph -->\n\n";

		$content  = $block( 'updated' );
		$content .= $heading( __( 'Quiénes somos', 'lachinata-core' ) );
		/* translators: 1: domain, 2: legal name, 3: tax id, 4: address, 5: privacy email. */
		$content     .= $paragraph( esc_html( sprintf( __( 'Esta tienda online, %1$s, es de %2$s, con NIF %3$s y domicilio en %4$s. Puedes escribirnos a %5$s para cualquier pregunta sobre esta política o sobre tus datos.', 'lachinata-core' ), $domain, $name, $tax_id, $address, $email ) ) );
		$content     .= $heading( __( 'Qué son las cookies', 'lachinata-core' ) );
		$content     .= $paragraph( esc_html__( 'Las cookies son pequeños archivos que una web guarda en tu navegador para recordar información entre una página y otra o entre una visita y la siguiente. En esta política llamamos «cookies» también a tecnologías parecidas, como el almacenamiento local del navegador o los píxeles de seguimiento.', 'lachinata-core' ) );
		$content     .= $heading( __( 'Qué cookies usamos y para qué', 'lachinata-core' ) );
		$content     .= $block( 'categories' );
		$content     .= $heading( __( 'Cómo das o retiras tu consentimiento', 'lachinata-core' ) );
		$content     .= $paragraph( esc_html__( 'En tu primera visita te mostramos un aviso con tres opciones del mismo tamaño: Aceptar todo, Rechazar todo y Configurar, para elegir tipo a tipo. Hasta que eliges, solo funcionan las cookies necesarias.', 'lachinata-core' ) );
		$content     .= $paragraph( esc_html__( 'Puedes cambiar de opinión cuando quieras desde «Configurar cookies», al pie de todas las páginas. Retirar el consentimiento es igual de fácil que darlo, y no afecta a lo que ya se hizo mientras estaba dado.', 'lachinata-core' ) );
		$content     .= $paragraph( esc_html__( 'Guardamos tu elección durante 12 meses. Pasado ese tiempo, o si cambiamos los servicios que usamos, te volveremos a preguntar.', 'lachinata-core' ) );
		$content     .= $paragraph( esc_html__( 'También puedes bloquear o borrar las cookies desde la configuración de tu navegador. Si bloqueas las necesarias, puede que la bolsa o el pago no funcionen.', 'lachinata-core' ) );
		$content     .= $heading( __( 'Medición sin cookies cuando las rechazas', 'lachinata-core' ) );
		$content     .= $block( 'cookieless' );
		$content     .= $heading( __( 'Quién recibe los datos y transferencias internacionales', 'lachinata-core' ) );
		$content     .= $block( 'recipients' );
		$content     .= $heading( __( 'Tus derechos', 'lachinata-core' ) );
		$privacy_link = '' === $privacy
			? esc_html__( 'política de privacidad', 'lachinata-core' )
			: sprintf( '<a href="%1$s">%2$s</a>', esc_url( $privacy ), esc_html__( 'política de privacidad', 'lachinata-core' ) );
		$content     .= $paragraph(
			wp_kses(
				sprintf(
					/* translators: 1: privacy email, 2: data protection authority, 3: «política de privacidad», linked. */
					__( 'Puedes ejercer tus derechos de acceso, rectificación, supresión, oposición, limitación y portabilidad escribiendo a %1$s. Si crees que no hemos tratado bien tus datos, puedes reclamar ante %2$s. Encontrarás más información en nuestra %3$s.', 'lachinata-core' ),
					esc_html( $email ),
					esc_html( self::authority() ),
					$privacy_link
				),
				array( 'a' => array( 'href' => array() ) )
			)
		);
		$content .= $heading( __( 'Cookies que usamos', 'lachinata-core' ) );
		$content .= $block( 'table' );

		return array(
			'content' => $content,
			'missing' => $missing,
		);
	}

	/**
	 * Creates the policy page (a draft marked for legal review) or rewrites its text.
	 *
	 * @param bool $update Rewrite the text of the page already set in Datos de la empresa.
	 * @return array{page: int, created: bool, missing: string[]}|\WP_Error
	 */
	public static function install( bool $update = false ) {
		$built   = self::content();
		$current = (int) Company::get()['cookies_page'];
		$exists  = $current > 0 && null !== get_post( $current );
		if ( $exists && ! $update ) {
			return new \WP_Error( 'lachinata_policy_exists', __( 'La tienda ya tiene página de política de cookies. Usa --update para reescribir su texto.', 'lachinata-core' ) );
		}
		$postarr = array(
			'post_type'    => 'page',
			'post_title'   => __( 'Política de cookies', 'lachinata-core' ),
			'post_content' => $built['content'],
		);
		if ( $exists ) {
			$postarr['ID'] = $current;
			$page          = wp_update_post( wp_slash( $postarr ), true );
		} else {
			$postarr['post_status'] = 'draft';
			$postarr['post_name']   = sanitize_title( _x( 'politica-de-cookies', 'page slug', 'lachinata-core' ) );
			$page                   = wp_insert_post( wp_slash( $postarr ), true );
		}
		if ( is_wp_error( $page ) ) {
			return $page;
		}
		update_post_meta( (int) $page, self::REVIEW_META, '1' );
		if ( ! $exists ) {
			Company::set_page( 'cookies_page', (int) $page );
		}
		return array(
			'page'    => (int) $page,
			'created' => ! $exists,
			'missing' => $built['missing'],
		);
	}
}
