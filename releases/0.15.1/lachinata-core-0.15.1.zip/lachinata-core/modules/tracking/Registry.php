<?php
/**
 * The services that set cookies or load scripts that need consent.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Tracking;

defined( 'ABSPATH' ) || exit;

/**
 * The list behind the notice, the gate and the cookie table. Each service declares what
 * it is, its category, its cookies, the script handles that must wait for consent and
 * whether it is configured; only configured services count. Other modules and plugins add
 * theirs with `lachinata/tracking/services`. The categories of the notice, the version of
 * the policy and the table come from here, so the policy is always true.
 *
 * @phpstan-type Cookie array{name: string, provider: string, purpose: string, duration: string}
 * @phpstan-type Service array{id: string, name: string, provider: string, company: string, category: string, configured: bool, cookies: list<Cookie>, handles: list<string>, consent_mode: bool, privacy_url: string, dpf: bool}
 */
final class Registry {

	/**
	 * Categories, in the order of the notice.
	 */
	public const CATEGORIES = array( 'necessary', 'analytics', 'marketing' );

	/**
	 * Services of this request, once built.
	 *
	 * @var list<Service>|null
	 */
	private ?array $services = null;

	/**
	 * Generation of the settings the cache was built with.
	 *
	 * @var int
	 */
	private int $built = -1;

	/**
	 * Raised whenever a setting of the module changes, so no registry keeps an old list.
	 *
	 * @var int
	 */
	private static int $generation = 0;

	/**
	 * Generation of the settings: changes whenever one of them does.
	 */
	public static function generation(): int {
		return self::$generation;
	}

	/**
	 * Forgets every cached list (an option `lachinata_tracking_*` changed).
	 *
	 * @param mixed $option Option name.
	 */
	public static function invalidate( $option = '' ): void {
		if ( '' === $option || str_starts_with( (string) $option, 'lachinata_tracking_' ) || str_starts_with( (string) $option, 'woocommerce_' ) ) {
			++self::$generation;
		}
	}

	/**
	 * Configured services, from `lachinata/tracking/services`; malformed entries are left out.
	 *
	 * @return list<Service>
	 */
	public function all(): array {
		if ( null !== $this->services && self::$generation === $this->built ) {
			return $this->services;
		}
		/**
		 * The services that set cookies or load scripts. Each one: `id`, `name`, `provider`
		 * (who sets the cookies, as people know it), `company` (legal entity), `category`
		 * (necessary, analytics or marketing), `configured`, `cookies` (name, provider,
		 * purpose, duration), `handles` (script handles that wait for consent),
		 * `consent_mode` (uses Google's consent mode), `privacy_url` and `dpf` (adhered to
		 * the EU-US Data Privacy Framework).
		 *
		 * @since 0.10.0
		 *
		 * @param array<int, array<string, mixed>> $services The module's own services (shop, WooCommerce, payment, GA4, Google Ads, Meta, Mailchimp).
		 */
		$raw = (array) apply_filters( 'lachinata/tracking/services', array() );
		$out = array();
		$ids = array();
		foreach ( $raw as $service ) {
			$service = is_array( $service ) ? self::normalize( $service ) : null;
			if ( null === $service || ! $service['configured'] || isset( $ids[ $service['id'] ] ) ) {
				continue;
			}
			$ids[ $service['id'] ] = true;
			$out[]                 = $service;
		}
		$this->services = $out;
		$this->built    = self::$generation;
		return $out;
	}

	/**
	 * Forgets the services of this request (after saving settings).
	 */
	public function reset(): void {
		$this->services = null;
		$this->built    = -1;
	}

	/**
	 * Configured services that need consent (analytics and marketing).
	 *
	 * @return list<Service>
	 */
	public function optional(): array {
		return array_values( array_filter( $this->all(), static fn( array $service ): bool => 'necessary' !== $service['category'] ) );
	}

	/**
	 * Configured services of a category.
	 *
	 * @param string $category necessary, analytics or marketing.
	 * @return list<Service>
	 */
	public function of( string $category ): array {
		return array_values( array_filter( $this->all(), static fn( array $service ): bool => $category === $service['category'] ) );
	}

	/**
	 * Categories that need consent and have a service, in order.
	 *
	 * @return string[]
	 */
	public function categories(): array {
		return array_values( array_filter( array( 'analytics', 'marketing' ), fn( string $category ): bool => (bool) $this->of( $category ) ) );
	}

	/**
	 * Whether a configured service uses Google's consent mode.
	 */
	public function google(): bool {
		foreach ( $this->optional() as $service ) {
			if ( $service['consent_mode'] ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Version of the policy: changes when the list of services that need consent changes
	 * (or the shop raises the revision to ask again), so whoever chose before is asked again.
	 */
	public function version(): string {
		$keys = array_map( static fn( array $service ): string => $service['category'] . ':' . $service['id'], $this->optional() );
		sort( $keys );
		$keys[] = 'r' . (int) TrackingModule::setting( 'policy_revision' );
		return substr( md5( implode( '|', $keys ) ), 0, 8 );
	}

	/**
	 * Script handles that wait for a category.
	 *
	 * @return array<string, string> Category by handle.
	 */
	public function handles(): array {
		$out = array();
		foreach ( $this->optional() as $service ) {
			foreach ( $service['handles'] as $handle ) {
				$out[ $handle ] = $service['category'];
			}
		}
		return $out;
	}

	/**
	 * Cookie names (or prefixes ending in `*`) of the services of a category, to delete
	 * them when consent is withdrawn.
	 *
	 * @param string $category analytics or marketing.
	 * @return string[]
	 */
	public function cookie_names( string $category ): array {
		$out = array();
		foreach ( $this->of( $category ) as $service ) {
			foreach ( $service['cookies'] as $cookie ) {
				foreach ( array_map( 'trim', explode( ',', $cookie['name'] ) ) as $name ) {
					if ( '' !== $name ) {
						$out[] = $name;
					}
				}
			}
		}
		return array_values( array_unique( $out ) );
	}

	/**
	 * Category names.
	 *
	 * @return array<string, string>
	 */
	public static function labels(): array {
		return array(
			'necessary' => __( 'Necesarias', 'lachinata-core' ),
			'analytics' => __( 'Analítica', 'lachinata-core' ),
			'marketing' => __( 'Publicidad', 'lachinata-core' ),
		);
	}

	/**
	 * A service as the rest of the module reads it, or null when it is malformed.
	 *
	 * @param array<mixed> $service Raw service.
	 * @return Service|null
	 */
	public static function normalize( array $service ): ?array {
		$id       = is_string( $service['id'] ?? null ) ? sanitize_key( $service['id'] ) : '';
		$category = is_string( $service['category'] ?? null ) ? $service['category'] : '';
		if ( '' === $id || ! in_array( $category, self::CATEGORIES, true ) ) {
			return null;
		}
		$cookies = array();
		foreach ( (array) ( $service['cookies'] ?? array() ) as $cookie ) {
			if ( ! is_array( $cookie ) || ! is_string( $cookie['name'] ?? null ) || '' === $cookie['name'] ) {
				continue;
			}
			$cookies[] = array(
				'name'     => $cookie['name'],
				'provider' => (string) ( $cookie['provider'] ?? $service['provider'] ?? '' ),
				'purpose'  => (string) ( $cookie['purpose'] ?? '' ),
				'duration' => (string) ( $cookie['duration'] ?? '' ),
			);
		}
		$name = is_string( $service['name'] ?? null ) ? $service['name'] : $id;
		return array(
			'id'           => $id,
			'name'         => $name,
			'provider'     => is_string( $service['provider'] ?? null ) ? $service['provider'] : $name,
			'company'      => is_string( $service['company'] ?? null ) ? $service['company'] : '',
			'category'     => $category,
			'configured'   => (bool) ( $service['configured'] ?? false ),
			'cookies'      => $cookies,
			'handles'      => array_values( array_filter( (array) ( $service['handles'] ?? array() ), 'is_string' ) ),
			'consent_mode' => (bool) ( $service['consent_mode'] ?? false ),
			'privacy_url'  => is_string( $service['privacy_url'] ?? null ) ? $service['privacy_url'] : '',
			'dpf'          => (bool) ( $service['dpf'] ?? false ),
		);
	}

	/**
	 * `lachinata/tracking/services`: the services this module knows about, each one
	 * configured only when it is on in this shop.
	 *
	 * @param mixed $services Services registered so far.
	 * @return array<int, mixed>
	 */
	public function builtin( $services ): array {
		$services = is_array( $services ) ? $services : array();
		$host     = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		$google   = array(
			'provider'     => 'Google',
			'company'      => 'Google Ireland Ltd.',
			'consent_mode' => true,
			'privacy_url'  => 'https://policies.google.com/privacy',
			'dpf'          => true,
		);
		$gateways = self::gateways();
		$ga4      = Fields::value( 'ga4_id' );

		$builtin = array(
			array(
				'id'         => 'shop',
				'name'       => __( 'Tienda', 'lachinata-core' ),
				'provider'   => $host,
				'category'   => 'necessary',
				'configured' => true,
				'cookies'    => array(
					array(
						'name'     => Consent::COOKIE,
						'purpose'  => __( 'Guarda tu elección sobre las cookies.', 'lachinata-core' ),
						'duration' => __( '12 meses', 'lachinata-core' ),
					),
				),
			),
			array(
				'id'         => 'woocommerce',
				'name'       => 'WooCommerce',
				'provider'   => $host,
				'category'   => 'necessary',
				'configured' => true,
				'cookies'    => array(
					array(
						'name'     => 'woocommerce_cart_hash, woocommerce_items_in_cart',
						'purpose'  => __( 'Recordar el contenido de la bolsa.', 'lachinata-core' ),
						'duration' => __( 'Sesión', 'lachinata-core' ),
					),
					array(
						'name'     => 'wp_woocommerce_session_*',
						'purpose'  => __( 'Identificar tu bolsa y tu sesión de compra.', 'lachinata-core' ),
						'duration' => __( '2 días', 'lachinata-core' ),
					),
				),
			),
			array(
				'id'         => 'wordpress',
				'name'       => 'WordPress',
				'provider'   => $host,
				'category'   => 'necessary',
				'configured' => true,
				'cookies'    => array(
					array(
						'name'     => 'wordpress_logged_in_*, wordpress_sec_*',
						'purpose'  => __( 'Mantener la sesión de tu cuenta.', 'lachinata-core' ),
						'duration' => __( 'Sesión, o 14 días si marcas «Recordarme»', 'lachinata-core' ),
					),
				),
			),
			array(
				'id'          => 'stripe',
				'name'        => 'Stripe',
				'provider'    => 'Stripe',
				'company'     => 'Stripe Payments Europe, Ltd.',
				'category'    => 'necessary',
				'configured'  => (bool) preg_grep( '/^stripe/', $gateways ),
				'privacy_url' => 'https://stripe.com/privacy',
				'cookies'     => array(
					array(
						'name'     => '__stripe_mid, __stripe_sid',
						'purpose'  => __( 'Prevenir el fraude en el pago.', 'lachinata-core' ),
						'duration' => __( '1 año / 30 minutos', 'lachinata-core' ),
					),
				),
			),
			array(
				'id'          => 'paypal',
				'name'        => 'PayPal',
				'provider'    => 'PayPal',
				'company'     => 'PayPal (Europe) S.à r.l. et Cie, S.C.A.',
				'category'    => 'necessary',
				'configured'  => (bool) preg_grep( '/^(ppcp|paypal)/', $gateways ),
				'privacy_url' => 'https://www.paypal.com/webapps/mpp/ua/privacy-full',
				'cookies'     => array(
					array(
						'name'     => 'ts, tsrce, x-pp-s',
						'purpose'  => __( 'Procesar el pago y prevenir el fraude, solo al pagar con PayPal.', 'lachinata-core' ),
						'duration' => __( 'Sesión a 3 años', 'lachinata-core' ),
					),
				),
			),
			array(
				'id'         => 'ga4',
				'name'       => 'Google Analytics',
				'category'   => 'analytics',
				'configured' => Fields::on( 'ga4' ),
				'cookies'    => array(
					array(
						'name'     => '_ga, _ga_' . ( '' === $ga4 ? '*' : substr( $ga4, 2 ) ),
						'purpose'  => __( 'Distinguir visitas y medir el uso de la tienda.', 'lachinata-core' ),
						'duration' => __( '2 años', 'lachinata-core' ),
					),
				),
			) + $google,
			array(
				'id'         => 'ads',
				'name'       => 'Google Ads',
				'category'   => 'marketing',
				'configured' => Fields::on( 'ads' ),
				'cookies'    => array(
					array(
						'name'     => '_gcl_au, _gcl_aw',
						'purpose'  => __( 'Medir las compras que vienen de nuestros anuncios.', 'lachinata-core' ),
						'duration' => __( '90 días', 'lachinata-core' ),
					),
				),
			) + $google,
			array(
				'id'          => 'meta',
				'name'        => 'Meta',
				'provider'    => 'Meta',
				'company'     => 'Meta Platforms Ireland Ltd.',
				'category'    => 'marketing',
				'configured'  => Fields::on( 'meta' ),
				'privacy_url' => 'https://www.facebook.com/privacy/policy',
				'dpf'         => true,
				'cookies'     => array(
					array(
						'name'     => '_fbp, _fbc',
						'purpose'  => __( 'Medir nuestras campañas en Facebook e Instagram y mostrarte anuncios relacionados.', 'lachinata-core' ),
						'duration' => __( '90 días', 'lachinata-core' ),
					),
				),
			),
			array(
				'id'          => 'mailchimp',
				'name'        => 'Mailchimp',
				'provider'    => 'Mailchimp',
				'company'     => 'The Rocket Science Group LLC (Intuit)',
				'category'    => 'marketing',
				'configured'  => Mailchimp::active() && (bool) TrackingModule::setting( 'mailchimp_consent' ),
				'privacy_url' => 'https://www.intuit.com/privacy/statement/',
				'dpf'         => true,
				'handles'     => Mailchimp::HANDLES,
				'cookies'     => array(
					array(
						'name'     => 'mailchimp_landing_site, mailchimp_campaign_id, mailchimp_email_id, mailchimp_user_email, mailchimp.cart.*',
						'purpose'  => __( 'Atribuir ventas a nuestros correos y recordarte una compra sin terminar.', 'lachinata-core' ),
						'duration' => __( '1 mes', 'lachinata-core' ),
					),
				),
			),
		);
		return array_merge( $builtin, $services );
	}

	/**
	 * Ids of the payment gateways that are on.
	 *
	 * @return string[]
	 */
	private static function gateways(): array {
		if ( ! function_exists( 'WC' ) || ! WC()->payment_gateways() ) {
			return array();
		}
		$out = array();
		foreach ( WC()->payment_gateways()->payment_gateways() as $id => $gateway ) {
			if ( 'yes' === $gateway->enabled ) {
				$out[] = (string) $id;
			}
		}
		return $out;
	}
}
