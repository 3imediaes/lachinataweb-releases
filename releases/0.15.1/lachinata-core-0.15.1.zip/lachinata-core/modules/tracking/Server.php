<?php
/**
 * Events sent from the server.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Tracking;

use LaChinata\Core\Hooks;
use LaChinata\Core\Services;

defined( 'ABSPATH' ) || exit;

/**
 * GA4 by Measurement Protocol (with the API secret) and Meta by the Conversions API (with
 * the token), queued in Action Scheduler so that nothing slows the order or the checkout.
 *
 * - **GA4:** only with the analytics consent, with the visitor's `client_id` and session
 *   read from GA4's cookies (`_ga`, `_ga_<id>`): the purchase (kept in the order from the
 *   checkout), its refunds, the checkout events (begin_checkout, add_shipping_info,
 *   add_payment_info and the `lc_*` of the funnel) and the coupons. Without that consent
 *   nothing goes to GA4. The purchase of GA4 comes only from here when the secret is
 *   there, so it is never counted twice.
 * - **Meta:** Purchase, InitiateCheckout, AddPaymentInfo and AddToCart, only with the
 *   advertising consent, with the `event_id` the pixel uses so that Meta keeps one.
 *
 * Failures go to the gap log and the health; a network error or a 5xx is retried once.
 */
final class Server {

	/**
	 * Action of the queue.
	 */
	public const SEND_HOOK = 'lachinata_tracking_send';

	/**
	 * Order meta with the consent and ids of the visitor at the checkout.
	 */
	public const CONTEXT_META = '_lc_tracking_context';

	/**
	 * Order meta with what was already sent.
	 */
	public const SENT_META = '_lc_tracking_sent';

	/**
	 * Events the page can ask the server to send (the checkout has no third-party tags),
	 * with the parameters each one takes.
	 */
	public const RELAYED = array(
		'begin_checkout'          => array(),
		'add_shipping_info'       => array( 'shipping_tier' ),
		'add_payment_info'        => array( 'payment_type' ),
		'add_to_cart'             => array( 'product_id', 'quantity' ),
		'lc_express_pay'          => array( 'wallet' ),
		'lc_gift'                 => array( 'channel' ),
		'lc_shipping_unavailable' => array( 'reason', 'country' ),
		'lc_checkout_error'       => array( 'field', 'error_type' ),
	);

	/**
	 * Meta's name of a GA4 event sent by the Conversions API.
	 */
	public const META_NAMES = array(
		'purchase'         => 'Purchase',
		'begin_checkout'   => 'InitiateCheckout',
		'add_payment_info' => 'AddPaymentInfo',
		'add_to_cart'      => 'AddToCart',
	);

	/**
	 * Services.
	 *
	 * @var Registry
	 */
	private static ?Registry $registry = null;

	/**
	 * Registers the hooks.
	 *
	 * @param Registry $registry Services.
	 */
	public static function boot( Registry $registry ): void {
		self::$registry = $registry;
		Hooks::add_action( self::SEND_HOOK, array( self::class, 'deliver' ) );
		Hooks::add_action( 'woocommerce_store_api_checkout_update_order_from_request', array( self::class, 'capture' ) );
		Hooks::add_action( 'woocommerce_checkout_order_processed', array( self::class, 'capture_classic' ), 10, 3 );
		Hooks::add_action( 'woocommerce_order_status_changed', array( self::class, 'status' ), 20, 3 );
		Hooks::add_action( 'woocommerce_order_refunded', array( self::class, 'refund' ), 20, 2 );
		Hooks::add_action( 'woocommerce_applied_coupon', array( self::class, 'coupon_applied' ) );
		Hooks::add_filter( 'woocommerce_coupon_error', array( self::class, 'coupon_error' ), 20, 3 );
		Hooks::add_action( 'rest_api_init', array( self::class, 'routes' ) );
	}

	/**
	 * Whether GA4 can be reached from the server.
	 */
	public static function ga4(): bool {
		return Fields::on( 'ga4' ) && '' !== Fields::value( 'ga4_api_secret' );
	}

	/**
	 * Whether Meta can be reached from the server.
	 */
	public static function meta(): bool {
		return Fields::on( 'meta' ) && '' !== Fields::value( 'meta_capi_token' );
	}

	/**
	 * Consent and ids of the visitor of this request (its cookies).
	 *
	 * @return array{analytics: bool, marketing: bool, client_id: string, session_id: string, fbp: string, fbc: string, ip: string, agent: string, url: string}
	 */
	public static function request_context(): array {
		$choice  = Consent::current( self::registry() );
		$cookie  = static fn( string $name ): string => isset( $_COOKIE[ $name ] ) ? sanitize_text_field( wp_unslash( $_COOKIE[ $name ] ) ) : '';
		$client  = '';
		$session = '';
		if ( preg_match( '/^GA\d\.\d\.(\d+\.\d+)$/', $cookie( '_ga' ), $match ) ) {
			$client = $match[1];
		}
		$ga4 = Fields::value( 'ga4_id' );
		if ( '' !== $ga4 ) {
			$raw = $cookie( '_ga_' . substr( $ga4, 2 ) );
			if ( preg_match( '/^GS1\.\d\.(\d+)\./', $raw, $match ) || preg_match( '/^GS2\.\d\.s(\d+)/', $raw, $match ) ) {
				$session = $match[1];
			}
		}
		return array(
			'analytics'  => null !== $choice && $choice['analytics'],
			'marketing'  => null !== $choice && $choice['marketing'],
			'client_id'  => $client,
			'session_id' => $session,
			'fbp'        => (string) preg_replace( '/[^A-Za-z0-9._-]/', '', $cookie( '_fbp' ) ),
			'fbc'        => (string) preg_replace( '/[^A-Za-z0-9._-]/', '', $cookie( '_fbc' ) ),
			'ip'         => class_exists( '\WC_Geolocation' ) ? (string) \WC_Geolocation::get_ip_address() : '',
			'agent'      => isset( $_SERVER['HTTP_USER_AGENT'] ) ? substr( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ), 0, 400 ) : '',
			'url'        => (string) wp_get_referer(),
		);
	}

	/**
	 * Services, also when called before boot (tests, WP-CLI).
	 */
	private static function registry(): Registry {
		return self::$registry ?? new Registry();
	}

	/**
	 * Keeps the consent and ids of the checkout in the order (block checkout).
	 *
	 * @param \WC_Order $order Order being placed.
	 */
	public static function capture( \WC_Order $order ): void {
		$context = self::request_context();
		unset( $context['ip'], $context['agent'] );
		$order->update_meta_data( self::CONTEXT_META, $context );
	}

	/**
	 * Same for the classic checkout (the pay-for-order form).
	 *
	 * @param int   $order_id Order id.
	 * @param mixed $posted   Posted data.
	 * @param mixed $order    Order.
	 */
	public static function capture_classic( $order_id, $posted = null, $order = null ): void {
		unset( $posted );
		$order = $order instanceof \WC_Order ? $order : wc_get_order( (int) $order_id );
		if ( $order instanceof \WC_Order ) {
			self::capture( $order );
			$order->save();
		}
	}

	/**
	 * What was sent for an order.
	 *
	 * @param \WC_Order $order Order.
	 * @return array<string, mixed>
	 */
	public static function sent( \WC_Order $order ): array {
		$sent = $order->get_meta( self::SENT_META );
		return is_array( $sent ) ? $sent : array();
	}

	/**
	 * Marks something as sent for an order.
	 *
	 * @param \WC_Order            $order Order.
	 * @param array<string, mixed> $marks Marks to add.
	 */
	public static function mark( \WC_Order $order, array $marks ): void {
		$order->update_meta_data( self::SENT_META, array_merge( self::sent( $order ), $marks ) );
		$order->save_meta_data();
	}

	/**
	 * The purchase, once, when the order is placed for good: paid (processing, completed)
	 * or waiting for an offline payment (on-hold).
	 *
	 * @param int    $order_id Order id.
	 * @param string $from     Previous status.
	 * @param string $to       New status.
	 */
	public static function status( $order_id, $from, $to ): void {
		unset( $from );
		if ( ! in_array( (string) $to, array( 'processing', 'completed', 'on-hold' ), true ) ) {
			return;
		}
		$order = wc_get_order( (int) $order_id );
		if ( ! $order instanceof \WC_Order || 'shop_order_refund' === $order->get_type() || isset( self::sent( $order )['purchase'] ) ) {
			return;
		}
		$context = $order->get_meta( self::CONTEXT_META );
		$context = is_array( $context ) ? $context : array();
		// GA4 only with the analytics consent and the visitor's ids from GA4's cookies.
		$ga4 = self::ga4() && ! empty( $context['analytics'] ) && '' !== (string) ( $context['client_id'] ?? '' );
		self::mark(
			$order,
			array(
				'purchase'  => time(),
				'client_id' => $ga4 ? (string) $context['client_id'] : '',
			)
		);
		$items  = Items::order( $order );
		$params = self::purchase_params( $order, $items );
		if ( $ga4 ) {
			self::queue_ga4( 'purchase', $params, $items, $context );
		}
		if ( self::meta() && ! empty( $context['marketing'] ) ) {
			self::queue_meta(
				'purchase',
				$params,
				$items,
				array(
					'ip'    => (string) $order->get_customer_ip_address(),
					'agent' => (string) $order->get_customer_user_agent(),
					'email' => (string) $order->get_billing_email(),
					'url'   => $order->get_checkout_order_received_url(),
				) + $context,
				self::purchase_event_id( $order )
			);
		}
	}

	/**
	 * Code of the language of an order («en»): the one it was made in (`translate`,
	 * `_lc_translate_language`), or the default.
	 *
	 * @param \WC_Order $order Order.
	 */
	public static function order_language( \WC_Order $order ): string {
		$languages = Services::languages();
		$language  = (string) $order->get_meta( '_lc_translate_language' );
		return $languages->code( in_array( $language, $languages->languages(), true ) ? $language : $languages->default_language() );
	}

	/**
	 * Parameters of a purchase: `value` products with VAT without shipping, `shipping` with
	 * its VAT, `tax` every VAT of the order.
	 *
	 * @param \WC_Order                  $order Order.
	 * @param list<array<string, mixed>> $items Items (Items::order()).
	 * @return array<string, mixed>
	 */
	public static function purchase_params( \WC_Order $order, array $items ): array {
		$decimals = wc_get_price_decimals();
		$params   = array(
			'transaction_id' => (string) $order->get_order_number(),
			'currency'       => $order->get_currency(),
			'site_language'  => self::order_language( $order ),
			'value'          => Items::value( $items ),
			'tax'            => round( (float) $order->get_total_tax(), $decimals ),
			'shipping'       => round( (float) $order->get_shipping_total() + (float) $order->get_shipping_tax(), $decimals ),
		);
		$coupons  = $order->get_coupon_codes();
		if ( $coupons ) {
			$params['coupon'] = implode( ',', $coupons );
		}
		return $params;
	}

	/**
	 * Id shared by the pixel and the Conversions API for a purchase.
	 *
	 * @param \WC_Order $order Order.
	 */
	public static function purchase_event_id( \WC_Order $order ): string {
		return 'purchase-' . $order->get_order_number();
	}

	/**
	 * A refund to GA4: the amount refunded and, when it is partial, its lines.
	 *
	 * @param int $order_id  Order id.
	 * @param int $refund_id Refund id.
	 */
	public static function refund( $order_id, $refund_id ): void {
		$order  = wc_get_order( (int) $order_id );
		$refund = wc_get_order( (int) $refund_id );
		if ( ! self::ga4() || ! $order instanceof \WC_Order || ! $refund instanceof \WC_Order_Refund ) {
			return;
		}
		$sent = self::sent( $order );
		// A refund goes only where its purchase went: GA4 with the purchase's ids.
		if ( '' === (string) ( $sent['client_id'] ?? '' ) ) {
			return;
		}
		$done = (array) ( $sent['refunds'] ?? array() );
		if ( in_array( (int) $refund_id, $done, true ) ) {
			return;
		}
		$done[] = (int) $refund_id;
		self::mark( $order, array( 'refunds' => $done ) );

		$params = array(
			'transaction_id' => (string) $order->get_order_number(),
			'currency'       => $order->get_currency(),
			'site_language'  => self::order_language( $order ),
			'value'          => round( abs( (float) $refund->get_amount() ), wc_get_price_decimals() ),
		);
		$items  = array();
		foreach ( $refund->get_items() as $line ) {
			$item = $line instanceof \WC_Order_Item_Product ? Items::order_line( $line ) : null;
			if ( null !== $item ) {
				$item['quantity'] = abs( (int) $line->get_quantity() );
				$items[]          = $item;
			}
		}
		$context              = $order->get_meta( self::CONTEXT_META );
		$context              = is_array( $context ) ? $context : array();
		$context['client_id'] = (string) $sent['client_id'];
		self::queue_ga4( 'refund', $params, $items, $context );
	}

	/**
	 * A coupon applied (bag or checkout): `lc_coupon`, only with the analytics consent.
	 *
	 * @param mixed $code Coupon code.
	 */
	public static function coupon_applied( $code ): void {
		self::coupon( 'applied', (string) $code, '' );
	}

	/**
	 * A coupon refused: `lc_coupon` with the WooCommerce error code (never the message).
	 *
	 * @param mixed $message Message (passed through).
	 * @param mixed $code    Error code.
	 * @param mixed $coupon  Coupon.
	 * @return mixed
	 */
	public static function coupon_error( $message, $code = 0, $coupon = null ) {
		self::coupon( 'error', $coupon instanceof \WC_Coupon ? (string) $coupon->get_code() : '', (string) $code );
		return $message;
	}

	/**
	 * Sends `lc_coupon` once per request and result.
	 *
	 * @param string $status applied or error.
	 * @param string $code   Coupon code.
	 * @param string $error  WooCommerce error code.
	 */
	private static function coupon( string $status, string $code, string $error ): void {
		static $done = array();
		$key         = $status . $code . $error;
		if ( isset( $done[ $key ] ) || ( is_admin() && ! wp_doing_ajax() ) || wp_doing_cron() ) {
			return;
		}
		$done[ $key ] = true;
		$params       = array(
			'status' => $status,
			'coupon' => substr( wc_format_coupon_code( $code ), 0, 40 ),
		);
		if ( '' !== $error ) {
			$params['error_code'] = $error;
		}
		self::event( 'lc_coupon', $params );
	}

	/**
	 * An event of this request (the visitor's cookies), with the cart as items where the
	 * event takes them. Only with the consent its destination needs.
	 *
	 * @param string                          $name     GA4 event name.
	 * @param array<string, mixed>            $params   Parameters.
	 * @param string                          $event_id Id shared with the pixel (Meta).
	 * @param list<array<string, mixed>>|null $items Items; null takes the cart for the checkout events.
	 */
	public static function event( string $name, array $params, string $event_id = '', ?array $items = null ): void {
		$context                 = self::request_context();
		$params['site_language'] = (string) ( $params['site_language'] ?? Services::languages()->code( Services::languages()->current() ) );
		if ( null === $items && in_array( $name, array( 'begin_checkout', 'add_shipping_info', 'add_payment_info' ), true ) ) {
			$items = Items::cart();
		}
		$items = $items ?? array();
		if ( $items ) {
			$params['currency'] = get_woocommerce_currency();
			$params['value']    = Items::value( $items );
		}
		if ( self::ga4() && $context['analytics'] && '' !== $context['client_id'] && 'add_to_cart' !== $name ) {
			self::queue_ga4( $name, $params, $items, $context );
		}
		if ( self::meta() && $context['marketing'] && isset( self::META_NAMES[ $name ] ) ) {
			self::queue_meta( $name, $params, $items, $context, '' === $event_id ? $name . '-' . wp_generate_uuid4() : $event_id );
		}
	}

	/**
	 * Queues a GA4 event.
	 *
	 * @param string                     $name    Event.
	 * @param array<string, mixed>       $params  Parameters.
	 * @param list<array<string, mixed>> $items   Items.
	 * @param array<string, mixed>       $context Consent and ids.
	 */
	private static function queue_ga4( string $name, array $params, array $items, array $context ): void {
		if ( empty( $context['analytics'] ) || '' === (string) ( $context['client_id'] ?? '' ) ) {
			return;
		}
		if ( $items ) {
			$params['items'] = array_slice( Items::for_ga4( $items ), 0, 50 );
		}
		if ( '' !== (string) ( $context['session_id'] ?? '' ) ) {
			$params['session_id'] = (string) $context['session_id'];
		}
		$params['engagement_time_msec'] = 1;
		$ads                            = ! empty( $context['marketing'] ) ? 'GRANTED' : 'DENIED';
		self::enqueue(
			array(
				'to'   => 'ga4',
				'name' => $name,
				'body' => array(
					'client_id'        => (string) ( $context['client_id'] ?? '' ),
					'timestamp_micros' => (int) floor( microtime( true ) * 1000000 ),
					'consent'          => array(
						'ad_user_data'       => $ads,
						'ad_personalization' => $ads,
					),
					'events'           => array(
						array(
							'name'   => $name,
							'params' => $params,
						),
					),
				),
			)
		);
	}

	/**
	 * Queues a Meta event.
	 *
	 * @param string                     $name     GA4 name of the event.
	 * @param array<string, mixed>       $params   Parameters.
	 * @param list<array<string, mixed>> $items    Items.
	 * @param array<string, mixed>       $context  Consent, ids, IP, agent, email and URL.
	 * @param string                     $event_id Id shared with the pixel.
	 */
	private static function queue_meta( string $name, array $params, array $items, array $context, string $event_id ): void {
		$user   = array_filter(
			array(
				'client_ip_address' => (string) ( $context['ip'] ?? '' ),
				'client_user_agent' => (string) ( $context['agent'] ?? '' ),
				'fbp'               => (string) ( $context['fbp'] ?? '' ),
				'fbc'               => (string) ( $context['fbc'] ?? '' ),
				'em'                => '' !== (string) ( $context['email'] ?? '' ) ? array( hash( 'sha256', strtolower( trim( (string) $context['email'] ) ) ) ) : null,
			)
		);
		$custom = array(
			'currency'     => (string) ( $params['currency'] ?? get_woocommerce_currency() ),
			'value'        => (float) ( $params['value'] ?? 0 ),
			'content_type' => 'product',
			'content_ids'  => array_values( array_map( static fn( array $item ): string => (string) $item['ids']['meta'], $items ) ),
			'contents'     => array_values(
				array_map(
					static fn( array $item ): array => array(
						'id'         => (string) $item['ids']['meta'],
						'quantity'   => (int) $item['quantity'],
						'item_price' => (float) $item['price'],
					),
					$items
				)
			),
			'num_items'    => array_sum( array_map( static fn( array $item ): int => (int) $item['quantity'], $items ) ),
		);
		if ( isset( $params['transaction_id'] ) ) {
			$custom['order_id'] = (string) $params['transaction_id'];
		}
		$body = array(
			'data' => array(
				array(
					'event_name'       => self::META_NAMES[ $name ],
					'event_time'       => time(),
					'event_id'         => $event_id,
					'action_source'    => 'website',
					'event_source_url' => '' !== (string) ( $context['url'] ?? '' ) ? (string) $context['url'] : home_url( '/' ),
					'user_data'        => $user,
					'custom_data'      => $custom,
				),
			),
		);
		$test = Fields::value( 'meta_test_code' );
		if ( '' !== $test ) {
			$body['test_event_code'] = $test;
		}
		self::enqueue(
			array(
				'to'   => 'meta',
				'name' => $name,
				'body' => $body,
			)
		);
	}

	/**
	 * Puts a request in the queue (or sends it now without Action Scheduler).
	 *
	 * @param array{to: string, name: string, body: array<string, mixed>, attempt?: int} $job Request.
	 */
	private static function enqueue( array $job ): void {
		/**
		 * A request to GA4 or Meta about to be queued (for tests and debugging).
		 *
		 * @since 0.10.0
		 *
		 * @param array<string, mixed> $job `to` (ga4, meta), `name` and `body`, without credentials.
		 */
		do_action( 'lachinata/tracking/queued', $job );
		if ( function_exists( 'as_enqueue_async_action' ) ) {
			as_enqueue_async_action( self::SEND_HOOK, array( 'job' => $job ), ConsentLog::GROUP );
			return;
		}
		self::deliver( $job );
	}

	/**
	 * Sends a queued request, adding the credentials at the last moment.
	 *
	 * @param mixed $job Request.
	 */
	public static function deliver( $job ): void {
		if ( ! is_array( $job ) || ! is_array( $job['body'] ?? null ) ) {
			return;
		}
		$to = (string) ( $job['to'] ?? '' );
		if ( 'ga4' === $to && self::ga4() ) {
			$url = add_query_arg(
				array(
					'measurement_id' => rawurlencode( Fields::value( 'ga4_id' ) ),
					'api_secret'     => rawurlencode( Fields::value( 'ga4_api_secret' ) ),
				),
				Http::GA4
			);
		} elseif ( 'meta' === $to && self::meta() ) {
			$url = Http::GRAPH . Http::graph_version() . '/' . rawurlencode( Fields::value( 'meta_pixel_id' ) ) . '/events?access_token=' . rawurlencode( Fields::value( 'meta_capi_token' ) );
		} else {
			return;
		}
		$result = Http::post( $url, $job['body'] );
		if ( '' === $result['error'] ) {
			return;
		}
		$attempt = (int) ( $job['attempt'] ?? 0 );
		if ( 0 === $attempt && ( 0 === $result['status'] || $result['status'] >= 500 ) && function_exists( 'as_schedule_single_action' ) ) {
			$job['attempt'] = 1;
			as_schedule_single_action( time() + 5 * MINUTE_IN_SECONDS, self::SEND_HOOK, array( 'job' => $job ), ConsentLog::GROUP );
			return;
		}
		TrackingModule::gaps()->record(
			'send:' . $to . ':' . (string) ( $job['name'] ?? '' ),
			sprintf(
				/* translators: 1: event, 2: GA4 or Meta, 3: error. */
				__( 'El evento %1$s no llegó a %2$s: %3$s', 'lachinata-core' ),
				(string) ( $job['name'] ?? '' ),
				'ga4' === $to ? 'GA4' : 'Meta',
				$result['error']
			)
		);
	}

	/**
	 * `POST /lachinata/v1/event`: what the page asks the server to send. Public (visitors
	 * without an account buy), so it takes only known events and parameters, rebuilds the
	 * products from the cart or the catalogue, needs the visitor's consent cookie and is
	 * limited per visitor.
	 */
	public static function routes(): void {
		register_rest_route(
			ConsentLog::ROUTE_NAMESPACE,
			'/event',
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'args'                => array(
					'event'    => array(
						'type'     => 'string',
						'required' => true,
						'enum'     => array_keys( self::RELAYED ),
					),
					'params'   => array(
						'type'    => 'object',
						'default' => array(),
					),
					'event_id' => array(
						'type'    => 'string',
						'default' => '',
						'pattern' => '^[A-Za-z0-9_.:-]{0,64}$',
					),
				),
				'callback'            => Hooks::rest(
					static function ( \WP_REST_Request $request ) {
						if ( ! self::allow_request() ) {
							return new \WP_Error( 'lachinata_event_limit', __( 'Demasiados eventos.', 'lachinata-core' ), array( 'status' => 429 ) );
						}
						$name   = (string) $request['event'];
						$raw    = is_array( $request['params'] ) ? $request['params'] : array();
						$params = array();
						foreach ( self::RELAYED[ $name ] as $key ) {
							if ( isset( $raw[ $key ] ) && is_scalar( $raw[ $key ] ) ) {
								$params[ $key ] = substr( sanitize_text_field( (string) $raw[ $key ] ), 0, 100 );
							}
						}
						if ( function_exists( 'wc_load_cart' ) && null === WC()->cart ) {
							wc_load_cart();
						}
						$items = null;
						if ( 'add_to_cart' === $name ) {
							$product = wc_get_product( (int) ( $params['product_id'] ?? 0 ) );
							if ( ! $product instanceof \WC_Product ) {
								return new \WP_Error( 'lachinata_event_product', __( 'Producto desconocido.', 'lachinata-core' ), array( 'status' => 400 ) );
							}
							$items  = array( Items::product( $product, max( 1, min( 99, (int) ( $params['quantity'] ?? 1 ) ) ) ) );
							$params = array();
						}
						self::event( $name, $params, (string) $request['event_id'], $items );
						return new \WP_REST_Response( array( 'queued' => true ), 202 );
					}
				),
			)
		);
	}

	/**
	 * At most 60 events every 10 minutes per visitor (hash of the IP).
	 */
	private static function allow_request(): bool {
		$ip  = class_exists( '\WC_Geolocation' ) ? (string) \WC_Geolocation::get_ip_address() : '';
		$key = 'lachinata_tracking_rate_' . substr( md5( $ip . wp_salt( 'nonce' ) ), 0, 16 );
		$hit = (int) get_transient( $key );
		if ( $hit >= 60 ) {
			return false;
		}
		set_transient( $key, $hit + 1, 10 * MINUTE_IN_SECONDS );
		return true;
	}
}
