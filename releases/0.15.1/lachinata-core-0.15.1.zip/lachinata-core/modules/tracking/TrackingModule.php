<?php
/**
 * Module `tracking`: cookie consent and commerce measurement.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Tracking;

use LaChinata\Core\GapLog;
use LaChinata\Core\Hooks;
use LaChinata\Core\Module;
use LaChinata\Core\Plugin;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * The cookie notice (ConsentBanner) built from the services each shop has configured
 * (`lachinata/tracking/services`), Google's consent mode, the proof of consent, the cookie
 * policy and, on top of the consent, the measurement adapters (GA4, Google Ads, Meta
 * pixel). Every service is optional: one without its id is not loaded, not in the notice
 * and not in the policy; a shop without any optional service shows no notice at all.
 * Nothing of any shop is in the code: ids, tokens and texts are settings.
 */
final class TrackingModule extends Module {

	/**
	 * Module id.
	 */
	public function id(): string {
		return 'tracking';
	}

	/**
	 * Module name.
	 */
	public function label(): string {
		return __( 'Cookies y medición', 'lachinata-core' );
	}

	/**
	 * Module description.
	 */
	public function description(): string {
		return __( 'Aviso y panel de cookies, modo de consentimiento de Google, registro de pruebas del consentimiento y política de cookies; GA4, Google Ads y el píxel de Meta solo con consentimiento. Cada servicio se activa al rellenar su ID.', 'lachinata-core' );
	}

	/**
	 * Version in which the module was added.
	 */
	public function since(): string {
		return '0.10.0';
	}

	/**
	 * Documentation.
	 */
	public function docs(): string {
		return 'plugin/modules/tracking/README.md';
	}

	/**
	 * Requirements.
	 *
	 * @return array{woocommerce: string}
	 */
	public function requires(): array {
		return array( 'woocommerce' => '10.0' );
	}

	/**
	 * Settings. Ids and secrets belong to each site (`export => false`): copying them to
	 * another shop would mix its data. How the module behaves travels.
	 *
	 * @return array<string, array{type: 'bool'|'int'|'float'|'string'|'array', default: mixed, export?: bool}>
	 */
	public function settings(): array {
		$site = static fn( string $type = 'string', $value = '' ): array => array(
			'type'    => $type,
			'default' => $value,
			'export'  => false,
		);
		$copy = static fn( string $type, $value ): array => array(
			'type'    => $type,
			'default' => $value,
			'export'  => true,
		);
		$out  = array();
		foreach ( Fields::all() as $key => $field ) {
			$out[ $key ] = $site();
			unset( $field );
		}
		return $out + array(
			'ads_enhanced'      => $copy( 'bool', false ),
			'ads_remarketing'   => $copy( 'bool', false ),
			'mailchimp_consent' => $copy( 'bool', true ),
			'google_cookieless' => $copy( 'bool', false ),
			'retention_months'  => $copy( 'int', 36 ),
			'policy_revision'   => $site( 'int', 0 ),
		);
	}

	/**
	 * A setting of the module.
	 *
	 * @param string $key Setting key.
	 * @return mixed
	 */
	public static function setting( string $key ) {
		$module = Plugin::instance()->modules()->get( 'tracking' );
		return null === $module ? null : Settings::get( $module, $key );
	}

	/**
	 * The module, for Settings.
	 */
	public static function instance(): ?Module {
		return Plugin::instance()->modules()->get( 'tracking' );
	}

	/**
	 * Dependencies and version of a compiled script of the module (`build/<name>.asset.php`).
	 *
	 * @param string $name consent, measure or policy.
	 * @return array{dependencies: string[], version: string}
	 */
	public static function asset( string $name ): array {
		$path  = __DIR__ . '/build/' . $name . '.asset.php';
		$asset = file_exists( $path ) ? require $path : array();
		return array(
			'dependencies' => is_array( $asset ) ? array_values( (array) ( $asset['dependencies'] ?? array() ) ) : array(),
			'version'      => is_array( $asset ) ? (string) ( $asset['version'] ?? LACHINATA_CORE_VERSION ) : LACHINATA_CORE_VERSION,
		);
	}

	/**
	 * Failures of the services (an event that did not reach GA4 or Meta, a feed of
	 * consent that could not be written).
	 */
	public static function gaps(): GapLog {
		return new GapLog( 'lachinata_tracking_gaps', 'lachinata-tracking' );
	}

	/**
	 * Version of the data: v1 creates the proof-of-consent table.
	 */
	public function schema_version(): int {
		return 1;
	}

	/**
	 * Steps of the data.
	 *
	 * @return array<int, callable(): void>
	 */
	public function migrations(): array {
		return array( 1 => array( ConsentLog::class, 'install' ) );
	}

	/**
	 * Which services are on, which are misconfigured (off until fixed) and whether the
	 * cookie policy is there.
	 *
	 * @return array{configured: bool, credentials: bool|null, notes: string[]}
	 */
	public function health(): array {
		$registry = new Registry();
		$notes    = array();
		$secrets  = array();
		foreach ( Fields::services() as $service => $label ) {
			$state = Fields::state( $service );
			if ( 'off' === $state ) {
				continue;
			}
			$notes[] = 'ok' === $state
				/* translators: %s: service name (GA4, Google Ads…). */
				? sprintf( __( '%s: activo', 'lachinata-core' ), $label )
				/* translators: %s: service name (GA4, Google Ads…). */
				: sprintf( __( '%s: mal configurado, apagado hasta corregirlo', 'lachinata-core' ), $label );
			foreach ( Fields::secrets( $service ) as $key => $present ) {
				$secrets[ $key ] = $present;
			}
		}
		if ( ! $registry->optional() ) {
			$notes[] = __( 'Sin servicios de analítica ni de publicidad: no hay aviso de cookies.', 'lachinata-core' );
		} elseif ( '' === Policy::url() ) {
			$notes[] = __( 'Falta la página de la política de cookies (Datos de la empresa).', 'lachinata-core' );
		} elseif ( Policy::pending_review() ) {
			$notes[] = __( 'La política de cookies es un borrador pendiente de revisión legal.', 'lachinata-core' );
		}
		return array(
			'configured'  => (bool) $registry->optional(),
			'credentials' => $secrets ? ! in_array( false, $secrets, true ) : null,
			'notes'       => $notes,
		);
	}

	/**
	 * What it keeps beyond its options: the review mark of the policy page, the
	 * proof-of-consent table and the purchase mark of each order (never deleted, as every
	 * order meta).
	 *
	 * @return array{product_meta: string[], order_meta: string[], tables: string[]}
	 */
	public function owned_data(): array {
		return array(
			'product_meta' => array( Policy::REVIEW_META ),
			'order_meta'   => array( '_lc_tracking_sent' ),
			'tables'       => array( ConsentLog::TABLE ),
		);
	}

	/**
	 * Registers the hooks.
	 */
	public function boot(): void {
		$registry = new Registry();
		Hooks::add_filter( 'lachinata/tracking/services', array( $registry, 'builtin' ), 5 );
		foreach ( array( 'added_option', 'updated_option', 'deleted_option' ) as $hook ) {
			Hooks::add_action( $hook, array( Registry::class, 'invalidate' ) );
		}
		Banner::boot( $registry );
		Gate::boot( $registry );
		ConsentLog::boot();
		Policy::boot( $registry );
		Server::boot( $registry );
		Measure::boot( $registry );
		if ( is_admin() ) {
			TrackingTab::boot();
		}
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::add_command( 'lachinata tracking', Cli::class );
		}
	}
}
