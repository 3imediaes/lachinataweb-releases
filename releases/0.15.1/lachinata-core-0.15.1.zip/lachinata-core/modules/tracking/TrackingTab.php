<?php
/**
 * WooCommerce → La Chinata → Cookies y medición.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Tracking;

use LaChinata\Core\Admin\Screen;
use LaChinata\Core\Hooks;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * The state of each service, its ids with the format checked next to the field, the
 * consent (retention, ask everyone again, the choices of the last days) and the policy.
 */
final class TrackingTab {

	/**
	 * Tab id.
	 */
	public const TAB = 'tracking';

	/**
	 * Actions of admin-post.php, also nonce actions; SAVE is also the form id.
	 */
	private const SAVE     = 'lachinata_tracking_settings';
	private const ASK      = 'lachinata_tracking_ask_again';
	private const POLICY   = 'lachinata_tracking_policy';
	private const REVIEWED = 'lachinata_tracking_reviewed';
	private const TEST     = 'lachinata_tracking_test';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/core/admin_tabs', array( self::class, 'tab' ), 34 );
		foreach ( array( self::SAVE, self::ASK, self::POLICY, self::REVIEWED, self::TEST ) as $action ) {
			Hooks::add_action( 'admin_post_' . $action, array( self::class, 'handle' ) );
		}
	}

	/**
	 * Adds the tab before Exportar/importar.
	 *
	 * @param array<string, array{label: string, render: callable}> $tabs Tabs.
	 * @return array<string, array{label: string, render: callable}>
	 */
	public static function tab( array $tabs ): array {
		$tab      = array(
			self::TAB => array(
				'label'  => __( 'Cookies y medición', 'lachinata-core' ),
				'render' => array( self::class, 'render' ),
			),
		);
		$position = array_search( 'transfer', array_keys( $tabs ), true );
		$position = false === $position ? count( $tabs ) : $position;
		return array_slice( $tabs, 0, $position, true ) + $tab + $tabs;
	}

	/**
	 * A small form with one button.
	 *
	 * @param string                $action Action.
	 * @param string                $label  Button text.
	 * @param array<string, string> $fields Hidden fields.
	 */
	private static function button_form( string $action, string $label, array $fields = array() ): void {
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline-block;margin-right:8px">
			<input type="hidden" name="action" value="<?php echo esc_attr( $action ); ?>">
			<?php foreach ( $fields as $name => $value ) : ?>
				<input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>">
			<?php endforeach; ?>
			<?php wp_nonce_field( $action ); ?>
			<?php submit_button( $label, 'secondary', 'submit', false ); ?>
		</form>
		<?php
	}

	/**
	 * State badge of a service.
	 *
	 * @param string $state ok, off or broken.
	 */
	private static function badge( string $state ): string {
		$labels = array(
			'ok'     => array( 'ok', __( 'Activo', 'lachinata-core' ) ),
			'off'    => array( '', __( 'Sin configurar', 'lachinata-core' ) ),
			'broken' => array( 'error', __( 'Mal configurado: apagado', 'lachinata-core' ) ),
		);
		$row    = $labels[ $state ] ?? $labels['off'];
		return sprintf( '<span class="lc-admin-status%1$s">%2$s</span>', '' === $row[0] ? '' : ' lc-admin-status--' . $row[0], esc_html( $row[1] ) );
	}

	/**
	 * One field of a service.
	 *
	 * @param string                $key    Field key.
	 * @param array<string, string> $errors Errors by field.
	 * @param array<string, mixed>  $posted Values typed before an error.
	 */
	private static function field( string $key, array $errors, array $posted ): void {
		$definition = Fields::all()[ $key ];
		$text       = Fields::text( $key );
		$id         = 'lc-tracking-' . $key;
		$saved      = (string) TrackingModule::setting( $key );
		$value      = $definition['secret'] ? '' : (string) ( $posted[ $key ] ?? $saved );
		$described  = $id . '-hint' . ( isset( $errors[ $key ] ) ? ' ' . $id . '-error' : '' );
		?>
		<tr>
			<th scope="row"><label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $text['label'] ); ?></label></th>
			<td>
				<input type="<?php echo $definition['secret'] ? 'password' : 'text'; ?>" class="regular-text code" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $value ); ?>" autocomplete="off" spellcheck="false" placeholder="<?php echo esc_attr( $definition['secret'] && '' !== $saved ? __( 'Guardado (escribe otro para cambiarlo)', 'lachinata-core' ) : $text['placeholder'] ); ?>" aria-describedby="<?php echo esc_attr( $described ); ?>"<?php echo isset( $errors[ $key ] ) ? ' aria-invalid="true"' : ''; ?>>
				<?php if ( $definition['secret'] && '' !== $saved ) : ?>
					<label><input type="checkbox" name="<?php echo esc_attr( $key ); ?>_clear" value="1"> <?php esc_html_e( 'Quitar', 'lachinata-core' ); ?></label>
				<?php endif; ?>
				<?php Screen::field_error( $errors, $key, $id ); ?>
				<p class="description" id="<?php echo esc_attr( $id ); ?>-hint"><?php echo esc_html( $text['help'] ); ?></p>
			</td>
		</tr>
		<?php
	}

	/**
	 * Prints the tab.
	 */
	public static function render(): void {
		$module = TrackingModule::instance();
		if ( null === $module ) {
			return;
		}
		$kept     = Screen::take_field_errors( self::SAVE );
		$errors   = $kept['errors'];
		$posted   = $kept['posted'];
		$registry = new Registry();
		$values   = Settings::all( $module );
		$groups   = array(
			'ga4'  => array( 'ga4_id', 'ga4_api_secret' ),
			'ads'  => array( 'ads_id', 'ads_label_purchase', 'ads_label_add_to_cart', 'ads_label_checkout', 'ads_label_lead' ),
			'meta' => array( 'meta_pixel_id', 'meta_capi_token', 'meta_test_code' ),
		);
		$summary  = ConsentLog::summary();
		$policy   = Policy::url();
		?>
		<p>
			<?php esc_html_e( 'Cada servicio se activa al rellenar su ID y se apaga al vaciarlo. Sin ningún servicio de analítica ni de publicidad, la tienda no muestra aviso de cookies. Nada se carga antes de que la persona elija.', 'lachinata-core' ); ?>
			<a href="<?php echo esc_url( Screen::guide_url( 'tracking' ) ); ?>"><?php esc_html_e( 'Guía de configuración', 'lachinata-core' ); ?></a> ·
			<a href="<?php echo esc_url( Screen::guide_url( 'medicion' ) ); ?>"><?php esc_html_e( 'Guía de medición', 'lachinata-core' ); ?></a>
		</p>
		<table class="widefat striped" style="max-width:720px">
			<thead><tr><th><?php esc_html_e( 'Servicio', 'lachinata-core' ); ?></th><th><?php esc_html_e( 'Tipo', 'lachinata-core' ); ?></th><th><?php esc_html_e( 'Estado', 'lachinata-core' ); ?></th></tr></thead>
			<tbody>
				<?php foreach ( Fields::services() as $service => $label ) : ?>
					<tr>
						<td><?php echo esc_html( $label ); ?></td>
						<td><?php echo esc_html( Registry::labels()[ 'ga4' === $service ? 'analytics' : 'marketing' ] ); ?></td>
						<td><?php echo wp_kses( self::badge( Fields::state( $service ) ), array( 'span' => array( 'class' => array() ) ) ); ?></td>
					</tr>
				<?php endforeach; ?>
				<tr>
					<td>Mailchimp for WooCommerce</td>
					<td><?php echo esc_html( Registry::labels()['marketing'] ); ?></td>
					<td>
						<?php
						if ( ! Mailchimp::active() ) {
							echo wp_kses( self::badge( 'off' ), array( 'span' => array( 'class' => array() ) ) );
						} elseif ( $values['mailchimp_consent'] ) {
							echo wp_kses( self::badge( 'ok' ), array( 'span' => array( 'class' => array() ) ) );
						} else {
							echo '<span class="lc-admin-status lc-admin-status--warn">' . esc_html__( 'Activo sin pedir consentimiento', 'lachinata-core' ) . '</span>';
						}
						?>
					</td>
				</tr>
			</tbody>
		</table>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" novalidate>
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE ); ?>">
			<?php wp_nonce_field( self::SAVE ); ?>
			<?php foreach ( $groups as $service => $keys ) : ?>
				<h2><?php echo esc_html( Fields::services()[ $service ] ); ?></h2>
				<table class="form-table" role="presentation">
					<?php
					foreach ( $keys as $key ) {
						self::field( $key, $errors, $posted );
					}
					?>
					<?php if ( 'ads' === $service ) : ?>
						<tr>
							<th scope="row"><?php esc_html_e( 'Opciones', 'lachinata-core' ); ?></th>
							<td>
								<label><input type="checkbox" name="ads_enhanced" value="1" <?php checked( (bool) $values['ads_enhanced'] ); ?>> <?php esc_html_e( 'Conversiones mejoradas (el correo del comprador, cifrado, solo con consentimiento de publicidad)', 'lachinata-core' ); ?></label><br>
								<label><input type="checkbox" name="ads_remarketing" value="1" <?php checked( (bool) $values['ads_remarketing'] ); ?>> <?php esc_html_e( 'Remarketing dinámico (los IDs de producto del feed de Google)', 'lachinata-core' ); ?></label>
							</td>
						</tr>
					<?php endif; ?>
				</table>
			<?php endforeach; ?>

			<h2><?php esc_html_e( 'Google: medición sin cookies', 'lachinata-core' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Tras rechazar', 'lachinata-core' ); ?></th>
					<td>
						<label><input type="checkbox" name="google_cookieless" value="1" <?php checked( (bool) $values['google_cookieless'] ); ?>> <?php esc_html_e( 'Cargar GA4 y Google Ads también cuando se rechazan, sin cookies (modo de consentimiento avanzado)', 'lachinata-core' ); ?></label>
						<p class="description"><?php esc_html_e( 'Apagado de serie: nada de Google se carga sin consentimiento. Encendido, Google recibe avisos sin identificadores con los que modela las visitas y compras de quien rechaza; la política de cookies lo explica. Antes de encenderlo, consúltalo con quien lleve la parte legal.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
			</table>

			<h2><?php esc_html_e( 'Mailchimp for WooCommerce', 'lachinata-core' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Consentimiento', 'lachinata-core' ); ?></th>
					<td>
						<label><input type="checkbox" name="mailchimp_consent" value="1" <?php checked( (bool) $values['mailchimp_consent'] ); ?>> <?php esc_html_e( 'Sus scripts y cookies (atribución de campañas, captura del correo para carritos abandonados, píxel) solo con consentimiento de publicidad', 'lachinata-core' ); ?></label>
						<p class="description"><?php esc_html_e( 'La sincronización de productos, pedidos y clientes sigue igual: la hace el servidor de la tienda.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
			</table>

			<h2><?php esc_html_e( 'Pruebas del consentimiento', 'lachinata-core' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="lc-tracking-retention"><?php esc_html_e( 'Conservar', 'lachinata-core' ); ?></label></th>
					<td>
						<input type="number" min="1" max="120" class="small-text" id="lc-tracking-retention" name="retention_months" value="<?php echo esc_attr( (string) ( $posted['retention_months'] ?? $values['retention_months'] ) ); ?>" aria-describedby="lc-tracking-retention-hint<?php echo isset( $errors['retention_months'] ) ? ' lc-tracking-retention-error' : ''; ?>"<?php echo isset( $errors['retention_months'] ) ? ' aria-invalid="true"' : ''; ?>> <?php esc_html_e( 'meses', 'lachinata-core' ); ?>
						<?php Screen::field_error( $errors, 'retention_months', 'lc-tracking-retention' ); ?>
						<p class="description" id="lc-tracking-retention-hint"><?php esc_html_e( 'Cada elección se guarda sin datos personales (identificador aleatorio, fecha, versión y opciones) y se borra pasado este plazo. 36 meses: los 12 de vida del consentimiento y los 24 en que prescribe una infracción grave.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>

		<h2><?php esc_html_e( 'Probar conexión', 'lachinata-core' ); ?></h2>
		<p class="description"><?php esc_html_e( 'Envía un evento de prueba al endpoint de validación de GA4 o a «Probar eventos» de Meta (con el código de prueba), sin datos de nadie.', 'lachinata-core' ); ?></p>
		<p>
			<?php
			self::button_form( self::TEST, __( 'Probar GA4', 'lachinata-core' ), array( 'service' => 'ga4' ) );
			self::button_form( self::TEST, __( 'Probar Meta', 'lachinata-core' ), array( 'service' => 'meta' ) );
			?>
		</p>

		<h2><?php esc_html_e( 'Aviso y política', 'lachinata-core' ); ?></h2>
		<p>
			<?php
			echo esc_html(
				sprintf(
					/* translators: 1: version of the policy, 2: accept all, 3: reject all, 4: saved choices. */
					__( 'Versión de la política: %1$s. Elecciones de los últimos 30 días: %2$d aceptar todo, %3$d rechazar todo, %4$d a medida.', 'lachinata-core' ),
					$registry->version(),
					$summary['accept'],
					$summary['reject'],
					$summary['save']
				)
			);
			?>
		</p>
		<p>
			<?php
			if ( '' === $policy ) {
				esc_html_e( 'Aún no hay página de política de cookies.', 'lachinata-core' );
			} else {
				printf( '<a href="%1$s">%2$s</a>', esc_url( $policy ), esc_html__( 'Ver la política de cookies', 'lachinata-core' ) );
				if ( Policy::pending_review() ) {
					echo ' · <strong>' . esc_html__( 'Borrador pendiente de revisión legal.', 'lachinata-core' ) . '</strong>';
				}
			}
			?>
		</p>
		<p>
			<?php
			if ( '' === $policy ) {
				self::button_form( self::POLICY, __( 'Crear la política de cookies (borrador)', 'lachinata-core' ) );
			} elseif ( Policy::pending_review() ) {
				self::button_form( self::REVIEWED, __( 'Marcar como revisada', 'lachinata-core' ) );
			}
			self::button_form( self::ASK, __( 'Volver a preguntar a todos', 'lachinata-core' ) );
			?>
		</p>
		<?php
	}

	/**
	 * Saves the settings, or runs one of the buttons.
	 */
	public static function handle(): void {
		$action = (string) preg_replace( '/^admin_post_/', '', current_action() );
		Screen::check( $action );
		$module = TrackingModule::instance();
		if ( null === $module ) {
			Screen::redirect( self::TAB );
		}
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Screen::check().
		switch ( $action ) {
			case self::ASK:
				Settings::set( $module, 'policy_revision', (int) TrackingModule::setting( 'policy_revision' ) + 1 );
				Screen::flash( 'success', array( __( 'Hecho: quien ya había elegido verá de nuevo el aviso en su próxima visita.', 'lachinata-core' ) ) );
				Screen::redirect( self::TAB );
				// No break: redirect() stops.
			case self::POLICY:
				$result = Policy::install();
				Screen::flash(
					is_wp_error( $result ) ? 'error' : 'success',
					is_wp_error( $result )
						? array( $result->get_error_message() )
						: array_merge(
							array( __( 'Política de cookies creada como borrador, pendiente de revisión legal. Revísala y publícala.', 'lachinata-core' ) ),
							/* translators: %s: list of missing company data. */
							$result['missing'] ? array( sprintf( __( 'Faltan datos de la empresa (quedan entre corchetes): %s.', 'lachinata-core' ), implode( ', ', $result['missing'] ) ) ) : array()
						)
				);
				Screen::redirect( self::TAB );
				// No break: redirect() stops.
			case self::REVIEWED:
				delete_post_meta( (int) \LaChinata\Core\Company::get()['cookies_page'], Policy::REVIEW_META );
				Screen::flash( 'success', array( __( 'Política marcada como revisada.', 'lachinata-core' ) ) );
				Screen::redirect( self::TAB );
				// No break: redirect() stops.
			case self::TEST:
				$service = isset( $_POST['service'] ) ? sanitize_key( wp_unslash( $_POST['service'] ) ) : '';
				$result  = ConnectionTest::run( $service );
				Screen::flash( '' === $result['error'] ? 'success' : 'error', array( '' === $result['error'] ? $result['message'] : $result['error'] ) );
				Screen::redirect( self::TAB );
		}

		$errors = array();
		$typed  = array();
		foreach ( Fields::all() as $key => $field ) {
			$value = isset( $_POST[ $key ] ) ? trim( sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) ) : '';
			if ( $field['secret'] && '' === $value ) {
				continue;
			}
			$error = Fields::error( $key, $value );
			if ( '' !== $error ) {
				$errors[ $key ] = $error;
			}
			if ( ! $field['secret'] ) {
				$typed[ $key ] = $value;
			}
		}
		$retention = isset( $_POST['retention_months'] ) ? (int) $_POST['retention_months'] : 36;
		if ( $retention < 1 || $retention > 120 ) {
			$errors['retention_months'] = __( 'Escribe un número de meses entre 1 y 120.', 'lachinata-core' );
			$typed['retention_months']  = $retention;
		}
		if ( $errors ) {
			Screen::field_errors( self::SAVE, $errors, $typed );
			Screen::flash( 'error', array( __( 'No se ha guardado nada: revisa los campos marcados.', 'lachinata-core' ) ) );
			Screen::redirect( self::TAB );
		}
		foreach ( Fields::all() as $key => $field ) {
			$value = isset( $_POST[ $key ] ) ? trim( sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) ) : '';
			if ( $field['secret'] ) {
				if ( ! empty( $_POST[ $key . '_clear' ] ) ) {
					Settings::set( $module, $key, '' );
				} elseif ( '' !== $value ) {
					Settings::set( $module, $key, $value );
				}
				continue;
			}
			Settings::set( $module, $key, $value );
		}
		foreach ( array( 'ads_enhanced', 'ads_remarketing', 'mailchimp_consent', 'google_cookieless' ) as $key ) {
			Settings::set( $module, $key, ! empty( $_POST[ $key ] ) );
		}
		Settings::set( $module, 'retention_months', $retention );
		// phpcs:enable
		$notes = array( __( 'Ajustes guardados.', 'lachinata-core' ) );
		foreach ( Fields::services() as $service => $label ) {
			if ( 'broken' === Fields::state( $service ) ) {
				/* translators: %s: service name. */
				$notes[] = sprintf( __( '%s queda apagado: le falta un dato obligatorio.', 'lachinata-core' ), $label );
			}
		}
		Screen::flash( count( $notes ) > 1 ? 'warning' : 'success', $notes );
		Screen::redirect( self::TAB );
	}
}
