/**
 * Module `tracking`: the cookie notice (ConsentBanner) and its panel.
 *
 * The bar shows when there is no valid choice (no cookie, an older version of the policy
 * or older than 12 months). «Aceptar todo», «Rechazar todo» and «Guardar mi elección»
 * write the cookie `lc_consent`, send the proof (no personal data) and update Google's
 * consent mode. Then the scripts that wait for a category (printed as
 * `type="text/plain" data-lc-consent`) become real scripts, in order. Withdrawing a
 * category deletes its first-party cookies and reloads, so nothing of it keeps running.
 * Any `[data-lc-consent-open]` (the footer link) reopens the panel.
 *
 * Others listen to `lachinata:consent` on `document` (detail: the choice) or read
 * `window.lcConsent`, which the first script of the `<head>` fills from the cookie.
 */

const FOCUSABLE =
	'a[href], button:not([disabled]), input:not([disabled]), [tabindex]:not([tabindex="-1"])';

const root = document.querySelector('[data-lc-consent]');
const configNode = document.getElementById('lc-consent-config');

/**
 * The choice of the cookie, as the head script read it.
 *
 * @return {{version: string, given: boolean, analytics: boolean, marketing: boolean, id: string}} Choice.
 */
const current = () =>
	window.lcConsent || {
		version: '',
		given: false,
		analytics: false,
		marketing: false,
		id: '',
	};

/**
 * A new random id (32 hex) for the proof of consent.
 *
 * @return {string} Id.
 */
const randomId = () => {
	const bytes = new Uint8Array(16);
	window.crypto.getRandomValues(bytes);
	return [...bytes].map((b) => b.toString(16).padStart(2, '0')).join('');
};

/**
 * Deletes first-party cookies by name or prefix (`_ga_*`) on this host and its parents.
 *
 * @param {string[]} names Names; a trailing `*` matches a prefix.
 */
const deleteCookies = (names) => {
	const present = document.cookie
		.split('; ')
		.map((pair) => pair.split('=')[0])
		.filter(Boolean);
	const parts = window.location.hostname.split('.');
	const domains = [''];
	for (let i = 0; i < parts.length - 1; i++) {
		domains.push(`; domain=.${parts.slice(i).join('.')}`);
	}
	present
		.filter((name) =>
			names.some((pattern) =>
				pattern.endsWith('*')
					? name.startsWith(pattern.slice(0, -1))
					: name === pattern
			)
		)
		.forEach((name) =>
			domains.forEach((domain) => {
				document.cookie = `${name}=; Max-Age=0; path=/${domain}`;
			})
		);
};

/**
 * Turns the inert scripts of the accepted categories into real ones, in document order.
 *
 * @param {{analytics: boolean, marketing: boolean}} choice Choice.
 */
const activate = (choice) => {
	document
		.querySelectorAll('script[type="text/plain"][data-lc-consent]')
		.forEach((inert) => {
			if (!choice[inert.dataset.lcConsent]) {
				return;
			}
			const script = document.createElement('script');
			[...inert.attributes].forEach(({ name, value }) => {
				if (
					!['type', 'data-lc-consent', 'data-lc-module'].includes(
						name
					)
				) {
					script.setAttribute(name, value);
				}
			});
			if (inert.hasAttribute('data-lc-module')) {
				script.type = 'module';
			}
			if (script.src) {
				script.async = false;
			} else {
				script.text = inert.text;
			}
			inert.replaceWith(script);
		});
};

if (root && configNode) {
	const config = JSON.parse(configNode.textContent);
	const bar = root.querySelector('[data-lc-consent-bar]');
	const layer = root.querySelector('[data-lc-consent-layer]');
	const dialog = layer.querySelector('[role="dialog"]');
	const switches = [...layer.querySelectorAll('[data-lc-consent-switch]')];
	let trigger = null;

	const setSwitch = (button, on) => {
		button.setAttribute('aria-checked', on ? 'true' : 'false');
		button.classList.toggle('lc-switch--on', on);
	};

	const behind = () =>
		[...document.body.children].filter(
			(el) => el !== root && !el.contains(root) && el.tagName !== 'SCRIPT'
		);

	const openPanel = (from) => {
		trigger = from || dialog.ownerDocument.activeElement;
		const choice = current();
		switches.forEach((button) =>
			setSwitch(button, !!choice[button.dataset.lcConsentSwitch])
		);
		root.hidden = false;
		layer.hidden = false;
		document.body.classList.add('lc-locked');
		behind().forEach((el) => el.setAttribute('inert', ''));
		dialog.focus();
	};

	const closePanel = () => {
		layer.hidden = true;
		document.body.classList.remove('lc-locked');
		behind().forEach((el) => el.removeAttribute('inert'));
		if (bar.hidden) {
			root.hidden = true;
		}
		if (trigger && document.contains(trigger)) {
			trigger.focus();
		}
		trigger = null;
	};

	const save = (choice, method) => {
		const before = current();
		const id = before.id || randomId();
		const value = [
			config.version,
			`${choice.analytics ? 1 : 0}${choice.marketing ? 1 : 0}`,
			id,
			Math.floor(Date.now() / 1000),
		].join('.');
		const secure = window.location.protocol === 'https:' ? '; Secure' : '';
		document.cookie = `${config.cookie}=${value}; Max-Age=${config.maxAge}; path=/; SameSite=Lax${secure}`;
		window.lcConsent = {
			version: config.version,
			given: true,
			analytics: choice.analytics,
			marketing: choice.marketing,
			id,
		};

		if (config.google && typeof window.gtag === 'function') {
			const ads = choice.marketing ? 'granted' : 'denied';
			window.gtag('consent', 'update', {
				analytics_storage: choice.analytics ? 'granted' : 'denied',
				ad_storage: ads,
				ad_user_data: ads,
				ad_personalization: ads,
			});
		}

		window
			.fetch(config.rest, {
				method: 'POST',
				keepalive: true,
				credentials: 'omit',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({
					id,
					version: config.version,
					analytics: choice.analytics,
					marketing: choice.marketing,
					method,
				}),
			})
			.catch(() => {});

		bar.hidden = true;
		closePanel();
		root.hidden = true;

		const withdrawn = ['analytics', 'marketing'].filter(
			(category) => before.given && before[category] && !choice[category]
		);
		document.dispatchEvent(
			new window.CustomEvent('lachinata:consent', {
				detail: window.lcConsent,
			})
		);
		if (withdrawn.length) {
			deleteCookies(
				withdrawn.flatMap((category) => config.cookies[category] || [])
			);
			window.location.reload();
			return;
		}
		activate(choice);
	};

	const all = (on) =>
		Object.fromEntries(
			['analytics', 'marketing'].map((category) => [
				category,
				on && config.categories.includes(category),
			])
		);

	root.addEventListener('click', (event) => {
		const toggle = event.target.closest('[data-lc-consent-switch]');
		if (toggle) {
			setSwitch(toggle, toggle.getAttribute('aria-checked') !== 'true');
			return;
		}
		const button = event.target.closest('[data-lc-consent-action]');
		if (!button) {
			return;
		}
		const action = button.dataset.lcConsentAction;
		if (action === 'configure') {
			openPanel(button);
		} else if (action === 'close') {
			closePanel();
		} else if (action === 'accept' || action === 'reject') {
			save(all(action === 'accept'), action);
		} else if (action === 'save') {
			const choice = all(false);
			switches.forEach((item) => {
				choice[item.dataset.lcConsentSwitch] =
					item.getAttribute('aria-checked') === 'true';
			});
			save(choice, 'save');
		}
	});

	document.addEventListener('click', (event) => {
		const opener = event.target.closest('[data-lc-consent-open]');
		if (opener) {
			event.preventDefault();
			openPanel(opener);
		}
	});

	document.addEventListener('keydown', (event) => {
		if (layer.hidden) {
			return;
		}
		if (event.key === 'Escape') {
			event.preventDefault();
			closePanel();
			return;
		}
		if (event.key !== 'Tab') {
			return;
		}
		const items = [...dialog.querySelectorAll(FOCUSABLE)].filter(
			(el) => el.offsetParent !== null
		);
		const first = items[0];
		const last = items[items.length - 1];
		const active = dialog.ownerDocument.activeElement;
		if (event.shiftKey && (active === first || active === dialog)) {
			event.preventDefault();
			last.focus();
		} else if (!event.shiftKey && active === last) {
			event.preventDefault();
			first.focus();
		}
	});

	const choice = current();
	const showBar = () => {
		root.hidden = false;
		bar.hidden = false;
	};
	if (choice.given) {
		activate(choice);
	} else if (!config.quiet) {
		// Never with the destination picker: first the destination, then the cookies
		// (`locale` marks the page and says when the picker is done).
		if (document.documentElement.hasAttribute('data-lc-locale-pending')) {
			document.addEventListener('lachinata:locale:done', showBar, {
				once: true,
			});
		} else {
			showBar();
		}
	}

	window.lachinata = window.lachinata || {};
	window.lachinata.consent = { get: current, open: () => openPanel(null) };
}
