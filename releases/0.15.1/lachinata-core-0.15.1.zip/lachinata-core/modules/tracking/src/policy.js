/**
 * Module `tracking`: the editor of the block «Política de cookies: parte automática».
 * It is rendered on the server with the services of the shop, so the editor shows that
 * render and only chooses which part.
 */
import { registerBlockType } from '@wordpress/blocks';
import { InspectorControls, useBlockProps } from '@wordpress/block-editor';
import { PanelBody, SelectControl } from '@wordpress/components';
import { __ } from '@wordpress/i18n';
import ServerSideRender from '@wordpress/server-side-render';

const SECTIONS = [
	{ value: 'table', label: __('Tabla de cookies', 'lachinata-core') },
	{
		value: 'categories',
		label: __('Qué cookies usamos y para qué', 'lachinata-core'),
	},
	{
		value: 'cookieless',
		label: __('Medición sin cookies', 'lachinata-core'),
	},
	{
		value: 'recipients',
		label: __('Quién recibe los datos', 'lachinata-core'),
	},
	{ value: 'updated', label: __('Última actualización', 'lachinata-core') },
];

const Edit = ({ attributes, setAttributes }) => (
	<div {...useBlockProps()}>
		<InspectorControls>
			<PanelBody title={__('Parte de la política', 'lachinata-core')}>
				<SelectControl
					label={__('Qué muestra', 'lachinata-core')}
					help={__(
						'Se calcula con los servicios activos de la tienda: no se escribe a mano.',
						'lachinata-core'
					)}
					value={attributes.section}
					options={SECTIONS}
					onChange={(section) => setAttributes({ section })}
					__nextHasNoMarginBottom
				/>
			</PanelBody>
		</InspectorControls>
		<ServerSideRender
			block="lachinata/cookie-table"
			attributes={attributes}
		/>
	</div>
);

registerBlockType('lachinata/cookie-table', {
	edit: Edit,
	save: () => null,
});
