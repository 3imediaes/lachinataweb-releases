<?php
/**
 * Whether a page exists in a language.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

defined( 'ABSPATH' ) || exit;

/**
 * A page exists in a language only when it is translated whole: every required field whose
 * Spanish is not empty has its translation (07-traduccion.md, «URL»). Kinds with addresses
 * (those that declare a slug: products, pages, entries, categories) follow that rule; the
 * rest (images, menu items, variations, attribute terms) are translated field by field.
 * The answer is kept as meta of the object (`_lc_translate_in`, one row per language) and
 * recalculated whenever a translation or the Spanish changes, so lists and sitemaps query it.
 */
final class Availability {

	/**
	 * Languages where a post or a term exists (one row per language).
	 */
	public const META = '_lc_translate_in';

	/**
	 * Whether a post or a term exists in a language.
	 *
	 * @param string $type     «post» or «term».
	 * @param int    $id       Object id.
	 * @param string $language Locale.
	 */
	public static function is( string $type, int $id, string $language ): bool {
		if ( Config::default_language() === $language ) {
			return true;
		}
		if ( ! isset( Config::languages()[ $language ] ) ) {
			return false;
		}
		$subtype = Fields::subtype( $type, $id );
		if ( null === $subtype ) {
			return false;
		}
		if ( ! self::whole( $type, $subtype ) ) {
			return true;
		}
		if ( 'post' === $type && (int) get_option( 'page_on_front' ) === $id ) {
			// The home is the blocks of the home, not the text of its page.
			return true;
		}
		return in_array( $language, array_map( 'strval', (array) get_metadata( $type, $id, self::META, false ) ), true );
	}

	/**
	 * Whether a kind of object exists in a language only when translated whole: those
	 * with addresses (a declared slug).
	 *
	 * @param string $type    «post» or «term».
	 * @param string $subtype Post type or taxonomy.
	 */
	public static function whole( string $type, string $subtype ): bool {
		return isset( Fields::of( $type, $subtype )['slug'] );
	}

	/**
	 * Recalculates the languages of an object and writes them.
	 *
	 * @param string $type «post» or «term».
	 * @param int    $id   Object id.
	 * @return string[] Languages where it exists, besides the default.
	 */
	public static function refresh( string $type, int $id ): array {
		$subtype = Fields::subtype( $type, $id );
		if ( null === $subtype || ! self::whole( $type, $subtype ) ) {
			return array();
		}
		$fields  = Fields::of( $type, $subtype );
		$sources = array();
		foreach ( $fields as $name => $field ) {
			if ( $field['required'] ) {
				$sources[ $name ] = Fields::source( $type, $id, $field );
			}
		}
		$in = array();
		foreach ( array_keys( Config::languages() ) as $language ) {
			$rows  = Store::get( $type, $id, $language );
			$whole = true;
			foreach ( $sources as $name => $source ) {
				if ( Fields::has_text( $source ) && '' === trim( (string) ( $rows[ $name ]['text'] ?? '' ) ) ) {
					$whole = false;
					break;
				}
			}
			if ( $whole ) {
				$in[] = $language;
			}
		}
		$current = array_map( 'strval', (array) get_metadata( $type, $id, self::META, false ) );
		if ( $current !== $in ) {
			delete_metadata( $type, $id, self::META );
			foreach ( $in as $language ) {
				add_metadata( $type, $id, self::META, $language );
			}
			/**
			 * The languages where a post or a term exists changed (sitemaps, caches).
			 *
			 * @since 0.15.0
			 *
			 * @param string   $type      «post» or «term».
			 * @param int      $id        Object id.
			 * @param string[] $languages Languages where it exists now, besides the default.
			 */
			do_action( 'lachinata/translate/availability_changed', $type, $id, $in );
		}
		return $in;
	}
}
