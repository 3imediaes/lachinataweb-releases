<?php
/**
 * Languages of the shop.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

defined( 'ABSPATH' ) || exit;

/**
 * The default language (the site's, never translated: everything is written in it) and
 * the others of this shop, each with the code of its addresses and of `hreflang` («en» for
 * «en_GB») and its name. They are a setting of the module, never code: lachinata.es has
 * English; canarias and cz have the module switched off.
 */
final class Config {

	/**
	 * The site's locale, read before the module filters it.
	 *
	 * @var string
	 */
	private static string $default = '';

	/**
	 * Other languages, once read.
	 *
	 * @var array<string, array{code: string, label: string}>|null
	 */
	private static ?array $languages = null;

	/**
	 * Keeps the site's locale (on boot, before the `locale` filter of the module).
	 */
	public static function capture(): void {
		self::$default = (string) get_locale();
	}

	/**
	 * The default language.
	 */
	public static function default_language(): string {
		if ( '' === self::$default ) {
			self::capture();
		}
		return self::$default;
	}

	/**
	 * The other languages, by locale.
	 *
	 * @return array<string, array{code: string, label: string}>
	 */
	public static function languages(): array {
		if ( null === self::$languages ) {
			self::$languages = self::clean( TranslateModule::setting( 'languages' ) );
		}
		return self::$languages;
	}

	/**
	 * Every language of the shop, the default first.
	 *
	 * @return string[]
	 */
	public static function all(): array {
		return array_merge( array( self::default_language() ), array_keys( self::languages() ) );
	}

	/**
	 * Language of an address code («en»), null when none is.
	 *
	 * @param string $code Code.
	 */
	public static function by_code( string $code ): ?string {
		foreach ( self::languages() as $locale => $language ) {
			if ( $language['code'] === $code ) {
				return $locale;
			}
		}
		return null;
	}

	/**
	 * Code of a language («en»); for the default, the language part of its locale.
	 *
	 * @param string $language Locale.
	 */
	public static function code( string $language ): string {
		return self::languages()[ $language ]['code'] ?? strtolower( (string) strtok( $language, '_' ) );
	}

	/**
	 * Name of a language for people, '' when it has none here.
	 *
	 * @param string $language Locale.
	 */
	public static function label( string $language ): string {
		return self::languages()[ $language ]['label'] ?? '';
	}

	/**
	 * Valid rows of languages: a locale («en_GB»), a code of two or three letters that no
	 * other uses (nor the default language), a name; never the default language.
	 *
	 * @param mixed $rows Rows (a list of {locale, code, label}).
	 * @return array<string, array{code: string, label: string}>
	 */
	public static function clean( $rows ): array {
		$out   = array();
		$codes = array( strtolower( (string) strtok( self::default_language(), '_' ) ) => true );
		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$locale = (string) ( $row['locale'] ?? '' );
			$code   = strtolower( (string) ( $row['code'] ?? '' ) );
			$code   = '' === $code ? strtolower( (string) strtok( $locale, '_' ) ) : $code;
			if ( ! preg_match( '/^[a-z]{2,3}(_[A-Z]{2})?$/', $locale ) || ! preg_match( '/^[a-z]{2,3}$/', $code ) || self::default_language() === $locale || isset( $codes[ $code ] ) ) {
				continue;
			}
			$codes[ $code ] = true;
			$out[ $locale ] = array(
				'code'  => $code,
				'label' => sanitize_text_field( (string) ( $row['label'] ?? '' ) ),
			);
		}
		return $out;
	}

	/**
	 * Problems of rows of languages, for the import and the panel.
	 *
	 * @param mixed $rows Rows.
	 * @return string[]
	 */
	public static function validate( $rows ): array {
		$count = is_array( $rows ) ? count( $rows ) : 0;
		if ( count( self::clean( $rows ) ) === $count ) {
			return array();
		}
		return array( __( 'Idiomas: cada uno necesita un locale («en_GB»), un código de dirección distinto («en») y no puede ser el idioma del sitio.', 'lachinata-core' ) );
	}

	/**
	 * Forgets what was read (after saving, tests).
	 */
	public static function reset(): void {
		self::$languages = null;
	}
}
