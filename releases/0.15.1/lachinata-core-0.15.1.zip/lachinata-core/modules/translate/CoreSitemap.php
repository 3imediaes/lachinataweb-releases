<?php
/**
 * Sitemap of a language in WordPress's own sitemaps.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

defined( 'ABSPATH' ) || exit;

/**
 * Without Rank Math: `wp-sitemap-translate-en-1.xml`, one subtype per language.
 */
final class CoreSitemap extends \WP_Sitemaps_Provider {

	/**
	 * Name and kind of object.
	 */
	public function __construct() {
		$this->name        = 'translate';
		$this->object_type = 'translate';
	}

	/**
	 * One subtype per language, by its code.
	 *
	 * @return array<string, object>
	 */
	public function get_object_subtypes() {
		$out = array();
		foreach ( Config::languages() as $language ) {
			$out[ $language['code'] ] = (object) array( 'name' => $language['code'] );
		}
		return $out;
	}

	/**
	 * Addresses of a page of a language.
	 *
	 * @param int    $page_num        Page.
	 * @param string $object_subtype  Code of the language.
	 * @return array<int, array{loc: string, lastmod: string}>
	 */
	public function get_url_list( $page_num, $object_subtype = '' ) {
		$language = Config::by_code( (string) $object_subtype );
		if ( null === $language ) {
			return array();
		}
		$max = wp_sitemaps_get_max_urls( $this->object_type );
		return array_map(
			static fn( array $entry ): array => array(
				'loc'     => $entry['url'],
				'lastmod' => $entry['modified'],
			),
			array_slice( Entries::all( $language ), ( max( 1, (int) $page_num ) - 1 ) * $max, $max )
		);
	}

	/**
	 * Pages of a language.
	 *
	 * @param string $object_subtype Code of the language.
	 */
	public function get_max_num_pages( $object_subtype = '' ) {
		$language = Config::by_code( (string) $object_subtype );
		return null === $language ? 0 : (int) ceil( count( Entries::all( $language ) ) / wp_sitemaps_get_max_urls( $this->object_type ) );
	}
}
