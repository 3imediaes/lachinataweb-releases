<?php
/**
 * Emails in the language of the order.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * An order keeps the language it was made in (`_lc_translate_language`), and every email
 * to its buyer goes in that language: subject, texts of the theme, product names and links.
 * The emails to the shop always go in the default language. The lines of the order keep the
 * Spanish names, the ones Odoo and the panel read; the email translates them as it renders.
 */
final class Emails {

	/**
	 * Language of an order (order meta).
	 */
	public const META = '_lc_translate_language';

	/**
	 * Emails switched to a language, by object id.
	 *
	 * @var array<int, true>
	 */
	private static array $switched = array();

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'woocommerce_checkout_create_order', array( self::class, 'remember' ) );
		Hooks::add_action( 'woocommerce_store_api_checkout_update_order_meta', array( self::class, 'remember' ) );
		Hooks::add_action( 'woocommerce_checkout_create_order_line_item', array( self::class, 'line' ), 20 );
		Hooks::add_filter( 'woocommerce_email_classes', array( self::class, 'emails' ), 99 );
		Hooks::add_filter( 'woocommerce_allow_restoring_email_locale', array( self::class, 'restore' ), 1, 2 );
	}

	/**
	 * The language of the request, kept in the order.
	 *
	 * @param mixed $order Order.
	 */
	public static function remember( $order ): void {
		if ( $order instanceof \WC_Order ) {
			$order->update_meta_data( self::META, Service::instance()->current() );
		}
	}

	/**
	 * Language of an order: the one it was made in, or the default.
	 *
	 * @param \WC_Order $order Order.
	 */
	public static function language( \WC_Order $order ): string {
		$language = (string) $order->get_meta( self::META );
		return in_array( $language, Config::all(), true ) ? $language : Config::default_language();
	}

	/**
	 * The line of a product with its Spanish name, whatever the language of the checkout.
	 *
	 * @param mixed $item Line.
	 */
	public static function line( $item ): void {
		if ( ! $item instanceof \WC_Order_Item_Product ) {
			return;
		}
		$id   = $item->get_variation_id() > 0 ? $item->get_variation_id() : $item->get_product_id();
		$name = (string) get_post_field( 'post_title', $id, 'raw' );
		if ( '' !== $name ) {
			$item->set_name( $name );
		}
	}

	/**
	 * Listens to the recipient of each email: it is asked once the email knows its order
	 * and before its subject and content are written.
	 *
	 * @param mixed $emails Emails of WooCommerce.
	 * @return mixed
	 */
	public static function emails( $emails ) {
		foreach ( is_array( $emails ) ? $emails : array() as $email ) {
			if ( $email instanceof \WC_Email ) {
				Hooks::add_filter( 'woocommerce_email_recipient_' . $email->id, array( self::class, 'recipient' ), 99, 3 );
			}
		}
		return $emails;
	}

	/**
	 * Switches to the language of the email: the order's for the buyer, the default for
	 * the shop.
	 *
	 * @param mixed $recipient Recipient.
	 * @param mixed $order     Object of the email.
	 * @param mixed $email     Email.
	 * @return mixed
	 */
	public static function recipient( $recipient, $order = null, $email = null ) {
		if ( ! $email instanceof \WC_Email || isset( self::$switched[ spl_object_id( $email ) ] ) || ! doing_action( 'woocommerce_email_recipient_' . $email->id ) ) {
			return $recipient;
		}
		if ( $email->is_customer_email() && ! $order instanceof \WC_Order ) {
			return $recipient;
		}
		$language = $email->is_customer_email() && $order instanceof \WC_Order ? self::language( $order ) : Config::default_language();
		Service::instance()->switch_to( $language );
		self::$switched[ spl_object_id( $email ) ] = true;
		return $recipient;
	}

	/**
	 * Back to the language before the email, before WooCommerce restores its own.
	 *
	 * @param mixed $allow Whether WooCommerce restores.
	 * @param mixed $email Email.
	 * @return mixed
	 */
	public static function restore( $allow, $email = null ) {
		if ( $email instanceof \WC_Email && isset( self::$switched[ spl_object_id( $email ) ] ) ) {
			unset( self::$switched[ spl_object_id( $email ) ] );
			Service::instance()->restore();
		}
		return $allow;
	}
}
