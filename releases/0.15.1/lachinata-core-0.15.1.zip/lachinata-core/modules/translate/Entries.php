<?php
/**
 * What exists in a language.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

defined( 'ABSPATH' ) || exit;

/**
 * The published posts and the terms with addresses that exist in a language, with their
 * address there and their date, for the sitemaps. Kept for the request.
 */
final class Entries {

	/**
	 * Entries of this request, by language.
	 *
	 * @var array<string, array<int, array{url: string, modified: string}>>
	 */
	private static array $cache = array();

	/**
	 * Everything that exists in a language, the home first.
	 *
	 * @param string $language Locale.
	 * @return array<int, array{url: string, modified: string}>
	 */
	public static function all( string $language ): array {
		if ( isset( self::$cache[ $language ] ) ) {
			return self::$cache[ $language ];
		}
		$service = Service::instance();
		$out     = array(
			array(
				'url'      => Links::generic( home_url( '/' ), $language ),
				'modified' => '',
			),
		);
		$types   = array_values( array_filter( Fields::subtypes( 'post' ), static fn( string $type ): bool => Availability::whole( 'post', $type ) && is_post_type_viewable( $type ) ) );
		if ( $types ) {
			$ids = get_posts(
				array(
					'post_type'        => $types,
					'post_status'      => 'publish',
					'posts_per_page'   => -1,
					'fields'           => 'ids',
					'orderby'          => 'ID',
					'order'            => 'ASC',
					'suppress_filters' => true,
					'meta_query'       => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- indexed by key, for the sitemap.
						array(
							'key'   => Availability::META,
							'value' => $language,
						),
					),
				)
			);
			foreach ( $ids as $id ) {
				if ( (int) get_option( 'page_on_front' ) === (int) $id ) {
					continue;
				}
				$out[] = array(
					'url'      => $service->post_url( (int) $id, $language ),
					'modified' => (string) get_post_field( 'post_modified_gmt', (int) $id, 'raw' ),
				);
			}
		}
		$taxonomies = array_values( array_filter( Fields::subtypes( 'term' ), static fn( string $taxonomy ): bool => Availability::whole( 'term', $taxonomy ) && is_taxonomy_viewable( $taxonomy ) ) );
		if ( $taxonomies ) {
			$terms = get_terms(
				array(
					'taxonomy'   => $taxonomies,
					'hide_empty' => true,
					'fields'     => 'ids',
					'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- indexed by key, for the sitemap.
						array(
							'key'   => Availability::META,
							'value' => $language,
						),
					),
				)
			);
			foreach ( is_array( $terms ) ? $terms : array() as $id ) {
				$out[] = array(
					'url'      => $service->term_url( (int) $id, $language ),
					'modified' => '',
				);
			}
		}
		self::$cache[ $language ] = $out;
		return $out;
	}

	/**
	 * Date of the newest entry of a language.
	 *
	 * @param string $language Locale.
	 */
	public static function lastmod( string $language ): string {
		$dates = array_filter( array_column( self::all( $language ), 'modified' ) );
		return $dates ? (string) max( $dates ) : '';
	}

	/**
	 * Forgets what was read (tests).
	 */
	public static function reset(): void {
		self::$cache = array();
	}
}
