<?php
/**
 * Texts in the language of the request.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * Puts the translated fields where WordPress, WooCommerce and the theme read them: titles,
 * content and excerpts of the posts of a page, the getters of the products, the meta
 * declared as translatable (Rank Math, the modules' own), terms, menu items and the names
 * of the lines of an order (emails). Only when the request is in another language, never in
 * the panel and never while reading the Spanish (raw()). A page that does not exist in that
 * language shows its Spanish whole: never a page half translated.
 */
final class Front {

	/**
	 * Depth of raw(): while above zero, nothing is translated.
	 *
	 * @var int
	 */
	private static int $raw = 0;

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'the_posts', array( self::class, 'posts' ), 5 );
		Hooks::add_filter( 'the_title', array( self::class, 'title' ), 5, 2 );
		Hooks::add_filter( 'get_the_excerpt', array( self::class, 'excerpt' ), 5, 2 );
		Hooks::add_filter( 'content_pagination', array( self::class, 'pages' ), 5, 2 );
		Hooks::add_filter( 'get_post_metadata', array( self::class, 'post_meta' ), 5, 4 );
		Hooks::add_filter( 'get_term_metadata', array( self::class, 'term_meta' ), 5, 4 );
		Hooks::add_filter( 'get_term', array( self::class, 'term' ), 5 );
		Hooks::add_filter( 'get_terms', array( self::class, 'terms' ), 5 );
		Hooks::add_filter( 'woocommerce_product_get_name', array( self::class, 'product_name' ), 5, 2 );
		Hooks::add_filter( 'woocommerce_product_get_short_description', array( self::class, 'product_short_description' ), 5, 2 );
		Hooks::add_filter( 'woocommerce_product_get_description', array( self::class, 'product_description' ), 5, 2 );
		Hooks::add_filter( 'woocommerce_product_variation_get_name', array( self::class, 'variation' ), 5, 2 );
		Hooks::add_filter( 'woocommerce_order_item_get_name', array( self::class, 'order_item' ), 5, 2 );
		Hooks::add_filter( 'wp_setup_nav_menu_item', array( self::class, 'menu_item' ), 20 );
	}

	/**
	 * Whether texts and links are translated now: a request (or a switch) in another
	 * language, outside raw().
	 */
	public static function active(): bool {
		// Before `init` there are no post types or fields to translate.
		return 0 === self::$raw && did_action( 'init' ) && Service::instance()->current() !== Config::default_language();
	}

	/**
	 * Runs something reading the Spanish as it is stored.
	 *
	 * @template T
	 * @param callable(): T $callback What to run.
	 * @return T
	 */
	public static function raw( callable $callback ) {
		++self::$raw;
		try {
			return $callback();
		} finally {
			--self::$raw;
		}
	}

	/**
	 * A translated field of an object in the language of the request, or the value given.
	 * Kinds with addresses only when the object exists in that language.
	 *
	 * @param string $type    «post» or «term».
	 * @param int    $id      Object id.
	 * @param string $field   Field.
	 * @param mixed  $value   Spanish value.
	 * @param string $subtype Post type or taxonomy, when known.
	 * @return mixed
	 */
	public static function text( string $type, int $id, string $field, $value, string $subtype = '' ) {
		if ( $id <= 0 || ! self::active() ) {
			return $value;
		}
		$subtype = '' !== $subtype ? $subtype : (string) self::raw( static fn() => Fields::subtype( $type, $id ) );
		$def     = Fields::of( $type, $subtype )[ $field ] ?? null;
		if ( null === $def ) {
			return $value;
		}
		$language = Service::instance()->current();
		if ( Availability::whole( $type, $subtype ) && ! Availability::is( $type, $id, $language ) ) {
			return $value;
		}
		$text = Store::text( $type, $id, $field, $language );
		if ( null !== $text ) {
			return $text;
		}
		return 'empty' === $def['fallback'] ? '' : $value;
	}

	/**
	 * The field of a kind stored in a column of the post (post_title…), null when none is.
	 *
	 * @param string $subtype Post type.
	 * @param string $column  Column.
	 */
	public static function column_field( string $subtype, string $column ): ?string {
		foreach ( Fields::of( 'post', $subtype ) as $name => $field ) {
			if ( Fields::POST === $field['source'] && $field['key'] === $column ) {
				return $name;
			}
		}
		return null;
	}

	/**
	 * The posts of a query with their title, excerpt and content translated, loading the
	 * translations of all of them at once.
	 *
	 * @param mixed $posts Posts.
	 * @return mixed
	 */
	public static function posts( $posts ) {
		if ( ! is_array( $posts ) || ! $posts || ! self::active() || is_admin() ) {
			return $posts;
		}
		$ids = array();
		foreach ( $posts as $post ) {
			if ( $post instanceof \WP_Post ) {
				$ids[] = $post->ID;
			}
		}
		Store::prime( 'post', $ids, Service::instance()->current() );
		foreach ( $posts as $index => $post ) {
			if ( ! $post instanceof \WP_Post ) {
				continue;
			}
			// A copy: WordPress caches the posts of the query when they are the same objects
			// it read, and the cache (persistent on a server) must keep the Spanish.
			$copy = clone $post;
			foreach ( array( 'post_title', 'post_excerpt', 'post_content' ) as $column ) {
				$field = self::column_field( $copy->post_type, $column );
				if ( null !== $field ) {
					$copy->{$column} = (string) self::text( 'post', $copy->ID, $field, $copy->{$column}, $copy->post_type );
				}
			}
			$posts[ $index ] = $copy;
		}
		return $posts;
	}

	/**
	 * A title.
	 *
	 * @param mixed $title Title.
	 * @param mixed $id    Post id.
	 * @return mixed
	 */
	public static function title( $title, $id = 0 ) {
		$id = (int) $id;
		if ( $id <= 0 || ! self::active() ) {
			return $title;
		}
		$type  = (string) get_post_type( $id );
		$field = self::column_field( $type, 'post_title' );
		if ( null === $field ) {
			return $title;
		}
		$text = self::text( 'post', $id, $field, null, $type );
		return is_string( $text ) ? $text : $title;
	}

	/**
	 * An excerpt.
	 *
	 * @param mixed $excerpt Excerpt.
	 * @param mixed $post    Post.
	 * @return mixed
	 */
	public static function excerpt( $excerpt, $post = null ) {
		if ( ! $post instanceof \WP_Post || ! self::active() ) {
			return $excerpt;
		}
		$field = self::column_field( $post->post_type, 'post_excerpt' );
		if ( null === $field || '' === trim( (string) $excerpt ) ) {
			return $excerpt;
		}
		$text = self::text( 'post', $post->ID, $field, null, $post->post_type );
		return is_string( $text ) ? $text : $excerpt;
	}

	/**
	 * The pages of a post's content (what get_the_content() reads), translated.
	 *
	 * @param mixed $pages Pages.
	 * @param mixed $post  Post.
	 * @return mixed
	 */
	public static function pages( $pages, $post = null ) {
		if ( ! $post instanceof \WP_Post || ! self::active() ) {
			return $pages;
		}
		$field = self::column_field( $post->post_type, 'post_content' );
		if ( null === $field ) {
			return $pages;
		}
		$text = self::text( 'post', $post->ID, $field, null, $post->post_type );
		if ( ! is_string( $text ) ) {
			return $pages;
		}
		return explode( '<!--nextpage-->', str_replace( array( "\n<!--nextpage-->\n", "\n<!--nextpage-->", "<!--nextpage-->\n" ), '<!--nextpage-->', $text ) );
	}

	/**
	 * Meta of a post declared as translatable.
	 *
	 * @param mixed $value   Null to read it as stored.
	 * @param mixed $post_id Post id.
	 * @param mixed $key     Meta key.
	 * @param mixed $single  Whether one value is asked.
	 * @return mixed
	 */
	public static function post_meta( $value, $post_id, $key = '', $single = false ) {
		unset( $single );
		if ( null !== $value || ! is_string( $key ) || '' === $key || ! self::active() || ! Fields::is_meta( 'post', $key ) ) {
			return $value;
		}
		$subtype = (string) get_post_type( (int) $post_id );
		$field   = Fields::by_meta( 'post', $subtype, $key );
		if ( null === $field ) {
			return $value;
		}
		$text = self::text( 'post', (int) $post_id, $field, null, $subtype );
		return is_string( $text ) ? array( self::meta_value( $text, Fields::of( 'post', $subtype )[ $field ]['format'] ) ) : $value;
	}

	/**
	 * A translated meta as it is stored: a list from its JSON.
	 *
	 * @param string $text   Translation.
	 * @param string $format Format of the field.
	 * @return mixed
	 */
	private static function meta_value( string $text, string $format ) {
		if ( 'json' !== $format ) {
			return $text;
		}
		$value = json_decode( $text, true );
		return is_array( $value ) ? $value : array();
	}

	/**
	 * Meta of a term declared as translatable.
	 *
	 * @param mixed $value   Null to read it as stored.
	 * @param mixed $term_id Term id.
	 * @param mixed $key     Meta key.
	 * @param mixed $single  Whether one value is asked.
	 * @return mixed
	 */
	public static function term_meta( $value, $term_id, $key = '', $single = false ) {
		unset( $single );
		if ( null !== $value || ! is_string( $key ) || '' === $key || ! self::active() || ! Fields::is_meta( 'term', $key ) ) {
			return $value;
		}
		$taxonomy = (string) self::raw( static fn() => Fields::subtype( 'term', (int) $term_id ) );
		$field    = Fields::by_meta( 'term', $taxonomy, $key );
		if ( null === $field ) {
			return $value;
		}
		$text = self::text( 'term', (int) $term_id, $field, null, $taxonomy );
		return is_string( $text ) ? array( self::meta_value( $text, Fields::of( 'term', $taxonomy )[ $field ]['format'] ) ) : $value;
	}

	/**
	 * A term with its name and description translated.
	 *
	 * @param mixed $term Term.
	 * @return mixed
	 */
	public static function term( $term ) {
		if ( ! $term instanceof \WP_Term || ! self::active() || is_admin() ) {
			return $term;
		}
		foreach ( array( 'name', 'description' ) as $column ) {
			if ( isset( Fields::of( 'term', $term->taxonomy )[ $column ] ) ) {
				$term->{$column} = (string) self::text( 'term', $term->term_id, $column, $term->{$column}, $term->taxonomy );
			}
		}
		return $term;
	}

	/**
	 * Terms of a list.
	 *
	 * @param mixed $terms Terms.
	 * @return mixed
	 */
	public static function terms( $terms ) {
		if ( ! is_array( $terms ) || ! self::active() || is_admin() ) {
			return $terms;
		}
		$ids = array();
		foreach ( $terms as $term ) {
			if ( $term instanceof \WP_Term ) {
				$ids[] = $term->term_id;
			}
		}
		Store::prime( 'term', $ids, Service::instance()->current() );
		return array_map( array( self::class, 'term' ), $terms );
	}

	/**
	 * Name of a product.
	 *
	 * @param mixed $value   Name.
	 * @param mixed $product Product.
	 * @return mixed
	 */
	public static function product_name( $value, $product ) {
		return $product instanceof \WC_Product ? self::text( 'post', $product->get_id(), 'name', $value, 'product' ) : $value;
	}

	/**
	 * Short description of a product.
	 *
	 * @param mixed $value   Text.
	 * @param mixed $product Product.
	 * @return mixed
	 */
	public static function product_short_description( $value, $product ) {
		return $product instanceof \WC_Product ? self::text( 'post', $product->get_id(), 'short_description', $value, 'product' ) : $value;
	}

	/**
	 * Description of a product.
	 *
	 * @param mixed $value   Text.
	 * @param mixed $product Product.
	 * @return mixed
	 */
	public static function product_description( $value, $product ) {
		return $product instanceof \WC_Product ? self::text( 'post', $product->get_id(), 'description', $value, 'product' ) : $value;
	}

	/**
	 * Name of a variation: «Aceite – 250 ml» with the name of its product translated.
	 *
	 * @param mixed $value     Name.
	 * @param mixed $variation Variation.
	 * @return mixed
	 */
	public static function variation( $value, $variation ) {
		if ( ! is_string( $value ) || ! $variation instanceof \WC_Product_Variation || ! self::active() ) {
			return $value;
		}
		$parent   = $variation->get_parent_id();
		$language = Service::instance()->current();
		return Availability::is( 'post', $parent, $language ) ? self::variation_name( $value, $parent, $language ) : $value;
	}

	/**
	 * A variation's name with the name of its product in a language.
	 *
	 * @param string $name     Spanish name («Aceite – 250 ml»).
	 * @param int    $parent_id Product id.
	 * @param string $language Locale.
	 */
	public static function variation_name( string $name, int $parent_id, string $language ): string {
		$spanish    = (string) get_post_field( 'post_title', $parent_id, 'raw' );
		$translated = Store::text( 'post', $parent_id, 'name', $language );
		if ( null === $translated || '' === $spanish || ! str_starts_with( $name, $spanish ) ) {
			return $name;
		}
		return $translated . substr( $name, strlen( $spanish ) );
	}

	/**
	 * Name of a line of an order (kept in Spanish) in the language of an email, of the
	 * order received page or of the account. Never while WooCommerce saves the line: it
	 * stores what this getter returns.
	 *
	 * @param mixed $name Name.
	 * @param mixed $item Line.
	 * @return mixed
	 */
	public static function order_item( $name, $item ) {
		if ( ! $item instanceof \WC_Order_Item_Product || ! self::active() ) {
			return $name;
		}
		$page = ! wp_is_serving_rest_request() && ! wp_doing_ajax() && did_action( 'template_redirect' ) && function_exists( 'is_order_received_page' ) && ( is_order_received_page() || is_account_page() );
		if ( ! Service::instance()->switched() && ! $page ) {
			return $name;
		}
		$product = $item->get_product();
		if ( ! $product instanceof \WC_Product ) {
			return $name;
		}
		$language = Service::instance()->current();
		$texts    = Service::instance()->product_texts( $product, $language );
		$own      = self::raw( static fn() => $product->get_name() );
		return $own !== $texts['title'] ? $texts['title'] : $name;
	}

	/**
	 * A menu item: its own label translated or, without one, the title of what it points
	 * to; a free link in the language of the request.
	 *
	 * @param mixed $item Menu item.
	 * @return mixed
	 */
	public static function menu_item( $item ) {
		if ( ! is_object( $item ) || ! isset( $item->ID, $item->title ) || ! self::active() ) {
			return $item;
		}
		$own = '' !== trim( (string) get_post_field( 'post_title', (int) $item->ID, 'raw' ) );
		if ( $own ) {
			$item->title = (string) self::text( 'post', (int) $item->ID, 'title', $item->title, 'nav_menu_item' );
		} elseif ( isset( $item->type, $item->object_id ) && 'post_type' === $item->type ) {
			$item->title = (string) self::title( $item->title, (int) $item->object_id );
		} elseif ( isset( $item->type, $item->object_id ) && 'taxonomy' === $item->type ) {
			$term = get_term( (int) $item->object_id );
			if ( $term instanceof \WP_Term ) {
				$item->title = $term->name;
			}
		}
		if ( isset( $item->type, $item->url ) && 'custom' === $item->type && is_string( $item->url ) && '' !== $item->url && '#' !== $item->url[0] ) {
			$item->url = Service::instance()->url( $item->url, Service::instance()->current() );
		}
		return $item;
	}
}
