<?php
/**
 * Addresses in each language.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

defined( 'ABSPATH' ) || exit;

/**
 * The address of something in a language is its Spanish address with the prefix of the
 * language (`/en/`), its own slug translated and the other segments that are pages or terms
 * translated too (`/tienda/` → `/en/shop/`, `/blog/recetas/x/` → `/en/blog/recipes/y/`).
 * The shape stays: if the Spanish ends in `.html`, the translation too. What does not exist
 * in a language keeps its Spanish address, without prefix.
 */
final class Links {

	/**
	 * Address of a post in a language, from its Spanish address.
	 *
	 * @param string $url      Spanish address.
	 * @param int    $id       Post id.
	 * @param string $language Locale.
	 */
	public static function post( string $url, int $id, string $language ): string {
		$url = self::strip( $url );
		if ( Config::default_language() === $language || ! Availability::is( 'post', $id, $language ) ) {
			return $url;
		}
		if ( (int) get_option( 'page_on_front' ) === $id ) {
			return self::rebuild( $url, $language, null );
		}
		return self::rebuild( $url, $language, Store::text( 'post', $id, 'slug', $language ) );
	}

	/**
	 * Address of a term in a language, from its Spanish address.
	 *
	 * @param string $url      Spanish address.
	 * @param int    $id       Term id.
	 * @param string $language Locale.
	 */
	public static function term( string $url, int $id, string $language ): string {
		$url = self::strip( $url );
		if ( Config::default_language() === $language || ! Availability::is( 'term', $id, $language ) ) {
			return $url;
		}
		return self::rebuild( $url, $language, Store::text( 'term', $id, 'slug', $language ) );
	}

	/**
	 * Any address of the site in a language: the prefix and the segments that are pages or
	 * terms translated. Other sites, as they are.
	 *
	 * @param string $url      Address (Spanish or of another language).
	 * @param string $language Locale.
	 */
	public static function generic( string $url, string $language ): string {
		$url = self::strip( $url );
		if ( Config::default_language() === $language || null === self::split( $url ) ) {
			return $url;
		}
		return self::rebuild( $url, $language, null );
	}

	/**
	 * The address without the prefix of a language, as it is in Spanish.
	 *
	 * @param string $url Address.
	 */
	public static function strip( string $url ): string {
		$parts = self::split( $url );
		if ( null === $parts ) {
			return $url;
		}
		$segments = explode( '/', ltrim( $parts['path'], '/' ) );
		if ( '' === $segments[0] || null === Config::by_code( $segments[0] ) ) {
			return $url;
		}
		$path = '/' . implode( '/', array_slice( $segments, 1 ) );
		return $parts['root'] . $path . $parts['rest'];
	}

	/**
	 * Language of an address by its prefix, null for the default.
	 *
	 * @param string $path Path relative to the home («/en/shop/»).
	 */
	public static function language_of( string $path ): ?string {
		$first = explode( '/', ltrim( $path, '/' ), 2 )[0];
		return '' === $first ? null : Config::by_code( $first );
	}

	/**
	 * The root of the site (scheme, host and path of the home, without the final slash),
	 * the path after it and the query and fragment; null for another site.
	 *
	 * @param string $url Address.
	 * @return array{root: string, path: string, rest: string}|null
	 */
	public static function split( string $url ): ?array {
		$home = untrailingslashit( (string) get_option( 'home' ) );
		$bare = (string) preg_replace( '#^https?:#i', '', $home );
		if ( str_starts_with( $url, '/' ) && ! str_starts_with( $url, '//' ) ) {
			$url = $home . $url;
		}
		$url_bare = (string) preg_replace( '#^https?:#i', '', $url );
		if ( ! str_starts_with( strtolower( $url_bare ), strtolower( $bare ) ) ) {
			return null;
		}
		$root  = substr( $url, 0, strlen( $url ) - strlen( $url_bare ) + strlen( $bare ) );
		$after = substr( $url_bare, strlen( $bare ) );
		if ( '' !== $after && ! in_array( $after[0], array( '/', '?', '#' ), true ) ) {
			return null;
		}
		$cut = strcspn( $after, '?#' );
		return array(
			'root' => $root,
			'path' => '' === substr( $after, 0, $cut ) ? '/' : substr( $after, 0, $cut ),
			'rest' => substr( $after, $cut ),
		);
	}

	/**
	 * The Spanish address in a language: prefix, the last segment with the translated slug
	 * (when there is one) and the other segments through the slugs of pages and terms.
	 *
	 * @param string      $url      Spanish address.
	 * @param string      $language Locale.
	 * @param string|null $slug     Translated slug of the object, null to keep its own.
	 */
	private static function rebuild( string $url, string $language, ?string $slug ): string {
		$parts = self::split( $url );
		if ( null === $parts ) {
			return $url;
		}
		$map      = Slugs::forward( $language );
		$trimmed  = trim( $parts['path'], '/' );
		$segments = '' === $trimmed ? array() : explode( '/', $trimmed );
		$last     = count( $segments ) - 1;
		foreach ( $segments as $index => $segment ) {
			if ( $index === $last && null !== $slug && '' !== $slug ) {
				$segments[ $index ] = $slug . self::extension( $segment );
			} elseif ( isset( $map[ $segment ] ) ) {
				$segments[ $index ] = $map[ $segment ];
			}
		}
		$path = '/' . Config::code( $language ) . '/' . implode( '/', $segments );
		if ( $segments && ! str_ends_with( $parts['path'], '/' ) ) {
			$path = rtrim( $path, '/' );
		} elseif ( $segments ) {
			$path = trailingslashit( $path );
		}
		return $parts['root'] . $path . $parts['rest'];
	}

	/**
	 * Extension of the last segment of an address («.html»), '' without one.
	 *
	 * @param string $segment Segment.
	 */
	public static function extension( string $segment ): string {
		return preg_match( '/(\.html?)$/i', $segment, $match ) ? $match[1] : '';
	}
}
