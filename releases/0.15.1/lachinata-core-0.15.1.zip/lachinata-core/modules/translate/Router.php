<?php
/**
 * Addresses by language.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * The language comes from the address, never from the browser or the IP (05-localizacion.md):
 * `/en/…` is English, without prefix Spanish. On each request in another language the
 * module takes the prefix out, turns the translated slugs back into the Spanish ones and
 * lets WordPress (and Permalink Manager, if it is there) parse that Spanish address; then it
 * puts the address back as it was, so the canonical redirection of WordPress compares it
 * with the translated permalink. Every link of the page (permalinks, terms, the home, the
 * Store API) comes out in the language of the request. A page that does not exist in that
 * language sends to its Spanish address (302: it may be translated tomorrow).
 */
final class Router {

	/**
	 * Address of the request as it came, while WordPress parses the Spanish one.
	 *
	 * @var string
	 */
	private static string $original = '';

	/**
	 * Paths of the home that never take a prefix.
	 */
	private const EXCLUDED = '#^/?(wp-admin|wp-login\.php|wp-content|wp-includes|xmlrpc\.php|robots\.txt|[a-z0-9_-]*sitemap[a-z0-9_-]*\.(xml|xsl))#i';

	/**
	 * Reads the language of the address (on boot, before the strings load) and registers
	 * the hooks.
	 */
	public static function boot(): void {
		self::detect();
		Hooks::add_filter( 'locale', array( self::class, 'locale' ), 1 );
		Hooks::add_filter( 'do_parse_request', array( self::class, 'parse' ), 1 );
		Hooks::add_action( 'parse_request', array( self::class, 'restore' ), 0 );
		Hooks::add_action( 'template_redirect', array( self::class, 'missing' ), 1 );
		Hooks::add_filter( 'home_url', array( self::class, 'home_url' ), 20, 2 );
		Hooks::add_filter( 'post_link', array( self::class, 'post_link' ), 99, 2 );
		Hooks::add_filter( 'post_type_link', array( self::class, 'post_link' ), 99, 2 );
		Hooks::add_filter( 'page_link', array( self::class, 'post_link' ), 99, 2 );
		Hooks::add_filter( 'term_link', array( self::class, 'term_link' ), 99, 2 );
		Hooks::add_filter( 'post_type_archive_link', array( self::class, 'generic_link' ), 99 );
	}

	/**
	 * The language of the address of this request.
	 */
	public static function detect(): void {
		if ( is_admin() || wp_doing_cron() || ( defined( 'WP_CLI' ) && WP_CLI ) || ! isset( $_SERVER['REQUEST_URI'] ) ) {
			return;
		}
		$path     = self::relative( (string) wp_parse_url( esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ), PHP_URL_PATH ) );
		$language = Links::language_of( $path );
		if ( null !== $language ) {
			Service::instance()->set_request( $language );
		}
	}

	/**
	 * The strings in the language of the address.
	 *
	 * @param mixed $locale Locale.
	 * @return mixed
	 */
	public static function locale( $locale ) {
		$current = Service::instance()->current();
		return ! is_admin() && Config::default_language() !== $current ? $current : $locale;
	}

	/**
	 * Before WordPress parses the request: the Spanish address of a translated one.
	 *
	 * @param mixed $parse Whether to parse.
	 * @return mixed
	 */
	public static function parse( $parse ) {
		if ( ! isset( $_SERVER['REQUEST_URI'] ) ) {
			return $parse;
		}
		$uri      = (string) wp_unslash( $_SERVER['REQUEST_URI'] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- parsed below and only rewritten as a path.
		$cut      = strcspn( $uri, '?#' );
		$path     = substr( $uri, 0, $cut );
		$query    = substr( $uri, $cut );
		$base     = untrailingslashit( (string) wp_parse_url( (string) get_option( 'home' ), PHP_URL_PATH ) );
		$relative = self::relative( $path );
		$language = Links::language_of( $relative );
		$root     = untrailingslashit( (string) get_option( 'home' ) );
		if ( null === $language ) {
			Service::instance()->set_request( '' );
			Service::instance()->set_source_url( $root . $relative . $query );
			return $parse;
		}
		Service::instance()->set_request( $language );
		$stripped = '/' . ltrim( (string) substr( ltrim( $relative, '/' ), strlen( Config::code( $language ) ) ), '/' );
		// The REST API keeps its routes: only the language of its answers changes.
		$rest    = '/' . trim( rest_get_url_prefix(), '/' ) . '/';
		$spanish = str_starts_with( trailingslashit( $stripped ), $rest ) || preg_match( self::EXCLUDED, ltrim( $stripped, '/' ) ) ? $stripped : self::resolve( $stripped, $language );
		Service::instance()->set_source_url( $root . $spanish . $query );
		self::$original         = $uri;
		$_SERVER['REQUEST_URI'] = $base . $spanish . $query;
		return $parse;
	}

	/**
	 * The address back as it came, once WordPress has its query.
	 */
	public static function restore(): void {
		if ( '' !== self::$original ) {
			$_SERVER['REQUEST_URI'] = self::$original;
			self::$original         = '';
		}
	}

	/**
	 * Spanish path of a path in a language: each segment that is a translated slug becomes
	 * the Spanish address of its object, with what follows it (pages, endpoints) as it is.
	 *
	 * @param string $path     Path without the prefix («/shop/page/2/»).
	 * @param string $language Locale.
	 */
	public static function resolve( string $path, string $language ): string {
		$trimmed = trim( $path, '/' );
		if ( '' === $trimmed ) {
			return '/';
		}
		$segments = explode( '/', $trimmed );
		$stems    = array_map( static fn( string $segment ): string => (string) preg_replace( '/\.html?$/i', '', rawurldecode( $segment ) ), $segments );
		$rows     = array();
		foreach ( Store::by_slugs( $language, $stems ) as $row ) {
			$rows[ $row['slug'] ][] = $row;
		}
		if ( ! $rows ) {
			return $path;
		}
		$service = Service::instance();
		$out     = array();
		foreach ( $segments as $index => $segment ) {
			$chosen = null;
			$wanted = implode( '/', array_slice( $segments, 0, $index + 1 ) );
			foreach ( $rows[ $stems[ $index ] ] ?? array() as $row ) {
				$own = 'post' === $row['type'] ? $service->post_url( $row['id'], $language ) : $service->term_url( $row['id'], $language );
				if ( '' === $own ) {
					continue;
				}
				$chosen = $chosen ?? $row;
				// Of several objects with that slug, the one whose address is this one.
				if ( trim( self::relative( (string) wp_parse_url( Links::strip( $own ), PHP_URL_PATH ) ), '/' ) === $wanted ) {
					$chosen = $row;
					break;
				}
			}
			if ( null === $chosen ) {
				$out[] = $segment;
				continue;
			}
			$spanish = 'post' === $chosen['type'] ? $service->post_url( $chosen['id'], Config::default_language() ) : $service->term_url( $chosen['id'], Config::default_language() );
			$own     = trim( self::relative( (string) wp_parse_url( $spanish, PHP_URL_PATH ) ), '/' );
			$out     = '' === $own ? array() : explode( '/', $own );
		}
		$resolved = '/' . implode( '/', $out );
		return str_ends_with( $path, '/' ) && '/' !== $resolved ? trailingslashit( $resolved ) : $resolved;
	}

	/**
	 * A page that does not exist in the language of the address goes to its Spanish one
	 * (302); one that exists, asked with another address (the Spanish slug, an old one),
	 * to its address in that language (301).
	 */
	public static function missing(): void {
		$service = Service::instance();
		$current = $service->current();
		if ( Config::default_language() === $current ) {
			return;
		}
		$object = get_queried_object();
		if ( $object instanceof \WP_Post && is_singular() && Availability::whole( 'post', $object->post_type ) ) {
			$type = 'post';
			$id   = $object->ID;
		} elseif ( $object instanceof \WP_Term && Availability::whole( 'term', $object->taxonomy ) ) {
			$type = 'term';
			$id   = $object->term_id;
		} else {
			return;
		}
		if ( ! Availability::is( $type, $id, $current ) ) {
			// The same address in Spanish, with what follows it (an endpoint, the query).
			$uri = isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
			wp_safe_redirect( '' !== $uri ? Service::to_source( $uri ) : ( 'post' === $type ? $service->post_url( $id, Config::default_language() ) : $service->term_url( $id, Config::default_language() ) ), 302, 'La Chinata' );
			exit;
		}
		if ( is_paged() || get_query_var( 'page' ) || get_query_var( 'cpage' ) || is_front_page() ) {
			return;
		}
		$own       = 'post' === $type ? $service->post_url( $id, $current ) : $service->term_url( $id, $current );
		$own_path  = untrailingslashit( (string) wp_parse_url( $own, PHP_URL_PATH ) );
		$requested = isset( $_SERVER['REQUEST_URI'] ) ? untrailingslashit( (string) wp_parse_url( esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ), PHP_URL_PATH ) ) : $own_path;
		// Beyond its address (an endpoint of WooCommerce: order received, the account) it stays.
		$beyond = str_starts_with( rawurldecode( $requested ), rawurldecode( $own_path ) . '/' );
		if ( '' !== $own_path && ! $beyond && rawurldecode( $requested ) !== rawurldecode( $own_path ) ) {
			$query = isset( $_SERVER['QUERY_STRING'] ) ? sanitize_text_field( wp_unslash( $_SERVER['QUERY_STRING'] ) ) : '';
			wp_safe_redirect( '' !== $query ? $own . '?' . $query : $own, 301, 'La Chinata' );
			exit;
		}
	}

	/**
	 * Addresses of the home with the prefix of the language and its pages translated.
	 *
	 * @param mixed $url  Address.
	 * @param mixed $path Path asked for.
	 * @return mixed
	 */
	public static function home_url( $url, $path = '' ) {
		if ( ! is_string( $url ) || ! Front::active() || preg_match( self::EXCLUDED, (string) $path ) ) {
			return $url;
		}
		return Links::generic( $url, Service::instance()->current() );
	}

	/**
	 * Permalink of a post in the language of the request.
	 *
	 * @param mixed $url  Permalink.
	 * @param mixed $post Post or id.
	 * @return mixed
	 */
	public static function post_link( $url, $post ) {
		if ( ! is_string( $url ) || ! Front::active() ) {
			return $url;
		}
		$id = $post instanceof \WP_Post ? $post->ID : (int) $post;
		return $id > 0 ? Links::post( $url, $id, Service::instance()->current() ) : $url;
	}

	/**
	 * Link of a term in the language of the request.
	 *
	 * @param mixed $url  Link.
	 * @param mixed $term Term.
	 * @return mixed
	 */
	public static function term_link( $url, $term ) {
		if ( ! is_string( $url ) || ! Front::active() || ! $term instanceof \WP_Term ) {
			return $url;
		}
		return Links::term( $url, $term->term_id, Service::instance()->current() );
	}

	/**
	 * An archive (the shop) in the language of the request.
	 *
	 * @param mixed $url Link.
	 * @return mixed
	 */
	public static function generic_link( $url ) {
		return is_string( $url ) && Front::active() ? Links::generic( $url, Service::instance()->current() ) : $url;
	}

	/**
	 * A path relative to the home («/en/shop/» on a site in «/tienda-web/»).
	 *
	 * @param string $path Path of the request.
	 */
	private static function relative( string $path ): string {
		$base = untrailingslashit( (string) wp_parse_url( (string) get_option( 'home' ), PHP_URL_PATH ) );
		if ( '' !== $base && str_starts_with( $path, $base ) ) {
			$path = substr( $path, strlen( $base ) );
		}
		return '' === $path ? '/' : $path;
	}
}
