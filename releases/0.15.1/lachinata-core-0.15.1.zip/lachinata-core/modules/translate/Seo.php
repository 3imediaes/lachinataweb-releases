<?php
/**
 * `hreflang` and sitemaps by language.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * Each translated page says where it is in the other languages (`hreflang`, with
 * `x-default` to the Spanish), only among the languages where it exists. The canonical of
 * each language is itself: WordPress and Rank Math build it from the permalink, which already
 * comes out in the language of the request. Each language has its sitemap in the index of
 * Rank Math (or of WordPress, without Rank Math) with only what exists in it.
 */
final class Seo {

	/**
	 * Type of the sitemap of a language in Rank Math («translate-en»).
	 */
	public const SITEMAP = 'translate-';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'wp_head', array( self::class, 'hreflang' ), 2 );
		Hooks::add_filter( 'rank_math/sitemap/providers', array( self::class, 'rank_math' ) );
		Hooks::add_action( 'wp_sitemaps_init', array( self::class, 'core_sitemaps' ) );
		Hooks::add_filter( 'rank_math/replacements', array( self::class, 'rank_math_vars' ), 10, 2 );
		Hooks::add_filter( 'rank_math/frontend/description', array( self::class, 'rank_math_description' ), 5 );
	}

	/**
	 * The meta description of a translated post: Rank Math takes the excerpt of the post as
	 * it is stored (in Spanish) before its template; in another language it is the
	 * translated SEO description, or the translated excerpt, or the start of the content.
	 *
	 * @param mixed $description Description.
	 * @return mixed
	 */
	public static function rank_math_description( $description ) {
		$id = is_singular() ? (int) get_queried_object_id() : 0;
		if ( $id <= 0 || ! Front::active() ) {
			return $description;
		}
		$type     = (string) get_post_type( $id );
		$language = Service::instance()->current();
		if ( ! Availability::is( 'post', $id, $language ) || ! Fields::translatable( 'post', $type ) ) {
			return $description;
		}
		$own = Store::text( 'post', $id, 'seo_description', $language );
		if ( null !== $own ) {
			return $own;
		}
		foreach ( array( 'post_excerpt', 'post_content' ) as $column ) {
			$field = Front::column_field( $type, $column );
			$text  = null === $field ? null : Store::text( 'post', $id, $field, $language );
			$text  = null === $text ? '' : trim( (string) preg_replace( '/\s+/', ' ', wp_strip_all_tags( strip_shortcodes( $text ) ) ) );
			if ( '' !== $text ) {
				return wp_html_excerpt( $text, 156, '…' );
			}
		}
		return $description;
	}

	/**
	 * The variables of Rank Math's titles and descriptions (%title%, %excerpt%, %term%…)
	 * with the translated texts: without a translated SEO title, Rank Math writes it from
	 * its template, and the template must read the translation.
	 *
	 * @param mixed $replacements Variable → value.
	 * @param mixed $args         Post or term the values come from.
	 * @return mixed
	 */
	public static function rank_math_vars( $replacements, $args ) {
		if ( ! is_array( $replacements ) || ! is_object( $args ) || ! Front::active() ) {
			return $replacements;
		}
		if ( isset( $args->ID, $args->post_type ) && (int) $args->ID > 0 ) {
			$id      = (int) $args->ID;
			$type    = (string) $args->post_type;
			$excerpt = Front::column_field( $type, 'post_excerpt' );
			$content = Front::column_field( $type, 'post_content' );
			$text    = static fn( ?string $field ): string => null === $field ? '' : (string) Front::text( 'post', $id, $field, '', $type );
			if ( isset( $replacements['%title%'] ) ) {
				$replacements['%title%'] = (string) Front::title( $replacements['%title%'], $id );
			}
			foreach ( array( '%excerpt%', '%excerpt_only%' ) as $variable ) {
				if ( isset( $replacements[ $variable ] ) ) {
					$own = $text( $excerpt );
					$own = '' !== trim( wp_strip_all_tags( $own ) ) || '%excerpt_only%' === $variable ? $own : $text( $content );
					if ( '' !== trim( wp_strip_all_tags( $own ) ) ) {
						$replacements[ $variable ] = wp_html_excerpt( strip_shortcodes( wp_strip_all_tags( $own ) ), 156, '' );
					}
				}
			}
		} elseif ( isset( $args->term_id, $args->taxonomy ) ) {
			$term = get_term( (int) $args->term_id );
			if ( $term instanceof \WP_Term ) {
				foreach ( array(
					'%term%'             => $term->name,
					'%term_description%' => wp_strip_all_tags( $term->description ),
				) as $variable => $value ) {
					if ( isset( $replacements[ $variable ] ) ) {
						$replacements[ $variable ] = $value;
					}
				}
			}
		}
		return $replacements;
	}

	/**
	 * The `<link rel="alternate" hreflang>` of the current page.
	 */
	public static function hreflang(): void {
		foreach ( self::links() as $code => $url ) {
			printf( '<link rel="alternate" hreflang="%1$s" href="%2$s">' . "\n", esc_attr( $code ), esc_url( $url ) );
		}
	}

	/**
	 * Addresses of the current page by `hreflang` code, with `x-default`; nothing when it
	 * exists in a single language or is not a page to index (search, 404, bag, checkout,
	 * account).
	 *
	 * @return array<string, string>
	 */
	public static function links(): array {
		if ( is_search() || is_404() || is_feed() || ( function_exists( 'is_cart' ) && ( is_cart() || is_checkout() || is_account_page() ) ) ) {
			return array();
		}
		$service    = Service::instance();
		$alternates = $service->alternates();
		if ( count( $alternates ) < 2 ) {
			return array();
		}
		$out = array();
		foreach ( $alternates as $language => $url ) {
			$out[ $service->code( $language ) ] = $url;
		}
		$default = $service->default_language();
		if ( isset( $alternates[ $default ] ) ) {
			$out['x-default'] = $alternates[ $default ];
		}
		return $out;
	}

	/**
	 * The sitemaps of the languages in Rank Math.
	 *
	 * @param mixed $providers Providers.
	 * @return mixed
	 */
	public static function rank_math( $providers ) {
		if ( is_array( $providers ) && Config::languages() ) {
			$providers[] = new Sitemap();
		}
		return $providers;
	}

	/**
	 * The sitemaps of the languages in WordPress's own, without Rank Math.
	 *
	 * @param mixed $sitemaps Sitemaps server.
	 */
	public static function core_sitemaps( $sitemaps ): void {
		if ( $sitemaps instanceof \WP_Sitemaps && Config::languages() && ! defined( 'RANK_MATH_VERSION' ) ) {
			$sitemaps->registry->add_provider( 'translate', new CoreSitemap() );
		}
	}
}
