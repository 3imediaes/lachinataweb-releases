<?php
/**
 * Sitemap of a language in Rank Math.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

defined( 'ABSPATH' ) || exit;

/**
 * A provider of Rank Math (`rank_math/sitemap/providers` only asks for an object with these
 * three methods): one sitemap per language, `translate-en-sitemap.xml`, with the posts and
 * terms that exist in it and their address there.
 */
final class Sitemap {

	/**
	 * Whether a type of sitemap is one of ours.
	 *
	 * @param mixed $type Type («translate-en»).
	 */
	public function handles_type( $type ): bool {
		return null !== self::language( (string) $type );
	}

	/**
	 * Links of the index: one per language and page.
	 *
	 * @param mixed $max_entries Entries per sitemap.
	 * @return array<int, array{loc: string, lastmod: string}>
	 */
	public function get_index_links( $max_entries ): array {
		$max   = max( 1, (int) $max_entries );
		$links = array();
		foreach ( array_keys( Config::languages() ) as $language ) {
			$total = count( Entries::all( $language ) );
			$pages = (int) ceil( $total / $max );
			for ( $page = 1; $page <= $pages; $page++ ) {
				$name    = Seo::SITEMAP . Config::code( $language ) . '-sitemap' . ( $page > 1 ? $page : '' ) . '.xml';
				$links[] = array(
					'loc'     => class_exists( '\RankMath\Sitemap\Router' ) ? (string) \RankMath\Sitemap\Router::get_base_url( $name ) : home_url( '/' . $name ),
					'lastmod' => Entries::lastmod( $language ),
				);
			}
		}
		return $links;
	}

	/**
	 * Links of a sitemap.
	 *
	 * @param mixed $type         Type.
	 * @param mixed $max_entries  Entries per sitemap.
	 * @param mixed $current_page Page.
	 * @return array<int, array{loc: string, mod: string}>
	 */
	public function get_sitemap_links( $type, $max_entries, $current_page ): array {
		$language = self::language( (string) $type );
		if ( null === $language ) {
			return array();
		}
		$max  = max( 1, (int) $max_entries );
		$page = max( 1, (int) $current_page );
		return array_map(
			static fn( array $entry ): array => array(
				'loc' => $entry['url'],
				'mod' => $entry['modified'],
			),
			array_slice( Entries::all( $language ), ( $page - 1 ) * $max, $max )
		);
	}

	/**
	 * Language of a type of sitemap, null when it is not ours.
	 *
	 * @param string $type Type.
	 */
	private static function language( string $type ): ?string {
		return str_starts_with( $type, Seo::SITEMAP ) ? Config::by_code( substr( $type, strlen( Seo::SITEMAP ) ) ) : null;
	}
}
