<?php
/**
 * Translated slugs of the pages and the terms.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

defined( 'ABSPATH' ) || exit;

/**
 * Spanish slug → translated slug of every page and term with a translated slug, by
 * language. They are the segments other addresses go through (the shop in `/tienda/…`, a
 * section in `/blog/recetas/…`, a parent page), so a link or an address is translated
 * segment by segment without asking the database for each one. Kept in a transient that
 * is emptied when a slug changes.
 */
final class Slugs {

	/**
	 * Maps of this request, by language.
	 *
	 * @var array<string, array<string, string>>
	 */
	private static array $maps = array();

	/**
	 * Spanish slug → translated slug in a language.
	 *
	 * @param string $language Locale.
	 * @return array<string, string>
	 */
	public static function forward( string $language ): array {
		if ( isset( self::$maps[ $language ] ) ) {
			return self::$maps[ $language ];
		}
		$key = 'lachinata_translate_slugs_' . $language;
		$map = get_transient( $key );
		if ( ! is_array( $map ) ) {
			$map = array();
			foreach ( Store::slugs( $language, 'post', array( 'page' ) ) as $id => $slug ) {
				$name = (string) get_post_field( 'post_name', $id, 'raw' );
				if ( '' !== $name && $name !== $slug ) {
					$map[ $name ] = $slug;
				}
			}
			foreach ( Store::slugs( $language, 'term', Fields::subtypes( 'term' ) ) as $id => $slug ) {
				$term = get_term( $id );
				if ( $term instanceof \WP_Term && $term->slug !== $slug ) {
					$map[ $term->slug ] = $slug;
				}
			}
			set_transient( $key, $map, DAY_IN_SECONDS );
		}
		self::$maps[ $language ] = $map;
		return $map;
	}

	/**
	 * Empties the maps (a slug was written, deleted or a page renamed).
	 */
	public static function flush(): void {
		foreach ( array_keys( Config::languages() ) as $language ) {
			delete_transient( 'lachinata_translate_slugs_' . $language );
		}
		self::$maps = array();
	}
}
