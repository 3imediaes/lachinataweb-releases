<?php
/**
 * The translations table.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

defined( 'ABSPATH' ) || exit;

/**
 * One row per object, field and language: the translated text, the fingerprint of the
 * Spanish it comes from, its state («auto», «edited», «outdated») and its origin (Claude, a
 * person or an import). The translated slug of an object goes in the same table, in its
 * own column with a unique index by language, so an address finds its object with one query.
 * Reads are kept for the request; prime() loads many objects at once (a list of products).
 */
final class Store {

	/**
	 * Table, without the WordPress prefix.
	 */
	public const TABLE = 'lc_translate';

	/**
	 * States of a translation.
	 */
	public const AUTO     = 'auto';
	public const EDITED   = 'edited';
	public const OUTDATED = 'outdated';

	/**
	 * Origins of a translation.
	 */
	public const ORIGINS = array( 'claude', 'person', 'import' );

	/**
	 * Translations read in this request, by «type:id:language».
	 *
	 * @var array<string, array<string, array{text: string, hash: string, status: string, origin: string, updated: string}>>
	 */
	private static array $cache = array();

	/**
	 * Full table name.
	 */
	public static function table(): string {
		global $wpdb;
		return $wpdb->prefix . self::TABLE;
	}

	/**
	 * Creates the table (migration 1; idempotent).
	 */
	public static function install(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table   = self::table();
		$charset = $wpdb->get_charset_collate();
		dbDelta(
			"CREATE TABLE {$table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				object_type varchar(8) NOT NULL,
				object_subtype varchar(32) NOT NULL,
				object_id bigint(20) unsigned NOT NULL,
				field varchar(64) NOT NULL,
				language varchar(12) NOT NULL,
				text longtext NOT NULL,
				slug varchar(200) DEFAULT NULL,
				source_hash char(40) NOT NULL DEFAULT '',
				status varchar(10) NOT NULL DEFAULT 'auto',
				origin varchar(10) NOT NULL DEFAULT 'import',
				updated_at datetime NOT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY object_field (object_type,object_id,field,language),
				UNIQUE KEY slug_unique (language,object_type,object_subtype,slug),
				KEY slug_lookup (language,slug),
				KEY status (language,status)
			) {$charset};"
		);
	}

	/**
	 * Fingerprint of a Spanish text: the same text gives the same fingerprint whatever the
	 * line endings and the spaces around it.
	 *
	 * @param string $text Text.
	 */
	public static function fingerprint( string $text ): string {
		return sha1( trim( str_replace( array( "\r\n", "\r" ), "\n", $text ) ) );
	}

	/**
	 * Translations of an object in a language, by field.
	 *
	 * @param string $type     «post» or «term».
	 * @param int    $id       Object id.
	 * @param string $language Locale.
	 * @return array<string, array{text: string, hash: string, status: string, origin: string, updated: string}>
	 */
	public static function get( string $type, int $id, string $language ): array {
		$key = $type . ':' . $id . ':' . $language;
		if ( ! isset( self::$cache[ $key ] ) ) {
			self::prime( $type, array( $id ), $language );
		}
		return self::$cache[ $key ] ?? array();
	}

	/**
	 * One translated field, or null.
	 *
	 * @param string $type     «post» or «term».
	 * @param int    $id       Object id.
	 * @param string $field    Field.
	 * @param string $language Locale.
	 */
	public static function text( string $type, int $id, string $field, string $language ): ?string {
		$rows = self::get( $type, $id, $language );
		return isset( $rows[ $field ] ) ? $rows[ $field ]['text'] : null;
	}

	/**
	 * Loads the translations of many objects with one query.
	 *
	 * @param string $type     «post» or «term».
	 * @param int[]  $ids      Object ids.
	 * @param string $language Locale.
	 */
	public static function prime( string $type, array $ids, string $language ): void {
		global $wpdb;
		$ids = array_values(
			array_filter(
				array_unique( array_map( 'intval', $ids ) ),
				static fn( int $id ): bool => $id > 0 && ! isset( self::$cache[ $type . ':' . $id . ':' . $language ] )
			)
		);
		if ( ! $ids ) {
			return;
		}
		foreach ( $ids as $id ) {
			self::$cache[ $type . ':' . $id . ':' . $language ] = array();
		}
		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- placeholders built for the list; own table, kept for the request.
		$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT object_id, field, text, source_hash, status, origin, updated_at FROM %i WHERE object_type = %s AND language = %s AND object_id IN ({$placeholders})", self::table(), $type, $language, ...$ids ), ARRAY_A );
		foreach ( $rows as $row ) {
			self::$cache[ $type . ':' . (int) $row['object_id'] . ':' . $language ][ (string) $row['field'] ] = array(
				'text'    => (string) $row['text'],
				'hash'    => (string) $row['source_hash'],
				'status'  => (string) $row['status'],
				'origin'  => (string) $row['origin'],
				'updated' => (string) $row['updated_at'],
			);
		}
	}

	/**
	 * Writes a translation (or replaces it). A slug is cleaned and made unique among the
	 * objects of its kind in that language. An empty text deletes the field.
	 *
	 * @param string $type     «post» or «term».
	 * @param string $subtype  Post type or taxonomy.
	 * @param int    $id       Object id.
	 * @param string $field    Field.
	 * @param string $language Locale.
	 * @param string $text     Translated text.
	 * @param string $hash     Fingerprint of the Spanish it comes from.
	 * @param string $status   «auto», «edited» or «outdated».
	 * @param string $origin   «claude», «person» or «import».
	 * @return bool Whether something changed.
	 */
	public static function put( string $type, string $subtype, int $id, string $field, string $language, string $text, string $hash, string $status = self::AUTO, string $origin = 'import' ): bool {
		global $wpdb;
		if ( '' === trim( $text ) ) {
			return self::delete( $type, $id, $field, $language );
		}
		$slug = null;
		if ( 'slug' === $field ) {
			$text = self::unique_slug( $type, $subtype, $id, $language, sanitize_title( $text ) );
			if ( '' === $text ) {
				return false;
			}
			$slug = $text;
		}
		$status  = in_array( $status, array( self::AUTO, self::EDITED, self::OUTDATED ), true ) ? $status : self::AUTO;
		$origin  = in_array( $origin, self::ORIGINS, true ) ? $origin : 'import';
		$current = self::get( $type, $id, $language )[ $field ] ?? null;
		if ( null !== $current && $current['text'] === $text && $current['hash'] === $hash && $current['status'] === $status && $current['origin'] === $origin ) {
			return false;
		}
		$now = current_time( 'mysql', true );
		$sql = null === $slug
			? $wpdb->prepare( 'INSERT INTO %i (object_type, object_subtype, object_id, field, language, text, slug, source_hash, status, origin, updated_at) VALUES (%s, %s, %d, %s, %s, %s, NULL, %s, %s, %s, %s)', self::table(), $type, $subtype, $id, $field, $language, $text, $hash, $status, $origin, $now )
			: $wpdb->prepare( 'INSERT INTO %i (object_type, object_subtype, object_id, field, language, text, slug, source_hash, status, origin, updated_at) VALUES (%s, %s, %d, %s, %s, %s, %s, %s, %s, %s, %s)', self::table(), $type, $subtype, $id, $field, $language, $text, $slug, $hash, $status, $origin, $now );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- own table, prepared above; the request cache is updated below.
		$wpdb->query( $sql . ' ON DUPLICATE KEY UPDATE object_subtype = VALUES(object_subtype), text = VALUES(text), slug = VALUES(slug), source_hash = VALUES(source_hash), status = VALUES(status), origin = VALUES(origin), updated_at = VALUES(updated_at)' );
		unset( self::$cache[ $type . ':' . $id . ':' . $language ] );
		if ( null !== $slug ) {
			Slugs::flush();
		}
		return true;
	}

	/**
	 * Changes the state of translated fields (with their fingerprint, when it is given).
	 *
	 * @param string      $type     «post» or «term».
	 * @param int         $id       Object id.
	 * @param string      $field    Field.
	 * @param string      $language Locale.
	 * @param string      $status   New state.
	 * @param string|null $hash     New fingerprint, null to keep it.
	 */
	public static function mark( string $type, int $id, string $field, string $language, string $status, ?string $hash = null ): void {
		global $wpdb;
		$data = array( 'status' => $status );
		if ( null !== $hash ) {
			$data['source_hash'] = $hash;
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table.
		$wpdb->update(
			self::table(),
			$data,
			array(
				'object_type' => $type,
				'object_id'   => $id,
				'field'       => $field,
				'language'    => $language,
			)
		);
		unset( self::$cache[ $type . ':' . $id . ':' . $language ] );
	}

	/**
	 * Deletes translations: one field, all the fields of a language or of every language.
	 *
	 * @param string      $type     «post» or «term».
	 * @param int         $id       Object id.
	 * @param string|null $field    Field, null for all.
	 * @param string|null $language Locale, null for all.
	 * @return bool Whether something was deleted.
	 */
	public static function delete( string $type, int $id, ?string $field = null, ?string $language = null ): bool {
		global $wpdb;
		$where = array(
			'object_type' => $type,
			'object_id'   => $id,
		);
		if ( null !== $field ) {
			$where['field'] = $field;
		}
		if ( null !== $language ) {
			$where['language'] = $language;
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table.
		$deleted = (int) $wpdb->delete( self::table(), $where );
		foreach ( array_keys( self::$cache ) as $key ) {
			if ( str_starts_with( $key, $type . ':' . $id . ':' ) ) {
				unset( self::$cache[ $key ] );
			}
		}
		if ( $deleted > 0 && ( null === $field || 'slug' === $field ) ) {
			Slugs::flush();
		}
		return $deleted > 0;
	}

	/**
	 * Objects whose translated slug in a language is one of these.
	 *
	 * @param string   $language Locale.
	 * @param string[] $slugs    Slugs.
	 * @return array<int, array{type: string, subtype: string, id: int, slug: string}>
	 */
	public static function by_slugs( string $language, array $slugs ): array {
		global $wpdb;
		$slugs = array_values( array_unique( array_filter( array_map( 'strval', $slugs ) ) ) );
		if ( ! $slugs ) {
			return array();
		}
		$placeholders = implode( ',', array_fill( 0, count( $slugs ), '%s' ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- placeholders built for the list; own table, one indexed query per request.
		$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT object_type, object_subtype, object_id, slug FROM %i WHERE language = %s AND slug IN ({$placeholders})", self::table(), $language, ...$slugs ), ARRAY_A );
		return array_map(
			static fn( array $row ): array => array(
				'type'    => (string) $row['object_type'],
				'subtype' => (string) $row['object_subtype'],
				'id'      => (int) $row['object_id'],
				'slug'    => (string) $row['slug'],
			),
			$rows
		);
	}

	/**
	 * Translated slugs of a kind of object in a language, by object id.
	 *
	 * @param string   $language Locale.
	 * @param string   $type     «post» or «term».
	 * @param string[] $subtypes Post types or taxonomies.
	 * @return array<int, string>
	 */
	public static function slugs( string $language, string $type, array $subtypes ): array {
		global $wpdb;
		if ( ! $subtypes ) {
			return array();
		}
		$placeholders = implode( ',', array_fill( 0, count( $subtypes ), '%s' ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- placeholders built for the list; own table; Slugs keeps the result.
		$rows = (array) $wpdb->get_results( $wpdb->prepare( "SELECT object_id, slug FROM %i WHERE language = %s AND object_type = %s AND slug IS NOT NULL AND object_subtype IN ({$placeholders})", self::table(), $language, $type, ...$subtypes ), ARRAY_A );
		$out  = array();
		foreach ( $rows as $row ) {
			$out[ (int) $row['object_id'] ] = (string) $row['slug'];
		}
		return $out;
	}

	/**
	 * How many translations there are by language and state.
	 *
	 * @return array<string, array<string, int>>
	 */
	public static function counts(): array {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table, for the panel and the CLI.
		$rows = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT language, status, COUNT(*) AS total FROM %i GROUP BY language, status', self::table() ), ARRAY_A );
		$out  = array();
		foreach ( $rows as $row ) {
			$out[ (string) $row['language'] ][ (string) $row['status'] ] = (int) $row['total'];
		}
		return $out;
	}

	/**
	 * Every translation of an object, for the export and the editor.
	 *
	 * @param string $type «post» or «term».
	 * @param int    $id   Object id.
	 * @return array<string, array<string, array{text: string, hash: string, status: string, origin: string, updated: string}>> By language and field.
	 */
	public static function all( string $type, int $id ): array {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table.
		$rows = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT language, field, text, source_hash, status, origin, updated_at FROM %i WHERE object_type = %s AND object_id = %d', self::table(), $type, $id ), ARRAY_A );
		$out  = array();
		foreach ( $rows as $row ) {
			$out[ (string) $row['language'] ][ (string) $row['field'] ] = array(
				'text'    => (string) $row['text'],
				'hash'    => (string) $row['source_hash'],
				'status'  => (string) $row['status'],
				'origin'  => (string) $row['origin'],
				'updated' => (string) $row['updated_at'],
			);
		}
		return $out;
	}

	/**
	 * Forgets what was read in this request (tests, after a bulk import).
	 */
	public static function reset(): void {
		self::$cache = array();
	}

	/**
	 * A slug no other object of the same kind uses in that language: «-2», «-3»… as
	 * WordPress does.
	 *
	 * @param string $type     «post» or «term».
	 * @param string $subtype  Post type or taxonomy.
	 * @param int    $id       Object id.
	 * @param string $language Locale.
	 * @param string $slug     Clean slug.
	 */
	private static function unique_slug( string $type, string $subtype, int $id, string $language, string $slug ): string {
		global $wpdb;
		if ( '' === $slug ) {
			return '';
		}
		$candidate = $slug;
		for ( $suffix = 2; $suffix < 100; $suffix++ ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table, only when a slug is written.
			$taken = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT object_id FROM %i WHERE language = %s AND object_type = %s AND object_subtype = %s AND slug = %s AND object_id <> %d LIMIT 1', self::table(), $language, $type, $subtype, $candidate, $id ) );
			if ( 0 === $taken ) {
				return $candidate;
			}
			$candidate = $slug . '-' . $suffix;
		}
		return $slug . '-' . $id;
	}
}
