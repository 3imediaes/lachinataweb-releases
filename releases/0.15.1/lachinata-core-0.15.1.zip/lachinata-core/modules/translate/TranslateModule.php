<?php
/**
 * Module `translate`: the shop in other languages.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

use LaChinata\Core\Hooks;
use LaChinata\Core\Module;
use LaChinata\Core\Plugin;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Replaces TranslatePress (07-traduccion.md). Translations are fields of the same post or
 * term, kept in its own table, never copies: one product in every language, with the same
 * id, stock, price and orders. Each language lives in its subdirectory (`/en/`) with
 * translated addresses, `hreflang` and its sitemap; a page exists in a language only when it
 * is translated whole. It serves `Contracts\Languages`; the other modules declare their
 * fields with `lachinata/translate/fields`. Off, there is a single language and the
 * translations stay. Claude, the controls and the queues arrive in 11c.
 */
final class TranslateModule extends Module {

	/**
	 * Module id.
	 */
	public function id(): string {
		return 'translate';
	}

	/**
	 * Module name.
	 */
	public function label(): string {
		return __( 'Traducción', 'lachinata-core' );
	}

	/**
	 * Module description.
	 */
	public function description(): string {
		return __( 'Sirve la tienda en otros idiomas, cada uno en su subdirectorio (/en/) con direcciones traducidas, hreflang y su sitemap. Las traducciones son campos de la misma ficha y se corrigen en el editor, al lado del español. Los idiomas se configuran en Traducción.', 'lachinata-core' );
	}

	/**
	 * Version in which the module was added.
	 */
	public function since(): string {
		return '0.15.0';
	}

	/**
	 * Documentation.
	 */
	public function docs(): string {
		return 'plugin/modules/translate/README.md';
	}

	/**
	 * Requirements.
	 *
	 * @return array{woocommerce: string}
	 */
	public function requires(): array {
		return array( 'woocommerce' => '10.0' );
	}

	/**
	 * Settings: the languages of the shop and whether only the reviewed Spanish enters
	 * the queue (07, «Primero el español»).
	 *
	 * @return array<string, array{type: 'bool'|'int'|'float'|'string'|'array', default: mixed, export?: bool}>
	 */
	public function settings(): array {
		return array(
			'languages'     => array(
				'type'    => 'array',
				'default' => array(),
				'export'  => true,
			),
			'only_reviewed' => array(
				'type'    => 'bool',
				'default' => true,
				'export'  => true,
			),
		);
	}

	/**
	 * The module, for Settings.
	 */
	public static function instance(): ?Module {
		return Plugin::instance()->modules()->get( 'translate' );
	}

	/**
	 * A setting of the module.
	 *
	 * @param string $key Setting key.
	 * @return mixed
	 */
	public static function setting( string $key ) {
		$module = self::instance();
		return null === $module ? null : Settings::get( $module, $key );
	}

	/**
	 * Version of the data: v1 creates the table of translations.
	 */
	public function schema_version(): int {
		return 1;
	}

	/**
	 * Steps of the data.
	 *
	 * @return array<int, callable(): void>
	 */
	public function migrations(): array {
		return array( 1 => array( Store::class, 'install' ) );
	}

	/**
	 * The languages, how many translations each one has and the strings of WordPress and
	 * WooCommerce in each language.
	 *
	 * @return array{configured: bool, credentials: null, notes: string[]}
	 */
	public function health(): array {
		$languages = Config::languages();
		$notes     = array();
		if ( ! $languages ) {
			$notes[] = __( 'Sin otros idiomas: la tienda sale solo en el suyo.', 'lachinata-core' );
		}
		$counts = Store::counts();
		foreach ( $languages as $locale => $language ) {
			$states  = $counts[ $locale ] ?? array();
			$notes[] = sprintf(
				/* translators: 1: language, 2: code, 3: translated fields, 4: outdated fields. */
				__( '%1$s (/%2$s/): %3$d campos traducidos, %4$d desfasados.', 'lachinata-core' ),
				'' !== $language['label'] ? $language['label'] : $locale,
				$language['code'],
				array_sum( $states ),
				$states[ Store::OUTDATED ] ?? 0
			);
			if ( ! is_readable( WP_LANG_DIR . '/plugins/woocommerce-' . $locale . '.mo' ) ) {
				/* translators: %s: locale. */
				$notes[] = sprintf( __( 'Faltan las cadenas de WooCommerce en %1$s: Escritorio → Actualizaciones, o wp language plugin install woocommerce %1$s.', 'lachinata-core' ), $locale );
			}
		}
		$notes[] = self::setting( 'only_reviewed' )
			? __( 'Solo el español «Revisado» entra en la cola de traducción.', 'lachinata-core' )
			: __( 'Todo el español entra en la cola de traducción, revisado o no.', 'lachinata-core' );
		return array(
			'configured'  => (bool) $languages,
			'credentials' => null,
			'notes'       => $notes,
		);
	}

	/**
	 * What it keeps beyond its options: the table, where each page exists and the language
	 * of each order (never deleted: it is the order's history).
	 *
	 * @return array{product_meta: string[], term_meta: string[], order_meta: string[], tables: string[]}
	 */
	public function owned_data(): array {
		return array(
			'product_meta' => array( Availability::META ),
			'term_meta'    => array( Availability::META ),
			'order_meta'   => array( Emails::META ),
			'tables'       => array( Store::TABLE ),
		);
	}

	/**
	 * Serves the languages of the shop.
	 *
	 * @param mixed $languages Service of another module, or null.
	 * @return mixed
	 */
	public static function service( $languages ) {
		return null === $languages ? Service::instance() : $languages;
	}

	/**
	 * Registers the hooks. The service and the panel always; addresses, texts, SEO and
	 * emails only with another language.
	 */
	public function boot(): void {
		Config::capture();
		Hooks::add_filter( 'lachinata/languages/service', array( self::class, 'service' ) );
		if ( is_admin() ) {
			TranslateTab::boot();
		}
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::add_command( 'lachinata translate', Cli::class );
		}
		if ( ! Config::languages() ) {
			return;
		}
		Router::boot();
		Front::boot();
		Seo::boot();
		Sync::boot();
		Emails::boot();
		if ( is_admin() ) {
			Editor::boot();
		}
	}
}
