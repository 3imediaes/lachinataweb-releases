<?php
/**
 * WooCommerce → La Chinata → Traducción.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

use LaChinata\Core\Admin\Screen;
use LaChinata\Core\Hooks;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * The languages of the shop (locale, code of the address, name) and whether only the
 * reviewed Spanish is translated, with how many translations each language has. The queue,
 * the spending limit, the glossary and «Revisar» arrive in 11c.
 */
final class TranslateTab {

	/**
	 * Tab id.
	 */
	public const TAB = 'translate';

	/**
	 * Action of admin-post.php, also nonce action.
	 */
	private const SAVE = 'lachinata_translate_settings';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/core/admin_tabs', array( self::class, 'tab' ), 40 );
		Hooks::add_action( 'admin_post_' . self::SAVE, array( self::class, 'handle' ) );
	}

	/**
	 * Adds the tab after Destino.
	 *
	 * @param array<string, array{label: string, render: callable}> $tabs Tabs.
	 * @return array<string, array{label: string, render: callable}>
	 */
	public static function tab( array $tabs ): array {
		$position = array_search( 'locale', array_keys( $tabs ), true );
		$position = false === $position ? count( $tabs ) : $position + 1;
		$tab      = array(
			self::TAB => array(
				'label'  => __( 'Traducción', 'lachinata-core' ),
				'render' => array( self::class, 'render' ),
			),
		);
		return array_slice( $tabs, 0, $position, true ) + $tab + $tabs;
	}

	/**
	 * Prints the tab.
	 */
	public static function render(): void {
		$languages = Config::languages();
		$rows      = array();
		foreach ( $languages as $locale => $language ) {
			$rows[] = array(
				'locale' => $locale,
				'code'   => $language['code'],
				'label'  => $language['label'],
			);
		}
		$rows[] = array(
			'locale' => '',
			'code'   => '',
			'label'  => '',
		);
		$counts = Store::counts();
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE ); ?>">
			<?php wp_nonce_field( self::SAVE ); ?>
			<h2><?php esc_html_e( 'Idiomas', 'lachinata-core' ); ?></h2>
			<p class="description">
				<?php
				printf(
					/* translators: %s: language of the site («es_ES»). */
					esc_html__( 'El idioma del sitio (%s) es siempre el origen y va sin prefijo. Cada otro idioma vive en su subdirectorio.', 'lachinata-core' ),
					'<code>' . esc_html( Config::default_language() ) . '</code>'
				);
				?>
			</p>
			<table class="widefat striped" style="max-width:48em">
				<thead><tr><th scope="col"><?php esc_html_e( 'Locale', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Código (dirección y hreflang)', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Nombre', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Traducciones', 'lachinata-core' ); ?></th></tr></thead>
				<tbody>
					<?php foreach ( $rows as $index => $row ) : ?>
						<tr>
							<td><label class="screen-reader-text" for="lc-tr-locale-<?php echo esc_attr( (string) $index ); ?>"><?php esc_html_e( 'Locale', 'lachinata-core' ); ?></label><input id="lc-tr-locale-<?php echo esc_attr( (string) $index ); ?>" type="text" name="languages[<?php echo esc_attr( (string) $index ); ?>][locale]" value="<?php echo esc_attr( $row['locale'] ); ?>" placeholder="en_GB" class="regular-text" style="width:8em"></td>
							<td><label class="screen-reader-text" for="lc-tr-code-<?php echo esc_attr( (string) $index ); ?>"><?php esc_html_e( 'Código', 'lachinata-core' ); ?></label><input id="lc-tr-code-<?php echo esc_attr( (string) $index ); ?>" type="text" name="languages[<?php echo esc_attr( (string) $index ); ?>][code]" value="<?php echo esc_attr( $row['code'] ); ?>" placeholder="en" style="width:5em"></td>
							<td><label class="screen-reader-text" for="lc-tr-label-<?php echo esc_attr( (string) $index ); ?>"><?php esc_html_e( 'Nombre', 'lachinata-core' ); ?></label><input id="lc-tr-label-<?php echo esc_attr( (string) $index ); ?>" type="text" name="languages[<?php echo esc_attr( (string) $index ); ?>][label]" value="<?php echo esc_attr( $row['label'] ); ?>" placeholder="English"></td>
							<td><?php echo '' === $row['locale'] ? '' : esc_html( number_format_i18n( array_sum( $counts[ $row['locale'] ] ?? array() ) ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<p class="description"><?php esc_html_e( 'Para quitar un idioma, vacía su fila: sus traducciones se conservan.', 'lachinata-core' ); ?></p>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Qué se traduce', 'lachinata-core' ); ?></th>
					<td>
						<label><input type="checkbox" name="only_reviewed" value="1" <?php checked( (bool) TranslateModule::setting( 'only_reviewed' ) ); ?>> <?php esc_html_e( 'Solo productos, páginas y entradas con el español «Revisado»', 'lachinata-core' ); ?></label>
						<p class="description"><?php esc_html_e( 'Términos, menús, oleotecas y bloques de la home no tienen estado y se traducen siempre.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
		<?php
	}

	/**
	 * Saves the settings.
	 */
	public static function handle(): void {
		Screen::check( self::SAVE );
		$module = TranslateModule::instance();
		if ( null !== $module ) {
			// phpcs:disable WordPress.Security.NonceVerification.Missing -- Screen::check().
			$posted = isset( $_POST['languages'] ) && is_array( $_POST['languages'] ) ? map_deep( wp_unslash( $_POST['languages'] ), 'sanitize_text_field' ) : array();
			$rows   = array_values( array_filter( (array) $posted, static fn( $row ): bool => is_array( $row ) && '' !== trim( (string) ( $row['locale'] ?? '' ) ) ) );
			$errors = Config::validate( $rows );
			$clean  = array();
			foreach ( Config::clean( $rows ) as $locale => $language ) {
				$clean[] = array_merge( array( 'locale' => $locale ), $language );
			}
			Settings::set( $module, 'languages', $clean );
			Settings::set( $module, 'only_reviewed', ! empty( $_POST['only_reviewed'] ) );
			// phpcs:enable
			Config::reset();
			Slugs::flush();
			flush_rewrite_rules( false );
			Screen::flash( $errors ? 'error' : 'success', $errors ? $errors : array( __( 'Ajustes guardados.', 'lachinata-core' ) ) );
		}
		Screen::redirect( self::TAB );
	}
}
