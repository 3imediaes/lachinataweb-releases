<?php
/**
 * WooCommerce → La Chinata → IDs de producto.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Admin;

use LaChinata\Core\ProductIds;

defined( 'ABSPATH' ) || exit;

/**
 * The id each destination knows a product by (ProductIds), with a preview on a real
 * product so the shop can compare it with its Merchant Center or Meta catalog.
 */
final class ProductIdsTab {

	/**
	 * Tab id.
	 */
	public const TAB = 'product-ids';

	/**
	 * Action of admin-post.php, also the nonce action and the form id.
	 */
	private const SAVE = 'lachinata_core_product_ids';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_filter( 'lachinata/core/admin_tabs', array( self::class, 'tab' ), 7 );
		add_action( 'admin_post_' . self::SAVE, array( self::class, 'handle' ) );
	}

	/**
	 * Adds the tab before Exportar/importar.
	 *
	 * @param array<string, array{label: string, render: callable}> $tabs Tabs.
	 * @return array<string, array{label: string, render: callable}>
	 */
	public static function tab( array $tabs ): array {
		$tab      = array(
			self::TAB => array(
				'label'  => __( 'IDs de producto', 'lachinata-core' ),
				'render' => array( self::class, 'render' ),
			),
		);
		$position = array_search( 'transfer', array_keys( $tabs ), true );
		$position = false === $position ? count( $tabs ) : $position;
		return array_slice( $tabs, 0, $position, true ) + $tab + $tabs;
	}

	/**
	 * Prints the tab.
	 */
	public static function render(): void {
		$kept    = Screen::take_field_errors( self::SAVE );
		$errors  = $kept['errors'];
		$config  = array_replace_recursive( ProductIds::config(), array_intersect_key( $kept['posted'], array_flip( ProductIds::DESTINATIONS ) ) );
		$samples = self::samples();
		?>
		<p><?php esc_html_e( 'Merchant Center y Meta guardan el historial y las campañas de cada producto por su ID: si cambia, el producto empieza de cero. Si vienes de otro plugin, elige el formato que usaba y compáralo con el ID que muestra tu catálogo para el mismo producto.', 'lachinata-core' ); ?></p>
		<p class="description"><?php esc_html_e( 'Los eventos de medición y los feeds usan el mismo ID de su destino. Marcadores de la plantilla personalizada: {product_id} (el ID del producto o de la variación), {variation_id}, {parent_id} y {sku}. Si sale vacío (SKU sin rellenar), se usa {product_id}.', 'lachinata-core' ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" novalidate>
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE ); ?>">
			<?php wp_nonce_field( self::SAVE ); ?>
			<table class="form-table" role="presentation">
				<?php foreach ( ProductIds::destinations() as $destination => $label ) : ?>
					<?php
					$id  = 'lc-ids-' . $destination;
					$row = $config[ $destination ];
					?>
					<tr>
						<th scope="row"><label for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label></th>
						<td>
							<select id="<?php echo esc_attr( $id ); ?>" name="ids[<?php echo esc_attr( $destination ); ?>][preset]">
								<?php foreach ( ProductIds::presets() as $preset => $name ) : ?>
									<option value="<?php echo esc_attr( $preset ); ?>" <?php selected( $row['preset'], $preset ); ?>><?php echo esc_html( $name ); ?></option>
								<?php endforeach; ?>
							</select>
							<p>
								<label for="<?php echo esc_attr( $id ); ?>-template"><?php esc_html_e( 'Plantilla personalizada', 'lachinata-core' ); ?></label><br>
								<input type="text" class="regular-text code" id="<?php echo esc_attr( $id ); ?>-template" name="ids[<?php echo esc_attr( $destination ); ?>][template]" value="<?php echo esc_attr( (string) $row['template'] ); ?>" placeholder="tienda_{product_id}" maxlength="<?php echo esc_attr( (string) ProductIds::MAX_LENGTH ); ?>"<?php echo isset( $errors[ $destination ] ) ? ' aria-invalid="true" aria-describedby="' . esc_attr( $id ) . '-template-error"' : ''; ?>>
							</p>
							<?php Screen::field_error( $errors, $destination, $id . '-template' ); ?>
							<?php if ( $samples ) : ?>
								<p class="description">
									<?php
									$shown = array();
									foreach ( $samples as $product ) {
										$shown[] = sprintf( '%1$s → %2$s', $product->get_name(), ProductIds::get( $product, $destination ) );
									}
									/* translators: %s: list of «product → id». */
									echo esc_html( sprintf( __( 'Ahora: %s', 'lachinata-core' ), implode( ' · ', $shown ) ) );
									?>
								</p>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</table>
			<p class="description"><?php esc_html_e( 'Entra en la exportación de configuración (sección «core»).', 'lachinata-core' ); ?></p>
			<?php submit_button(); ?>
		</form>
		<?php
	}

	/**
	 * A simple product and a variation of this shop for the preview.
	 *
	 * @return \WC_Product[]
	 */
	private static function samples(): array {
		$out = array();
		foreach ( array( 'simple', 'variation' ) as $type ) {
			$found = wc_get_products(
				array(
					'type'   => $type,
					'status' => 'publish',
					'limit'  => 1,
				)
			);
			if ( is_array( $found ) && isset( $found[0] ) && $found[0] instanceof \WC_Product ) {
				$out[] = $found[0];
			}
		}
		return $out;
	}

	/**
	 * Saves the configuration, or goes back with the error under each field.
	 */
	public static function handle(): void {
		Screen::check( self::SAVE );
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Screen::check(); sanitized below and validated by ProductIds::save().
		$posted = isset( $_POST['ids'] ) && is_array( $_POST['ids'] ) ? (array) wp_unslash( $_POST['ids'] ) : array();
		$config = array();
		foreach ( ProductIds::DESTINATIONS as $destination ) {
			$row                    = is_array( $posted[ $destination ] ?? null ) ? $posted[ $destination ] : array();
			$config[ $destination ] = array(
				'preset'   => sanitize_key( (string) ( $row['preset'] ?? '' ) ),
				'template' => sanitize_text_field( (string) ( $row['template'] ?? '' ) ),
			);
		}
		$errors = ProductIds::save( $config );
		if ( $errors ) {
			Screen::field_errors( self::SAVE, $errors, $config );
			Screen::flash( 'error', array( __( 'No se ha guardado: revisa los campos marcados.', 'lachinata-core' ) ) );
			Screen::redirect( self::TAB );
		}
		Screen::flash( 'success', array( __( 'IDs de producto guardados.', 'lachinata-core' ) ) );
		Screen::redirect( self::TAB );
	}
}
