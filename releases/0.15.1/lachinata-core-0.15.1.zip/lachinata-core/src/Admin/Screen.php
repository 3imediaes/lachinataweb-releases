<?php
/**
 * WooCommerce → La Chinata.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * The plugin screen under WooCommerce, with one tab per area (Módulos, Exportar/importar,
 * Actualizaciones; modules add theirs with `lachinata/core/admin_tabs`).
 */
final class Screen {

	/**
	 * Page slug.
	 */
	public const SLUG = 'lachinata';

	/**
	 * Capability to see and use the screen.
	 */
	public const CAPABILITY = 'manage_woocommerce';

	/**
	 * Hook suffix of the page, set when the menu is added.
	 *
	 * @var string
	 */
	private static string $hook = '';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_action( 'admin_menu', array( self::class, 'menu' ), 60 );
		add_action( 'admin_enqueue_scripts', array( self::class, 'enqueue' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( LACHINATA_CORE_FILE ), array( self::class, 'action_links' ) );
		ModulesTab::boot();
		ContactTab::boot();
		CompanyTab::boot();
		ProductIdsTab::boot();
		TransferTab::boot();
		UpdatesTab::boot();
	}

	/**
	 * Adds the page under WooCommerce.
	 */
	public static function menu(): void {
		self::$hook = (string) add_submenu_page(
			'woocommerce',
			__( 'La Chinata', 'lachinata-core' ),
			__( 'La Chinata', 'lachinata-core' ),
			self::CAPABILITY,
			self::SLUG,
			array( self::class, 'render' )
		);
	}

	/**
	 * «Ajustes» link in the plugin row of Plugins.
	 *
	 * @param string[] $links Action links.
	 * @return string[]
	 */
	public static function action_links( array $links ): array {
		if ( current_user_can( self::CAPABILITY ) ) {
			array_unshift( $links, sprintf( '<a href="%1$s">%2$s</a>', esc_url( self::url( 'modules' ) ), esc_html__( 'Ajustes', 'lachinata-core' ) ) );
		}
		return $links;
	}

	/**
	 * Loads the screen styles, only on this page.
	 *
	 * @param string $hook_suffix Current admin page.
	 */
	public static function enqueue( string $hook_suffix ): void {
		if ( '' === self::$hook || self::$hook !== $hook_suffix ) {
			return;
		}
		wp_enqueue_style( 'lachinata-core-admin', plugins_url( 'assets/admin.css', LACHINATA_CORE_FILE ), array(), LACHINATA_CORE_VERSION );
	}

	/**
	 * Tabs of the screen.
	 *
	 * @return array<string, array{label: string, render: callable}>
	 */
	public static function tabs(): array {
		$tabs = array(
			'modules'  => array(
				'label'  => __( 'Módulos', 'lachinata-core' ),
				'render' => array( ModulesTab::class, 'render' ),
			),
			'transfer' => array(
				'label'  => __( 'Exportar/importar', 'lachinata-core' ),
				'render' => array( TransferTab::class, 'render' ),
			),
			'updates'  => array(
				'label'  => __( 'Actualizaciones', 'lachinata-core' ),
				'render' => array( UpdatesTab::class, 'render' ),
			),
		);
		/**
		 * Tabs of WooCommerce → La Chinata. Modules add their screens here.
		 *
		 * @since 0.3.0
		 *
		 * @param array<string, array{label: string, render: callable}> $tabs Tabs keyed by id.
		 */
		return (array) apply_filters( 'lachinata/core/admin_tabs', $tabs );
	}

	/**
	 * URL of a tab.
	 *
	 * @param string               $tab  Tab id.
	 * @param array<string, mixed> $args Extra query arguments.
	 */
	public static function url( string $tab, array $args = array() ): string {
		return add_query_arg(
			array_merge(
				array(
					'page' => self::SLUG,
					'tab'  => $tab,
				),
				$args
			),
			admin_url( 'admin.php' )
		);
	}

	/**
	 * Links between the sections of a tab («Zonas | Probador | Huecos de configuración»).
	 *
	 * @param string                $tab      Tab id.
	 * @param array<string, string> $sections Labels by section id.
	 * @param string                $current  Current section.
	 */
	public static function section_links( string $tab, array $sections, string $current ): void {
		echo '<ul class="subsubsub lc-admin__sections">';
		$links = array();
		foreach ( $sections as $id => $label ) {
			$links[] = sprintf(
				'<li><a href="%1$s"%2$s>%3$s</a>',
				esc_url( self::url( $tab, array( 'section' => $id ) ) ),
				$id === $current ? ' class="current" aria-current="page"' : '',
				esc_html( $label )
			);
		}
		echo implode( ' | </li>', $links ) . '</li></ul><br class="clear">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts.
	}

	/**
	 * Stops unless the current user may use the screen and the nonce matches.
	 *
	 * @param string $action Nonce action.
	 */
	public static function check( string $action ): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'No tienes permiso para hacer esto.', 'lachinata-core' ), 403 );
		}
		check_admin_referer( $action );
	}

	/**
	 * Keeps a message for the next page load of the current user.
	 *
	 * @param string   $type     success, error, warning or info.
	 * @param string[] $messages Messages.
	 */
	public static function flash( string $type, array $messages ): void {
		set_transient(
			'lachinata_core_notice_' . get_current_user_id(),
			array(
				'type'     => $type,
				'messages' => $messages,
			),
			MINUTE_IN_SECONDS * 5
		);
	}

	/**
	 * Link to a usage guide of the plugin («medicion», a module id, «core»), published with
	 * each release on the public site of the versions (docs/guias/, without data of any shop).
	 *
	 * @param string $slug Guide.
	 */
	public static function guide_url( string $slug ): string {
		/**
		 * Where the usage guides of the plugin are read (a mirror or a local copy).
		 *
		 * @since 0.10.0
		 *
		 * @param string $base Base URL ending in a slash.
		 */
		$base = (string) apply_filters( 'lachinata/core/docs_url', \LaChinata\Core\Updates\Manifest::base_url() . 'guias/' );
		return trailingslashit( $base ) . sanitize_key( $slug ) . '.html';
	}

	/**
	 * Keeps the errors of a form, by field, and what was typed, for the next page load of
	 * the current user: the form shows each error under its field with the typed value.
	 *
	 * @param string                $form   Form id.
	 * @param array<string, string> $errors Message by field name.
	 * @param array<string, mixed>  $posted Values that were sent (never credentials).
	 */
	public static function field_errors( string $form, array $errors, array $posted = array() ): void {
		set_transient(
			'lachinata_core_fields_' . $form . '_' . get_current_user_id(),
			array(
				'errors' => $errors,
				'posted' => $posted,
			),
			MINUTE_IN_SECONDS * 5
		);
	}

	/**
	 * Errors and typed values kept by field_errors(), once: reading them forgets them.
	 *
	 * @param string $form Form id.
	 * @return array{errors: array<string, string>, posted: array<string, mixed>}
	 */
	public static function take_field_errors( string $form ): array {
		$key   = 'lachinata_core_fields_' . $form . '_' . get_current_user_id();
		$saved = get_transient( $key );
		delete_transient( $key );
		$saved = is_array( $saved ) ? $saved : array();
		return array(
			'errors' => is_array( $saved['errors'] ?? null ) ? $saved['errors'] : array(),
			'posted' => is_array( $saved['posted'] ?? null ) ? $saved['posted'] : array(),
		);
	}

	/**
	 * Prints the error of a field (from take_field_errors()), tied to it by `aria-describedby`
	 * with the id `<field id>-error`.
	 *
	 * @param array<string, string> $errors   Errors by field name.
	 * @param string                $name     Field name.
	 * @param string                $field_id Id of the input.
	 */
	public static function field_error( array $errors, string $name, string $field_id ): void {
		if ( empty( $errors[ $name ] ) ) {
			return;
		}
		printf( '<p class="lc-admin-error" id="%1$s-error" role="alert">%2$s</p>', esc_attr( $field_id ), esc_html( $errors[ $name ] ) );
	}

	/**
	 * Goes back to a tab and stops.
	 *
	 * @param string               $tab  Tab id.
	 * @param array<string, mixed> $args Extra query arguments.
	 */
	public static function redirect( string $tab, array $args = array() ): never {
		wp_safe_redirect( self::url( $tab, $args ) );
		exit;
	}

	/**
	 * Prints the page.
	 */
	public static function render(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		$tabs    = self::tabs();
		$current = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'modules'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Navigation only.
		if ( ! isset( $tabs[ $current ] ) ) {
			$current = 'modules';
		}
		echo '<div class="wrap lc-admin">';
		echo '<h1>' . esc_html__( 'La Chinata', 'lachinata-core' ) . '</h1>';
		echo '<nav class="nav-tab-wrapper" aria-label="' . esc_attr__( 'Secciones', 'lachinata-core' ) . '">';
		foreach ( $tabs as $id => $tab ) {
			printf(
				'<a href="%1$s" class="nav-tab%2$s"%3$s>%4$s</a>',
				esc_url( self::url( $id ) ),
				$id === $current ? ' nav-tab-active' : '',
				$id === $current ? ' aria-current="page"' : '',
				esc_html( $tab['label'] )
			);
		}
		echo '</nav>';
		self::print_notice();
		call_user_func( $tabs[ $current ]['render'] );
		echo '</div>';
	}

	/**
	 * Prints and forgets the message kept by flash().
	 */
	private static function print_notice(): void {
		$key    = 'lachinata_core_notice_' . get_current_user_id();
		$notice = get_transient( $key );
		if ( ! is_array( $notice ) || empty( $notice['messages'] ) ) {
			return;
		}
		delete_transient( $key );
		$type = in_array( $notice['type'] ?? '', array( 'success', 'error', 'warning', 'info' ), true ) ? $notice['type'] : 'info';
		printf( '<div class="notice notice-%s">', esc_attr( $type ) );
		foreach ( (array) $notice['messages'] as $message ) {
			echo '<p>' . esc_html( (string) $message ) . '</p>';
		}
		echo '</div>';
	}

	/**
	 * A value for people: Sí/No, «—» for nothing, JSON for lists.
	 *
	 * @param mixed $value Value.
	 */
	public static function format_value( $value ): string {
		if ( is_bool( $value ) ) {
			return $value ? __( 'Sí', 'lachinata-core' ) : __( 'No', 'lachinata-core' );
		}
		if ( null === $value || '' === $value ) {
			return '—';
		}
		if ( is_scalar( $value ) ) {
			return (string) $value;
		}
		return (string) wp_json_encode( $value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
	}
}
