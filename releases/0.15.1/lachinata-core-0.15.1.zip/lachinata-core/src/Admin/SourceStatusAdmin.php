<?php
/**
 * «Español: Pendiente / Revisado» in the lists and the editor.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Admin;

use LaChinata\Core\SourceStatus;

defined( 'ABSPATH' ) || exit;

/**
 * The state of the Spanish text where people work: a column and a filter in the lists of
 * products, pages and posts, two bulk actions to mark many at once, and a box in the
 * editor (classic and block editor) to change one.
 */
final class SourceStatusAdmin {

	/**
	 * Column, filter and bulk actions.
	 */
	private const COLUMN = 'lc_source_status';

	/**
	 * Query argument of the filter.
	 */
	private const FILTER = 'lc_source_status';

	/**
	 * Query argument of the notice after a bulk action.
	 */
	private const DONE = 'lc_source_marked';

	/**
	 * Nonce of the editor box.
	 */
	private const NONCE = 'lc_source_status_nonce';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_action( 'admin_init', array( self::class, 'register' ) );
		add_action( 'add_meta_boxes', array( self::class, 'meta_box' ), 10, 2 );
		add_action( 'save_post', array( self::class, 'save' ), 10, 2 );
		add_action( 'restrict_manage_posts', array( self::class, 'filter_field' ), 20, 1 );
		add_action( 'pre_get_posts', array( self::class, 'filter_query' ) );
		add_action( 'admin_notices', array( self::class, 'notice' ) );
	}

	/**
	 * The column and the bulk actions of each list.
	 */
	public static function register(): void {
		foreach ( SourceStatus::post_types() as $post_type ) {
			add_filter( "manage_{$post_type}_posts_columns", array( self::class, 'columns' ), 20 );
			add_action( "manage_{$post_type}_posts_custom_column", array( self::class, 'cell' ), 10, 2 );
			add_filter( "bulk_actions-edit-{$post_type}", array( self::class, 'bulk_actions' ) );
			add_filter( "handle_bulk_actions-edit-{$post_type}", array( self::class, 'bulk' ), 10, 3 );
		}
	}

	/**
	 * «Español» after the title.
	 *
	 * @param mixed $columns Columns.
	 * @return array<string, string>
	 */
	public static function columns( $columns ): array {
		$columns = is_array( $columns ) ? $columns : array();
		$out     = array();
		foreach ( $columns as $key => $label ) {
			$out[ $key ] = $label;
			if ( 'title' === $key || 'name' === $key ) {
				$out[ self::COLUMN ] = __( 'Español', 'lachinata-core' );
			}
		}
		if ( ! isset( $out[ self::COLUMN ] ) ) {
			$out[ self::COLUMN ] = __( 'Español', 'lachinata-core' );
		}
		return $out;
	}

	/**
	 * The state of a row.
	 *
	 * @param mixed $column  Column.
	 * @param mixed $post_id Post id.
	 */
	public static function cell( $column, $post_id ): void {
		if ( self::COLUMN === $column ) {
			echo esc_html( SourceStatus::labels()[ SourceStatus::get( (int) $post_id ) ] );
		}
	}

	/**
	 * «Marcar el español como revisado» and «… como pendiente».
	 *
	 * @param mixed $actions Bulk actions.
	 * @return array<string, string>
	 */
	public static function bulk_actions( $actions ): array {
		$actions = is_array( $actions ) ? $actions : array();
		$actions[ self::COLUMN . '_' . SourceStatus::REVIEWED ] = __( 'Marcar el español como revisado', 'lachinata-core' );
		$actions[ self::COLUMN . '_' . SourceStatus::PENDING ]  = __( 'Marcar el español como pendiente', 'lachinata-core' );
		return $actions;
	}

	/**
	 * Marks the chosen posts the user can edit.
	 *
	 * @param mixed $redirect Where to go back.
	 * @param mixed $action   Bulk action.
	 * @param mixed $ids      Post ids.
	 */
	public static function bulk( $redirect, $action, $ids ): string {
		$redirect = (string) $redirect;
		$status   = str_starts_with( (string) $action, self::COLUMN . '_' ) ? substr( (string) $action, strlen( self::COLUMN ) + 1 ) : '';
		if ( ! in_array( $status, array( SourceStatus::PENDING, SourceStatus::REVIEWED ), true ) ) {
			return $redirect;
		}
		$marked = 0;
		foreach ( array_map( 'absint', (array) $ids ) as $id ) {
			if ( current_user_can( 'edit_post', $id ) && SourceStatus::set( $id, $status ) ) {
				++$marked;
			}
		}
		return add_query_arg( self::DONE, $marked, $redirect );
	}

	/**
	 * «N marcados» after a bulk action.
	 */
	public static function notice(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only a count to show.
		if ( ! isset( $_GET[ self::DONE ] ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only a count to show.
		$count = absint( wp_unslash( $_GET[ self::DONE ] ) );
		printf(
			'<div class="notice notice-success is-dismissible"><p>%s</p></div>',
			esc_html(
				sprintf(
					/* translators: %s: number of products, pages or posts. */
					_n( 'Estado del español cambiado en %s elemento.', 'Estado del español cambiado en %s elementos.', $count, 'lachinata-core' ),
					number_format_i18n( $count )
				)
			)
		);
	}

	/**
	 * «Español: todos / Pendiente / Revisado» above the list.
	 *
	 * @param mixed $post_type Post type of the list.
	 */
	public static function filter_field( $post_type ): void {
		if ( ! in_array( (string) $post_type, SourceStatus::post_types(), true ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- A list filter.
		$current = isset( $_GET[ self::FILTER ] ) ? sanitize_key( wp_unslash( $_GET[ self::FILTER ] ) ) : '';
		printf( '<label class="screen-reader-text" for="%1$s">%2$s</label>', esc_attr( self::FILTER ), esc_html__( 'Estado del español', 'lachinata-core' ) );
		printf( '<select name="%1$s" id="%1$s"><option value="">%2$s</option>', esc_attr( self::FILTER ), esc_html__( 'Español: todos', 'lachinata-core' ) );
		foreach ( SourceStatus::labels() as $value => $label ) {
			/* translators: %s: state of the Spanish text («Pendiente»). */
			printf( '<option value="%1$s"%2$s>%3$s</option>', esc_attr( $value ), selected( $current, $value, false ), esc_html( sprintf( __( 'Español: %s', 'lachinata-core' ), $label ) ) );
		}
		echo '</select>';
	}

	/**
	 * Applies the filter to the main query of the list.
	 *
	 * @param \WP_Query $query Query.
	 */
	public static function filter_query( \WP_Query $query ): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- A list filter.
		$status = isset( $_GET[ self::FILTER ] ) ? sanitize_key( wp_unslash( $_GET[ self::FILTER ] ) ) : '';
		if ( '' === $status || ! is_admin() || ! $query->is_main_query() || ! in_array( (string) $query->get( 'post_type' ), SourceStatus::post_types(), true ) ) {
			return;
		}
		$meta_query   = (array) $query->get( 'meta_query' );
		$meta_query[] = SourceStatus::meta_query( $status );
		$query->set( 'meta_query', $meta_query );
	}

	/**
	 * «Texto en español» in the side of the editor.
	 *
	 * @param mixed $post_type Post type.
	 * @param mixed $post      Post.
	 */
	public static function meta_box( $post_type, $post = null ): void {
		unset( $post );
		if ( ! in_array( (string) $post_type, SourceStatus::post_types(), true ) ) {
			return;
		}
		add_meta_box( 'lc-source-status', __( 'Texto en español', 'lachinata-core' ), array( self::class, 'box' ), (string) $post_type, 'side', 'default' );
	}

	/**
	 * The two states, and what «Revisado» means.
	 *
	 * @param \WP_Post $post Post.
	 */
	public static function box( \WP_Post $post ): void {
		wp_nonce_field( 'lc_source_status_' . $post->ID, self::NONCE );
		$current = SourceStatus::get( $post->ID );
		echo '<fieldset><legend class="screen-reader-text">' . esc_html__( 'Estado del texto en español', 'lachinata-core' ) . '</legend>';
		foreach ( SourceStatus::labels() as $value => $label ) {
			printf(
				'<p><label><input type="radio" name="lc_source_status" value="%1$s"%2$s> %3$s</label></p>',
				esc_attr( $value ),
				checked( $current, $value, false ),
				esc_html( $label )
			);
		}
		echo '</fieldset><p class="description">' . esc_html__( 'Solo lo revisado se traduce a los demás idiomas.', 'lachinata-core' ) . '</p>';
	}

	/**
	 * Saves the box.
	 *
	 * @param mixed $post_id Post id.
	 * @param mixed $post    Post.
	 */
	public static function save( $post_id, $post = null ): void {
		$post_id = (int) $post_id;
		if ( ! $post instanceof \WP_Post || wp_is_post_revision( $post_id ) || ! isset( $_POST[ self::NONCE ], $_POST['lc_source_status'] ) ) {
			return;
		}
		if ( ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST[ self::NONCE ] ) ), 'lc_source_status_' . $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		SourceStatus::set( $post_id, SourceStatus::sanitize( sanitize_key( wp_unslash( $_POST['lc_source_status'] ) ) ) );
	}
}
