<?php
/**
 * Legal details of the company that runs the shop.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core;

defined( 'ABSPATH' ) || exit;

/**
 * «Datos de la empresa»: trade name, legal name, tax id, registered address, privacy email and the
 * legal pages. They belong to the core because several readers need them: the cookie
 * policy (`tracking`), the legal footer of the emails, the structured data of `content`
 * and the invoice. The theme and the modules read them with the filter `lachinata/company`
 * (empty by default). Each site keeps its own: they never travel in the configuration
 * export.
 */
final class Company {

	/**
	 * Option with the values.
	 */
	public const OPTION = 'lachinata_core_company';

	/**
	 * Text keys, in the order of the screen.
	 */
	public const TEXTS = array( 'trade_name', 'legal_name', 'tax_id', 'address', 'privacy_email', 'brand' );

	/**
	 * Legal pages, by key.
	 */
	public const PAGES = array( 'privacy_page', 'cookies_page', 'legal_page' );

	/**
	 * Networks of «Redes», in the order of SocialLinks (since 0.13.0).
	 */
	public const NETWORKS = array( 'instagram', 'facebook', 'tiktok', 'youtube', 'x', 'web' );

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_filter( 'lachinata/company', array( self::class, 'fill' ) );
	}

	/**
	 * The saved values. The address falls back to the shop's address in WooCommerce and
	 * the privacy page to the one of WordPress (Ajustes → Privacidad).
	 *
	 * @return array{trade_name: string, legal_name: string, tax_id: string, address: string, privacy_email: string, brand: string, privacy_page: int, cookies_page: int, legal_page: int}
	 */
	public static function get(): array {
		$saved  = get_option( self::OPTION, array() );
		$saved  = is_array( $saved ) ? $saved : array();
		$values = array();
		foreach ( self::TEXTS as $key ) {
			$values[ $key ] = is_string( $saved[ $key ] ?? null ) ? trim( $saved[ $key ] ) : '';
		}
		foreach ( self::PAGES as $key ) {
			$values[ $key ] = is_numeric( $saved[ $key ] ?? null ) ? (int) $saved[ $key ] : 0;
		}
		if ( '' === $values['address'] ) {
			$values['address'] = self::store_address();
		}
		if ( 0 === $values['privacy_page'] ) {
			$values['privacy_page'] = (int) get_option( 'wp_page_for_privacy_policy', 0 );
		}
		/**
		 * The keys are all there.
		 *
		 * @var array{trade_name: string, legal_name: string, tax_id: string, address: string, privacy_email: string, brand: string, privacy_page: int, cookies_page: int, legal_page: int} $values
		 */
		return $values;
	}

	/**
	 * Saves the values (unknown keys are dropped).
	 *
	 * @param array<string, mixed> $values Values.
	 */
	public static function save( array $values ): void {
		$clean = array(
			'trade_name'    => sanitize_text_field( (string) ( $values['trade_name'] ?? '' ) ),
			'legal_name'    => sanitize_text_field( (string) ( $values['legal_name'] ?? '' ) ),
			'tax_id'        => strtoupper( (string) preg_replace( '/[^A-Za-z0-9\-]/', '', (string) ( $values['tax_id'] ?? '' ) ) ),
			'address'       => sanitize_text_field( (string) ( $values['address'] ?? '' ) ),
			'privacy_email' => sanitize_email( (string) ( $values['privacy_email'] ?? '' ) ),
			'brand'         => sanitize_text_field( (string) ( $values['brand'] ?? '' ) ),
		);
		foreach ( self::PAGES as $key ) {
			$clean[ $key ] = absint( $values[ $key ] ?? 0 );
		}
		$clean['social'] = array();
		$social          = is_array( $values['social'] ?? null ) ? $values['social'] : array();
		foreach ( self::NETWORKS as $network ) {
			$url = esc_url_raw( trim( (string) ( $social[ $network ] ?? '' ) ), array( 'https', 'http' ) );
			if ( '' !== $url ) {
				$clean['social'][ $network ] = $url;
			}
		}
		update_option( self::OPTION, $clean, false );
	}

	/**
	 * Brand of a product for the feeds and the measurement: its WooCommerce brand
	 * (`product_brand`, the parent's for a variation), else the brand of the shop, else the
	 * trade name.
	 *
	 * @param \WC_Product $product Product or variation.
	 */
	public static function brand( \WC_Product $product ): string {
		$id = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();
		if ( taxonomy_exists( 'product_brand' ) ) {
			$terms = get_the_terms( $id, 'product_brand' );
			if ( is_array( $terms ) && isset( $terms[0] ) ) {
				return html_entity_decode( $terms[0]->name );
			}
		}
		$brand = self::get()['brand'];
		return '' !== $brand ? $brand : self::trade_name();
	}

	/**
	 * The shop's name for people («La Chinata»): the trade name of Datos de la empresa, else
	 * the site name of WordPress. Never the slug or the domain.
	 */
	public static function trade_name(): string {
		$name = self::get()['trade_name'];
		return '' !== $name ? $name : trim( wp_specialchars_decode( html_entity_decode( (string) get_bloginfo( 'name' ), ENT_QUOTES, 'UTF-8' ), ENT_QUOTES ) );
	}

	/**
	 * «Redes»: the profiles of the brand, in the order of SocialLinks. The structured data
	 * (`sameAs`) and the footer read them from here, the only source.
	 *
	 * @return array<int, array{network: string, url: string}>
	 */
	public static function social(): array {
		$saved  = get_option( self::OPTION, array() );
		$social = is_array( $saved ) && is_array( $saved['social'] ?? null ) ? $saved['social'] : array();
		$links  = array();
		foreach ( self::NETWORKS as $network ) {
			if ( is_string( $social[ $network ] ?? null ) && '' !== $social[ $network ] ) {
				$links[] = array(
					'network' => $network,
					'url'     => $social[ $network ],
				);
			}
		}
		return $links;
	}

	/**
	 * Sets one legal page, keeping the rest as saved (without the fallbacks of get()).
	 *
	 * @param string $key     privacy_page, cookies_page or legal_page.
	 * @param int    $page_id Page id.
	 */
	public static function set_page( string $key, int $page_id ): void {
		if ( ! in_array( $key, self::PAGES, true ) ) {
			return;
		}
		$saved         = get_option( self::OPTION, array() );
		$saved         = is_array( $saved ) ? $saved : array();
		$saved[ $key ] = max( 0, $page_id );
		update_option( self::OPTION, $saved, false );
	}

	/**
	 * Address of the shop as WooCommerce → Ajustes → Generales has it, in one line.
	 */
	public static function store_address(): string {
		if ( ! function_exists( 'WC' ) || ! WC()->countries ) {
			return '';
		}
		$countries = WC()->countries;
		$country   = $countries->get_base_country();
		$state     = $countries->get_base_state();
		$states    = $countries->get_states( $country );
		$parts     = array(
			$countries->get_base_address(),
			$countries->get_base_address_2(),
			trim( $countries->get_base_postcode() . ' ' . $countries->get_base_city() ),
			is_array( $states ) && isset( $states[ $state ] ) ? html_entity_decode( (string) $states[ $state ] ) : '',
			html_entity_decode( (string) ( $countries->get_countries()[ $country ] ?? '' ) ),
		);
		return implode( ', ', array_filter( array_map( 'trim', $parts ) ) );
	}

	/**
	 * Link of a legal page, or an empty string while it is not set or not published.
	 *
	 * @param string $key privacy_page, cookies_page or legal_page.
	 */
	public static function url( string $key ): string {
		$id = (int) ( self::get()[ $key ] ?? 0 );
		return $id > 0 && 'publish' === get_post_status( $id ) ? (string) get_permalink( $id ) : '';
	}

	/**
	 * `lachinata/company`: the values, with the page links.
	 *
	 * @param mixed $company What the reader passes (empty values).
	 * @return array{trade_name: string, legal_name: string, tax_id: string, address: string, privacy_email: string, privacy_url: string, cookies_url: string, legal_url: string, social: array<int, array{network: string, url: string}>}
	 */
	public static function fill( $company ): array {
		unset( $company );
		$values = self::get();
		return array(
			'trade_name'    => $values['trade_name'],
			'legal_name'    => $values['legal_name'],
			'tax_id'        => $values['tax_id'],
			'address'       => $values['address'],
			'privacy_email' => $values['privacy_email'],
			'privacy_url'   => self::url( 'privacy_page' ),
			'cookies_url'   => self::url( 'cookies_page' ),
			'legal_url'     => self::url( 'legal_page' ),
			'social'        => self::social(),
		);
	}
}
