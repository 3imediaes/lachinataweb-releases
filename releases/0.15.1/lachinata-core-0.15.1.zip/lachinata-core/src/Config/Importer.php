<?php
/**
 * Configuration import.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Config;

use LaChinata\Core\ModuleRegistry;
use LaChinata\Core\ProductIds;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Reads a document made by Exporter in two steps: plan() validates everything and lists
 * the changes without writing; apply() writes a plan without errors.
 */
final class Importer {

	/**
	 * Builds the registry-aware importer.
	 *
	 * @param ModuleRegistry $modules Module registry.
	 */
	public function __construct( private ModuleRegistry $modules ) {}

	/**
	 * Decodes JSON text into a document.
	 *
	 * @param string $json JSON text.
	 * @return array<mixed>|null Null when it is not a JSON object.
	 */
	public static function decode( string $json ): ?array {
		$document = json_decode( $json, true );
		return is_array( $document ) ? $document : null;
	}

	/**
	 * Validates a document and lists what would change. Writes nothing.
	 *
	 * @param array<mixed>  $document Decoded document.
	 * @param string[]|null $only     Module ids to import; null for all in the document.
	 */
	public function plan( array $document, ?array $only = null ): ImportPlan {
		$plan = new ImportPlan();

		if ( Exporter::FORMAT !== ( $document['format'] ?? null ) ) {
			$plan->errors[] = __( 'No es un archivo de configuración de La Chinata Core.', 'lachinata-core' );
			return $plan;
		}
		$schema = $document['schema'] ?? null;
		if ( ! is_int( $schema ) || $schema < 1 ) {
			$plan->errors[] = __( 'El archivo no indica su versión de formato.', 'lachinata-core' );
			return $plan;
		}
		if ( $schema > Exporter::SCHEMA ) {
			$plan->errors[] = sprintf(
				/* translators: 1: plugin version that made the file, 2: installed plugin version. */
				__( 'El archivo se exportó con La Chinata Core %1$s, que usa un formato posterior al de esta instalación (%2$s). Actualiza el plugin antes de importarlo.', 'lachinata-core' ),
				is_string( $document['version'] ?? null ) ? $document['version'] : '?',
				LACHINATA_CORE_VERSION
			);
			return $plan;
		}
		$sections = $document['modules'] ?? null;
		if ( ! is_array( $sections ) ) {
			$plan->errors[] = __( 'Al archivo le falta la lista de módulos.', 'lachinata-core' );
			return $plan;
		}
		$plan->source = is_string( $document['site'] ?? null ) ? $document['site'] : '';

		$core = $document['core']['product_ids'] ?? null;
		if ( null !== $core && ( null === $only || in_array( 'core', $only, true ) ) ) {
			if ( ! is_array( $core ) ) {
				$plan->errors[] = __( 'Los IDs de producto del archivo no son una lista.', 'lachinata-core' );
			} else {
				foreach ( ProductIds::validate( $core ) as $destination => $message ) {
					/* translators: 1: destination (google, meta, ga4), 2: problem. */
					$plan->errors[] = sprintf( __( 'IDs de producto (%1$s): %2$s', 'lachinata-core' ), $destination, $message );
				}
				$plan->core['product_ids'] = $core;
				if ( ProductIds::config() !== array_replace( ProductIds::config(), $core ) ) {
					$plan->changes[] = array(
						'module' => 'core',
						'field'  => __( 'IDs de producto', 'lachinata-core' ),
						'from'   => ProductIds::config(),
						'to'     => $core,
					);
				}
			}
		}

		$enabled = $this->modules->enabled();
		foreach ( $sections as $id => $section ) {
			$id = (string) $id;
			if ( null !== $only && ! in_array( $id, $only, true ) ) {
				continue;
			}
			$module = $this->modules->get( $id );
			if ( null === $module ) {
				/* translators: %s: module id. */
				$plan->warnings[] = sprintf( __( 'El módulo %s no existe en esta instalación: se ignora.', 'lachinata-core' ), $id );
				continue;
			}
			if ( ! is_array( $section ) || ! is_bool( $section['enabled'] ?? null ) ) {
				/* translators: %s: module id. */
				$plan->errors[] = sprintf( __( 'El módulo %s no indica si está activo.', 'lachinata-core' ), $id );
				continue;
			}

			$plan->modules[] = $id;
			$is_enabled      = in_array( $id, $enabled, true );
			if ( $section['enabled'] !== $is_enabled ) {
				$plan->changes[] = array(
					'module' => $id,
					'field'  => __( 'Activo', 'lachinata-core' ),
					'from'   => $is_enabled,
					'to'     => $section['enabled'],
				);
			}
			$plan->enabled[ $id ] = $section['enabled'];

			$settings = $section['settings'] ?? array();
			if ( ! is_array( $settings ) ) {
				/* translators: %s: module id. */
				$plan->errors[] = sprintf( __( 'Los ajustes del módulo %s no son una lista.', 'lachinata-core' ), $id );
				continue;
			}
			$schemas = $module->settings();
			foreach ( $settings as $key => $value ) {
				$key    = (string) $key;
				$schema = $schemas[ $key ] ?? null;
				if ( null === $schema || false === ( $schema['export'] ?? true ) ) {
					/* translators: 1: setting key, 2: module id. */
					$plan->warnings[] = sprintf( __( 'El ajuste %1$s del módulo %2$s no se importa: se ignora.', 'lachinata-core' ), $key, $id );
					continue;
				}
				if ( ! Settings::is_valid( $schema['type'], $value ) ) {
					/* translators: 1: setting key, 2: module id, 3: expected type. */
					$plan->errors[] = sprintf( __( 'El ajuste %1$s del módulo %2$s debe ser de tipo %3$s.', 'lachinata-core' ), $key, $id, $schema['type'] );
					continue;
				}
				if ( 'float' === $schema['type'] ) {
					$value = (float) $value; // JSON writes 150.0 as 150.
				}
				$plan->settings[ $id ][ $key ] = $value;
				$current                       = Settings::get( $module, $key );
				if ( $current !== $value ) {
					$plan->changes[] = array(
						'module' => $id,
						'field'  => $key,
						'from'   => $current,
						'to'     => $value,
					);
				}
			}

			$data = $section['data'] ?? array();
			if ( ! is_array( $data ) ) {
				/* translators: %s: module id. */
				$plan->errors[] = sprintf( __( 'Los datos del módulo %s no son una lista.', 'lachinata-core' ), $id );
				continue;
			}
			foreach ( $module->validate_data( $data ) as $message ) {
				$plan->errors[] = sprintf( '%1$s: %2$s', $id, $message );
			}
			if ( $data ) {
				$plan->data[ $id ] = $data;
				$plan->changes[]   = array(
					'module' => $id,
					'field'  => __( 'Datos del módulo', 'lachinata-core' ),
					'from'   => null,
					'to'     => $data,
				);
			}
		}

		return $plan;
	}

	/**
	 * Writes a plan. A plan with errors writes nothing.
	 *
	 * @param ImportPlan $plan Plan from plan().
	 */
	public function apply( ImportPlan $plan ): bool {
		if ( $plan->errors ) {
			return false;
		}
		foreach ( $plan->enabled as $id => $on ) {
			if ( $on ) {
				$this->modules->enable( $id );
			} else {
				$this->modules->disable( $id );
			}
		}
		foreach ( $plan->settings as $id => $values ) {
			$module = $this->modules->get( $id );
			foreach ( $values as $key => $value ) {
				if ( null !== $module ) {
					Settings::set( $module, $key, $value );
				}
			}
		}
		if ( isset( $plan->core['product_ids'] ) ) {
			ProductIds::save( $plan->core['product_ids'] );
		}
		foreach ( $plan->data as $id => $data ) {
			$this->modules->get( $id )?->import_data( $data );
		}

		/**
		 * Fires after a configuration import was written.
		 *
		 * @since 0.3.0
		 *
		 * @param ImportPlan $plan Imported plan.
		 */
		do_action( 'lachinata/core/config_imported', $plan );
		return true;
	}
}
