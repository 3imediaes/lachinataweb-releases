<?php
/**
 * Languages the shop sells in.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Contracts;

defined( 'ABSPATH' ) || exit;

/**
 * The languages of the shop and how a text or a link reads in each one. The core serves a
 * single language, the one of the site (Languages\SiteLanguage); `translate` serves the
 * others with the same contract. Readers (the feeds, `llms.txt`, the selector of `locale`)
 * loop over languages() and never assume there is only one.
 *
 * Version 2 (0.15.0): the language of the request, the code of the address, whether a page
 * exists in a language, its address there, the alternates of the current page and a way to
 * render something in another language (an email, a feed, `llms.txt`).
 */
interface Languages {

	/**
	 * Version of the contract (docs/arquitectura-modulos.md, «Versiones de un contrato»).
	 */
	public const VERSION = 2;

	/**
	 * Language codes of the shop (WordPress locales, «es_ES», «cs_CZ»), the default first.
	 *
	 * @return string[]
	 */
	public function languages(): array;

	/**
	 * The default language.
	 */
	public function default_language(): string;

	/**
	 * Name of a language for people («Español»).
	 *
	 * @param string $language Locale.
	 */
	public function label( string $language ): string;

	/**
	 * Title and description of a product (or variation) in a language. Without a
	 * translation, the original.
	 *
	 * @param \WC_Product $product  Product or variation.
	 * @param string      $language Locale.
	 * @return array{title: string, description: string, short_description: string}
	 */
	public function product_texts( \WC_Product $product, string $language ): array;

	/**
	 * Name of a term (a category) in a language.
	 *
	 * @param \WP_Term $term     Term.
	 * @param string   $language Locale.
	 */
	public function term_name( \WP_Term $term, string $language ): string;

	/**
	 * A link of the shop in a language (a product permalink, the home…).
	 *
	 * @param string $url      Link in the default language.
	 * @param string $language Locale.
	 */
	public function url( string $url, string $language ): string;

	/**
	 * Language of this request: the one of the address (`/en/…`), or the one switched to
	 * with switch_to(); the default otherwise.
	 *
	 * @since 0.15.0
	 */
	public function current(): string;

	/**
	 * Code of a language in the addresses and in `hreflang` («en» for «en_GB»).
	 *
	 * @since 0.15.0
	 *
	 * @param string $language Locale.
	 */
	public function code( string $language ): string;

	/**
	 * Whether a post (product, page, entry…) or a term exists in a language: always in the
	 * default; in another, only when it is translated whole.
	 *
	 * @since 0.15.0
	 *
	 * @param string $type     «post» or «term».
	 * @param int    $id       Post or term id.
	 * @param string $language Locale.
	 */
	public function available( string $type, int $id, string $language ): bool;

	/**
	 * Address of a post in a language; the default one when it does not exist there.
	 *
	 * @since 0.15.0
	 *
	 * @param int    $post_id  Post id.
	 * @param string $language Locale.
	 */
	public function post_url( int $post_id, string $language ): string;

	/**
	 * Address of a term in a language; the default one when it does not exist there.
	 *
	 * @since 0.15.0
	 *
	 * @param int    $term_id  Term id.
	 * @param string $language Locale.
	 */
	public function term_url( int $term_id, string $language ): string;

	/**
	 * The current page in each language where it exists, the default first (the
	 * `hreflang` and the selector of the language).
	 *
	 * @since 0.15.0
	 *
	 * @return array<string, string> Address by locale.
	 */
	public function alternates(): array;

	/**
	 * Renders what follows in a language (texts, links and the strings of WordPress) until
	 * restore(): an email in the language of its order, a feed, `llms.txt`.
	 *
	 * @since 0.15.0
	 *
	 * @param string $language Locale.
	 */
	public function switch_to( string $language ): void;

	/**
	 * Back to the language before the last switch_to().
	 *
	 * @since 0.15.0
	 */
	public function restore(): void;
}
