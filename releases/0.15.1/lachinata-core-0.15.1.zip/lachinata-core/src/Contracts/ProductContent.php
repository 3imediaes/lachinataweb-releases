<?php
/**
 * Net content of a product.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Contracts;

defined( 'ABSPATH' ) || exit;

/**
 * The amount a product holds («500 ml») and the reference for its unit price («1 l»).
 * Served by `catalog` (Services::product_content()); the feeds use it for
 * `unit_pricing_measure` and `unit_pricing_base_measure`.
 */
interface ProductContent {

	/**
	 * Content of a product or variation (variations inherit the parent's), or null.
	 * Units: g, kg, ml, l or ud (units).
	 *
	 * @param \WC_Product $product Product or variation.
	 * @return array{amount: float, unit: string}|null
	 */
	public function content( \WC_Product $product ): ?array;

	/**
	 * Reference quantity of the unit price («1 l», «100 g»), or null.
	 *
	 * @param \WC_Product $product Product or variation.
	 * @return array{amount: float, unit: string}|null
	 */
	public function reference( \WC_Product $product ): ?array;
}
