<?php
/**
 * The shipping rules of the site, for the modules that need them.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Contracts;

defined( 'ABSPATH' ) || exit;

/**
 * What the `shipping` module decides that others read (`eta`, `locale`, the theme's
 * function lachinata_producto_enviable()). Ask Services::shipping_rules(); null while
 * `shipping` is off.
 *
 * Version 2 (0.11.0) adds free_shipping_from(); version 3 (0.12.2), unavailable_message().
 */
interface ShippingRules {

	/**
	 * Version of the contract: 1 since 0.9.0, 2 since 0.11.0, 3 since 0.12.2.
	 */
	public const VERSION = 3;

	/**
	 * Whether a product can ship to a destination: true, or the reason
	 * (`producto_restringido`, `zona_no_cubierta`, `peso_max`).
	 *
	 * @param \WC_Product                                               $product     Product or variation.
	 * @param array{country: string, state?: string, postcode?: string} $destination Destination.
	 * @return true|string
	 */
	public function shippable( \WC_Product $product, array $destination ): true|string;

	/**
	 * Zone used when the visitor's destination is not known (0: the rest of the world).
	 */
	public function default_zone_id(): int;

	/**
	 * Amount of the order from which shipping to a destination is free (the threshold of
	 * its zone), or null when the zone has none. Since 0.11.0 (version 2).
	 *
	 * @param array{country: string, state?: string, postcode?: string} $destination Destination.
	 */
	public function free_shipping_from( array $destination ): ?float;

	/**
	 * Notice of a product page when the product does not ship to the visitor's destination
	 * («Lo sentimos, este producto no está disponible en tu país.»), as plain text. Since
	 * 0.12.2 (version 3).
	 */
	public function unavailable_message(): string;
}
