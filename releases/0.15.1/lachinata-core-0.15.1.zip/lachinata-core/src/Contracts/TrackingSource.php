<?php
/**
 * Where the tracking of an order comes from.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Contracts;

defined( 'ABSPATH' ) || exit;

/**
 * Tracking of a shipped order. The core reads WooCommerce Shipment Tracking (what Odoo
 * writes); register another source with `lachinata/shipment/sources`.
 */
interface TrackingSource {

	/**
	 * The latest tracking of an order, or null.
	 *
	 * @param \WC_Order $order Order.
	 * @return array{carrier: string, number: string, url: string, shipped: int|null}|null
	 */
	public function find( \WC_Order $order ): ?array;
}
