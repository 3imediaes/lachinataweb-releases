<?php
/**
 * GTIN (EAN, UPC) of a product.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Whether a GTIN can exist: 8, 12, 13 or 14 digits and the right check digit (GS1). The
 * feeds leave out the ones that cannot; the catalog health lists them.
 */
final class Gtin {

	/**
	 * Digits of a GTIN as typed (spaces and dashes out).
	 *
	 * @param string $gtin GTIN.
	 */
	public static function digits( string $gtin ): string {
		return (string) preg_replace( '/\D/', '', $gtin );
	}

	/**
	 * Whether the number of digits is one a GTIN has.
	 *
	 * @param string $gtin GTIN (digits).
	 */
	public static function valid_length( string $gtin ): bool {
		return in_array( strlen( $gtin ), array( 8, 12, 13, 14 ), true );
	}

	/**
	 * Whether the last digit is the check digit of the others (GS1 modulo 10).
	 *
	 * @param string $gtin GTIN (digits).
	 */
	public static function valid_check_digit( string $gtin ): bool {
		if ( ! self::valid_length( $gtin ) || 1 !== preg_match( '/^\d+$/', $gtin ) ) {
			return false;
		}
		$body = strrev( substr( $gtin, 0, -1 ) );
		$sum  = 0;
		foreach ( str_split( $body ) as $index => $digit ) {
			$sum += (int) $digit * ( 0 === $index % 2 ? 3 : 1 );
		}
		return ( 10 - $sum % 10 ) % 10 === (int) substr( $gtin, -1 );
	}

	/**
	 * Whether the GTIN can exist.
	 *
	 * @param string $gtin GTIN as typed.
	 */
	public static function valid( string $gtin ): bool {
		return self::valid_check_digit( self::digits( $gtin ) );
	}
}
