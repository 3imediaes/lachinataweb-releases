<?php
/**
 * The language of the site, while no module serves more.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Languages;

use LaChinata\Core\Contracts\Languages;

defined( 'ABSPATH' ) || exit;

/**
 * One language, the locale of the site, with the texts and links as they are.
 */
final class SiteLanguage implements Languages {

	/**
	 * Languages of the shop: only the site's.
	 *
	 * @return string[]
	 */
	public function languages(): array {
		return array( $this->default_language() );
	}

	/**
	 * The locale of the site.
	 */
	public function default_language(): string {
		return get_locale();
	}

	/**
	 * Name of the language, from the WordPress translations when they are installed.
	 *
	 * @param string $language Locale.
	 */
	public function label( string $language ): string {
		if ( 'en_US' === $language ) {
			return 'English';
		}
		if ( ! function_exists( 'wp_get_available_translations' ) ) {
			require_once ABSPATH . 'wp-admin/includes/translation-install.php';
		}
		// Reads the cached list of WordPress.org; without it, the locale itself.
		$known = wp_get_available_translations();
		return isset( $known[ $language ]['native_name'] ) ? (string) $known[ $language ]['native_name'] : $language;
	}

	/**
	 * The product's own texts.
	 *
	 * @param \WC_Product $product  Product or variation.
	 * @param string      $language Locale.
	 * @return array{title: string, description: string, short_description: string}
	 */
	public function product_texts( \WC_Product $product, string $language ): array {
		unset( $language );
		return array(
			'title'             => $product->get_name(),
			'description'       => (string) $product->get_description(),
			'short_description' => (string) $product->get_short_description(),
		);
	}

	/**
	 * The term's own name.
	 *
	 * @param \WP_Term $term     Term.
	 * @param string   $language Locale.
	 */
	public function term_name( \WP_Term $term, string $language ): string {
		unset( $language );
		return $term->name;
	}

	/**
	 * The link as it is.
	 *
	 * @param string $url      Link.
	 * @param string $language Locale.
	 */
	public function url( string $url, string $language ): string {
		unset( $language );
		return $url;
	}

	/**
	 * Always the site's.
	 */
	public function current(): string {
		return $this->default_language();
	}

	/**
	 * The language part of the locale («es» for «es_ES»).
	 *
	 * @param string $language Locale.
	 */
	public function code( string $language ): string {
		return strtolower( (string) strtok( $language, '_' ) );
	}

	/**
	 * Everything exists in the site's language, nothing in another.
	 *
	 * @param string $type     «post» or «term».
	 * @param int    $id       Post or term id.
	 * @param string $language Locale.
	 */
	public function available( string $type, int $id, string $language ): bool {
		unset( $type, $id );
		return $language === $this->default_language();
	}

	/**
	 * The permalink.
	 *
	 * @param int    $post_id  Post id.
	 * @param string $language Locale.
	 */
	public function post_url( int $post_id, string $language ): string {
		unset( $language );
		return (string) get_permalink( $post_id );
	}

	/**
	 * The term's link.
	 *
	 * @param int    $term_id  Term id.
	 * @param string $language Locale.
	 */
	public function term_url( int $term_id, string $language ): string {
		unset( $language );
		$link = get_term_link( $term_id );
		return is_string( $link ) ? $link : '';
	}

	/**
	 * The current page, only in the site's language.
	 *
	 * @return array<string, string>
	 */
	public function alternates(): array {
		$path = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_parse_url( esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ), PHP_URL_PATH ) : '/';
		return array( $this->default_language() => home_url( '' !== $path ? $path : '/' ) );
	}

	/**
	 * Nothing to switch to.
	 *
	 * @param string $language Locale.
	 */
	public function switch_to( string $language ): void {
		unset( $language );
	}

	/**
	 * Nothing to restore.
	 */
	public function restore(): void {}
}
