<?php
/**
 * Module registry.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Keeps the known modules, which ones are enabled on this site and which ones booted.
 */
final class ModuleRegistry {

	/**
	 * Option that stores the enabled module ids.
	 */
	public const OPTION = 'lachinata_core_modules';

	/**
	 * Modules enabled when the plugin is activated for the first time.
	 */
	public const DEFAULTS = array( 'catalog' );

	/**
	 * Emergency switch in wp-config.php: `'gift,notify'` or `'*'`. Those modules (and the
	 * ones that need them) do not boot, whatever the panel says.
	 */
	public const DISABLE_CONSTANT = 'LACHINATA_DISABLE_MODULES';

	/**
	 * Registered modules, keyed by id.
	 *
	 * @var array<string, Module>
	 */
	private array $modules = array();

	/**
	 * Ids of the modules that booted in this request.
	 *
	 * @var array<string, true>
	 */
	private array $booted = array();

	/**
	 * Adds a module to the registry.
	 *
	 * @param Module $module Module instance.
	 */
	public function register( Module $module ): void {
		$this->modules[ $module->id() ] = $module;
	}

	/**
	 * All registered modules.
	 *
	 * @return array<string, Module>
	 */
	public function all(): array {
		return $this->modules;
	}

	/**
	 * Module by id.
	 *
	 * @param string $id Module id.
	 */
	public function get( string $id ): ?Module {
		return $this->modules[ $id ] ?? null;
	}

	/**
	 * Ids enabled on this site.
	 *
	 * @return string[]
	 */
	public function enabled(): array {
		$enabled = get_option( self::OPTION, array() );
		return is_array( $enabled ) ? array_values( array_filter( $enabled, 'is_string' ) ) : array();
	}

	/**
	 * Whether a module booted in this request (enabled and with its requirements met) and
	 * has not failed since.
	 *
	 * @param string $id Module id.
	 */
	public function is_active( string $id ): bool {
		return isset( $this->booted[ $id ] ) && ! Hooks::failed( $id );
	}

	/**
	 * Enables a module.
	 *
	 * @param string $id Module id.
	 */
	public function enable( string $id ): void {
		update_option( self::OPTION, array_values( array_unique( array_merge( $this->enabled(), array( $id ) ) ) ) );
	}

	/**
	 * Disables a module. Its data stays (delete_data() removes it).
	 *
	 * @param string $id Module id.
	 */
	public function disable( string $id ): void {
		update_option( self::OPTION, array_values( array_diff( $this->enabled(), array( $id ) ) ) );
	}

	/**
	 * Whether the emergency switch keeps a module off.
	 *
	 * @param string $id Module id.
	 */
	public function disabled_by_constant( string $id ): bool {
		return defined( self::DISABLE_CONSTANT ) && self::listed( constant( self::DISABLE_CONSTANT ), $id );
	}

	/**
	 * Whether a value of the emergency switch names a module: `'*'` or true for all,
	 * `'gift, notify'` or an array for some.
	 *
	 * @param mixed  $value Value of LACHINATA_DISABLE_MODULES.
	 * @param string $id    Module id.
	 */
	public static function listed( mixed $value, string $id ): bool {
		if ( true === $value || '*' === $value ) {
			return true;
		}
		$ids = is_array( $value ) ? $value : explode( ',', (string) $value );
		return in_array( $id, array_map( 'trim', array_map( 'strval', $ids ) ), true );
	}

	/**
	 * Unmet requirements of a module, as readable messages.
	 *
	 * @param Module $module Module.
	 * @return string[]
	 */
	public function missing_requirements( Module $module ): array {
		$missing  = array();
		$requires = $module->requires();
		$enabled  = $this->enabled();

		foreach ( $requires['modules'] ?? array() as $dependency ) {
			if ( ! in_array( $dependency, $enabled, true ) ) {
				/* translators: %s: module id. */
				$missing[] = sprintf( __( 'Necesita el módulo %s.', 'lachinata-core' ), $dependency );
			} elseif ( $this->disabled_by_constant( $dependency ) ) {
				/* translators: 1: module id, 2: constant name. */
				$missing[] = sprintf( __( 'Necesita el módulo %1$s, apagado por %2$s.', 'lachinata-core' ), $dependency, self::DISABLE_CONSTANT );
			}
		}

		if ( isset( $requires['wordpress'] ) && version_compare( (string) get_bloginfo( 'version' ), $requires['wordpress'], '<' ) ) {
			/* translators: %s: WordPress version. */
			$missing[] = sprintf( __( 'Necesita WordPress %s o superior.', 'lachinata-core' ), $requires['wordpress'] );
		}

		if ( isset( $requires['woocommerce'] ) && ( ! defined( 'WC_VERSION' ) || version_compare( WC_VERSION, $requires['woocommerce'], '<' ) ) ) {
			/* translators: %s: WooCommerce version. */
			$missing[] = sprintf( __( 'Necesita WooCommerce %s o superior.', 'lachinata-core' ), $requires['woocommerce'] );
		}

		return $missing;
	}

	/**
	 * Boots every enabled module whose requirements are met, dependencies first. A module
	 * whose boot fails is off for the request (Hooks), and so are the ones that need it.
	 */
	public function boot_enabled(): void {
		foreach ( $this->boot_order() as $id ) {
			$module = $this->modules[ $id ];
			if ( isset( $this->booted[ $id ] ) || $this->disabled_by_constant( $id ) || $this->missing_requirements( $module ) ) {
				continue;
			}
			foreach ( $module->requires()['modules'] ?? array() as $dependency ) {
				if ( ! $this->is_active( $dependency ) ) {
					continue 2;
				}
			}
			if ( ! $this->migrate( $module ) ) {
				continue;
			}
			if ( Hooks::run( $id, array( $module, 'boot' ), 'boot' ) ) {
				$this->booted[ $id ] = true;
			}
		}
	}

	/**
	 * Option with the version of a module's data.
	 *
	 * @param Module $module Module.
	 */
	public static function schema_option( Module $module ): string {
		return 'lachinata_' . $module->id() . '_schema';
	}

	/**
	 * Version of a module's data on this site (0: never migrated).
	 *
	 * @param Module $module Module.
	 */
	public function schema( Module $module ): int {
		return (int) get_option( self::schema_option( $module ), 0 );
	}

	/**
	 * Runs the module's pending migrations. False when one failed: the module does not
	 * boot and the next request tries again.
	 *
	 * @param Module $module Module.
	 */
	public function migrate( Module $module ): bool {
		$done   = $this->schema( $module );
		$target = $module->schema_version();
		if ( $done >= $target ) {
			return true;
		}
		$steps = $module->migrations();
		ksort( $steps );
		foreach ( $steps as $version => $step ) {
			if ( $version <= $done || $version > $target ) {
				continue;
			}
			if ( ! Hooks::run( $module->id(), $step, 'migración ' . $version ) ) {
				return false;
			}
			update_option( self::schema_option( $module ), $version, true );
		}
		update_option( self::schema_option( $module ), $target, true );
		return true;
	}

	/**
	 * Deletes what a module stores: its options and transients and its product, term and
	 * user meta. Never order meta, nor the version of its data. The module must be off.
	 *
	 * @param Module $module Module.
	 * @return array{options: int, meta: int}
	 */
	public function delete_data( Module $module ): array {
		global $wpdb;
		$prefix = 'lachinata_' . $module->id() . '_';
		$like   = array(
			$wpdb->esc_like( $prefix ) . '%',
			$wpdb->esc_like( '_transient_' . $prefix ) . '%',
			$wpdb->esc_like( '_transient_timeout_' . $prefix ) . '%',
		);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- one-off admin action; each option is then deleted through the API.
		$names = (array) $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s", $like[0], $like[1], $like[2] ) );
		$owned = $module->owned_data();
		// The version of its data stays: with nothing left there is nothing to migrate.
		$names = array_diff( array_unique( array_merge( $names, $owned['options'] ?? array() ) ), array( self::schema_option( $module ) ) );

		$options = 0;
		foreach ( $names as $name ) {
			$options += delete_option( (string) $name ) ? 1 : 0;
		}

		$meta = 0;
		foreach ( array(
			'product_meta' => 'post',
			'term_meta'    => 'term',
			'user_meta'    => 'user',
		) as $key => $type ) {
			foreach ( $owned[ $key ] ?? array() as $meta_key ) {
				$meta += $this->count_meta( $type, $meta_key );
				delete_metadata( $type, 0, $meta_key, '', true );
			}
		}

		$tables = $owned['tables'] ?? array();
		foreach ( $tables as $table ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.DirectDatabaseQuery.SchemaChange -- explicit «Borrar datos» of a module that declared the table.
			$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $wpdb->prefix . $table ) );
		}
		if ( $tables ) {
			// Its migrations create the tables: they must run again when it is switched on.
			delete_option( self::schema_option( $module ) );
		}

		/**
		 * A module's data was deleted from the panel or WP-CLI.
		 *
		 * @since 0.9.0
		 *
		 * @param Module $module Module.
		 */
		do_action( 'lachinata/core/data_deleted', $module );

		return array(
			'options' => $options,
			'meta'    => $meta,
		);
	}

	/**
	 * Rows of a meta key.
	 *
	 * @param string $type     post, term or user.
	 * @param string $meta_key Key.
	 */
	private function count_meta( string $type, string $meta_key ): int {
		global $wpdb;
		$table = _get_meta_table( $type );
		if ( ! $table ) {
			return 0;
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name from _get_meta_table().
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE meta_key = %s", $meta_key ) );
	}

	/**
	 * Enabled and registered ids, each after the modules it needs.
	 *
	 * @return string[]
	 */
	private function boot_order(): array {
		$order   = array();
		$visit   = function ( string $id, array $path ) use ( &$visit, &$order ): void {
			if ( isset( $order[ $id ] ) || ! isset( $this->modules[ $id ] ) || in_array( $id, $path, true ) ) {
				return;
			}
			foreach ( $this->modules[ $id ]->requires()['modules'] ?? array() as $dependency ) {
				$visit( $dependency, array_merge( $path, array( $id ) ) );
			}
			$order[ $id ] = true;
		};
		$enabled = $this->enabled();
		foreach ( $enabled as $id ) {
			$visit( $id, array() );
		}
		return array_values( array_intersect( array_keys( $order ), $enabled ) );
	}
}
