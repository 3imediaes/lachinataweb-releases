<?php
/**
 * Product identifiers per destination.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core;

defined( 'ABSPATH' ) || exit;

/**
 * The id each destination knows a product by: Google (Merchant Center feed and Google Ads
 * dynamic remarketing), Meta (catalog, pixel and Conversions API) and GA4 (no catalog: the
 * `item_id` of the reports). Merchant Center and Meta keep history and campaigns by id, so
 * a shop that migrates from another plugin picks the preset of that plugin and the ids do
 * not change. `tracking` and `feeds` both read it here, so the event and the feed of a
 * destination always agree, whichever of the two modules is on.
 *
 * Placeholders of a template: `{product_id}` the id of the item (a variation's own id),
 * `{variation_id}` (empty for a product without variations), `{parent_id}` (the parent of
 * a variation; the product itself otherwise) and `{sku}` (a variation without its own SKU
 * takes the parent's, as WooCommerce shows it). An id that would come out empty (SKU
 * template, product without SKU) falls back to `{product_id}`.
 */
final class ProductIds {

	/**
	 * Option with the preset (and template) of each destination.
	 */
	public const OPTION = 'lachinata_core_product_ids';

	/**
	 * Destinations.
	 */
	public const DESTINATIONS = array( 'google', 'meta', 'ga4' );

	/**
	 * Placeholders a template may use.
	 */
	public const PLACEHOLDERS = array( '{product_id}', '{variation_id}', '{parent_id}', '{sku}' );

	/**
	 * Longest id Merchant Center accepts.
	 */
	public const MAX_LENGTH = 50;

	/**
	 * Template of each preset. `facebook_legacy` has two forms and is resolved in code.
	 */
	private const TEMPLATES = array(
		'product_id'      => '{product_id}',
		'sku'             => '{sku}',
		'gpf'             => 'woocommerce_gpf_{product_id}',
		'facebook'        => '{product_id}',
		'facebook_legacy' => '',
	);

	/**
	 * Default preset per destination: neutral, nothing of any shop.
	 */
	private const DEFAULTS = array(
		'google' => 'product_id',
		'meta'   => 'product_id',
		'ga4'    => 'sku',
	);

	/**
	 * Presets with their names, in the order of the screen.
	 *
	 * @return array<string, string>
	 */
	public static function presets(): array {
		return array(
			'product_id'      => __( 'ID de producto', 'lachinata-core' ),
			'sku'             => __( 'SKU', 'lachinata-core' ),
			'gpf'             => __( 'Compatible con WooCommerce Google Product Feed (woocommerce_gpf_{product_id})', 'lachinata-core' ),
			'facebook'        => __( 'Compatible con Facebook for WooCommerce 3.5.17 o posterior ({product_id})', 'lachinata-core' ),
			'facebook_legacy' => __( 'Compatible con Facebook for WooCommerce anterior a 3.5.17 ({sku}_{product_id}, o wc_post_id_{product_id} sin SKU)', 'lachinata-core' ),
			'custom'          => __( 'Personalizada', 'lachinata-core' ),
		);
	}

	/**
	 * Destination names.
	 *
	 * @return array<string, string>
	 */
	public static function destinations(): array {
		return array(
			'google' => __( 'Google (Merchant Center y remarketing de Google Ads)', 'lachinata-core' ),
			'meta'   => __( 'Meta (catálogo, píxel y API de conversiones)', 'lachinata-core' ),
			'ga4'    => __( 'Google Analytics 4 (item_id de los informes)', 'lachinata-core' ),
		);
	}

	/**
	 * Saved configuration, with the defaults for what is missing or broken.
	 *
	 * @return array<string, array{preset: string, template: string}>
	 */
	public static function config(): array {
		$saved = get_option( self::OPTION, array() );
		$saved = is_array( $saved ) ? $saved : array();
		// Read once per value: a page with many products asks for every id.
		if ( null !== self::$config && self::$config[0] === $saved ) {
			return self::$config[1];
		}
		$out = array();
		foreach ( self::DESTINATIONS as $destination ) {
			$row      = is_array( $saved[ $destination ] ?? null ) ? $saved[ $destination ] : array();
			$preset   = is_string( $row['preset'] ?? null ) ? $row['preset'] : '';
			$template = is_string( $row['template'] ?? null ) ? $row['template'] : '';
			if ( ! isset( self::presets()[ $preset ] ) || ( 'custom' === $preset && '' !== self::template_error( $template ) ) ) {
				$preset   = self::DEFAULTS[ $destination ];
				$template = '';
			}
			$out[ $destination ] = array(
				'preset'   => $preset,
				'template' => 'custom' === $preset ? $template : '',
			);
		}
		self::$config = array( $saved, $out );
		return $out;
	}

	/**
	 * Configuration of this request and the stored value it comes from.
	 *
	 * @var array{0: array<mixed>, 1: array<string, array{preset: string, template: string}>}|null
	 */
	private static ?array $config = null;

	/**
	 * Problems with a configuration, by destination. Empty when it can be saved.
	 *
	 * @param array<mixed> $config Configuration as config() returns it.
	 * @return array<string, string>
	 */
	public static function validate( array $config ): array {
		$errors = array();
		foreach ( $config as $destination => $row ) {
			if ( ! in_array( $destination, self::DESTINATIONS, true ) ) {
				/* translators: %s: destination key. */
				$errors[ (string) $destination ] = sprintf( __( 'Destino desconocido: %s.', 'lachinata-core' ), (string) $destination );
				continue;
			}
			$preset = is_array( $row ) && is_string( $row['preset'] ?? null ) ? $row['preset'] : '';
			if ( ! isset( self::presets()[ $preset ] ) ) {
				$errors[ $destination ] = __( 'Elige uno de los formatos de la lista.', 'lachinata-core' );
				continue;
			}
			if ( 'custom' === $preset ) {
				$error = self::template_error( is_string( $row['template'] ?? null ) ? $row['template'] : '' );
				if ( '' !== $error ) {
					$errors[ $destination ] = $error;
				}
			}
		}
		return $errors;
	}

	/**
	 * Saves a configuration that passed validate(). Destinations left out keep their value.
	 *
	 * @param array<string, array{preset: string, template?: string}> $config Configuration.
	 * @return array<string, string> Errors by destination; nothing is saved when there are any.
	 */
	public static function save( array $config ): array {
		$errors = self::validate( $config );
		if ( $errors ) {
			return $errors;
		}
		$current = self::config();
		foreach ( $config as $destination => $row ) {
			$current[ $destination ] = array(
				'preset'   => $row['preset'],
				'template' => 'custom' === $row['preset'] ? trim( (string) ( $row['template'] ?? '' ) ) : '',
			);
		}
		update_option( self::OPTION, $current, false );
		return array();
	}

	/**
	 * Why a custom template cannot be used, or an empty string.
	 *
	 * @param string $template Template.
	 */
	public static function template_error( string $template ): string {
		$template = trim( $template );
		if ( '' === $template ) {
			return __( 'Escribe la plantilla, por ejemplo tienda_{product_id}.', 'lachinata-core' );
		}
		if ( ! preg_match( '/\{(product_id|variation_id|sku)\}/', $template ) ) {
			return __( 'La plantilla necesita {product_id}, {variation_id} o {sku}: sin ellos, todos los productos tendrían el mismo ID.', 'lachinata-core' );
		}
		$rest = str_replace( self::PLACEHOLDERS, '', $template );
		if ( str_contains( $rest, '{' ) || str_contains( $rest, '}' ) ) {
			return __( 'Solo se admiten los marcadores {product_id}, {variation_id}, {parent_id} y {sku}.', 'lachinata-core' );
		}
		if ( ! preg_match( '/^[A-Za-z0-9_.\-]*$/', $rest ) ) {
			return __( 'Fuera de los marcadores, usa solo letras sin tilde, números, guiones, puntos y guiones bajos.', 'lachinata-core' );
		}
		return '';
	}

	/**
	 * The id of a product or variation for a destination.
	 *
	 * @param \WC_Product $product     Product or variation.
	 * @param string      $destination google, meta or ga4.
	 */
	public static function get( \WC_Product $product, string $destination ): string {
		$row = self::config()[ $destination ] ?? array(
			'preset'   => 'product_id',
			'template' => '',
		);
		$id  = self::resolve( $product, $row['preset'], $row['template'] );
		/**
		 * The id of a product for a destination (for a catalog with ids of its own).
		 *
		 * @since 0.10.0
		 *
		 * @param string      $id          Id from the preset of the destination.
		 * @param \WC_Product $product     Product or variation.
		 * @param string      $destination google, meta or ga4.
		 */
		$id = (string) apply_filters( 'lachinata/product_ids/id', $id, $product, $destination );
		return '' === $id ? (string) $product->get_id() : $id;
	}

	/**
	 * The group id (`item_group_id`) of a variation for a destination: its parent's id.
	 * Empty for a product without variations.
	 *
	 * @param \WC_Product $product     Product or variation.
	 * @param string      $destination google, meta or ga4.
	 */
	public static function group( \WC_Product $product, string $destination ): string {
		if ( ! $product->is_type( 'variation' ) ) {
			return '';
		}
		$parent = wc_get_product( $product->get_parent_id() );
		return $parent instanceof \WC_Product ? self::get( $parent, $destination ) : '';
	}

	/**
	 * Fills a preset or template for a product.
	 *
	 * @param \WC_Product $product  Product or variation.
	 * @param string      $preset   Preset key.
	 * @param string      $template Template of the custom preset.
	 */
	public static function resolve( \WC_Product $product, string $preset, string $template = '' ): string {
		$sku = (string) $product->get_sku();
		if ( 'facebook_legacy' === $preset ) {
			return '' !== $sku ? $sku . '_' . $product->get_id() : 'wc_post_id_' . $product->get_id();
		}
		$template = 'custom' === $preset ? $template : ( self::TEMPLATES[ $preset ] ?? '{product_id}' );
		if ( str_contains( $template, '{sku}' ) && '' === $sku ) {
			return (string) $product->get_id();
		}
		$variation = $product->is_type( 'variation' );
		return strtr(
			$template,
			array(
				'{product_id}'   => (string) $product->get_id(),
				'{variation_id}' => $variation ? (string) $product->get_id() : '',
				'{parent_id}'    => (string) ( $variation ? $product->get_parent_id() : $product->get_id() ),
				'{sku}'          => $sku,
			)
		);
	}
}
