<?php
/**
 * Robots directives under an SEO plugin.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core;

defined( 'ABSPATH' ) || exit;

/**
 * «Do not index this page» for the theme and the modules (page 2 of the reviews, a section
 * filtered by product), whatever prints the robots meta: `lachinata/robots/noindex` goes to
 * WordPress's `wp_robots` and to Rank Math's directives (Rank Math removes every
 * `wp_robots` filter and prints its own).
 */
final class Robots {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_filter( 'wp_robots', array( self::class, 'wp_robots' ), 20 );
		add_filter( 'rank_math/frontend/robots', array( self::class, 'rank_math' ) );
	}

	/**
	 * Whether the current page is not indexed.
	 */
	public static function noindex(): bool {
		/**
		 * Whether the current page is not indexed (it is still followed).
		 *
		 * @since 0.13.0
		 *
		 * @param bool $noindex False by default.
		 */
		return (bool) apply_filters( 'lachinata/robots/noindex', false );
	}

	/**
	 * WordPress's directives.
	 *
	 * @param mixed $robots Directives.
	 * @return mixed
	 */
	public static function wp_robots( $robots ) {
		if ( is_array( $robots ) && self::noindex() ) {
			$robots['noindex'] = true;
			$robots['follow']  = true;
		}
		return $robots;
	}

	/**
	 * Rank Math's directives.
	 *
	 * @param mixed $robots Rank Math's directives (`index`, `follow`…).
	 * @return mixed
	 */
	public static function rank_math( $robots ) {
		if ( ! is_array( $robots ) ) {
			return $robots;
		}
		if ( self::noindex() ) {
			$robots['index'] = 'noindex';
		}
		return $robots;
	}
}
