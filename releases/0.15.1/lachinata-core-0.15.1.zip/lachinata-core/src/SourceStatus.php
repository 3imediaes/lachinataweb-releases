<?php
/**
 * State of the Spanish text of a product, page or post.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Whether the text in the source language (Spanish) of a product, a page or a post has been
 * reviewed: «Pendiente» or «Revisado» (07-traduccion.md, «Primero el español»). Translation
 * is the last layer: only what is «Revisado» goes into the translation queue. It describes
 * the source text, not a translation, so it lives in the core: `catalog` marks it when it
 * imports an editorial package and `translate` reads it, without either owning the other's
 * data. Without the meta, the text is «Pendiente».
 */
final class SourceStatus {

	/**
	 * Post meta with the state.
	 */
	public const META = '_lc_source_status';

	/**
	 * Not reviewed yet (also without the meta).
	 */
	public const PENDING = 'pending';

	/**
	 * Reviewed: it may be translated.
	 */
	public const REVIEWED = 'reviewed';

	/**
	 * State of the posts being deleted, read before the meta goes.
	 *
	 * @var array<int, string>
	 */
	private static array $deleting = array();

	/**
	 * Registers the meta and tells every change, whoever writes it (this class, the REST
	 * API of the editor, an import).
	 */
	public static function boot(): void {
		add_action( 'init', array( self::class, 'register' ), 20 );
		add_action( 'added_post_meta', array( self::class, 'on_write' ), 10, 4 );
		add_action( 'updated_post_meta', array( self::class, 'on_write' ), 10, 4 );
		add_action( 'delete_post_meta', array( self::class, 'before_delete' ), 10, 3 );
		add_action( 'deleted_post_meta', array( self::class, 'on_delete' ), 10, 3 );
	}

	/**
	 * The meta on each post type with a source text, in the REST API of the editor.
	 */
	public static function register(): void {
		foreach ( self::post_types() as $post_type ) {
			register_post_meta(
				$post_type,
				self::META,
				array(
					'type'              => 'string',
					'single'            => true,
					'default'           => self::PENDING,
					'show_in_rest'      => array(
						'schema' => array(
							'type' => 'string',
							'enum' => array( self::PENDING, self::REVIEWED ),
						),
					),
					'sanitize_callback' => array( self::class, 'sanitize' ),
					'auth_callback'     => static fn( $allowed, $key, $post_id ): bool => current_user_can( 'edit_post', (int) $post_id ),
				)
			);
		}
	}

	/**
	 * Post types whose Spanish text has a state: products, pages and posts. Terms, menus
	 * and the shops' texts have none and go to the queue directly.
	 *
	 * @return string[]
	 */
	public static function post_types(): array {
		/**
		 * Post types whose source text is «Pendiente» or «Revisado».
		 *
		 * @since 0.14.0
		 *
		 * @param string[] $post_types Products, pages and posts.
		 */
		$types = (array) apply_filters( 'lachinata/source_status/post_types', array( 'product', 'page', 'post' ) );
		return array_values( array_unique( array_filter( array_map( 'strval', $types ) ) ) );
	}

	/**
	 * The state of a post.
	 *
	 * @param int $post_id Post id.
	 */
	public static function get( int $post_id ): string {
		return self::REVIEWED === get_post_meta( $post_id, self::META, true ) ? self::REVIEWED : self::PENDING;
	}

	/**
	 * Whether the Spanish text of a post is reviewed.
	 *
	 * @param int $post_id Post id.
	 */
	public static function is_reviewed( int $post_id ): bool {
		return self::REVIEWED === self::get( $post_id );
	}

	/**
	 * Sets the state of a post and tells it when it changes.
	 *
	 * @param int    $post_id Post id.
	 * @param string $status  `pending` or `reviewed`.
	 * @return bool Whether it changed.
	 */
	public static function set( int $post_id, string $status ): bool {
		$post = get_post( $post_id );
		if ( ! $post instanceof \WP_Post || ! in_array( $post->post_type, self::post_types(), true ) || ! in_array( $status, array( self::PENDING, self::REVIEWED ), true ) ) {
			return false;
		}
		if ( self::get( $post_id ) === $status ) {
			return false;
		}
		update_post_meta( $post_id, self::META, $status );
		return true;
	}

	/**
	 * The meta was added or changed: WordPress only writes a different value, so with two
	 * states the previous one is the other.
	 *
	 * @param mixed $meta_id   Meta id.
	 * @param mixed $post_id   Post id.
	 * @param mixed $meta_key  Meta key.
	 * @param mixed $value     New value.
	 */
	public static function on_write( $meta_id, $post_id, $meta_key, $value ): void {
		unset( $meta_id );
		if ( self::META !== $meta_key ) {
			return;
		}
		$status = self::sanitize( $value );
		if ( 'added_post_meta' === current_action() && self::PENDING === $status ) {
			return;
		}
		self::changed( (int) $post_id, $status, self::REVIEWED === $status ? self::PENDING : self::REVIEWED );
	}

	/**
	 * Keeps the state of a post whose meta is about to go.
	 *
	 * @param mixed $meta_ids Meta ids.
	 * @param mixed $post_id  Post id.
	 * @param mixed $meta_key Meta key.
	 */
	public static function before_delete( $meta_ids, $post_id, $meta_key ): void {
		unset( $meta_ids );
		if ( self::META === $meta_key ) {
			self::$deleting[ (int) $post_id ] = self::get( (int) $post_id );
		}
	}

	/**
	 * Without the meta the text is «Pendiente».
	 *
	 * @param mixed $meta_ids Meta ids.
	 * @param mixed $post_id  Post id.
	 * @param mixed $meta_key Meta key.
	 */
	public static function on_delete( $meta_ids, $post_id, $meta_key ): void {
		unset( $meta_ids );
		if ( self::META !== $meta_key ) {
			return;
		}
		$previous = self::$deleting[ (int) $post_id ] ?? self::PENDING;
		unset( self::$deleting[ (int) $post_id ] );
		if ( self::REVIEWED === $previous ) {
			self::changed( (int) $post_id, self::PENDING, $previous );
		}
	}

	/**
	 * Tells a change of state.
	 *
	 * @param int    $post_id  Post id.
	 * @param string $status   New state.
	 * @param string $previous The state before.
	 */
	private static function changed( int $post_id, string $status, string $previous ): void {
		/**
		 * The Spanish text of a product, page or post changed its state («Pendiente» or
		 * «Revisado»), whoever wrote it. `translate` queues what becomes «Revisado».
		 *
		 * @since 0.14.0
		 *
		 * @param int    $post_id  Post id.
		 * @param string $status   `pending` or `reviewed`.
		 * @param string $previous The state before.
		 */
		do_action( 'lachinata/source_status/changed', $post_id, $status, $previous );
	}

	/**
	 * The meta query of a state: «Pendiente» is also the posts without the meta.
	 *
	 * @param string $status State.
	 * @return array<string|int, mixed>
	 */
	public static function meta_query( string $status ): array {
		if ( self::REVIEWED === $status ) {
			return array(
				'key'   => self::META,
				'value' => self::REVIEWED,
			);
		}
		return array(
			'relation' => 'OR',
			array(
				'key'     => self::META,
				'compare' => 'NOT EXISTS',
			),
			array(
				'key'     => self::META,
				'value'   => self::REVIEWED,
				'compare' => '!=',
			),
		);
	}

	/**
	 * A valid state.
	 *
	 * @param mixed $value Value.
	 */
	public static function sanitize( $value ): string {
		return self::REVIEWED === $value ? self::REVIEWED : self::PENDING;
	}

	/**
	 * Names of the states for people.
	 *
	 * @return array<string, string>
	 */
	public static function labels(): array {
		return array(
			self::PENDING  => __( 'Pendiente', 'lachinata-core' ),
			self::REVIEWED => __( 'Revisado', 'lachinata-core' ),
		);
	}
}
