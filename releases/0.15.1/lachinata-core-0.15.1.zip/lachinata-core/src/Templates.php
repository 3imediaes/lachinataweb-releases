<?php
/**
 * Full-page templates of the modules.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core;

defined( 'ABSPATH' ) || exit;

/**
 * A module that owns whole pages (a post type, an archive, a taxonomy) ships its templates
 * in `plugin/modules/<id>/templates/<id>/<name>.php` and serves them from `template_include`.
 * The theme may override any of them with `lachinata/<id>/<name>.php` (found with
 * locate_template, so a child theme wins over its parent). The templates call the theme's
 * get_header() and get_footer(), print the `.lc-*` classes of the system and take the icons
 * from the theme's sprite; the layout of the page is the theme's (theme.css). Stateless:
 * every module may use it (docs/arquitectura-modulos.md, § 3).
 */
final class Templates {

	/**
	 * Path of a module's template: the theme's override or the module's own file; '' when
	 * neither exists.
	 *
	 * @param string $module Module id.
	 * @param string $name   Template name, without `.php`.
	 */
	public static function locate( string $module, string $name ): string {
		$module = sanitize_key( $module );
		$name   = implode( '/', array_map( 'sanitize_file_name', explode( '/', $name ) ) );
		$theme  = locate_template( 'lachinata/' . $module . '/' . $name . '.php' );
		if ( '' !== $theme ) {
			return $theme;
		}
		$own = LACHINATA_CORE_DIR . '/modules/' . $module . '/templates/' . $module . '/' . $name . '.php';
		return is_readable( $own ) ? $own : '';
	}

	/**
	 * Prints a partial of a module (a piece shared by its pages or a block) with its
	 * arguments in `$args`, with the same override rule.
	 *
	 * @param string               $module Module id.
	 * @param string               $name   Partial name (`parts/card`).
	 * @param array<string, mixed> $args   Arguments.
	 */
	public static function part( string $module, string $name, array $args = array() ): void {
		$file = self::locate( $module, $name );
		if ( '' !== $file ) {
			( static function ( string $lachinata_file, array $args ): void { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.FoundAfterLastUsed -- The template reads $args.
				include $lachinata_file;
			} )( $file, $args );
		}
	}

	/**
	 * The same partial, as a string.
	 *
	 * @param string               $module Module id.
	 * @param string               $name   Partial name.
	 * @param array<string, mixed> $args   Arguments.
	 */
	public static function capture( string $module, string $name, array $args = array() ): string {
		ob_start();
		self::part( $module, $name, $args );
		return (string) ob_get_clean();
	}
}
