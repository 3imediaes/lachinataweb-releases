# Huecos del tema (contrato con lachinata-core)

El tema nunca llama al plugin: pregunta `lachinata_module( 'x' )` y deja estos huecos. La API del plugin (servicios entre módulos, hooks del núcleo y de los módulos, REST y metadatos) está en [`plugin/HOOKS.md`](../plugin/HOOKS.md). «Desde» y «Obsoleto desde» siguen las reglas de ese documento: lo obsoleto se mantiene como alias al menos una versión menor. Cada filtro tiene un valor por defecto neutro, de modo que con WooCommerce de serie el tema funciona (sin tintas, sin precio por unidad, sin pestañas extra). Lo que cambia entre tiendas no vive en el tema: entra por estos filtros o por los menús.

## Filtros

| Hook | Valor por defecto | Quién lo rellena | Desde | Obsoleto desde |
| --- | --- | --- | --- | --- |
| `lachinata/category/tint` `( string $tint, WP_Term $term )` | `''` (sin tinta: `surface-2`/`surface-3`) | `catalog` (`_lc_tint`, heredado) | 0.2.0 | — |
| `lachinata/product/tint` `( string $tint, WC_Product $product )` | `''` | `catalog` (la de su categoría principal o, sin ella, la de la más profunda). En el listado de una categoría la tarjeta usa la tinta de la raíz que se ve (argumento `tint` de `product-card`) | 0.2.0 | — |
| `lachinata/product/unit_price` `( string $html, WC_Product $product )` | `''` | `catalog` («500 ml \| 9,33 € / 1 l»; producto o variación) | 0.2.0 | — |
| `lachinata/product_card/badges` `( array $badges, WC_Product $product )` | «-20 %» con rebaja y todas las etiquetas de producto (`term_id`, tono neutro); la tarjeta y la galería las pintan todas, apiladas. Desde 0.12.2, cada etiqueta puede llevar `image_id` (imagen pequeña delante del texto) | `catalog`: tono, imagen y orden de cada etiqueta (campos del término) y la «etiqueta» del producto tras la rebaja | 0.2.0 | — |
| `lachinata/product_card/marker` `( ?array $marker, WC_Product $product )` | `null` (`label`, el texto de la pastilla, e `icon` del sprite delante, opcional: `''` sin icono; hasta 0.12.2, `label` era el nombre accesible de un icono) | `catalog`: la marca de la clase de envío («Refrigerado», sin icono, en Frío y Fresco), ajuste de La Chinata → Catálogo | 0.12.2 | — |
| `lachinata/product_card/image_id` `( int $image_id, WC_Product $product )` | la imagen destacada | `catalog`: «Imagen de tarjeta» del producto | 0.12.2 | — |
| `lachinata/catalog/cutout` `( bool $cutout, int $image_id )` | `false` (todas las fotos con fondo) | `catalog`: la imagen tiene transparencia (`_lc_catalog_recorte`). Con `true`, la foto lleva `lc-img--recorte`: producto centrado con un 8 % de aire sobre la tinta de su familia, en la tarjeta, la línea de la bolsa, el resumen del pedido, los regalos y la galería de la ficha (y en «Ingredientes de esta receta», de `content`). `feeds` la usa para el JPEG sobre blanco y la imagen de Open Graph | 0.16.0 | — |
| `lachinata/product/main_category` `( int $term_id, WC_Product $product )` | la categoría más profunda del producto | `catalog`: la categoría principal (`_lc_catalog_categoria_principal`). La usan las migas, el antetítulo y la venta cruzada | 0.12.2 | — |
| `lachinata/product/notices` `( array $notices, WC_Product $product )` | `[]` (`tone`, `icon`, `html`) | `catalog`: «**Envío refrigerado.** Solo a España peninsular; gratis desde 60 €. Sale de lunes a miércoles.» (condiciones de `shipping` y `eta`) | 0.12.2 | — |
| `lachinata/product/cross_sell` `( array $cross_sell, WC_Product $product )` | `title` «También te puede gustar» y `source` `cross_sells` (las del producto; sin ellas, los más vendidos de su subcategoría) o `bestsellers` | `catalog`: título y fuente por categoría raíz («Completa tu rutina» en Cosmética, «Combina con» en Aceites y Gourmet) | 0.12.2 | — |
| `lachinata/product_card/meta` `( string $html, WC_Product $product )` | el precio por unidad (`lachinata/product/unit_price`) | `catalog`: en un regalo compuesto, «6 productos · Caja de regalo» (unidades y presentación) | 0.16.0 | — |
| `lachinata/product/gift` `( ?array $gift, WC_Product $product )` | `null` (no es un regalo compuesto) | `catalog`: `count` (unidades), `presentation`, `items` (`name`, `meta`, `qty`, `image_id`, `tint`, `href` —`''` sin página—, `description`, `ingredients` en HTML —vacío hasta que lleguen de la aplicación de La Chinata—, `allergens`), `allergens` y `traces` del conjunto. Sin precios. El tema añade medidas y peso de WooCommerce y pinta `GiftSummary`, `GiftContents` y `GiftItem` | 0.16.0 | — |
| `lachinata/product/bulk_cta` `( ?array $cta, WC_Product $product )` | `null` (no se pinta) | `catalog`: «¿Es para tu empresa?» (`href`, `title`, `text`, `cta`, `min`, `sku`, `channel` `page` o `whatsapp`) en los productos que marca La Chinata → Catálogo → Regalos | 0.16.0 | — |
| `lachinata/catalog/categories` `( ?int[] $ids )` | `null`: todas las categorías raíz con productos | `catalog`: la lista ordenada de La Chinata → Catálogo → Tienda, con las campañas del día delante (cabecera, menú, buscador y home) | 0.12.2 | — |
| `lachinata/product/tabs` `( array $tabs, WC_Product $product )` | Descripción | `catalog` añade Ingredientes e imagen de descripción. «Opiniones» la añade el tema después. | 0.2.0 | — |
| `lachinata/product/seals` `( array $seals, WC_Product $product )` | `[]` | `catalog` (taxonomía `tipo` con icono) | 0.2.0 | — |
| `lachinata/product/details` `( array $rows, WC_Product $product )` | `[]` | `catalog` (consumo preferente) | 0.2.0 | — |
| `lachinata/product/availability` `( array{tone,text} $availability, WC_Product $product )` | «Disponible», «Quedan N unidades», «Agotado por ahora.» | `eta`: «Disponible. Pídelo antes de las 16:00 y lo recibes el jueves 24.» (un script lo refresca y añade la cuenta atrás) | 0.2.0 | — |
| `lachinata/product/routine_ids` `( int[] $ids, WC_Product $product )` | productos de la venta cruzada según la fuente de `lachinata/product/cross_sell` (sin ninguno, la sección no se pinta; desde 0.12.2 basta uno) | `locale` quita los que no se envían al destino | 0.2.0 | — |
| `lachinata/cart/line_note` `( string $note, array $item )` | `''` | `shipping`: «No se envía a Alemania» (restricción de producto en el destino del cliente); con la causa `peso_max`, «Pesa 2,4 kg» en cada línea que se envía | 0.2.0 | — |
| `lachinata/cart/shipping_summary` `( string $html, WC_Cart $cart )` | «Se calcula con tu dirección» | `shipping`: «Envío estándar · 4,13 € · Llega jue 24 – vie 25 oct» (método elegido, precio y fecha de `eta`) | 0.4.0 | — |
| `lachinata/promo_bar/messages` `( array $messages )` | menú «promo» (`title`, `url`, `icon`; desde 0.11.0, `attrs`: atributos `data-*` del mensaje; desde 0.12.1, `short`: el texto junto a la `MarketBadge` en móvil, que ya dice el destino; de serie, la descripción del elemento) | `shipping`: antepone «Envío gratis a Portugal desde 60 €» (corto: «Envío gratis desde 60 €») (destino del visitante y su umbral, en la moneda de la tienda) o rellena `{destino}` y `{envio_gratis}` si un mensaje los usa; sin envío gratis al destino, el mensaje se va. El mensaje lleva sus plantillas en `data-lc-free` (`locale` lo completa en el navegador con «Caché sin destino») | 0.2.0 | — |
| `lachinata/catalog/show_count` `( bool $show )` | `true` | `locale`: `false` con «Caché sin destino» (la página es la misma para todos y el navegador puede ocultar tarjetas: ni «24 productos» ni «Cargar más (12 de 24)») | 0.11.0 | — |
| `lachinata/product/can_buy` `( bool $can_buy, WC_Product $product )` | `true` | `locale`: `false` si el producto no se envía al destino del visitante (la ficha no se oculta; sin disponibilidad, sin formulario de compra ni barra fija) | 0.11.0 | — |
| `lachinata/cart/checkout_blocked` `( string $reason, WC_Cart $cart )` | `''` | `locale`: «Hay productos que no se envían a Portugal…» (con texto, «Tramitar pedido» va desactivado y el motivo debajo) | 0.11.0 | — |
| `lachinata/usp/items` `( array $items, string $layout )` | menú «usp» (`title`, `text`, `icon`; desde 0.11.0, `attrs`: atributos `data-*` del elemento) | `shipping`: rellena `{destino}` y `{envio_gratis}` en título y texto («Envío gratis · Portugal desde 60 €»); sin envío gratis al destino, «Envío a Alemania · Gastos calculados en la bolsa». Lleva sus plantillas en `data-lc-free`, como la PromoBar | 0.2.0 | — |
| `lachinata/home/category_sections` `( array $tree )` | las categorías de la tienda (`lachinata/catalog/categories`) | — | 0.2.0 | — |
| `lachinata/thankyou/delivery` `( string $title, WC_Order $order )` | nombre del método de envío | `eta`: «Llega jue 24 – vie 25 oct» (titular del bloque de entrega de gracias) | 0.5.0 | — |
| `lachinata/order/tracking` `( ?array $tracking, WC_Order $order )` | `null` (`url`, `carrier`, `number`) | `shipment`: «Seguir el paquete» en gracias y en Mi cuenta → Pedidos | 0.8.0 | — |
| `lachinata/order/status` `( array $status, WC_Order $order )` | nombre de estado de WooCommerce y tono del `Badge` | `shipment`: «En camino» (`info`) una vez enviado | 0.8.0 | — |
| `lachinata/thankyou/product_ids` `( int[] $ids, WC_Order $order )` | ventas cruzadas de lo comprado o, sin ellas, los más vendidos de su categoría | — | 0.5.0 | — |
| `lachinata/footer/copyright` `( string $text )` | «© año Nombre comercial» (el de `lachinata/company`; sin plugin, el nombre del sitio) | — | 0.2.0 | — |
| `lachinata/product_card/attributes` `( array $attributes, WC_Product $product, array $args )` | `[]` (solo cuentan los `data-*`) | `tracking`: `data-lc-item`, el producto en la forma de los eventos, con su lista (`args['list']`: `id`, `name`, `index`) | 0.10.0 | — |
| `lachinata/cart/line_attributes` `( array $attributes, array $item, string $key )` | `[]` (solo cuentan los `data-*`) | `tracking`: `data-lc-item` de la línea de la bolsa | 0.10.0 | — |
| `lachinata/company` `( array $company )` | vacío (`trade_name`, `legal_name`, `tax_id`, `address`, `privacy_email`, `privacy_url`, `cookies_url`, `legal_url` y, desde 0.13.0, `social`: lista de `network` y `url`) | núcleo del plugin: «Datos de la empresa» (WooCommerce → La Chinata), con «Redes», fuente única de `SocialLinks` del pie y del `sameAs` de la organización. El nombre comercial (`trade_name`, vacío si no se ha rellenado: entonces el nombre del sitio) es el nombre de la tienda en el pie, los correos, el aviso y la política de cookies. Lo leen también, en su día, el pie legal de los correos, los datos estructurados (`content`) y la factura | 0.10.0 | — |
| `lachinata/contact` `( array $contact )` | vacío (`phone`, `whatsapp`, `email`, `hours`, `phone_url`, `whatsapp_url`) | núcleo del plugin: «Atención al cliente» (WooCommerce → La Chinata). Lo leen los correos; los menús `usp` y `promo` admiten `{telefono}`, `{whatsapp}`, `{correo}` y `{horario}` | 0.8.0 | — |
| `lachinata/product/content` `( string $content, WC_Product $product )` | `''` | `catalog` («500 ml»): segunda línea de los productos en los correos | 0.8.0 | — |
| `lachinata/checkout/wallets` `( bool $wallets )` | `false`: la página de pago de un pedido y el correo del pedido telefónico dicen «con tarjeta o PayPal» | `checkout`: `true` con el pago exprés de Stripe activo en el checkout. El correo nombra Apple Pay y Google Pay; la página, solo cuando su fila aparece (dispositivo con cartera) | 0.8.1 | — |
| `lachinata/breadcrumb/items` `( array $items )` | Inicio, categorías y la página (`[etiqueta, url]`, la última sin enlace) | `oleotecas`: Oleotecas › País › Zona › tienda | 0.12.0 | — |
| `lachinata/view/secondary` `( bool $secondary )` | ficha de producto y subpáginas de la cuenta | `oleotecas`: la ficha de cada tienda (AppBar con «Volver») | 0.12.0 | — |
| `lachinata/app_bar/section` `( string $url )` | `''` (solo el enlace de la página actual) | `oleotecas`: el buscador, en todas sus páginas (OLEOTECAS marcado en la AppBar de escritorio) | 0.12.0 | — |
| `lachinata/view/editorial` `( bool $editorial )` | home, entradas, la plantilla editorial y los archivos del blog | `oleotecas`: buscador, zonas y fichas (título en Recoleta: se precarga) | 0.12.0 | — |
| `lachinata/view/back_url` `( string $url )` | la categoría del producto, o la home | `oleotecas`: la zona de la tienda, o el buscador; `content`: la sección de la entrada, o la revista | 0.12.0 | — |
| `lachinata/view/blog` `( bool $blog )` | entradas y sus archivos | `content`: la revista, las secciones y los temas (carga `blog.css`: el grupo «Blog» del sistema y el layout de la revista, el artículo y la receta) | 0.13.0 | — |

## Plantillas de página de los módulos

Un módulo que tiene páginas completas propias (un tipo de contenido, su archivo, una taxonomía) trae sus plantillas en `plugin/modules/<id>/templates/<id>/<nombre>.php` y las sirve desde `template_include` con la utilidad del núcleo `LaChinata\Core\Templates` (también sus piezas: `Templates::part( '<id>', 'parts/<pieza>', $args )`). El tema puede sustituir cualquiera con `lachinata/<id>/<nombre>.php` (se busca con `locate_template`, así que un tema hijo gana al padre). Las plantillas:

- usan `get_header()` y `get_footer()` del tema, y sus piezas cuando las hay (`template-parts/breadcrumb`, las tarjetas de producto por `content-product`);
- imprimen el HTML y las clases `.lc-*` del sistema, con los iconos del sprite del tema (`<use href="#lc-icon-…">`);
- dejan el layout al tema: `theme.css` lo viste por sus clases (`lc-stores-*` y `lc-store-page__*` para `oleotecas`).

| Módulo | Plantillas | Desde |
| --- | --- | --- |
| `oleotecas` | `archive` (`/oleotecas/`), `zone` (`/oleotecas/{zona}/`), `single` (`/oleoteca/{slug}/`) y las piezas `parts/finder`, `parts/places`, `parts/franchise` | 0.12.0 |
| `content` | `blog` (`/blog/`), `section` (`/blog/{seccion}/`, `/blog/tema/{slug}/`), `single` (artículo y noticia) y `recipe` (`/slug/`); el layout en `blog.css` (`lc-blog__*`, `lc-entry__*`, `lc-recipe-page__*`) | 0.13.0 |

## Acciones

| Hook | Dónde | Quién | Desde | Obsoleto desde |
| --- | --- | --- | --- | --- |
| `lachinata/promo_bar/start` | principio de la PromoBar, en móvil (con algo enganchado, la barra se pinta aunque no haya mensajes) | `locale`: `MarketBadge` | 0.11.0 | — |
| `lachinata/app_bar/utilities` | AppBar de escritorio, antes de los enlaces de marca (no en el checkout) | `locale`: `MarketBadge` | 0.11.0 | — |
| `lachinata/product/before_title` `( WC_Product $product )` | ficha, antes del antetítulo y el título | `locale`: «Lo sentimos, este producto no está disponible en tu país.» (texto de Envíos → Restricciones de producto) | 0.12.2 | — |
| `lachinata/product/before_buy` `( WC_Product $product )` | ficha, antes de la disponibilidad y el formulario de compra | `locale`: «Cambiar destino» en lugar del formulario (hasta 0.12.1 también el aviso, que pasa a `before_title`) | 0.11.0 | — |
| `lachinata/nav_drawer/utilities` | final de las utilidades del menú lateral | — (en móvil, el destino va en la PromoBar) | 0.2.0 | — |
| `lachinata/footer/legal` | principio de la línea legal del pie | `locale`: «Cambiar destino» (abre el selector; sin JavaScript, la página con el selector abierto) | 0.2.0 | — |
| `lachinata/footer/consent` | final de los enlaces de la línea legal del pie | `tracking`: «Configurar cookies» (reabre el panel de cookies; sin JavaScript, la política) | 0.10.0 | — |
| `lachinata/footer/newsletter` | bloque de newsletter del pie (no se pinta si nadie engancha) | `newsletter`: título, texto, formulario (sin JS) y consentimiento | 0.2.0 | — |
| `lachinata/cart/notices` | encima del resumen de la bolsa (página y sheet) | `shipping`: aviso informativo de la zona, motivo cuando no hay envío y «Te faltan X € para el envío gratis» | 0.2.0 | — |
| `lachinata/thankyou/account` `( WC_Order $order )` | gracias, tras «Seguir el pedido» | `checkout`: «Hemos creado tu cuenta…» o «Guarda tus datos para la próxima vez» con «Crear mi cuenta» | 0.5.0 | — |
| `lachinata/thankyou/invoice` `( WC_Order $order )` | gracias, tras la cuenta | `checkout`: «¿Necesitas factura con NIF?» (Empresa y NIF después de pagar) o los datos de factura ya guardados | 0.6.0 | — |
| `lachinata/thankyou/gift` `( WC_Order $order )` | gracias, bajo la fecha de entrega (antes de «Seguir el pedido») | `gift`: «Es un regalo para María» y cómo se le avisará | 0.7.0 | — |
| `lachinata/thankyou/after` `( WC_Order $order )` | gracias, tras «Mientras llega» y antes de «Seguir comprando» | `content`: «Ideas para tu {producto}» (recetas del primer producto del pedido que las tenga) | 0.13.0 | — |
| `lachinata/product/after` `( WC_Product $product )` | ficha, debajo de todo lo que sirve para comprar (compra, descripción, opiniones y venta cruzada) | `content`: «Recetas con este producto» (como mucho 3, solo en las categorías del ajuste) | 0.13.0 | — |

## Correos

Todos los correos salen del marco del tema (`theme/inc/emails.php`, `woocommerce/emails/*.php`; `design-system/sistema/06-correos.md`). El tema lo declara con `lachinata/email/frame` (`true`); un módulo que pinta piezas lo comprueba y, sin marco (otro tema), escribe su contenido donde lo dejan las plantillas de WooCommerce.

| Hook | Tipo | Valor por defecto | Quién lo rellena | Desde | Obsoleto desde |
| --- | --- | --- | --- | --- | --- |
| `lachinata/email/frame` `( bool $frame )` | filtro | `false`; el tema, `true` | tema | 0.8.0 | — |
| `lachinata/email/intro` `( array $intro, ?WC_Email $email )` | filtro | `eyebrow`, `title`, `lead`, `preheader` del inventario | `eta` (preheader con la fecha), `gift` (aviso al destinatario), `shipment` (transportista en la entradilla) | 0.8.0 | — |
| `lachinata/email/facts` `( array $facts, ?WC_Order $order, ?WC_Email $email )` | filtro | por correo: `delivery`, `address`, `payment`… (`label`, `value`, `note`; 3 como máximo, los vacíos no dejan hueco) | `eta` (entrega estimada, «ETA»), `gift`, `shipment` (llega, transportista y número) | 0.8.0 | — |
| `lachinata/email/button` `( ?array $button, ?WC_Email $email )` | filtro | «Ver mi pedido», «Pagar {total}», «Volver a la tienda», «Abrir en WooCommerce»… (`label`, `url`, `variant`) | `gift` (secundario), `shipment` («Seguir el paquete») | 0.8.0 | — |
| `lachinata/email/layout` `( array $layout, ?WC_Email $email )` | filtro | `lines` (`full`, `compact`, `none`), `totals`, `addresses`, `help`, `instructions` | `gift` (aviso al destinatario: nada del pedido) | 0.8.0 | — |
| `lachinata/email/subject` `( string $subject, WC_Email $email )` | filtro | asunto del inventario (si la tienda no ha escrito el suyo) | `gift` («· regalo» en el interno) | 0.8.0 | — |
| `lachinata/email/shipping_label` `( string $label, WC_Order_Item_Shipping $line, WC_Order $order )` | filtro | nombre del método | `eta` («Envío estándar · jue 24 – vie 25 oct») | 0.8.0 | — |
| `lachinata/email/footer_note` `( string $html, ?WC_Email $email )` | filtro | por qué recibe el correo | `gift` (aviso al destinatario: nada) | 0.8.0 | — |
| `lachinata/email/footer_line` `( string $html, ?WC_Email $email )` | filtro | «La Chinata · {ciudad}, {provincia} · desde 1932» (HTML: solo enlaces) | `gift` («· ¿Qué es La Chinata?» en el aviso al destinatario) | 0.8.0 | — |
| `lachinata/email/footer_links` `( ?array $links, ?WC_Email $email )` | filtro | `null`: el menú «Pie de correos» o «Mi cuenta»; los internos, ninguno | `gift` (ninguno en el aviso al destinatario) | 0.8.0 | — |
| `lachinata/email/pay_today` `( string $html, WC_Order $order )` | filtro | `''` (la nota del pedido telefónico dice solo «La fecha de entrega empieza a contar cuando pagues») | `eta` («Si lo pagas hoy, llega …») | 0.8.0 | — |
| `lachinata/order/payment_label` `( string $label, WC_Order $order )` | filtro | título de la pasarela sin lo que va entre paréntesis (cuenta o correo) | `checkout` («Tarjeta ···· 4242», «Apple Pay», «Google Pay») | 0.8.0 | — |
| `lachinata/email/after_title` `( ?WC_Order $order, ?WC_Email $email )` | acción | — | `gift` (etiqueta «Regalo» en el interno) | 0.8.0 | — |
| `lachinata/email/before_lines` `( WC_Order $order, ?WC_Email $email )` | acción | — | `gift` (nota del regalo) | 0.8.0 | — |

Las acciones imprimen HTML con las clases del marco, que el tema viste y WooCommerce pasa a estilos en línea: `lc-mail-note` (`__cell`, `__title`, `__text`), `lc-mail-badges` + `lc-mail-badge`, `lc-mail-text`, `lc-mail-caption`. Los correos en texto plano siguen con las plantillas de WooCommerce (con los asuntos del marco). El «Contenido adicional» de cada correo no se imprime.

## Checkout de bloques

El checkout lo pinta React (bloque de WooCommerce), así que aquí los huecos no son hooks de PHP:

- Sin indicador de pasos (retirado el 23/10/2026: en una página el scroll ya orienta).
- **Después del envío** y **resumen**: *slots* JS `lachinata/checkout/after-shipping` y `lachinata/checkout/summary` del módulo `checkout` (bloque `lachinata/checkout-after-shipping` y *fill* en `ExperimentalOrderMeta`). Un módulo los rellena con `wc.blocksCheckout.createSlotFill( nombre ).Fill` y registra sus campos y su script en la acción PHP `lachinata/checkout/after_shipping`, que no imprime nada. Ver `plugin/modules/checkout/README.md`.
- **Casilla del aviso de envío por WhatsApp (`shipment`):** el script del módulo pone `lc-gift-open` en `<body>` mientras «Es un regalo» está marcado; `checkout.css` oculta entonces `.wc-block-components-address-form__lachinata-shipment-whatsapp`.
- **CSS que el tema da por hecho del módulo:** `.lc-billing` (bloque de facturación propio: con él se ocultan la casilla nativa y los títulos de facturación e «Información del pedido»), `.lc-checkout-shipping--cause` (hay motivo de «sin envío»: el tema oculta el aviso genérico de WooCommerce), `.lc-checkout__outlets`, `.lc-checkout__actions`, `.lc-checkout__restricted`, `.lc-checkout__unavailable`.

## Contenido por sitio (menús, no código)

| Ubicación | Uso |
| --- | --- |
| `promo` | Mensajes de la `PromoBar` (título, URL; descripción = texto corto junto a la `MarketBadge` en móvil, sin el destino; clase CSS = icono). `{envio_gratis}` se sustituye por el umbral del destino del visitante y `{destino}` por su nombre; sin envío gratis allí, el mensaje no sale. Sin ningún mensaje con `{envio_gratis}`, `shipping` añade el suyo |
| `brand` | Enlaces de marca en la cabecera de escritorio |
| `utility` | Utilidades del menú lateral (clase CSS = icono: `pin`, `leaf`, `headset`…) |
| `usp` | `UspBar` (título, descripción = texto, clase CSS = icono). `{envio_gratis}` se sustituye por el umbral del destino del visitante y `{destino}` por su nombre («Envío gratis» · «{destino} desde {envio_gratis}»); sin envío gratis allí, el elemento dice «Envío a …» sin cifra. Ningún importe, moneda ni destino se escribe a mano |
| `help` | Acordeón de ayuda de la ficha (título = pregunta, descripción = respuesta) |
| `footer` | Columnas del pie (elementos de primer nivel con sus enlaces) |
| `legal` | Enlaces legales del pie |
| `email-footer` | Enlaces del pie de los correos (Mi cuenta · Envíos y devoluciones · Privacidad). Sin menú: Mi cuenta y la página de privacidad |

La nota de impuestos bajo los precios es el «sufijo de precio» de WooCommerce (Ajustes → Impuestos). El lema del pie es la descripción corta del sitio.

## Eventos del navegador

El tema no mide nada. Cuenta lo que pasa con eventos en `document` y algunos atributos; el módulo `tracking` los escucha y los traduce a cada servicio. Un evento nuevo se añade aquí en el mismo cambio.

| Evento o atributo | Cuándo | `detail` | Desde | Obsoleto desde |
| --- | --- | --- | --- | --- |
| `lachinata:cart:add` | se ha añadido un producto a la bolsa desde la tarjeta, la ficha o la barra fija | `id` (producto o variación), `quantity`, `source` (`card`, `product`, `sticky`) y `element` (la tarjeta o el formulario). Desde 0.13.0, un `[data-lc-add]` con varios ids («Añadir los N a la bolsa», `href` con `?lc-add-many=`) emite uno por producto | 0.10.0 | — |
| `lachinata:cart:remove` | «Quitar» en una línea de la bolsa | `element` (la `.lc-line`) | 0.10.0 | — |
| `lachinata:cart:quantity` | cambia la cantidad de una línea | `element` y `quantity` (la nueva) | 0.10.0 | — |
| `lachinata:cart:view` | se abre la bolsa en la hoja (la página `/bolsa/` la mide el servidor) | `source` (`sheet`) y `element` | 0.10.0 | — |
| `lachinata:content:added` | «Cargar más» añade tarjetas | `elements` | 0.10.0 | — |
| `lachinata:recipe:view`, `:scale`, `:print`, `:cook_mode`, `:ingredient_product` (los emite `content`) | una receta se abre; cambian las raciones; se imprime; se abre el modo cocina; se pulsa el enlace a producto de un ingrediente | `id` y `title` de la receta; `servings` (`scale`) y `product` (`ingredient_product`). `tracking` los manda solo a GA4 (`lc_recipe_*`, `lc_ingredient_product`; desde 0.13.1) | 0.13.0 | — |
| `lachinata:article:read` (lo emite `content`) | quien lee llega al 75 % del texto de un artículo, una vez | `id` y `title`. `tracking`: `lc_article_read`, solo a GA4 | 0.13.1 | — |
| `data-lc-entry`, `data-lc-list`, `data-lc-index` (en `.lc-acard`) y `data-lc-item` (en `.lc-rprod__item`, por `lachinata/product_card/attributes` desde 0.13.1) | los pinta `content` en las listas de entradas y en «Ingredientes … de esta receta» | entrada, nombre de la lista («Recetas con este producto»…) y posición; el producto con la lista «Receta: {título}». `tracking`: `select_item` y `add_to_cart` | 0.13.0 | — |
| `lachinata:layer:open` (lo escucha el tema) | un módulo pide abrir una capa del tema (`[data-lc-layer]`); el tema cancela el evento si la abre | `name` | 0.11.0 | — |
| `lachinata:layer:closed` | se ha cerrado una capa del tema (Escape, el fondo, «Cerrar» o al abrir otra) | `name` | 0.11.0 | — |
| `lachinata:locale:done` | el selector de destino de la primera visita ha terminado (elegido, cerrado o no hacía falta); `tracking` espera a este evento para mostrar la barra de cookies | — | 0.11.0 | — |
| `data-lc-destino`, `data-lc-locale-pending` (en `<html>`) | los pone `locale` en el `<head>`: el destino elegido, o que la primera visita aún no ha elegido | — | 0.11.0 | — |
| `data-lc-no` (en `.lc-card`) | lo añade `locale` por `lachinata/product_card/attributes` con «Caché sin destino» | destinos donde no se envía, separados por espacios | 0.11.0 | — |
| `data-lc-checkout` | el botón «Tramitar pedido» de la bolsa | — | 0.10.0 | — |
| `data-lc-bulk` (en `.lc-bulk`) | el enlace «¿Es para tu empresa?» de la ficha | JSON con `id`, `sku` y `channel`. `tracking`: `lc_bulk_quote`, solo a GA4 | 0.16.0 | — |
| `data-lc-item` (en `.lc-card` y `.lc-line`) | lo añade `tracking` por `lachinata/product_card/attributes` y `lachinata/cart/line_attributes` | JSON del producto | 0.10.0 | — |

`window.lachinata` lo comparten el tema (sus ajustes: `cartUrl`, `storeApi`…) y los módulos (`track`, `consent`): se amplía con `Object.assign`, nunca se reemplaza.

## Home

Los bloques editoriales son el contenido de la página de inicio (patrones del tema, categoría «La Chinata»). Lo que va antes del bloque «Más» se pinta arriba (hero, campaña) y lo que va después, al final (historia, oleotecas). Entre medias, el tema pinta tiles de categoría, `UspBar`, TOP 10 y una sección por categoría.
