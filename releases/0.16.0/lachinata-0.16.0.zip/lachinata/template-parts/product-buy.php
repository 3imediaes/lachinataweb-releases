<?php
/**
 * Buy form: format chips (variations), Stepper and «Añadir a la bolsa». Posts to
 * WooCommerce's add-to-cart handler, so it works without JavaScript. Args: product.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_product = $args['product'] ?? null;
if ( ! $lachinata_product instanceof WC_Product || ! $lachinata_product->is_purchasable() ) {
	return;
}

if ( ! $lachinata_product->is_type( array( 'simple', 'variable' ) ) ) {
	echo '<div class="lc-buy__other">';
	woocommerce_template_single_add_to_cart();
	echo '</div>';
	return;
}

if ( ! $lachinata_product->is_in_stock() ) {
	return;
}

$lachinata_variable   = $lachinata_product instanceof WC_Product_Variable;
$lachinata_variations = array();
if ( $lachinata_variable ) {
	foreach ( $lachinata_product->get_available_variations( 'objects' ) as $lachinata_variation ) {
		if ( ! $lachinata_variation instanceof WC_Product_Variation || ! $lachinata_variation->is_purchasable() ) {
			continue;
		}
		$lachinata_image        = (int) $lachinata_variation->get_image_id();
		$lachinata_variations[] = array(
			'id'         => $lachinata_variation->get_id(),
			'attributes' => $lachinata_variation->get_variation_attributes(),
			'price'      => wc_price( (float) wc_get_price_to_display( $lachinata_variation ) ),
			'old'        => $lachinata_variation->is_on_sale() ? wc_price( (float) wc_get_price_to_display( $lachinata_variation, array( 'price' => $lachinata_variation->get_regular_price() ) ) ) : '',
			'unit'       => lachinata_unit_price( $lachinata_variation ),
			'inStock'    => $lachinata_variation->is_in_stock(),
			'max'        => $lachinata_variation->get_max_purchase_quantity() > 0 ? $lachinata_variation->get_max_purchase_quantity() : 99,
			'image'      => $lachinata_image && $lachinata_image !== (int) $lachinata_product->get_image_id() ? array(
				'src'    => wp_get_attachment_image_url( $lachinata_image, 'woocommerce_single' ),
				'srcset' => wp_get_attachment_image_srcset( $lachinata_image, 'woocommerce_single' ),
				'cutout' => lachinata_image_cutout( $lachinata_image ),
			) : null,
		);
	}
	$lachinata_defaults = $lachinata_product->get_default_attributes();
}
$lachinata_max = $lachinata_product->get_max_purchase_quantity() > 0 ? $lachinata_product->get_max_purchase_quantity() : 99;
?>
<form class="lc-buy__form" id="lc-buy" action="<?php echo esc_url( $lachinata_product->get_permalink() ); ?>" method="post" enctype="multipart/form-data" data-lc-buy>
	<?php
	/**
	 * WooCommerce: before the add-to-cart button (product add-ons, etc.).
	 *
	 * @since 0.2.0
	 */
	do_action( 'woocommerce_before_add_to_cart_button' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.HookCommentWrongStyle, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook.
	?>
	<?php if ( $lachinata_variable ) : ?>
		<?php foreach ( $lachinata_product->get_variation_attributes() as $lachinata_name => $lachinata_options ) : ?>
			<?php
			$lachinata_field = 'attribute_' . sanitize_title( $lachinata_name );
			$lachinata_terms = taxonomy_exists( $lachinata_name ) ? wc_get_product_terms( $lachinata_product->get_id(), $lachinata_name, array( 'fields' => 'all' ) ) : array();
			$lachinata_list  = array();
			if ( $lachinata_terms ) {
				foreach ( $lachinata_terms as $lachinata_term ) {
					if ( in_array( $lachinata_term->slug, $lachinata_options, true ) ) {
						$lachinata_list[ $lachinata_term->slug ] = $lachinata_term->name;
					}
				}
			} else {
				foreach ( $lachinata_options as $lachinata_option ) {
					$lachinata_list[ $lachinata_option ] = $lachinata_option;
				}
			}
			$lachinata_default = $lachinata_defaults[ sanitize_title( $lachinata_name ) ] ?? ( 1 === count( $lachinata_list ) ? (string) array_key_first( $lachinata_list ) : '' );
			?>
			<fieldset class="lc-buy__format">
				<legend class="label"><?php echo esc_html( wc_attribute_label( $lachinata_name, $lachinata_product ) ); ?></legend>
				<div class="lc-chips">
					<?php foreach ( $lachinata_list as $lachinata_value => $lachinata_label ) : ?>
						<label class="<?php echo esc_attr( lachinata_cx( 'lc-chip', 'label', (string) $lachinata_value === $lachinata_default ? 'lc-chip--on' : '' ) ); ?>">
							<input class="screen-reader-text" type="radio" name="<?php echo esc_attr( $lachinata_field ); ?>" value="<?php echo esc_attr( (string) $lachinata_value ); ?>"<?php checked( (string) $lachinata_value, $lachinata_default ); ?> required data-lc-chip-input data-lc-attribute>
							<?php echo esc_html( $lachinata_label ); ?>
						</label>
					<?php endforeach; ?>
				</div>
			</fieldset>
		<?php endforeach; ?>
		<input type="hidden" name="variation_id" value="" data-lc-variation-id>
		<input type="hidden" name="product_id" value="<?php echo esc_attr( (string) $lachinata_product->get_id() ); ?>">
		<script type="application/json" data-lc-variations><?php echo wp_json_encode( $lachinata_variations, JSON_HEX_TAG | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ); ?></script>
	<?php endif; ?>
	<div class="lc-buy__row">
		<?php
		if ( ! $lachinata_product->is_sold_individually() ) {
			echo lachinata_stepper(
				array(
					'name'  => 'quantity',
					'value' => 1,
					'min'   => 1,
					'max'   => $lachinata_max,
					'id'    => 'lc-qty',
				)
			);
		}
		echo lachinata_button(
			__( 'Añadir a la bolsa', 'lachinata' ),
			array(
				'variant'   => 'cart',
				'size'      => 'lg',
				'block'     => true,
				'icon_left' => 'bag',
				'type'      => 'submit',
				'class'     => 'lc-buy__submit',
				'attrs'     => array(
					'name'  => 'add-to-cart',
					'value' => $lachinata_product->get_id(),
				),
			)
		);
		?>
	</div>
	<?php
	/**
	 * WooCommerce: after the add-to-cart button (express payment buttons, etc.).
	 *
	 * @since 0.2.0
	 */
	do_action( 'woocommerce_after_add_to_cart_button' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.HookCommentWrongStyle, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook.
	?>
</form>
