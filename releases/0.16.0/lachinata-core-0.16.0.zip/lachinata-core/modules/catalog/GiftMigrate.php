<?php
/**
 * Migration of the composite gifts: from the description to the gift data.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

defined( 'ABSPATH' ) || exit;

/**
 * The old gifts list their contents in the description: a subtitle («Contenido del…», or
 * «Productos incluidos» in the copy rewritten by marketing) and the products block (or the
 * `[products]` shortcode). The migration moves the SKUs to the gift data (a repeated SKU is
 * one more unit), takes the presentation from the name, moves «Dimensiones (l x w x h): …»
 * to the WooCommerce fields and removes all that from the description. Whatever does not
 * fit goes to the report; nothing is guessed.
 */
final class GiftMigrate {

	/**
	 * Subtitles of the contents the migration knows (start of the text, any case).
	 */
	private const HEADINGS = '/^(contenido|productos incluidos)\b/iu';

	/**
	 * Subtitle of the product data section, where the dimensions are in the new copy.
	 */
	private const DATA_HEADING = '/^datos del producto$/iu';

	/**
	 * Blank between a subtitle and what follows: spaces, `&nbsp;` and empty paragraphs.
	 */
	private const BLANK = '(?:\s|&nbsp;|<p>(?:\s|&nbsp;)*</p>)*';

	/**
	 * Reads and removes the contents of a description.
	 *
	 * @param string $html       Description.
	 * @param bool   $dimensions Also take the dimensions out.
	 * @return array{html: string, skus: string[], ids: int[], heading: string, known: bool, blocks: int, dimensions: array{0: float, 1: float, 2: float, unit: string}|null, notes: string[]}
	 */
	public static function parse( string $html, bool $dimensions = true ): array {
		$found = array(
			'html'       => $html,
			'skus'       => array(),
			'ids'        => array(),
			'heading'    => '',
			'known'      => false,
			'blocks'     => 0,
			'dimensions' => null,
			'notes'      => array(),
		);
		$list  = static fn( string $value ): array => array_values( array_filter( array_map( 'trim', explode( ',', $value ) ) ) );

		// Every products block and every [products] with skus or ids, with the subtitle
		// right before it (an `h2`–`h4`, maybe inside a closed `div`).
		$pattern       = '#(?:<h([2-4])\b[^>]*>((?:(?!</?h[1-6]\b).)*)</h\1>(' . self::BLANK . '(?:</div>' . self::BLANK . ')?))?(<!--\s*wp:lachinata/products\s+(\{.*?\})\s*/-->|\[products(\s[^\]]*)?\])' . self::BLANK . '#is';
		$found['html'] = (string) preg_replace_callback(
			$pattern,
			static function ( array $found_match ) use ( &$found, $list ): string {
				if ( ! empty( $found_match[5] ) ) {
					$attributes = json_decode( $found_match[5], true );
				} else {
					$attributes = shortcode_parse_atts( trim( $found_match[6] ?? '' ) );
				}
				$attributes = is_array( $attributes ) ? array_change_key_case( $attributes ) : array();
				$skus       = $list( (string) ( $attributes['skus'] ?? '' ) );
				$ids        = array_map( 'absint', $list( (string) ( $attributes['ids'] ?? '' ) ) );
				if ( ! $skus && ! $ids ) {
					return $found_match[0];
				}
				++$found['blocks'];
				$found['skus'] = array_merge( $found['skus'], $skus );
				$found['ids']  = array_merge( $found['ids'], $ids );
				$heading       = trim( html_entity_decode( wp_strip_all_tags( $found_match[2] ), ENT_QUOTES, 'UTF-8' ), " \t\n\r\0\x0B\xC2\xA0" );
				if ( '' !== $heading && '' === $found['heading'] ) {
					$found['heading'] = $heading;
					$found['known']   = (bool) preg_match( self::HEADINGS, $heading );
				}
				// The closing `div` of an old layout stays; the rest goes with the block.
				return str_contains( $found_match[3], '</div>' ) ? "</div>\n" : "\n";
			},
			$html
		);
		if ( $found['blocks'] > 1 ) {
			$found['notes'][] = sprintf( '%d bloques de productos: se suman.', $found['blocks'] );
		}
		if ( $found['blocks'] && '' === $found['heading'] ) {
			$found['notes'][] = 'Sin subtítulo antes del bloque.';
		} elseif ( '' !== $found['heading'] && ! $found['known'] ) {
			$found['notes'][] = sprintf( 'Subtítulo «%s» quitado con el bloque: no es «Contenido…» ni «Productos incluidos».', $found['heading'] );
		}

		if ( $dimensions ) {
			$size                = self::dimensions( $found['html'] );
			$found['html']       = $size['html'];
			$found['dimensions'] = $size['dimensions'];
			$found['notes']      = array_merge( $found['notes'], $size['notes'] );
		}
		$found['html'] = self::tidy( $found['html'] );
		return $found;
	}

	/**
	 * «Dimensiones (l x w x h): 26 x 26,6 x 9,3 cm.» (or «Dimensiones: 190 x 154 x 53 mm»)
	 * out of the description, as numbers. In a list, the item goes and so does the list when
	 * it is left empty, and the «Datos del producto» subtitle when its section is empty.
	 *
	 * @param string $html Description.
	 * @return array{html: string, dimensions: array{0: float, 1: float, 2: float, unit: string}|null, notes: string[]}
	 */
	public static function dimensions( string $html ): array {
		$number = '(\d+(?:[.,]\d+)?)';
		$line   = 'Dimensiones(?:\s*\([^)]*\))?\s*:\s*' . $number . '\s*[x×]\s*' . $number . '\s*[x×]\s*' . $number . '\s*(mm|cm|m)\b\.?';
		$found  = null;
		$notes  = array();
		// A list item, a paragraph or a line of its own; the first one found.
		foreach ( array( '#<li>\s*' . $line . '\s*</li>#iu', '#<p>\s*' . $line . '\s*</p>#iu', '#^[ \t]*' . $line . '[ \t]*(?:<br\s*/?>)?\r?$#imu' ) as $pattern ) {
			$html = (string) preg_replace_callback(
				$pattern,
				static function ( array $found_match ) use ( &$found ): string {
					$found = array(
						(float) str_replace( ',', '.', $found_match[1] ),
						(float) str_replace( ',', '.', $found_match[2] ),
						(float) str_replace( ',', '.', $found_match[3] ),
						'unit' => strtolower( $found_match[4] ),
					);
					return '';
				},
				$html,
				1
			);
			if ( null !== $found ) {
				break;
			}
		}
		if ( null === $found ) {
			return array(
				'html'       => $html,
				'dimensions' => null,
				'notes'      => $notes,
			);
		}
		$html = (string) preg_replace( '#<ul>\s*</ul>#i', '', $html );
		// The «Datos del producto» subtitle with nothing under it before the next subtitle.
		$html = (string) preg_replace_callback(
			'#<h([2-4])\b[^>]*>((?:(?!</?h[1-6]\b).)*)</h\1>(' . self::BLANK . ')(?=<h[2-4]\b|$)#is',
			static fn( array $found_match ): string => preg_match( self::DATA_HEADING, trim( wp_strip_all_tags( $found_match[2] ) ) ) ? '' : $found_match[0],
			$html
		);
		if ( preg_match( '#<h([2-4])\b[^>]*>\s*Datos del producto\s*</h\1>#iu', $html ) ) {
			$notes[] = '«Datos del producto» conserva otro texto.';
		}
		return array(
			'html'       => $html,
			'dimensions' => $found,
			'notes'      => $notes,
		);
	}

	/**
	 * Empty `div`s and blank lines left behind.
	 *
	 * @param string $html Description.
	 */
	private static function tidy( string $html ): string {
		do {
			$html = (string) preg_replace( '#<div\b[^>]*>(?:\s|&nbsp;)*</div>#i', '', $html, -1, $count );
		} while ( $count );
		$html = (string) preg_replace( '/(?:\s*&nbsp;\s*)+$/', '', $html );
		$html = (string) preg_replace( "/\n{3,}/", "\n\n", $html );
		return trim( $html );
	}

	/**
	 * Runs the migration on every product whose description has a products block or the
	 * shortcode. A gift that already has contents is left as it is.
	 *
	 * @param bool $dry_run Report only.
	 * @return array{gifts: array<int, array{id: int, name: string, status: string, units: int, presentation: string, dimensions: string, heading: string, missing: string[], notes: string[]}>, skipped: array<int, array{id: int, name: string, reason: string}>}
	 */
	public static function run( bool $dry_run ): array {
		global $wpdb;
		$report = array(
			'gifts'   => array(),
			'skipped' => array(),
		);
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- A one-off migration.
		$ids  = $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'product' AND post_status IN ('publish','draft','pending','private') AND (post_content LIKE '%wp:lachinata/products%' OR post_content LIKE '%[products%') ORDER BY ID" );
		$unit = (string) get_option( 'woocommerce_dimension_unit', 'cm' );
		foreach ( array_map( 'intval', $ids ) as $id ) {
			$product = wc_get_product( $id );
			if ( ! $product instanceof \WC_Product ) {
				continue;
			}
			if ( Gifts::is_gift( $id ) ) {
				$report['skipped'][] = array(
					'id'     => $id,
					'name'   => $product->get_name(),
					'reason' => 'Ya tiene contenido.',
				);
				continue;
			}
			$parsed = self::parse( $product->get_description() );
			if ( ! $parsed['blocks'] ) {
				$report['skipped'][] = array(
					'id'     => $id,
					'name'   => $product->get_name(),
					'reason' => 'El bloque no lleva SKU ni ID.',
				);
				continue;
			}
			$rows    = array();
			$missing = array();
			foreach ( $parsed['skus'] as $sku ) {
				$found  = wc_get_product_id_by_sku( $sku );
				$rows[] = array(
					'id'  => $found,
					'sku' => $sku,
					'qty' => 1,
				);
				if ( ! $found ) {
					$missing[] = $sku;
				}
			}
			foreach ( $parsed['ids'] as $item_id ) {
				$item   = wc_get_product( $item_id );
				$rows[] = array(
					'id'  => $item_id,
					'sku' => $item instanceof \WC_Product ? $item->get_sku() : '',
					'qty' => 1,
				);
				if ( ! $item instanceof \WC_Product ) {
					$missing[] = '#' . $item_id;
				}
			}
			$notes        = $parsed['notes'];
			$presentation = Gifts::presentation( $id ) ?? Gifts::presentation_for_name( $product->get_name() );
			if ( null === $presentation ) {
				$notes[] = 'Sin presentación: ninguna palabra del nombre casa con una presentación.';
			}
			$html = $parsed['html'];
			$size = '';
			if ( null !== $parsed['dimensions'] ) {
				$new  = array_map( static fn( float $value ): string => (string) round( wc_get_dimension( $value, $unit, $parsed['dimensions']['unit'] ), 2 ), array( $parsed['dimensions'][0], $parsed['dimensions'][1], $parsed['dimensions'][2] ) );
				$old  = array( $product->get_length(), $product->get_width(), $product->get_height() );
				$size = implode( ' × ', $new ) . ' ' . $unit;
				if ( array_filter( $old ) && array_map( 'floatval', $old ) !== array_map( 'floatval', $new ) ) {
					$notes[] = sprintf( 'Medidas del texto (%1$s) distintas de las de la ficha (%2$s): no se pisan y el texto se queda.', $size, implode( ' × ', $old ) . ' ' . $unit );
					$size    = '';
					$html    = self::parse( $product->get_description(), false )['html'];
				} elseif ( ! $dry_run ) {
					$product->set_length( $new[0] );
					$product->set_width( $new[1] );
					$product->set_height( $new[2] );
				}
			}
			if ( ! $dry_run ) {
				Gifts::save( $id, $rows );
				if ( $presentation && ! Gifts::presentation( $id ) ) {
					wp_set_object_terms( $id, array( $presentation->term_id ), Gifts::TAXONOMY );
				}
				$product->set_description( $html );
				$product->save();
			}
			$report['gifts'][] = array(
				'id'           => $id,
				'name'         => $product->get_name(),
				'status'       => $product->get_status(),
				'units'        => count( $rows ),
				'presentation' => $presentation ? $presentation->name : '',
				'dimensions'   => $size,
				'heading'      => $parsed['heading'],
				'missing'      => $missing,
				'notes'        => $notes,
			);
		}
		return $report;
	}

	/**
	 * The report as Markdown.
	 *
	 * @param array{gifts: array<int, array{id: int, name: string, status: string, units: int, presentation: string, dimensions: string, heading: string, missing: string[], notes: string[]}>, skipped: array<int, array{id: int, name: string, reason: string}>} $report  Report.
	 * @param bool                                                                                                                                                                                                                                                 $dry_run Report only.
	 */
	public static function markdown( array $report, bool $dry_run ): string {
		$gifts   = $report['gifts'];
		$lines   = array( '# Migración de regalos compuestos' . ( $dry_run ? ' (simulación)' : '' ), '' );
		$lines[] = sprintf( '- Regalos migrados: %d.', count( $gifts ) );
		$lines[] = sprintf( '- Con presentación: %d; sin presentación: %d.', count( array_filter( array_column( $gifts, 'presentation' ) ) ), count( $gifts ) - count( array_filter( array_column( $gifts, 'presentation' ) ) ) );
		$lines[] = sprintf( '- Con medidas pasadas a la ficha: %d.', count( array_filter( array_column( $gifts, 'dimensions' ) ) ) );
		$lines[] = sprintf( '- Con algún SKU que no casa: %d.', count( array_filter( array_column( $gifts, 'missing' ) ) ) );
		$lines[] = sprintf( '- Sin tocar: %d.', count( $report['skipped'] ) );
		$lines[] = '';
		$lines[] = '## Para revisar';
		$lines[] = '';
		$review  = array_filter( $gifts, static fn( array $gift ): bool => $gift['missing'] || $gift['notes'] );
		if ( ! $review ) {
			$lines[] = 'Nada.';
		}
		foreach ( $review as $gift ) {
			$lines[] = sprintf( '- **%1$s** (#%2$d, %3$s)', $gift['name'], $gift['id'], $gift['status'] );
			if ( $gift['missing'] ) {
				$lines[] = '  - SKU sin producto: ' . implode( ', ', $gift['missing'] ) . '.';
			}
			foreach ( $gift['notes'] as $note ) {
				$lines[] = '  - ' . $note;
			}
		}
		$lines[] = '';
		$lines[] = '## Todos';
		$lines[] = '';
		$lines[] = '| ID | Regalo | Estado | Productos | Presentación | Medidas | Subtítulo quitado |';
		$lines[] = '| --- | --- | --- | --- | --- | --- | --- |';
		foreach ( $gifts as $gift ) {
			$lines[] = sprintf( '| %1$d | %2$s | %3$s | %4$d | %5$s | %6$s | %7$s |', $gift['id'], str_replace( '|', '\|', $gift['name'] ), $gift['status'], $gift['units'], '' !== $gift['presentation'] ? $gift['presentation'] : '—', '' !== $gift['dimensions'] ? $gift['dimensions'] : '—', '' !== $gift['heading'] ? str_replace( '|', '\|', $gift['heading'] ) : '—' );
		}
		if ( $report['skipped'] ) {
			$lines[] = '';
			$lines[] = '## Sin tocar';
			$lines[] = '';
			foreach ( $report['skipped'] as $row ) {
				$lines[] = sprintf( '- %1$s (#%2$d): %3$s', $row['name'], $row['id'], $row['reason'] );
			}
		}
		return implode( "\n", $lines ) . "\n";
	}
}
