<?php
/**
 * Catalog health: data to review in the product sheets.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

use LaChinata\Core\Gtin;

defined( 'ABSPATH' ) || exit;

/**
 * Lists what the templates show as it comes but looks wrong: unit price data that is
 * missing, incompatible or odd; GTINs that cannot exist; old EANs that differ from the
 * GTIN; products without image or category; a main category the product is no longer in.
 * Never changes what the shop shows: whoever loads the data fixes it in the product.
 * Calculated when the screen opens (or with WP-CLI); the home of the panel shows the last
 * count.
 */
final class Health {

	/**
	 * Transient with the last count, for the home of the panel.
	 */
	public const COUNT = 'lachinata_catalog_health_count';

	/**
	 * A reference this many times the content is odd (4 g by 1 kg): worth a look.
	 */
	private const ODD_RATIO = 100;

	/**
	 * Groups of warnings, in the order they are shown.
	 *
	 * @return array<string, string>
	 */
	public static function groups(): array {
		return array(
			'unit_price'    => __( 'Precio por unidad', 'lachinata-core' ),
			'gtin'          => __( 'GTIN que no puede existir (no sale en los feeds)', 'lachinata-core' ),
			'ean'           => __( 'EAN antiguo distinto del GTIN', 'lachinata-core' ),
			'image'         => __( 'Sin imagen', 'lachinata-core' ),
			'category'      => __( 'Sin categoría', 'lachinata-core' ),
			'main_category' => __( 'Categoría principal que ya no es del producto', 'lachinata-core' ),
			'gift'          => __( 'Regalos con un producto que no existe, sin publicar o agotado', 'lachinata-core' ),
		);
	}

	/**
	 * Warnings of the catalog (published, private and draft products), by group.
	 *
	 * @return array<string, array<int, array{id: int, name: string, detail: string}>>
	 */
	public static function run(): array {
		$found = array_fill_keys( array_keys( self::groups() ), array() );
		$ids   = get_posts(
			array(
				'post_type'      => 'product',
				'post_status'    => array( 'publish', 'private', 'draft', 'pending' ),
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'orderby'        => 'ID',
				'order'          => 'ASC',
			)
		);
		update_meta_cache( 'post', $ids );
		update_object_term_cache( $ids, 'product' );
		$uncategorized = (int) get_option( 'default_product_cat', 0 );

		foreach ( $ids as $id ) {
			$id   = (int) $id;
			$name = get_the_title( $id );
			$add  = static function ( string $group, string $detail ) use ( &$found, $id, $name ): void {
				$found[ $group ][] = array(
					'id'     => $id,
					'name'   => $name,
					'detail' => $detail,
				);
			};

			foreach ( self::unit_price( $id ) as $detail ) {
				$add( 'unit_price', $detail );
			}

			$gtin = Gtin::digits( (string) get_post_meta( $id, '_global_unique_id', true ) );
			foreach ( self::wrong_gtins( $id ) as $detail ) {
				$add( 'gtin', $detail );
			}

			$ean = trim( (string) get_post_meta( $id, 'ean', true ) );
			if ( '' !== $ean && '' !== $gtin && Gtin::digits( $ean ) !== $gtin ) {
				/* translators: 1: old EAN, 2: GTIN. */
				$add( 'ean', sprintf( __( 'EAN %1$s, GTIN %2$s. Manda el GTIN.', 'lachinata-core' ), $ean, $gtin ) );
			}

			if ( ! has_post_thumbnail( $id ) ) {
				$add( 'image', '' );
			}

			$categories = wp_get_object_terms( $id, 'product_cat', array( 'fields' => 'ids' ) );
			$categories = is_array( $categories ) ? array_map( 'intval', $categories ) : array();
			if ( ! array_diff( $categories, array( $uncategorized ) ) ) {
				$add( 'category', '' );
			}

			$main = absint( get_post_meta( $id, Fields::MAIN_CATEGORY, true ) );
			if ( $main && ! in_array( $main, $categories, true ) ) {
				$term = get_term( $main, 'product_cat' );
				/* translators: %s: category name. */
				$add( 'main_category', sprintf( __( '«%s» ya no está entre sus categorías: la tarjeta usa la más profunda.', 'lachinata-core' ), $term instanceof \WP_Term ? $term->name : '#' . $main ) );
			}

			foreach ( self::gift( $id ) as $detail ) {
				$add( 'gift', $detail );
			}
		}

		set_transient( self::COUNT, self::count( $found ), DAY_IN_SECONDS );
		return $found;
	}

	/**
	 * GTINs of a product and its variations that cannot exist.
	 *
	 * @param int $id Product id.
	 * @return string[]
	 */
	private static function wrong_gtins( int $id ): array {
		$details = array();
		$ids     = array_merge(
			array( $id ),
			array_map(
				'intval',
				get_children(
					array(
						'post_parent' => $id,
						'post_type'   => 'product_variation',
						'fields'      => 'ids',
					)
				)
			)
		);
		foreach ( $ids as $owner ) {
			$gtin = Gtin::digits( (string) get_post_meta( $owner, '_global_unique_id', true ) );
			if ( '' === $gtin || Gtin::valid_check_digit( $gtin ) ) {
				continue;
			}
			$detail = Gtin::valid_length( $gtin )
				/* translators: %s: GTIN. */
				? sprintf( __( '%s: el último dígito no es el de control.', 'lachinata-core' ), $gtin )
				/* translators: %s: GTIN. */
				: sprintf( __( '%s: un GTIN tiene 8, 12, 13 o 14 cifras.', 'lachinata-core' ), $gtin );
			$details[] = $owner === $id
				? $detail
				/* translators: 1: variation id, 2: what is wrong. */
				: sprintf( __( 'Variación #%1$d: %2$s', 'lachinata-core' ), $owner, $detail );
		}
		return $details;
	}

	/**
	 * Products of a gift that no longer exist, are not published or are out of stock. The
	 * page still shows an unpublished one, without a link, and leaves out one that is gone.
	 *
	 * @param int $id Product id.
	 * @return string[]
	 */
	public static function gift( int $id ): array {
		$details = array();
		foreach ( Gifts::rows( $id ) as $row ) {
			$product = Gifts::product( $row );
			if ( ! $product ) {
				/* translators: 1: SKU, 2: product id. */
				$details[] = sprintf( __( 'SKU %1$s (#%2$d): no existe; la ficha no lo muestra.', 'lachinata-core' ), '' !== $row['sku'] ? $row['sku'] : '—', $row['id'] );
			} elseif ( 'publish' !== $product->get_status() ) {
				/* translators: %s: product name. */
				$details[] = sprintf( __( '«%s»: sin publicar; la ficha lo muestra sin enlace.', 'lachinata-core' ), $product->get_name() );
			} elseif ( ! $product->is_in_stock() ) {
				/* translators: %s: product name. */
				$details[] = sprintf( __( '«%s»: agotado.', 'lachinata-core' ), $product->get_name() );
			}
		}
		return $details;
	}

	/**
	 * Warnings in total.
	 *
	 * @param array<string, array<int, mixed>> $found Warnings by group.
	 */
	public static function count( array $found ): int {
		return (int) array_sum( array_map( 'count', $found ) );
	}

	/**
	 * Last count, calculated again when it is older than a day.
	 */
	public static function last_count(): int {
		$count = get_transient( self::COUNT );
		return false === $count ? self::count( self::run() ) : (int) $count;
	}

	/**
	 * Unit price problems of a product and its variations.
	 *
	 * @param int $id Product id.
	 * @return string[]
	 */
	public static function unit_price( int $id ): array {
		$details   = array();
		$content   = Fields::quantity( $id, Fields::CONTENT );
		$reference = Fields::quantity( $id, Fields::REFERENCE );
		foreach ( array(
			Fields::CONTENT   => $content,
			Fields::REFERENCE => $reference,
		) as $key => $value ) {
			$legacy = Fields::LEGACY[ $key ];
			if ( null === $value && ! metadata_exists( 'post', $id, $key ) && '' !== trim( (string) get_post_meta( $id, $legacy, true ) ) ) {
				/* translators: 1: field, 2: value as typed. */
				$details[] = sprintf( __( '%1$s: no se entiende «%2$s».', 'lachinata-core' ), Fields::CONTENT === $key ? __( 'Contenido', 'lachinata-core' ) : __( 'Referencia', 'lachinata-core' ), (string) get_post_meta( $id, $legacy, true ) );
			}
		}

		$contents = array( $content );
		foreach ( get_children(
			array(
				'post_parent' => $id,
				'post_type'   => 'product_variation',
				'fields'      => 'ids',
			)
		) as $variation ) {
			$own = metadata_exists( 'post', (int) $variation, Fields::CONTENT ) ? Quantity::from_array( get_post_meta( (int) $variation, Fields::CONTENT, true ) ) : null;
			if ( null !== $own ) {
				$contents[] = $own;
			}
		}
		$contents = array_filter( $contents );

		if ( null !== $reference && ! $contents ) {
			/* translators: %s: reference quantity («1 kg»). */
			$details[] = sprintf( __( 'Referencia %s sin contenido: no se calcula el precio por unidad.', 'lachinata-core' ), $reference->label() );
		}
		if ( null === $reference && $contents ) {
			$details[] = __( 'Contenido sin referencia: solo se ve el contenido, sin precio por unidad.', 'lachinata-core' );
		}
		foreach ( null === $reference ? array() : $contents as $quantity ) {
			if ( ! $quantity->is_compatible( $reference ) ) {
				/* translators: 1: content («500 ml»), 2: reference («1 kg»). */
				$details[] = sprintf( __( 'Contenido %1$s y referencia %2$s de distinta magnitud: no se calcula el precio por unidad.', 'lachinata-core' ), $quantity->label(), $reference->label() );
			} elseif ( $reference->in_base_unit() >= self::ODD_RATIO * $quantity->in_base_unit() ) {
				/* translators: 1: content («4 g»), 2: reference («1 kg»). */
				$details[] = sprintf( __( 'Contenido %1$s con precio por %2$s: comprueba que sea la referencia que corresponde.', 'lachinata-core' ), $quantity->label(), $reference->label() );
			}
		}
		return array_values( array_unique( $details ) );
	}
}
