<?php
/**
 * What is sent to Claude to translate an object.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

use LaChinata\Core\Company;

defined( 'ABSPATH' ) || exit;

/**
 * One request per object, with all its fields, and the answer field by field as JSON (a
 * schema with the same keys). The instructions of the language go first and do not change
 * between requests, so the API can cache them; the glossary terms that appear, the context
 * (kind, category and name of the product) and the fields go after.
 */
final class Prompt {

	/**
	 * Default instructions by language code: tone, form of address and the line of the legal
	 * pages. The panel changes them for each language.
	 */
	public const DEFAULTS = array(
		'en' => array(
			'tone'       => 'Warm, clear and direct, never pompous. British English spelling (flavour, colour, centre).',
			'address'    => 'you',
			'legal_line' => 'In case of discrepancy, the Spanish version prevails.',
		),
		'de' => array(
			'tone'       => 'Warm, clear and direct, never pompous.',
			'address'    => 'Sie',
			'legal_line' => 'Im Falle von Abweichungen ist die spanische Fassung maßgeblich.',
		),
		'fr' => array(
			'tone'       => 'Chaleureux, clair et direct, jamais pompeux.',
			'address'    => 'vous',
			'legal_line' => 'En cas de divergence, la version espagnole prévaut.',
		),
	);

	/**
	 * Instructions of a language: tone, address, legal line and whether it is on.
	 *
	 * @param string $language Locale.
	 * @return array{tone: string, address: string, legal_line: string, legal_on: bool}
	 */
	public static function instructions( string $language ): array {
		$code     = strtolower( (string) strtok( $language, '_' ) );
		$defaults = self::DEFAULTS[ $code ] ?? array(
			'tone'       => '',
			'address'    => '',
			'legal_line' => '',
		);
		$saved    = TranslateModule::setting( 'instructions' );
		$saved    = is_array( $saved ) && is_array( $saved[ $language ] ?? null ) ? $saved[ $language ] : array();
		return array(
			'tone'       => isset( $saved['tone'] ) ? sanitize_textarea_field( (string) $saved['tone'] ) : $defaults['tone'],
			'address'    => isset( $saved['address'] ) ? sanitize_text_field( (string) $saved['address'] ) : $defaults['address'],
			'legal_line' => isset( $saved['legal_line'] ) ? sanitize_text_field( (string) $saved['legal_line'] ) : $defaults['legal_line'],
			'legal_on'   => ! isset( $saved['legal_on'] ) || (bool) $saved['legal_on'],
		);
	}

	/**
	 * Instructions of the system for a language (the same in every request).
	 *
	 * @param string $language Locale.
	 */
	public static function system( string $language ): string {
		$rules = self::instructions( $language );
		$shop  = Company::trade_name();
		$lines = array(
			sprintf( 'You translate the texts of an online shop%s from Spanish (Spain) into %s (%s). The Spanish is the reviewed original.', '' !== $shop ? ' (' . $shop . ')' : '', self::language_name( $language ), $language ),
			'Rules:',
			'- Translate the meaning naturally for a customer of that language; do not translate word by word.',
			'' !== $rules['tone'] ? '- Tone: ' . $rules['tone'] : '',
			'' !== $rules['address'] ? '- Address the reader as «' . $rules['address'] . '».' : '',
			'- Keep metric units always. Use the number and date format of the target language, but never change a figure: every number, percentage, quantity and price stays exactly as in the Spanish.',
			'- Do not invent, add or remove claims, above all about health, cosmetics or food. Do not add text that is not in the Spanish.',
			'- Keep the HTML exactly: the same tags in the same order (lists, tables, <u> for allergens), the same attributes and the same links. Keep block comments (<!-- wp:… -->), shortcodes ([…]) and placeholders (%s, %1$s, {name}) untouched.',
			'- Apply the glossary: the fixed terms with their translation; the terms marked «keep» exactly as written.',
			'- Product names are translated, except the terms of the glossary marked «keep».',
			'- A field called «slug» is a web address segment: lower case ASCII letters, numbers and hyphens, from the translated name.',
			'- A field with format «json» is a JSON list: translate only its text values and keep the same keys and structure.',
			'- Respect the maximum length of a field when it has one.',
			'- Answer only with the JSON object asked, one key per field.',
		);
		return implode( "\n", array_filter( $lines, static fn( string $line ): bool => '' !== $line ) );
	}

	/**
	 * Body of the request to translate some fields of an object.
	 *
	 * @param string                                                                      $language Locale.
	 * @param array<string, string>                                                       $context  Kind, category, name.
	 * @param array<string, array{text: string, format: string, max: int, label: string}> $fields   Field → Spanish and definition.
	 * @return array<string, mixed>
	 */
	public static function body( string $language, array $context, array $fields ): array {
		$properties = array();
		$payload    = array();
		$all        = '';
		foreach ( $fields as $name => $field ) {
			$properties[ $name ] = array( 'type' => 'string' );
			$payload[ $name ]    = array_filter(
				array(
					'format' => $field['format'],
					'max'    => $field['max'] > 0 ? $field['max'] : null,
					'text'   => $field['text'],
				),
				static fn( $value ): bool => null !== $value
			);
			$all                .= "\n" . $field['text'];
		}
		$glossary = array_map(
			static fn( array $row ): array => $row['keep'] ? array(
				'term' => $row['term'],
				'keep' => true,
			) : array(
				'term'        => $row['term'],
				'translation' => $row['translation'],
			),
			Glossary::in( $all, $language )
		);
		$message  = array(
			'target_language' => $language,
			'context'         => array_filter( $context ),
			'glossary'        => $glossary,
			'fields'          => $payload,
		);
		return array(
			'model'         => Spend::model(),
			'max_tokens'    => 16000,
			'output_config' => array(
				'effort' => self::effort(),
				'format' => array(
					'type'   => 'json_schema',
					'schema' => array(
						'type'                 => 'object',
						'properties'           => $properties,
						'required'             => array_keys( $properties ),
						'additionalProperties' => false,
					),
				),
			),
			'system'        => array(
				array(
					'type'          => 'text',
					'text'          => self::system( $language ),
					'cache_control' => array( 'type' => 'ephemeral' ),
				),
			),
			'messages'      => array(
				array(
					'role'    => 'user',
					'content' => (string) wp_json_encode( $message, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT ),
				),
			),
		);
	}

	/**
	 * Effort of the panel (`medium` by default).
	 */
	public static function effort(): string {
		$effort = (string) TranslateModule::setting( 'effort' );
		return in_array( $effort, array( 'low', 'medium', 'high' ), true ) ? $effort : 'medium';
	}

	/**
	 * Name of a language in English, for the model.
	 *
	 * @param string $language Locale.
	 */
	private static function language_name( string $language ): string {
		$names = array(
			'en_GB' => 'British English',
			'en_US' => 'American English',
			'de_DE' => 'German',
			'fr_FR' => 'French',
			'pt_PT' => 'European Portuguese',
			'it_IT' => 'Italian',
		);
		return $names[ $language ] ?? $language;
	}
}
