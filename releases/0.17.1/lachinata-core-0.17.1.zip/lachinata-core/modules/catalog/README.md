# Módulo `catalog`

Datos propios del catálogo que en la web actual están en ACF, con campos nativos de WordPress y WooCommerce: contenido y referencia para el precio por unidad (también por variación), ingredientes, etiqueta, imagen de descripción, consumo preferente y exclusión internacional del producto; tinta de cada categoría; taxonomía `tipo` (sellos) con su icono. Sustituye a ACF sin migración de datos: lee las claves de ACF hasta que se normalizan.

Desde la 0.12.2 (incremento 9c), además: categoría principal e imagen de tarjeta del producto; tono, imagen y orden de cada etiqueta de producto; la configuración de la tienda (categorías de la tienda con campañas de temporada, venta cruzada por categoría raíz y marcas de las clases de envío) y la salud del catálogo. El principio: **la plantilla pinta los datos tal como vienen**; lo que está mal se corrige en la ficha y la salud lo avisa.

Desde la 0.16.0, además: **regalos compuestos** (`02-plantillas.md`, «Regalos compuestos»): qué productos lleva cada regalo, su presentación, «¿Es para tu empresa?», su salud y la migración desde la descripción.

Especificación: `design-system/sistema/03-implementacion.md` («ACF se retira» y tabla de módulos). Huecos del tema que rellena: `theme/HOOKS.md`. Se enciende por defecto al activar el plugin.

## Qué hace

| Pieza | Cómo | Dónde |
| --- | --- | --- |
| Campos del producto en la pestaña «La Chinata» de la ficha del panel (y por variación, contenido y referencia) | `woocommerce_product_data_tabs`, `woocommerce_product_data_panels`, `woocommerce_product_after_variable_attributes`, `woocommerce_admin_process_product_object` y `_variation_object` | `ProductAdmin.php` |
| Metadatos nativos con `show_in_rest` (editor y Store API): `_lc_contenido`, `_lc_referencia` (cantidad y unidad por separado), `_lc_ingredientes`, `_lc_etiqueta`, `_lc_imagen_descripcion`, `_lc_consumo_preferente`, `_lc_excluir_internacional`. Si un producto aún no está normalizado, se lee la clave de ACF (`cantidad_unidad_medida`…) | `register_post_meta`, `register_term_meta` | `Fields.php`, `Quantity.php` |
| Tinta de la categoría (`_lc_tint`, la heredan las subcategorías) e icono del tipo (`_lc_icono`), con selector de medios | Campos de término (`product_cat_*_form_fields`, `created_`/`edited_`) | `TermFields.php`, `Admin.php` |
| Taxonomía `tipo` (sellos del producto) | `register_taxonomy` en `init` | `TipoTaxonomy.php` |
| Lo que ve el cliente, por los huecos del tema: precio por unidad («500 ml \| 9,33 € / 1 l»), tinta de categoría y de producto, etiqueta antes de las insignias, pestañas Ingredientes e imagen de descripción, sellos, consumo preferente y la segunda línea de los productos en los correos | Filtros `lachinata/product/*`, `lachinata/category/tint`, `lachinata/product_card/badges` | `Storefront.php`, `UnitPrice.php` |
| Normalización de ACF a los campos nativos (una vez por sitio): cantidad y unidad por separado; el EAN no se migra (manda el GTIN de WooCommerce y solo se avisa de los que no coinciden) | `wp lachinata catalog normalize [--dry-run] [--from-shipping-class=<slug>]` | `NormalizeCommand.php` |
| La marca de exclusión internacional para `shipping` | Filtro `lachinata/catalog/no_ship_abroad` (0.9.0) | `CatalogModule.php` |
| Categoría principal (`_lc_catalog_categoria_principal`, una de las del producto) e imagen de tarjeta (`_lc_catalog_imagen_tarjeta`) en la pestaña «La Chinata» | `lachinata/product/main_category`, `lachinata/product_card/image_id`; la tinta del producto sale de la principal | `ProductAdmin.php`, `Storefront.php` |
| Aspecto de cada etiqueta de producto: tono de la lista del sistema, imagen opcional (la bandera de «Extremeño») y orden | Campos del término `product_tag`; `lachinata/product_card/badges` las devuelve todas, en ese orden, tras «-20 %» y la «etiqueta» | `TermFields.php`, `Storefront.php` |
| Marca de una clase de envío: pastilla con texto en la tarjeta y un icono opcional («Refrigerado», sin icono, en Frío y Fresco) y, si se marca, su aviso en la ficha con su título, su icono y las condiciones que dan `shipping` y `eta` («Envío refrigerado» con el camión). Desde 0.12.3; antes, un icono con nombre accesible | `lachinata/product_card/marker`, `lachinata/product/notices` y `lachinata/catalog/marker_conditions` (0.12.2) | `Config.php`, `Storefront.php` |
| Categorías de la tienda: lista ordenada y campañas de temporada con fechas (entran delante mientras duran) | `lachinata/catalog/categories` | `Config.php`, `Storefront.php` |
| Venta cruzada por categoría raíz: título y fuente (las del producto y, sin ellas, los más vendidos de su subcategoría; o solo los más vendidos) | `lachinata/product/cross_sell` | `Config.php`, `Storefront.php` |
| WooCommerce → La Chinata → Catálogo: «Salud del catálogo» (se calcula al abrirla) y «Tienda» (la configuración de arriba); contador en la portada | `lachinata/core/admin_tabs`, `lachinata/core/admin_home` | `CatalogTab.php`, `Health.php` |
| Salud: precio por unidad sin referencia, sin contenido, de magnitudes distintas o con una referencia cien veces mayor que el contenido; GTIN que no puede existir (también de las variaciones); EAN antiguo distinto del GTIN; sin imagen; sin categoría; categoría principal que ya no es del producto | `wp lachinata catalog health [--format=table\|json\|count]` | `Health.php`, `NormalizeCommand.php` |
| Migración (dentro de `normalize`): categoría principal de Rank Math si el producto sigue en ella; EAN como GTIN si no hay GTIN y el dígito de control cuadra; en las descripciones, subtítulos en negrita en su propia línea a `h3` y `[products skus="…"]` al bloque `lachinata/products`, sin tocar el texto; informe de lo que no se traslada | `wp lachinata catalog normalize` | `Migrate.php`, `NormalizeCommand.php` |
| **Cambios que cuentan** (0.13.1): la fecha del último cambio de los sellos (`tipo`) y de los campos vigilados (ajuste `watched_fields`; de serie, los ingredientes, que llevan alérgenos, trazas y nutrición) en `_lc_catalog_cambios`, y `lachinata/catalog/product_changed`; al dejar de estar publicado, `lachinata/catalog/product_discontinued`. La descripción libre y el stock no cuentan. El blog manda a «Revisar» las entradas que lo mencionan | `updated_post_meta`, `deleted_post_meta`, `set_object_terms`, `transition_post_status` | `Changes.php` |
| **Paquete editorial** (0.14.0): los textos en español de los productos (nombre, descripción corta y larga, etiqueta, título y descripción SEO, texto alternativo de las imágenes, descripción de las variaciones que la tienen) salen como JSON con la huella de cada texto y vuelven con detección de conflictos; nombres cambiados aparte en el informe; `--mark-reviewed` marca «Revisado» (`SourceStatus` del núcleo) lo que entra entero. Sin ingredientes ni nutrición | `wp lachinata catalog export-editorial [--file] [--ids] [--category] [--post-status] [--source-status]`, `import-editorial <archivo> [--dry-run] [--mark-reviewed] [--report]` | `Editorial.php`, `NormalizeCommand.php` |
| **Regalos compuestos** (0.16.0): contenido del regalo (`_lc_catalog_regalo`, lista de `{id, sku, qty, note}`; el mismo producto dos veces suma unidades) en la caja «Contenido del regalo» del editor, con la búsqueda de productos de WooCommerce; presentación, un término de la taxonomía `lc_presentacion` (con sus palabras del nombre para la migración, `_lc_catalog_palabras`). Para el stock, los pedidos y Odoo sigue siendo un producto simple | `add_meta_boxes_product`, `woocommerce_admin_process_product_object`, formularios de `lc_presentacion` | `Gifts.php`, `GiftAdmin.php` |
| Lo que ve el cliente de un regalo: los productos en su orden, sin precios (uno que ya no existe no sale; uno sin publicar sale sin enlace), unidades, presentación y los alérgenos del conjunto (unión de los de cada producto, de `lachinata/catalog/allergens`, vacío de serie); en la ficha resumida de cada producto, los ingredientes de `lachinata/catalog/gift_item_ingredients`, vacío de serie (nunca `_lc_ingredientes`, que en muchos productos mezcla ingredientes, nutrición en dos idiomas y conservación); «N productos · {presentación}» en la tarjeta; «¿Es para tu empresa?» con su destino (página con {sku}, {nombre} y {min}, o WhatsApp de «Atención al cliente» con el mensaje escrito) | `lachinata/product/gift`, `lachinata/product_card/meta`, `lachinata/product/bulk_cta` | `GiftFront.php` |
| Salud: regalos con un producto que no existe, sin publicar o agotado | grupo «Regalos…» de la salud | `Health.php` |
| **Fotos recortadas** (0.16.0): una imagen con transparencia (PNG, WebP o GIF con píxeles transparentes, no solo con canal alfa) se marca con `_lc_catalog_recorte` al subirla o al cambiar su archivo; el tema la pinta centrada con aire sobre la tinta (`lachinata/catalog/cutout`) y `feeds` saca de ella el JPEG sobre blanco y la imagen de Open Graph. Comando para las que ya existen (también desmarca las que cambiaron) | `wp_generate_attachment_metadata`, `lachinata/catalog/cutout`, `wp lachinata catalog detect-cutouts [--dry-run]` | `Cutouts.php`, `NormalizeCommand.php` |
| Migración: los SKU del bloque de productos (o de `[products]`) de la descripción al contenido, con la presentación por la primera palabra del nombre y «Dimensiones (l x w x h): …» a las medidas de WooCommerce (nunca sobre otras); quita el bloque, su subtítulo («Contenido del…», «Productos incluidos») y la sección «Datos del producto» si se queda vacía. Informe en Markdown | `wp lachinata catalog migrate-gifts [--dry-run] [--report=<archivo>]` | `GiftMigrate.php`, `NormalizeCommand.php` |
| **Productos borrados** (0.17.1): al borrar un producto definitivamente (también desde la papelera), una 301 de su dirección a su categoría principal (o la más profunda) en la lista de redirecciones del panel (Rank Math), donde se edita. Ajuste `redirect_deleted`, encendido de serie. En otro idioma vale la misma regla (`translate`) | `before_delete_post` | `DeletedRedirect.php` |
| **Sellos en otro idioma** (0.17.1): el archivo de un sello (`/en/tipo/{sello}/`, direcciones antiguas) va con 301 a la tienda en ese idioma, filtrada por el sello si la tienda filtra por él (un atributo `tipo` de WooCommerce con ese término) | `template_redirect` (prioridad 0) | `TipoTaxonomy.php` |

## Depende de

Ningún módulo. WooCommerce 10. No necesita ACF: si está, conviven y el módulo lee sus valores hasta normalizarlos. Desde 0.17.1, la utilidad `Redirections` del núcleo (la lista de Rank Math) para la 301 de los productos borrados; sin Rank Math, no se crea.

## Hooks que escucha

- `init` (taxonomía y metadatos), la ficha de producto y las variaciones en el panel, los formularios de `product_cat` y `tipo`, `admin_enqueue_scripts` y `admin_notices` (selector de medios y avisos de la normalización).
- Del tema, desde 0.16.0: `lachinata/product/gift`, `lachinata/product/bulk_cta`, `lachinata/product_card/meta` y `lachinata/catalog/cutout`.
- `wp_generate_attachment_metadata` (0.16.0): comprueba si la imagen subida o sustituida es un recorte.
- `before_delete_post` y `template_redirect` (0.17.1): la 301 de un producto borrado y el archivo de un sello en otro idioma.
- Del tema: `lachinata/product/unit_price`, `lachinata/product/tint`, `lachinata/category/tint`, `lachinata/product_card/badges`, `lachinata/product/tabs`, `lachinata/product/seals`, `lachinata/product/details`, `lachinata/product/content`; desde 0.12.2, `lachinata/product_card/marker`, `lachinata/product_card/image_id`, `lachinata/product/main_category`, `lachinata/product/notices`, `lachinata/product/cross_sell` y `lachinata/catalog/categories`.
- Del núcleo: `lachinata/catalog/no_ship_abroad`, `lachinata/core/admin_tabs`, `lachinata/core/admin_home`.
- Los formularios de `product_tag` (tono, imagen y orden).
- `lachinata/translate/fields` (0.15.0): declara para `translate` la etiqueta de la tarjeta (`_lc_etiqueta`) y el nombre y la descripción de los sellos (`tipo`); desde 0.16.0, el nombre de las presentaciones (`lc_presentacion`). Ni ingredientes ni nutrición ni el contenido («300 g»).
- `lachinata/translate/options` (0.17.0): declara para `translate` los textos de sus ajustes: las marcas de envío (texto de la tarjeta y título del aviso), los títulos de la venta cruzada y los textos de «¿Es para tu empresa?» que la tienda escriba.

## Hooks que emite

- `lachinata/catalog/marker_conditions` (0.12.2): las frases del aviso de una clase con marca; las añaden `shipping` y `eta`.
- `lachinata/catalog/product_fields`: final de la pestaña «La Chinata», para los campos de otros módulos.
- `lachinata/catalog/allergens` (0.16.0): los alérgenos de un producto (`contains` y `traces`), vacío de serie; los traerá la aplicación de La Chinata.
- `lachinata/catalog/gift_item_ingredients` (0.16.0): los ingredientes de un producto para la ficha resumida de un regalo, vacío de serie; también de la aplicación.
- Lo demás sale por los huecos del tema (`theme/HOOKS.md`) y por `lachinata/catalog/no_ship_abroad` (`plugin/HOOKS.md`).

## Datos que guarda

- Desde 0.16.0: `_lc_catalog_regalo` (producto), `_lc_catalog_recorte` (adjunto, `1` en una foto recortada), la taxonomía `lc_presentacion` (sus términos son contenido del sitio) con `_lc_catalog_palabras` y la opción `lachinata_catalog_bulk`.
- Metadatos de producto y variación: `_lc_contenido`, `_lc_referencia`, `_lc_ingredientes`, `_lc_etiqueta`, `_lc_imagen_descripcion`, `_lc_consumo_preferente`, `_lc_excluir_internacional`; desde 0.12.2, `_lc_catalog_categoria_principal` y `_lc_catalog_imagen_tarjeta`.
- Metadatos de término: `_lc_tint` (`product_cat`), `_lc_icono` (`tipo`); desde 0.12.2, `_lc_catalog_tono`, `_lc_catalog_imagen` y `_lc_catalog_orden` (`product_tag`). Los términos de `tipo` son contenido del sitio.
- Opciones (0.12.2): `lachinata_catalog_store_categories`, `lachinata_catalog_campaigns`, `lachinata_catalog_cross_sell`, `lachinata_catalog_markers` (por slug de categoría y de clase de envío) y el transitorio `lachinata_catalog_health_count` (último recuento de la salud, un día).
- El paquete editorial escribe los campos de WooCommerce, `_lc_etiqueta`, `rank_math_title`, `rank_math_description` y el texto alternativo de los adjuntos (`_wp_attachment_image_alt`), y marca `_lc_source_status`, que es del núcleo, con su utilidad `SourceStatus`.
- Son anteriores a la regla `_lc_<módulo>_*` y se quedan con su nombre (excepción catalogada en `plugin/HOOKS.md`). Las claves de ACF no se tocan nunca.

## REST y API para Odoo

Los metadatos de producto van en la API REST y en la Store API (`show_in_rest`). Nada en el objeto `lachinata` de los pedidos.

## Ajustes y exportación

Desde 0.12.2, cuatro ajustes de tipo lista que viajan en el JSON: `store_categories`, `campaigns`, `cross_sell` y `markers`. Desde 0.16.0, `bulk` («¿Es para tu empresa?»: `min`, `title`, `text`, `cta`, `destination`, `url`, `whatsapp_text`, `gifts`, `categories`); sin guardar, sale en los regalos compuestos con los textos del plugin y `/regalos-de-empresa/?producto={sku}`. Desde 0.17.1, `redirect_deleted` (encendido de serie): la 301 de los productos borrados. Van por slug (de categoría y de clase de envío) para que valgan en otra tienda; `Config` los lee saneados, también cuando llegan de un JSON importado. Los datos de cada producto y término (tonos de etiqueta, categoría principal…) son contenido y no viajan.

## Qué pasa al apagarlo

El tema vuelve a sus valores neutros: sin tintas, sin precio por unidad, sin etiqueta, pestañas ni sellos propios; etiquetas en gris, sin marca de clase ni aviso de refrigerado; todas las categorías raíz en la navegación; venta cruzada «También te puede gustar» con las ventas cruzadas o los más vendidos; la taxonomía `tipo` deja de registrarse (sus términos siguen en la base de datos); los regalos se ven como productos normales, sin «Qué lleva» ni «¿Es para tu empresa?», y `lc_presentacion` deja de registrarse y `shipping` deja de ver la exclusión internacional del producto (solo cuentan las clases de envío). Los datos se quedan. «Borrar datos» borra los metadatos de producto y término de arriba (nunca las claves de ACF ni los pedidos), después de descargar el JSON del módulo.

## Pruebas

- `tests/ShopTest.php` (etiquetas con su aspecto y orden, marca y aviso de la clase, categoría principal, imagen de tarjeta, categorías y campañas, venta cruzada), `tests/HealthTest.php` (salud y recuento), `tests/FieldsTest.php` (registro, lectura con la clave de ACF de respaldo), `tests/QuantityTest.php` (cantidad y unidad), `tests/UnitPriceTest.php` (precio por unidad, también por variación), `tests/StorefrontTest.php` (lo que llega al tema por cada hueco), `tests/NormalizeCommandTest.php` (normalización, `--dry-run`, GTIN, `--from-shipping-class`, categoría principal, EAN a GTIN, subtítulos a `h3` y `[products]` al bloque).
- `tests/DeletedRedirectTest.php` (0.17.1): la 301 a la categoría principal o a la más profunda, también desde la papelera con su dirección de antes; a la papelera, nada; con el ajuste apagado, nada.
- `tests/CutoutsTest.php` (detección en PNG, WebP, GIF y JPEG; canal alfa sin transparencia; marca al subir; comando con simulación, nuevas y desmarcadas).
- `tests/GiftsTest.php` (filas, lo que llega al tema, alérgenos e ingredientes sin datos y con fuente, productos que faltan y salud, «¿Es para tu empresa?» con página, categorías y WhatsApp, presentación por el nombre) y `tests/GiftMigrateTest.php` (texto antiguo, el de marketing, «Datos del producto», maquetaciones antiguas, migración completa sin pisar medidas y sin repetir).
- e2e: `tests/e2e/gifts.spec.mjs` (resumen, «Qué lleva» sin precios, diálogo con Escape, sin JavaScript, BulkCta y tarjeta) y `lc_bulk_quote` en `tests/e2e/tracking.spec.mjs`.
- `tests/EditorialTest.php` (paquete: solo lectura, campos vacíos, sin ingredientes, variaciones con descripción; importación, ida y vuelta sin cambios, conflictos, simulación, errores, nombres aparte y «Revisado»).
- e2e: `tests/e2e/catalog.spec.mjs` (tarjeta, opiniones, ChipRow y aviso de refrigerado).
- En cada perfil: `tests/profiles/ProfileBootTest.php`. El módulo solo: `tools/tests/modules-isolated.sh`.

## Huecos conocidos

- Alérgenos e ingredientes de cada producto en los regalos: sin fuente hasta la aplicación de La Chinata (`lachinata/catalog/allergens` y `lachinata/catalog/gift_item_ingredients` devuelven vacío y no se pintan).
- Una imagen editada en el editor de imágenes de WordPress (recortar, girar) no se vuelve a comprobar: `detect-cutouts` la pone al día.
- El título de «Qué lleva» va sin el nombre: «Qué lleva el {nombre}» no concuerda con los nombres en femenino («Cesta…»).

- Exclusión internacional duplicada (clase «Ocultar internacional» y campo): pendiente de decidir cuál manda; `normalize --from-shipping-class` pasa de la clase al campo.
- `rutina`, `destacamos`, `modo_empleo` y `email_collect` de ACF no se migran (decidido).
- El modo de empleo no está en el paquete editorial: no existe como campo (`modo_empleo` no se migró). Ingredientes y valores nutricionales tampoco: vendrán de la aplicación de La Chinata (`07-traduccion.md`).
- El grupo «Oleoteca» de ACF llegó con `oleotecas` (0.12.0).
- La maquetación antigua de algunas descripciones (`div.row`, `h4` con `span` y estilos en línea) no se toca: el informe de la migración la lista y decide La Chinata.
- El pedido mínimo (21 productos con Min/Max Quantities) llega con el módulo de personalizados; hasta entonces, solo en el informe.
