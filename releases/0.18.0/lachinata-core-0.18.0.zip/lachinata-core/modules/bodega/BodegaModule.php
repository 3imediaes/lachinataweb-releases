<?php
/**
 * Module `bodega`: wines, cases of 6 and pairing.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

use LaChinata\Core\Hooks;
use LaChinata\Core\Module;
use LaChinata\Core\Plugin;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Wine data (type, making, winery, origin, grapes, pairing, tasting, scores and awards by
 * vintage), the wine page and listing, cases of 6 with a discount per line, pairing with the
 * shop's products, age notices and the +18 box in the checkout, the migration from the
 * descriptions and the import of scores. Specification: design-system/sistema/10-bodega.md.
 */
final class BodegaModule extends Module {

	/**
	 * Module id.
	 */
	public function id(): string {
		return 'bodega';
	}

	/**
	 * Module name.
	 */
	public function label(): string {
		return __( 'Bodega', 'lachinata-core' );
	}

	/**
	 * Module description.
	 */
	public function description(): string {
		return __( 'Vinos: ficha técnica, cata, añadas con puntuaciones y premios, maridaje con productos de la tienda, listado con filtros, cajas de 6 con descuento y avisos de edad.', 'lachinata-core' );
	}

	/**
	 * Version in which the module was added.
	 */
	public function since(): string {
		return '0.18.0';
	}

	/**
	 * Documentation.
	 */
	public function docs(): string {
		return 'plugin/modules/bodega/README.md';
	}

	/**
	 * Requirements.
	 *
	 * @return array{woocommerce: string}
	 */
	public function requires(): array {
		return array( 'woocommerce' => '10.0' );
	}

	/**
	 * Settings (all travel in the JSON). Read them clean with Config.
	 *
	 * @return array<string, array{type: 'bool'|'int'|'float'|'string'|'array', default: mixed, export: bool}>
	 */
	public function settings(): array {
		$setting = static fn( string $type, $fallback ): array => array(
			'type'    => $type,
			'default' => $fallback,
			'export'  => true,
		);
		return array(
			'category'             => $setting( 'string', '' ),
			'accessories_category' => $setting( 'string', '' ),
			'vintage_attribute'    => $setting( 'string', '' ),
			'format_attribute'     => $setting( 'string', '' ),
			'case_same'            => $setting( 'float', 10.0 ),
			'case_mixed'           => $setting( 'float', 5.0 ),
			'stack_sale'           => $setting( 'bool', false ),
			'stack_coupons'        => $setting( 'bool', false ),
			'critics'              => $setting( 'array', array() ),
			'contests'             => $setting( 'array', array() ),
			'medals'               => $setting( 'array', array() ),
			'min_points'           => $setting( 'int', 90 ),
			'min_medal'            => $setting( 'string', '' ),
			'suggest_pairing'      => $setting( 'bool', true ),
			'carrier_note'         => $setting( 'bool', false ),
			'texts'                => $setting( 'array', array() ),
			'chips'                => $setting( 'array', array() ),
			'entries'              => $setting( 'array', array() ),
			'featured_origin'      => $setting( 'string', '' ),
			'landing_min'          => $setting( 'int', 3 ),
		);
	}

	/**
	 * The module, for Settings.
	 */
	public static function instance(): ?Module {
		return Plugin::instance()->modules()->get( 'bodega' );
	}

	/**
	 * A setting of the module (its default when the module is not registered).
	 *
	 * @param string $key Setting key.
	 * @return mixed
	 */
	public static function setting( string $key ) {
		$module = self::instance();
		if ( null === $module ) {
			$module = new self();
		}
		return Settings::get( $module, $key );
	}

	/**
	 * Whether the settings are enough to work: the Bodega category is chosen.
	 *
	 * @return array{configured: bool|null, credentials: bool|null, notes: string[]}
	 */
	public function health(): array {
		$notes = array();
		if ( null === Config::category() ) {
			$notes[] = __( 'Falta elegir la categoría de la Bodega (WooCommerce → La Chinata → Bodega).', 'lachinata-core' );
		}
		if ( '' === Config::vintage_attribute() ) {
			$notes[] = __( 'No hay atributo de añada: las puntuaciones no se pueden enganchar a su añada.', 'lachinata-core' );
		}
		return array(
			'configured'  => ! $notes,
			'credentials' => null,
			'notes'       => $notes,
		);
	}

	/**
	 * Product, variation and term meta («Borrar datos» removes them; the taxonomies' terms
	 * are content and stay).
	 *
	 * @return array{product_meta: string[], term_meta: string[], options: string[]}
	 */
	public function owned_data(): array {
		return array(
			'product_meta' => Fields::product_keys(),
			'term_meta'    => Taxonomies::meta_keys(),
			'options'      => array( Taxonomies::SEEDED, WineryMerge::OPTION, Landing::OPTION ),
		);
	}

	/**
	 * Declares for `translate` the texts of its settings.
	 *
	 * @param mixed $options Options of other modules.
	 * @return array<string, array<string, mixed>>
	 */
	public static function translatable_options( $options ): array {
		$options                             = is_array( $options ) ? $options : array();
		$options['lachinata_bodega_texts']   = array(
			'label' => __( 'Bodega: textos', 'lachinata-core' ),
			'paths' => array( 'age', 'carrier_note', 'eyebrow', 'intro' ),
		);
		$options['lachinata_bodega_chips']   = array(
			'label' => __( 'Bodega: chips del listado', 'lachinata-core' ),
			'paths' => array( '*.label' ),
		);
		$options['lachinata_bodega_entries'] = array(
			'label' => __( 'Bodega: entradas del listado', 'lachinata-core' ),
			'paths' => array( '*.title', '*.eyebrow', '*.text', '*.cta' ),
		);
		return $options;
	}

	/**
	 * Registers the hooks.
	 */
	public function boot(): void {
		Hooks::add_action( 'init', array( Taxonomies::class, 'register' ), 5 );
		Hooks::add_action( 'init', array( Taxonomies::class, 'seed' ), 20 );
		Hooks::add_action( 'init', array( Fields::class, 'register' ) );
		Hooks::add_filter( 'lachinata/translate/fields', array( Fields::class, 'translatable' ) );
		Hooks::add_filter( 'lachinata/translate/options', array( self::class, 'translatable_options' ) );
		Scores::boot();
		Cart::boot();
		Checkout::boot();
		Orders::boot();
		Storefront::boot();
		Listing::boot();
		Landing::boot();
		Seo::boot();
		Pairing::boot();
		Rest::boot();
		WineryMerge::boot();

		if ( is_admin() ) {
			ProductBox::boot();
			ProductList::boot();
			TermFields::boot();
			BodegaTab::boot();
		}

		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::add_command( 'lachinata bodega', Cli::class );
		}
	}
}
