<?php
/**
 * «Marida con».
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * The dishes of a wine and up to three products of the shop chosen in the panel. Without
 * chosen products, and while the setting and the wine allow it, one suggestion per dish:
 * the best seller of the store category its dish points to (Quesos for «Quesos curados»).
 *
 * «Añadir los dos» is a form posted to the bag (the classic handler, so it works without
 * JavaScript): the wine with the quantity and vintage chosen on the page, and the product.
 */
final class Pairing {

	/**
	 * Fields of the form.
	 */
	public const FIELD_PRODUCT = 'lc-bodega-pair';
	public const FIELD_WINE    = 'lc-bodega-wine';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'wp_loaded', array( self::class, 'handle' ), 15 );
	}

	/**
	 * Pairing of a wine: dish names, products (visible and purchasable), whether they are
	 * suggestions and the wine's name.
	 *
	 * @param \WC_Product $product Wine.
	 * @return array{dishes: string[], products: \WC_Product[], suggested: bool, wine: string}
	 */
	public static function of( \WC_Product $product ): array {
		$dishes   = Fields::terms( $product, Taxonomies::DISH );
		$products = array();
		foreach ( Fields::pairing( Fields::get( $product->get_id(), Fields::PAIRING ) ) as $id ) {
			$item = wc_get_product( $id );
			if ( $item instanceof \WC_Product && $item->is_visible() && $item->is_purchasable() ) {
				$products[] = $item;
			}
		}
		$suggested = false;
		if ( ! $products && $dishes && Fields::suggests( $product ) ) {
			$products  = self::suggest( $dishes, $product->get_id() );
			$suggested = (bool) $products;
		}
		return array(
			'dishes'    => array_map( static fn( \WP_Term $term ): string => $term->name, $dishes ),
			'products'  => $products,
			'suggested' => $suggested,
			'wine'      => $product->get_name(),
		);
	}

	/**
	 * One product per dish with a category, the best seller in stock (without alcohol),
	 * at most three.
	 *
	 * @param \WP_Term[] $dishes  Dishes.
	 * @param int        $exclude Wine.
	 * @return \WC_Product[]
	 */
	public static function suggest( array $dishes, int $exclude ): array {
		$chosen = array();
		foreach ( $dishes as $dish ) {
			if ( count( $chosen ) >= Fields::MAX_PAIRING ) {
				break;
			}
			$category = (int) get_term_meta( $dish->term_id, Taxonomies::DISH_CATEGORY, true );
			if ( ! $category ) {
				continue;
			}
			$key = 'lachinata_bodega_suggest_' . $category . '_' . \WC_Cache_Helper::get_transient_version( 'product' );
			$ids = get_transient( $key );
			if ( ! is_array( $ids ) ) {
				$ids = wc_get_products(
					array(
						'status'       => 'publish',
						'visibility'   => 'catalog',
						'stock_status' => 'instock',
						'limit'        => 6,
						'orderby'      => 'popularity',
						'order'        => 'DESC',
						'return'       => 'ids',
						'tax_query'    => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
							array(
								'taxonomy' => 'product_cat',
								'terms'    => array( $category ),
							),
						),
					)
				);
				$ids = is_array( $ids ) ? array_map( 'intval', $ids ) : array();
				set_transient( $key, $ids, DAY_IN_SECONDS );
			}
			foreach ( $ids as $id ) {
				$item = wc_get_product( $id );
				if ( $id === $exclude || isset( $chosen[ $id ] ) || ! $item instanceof \WC_Product || ! $item->is_purchasable() || Fields::has_alcohol( $item ) ) {
					continue;
				}
				$chosen[ $id ] = $item;
				break;
			}
		}
		return array_values( $chosen );
	}

	/**
	 * Adds the wine and the product of «Añadir los dos», before WooCommerce's handler.
	 */
	public static function handle(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Adding to the bag, like WooCommerce's own form (no nonce).
		if ( empty( $_POST[ self::FIELD_PRODUCT ] ) || empty( $_POST[ self::FIELD_WINE ] ) || ! function_exists( 'WC' ) || ! WC()->cart ) {
			return;
		}
		$wine_id   = absint( wp_unslash( $_POST[ self::FIELD_WINE ] ) );
		$pair_id   = absint( wp_unslash( $_POST[ self::FIELD_PRODUCT ] ) );
		$variation = isset( $_POST['variation_id'] ) ? absint( wp_unslash( $_POST['variation_id'] ) ) : 0;
		$quantity  = isset( $_POST['quantity'] ) ? max( 1, absint( wp_unslash( $_POST['quantity'] ) ) ) : 1;
		$wine      = wc_get_product( $wine_id );
		$pair      = wc_get_product( $pair_id );
		$attrs     = array();
		foreach ( wp_unslash( $_POST ) as $name => $value ) {
			if ( is_string( $name ) && str_starts_with( $name, 'attribute_' ) && is_scalar( $value ) ) {
				$attrs[ sanitize_title( $name ) ] = wc_clean( (string) $value );
			}
		}
		// phpcs:enable
		if ( ! $wine instanceof \WC_Product || ! $pair instanceof \WC_Product || ! $pair->is_purchasable() || $pair->is_type( 'variable' ) ) {
			wc_add_notice( __( 'No hemos podido añadir los dos productos. Prueba a añadirlos por separado.', 'lachinata-core' ), 'error' );
			return;
		}
		if ( $wine instanceof \WC_Product_Variable && ! $variation ) {
			$default   = Storefront::default_child( $wine );
			$variation = $default ? $default->get_id() : 0;
		}
		if ( $variation && ! $attrs ) {
			$child = wc_get_product( $variation );
			$attrs = $child instanceof \WC_Product_Variation ? $child->get_variation_attributes() : array();
		}
		$added_wine = $variation
			? WC()->cart->add_to_cart( $wine->get_id(), $quantity, $variation, $attrs )
			: WC()->cart->add_to_cart( $wine->get_id(), $quantity );
		$added_pair = $added_wine ? WC()->cart->add_to_cart( $pair->get_id(), 1 ) : false;
		if ( ! $added_wine || ! $added_pair ) {
			return;
		}
		wc_add_notice(
			sprintf(
				/* translators: 1: wine, 2: product. */
				__( 'Hemos añadido %1$s y %2$s a tu bolsa.', 'lachinata-core' ),
				$wine->get_name(),
				$pair->get_name()
			),
			'success'
		);
		/**
		 * A measurement event for the next page (core of tracking, plugin/HOOKS.md).
		 *
		 * @since 0.18.0
		 *
		 * @param string               $name   Event.
		 * @param array<string, mixed> $params Parameters.
		 */
		do_action(
			'lachinata/tracking/event',
			'lc_pairing_add',
			array(
				'item_id'    => (string) $wine->get_id(),
				'pairing_id' => (string) $pair->get_id(),
				'quantity'   => $quantity,
			)
		);
	}
}
