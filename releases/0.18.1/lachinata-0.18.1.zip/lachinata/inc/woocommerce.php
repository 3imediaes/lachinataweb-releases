<?php
/**
 * WooCommerce integration: the theme prints its own markup, so the default wrappers,
 * sidebar and loop pieces are removed, and catalog queries follow the system.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Checkout (and order received) views: no PromoBar, BottomNav or layers.
 */
function lachinata_is_checkout_view(): bool {
	return function_exists( 'is_checkout' ) && is_checkout();
}

/**
 * Removes WooCommerce's default presentation hooks that the templates replace.
 */
function lachinata_woocommerce_hooks(): void {
	remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
	remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );
	remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
	remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );
	remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );
	remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );
	add_filter( 'woocommerce_show_page_title', '__return_false' );
	// The order received page prints its own OrderSummary (woocommerce/checkout/thankyou.php).
	remove_action( 'woocommerce_thankyou', 'woocommerce_order_details_table', 10 );
}
add_action( 'init', 'lachinata_woocommerce_hooks' );

/**
 * Twelve products per page, as in the category template («Cargar más» in batches of 12).
 */
add_filter( 'loop_shop_per_page', static fn(): int => 12 );

/**
 * Filter chips and checkboxes send arrays (filter_formato[]=a&filter_formato[]=b);
 * WooCommerce's layered navigation expects comma-separated values.
 */
function lachinata_normalize_filter_params(): void {
	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only catalog filters.
	foreach ( array_keys( $_GET ) as $key ) {
		if ( is_string( $key ) && str_starts_with( $key, 'filter_' ) && isset( $_GET[ $key ] ) && is_array( $_GET[ $key ] ) ) {
			$_GET[ $key ] = implode( ',', array_map( 'sanitize_title', wp_unslash( $_GET[ $key ] ) ) );
		}
	}
	// phpcs:enable
}
add_action( 'parse_request', 'lachinata_normalize_filter_params', 1 );

/**
 * Filters available in the current catalog view: the attributes with products here and
 * those a module adds (the Bodega's type, origin, grape…).
 *
 * @return array<int, array{taxonomy: string, param: string, label: string, terms: WP_Term[], chosen: string[]}>
 */
function lachinata_catalog_filters(): array {
	static $filters = null;
	if ( null !== $filters ) {
		return $filters;
	}
	/**
	 * Filters of the listing, in the theme's shape: `taxonomy`, `param` (the GET parameter,
	 * `a,b` or `a[]`), `label`, `terms` (objects with `slug` and `name`) and `chosen`
	 * (slugs). The module that adds a filter also applies it to the query.
	 *
	 * @since 0.18.0
	 *
	 * @param array<int, array<string, mixed>> $filters Attribute filters with products in the view.
	 */
	$filters = (array) apply_filters( 'lachinata/catalog/filters', lachinata_attribute_filters() );
	return $filters;
}

/**
 * Attribute filters with products in the current catalog view.
 *
 * @return array<int, array{taxonomy: string, param: string, label: string, terms: WP_Term[], chosen: string[]}>
 */
function lachinata_attribute_filters(): array {
	$taxonomies = array();
	foreach ( wc_get_attribute_taxonomies() as $attribute ) {
		$taxonomies[ wc_attribute_taxonomy_name( $attribute->attribute_name ) ] = $attribute;
	}
	if ( ! $taxonomies ) {
		return array();
	}

	$term      = get_queried_object();
	$cache_key = 'lachinata_filters_' . ( $term instanceof WP_Term ? $term->term_id : 'shop' ) . '_' . WC_Cache_Helper::get_transient_version( 'product' );
	$by_tax    = get_transient( $cache_key );
	if ( ! is_array( $by_tax ) ) {
		$query = array(
			'status' => 'publish',
			'limit'  => -1,
			'return' => 'ids',
		);
		if ( $term instanceof WP_Term && 'product_cat' === $term->taxonomy ) {
			$query['category'] = array( $term->slug );
		}
		$ids    = wc_get_products( $query );
		$by_tax = array();
		if ( $ids ) {
			foreach ( wp_get_object_terms( $ids, array_keys( $taxonomies ) ) as $found ) {
				$by_tax[ $found->taxonomy ][ $found->term_id ] = $found;
			}
		}
		set_transient( $cache_key, $by_tax, DAY_IN_SECONDS );
	}

	$chosen  = WC_Query::get_layered_nav_chosen_attributes();
	$filters = array();
	foreach ( $by_tax as $taxonomy => $terms ) {
		$filters[] = array(
			'taxonomy' => $taxonomy,
			'param'    => 'filter_' . wc_attribute_taxonomy_slug( $taxonomy ),
			'label'    => $taxonomies[ $taxonomy ]->attribute_label,
			'terms'    => array_values( $terms ),
			'chosen'   => $chosen[ $taxonomy ]['terms'] ?? array(),
		);
	}
	return $filters;
}

/**
 * Applied filters as removable chips: [label, url without that filter].
 *
 * @return array<int, array{0: string, 1: string}>
 */
function lachinata_applied_filters(): array {
	$applied = array();
	foreach ( lachinata_catalog_filters() as $filter ) {
		foreach ( $filter['terms'] as $term ) {
			if ( in_array( $term->slug, $filter['chosen'], true ) ) {
				$rest      = array_diff( $filter['chosen'], array( $term->slug ) );
				$applied[] = array( $term->name, $rest ? add_query_arg( $filter['param'], implode( ',', $rest ) ) : remove_query_arg( $filter['param'] ) );
			}
		}
	}
	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only catalog filters.
	foreach ( array( 'min_price', 'max_price' ) as $param ) {
		if ( isset( $_GET[ $param ] ) && '' !== $_GET[ $param ] ) {
			$value = wc_price( (float) wc_clean( wp_unslash( $_GET[ $param ] ) ) );
			$label = 'min_price' === $param
				/* translators: %s: price. */
				? sprintf( __( 'Desde %s', 'lachinata' ), wp_strip_all_tags( $value ) )
				/* translators: %s: price. */
				: sprintf( __( 'Hasta %s', 'lachinata' ), wp_strip_all_tags( $value ) );
			$applied[] = array( $label, remove_query_arg( $param ) );
		}
	}
	// phpcs:enable
	return $applied;
}

/**
 * Notices printed with the Notice component instead of WooCommerce's markup.
 *
 * @param string $template      Located template.
 * @param string $template_name Template name.
 */
function lachinata_notice_templates( string $template, string $template_name ): string {
	$map = array(
		'notices/success.php' => 'success',
		'notices/error.php'   => 'error',
		'notices/notice.php'  => 'info',
	);
	if ( isset( $map[ $template_name ] ) ) {
		set_query_var( 'lachinata_notice_tone', $map[ $template_name ] );
		return get_template_directory() . '/woocommerce/notices/lachinata-notice.php';
	}
	return $template;
}
add_filter( 'wc_get_template', 'lachinata_notice_templates', 10, 2 );

/**
 * The icon of the Notice component through WooCommerce's filter of the notices, which
 * passes the whole printed notice through wp_kses(): without this it loses its class and
 * its <use>, and the empty SVG takes half the box.
 *
 * @param mixed $tags Allowed tags.
 * @return mixed
 */
function lachinata_notice_allowed_tags( $tags ) {
	if ( ! is_array( $tags ) ) {
		return $tags;
	}
	$tags['svg'] = array_merge(
		(array) ( $tags['svg'] ?? array() ),
		array_fill_keys( array( 'class', 'viewbox', 'fill', 'stroke', 'stroke-width', 'stroke-linecap', 'stroke-linejoin', 'aria-hidden', 'focusable', 'role' ), true )
	);
	$tags['use'] = array( 'href' => true );
	return $tags;
}
add_filter( 'woocommerce_kses_notice_allowed_tags', 'lachinata_notice_allowed_tags' );

/**
 * Cross-sell of the product page: its title and up to four products. Where they come from
 * is set by root category (module `catalog`): the product's cross-sells and, without
 * them, the best sellers of its subcategory (by default), or only the best sellers.
 *
 * @param WC_Product $product Product.
 * @param int        $limit   Products.
 * @return array{title: string, products: WC_Product[]}
 */
function lachinata_cross_sell( WC_Product $product, int $limit = 4 ): array {
	/**
	 * Title and source of the cross-sell of a product: `cross_sells` (the product's, and
	 * the best sellers of its subcategory when it has none) or `bestsellers`.
	 *
	 * @since 0.12.2
	 *
	 * @param array{title: string, source: string} $cross_sell Title and source.
	 * @param WC_Product                           $product    Product.
	 */
	$config = (array) apply_filters(
		'lachinata/product/cross_sell',
		array(
			'title'  => __( 'También te puede gustar', 'lachinata' ),
			'source' => 'cross_sells',
		),
		$product
	);
	$ids    = 'bestsellers' === ( $config['source'] ?? '' ) ? array() : $product->get_cross_sell_ids();
	$main   = $ids ? null : lachinata_product_main_category( $product );
	if ( $main ) {
		$ids = wc_get_products(
			array(
				'status'     => 'publish',
				'visibility' => 'catalog',
				'limit'      => $limit + 1,
				'category'   => array( $main->slug ),
				'exclude'    => array( $product->get_id() ),
				'orderby'    => 'popularity',
				'return'     => 'ids',
			)
		);
	}
	/**
	 * Product ids of the cross-sell (module `locale` leaves out those that do not ship to
	 * the visitor's destination).
	 *
	 * @since 0.2.0
	 *
	 * @param int[]      $ids     Cross-sells, or best sellers of the same subcategory.
	 * @param WC_Product $product Product.
	 */
	$ids      = (array) apply_filters( 'lachinata/product/routine_ids', array_map( 'intval', (array) $ids ), $product );
	$products = array_filter( array_map( 'wc_get_product', array_slice( $ids, 0, $limit ) ) );
	return array(
		'title'    => (string) ( $config['title'] ?? '' ),
		'products' => array_values( array_filter( $products, static fn( $p ): bool => $p instanceof WC_Product && $p->is_visible() ) ),
	);
}

/**
 * Tabs of the product page: Descripción · (modules) · Opiniones.
 *
 * @param WC_Product $product Product.
 * @return array<int, array{id: string, title: string, content: string}>
 */
function lachinata_product_tabs( WC_Product $product ): array {
	$tabs        = array();
	$description = (string) apply_filters( 'the_content', $product->get_description() ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core hook.
	if ( '' !== trim( wp_strip_all_tags( $description ) ) ) {
		$tabs[] = array(
			'id'      => 'description',
			'title'   => __( 'Descripción', 'lachinata' ),
			'content' => $description,
		);
	}
	/**
	 * Tabs of the product page. Reviews are added after this filter.
	 *
	 * @since 0.2.0
	 *
	 * @param array<int, array{id: string, title: string, content: string}> $tabs    Tabs (content is HTML).
	 * @param WC_Product                                                  $product Product.
	 */
	return (array) apply_filters( 'lachinata/product/tabs', $tabs, $product );
}

/**
 * Sort options with the system wording (WooCommerce's filter still applies).
 *
 * @return array<string, string>
 */
function lachinata_catalog_orderby_options(): array {
	$options = array(
		'menu_order' => __( 'Relevancia', 'lachinata' ),
		'popularity' => __( 'Más vendidos', 'lachinata' ),
		'rating'     => __( 'Mejor valorados', 'lachinata' ),
		'date'       => __( 'Novedades', 'lachinata' ),
		'price'      => __( 'Precio: de menor a mayor', 'lachinata' ),
		'price-desc' => __( 'Precio: de mayor a menor', 'lachinata' ),
	);
	if ( ! wc_review_ratings_enabled() ) {
		unset( $options['rating'] );
	}
	if ( is_search() ) {
		$options = array( 'relevance' => __( 'Relevancia', 'lachinata' ) ) + array_diff_key( $options, array( 'menu_order' => true ) );
	}
	return (array) apply_filters( 'woocommerce_catalog_orderby', $options ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook.
}

/**
 * Current sort option.
 */
function lachinata_catalog_current_orderby(): string {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only catalog sort.
	if ( isset( $_GET['orderby'] ) ) {
		return (string) wc_clean( wp_unslash( $_GET['orderby'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}
	return is_search() ? 'relevance' : (string) apply_filters( 'woocommerce_default_catalog_orderby', get_option( 'woocommerce_default_catalog_orderby', 'menu_order' ) ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook.
}

/**
 * Page of reviews the visitor asks for: 1 shows the 5 most recent; from 2 on, 10 each
 * (the link «Ver más opiniones» without JavaScript).
 */
function lachinata_reviews_page(): int {
	return max( 1, isset( $_GET['opiniones'] ) ? absint( wp_unslash( $_GET['opiniones'] ) ) : 1 ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only page number.
}

/**
 * Reviews of a page: how many and from which one (5 on the first, 10 on the others).
 *
 * @param int $page Page of reviews.
 * @return array{number: int, offset: int}
 */
function lachinata_reviews_window( int $page ): array {
	return 1 === $page
		? array(
			'number' => 5,
			'offset' => 0,
		)
		: array(
			'number' => 10,
			'offset' => 5 + 10 * ( $page - 2 ),
		);
}

/**
 * The pages of reviews after the first one are not indexed: the product page is.
 *
 * @param array<string, bool|string> $robots Robots directives.
 * @return array<string, bool|string>
 */
function lachinata_reviews_robots( array $robots ): array {
	if ( is_singular( 'product' ) && lachinata_reviews_page() > 1 ) {
		$robots['noindex'] = true;
		$robots['follow']  = true;
	}
	return $robots;
}
add_filter( 'wp_robots', 'lachinata_reviews_robots' );

/**
 * The same for an SEO plugin that prints its own robots meta (the core of the plugin reads
 * `lachinata/robots/noindex`).
 *
 * @param mixed $noindex Whether the page is not indexed.
 */
function lachinata_reviews_noindex( $noindex ): bool {
	return (bool) $noindex || ( is_singular( 'product' ) && lachinata_reviews_page() > 1 );
}
add_filter( 'lachinata/robots/noindex', 'lachinata_reviews_noindex' );

/**
 * The product schema carries the mean, the count and the reviews the page shows (the 5
 * most recent), not more.
 *
 * @param array<string, mixed> $markup Product markup of WooCommerce.
 * @return array<string, mixed>
 */
function lachinata_reviews_schema( array $markup ): array {
	if ( isset( $markup['review'] ) && is_array( $markup['review'] ) ) {
		$markup['review'] = array_slice( $markup['review'], 0, lachinata_reviews_window( 1 )['number'] );
	}
	return $markup;
}
add_filter( 'woocommerce_structured_data_product', 'lachinata_reviews_schema' );
