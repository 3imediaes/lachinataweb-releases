<?php
/**
 * Category, line, shop, tag and search listing.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

get_header();

$lachinata_term    = get_queried_object();
$lachinata_is_cat  = $lachinata_term instanceof WP_Term && 'product_cat' === $lachinata_term->taxonomy;
$lachinata_root    = $lachinata_is_cat ? lachinata_root_category( $lachinata_term ) : null;
$lachinata_tint    = $lachinata_is_cat ? lachinata_category_tint( $lachinata_term ) : '';
$lachinata_total   = (int) $GLOBALS['wp_query']->found_posts;
$lachinata_shown   = min( $lachinata_total, (int) $GLOBALS['wp_query']->get( 'posts_per_page' ) * max( 1, (int) get_query_var( 'paged' ) ) );
$lachinata_filters = lachinata_catalog_filters();
$lachinata_applied = lachinata_applied_filters();

if ( is_search() ) {
	/* translators: %s: search terms. */
	$lachinata_title = sprintf( __( 'Resultados para «%s»', 'lachinata' ), get_search_query() );
} elseif ( $lachinata_term instanceof WP_Term ) {
	$lachinata_title = $lachinata_term->name;
} else {
	$lachinata_title = woocommerce_page_title( false );
}
/**
 * Header of a category listing of a module (the Bodega and its type and origin pages):
 * `eyebrow`, `title`, `tint` (of the header and the cards), `text` (a line under the title; the count when empty), `chips`
 * (`label`, `href`, `selected`) in place of the lines of the root, `entries`
 * (CategoryTile: `title`, `href`, `eyebrow`, `text`, `cta`, `tint`, `photo_id`) in place
 * of the two lines with a photo, and `description` (the text of «Sobre…», null for the
 * category's). Null: the category's own header.
 *
 * @since 0.18.0
 *
 * @param array<string, mixed>|null $header Header, null by default.
 * @param WP_Term                   $term   Category.
 */
$lachinata_header = $lachinata_is_cat ? apply_filters( 'lachinata/category/header', null, $lachinata_term ) : null;
$lachinata_header = is_array( $lachinata_header ) ? $lachinata_header : null;
if ( $lachinata_header && ! empty( $lachinata_header['title'] ) ) {
	$lachinata_title = (string) $lachinata_header['title'];
}
if ( $lachinata_header && ! empty( $lachinata_header['tint'] ) ) {
	$lachinata_tint = sanitize_key( (string) $lachinata_header['tint'] );
}
/**
 * Whether the listing says how many products it has («24 productos», «Cargar más (12 de
 * 24)»). False when the page is the same for every visitor and the browser may still hide
 * cards (locale with a cache that does not vary by destination).
 *
 * @since 0.11.0
 *
 * @param bool $show Show the counts.
 */
$lachinata_counts = (bool) apply_filters( 'lachinata/catalog/show_count', true );
/* translators: %s: number of products. */
$lachinata_count_text = $lachinata_counts ? sprintf( _n( '%s producto', '%s productos', $lachinata_total, 'lachinata' ), number_format_i18n( $lachinata_total ) ) : '';
?>
<?php lachinata_part( 'breadcrumb', array( 'class' => 'lc-container' ) ); ?>

<header class="lc-cat-head"<?php echo $lachinata_tint ? ' style="background: var(--tint-' . esc_attr( $lachinata_tint ) . ')"' : ''; ?>>
	<div class="lc-container lc-cat-head__inner">
		<?php
		lachinata_part(
			'section-header',
			array(
				'title'   => $lachinata_title,
				'as'      => 'h1',
				'eyebrow' => (string) ( $lachinata_header['eyebrow'] ?? '' ),
				'text'    => '' !== (string) ( $lachinata_header['text'] ?? '' ) ? (string) $lachinata_header['text'] : $lachinata_count_text,
			)
		);
		if ( ! $lachinata_header && $lachinata_is_cat ) {
			// Two lines with a photo for the desktop header (term meta query on a handful of terms).
			$lachinata_lines = get_terms(
				array(
					'taxonomy'   => 'product_cat',
					'parent'     => $lachinata_term->term_id,
					'hide_empty' => true,
					'orderby'    => 'menu_order',
					'meta_key'   => 'thumbnail_id', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
					'number'     => 2,
				)
			);
			$lachinata_lines = is_array( $lachinata_lines ) ? $lachinata_lines : array();
			if ( $lachinata_lines ) {
				echo '<div class="lc-cat-head__tiles">';
				foreach ( $lachinata_lines as $lachinata_line ) {
					lachinata_part(
						'category-tile',
						array(
							'title'    => $lachinata_line->name,
							'href'     => lachinata_term_url( $lachinata_line ),
							'photo_id' => (int) get_term_meta( $lachinata_line->term_id, 'thumbnail_id', true ),
						)
					);
				}
				echo '</div>';
			}
		}
		?>
	</div>
</header>

<?php
if ( $lachinata_header && ! empty( $lachinata_header['chips'] ) ) {
	echo '<div class="lc-chiprow lc-container" role="group" aria-label="' . esc_attr__( 'Tipos', 'lachinata' ) . '">';
	foreach ( (array) $lachinata_header['chips'] as $lachinata_chip ) {
		echo lachinata_chip(
			(string) $lachinata_chip['label'],
			array(
				'href'     => (string) $lachinata_chip['href'],
				'selected' => ! empty( $lachinata_chip['selected'] ),
			)
		);
	}
	echo '</div>';
} elseif ( $lachinata_root ) {
	$lachinata_subs = get_terms(
		array(
			'taxonomy'   => 'product_cat',
			'parent'     => $lachinata_root->term_id,
			'hide_empty' => true,
			'orderby'    => 'menu_order',
		)
	);
	if ( is_array( $lachinata_subs ) && $lachinata_subs ) {
		echo '<div class="lc-chiprow lc-container" role="group" aria-label="' . esc_attr__( 'Líneas', 'lachinata' ) . '">';
		echo lachinata_chip(
			__( 'Todo', 'lachinata' ),
			array(
				'href'     => lachinata_term_url( $lachinata_root ),
				'selected' => $lachinata_root->term_id === $lachinata_term->term_id,
			)
		);
		foreach ( $lachinata_subs as $lachinata_sub ) {
			echo lachinata_chip(
				$lachinata_sub->name,
				array(
					'href'     => lachinata_term_url( $lachinata_sub ),
					'selected' => $lachinata_sub->term_id === $lachinata_term->term_id || term_is_ancestor_of( $lachinata_sub, $lachinata_term, 'product_cat' ),
				)
			);
		}
		echo '</div>';
	}
}
if ( $lachinata_header && ! empty( $lachinata_header['entries'] ) ) {
	echo '<div class="lc-entries lc-container">';
	foreach ( (array) $lachinata_header['entries'] as $lachinata_entry ) {
		lachinata_part( 'category-tile', (array) $lachinata_entry );
	}
	echo '</div>';
}
?>

<div class="lc-container lc-catalog">
	<aside class="lc-catalog__filters" aria-labelledby="lc-filters-title">
		<h2 class="h4" id="lc-filters-title"><?php esc_html_e( 'Filtrar', 'lachinata' ); ?></h2>
		<?php
		lachinata_part(
			'catalog-filters',
			array(
				'filters' => $lachinata_filters,
				'context' => 'panel',
			)
		);
		?>
	</aside>

	<div class="lc-catalog__main">
		<div class="lc-chiprow lc-catalog__controls" role="group" aria-label="<?php esc_attr_e( 'Filtros y orden', 'lachinata' ); ?>">
			<?php
			if ( $lachinata_filters ) {
				echo lachinata_chip(
					__( 'Filtrar', 'lachinata' ),
					array(
						'icon'  => 'filter',
						'class' => 'lc-catalog__filter-chip',
						'attrs' => array(
							'data-lc-open'  => 'filters',
							'aria-haspopup' => 'dialog',
							'aria-pressed'  => null,
						),
					)
				);
			}
			$lachinata_options = lachinata_catalog_orderby_options();
			$lachinata_current = lachinata_catalog_current_orderby();
			if ( $lachinata_options ) {
				echo lachinata_chip(
					/* translators: %s: current sort order. */
					sprintf( __( 'Ordenar: %s', 'lachinata' ), mb_strtolower( (string) ( $lachinata_options[ $lachinata_current ] ?? reset( $lachinata_options ) ) ) ),
					array(
						'icon'  => 'chevron-down',
						'attrs' => array(
							'data-lc-open'  => 'sort',
							'aria-haspopup' => 'dialog',
							'aria-pressed'  => null,
						),
					)
				);
			}
			foreach ( $lachinata_applied as [ $lachinata_label, $lachinata_url ] ) {
				printf(
					'<a class="lc-chip label lc-chip--on" href="%1$s" aria-label="%2$s">%3$s%4$s</a>',
					esc_url( $lachinata_url ),
					/* translators: %s: filter name. */
					esc_attr( sprintf( __( 'Quitar filtro %s', 'lachinata' ), $lachinata_label ) ),
					esc_html( $lachinata_label ),
					lachinata_icon( 'close', array( 'size' => 'sm' ) )
				);
			}
			?>
		</div>

		<?php wc_print_notices(); ?>

		<?php if ( woocommerce_product_loop() && have_posts() ) : ?>
			<?php $lachinata_wide = is_search() && $lachinata_total <= 3; ?>
			<div class="<?php echo esc_attr( lachinata_cx( 'lc-grid', 'lc-catalog__grid', $lachinata_wide ? 'lc-grid--wide' : '' ) ); ?>" data-lc-grid>
				<?php
				$lachinata_index = 0;
				$lachinata_term  = get_queried_object();
				$lachinata_list  = is_search()
					? array(
						'id'   => 'search',
						'name' => __( 'Búsqueda', 'lachinata' ),
					)
					: array(
						'id'   => $lachinata_term instanceof WP_Term ? $lachinata_term->taxonomy . '_' . $lachinata_term->term_id : 'shop',
						'name' => $lachinata_term instanceof WP_Term ? $lachinata_term->name : __( 'Tienda', 'lachinata' ),
					);
				$lachinata_first = ( max( 1, (int) get_query_var( 'paged' ) ) - 1 ) * (int) get_query_var( 'posts_per_page' );
				while ( have_posts() ) {
					the_post();
					$lachinata_product = wc_get_product( get_the_ID() );
					if ( $lachinata_product ) {
						lachinata_part(
							'product-card',
							array(
								'product' => $lachinata_product,
								'layout'  => $lachinata_wide ? 'wide' : 'compact',
								'eager'   => $lachinata_index < 2 && ! is_paged(),
								'tint'    => $lachinata_header && ! empty( $lachinata_header['tint'] ) ? $lachinata_tint : ( $lachinata_root ? lachinata_category_tint( $lachinata_root ) : '' ),
								'list'    => $lachinata_list + array( 'index' => $lachinata_first + $lachinata_index + 1 ),
							)
						);
					}
					++$lachinata_index;
				}
				?>
			</div>
			<?php
			$lachinata_next = get_next_posts_page_link();
			if ( $lachinata_next && $GLOBALS['wp_query']->max_num_pages > max( 1, (int) get_query_var( 'paged' ) ) ) :
				?>
				<div class="lc-catalog__more">
					<?php
					echo lachinata_button(
						$lachinata_counts
							/* translators: 1: products shown, 2: total products. */
							? sprintf( __( 'Cargar más (%1$s de %2$s)', 'lachinata' ), number_format_i18n( $lachinata_shown ), number_format_i18n( $lachinata_total ) )
							: __( 'Cargar más', 'lachinata' ),
						array(
							'variant' => 'secondary',
							'href'    => $lachinata_next,
							'attrs'   => array(
								'data-lc-more'  => '',
								'data-lc-total' => $lachinata_counts ? $lachinata_total : null,
							),
						)
					);
					?>
				</div>
			<?php endif; ?>
		<?php else : ?>
			<?php echo lachinata_notice( esc_html__( 'No hay productos que coincidan. Quita algún filtro o prueba con otra búsqueda.', 'lachinata' ), 'neutral', 'lc-catalog__empty' ); ?>
		<?php endif; ?>
	</div>
</div>

<?php $lachinata_about = $lachinata_header && null !== ( $lachinata_header['description'] ?? null ) ? (string) $lachinata_header['description'] : ( $lachinata_term instanceof WP_Term ? (string) $lachinata_term->description : '' ); ?>
<?php if ( $lachinata_term instanceof WP_Term && '' !== trim( $lachinata_about ) ) : ?>
	<div class="lc-container lc-cat-seo">
		<div class="lc-acc">
			<div class="lc-acc__item">
				<button type="button" class="lc-acc__btn h4" aria-expanded="false" aria-controls="lc-cat-about" data-lc-toggle>
					<?php
					/* translators: %s: category name. */
					echo esc_html( sprintf( __( 'Sobre %s', 'lachinata' ), $lachinata_header ? $lachinata_title : $lachinata_term->name ) );
					?>
					<?php echo lachinata_icon( 'chevron-down' ); ?>
				</button>
				<div class="lc-acc__panel body-sm" id="lc-cat-about" hidden><?php echo wp_kses_post( wpautop( $lachinata_about ) ); ?></div>
			</div>
		</div>
	</div>
<?php endif; ?>

<?php if ( $lachinata_filters ) : ?>
	<div class="lc-layer lc-layer--sheet" data-lc-layer="filters" hidden>
		<div class="lc-layer__overlay" data-lc-close></div>
		<div class="lc-sheet" role="dialog" aria-modal="true" aria-labelledby="lc-sheet-filters" tabindex="-1">
			<div class="lc-sheet__grab" aria-hidden="true"></div>
			<div class="lc-sheet__head">
				<h2 class="h3" id="lc-sheet-filters" style="margin: 0"><?php esc_html_e( 'Filtrar', 'lachinata' ); ?></h2>
				<?php echo lachinata_icon_button( 'close', __( 'Cerrar', 'lachinata' ), array( 'attrs' => array( 'data-lc-close' => '' ) ) ); ?>
			</div>
			<?php
			lachinata_part(
				'catalog-filters',
				array(
					'filters' => $lachinata_filters,
					'context' => 'sheet',
				)
			);
			?>
		</div>
	</div>
<?php endif; ?>

<?php if ( ! empty( $lachinata_options ) ) : ?>
	<div class="lc-layer lc-layer--sheet" data-lc-layer="sort" hidden>
		<div class="lc-layer__overlay" data-lc-close></div>
		<div class="lc-sheet" role="dialog" aria-modal="true" aria-labelledby="lc-sheet-sort" tabindex="-1">
			<div class="lc-sheet__grab" aria-hidden="true"></div>
			<div class="lc-sheet__head">
				<h2 class="h3" id="lc-sheet-sort" style="margin: 0"><?php esc_html_e( 'Ordenar', 'lachinata' ); ?></h2>
				<?php echo lachinata_icon_button( 'close', __( 'Cerrar', 'lachinata' ), array( 'attrs' => array( 'data-lc-close' => '' ) ) ); ?>
			</div>
			<form method="get" class="lc-sheet__body">
				<fieldset class="lc-sheet__group">
					<legend class="screen-reader-text"><?php esc_html_e( 'Ordenar por', 'lachinata' ); ?></legend>
					<?php foreach ( $lachinata_options as $lachinata_value => $lachinata_label ) : ?>
						<label class="<?php echo esc_attr( lachinata_cx( 'lc-opt', $lachinata_value === $lachinata_current ? 'lc-opt--on' : '' ) ); ?>">
							<input type="radio" name="orderby" value="<?php echo esc_attr( (string) $lachinata_value ); ?>"<?php checked( $lachinata_value, $lachinata_current ); ?> data-lc-autosubmit>
							<span class="lc-opt__radio" aria-hidden="true"></span>
							<span class="lc-opt__body"><span class="label"><?php echo esc_html( (string) $lachinata_label ); ?></span></span>
						</label>
					<?php endforeach; ?>
				</fieldset>
				<?php wc_query_string_form_fields( null, array( 'orderby', 'submit', 'paged', 'product-page' ) ); ?>
				<noscript>
				<?php
				echo lachinata_button(
					__( 'Ordenar', 'lachinata' ),
					array(
						'type'  => 'submit',
						'block' => true,
					)
				); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped 
				?>
							</noscript>
			</form>
		</div>
	</div>
<?php endif; ?>
<?php
get_footer();
