<?php
/**
 * Cases of 6 in the bag.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * The case discount is a discount per line, never a change of the product's price, so the
 * product page, the bag, the checkout, the order, Odoo and the feeds see the same thing. It
 * travels as a virtual coupon («Descuento por caja», code CODE) that nobody types or
 * removes: the module adds it while the bag has a case and takes it away when not.
 *
 * It does not count as a customer's coupon: neither in the comparison nor in the rule of
 * individual use. With a customer's coupon that discounts products, by default the bag
 * keeps whichever leaves the lower total and says so in a notice; coupons of free shipping
 * always add up.
 */
final class Cart {

	/**
	 * Code of the virtual coupon (it shows only in the order screen of the panel).
	 */
	public const CODE = 'descuento-por-caja';

	/**
	 * Discount type of the virtual coupon.
	 */
	public const TYPE = 'lc_bodega_case';

	/**
	 * Session keys: the cases last seen (for `lc_case_complete`) and the coupons that won.
	 */
	private const SESSION_CASES  = 'lc_bodega_cases';
	private const SESSION_WINNER = 'lc_bodega_coupon_wins';

	/**
	 * Plan of the current bag, by cart hash.
	 *
	 * @var array<string, array<string, mixed>>
	 */
	private static array $plans = array();

	/**
	 * Whether the case is set aside because a coupon is better (this request).
	 *
	 * @var bool
	 */
	private static bool $suppressed = false;

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'woocommerce_coupon_discount_types', array( self::class, 'discount_types' ) );
		Hooks::add_filter( 'woocommerce_cart_coupon_types', array( self::class, 'cart_types' ) );
		Hooks::add_filter( 'woocommerce_get_shop_coupon_data', array( self::class, 'coupon_data' ), 10, 2 );
		Hooks::add_filter( 'woocommerce_coupon_get_discount_amount', array( self::class, 'discount_amount' ), 10, 5 );
		Hooks::add_action( 'woocommerce_before_calculate_totals', array( self::class, 'before_totals' ), 20 );
		Hooks::add_action( 'woocommerce_after_calculate_totals', array( self::class, 'after_totals' ), 20 );
		Hooks::add_filter( 'woocommerce_apply_individual_use_coupon', array( self::class, 'keep_with_individual' ), 10, 2 );
		Hooks::add_filter( 'woocommerce_apply_with_individual_use_coupon', array( self::class, 'apply_with_individual' ), 10, 2 );
		Hooks::add_filter( 'woocommerce_cart_totals_coupon_label', array( self::class, 'label' ), 10, 2 );
		Hooks::add_filter( 'lachinata/cart/coupon', array( self::class, 'theme_coupon' ), 10, 2 );
		Hooks::add_filter( 'lachinata/cart/line_note', array( self::class, 'line_note' ), 20, 2 );
		Hooks::add_filter( 'lachinata/cart/case_progress', array( self::class, 'progress' ) );
		Hooks::add_filter( 'lachinata/cart/age_notice', array( self::class, 'age_notice' ) );
		Hooks::add_filter( 'woocommerce_add_to_cart_quantity', array( self::class, 'case_quantity' ), 10, 2 );
	}

	/**
	 * «Caja de 6» chosen on the product page without JavaScript: the quantity goes up to
	 * the next whole case.
	 *
	 * @param mixed $quantity   Quantity.
	 * @param mixed $product_id Product.
	 * @return mixed
	 */
	public static function case_quantity( $quantity, $product_id ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Adding to the bag, like WooCommerce's own form.
		if ( 'case' !== ( isset( $_POST['lc_case'] ) ? sanitize_key( wp_unslash( $_POST['lc_case'] ) ) : '' ) || ! is_numeric( $quantity ) ) {
			return $quantity;
		}
		$product = wc_get_product( absint( $product_id ) );
		if ( ! $product instanceof \WC_Product || ! Fields::counts_for_case( $product ) ) {
			return $quantity;
		}
		$size = Config::CASE_SIZE;
		return max( $size, (int) ceil( (float) $quantity / $size ) * $size );
	}

	/**
	 * Name of the discount type, for the panel.
	 *
	 * @param mixed $types Types.
	 * @return mixed
	 */
	public static function discount_types( $types ) {
		if ( is_array( $types ) ) {
			$types[ self::TYPE ] = __( 'Descuento por caja', 'lachinata-core' );
		}
		return $types;
	}

	/**
	 * The type is a cart discount (WooCommerce applies it to every line; the plan says how
	 * much to each one).
	 *
	 * @param mixed $types Types.
	 * @return mixed
	 */
	public static function cart_types( $types ) {
		if ( is_array( $types ) && ! in_array( self::TYPE, $types, true ) ) {
			$types[] = self::TYPE;
		}
		return $types;
	}

	/**
	 * The virtual coupon.
	 *
	 * @param mixed  $data Coupon data.
	 * @param string $code Code.
	 * @return mixed
	 */
	public static function coupon_data( $data, $code ) {
		if ( self::CODE !== wc_format_coupon_code( (string) $code ) ) {
			return $data;
		}
		return array(
			'code'           => self::CODE,
			'discount_type'  => self::TYPE,
			'amount'         => 1,
			'individual_use' => false,
			'usage_limit'    => 0,
			'free_shipping'  => false,
		);
	}

	/**
	 * Discount of one bottle of a line: what the plan gives the line, per unit.
	 *
	 * @param mixed $discount           Discount WooCommerce calculated.
	 * @param mixed $discounting_amount Price of one unit.
	 * @param mixed $item               Cart item (array) or order item.
	 * @param mixed $single             Whether it is for one unit.
	 * @param mixed $coupon             Coupon.
	 * @return mixed
	 */
	public static function discount_amount( $discount, $discounting_amount, $item, $single, $coupon ) {
		if ( ! $coupon instanceof \WC_Coupon || self::CODE !== $coupon->get_code() ) {
			return $discount;
		}
		unset( $single );
		$plan = null;
		$key  = '';
		$qty  = 0;
		if ( is_array( $item ) && isset( $item['key'] ) && WC()->cart ) {
			$plan = self::plan( WC()->cart );
			$key  = (string) $item['key'];
			$qty  = (int) $item['quantity'];
		} elseif ( $item instanceof \WC_Order_Item_Product ) {
			$order = $item->get_order();
			$plan  = $order instanceof \WC_Order ? self::order_plan( $order ) : null;
			$key   = (string) $item->get_id();
			$qty   = (int) $item->get_quantity();
		}
		if ( null === $plan || $qty < 1 || empty( $plan['lines'][ $key ]['discount'] ) ) {
			return 0;
		}
		return min( (float) $discounting_amount, (float) $plan['lines'][ $key ]['discount'] / $qty );
	}

	/**
	 * The cases of a bag: the calculation with the bag's lines and the settings.
	 *
	 * @param \WC_Cart $cart Cart.
	 * @return array{lines: array<string, array{same: int, mixed: int, discount: float}>, same_cases: int, mixed_cases: int, counting: int, loose: int, discount: float}
	 */
	public static function plan( \WC_Cart $cart ): array {
		$lines = array();
		foreach ( $cart->get_cart() as $key => $item ) {
			$product = $item['data'] ?? null;
			if ( ! $product instanceof \WC_Product ) {
				continue;
			}
			$lines[] = array(
				'key'     => (string) $key,
				'group'   => (string) ( $product->get_id() ),
				'qty'     => (int) $item['quantity'],
				'price'   => (float) $product->get_price(),
				'regular' => (float) ( '' !== $product->get_regular_price() ? $product->get_regular_price() : $product->get_price() ),
				'counts'  => Fields::counts_for_case( $product ),
			);
		}
		$hash = md5( (string) wp_json_encode( $lines ) . self::settings_hash() );
		if ( ! isset( self::$plans[ $hash ] ) ) {
			self::$plans[ $hash ] = Cases::calculate( $lines, Config::same_discount(), Config::mixed_discount(), Config::stack_sale() );
		}
		return self::$plans[ $hash ];
	}

	/**
	 * The cases of an order, when the panel recalculates it with the coupon on it: the
	 * prices of its lines, without the sale rule (the regular price is not in the order).
	 *
	 * @param \WC_Order $order Order.
	 * @return array<string, mixed>
	 */
	public static function order_plan( \WC_Order $order ): array {
		$lines = array();
		foreach ( $order->get_items() as $item ) {
			if ( ! $item instanceof \WC_Order_Item_Product ) {
				continue;
			}
			$product = $item->get_product();
			$qty     = max( 1, (int) $item->get_quantity() );
			$price   = (float) $item->get_subtotal() / $qty;
			$lines[] = array(
				'key'     => (string) $item->get_id(),
				'group'   => (string) ( $item->get_variation_id() ? $item->get_variation_id() : $item->get_product_id() ),
				'qty'     => (int) $item->get_quantity(),
				'price'   => $price,
				'regular' => $price,
				'counts'  => $product instanceof \WC_Product && Fields::counts_for_case( $product ),
			);
		}
		return Cases::calculate( $lines, Config::same_discount(), Config::mixed_discount(), true );
	}

	/**
	 * Settings that change the plan.
	 */
	private static function settings_hash(): string {
		return Config::same_discount() . '|' . Config::mixed_discount() . '|' . ( Config::stack_sale() ? 1 : 0 );
	}

	/**
	 * Before the totals: decides between the case and the customer's coupons and puts the
	 * virtual coupon on the bag or takes it away.
	 *
	 * @param mixed $cart Cart.
	 */
	public static function before_totals( $cart ): void {
		if ( ! $cart instanceof \WC_Cart ) {
			return;
		}
		self::$suppressed = false;
		$plan             = self::plan( $cart );
		$has_case         = $plan['discount'] > 0;
		$customer         = array_values( array_diff( $cart->get_applied_coupons(), array( self::CODE ) ) );

		if ( $has_case && $customer && ! Config::stack_coupons() ) {
			$competing = self::coupon_discounts( $cart, $customer );
			$coupons   = array_sum( $competing );
			if ( $coupons > 0 ) {
				if ( $plan['discount'] >= $coupons ) {
					foreach ( array_keys( array_filter( $competing ) ) as $code ) {
						$cart->remove_coupon( (string) $code );
					}
					self::notice( __( 'Tu caja ya tiene un descuento mayor que el cupón, así que no lo hemos aplicado.', 'lachinata-core' ) );
					self::remember_winner( '' );
				} else {
					self::$suppressed = true;
					$winner           = implode( ',', array_keys( array_filter( $competing ) ) );
					if ( self::remember_winner( $winner ) ) {
						self::notice( __( 'Hemos aplicado tu cupón, que es mejor que el descuento por caja.', 'lachinata-core' ) );
					}
				}
			}
		} elseif ( ! $customer ) {
			self::remember_winner( '' );
		}

		$applied = $cart->get_applied_coupons();
		$on      = in_array( self::CODE, $applied, true );
		if ( $has_case && ! self::$suppressed && ! $on ) {
			$applied[] = self::CODE;
			$cart->set_applied_coupons( $applied );
		} elseif ( ( ! $has_case || self::$suppressed ) && $on ) {
			$cart->set_applied_coupons( array_values( array_diff( $applied, array( self::CODE ) ) ) );
		}
	}

	/**
	 * What each customer's coupon discounts on the products of the bag, by code (0 for a
	 * coupon of free shipping only or one that does not apply).
	 *
	 * @param \WC_Cart $cart  Cart.
	 * @param string[] $codes Codes.
	 * @return array<string, float>
	 */
	public static function coupon_discounts( \WC_Cart $cart, array $codes ): array {
		$amounts   = array();
		$discounts = new \WC_Discounts( $cart );
		foreach ( $codes as $code ) {
			$coupon           = new \WC_Coupon( $code );
			$result           = $discounts->apply_coupon( $coupon, false );
			$amounts[ $code ] = 0.0;
			if ( true === $result ) {
				$by_coupon        = $discounts->get_discounts_by_coupon();
				$amounts[ $code ] = (float) ( $by_coupon[ $coupon->get_code() ] ?? 0 );
			}
		}
		return $amounts;
	}

	/**
	 * Remembers which coupons won (empty: none). True when it changed.
	 *
	 * @param string $winner Codes.
	 */
	private static function remember_winner( string $winner ): bool {
		if ( ! function_exists( 'WC' ) || ! WC()->session ) {
			return '' !== $winner;
		}
		$before = (string) WC()->session->get( self::SESSION_WINNER, '' );
		if ( $before === $winner ) {
			return false;
		}
		WC()->session->set( self::SESSION_WINNER, $winner );
		return '' !== $winner;
	}

	/**
	 * Adds an information notice once.
	 *
	 * @param string $text Text.
	 */
	private static function notice( string $text ): void {
		if ( function_exists( 'wc_add_notice' ) && ! wc_has_notice( $text, 'notice' ) ) {
			wc_add_notice( $text, 'notice' );
		}
	}

	/**
	 * After the totals: a case that has just been completed is measured (`lc_case_complete`).
	 *
	 * @param mixed $cart Cart.
	 */
	public static function after_totals( $cart ): void {
		if ( ! $cart instanceof \WC_Cart || ! WC()->session ) {
			return;
		}
		$plan   = self::plan( $cart );
		$before = (array) WC()->session->get( self::SESSION_CASES, array() );
		$now    = array(
			'same'  => self::$suppressed ? 0 : $plan['same_cases'],
			'mixed' => self::$suppressed ? 0 : $plan['mixed_cases'],
		);
		if ( $now !== $before ) {
			WC()->session->set( self::SESSION_CASES, $now );
		}
		foreach ( $now as $kind => $count ) {
			if ( $count > (int) ( $before[ $kind ] ?? 0 ) ) {
				/**
				 * A measurement event for the next page (core of tracking, plugin/HOOKS.md).
				 *
				 * @since 0.18.0
				 *
				 * @param string               $name   Event.
				 * @param array<string, mixed> $params Parameters.
				 */
				do_action(
					'lachinata/tracking/event',
					'lc_case_complete',
					array(
						'case_type' => $kind,
						'cases'     => $count,
					)
				); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingSinceComment -- Hook of the core, documented in plugin/HOOKS.md.
			}
		}
	}

	/**
	 * A customer's coupon of individual use does not take the case away.
	 *
	 * @param mixed $keep   Coupons that stay.
	 * @param mixed $coupon Coupon of individual use.
	 * @return mixed
	 */
	public static function keep_with_individual( $keep, $coupon ) {
		unset( $coupon );
		if ( is_array( $keep ) && WC()->cart && in_array( self::CODE, WC()->cart->get_applied_coupons(), true ) ) {
			$keep[] = self::CODE;
		}
		return $keep;
	}

	/**
	 * The case may go with a customer's coupon of individual use.
	 *
	 * @param mixed $apply  Whether it applies.
	 * @param mixed $coupon Coupon being applied.
	 * @return mixed
	 */
	public static function apply_with_individual( $apply, $coupon ) {
		return $coupon instanceof \WC_Coupon && self::CODE === $coupon->get_code() ? true : $apply;
	}

	/**
	 * Label of the coupon in WooCommerce's summaries.
	 *
	 * @param mixed $label  Label.
	 * @param mixed $coupon Coupon.
	 * @return mixed
	 */
	public static function label( $label, $coupon ) {
		return $coupon instanceof \WC_Coupon && self::CODE === $coupon->get_code() ? __( 'Descuento por caja', 'lachinata-core' ) : $label;
	}

	/**
	 * The coupon line of the theme's bag: its own label and no «Quitar».
	 *
	 * @param mixed $line Line (`label`, `removable`).
	 * @param mixed $code Code.
	 * @return mixed
	 */
	public static function theme_coupon( $line, $code ) {
		if ( self::CODE !== (string) $code || ! is_array( $line ) ) {
			return $line;
		}
		$line['label']     = __( 'Descuento por caja', 'lachinata-core' );
		$line['removable'] = false;
		return $line;
	}

	/**
	 * Note of a line in a case: «Caja de 6 iguales · −10 %».
	 *
	 * @param mixed $note Note.
	 * @param mixed $item Cart item.
	 * @return mixed
	 */
	public static function line_note( $note, $item ) {
		if ( '' !== (string) $note || ! is_array( $item ) || ! isset( $item['key'] ) || ! WC()->cart || self::$suppressed || ! in_array( self::CODE, WC()->cart->get_applied_coupons(), true ) ) {
			return $note;
		}
		$row = self::plan( WC()->cart )['lines'][ (string) $item['key'] ] ?? null;
		if ( null === $row ) {
			return $note;
		}
		$parts = array();
		if ( $row['same'] ) {
			/* translators: 1: bottles in a case, 2: discount (10). */
			$parts[] = sprintf( __( 'Caja de %1$s iguales · −%2$s %%', 'lachinata-core' ), number_format_i18n( Config::CASE_SIZE ), number_format_i18n( Config::same_discount() ) );
		}
		if ( $row['mixed'] ) {
			/* translators: 1: bottles in a case, 2: discount (5). */
			$parts[] = sprintf( __( 'Caja de %1$s variada · −%2$s %%', 'lachinata-core' ), number_format_i18n( Config::CASE_SIZE ), number_format_i18n( Config::mixed_discount() ) );
		}
		return implode( ' · ', $parts );
	}

	/**
	 * Data of CaseProgress for the bag (sheet and page), or null when no bottle counts.
	 *
	 * @param mixed $progress Progress of other sources.
	 * @return mixed
	 */
	public static function progress( $progress ) {
		if ( null !== $progress || ! WC()->cart ) {
			return $progress;
		}
		$plan = self::plan( WC()->cart );
		if ( $plan['counting'] < 1 || self::$suppressed ) {
			return $progress;
		}
		$same = 0 === $plan['loose'] && $plan['same_cases'] > 0;
		return array(
			'count'    => $same ? $plan['same_cases'] * Config::CASE_SIZE : $plan['loose'],
			'size'     => Config::CASE_SIZE,
			'discount' => $same ? Config::same_discount() : Config::mixed_discount(),
			'href'     => Listing::url(),
			'cta'      => __( 'Ver vinos', 'lachinata-core' ),
		);
	}

	/**
	 * The age notice of the bag, when it holds a product with alcohol.
	 *
	 * @param mixed $notice Notice of other sources.
	 * @return mixed
	 */
	public static function age_notice( $notice ) {
		if ( '' !== (string) $notice || ! WC()->cart || ! self::has_alcohol( WC()->cart ) ) {
			return $notice;
		}
		return Config::text( 'age' );
	}

	/**
	 * Whether a bag holds a product with alcohol.
	 *
	 * @param \WC_Cart $cart Cart.
	 */
	public static function has_alcohol( \WC_Cart $cart ): bool {
		foreach ( $cart->get_cart() as $item ) {
			$product = $item['data'] ?? null;
			if ( $product instanceof \WC_Product && Fields::has_alcohol( $product ) ) {
				return true;
			}
		}
		return false;
	}
}
