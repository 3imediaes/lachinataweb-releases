<?php
/**
 * Cases of 6: the calculation.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

defined( 'ABSPATH' ) || exit;

/**
 * 10-bodega.md, «Cajas de 6», without WooCommerce: given the lines of the bag, which bottles
 * go in a case and how much each line saves.
 *
 * - First the cases of the same wine (same vintage and format: the same variation): every 6
 *   bottles of a line, one case at the «same» discount. It repeats: 12 are two cases.
 * - With what is left of every line, mixed cases at the «mixed» discount. When the leftover
 *   is not a multiple of 6, the bottles that save the most go in the case (on a tie, the
 *   first line of the bag); the rest pay the normal price.
 * - Only the lines that count for the case take part.
 * - With a sale price, by default the larger of the two discounts and never both: the bottle
 *   costs the lower of the sale price and the regular price minus the case discount.
 *   Stacking (a setting) applies the case discount on the sale price.
 *
 * Prices may come with or without tax: the discount keeps the same basis.
 */
final class Cases {

	/**
	 * Calculates the cases of a bag.
	 *
	 * @param array<int, array{key: string, group: string, qty: int, price: float, regular: float, counts: bool}> $lines Lines, in the order of the bag.
	 * @param float                                                                                               $same  Discount of a case of the same wine, %.
	 * @param float                                                                                               $mixed_pct Discount of a mixed case, %.
	 * @param bool                                                                                                $stack Whether it adds to a sale price.
	 * @param int                                                                                                 $size  Bottles in a case.
	 * @return array{lines: array<string, array{same: int, mixed: int, discount: float}>, same_cases: int, mixed_cases: int, counting: int, loose: int, discount: float}
	 */
	public static function calculate( array $lines, float $same, float $mixed_pct, bool $stack = false, int $size = Config::CASE_SIZE ): array {
		$result = array(
			'lines'       => array(),
			'same_cases'  => 0,
			'mixed_cases' => 0,
			'counting'    => 0,
			'loose'       => 0,
			'discount'    => 0.0,
		);
		if ( $size < 1 ) {
			return $result;
		}

		// Lines of the same wine add up (the same variation in two lines of the bag).
		$groups = array();
		foreach ( $lines as $order => $line ) {
			$result['lines'][ $line['key'] ] = array(
				'same'     => 0,
				'mixed'    => 0,
				'discount' => 0.0,
			);
			if ( ! $line['counts'] || $line['qty'] < 1 ) {
				continue;
			}
			$result['counting']                += $line['qty'];
			$groups[ $line['group'] ][ $order ] = $line;
		}

		$leftover = array();
		foreach ( $groups as $group ) {
			$total                 = array_sum( array_column( $group, 'qty' ) );
			$boxed                 = intdiv( $total, $size ) * $size;
			$result['same_cases'] += intdiv( $total, $size );
			foreach ( $group as $order => $line ) {
				$take                                    = min( $line['qty'], $boxed );
				$boxed                                  -= $take;
				$result['lines'][ $line['key'] ]['same'] = $take;
				$rest                                    = $line['qty'] - $take;
				for ( $i = 0; $i < $rest; $i++ ) {
					$leftover[] = array(
						'key'   => $line['key'],
						'order' => $order,
						'save'  => self::saving( $line['price'], $line['regular'], $mixed_pct, $stack ),
					);
				}
			}
		}

		$result['loose']       = count( $leftover );
		$mixed_units           = intdiv( count( $leftover ), $size ) * $size;
		$result['mixed_cases'] = intdiv( count( $leftover ), $size );
		usort( $leftover, static fn( array $a, array $b ): int => 0 !== ( $b['save'] <=> $a['save'] ) ? $b['save'] <=> $a['save'] : $a['order'] <=> $b['order'] );
		foreach ( array_slice( $leftover, 0, $mixed_units ) as $unit ) {
			++$result['lines'][ $unit['key'] ]['mixed'];
		}

		foreach ( $lines as $line ) {
			$row = $result['lines'][ $line['key'] ];
			if ( ! $row['same'] && ! $row['mixed'] ) {
				continue;
			}
			$discount                                    = $row['same'] * self::saving( $line['price'], $line['regular'], $same, $stack )
				+ $row['mixed'] * self::saving( $line['price'], $line['regular'], $mixed_pct, $stack );
			$result['lines'][ $line['key'] ]['discount'] = $discount;
			$result['discount']                         += $discount;
		}
		return $result;
	}

	/**
	 * What one bottle saves with a discount of $percent.
	 *
	 * @param float $price   Price it is sold at (the sale price when there is one).
	 * @param float $regular Regular price.
	 * @param float $percent Discount, %.
	 * @param bool  $stack   Whether it adds to the sale price.
	 */
	public static function saving( float $price, float $regular, float $percent, bool $stack ): float {
		if ( $price <= 0 || $percent <= 0 ) {
			return 0.0;
		}
		if ( $stack || $regular <= $price ) {
			return $price * $percent / 100;
		}
		return max( 0.0, $price - $regular * ( 100 - $percent ) / 100 );
	}
}
