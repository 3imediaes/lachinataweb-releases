<?php
/**
 * Age box and carrier note in the checkout.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * 10-bodega.md, «Avisos legales»: when the bag holds a product with «Contiene alcohol», the
 * checkout asks for «Confirmo que soy mayor de 18 años» (required) and keeps it in the
 * order. It is an additional field of the blocks checkout whose rules read the bag (the
 * Store API data `lachinata-bodega.alcohol`), so WooCommerce shows it, requires it and
 * validates it on the server only then. With the setting on, the order carries the note
 * for the carrier that Odoo reads.
 */
final class Checkout {

	/**
	 * Id of the field and namespace of the Store API data.
	 */
	public const FIELD     = 'lachinata-bodega/mayor-de-edad';
	public const NAMESPACE = 'lachinata-bodega';

	/**
	 * Order meta of the field (WooCommerce's) and of the note for the carrier.
	 */
	public const FIELD_META = '_wc_other/lachinata-bodega/mayor-de-edad';
	public const NOTE_META  = '_lc_bodega_nota_transportista';

	/**
	 * Script handle of the coupon label in the blocks checkout.
	 */
	public const SCRIPT = 'lachinata-bodega-checkout';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'woocommerce_init', array( self::class, 'register_field' ) );
		Hooks::add_action( 'init', array( self::class, 'register_data' ) );
		Hooks::add_action( 'woocommerce_store_api_checkout_order_processed', array( self::class, 'order_processed' ) );
		Hooks::add_action( 'wp_enqueue_scripts', array( self::class, 'enqueue' ), 20 );
	}

	/**
	 * The age box, only with alcohol in the bag.
	 */
	public static function register_field(): void {
		if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
			return;
		}
		$with    = array(
			'cart' => array(
				'properties' => array(
					'extensions' => array(
						'properties' => array(
							self::NAMESPACE => array(
								'properties' => array(
									'alcohol' => array( 'const' => true ),
								),
							),
						),
					),
				),
			),
		);
		$without = $with;
		$without['cart']['properties']['extensions']['properties'][ self::NAMESPACE ]['properties']['alcohol'] = array( 'const' => false );
		woocommerce_register_additional_checkout_field(
			array(
				'id'            => self::FIELD,
				'label'         => __( 'Confirmo que soy mayor de 18 años', 'lachinata-core' ),
				'optionalLabel' => __( 'Confirmo que soy mayor de 18 años', 'lachinata-core' ),
				'location'      => 'order',
				'type'          => 'checkbox',
				'required'      => $with,
				'hidden'        => $without,
				'error_message' => __( 'Para comprar vino tienes que confirmar que eres mayor de 18 años.', 'lachinata-core' ),
			)
		);
	}

	/**
	 * Whether the bag holds alcohol, in the Store API data of the cart.
	 */
	public static function register_data(): void {
		if ( ! function_exists( 'woocommerce_store_api_register_endpoint_data' ) ) {
			return;
		}
		woocommerce_store_api_register_endpoint_data(
			array(
				'endpoint'        => 'cart',
				'namespace'       => self::NAMESPACE,
				'data_callback'   => Hooks::wrap(
					static fn(): array => array(
						'alcohol' => WC()->cart instanceof \WC_Cart && Cart::has_alcohol( WC()->cart ),
						'case'    => WC()->cart instanceof \WC_Cart ? round( (float) Cart::plan( WC()->cart )['discount'], wc_get_price_decimals() ) : 0,
					),
					array(
						'alcohol' => false,
						'case'    => 0,
					)
				),
				'schema_callback' => static fn(): array => array(
					'alcohol' => array(
						'description' => 'Whether the bag holds a product with alcohol.',
						'type'        => 'boolean',
						'context'     => array( 'view', 'edit' ),
						'readonly'    => true,
					),
					'case'    => array(
						'description' => 'Case discount of the bag, before comparing with coupons.',
						'type'        => 'number',
						'context'     => array( 'view', 'edit' ),
						'readonly'    => true,
					),
				),
				'schema_type'     => ARRAY_A,
			)
		);
	}

	/**
	 * Keeps the note for the carrier in an order with alcohol, when the setting is on.
	 *
	 * @param mixed $order Order.
	 */
	public static function order_processed( $order ): void {
		if ( ! $order instanceof \WC_Order || ! Config::carrier_note() || ! self::order_has_alcohol( $order ) ) {
			return;
		}
		$order->update_meta_data( self::NOTE_META, Config::text( 'carrier_note' ) );
		$order->save();
	}

	/**
	 * Whether an order holds a product with alcohol.
	 *
	 * @param \WC_Order $order Order.
	 */
	public static function order_has_alcohol( \WC_Order $order ): bool {
		foreach ( $order->get_items() as $item ) {
			$product = $item instanceof \WC_Order_Item_Product ? $item->get_product() : null;
			if ( $product instanceof \WC_Product && Fields::has_alcohol( $product ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * The label «Descuento por caja» in the summary of the blocks checkout.
	 */
	public static function enqueue(): void {
		// Only the blocks checkout: the theme's bag and the thank-you page do not load it.
		if ( ! function_exists( 'is_checkout' ) || ! is_checkout() || is_order_received_page() || is_checkout_pay_page() || ! has_block( 'woocommerce/checkout' ) ) {
			return;
		}
		$file  = LACHINATA_CORE_DIR . '/modules/bodega/build/checkout.asset.php';
		$asset = is_readable( $file ) ? require $file : array(
			'dependencies' => array( 'wc-blocks-checkout', 'wp-i18n' ),
			'version'      => LACHINATA_CORE_VERSION,
		);
		$deps  = array_values( array_unique( array_merge( (array) $asset['dependencies'], wp_script_is( 'wc-blocks-checkout', 'registered' ) ? array( 'wc-blocks-checkout' ) : array() ) ) );
		wp_enqueue_script( self::SCRIPT, plugins_url( 'modules/bodega/build/checkout.js', LACHINATA_CORE_FILE ), $deps, (string) $asset['version'], true );
		wp_set_script_translations( self::SCRIPT, 'lachinata-core', LACHINATA_CORE_DIR . '/languages' );
		wp_add_inline_script( self::SCRIPT, 'window.lcBodegaCheckout = ' . wp_json_encode( array( 'code' => Cart::CODE ) ) . ';', 'before' );
	}
}
