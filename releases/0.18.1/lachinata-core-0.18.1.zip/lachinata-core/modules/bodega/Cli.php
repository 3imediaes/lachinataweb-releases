<?php
/**
 * WP-CLI commands of the Bodega.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

use LaChinata\Core\Cli\Output;

defined( 'ABSPATH' ) || exit;

/**
 * `wp lachinata bodega …`: the migration of the wines from their descriptions, the import
 * of scores and awards, the best score of each wine and the glossary of names.
 */
final class Cli {

	/**
	 * Moves the wines' data from their descriptions to the module's fields and turns the
	 * simple wines into variable ones (one variation per vintage and format).
	 *
	 * Reads the technical sheet of the description and the tasting of the short description;
	 * the scores of the text enter unpublished. Only fills what is empty, so it can run again
	 * (for instance after marketing fills «Para completar» in the Excel). The wines that are
	 * already variable keep their variations.
	 *
	 * ## OPTIONS
	 *
	 * [--dry-run]
	 * : Report only: what would be filled and which SKU goes to which variation.
	 *
	 * [--xlsx=<file>]
	 * : bodega-datos-vinos.xlsx: the sheet «Para completar» is imported and «Vinos» is the
	 * comparison.
	 *
	 * [--ids=<ids>]
	 * : Only these products (ids separated by commas).
	 *
	 * [--report=<file>]
	 * : Also writes the report as Markdown.
	 *
	 * [--force]
	 * : Write over the report if it already exists.
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata bodega migrate --dry-run --xlsx=bodega-datos-vinos.xlsx --report=informe-migracion-en-seco.md
	 *
	 * @param string[]             $args       Arguments.
	 * @param array<string, mixed> $assoc_args Options.
	 */
	public function migrate( array $args, array $assoc_args ): void {
		unset( $args );
		$report_file = (string) ( $assoc_args['report'] ?? '' );
		Output::check( $report_file, $assoc_args );
		if ( null === Config::category() && empty( $assoc_args['ids'] ) ) {
			\WP_CLI::error( __( 'Elige antes la categoría de la Bodega (WooCommerce → La Chinata → Bodega).', 'lachinata-core' ) );
		}
		$excel = array();
		if ( ! empty( $assoc_args['xlsx'] ) ) {
			try {
				$excel = Xlsx::read( (string) $assoc_args['xlsx'] );
			} catch ( \RuntimeException $error ) {
				\WP_CLI::error( $error->getMessage() );
			}
		}
		$ids    = ! empty( $assoc_args['ids'] ) ? array_map( 'absint', explode( ',', (string) $assoc_args['ids'] ) ) : array();
		$report = ( new Migrate( ! empty( $assoc_args['dry-run'] ), $excel, $ids ) )->run();
		if ( '' !== $report_file ) {
			Output::write( $report_file, Migrate::markdown( $report ), $assoc_args );
		}
		\WP_CLI::success(
			sprintf(
				/* translators: 1: wines read, 2: wines with new data, 3: wines turned variable, 4: unknown vintages, 5: unpublished scores, 6: errors. */
				__( '%1$d vinos leídos, %2$d con datos nuevos, %3$d pasan a variables (%4$d con la añada desconocida), %5$d puntuaciones del texto sin publicar, %6$d errores.', 'lachinata-core' ),
				$report['wines'],
				$report['filled'],
				count( $report['converted'] ),
				count( $report['unknown'] ),
				count( $report['scores'] ),
				count( $report['errors'] )
			)
		);
	}

	/**
	 * Imports scores and awards by vintage from bodega-puntuaciones.xlsx (or a CSV with the
	 * same columns). It can be repeated without duplicating.
	 *
	 * ## OPTIONS
	 *
	 * <file>
	 * : The .xlsx (sheets «Puntuaciones», «Premios» and «Listas») or a CSV.
	 *
	 * [--dry-run]
	 * : Report only.
	 *
	 * [--report=<file>]
	 * : Also writes the report as Markdown.
	 *
	 * [--force]
	 * : Write over the report if it already exists.
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata bodega import-scores bodega-puntuaciones.xlsx --dry-run
	 *
	 * @subcommand import-scores
	 *
	 * @param string[]             $args       Arguments.
	 * @param array<string, mixed> $assoc_args Options.
	 */
	public function import_scores( array $args, array $assoc_args ): void {
		$file        = (string) ( $args[0] ?? '' );
		$report_file = (string) ( $assoc_args['report'] ?? '' );
		Output::check( $report_file, $assoc_args );
		try {
			$report = ScoresImport::run( $file, ! empty( $assoc_args['dry-run'] ) );
		} catch ( \RuntimeException $error ) {
			\WP_CLI::error( $error->getMessage() );
		}
		if ( '' !== $report_file ) {
			Output::write( $report_file, ScoresImport::markdown( $report ), $assoc_args );
		}
		foreach ( $report['skipped'] as $row ) {
			\WP_CLI::warning( sprintf( '%s, fila %d (%s): %s', $row['sheet'], $row['line'], $row['wine'], $row['reason'] ) );
		}
		\WP_CLI::success(
			sprintf(
				/* translators: 1: new, 2: updated, 3: unchanged, 4: rows left out. */
				__( '%1$d nuevas, %2$d actualizadas, %3$d ya estaban; %4$d filas no entran.', 'lachinata-core' ),
				$report['added'],
				$report['updated'],
				$report['same'],
				count( $report['skipped'] )
			)
		);
	}

	/**
	 * Recalculates the best published score of every wine («Mejor puntuados» and the filter
	 * «90 o más»).
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata bodega refresh-scores
	 *
	 * @subcommand refresh-scores
	 *
	 * @param string[]             $args       Arguments.
	 * @param array<string, mixed> $assoc_args Options.
	 */
	public function refresh_scores( array $args, array $assoc_args ): void {
		unset( $args, $assoc_args );
		$ids   = self::wine_ids();
		$count = 0;
		foreach ( $ids as $id ) {
			$product = wc_get_product( $id );
			if ( $product instanceof \WC_Product ) {
				Scores::refresh( $product );
				++$count;
			}
		}
		/* translators: %d: wines. */
		\WP_CLI::success( sprintf( __( '%d vinos al día.', 'lachinata-core' ), $count ) );
	}

	/**
	 * Merges a winery into another: its wines go to the one that stays, which keeps its
	 * texts and data (and takes the other's where it has none); the one that goes away
	 * answers with a 301 to the other. Nothing is merged without this command or the panel.
	 *
	 * ## OPTIONS
	 *
	 * <from>
	 * : Winery that goes away (id or slug).
	 *
	 * <into>
	 * : Winery that stays (id or slug).
	 *
	 * [--dry-run]
	 * : Say what would happen without changing anything.
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata bodega merge-wineries dominio-do-bibei dominio-de-bibei --dry-run
	 *
	 * @subcommand merge-wineries
	 *
	 * @param string[]             $args       Arguments.
	 * @param array<string, mixed> $assoc_args Options.
	 */
	public function merge_wineries( array $args, array $assoc_args ): void {
		$terms = array();
		foreach ( array_slice( $args, 0, 2 ) as $arg ) {
			$term    = is_numeric( $arg ) ? get_term( (int) $arg, Taxonomies::WINERY ) : get_term_by( 'slug', (string) $arg, Taxonomies::WINERY );
			$terms[] = $term instanceof \WP_Term ? $term : null;
		}
		if ( 2 !== count( $terms ) || in_array( null, $terms, true ) ) {
			\WP_CLI::error( __( 'No encuentro las dos bodegas.', 'lachinata-core' ) );
		}
		$dry    = ! empty( $assoc_args['dry-run'] );
		$result = WineryMerge::merge( $terms[0]->term_id, $terms[1]->term_id, $dry );
		if ( is_wp_error( $result ) ) {
			\WP_CLI::error( $result->get_error_message() );
		}
		\WP_CLI::success(
			sprintf(
				/* translators: 1: wines, 2: winery that goes away, 3: winery that stays, 4: «(simulación)» or empty. */
				__( '%1$d vinos de «%2$s» a «%3$s»%4$s.', 'lachinata-core' ),
				count( $result['wines'] ),
				Taxonomies::name( $terms[0] ),
				Taxonomies::name( $terms[1] ),
				$dry ? ' ' . __( '(simulación)', 'lachinata-core' ) : ''
			)
		);
	}

	/**
	 * Lists the wineries that are likely the same one written two ways. It only proposes:
	 * merging is up to whoever runs the catalogue.
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata bodega duplicates
	 *
	 * @param string[]             $args       Arguments.
	 * @param array<string, mixed> $assoc_args Options.
	 */
	public function duplicates( array $args, array $assoc_args ): void {
		unset( $args, $assoc_args );
		$rows = array();
		foreach ( WineryMerge::duplicates() as $pair ) {
			$rows[] = array(
				'bodega' => sprintf( '%s (%d)', Taxonomies::name( $pair[0] ), $pair[0]->count ),
				'y'      => sprintf( '%s (%d)', Taxonomies::name( $pair[1] ), $pair[1]->count ),
			);
		}
		if ( ! $rows ) {
			\WP_CLI::success( __( 'Ninguna bodega parece duplicada.', 'lachinata-core' ) );
			return;
		}
		\WP_CLI\Utils\format_items( 'table', $rows, array( 'bodega', 'y' ) );
	}

	/**
	 * Writes the names that are not translated (wines, wineries, D.O. and grapes) as a CSV
	 * for `wp lachinata translate glossary-import`.
	 *
	 * ## OPTIONS
	 *
	 * [--file=<file>]
	 * : Where to write it (without it, to the screen).
	 *
	 * [--force]
	 * : Write over the file if it already exists.
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata bodega glossary --file=glosario-bodega.csv
	 *     wp lachinata translate glossary-import glosario-bodega.csv
	 *
	 * @param string[]             $args       Arguments.
	 * @param array<string, mixed> $assoc_args Options.
	 */
	public function glossary( array $args, array $assoc_args ): void {
		unset( $args );
		$csv  = self::glossary_csv();
		$file = (string) ( $assoc_args['file'] ?? '' );
		if ( '' === $file ) {
			\WP_CLI::line( $csv );
			return;
		}
		Output::write( $file, $csv, $assoc_args );
		/* translators: %s: file. */
		\WP_CLI::success( sprintf( __( 'Glosario escrito en %s.', 'lachinata-core' ), $file ) );
	}

	/**
	 * The glossary CSV: `idioma,termino,traduccion` with the language and translation
	 * empty (every language, «no traducir»).
	 */
	public static function glossary_csv(): string {
		$names = array();
		foreach ( self::wine_ids() as $id ) {
			$names[] = (string) get_the_title( $id );
		}
		foreach ( array( Taxonomies::WINERY, Taxonomies::GRAPE, Taxonomies::ORIGIN ) as $taxonomy ) {
			$terms = get_terms(
				array(
					'taxonomy'   => $taxonomy,
					'hide_empty' => true,
				)
			);
			foreach ( is_array( $terms ) ? $terms : array() as $term ) {
				// Of the origins, only the D.O. (the country and the region are translated).
				if ( $term instanceof \WP_Term && ( Taxonomies::ORIGIN !== $taxonomy || count( get_ancestors( $term->term_id, Taxonomies::ORIGIN, 'taxonomy' ) ) >= 2 ) ) {
					$names[] = Taxonomies::name( $term );
				}
			}
		}
		$names = array_values( array_unique( array_filter( array_map( 'trim', $names ) ) ) );
		natcasesort( $names );
		$handle = fopen( 'php://temp', 'r+' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- In-memory buffer.
		if ( false === $handle ) {
			return '';
		}
		fputcsv( $handle, array( 'idioma', 'termino', 'traduccion' ), ',', '"', '' );
		foreach ( $names as $name ) {
			fputcsv( $handle, array( '', html_entity_decode( $name, ENT_QUOTES ), '' ), ',', '"', '' );
		}
		rewind( $handle );
		$csv = (string) stream_get_contents( $handle );
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- In-memory buffer.
		return $csv;
	}

	/**
	 * Ids of the products with a wine type.
	 *
	 * @return int[]
	 */
	private static function wine_ids(): array {
		$ids = get_posts(
			array(
				'post_type'      => 'product',
				'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
					array(
						'taxonomy' => Taxonomies::TYPE,
						'operator' => 'EXISTS',
					),
				),
			)
		);
		return array_map( 'intval', $ids );
	}
}
