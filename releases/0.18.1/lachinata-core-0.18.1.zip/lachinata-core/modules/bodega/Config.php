<?php
/**
 * The module's settings, read clean.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

defined( 'ABSPATH' ) || exit;

/**
 * Every setting of WooCommerce → La Chinata → Bodega with its default, sanitised also when
 * it comes from an imported JSON. Categories and attributes go by slug so they hold in
 * another shop.
 */
final class Config {

	/**
	 * Bottles in a case.
	 */
	public const CASE_SIZE = 6;

	/**
	 * Critics of the default list, by weight (10-bodega.md, «Críticos y concursos»): full
	 * name and the name the badge shows.
	 *
	 * @return array<int, array{name: string, short: string}>
	 */
	public static function default_critics(): array {
		return array(
			array(
				'name'  => 'Robert Parker Wine Advocate',
				'short' => 'Parker',
			),
			array(
				'name'  => 'Guía Peñín',
				'short' => 'Peñín',
			),
			array(
				'name'  => 'James Suckling',
				'short' => 'Suckling',
			),
			array(
				'name'  => 'Tim Atkin',
				'short' => 'Tim Atkin',
			),
			array(
				'name'  => 'Decanter',
				'short' => 'Decanter',
			),
			array(
				'name'  => 'Wine Spectator',
				'short' => 'Wine Spectator',
			),
			array(
				'name'  => 'Vinous',
				'short' => 'Vinous',
			),
			array(
				'name'  => 'Guía Proensa',
				'short' => 'Proensa',
			),
		);
	}

	/**
	 * Contests of the default list.
	 *
	 * @return array<int, array{name: string, short: string}>
	 */
	public static function default_contests(): array {
		return array_map(
			static fn( string $name ): array => array(
				'name'  => $name,
				'short' => $name,
			),
			array( 'Decanter World Wine Awards', 'International Wine Challenge', 'Concours Mondial de Bruxelles', 'Mundus Vini', 'Premios Bacchus', 'Premios Zarcillo' )
		);
	}

	/**
	 * Medals, best first.
	 *
	 * @return string[]
	 */
	public static function default_medals(): array {
		return array( 'Platino', 'Gran Oro', 'Oro', 'Plata', 'Bronce' );
	}

	/**
	 * The Bodega category, or null when it is not chosen or no longer exists.
	 */
	public static function category(): ?\WP_Term {
		return self::term_by_slug( (string) BodegaModule::setting( 'category' ) );
	}

	/**
	 * The accessories subcategory (no alcohol, no case), or null.
	 */
	public static function accessories(): ?\WP_Term {
		return self::term_by_slug( (string) BodegaModule::setting( 'accessories_category' ) );
	}

	/**
	 * A product category by slug.
	 *
	 * @param string $slug Slug.
	 */
	private static function term_by_slug( string $slug ): ?\WP_Term {
		if ( '' === $slug ) {
			return null;
		}
		$term = get_term_by( 'slug', $slug, 'product_cat' );
		return $term instanceof \WP_Term ? $term : null;
	}

	/**
	 * Taxonomy of the vintage attribute (`pa_…`): the chosen one or, by default, the global
	 * attribute called «Añada». Empty when there is none.
	 */
	public static function vintage_attribute(): string {
		return self::attribute( 'vintage_attribute', array( 'añada', 'anada', 'vintage' ) );
	}

	/**
	 * Taxonomy of the format attribute: the chosen one or the one called «Formato».
	 */
	public static function format_attribute(): string {
		return self::attribute( 'format_attribute', array( 'formato', 'format' ) );
	}

	/**
	 * A global attribute taxonomy, from its setting or by its name.
	 *
	 * @param string   $key   Setting.
	 * @param string[] $names Names (label or slug) that serve as default.
	 */
	private static function attribute( string $key, array $names ): string {
		$chosen = (string) BodegaModule::setting( $key );
		$found  = '';
		foreach ( wc_get_attribute_taxonomies() as $attribute ) {
			$taxonomy = wc_attribute_taxonomy_name( $attribute->attribute_name );
			if ( '' !== $chosen ) {
				if ( $taxonomy === $chosen ) {
					return $taxonomy;
				}
				continue;
			}
			$label = function_exists( 'mb_strtolower' ) ? mb_strtolower( (string) $attribute->attribute_label ) : strtolower( (string) $attribute->attribute_label );
			if ( '' === $found && ( in_array( $label, $names, true ) || in_array( (string) $attribute->attribute_name, $names, true ) ) ) {
				$found = $taxonomy;
			}
		}
		return $found;
	}

	/**
	 * Discount of a case of the same wine, in %.
	 */
	public static function same_discount(): float {
		return self::percent( (float) BodegaModule::setting( 'case_same' ) );
	}

	/**
	 * Discount of a mixed case, in %.
	 */
	public static function mixed_discount(): float {
		return self::percent( (float) BodegaModule::setting( 'case_mixed' ) );
	}

	/**
	 * A percentage between 0 and 100.
	 *
	 * @param float $value Value.
	 */
	private static function percent( float $value ): float {
		return max( 0.0, min( 100.0, $value ) );
	}

	/**
	 * Whether the case discount adds to a sale price (default no: the larger of the two).
	 */
	public static function stack_sale(): bool {
		return (bool) BodegaModule::setting( 'stack_sale' );
	}

	/**
	 * Whether the case discount adds to the customer's coupons (default no: the better one).
	 */
	public static function stack_coupons(): bool {
		return (bool) BodegaModule::setting( 'stack_coupons' );
	}

	/**
	 * Critics, in the order of the list (that order breaks ties).
	 *
	 * @return array<int, array{name: string, short: string}>
	 */
	public static function critics(): array {
		return self::named_list( (array) BodegaModule::setting( 'critics' ), self::default_critics() );
	}

	/**
	 * Contests.
	 *
	 * @return array<int, array{name: string, short: string}>
	 */
	public static function contests(): array {
		return self::named_list( (array) BodegaModule::setting( 'contests' ), self::default_contests() );
	}

	/**
	 * A list of `{name, short}`, clean; the default when empty.
	 *
	 * @param array<mixed>                                   $stored   Stored list.
	 * @param array<int, array{name: string, short: string}> $fallback Default.
	 * @return array<int, array{name: string, short: string}>
	 */
	private static function named_list( array $stored, array $fallback ): array {
		$clean = array();
		$seen  = array();
		foreach ( $stored as $row ) {
			$name  = is_array( $row ) ? sanitize_text_field( (string) ( $row['name'] ?? '' ) ) : sanitize_text_field( (string) $row );
			$short = is_array( $row ) ? sanitize_text_field( (string) ( $row['short'] ?? '' ) ) : '';
			$key   = self::key( $name );
			if ( '' === $name || isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;
			$clean[]      = array(
				'name'  => $name,
				'short' => '' !== $short ? $short : $name,
			);
		}
		return $clean ? $clean : $fallback;
	}

	/**
	 * Medals, best first.
	 *
	 * @return string[]
	 */
	public static function medals(): array {
		$medals = array_values( array_unique( array_filter( array_map( static fn( $medal ): string => sanitize_text_field( (string) $medal ), (array) BodegaModule::setting( 'medals' ) ) ) ) );
		return $medals ? $medals : self::default_medals();
	}

	/**
	 * Lowest points that are shown.
	 */
	public static function min_points(): int {
		return max( 0, (int) BodegaModule::setting( 'min_points' ) );
	}

	/**
	 * Worst medal that is shown (default: «Oro», or the third of the list).
	 */
	public static function min_medal(): string {
		$medals = self::medals();
		$chosen = (string) BodegaModule::setting( 'min_medal' );
		if ( '' !== $chosen && in_array( $chosen, $medals, true ) ) {
			return $chosen;
		}
		return in_array( 'Oro', $medals, true ) ? 'Oro' : (string) ( $medals[ min( 2, count( $medals ) - 1 ) ] ?? '' );
	}

	/**
	 * Comparable key of a name (critic, contest): lowercase, without accents.
	 *
	 * @param string $name Name.
	 */
	public static function key( string $name ): string {
		$name = remove_accents( trim( $name ) );
		return function_exists( 'mb_strtolower' ) ? mb_strtolower( $name ) : strtolower( $name );
	}

	/**
	 * A critic or contest of the lists by its full or short name (case and accents do not
	 * matter), with its position; null when it is not on the lists.
	 *
	 * @param string $name Name.
	 * @return array{name: string, short: string, kind: string, position: int}|null
	 */
	public static function source( string $name ): ?array {
		$key = self::key( $name );
		foreach ( array(
			'critic'  => self::critics(),
			'contest' => self::contests(),
		) as $kind => $list ) {
			foreach ( $list as $position => $row ) {
				if ( self::key( $row['name'] ) === $key || self::key( $row['short'] ) === $key ) {
					return $row + array(
						'kind'     => $kind,
						'position' => (int) $position,
					);
				}
			}
		}
		return null;
	}

	/**
	 * Whether pairing products are suggested by dish when a wine has none chosen.
	 */
	public static function suggest_pairing(): bool {
		return (bool) BodegaModule::setting( 'suggest_pairing' );
	}

	/**
	 * A text of the shop, or its default.
	 *
	 * @param string $key `age`, `carrier_note`, `eyebrow` or `intro`.
	 */
	public static function text( string $key ): string {
		$texts = (array) BodegaModule::setting( 'texts' );
		$text  = trim( sanitize_textarea_field( (string) ( $texts[ $key ] ?? '' ) ) );
		if ( '' !== $text ) {
			return $text;
		}
		switch ( $key ) {
			case 'age':
				return __( 'Venta solo a mayores de 18 años. Disfruta del vino con moderación.', 'lachinata-core' );
			case 'carrier_note':
				return __( 'Contiene alcohol: entregar a una persona mayor de edad.', 'lachinata-core' );
			default:
				return '';
		}
	}

	/**
	 * Whether the order carries the note for the carrier when it holds alcohol.
	 */
	public static function carrier_note(): bool {
		return (bool) BodegaModule::setting( 'carrier_note' );
	}

	/**
	 * Least wines a type or origin page needs to be indexable.
	 */
	public static function landing_min(): int {
		return max( 1, (int) BodegaModule::setting( 'landing_min' ) );
	}

	/**
	 * Type chips of the listing: `label` and the type slugs they gather (or a category
	 * slug, such as accessories). By default, one chip per type with wines.
	 *
	 * @return array<int, array{label: string, types: string[], category: string}>
	 */
	public static function chips(): array {
		$chips = array();
		foreach ( (array) BodegaModule::setting( 'chips' ) as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$label = sanitize_text_field( (string) ( $row['label'] ?? '' ) );
			$types = array_values( array_filter( array_map( 'sanitize_title', (array) ( $row['types'] ?? array() ) ) ) );
			$cat   = sanitize_title( (string) ( $row['category'] ?? '' ) );
			if ( '' === $label || ( ! $types && '' === $cat ) ) {
				continue;
			}
			$chips[] = array(
				'label'    => $label,
				'types'    => $types,
				'category' => $cat,
			);
		}
		return $chips;
	}

	/**
	 * The origin with its own entry in the listing («Vinos de Extremadura»), or null.
	 */
	public static function featured_origin(): ?\WP_Term {
		$slug = sanitize_title( (string) BodegaModule::setting( 'featured_origin' ) );
		$term = '' !== $slug && taxonomy_exists( Taxonomies::ORIGIN ) ? get_term_by( 'slug', $slug, Taxonomies::ORIGIN ) : false;
		return $term instanceof \WP_Term ? $term : null;
	}

	/**
	 * Entries before the grid (CategoryTile): title, address, eyebrow, text, call to action,
	 * tint and image, after the automatic ones (Listing::entries()).
	 *
	 * @return array<int, array{title: string, url: string, eyebrow: string, text: string, cta: string, tint: string, image_id: int}>
	 */
	public static function entries(): array {
		$entries = array();
		foreach ( (array) BodegaModule::setting( 'entries' ) as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$title = sanitize_text_field( (string) ( $row['title'] ?? '' ) );
			$url   = esc_url_raw( (string) ( $row['url'] ?? '' ) );
			if ( '' === $title || '' === $url ) {
				continue;
			}
			$entries[] = array(
				'title'    => $title,
				'url'      => $url,
				'eyebrow'  => sanitize_text_field( (string) ( $row['eyebrow'] ?? '' ) ),
				'text'     => sanitize_text_field( (string) ( $row['text'] ?? '' ) ),
				'cta'      => sanitize_text_field( (string) ( $row['cta'] ?? '' ) ),
				'tint'     => sanitize_key( (string) ( $row['tint'] ?? '' ) ),
				'image_id' => absint( $row['image_id'] ?? 0 ),
			);
		}
		return $entries;
	}
}
