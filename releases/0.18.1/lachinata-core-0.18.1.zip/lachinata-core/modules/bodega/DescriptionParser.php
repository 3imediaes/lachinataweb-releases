<?php
/**
 * The technical sheet written in a wine's description.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

defined( 'ABSPATH' ) || exit;

/**
 * Reads what the old descriptions carry as text (10-bodega.md, «Migración»):
 * - in the description, the «Ficha técnica» lines («La bodega:», «Marca:», «D.O.:»,
 *   «Tipo:», «Grado:», «Variedad:», «Tiempo de crianza:», «Viticultura:», «Añada:»,
 *   «Puntuación:»…, with or without the colon inside the bold), and the blocks «Viñedo(s)
 *   y elaboración» and «Bodega» (or a heading with the winery's name);
 * - in the short description, the sentences of sight, nose and mouth, the serving
 *   temperature and the pairing.
 * Nothing is written here: Migrate decides.
 */
final class DescriptionParser {

	/**
	 * Labels of the sheet, by comparable key.
	 */
	private const LABELS = array(
		'labodega'              => 'winery',
		'bodega'                => 'winery',
		'bodegas'               => 'winery',
		'marca'                 => 'brand',
		'do'                    => 'do',
		'dop'                   => 'do',
		'doca'                  => 'do',
		'o'                     => 'do',
		'origen'                => 'do',
		'igp'                   => 'do',
		'denominaciondeorigen'  => 'do',
		'tipo'                  => 'type',
		'tipodevino'            => 'type',
		'grado'                 => 'grade',
		'gradoalcoholico'       => 'grade',
		'variedad'              => 'grapes',
		'variedades'            => 'grapes',
		'uva'                   => 'grapes',
		'uvas'                  => 'grapes',
		'tiempodecrianza'       => 'ageing',
		'crianza'               => 'ageing',
		'viticultura'           => 'viticulture',
		'tipodeviticultura'     => 'viticulture',
		'anada'                 => 'vintage',
		'puntuacion'            => 'scores',
		'puntuaciones'          => 'scores',
		'subzona'               => 'subzone',
		'vinificacion'          => 'making_text',
		'temperaturadeservicio' => 'temperature',
		'temperatura'           => 'temperature',
	);

	/**
	 * Parses a description and a short description.
	 *
	 * @param string $description Description (HTML).
	 * @param string $short       Short description (HTML).
	 * @return array{sheet: array<string, string>, vineyard: string, winery_text: string, other: array<int, array{title: string, html: string}>, structured: bool, grapes: array<int, array{name: string, pct: int|null}>, scores: array<int, array{points: int, source: string}>, tasting: array{sight: string, nose: string, mouth: string}, temperature: int[], pairing: string, short: string}
	 */
	public static function parse( string $description, string $short ): array {
		$sections = self::sections( $description );
		$sheet    = array();
		$lines    = array();
		$vineyard = array();
		$winery   = array();
		$other    = array();
		foreach ( $sections as $section ) {
			$kept = array();
			foreach ( self::lines( $section['html'] ) as $line ) {
				$pair = self::label( $line );
				if ( null !== $pair ) {
					if ( '' !== $pair[1] && ! isset( $sheet[ $pair[0] ] ) ) {
						$sheet[ $pair[0] ] = $pair[1];
					}
					$lines[] = $line;
					continue;
				}
				$kept[] = $line;
			}
			$section['text'] = trim( implode( "\n", $kept ) );
			$kind            = self::kind( $section['title'], $sheet['winery'] ?? '' );
			if ( '' === $section['text'] || ( 'sheet' === $kind && mb_strlen( $section['text'] ) < 40 ) ) {
				continue;
			}
			if ( 'vineyard' === $kind ) {
				$vineyard[] = $section['text'];
			} elseif ( 'winery' === $kind ) {
				$winery[] = $section['text'];
			} else {
				$other[] = array(
					'title' => 'sheet' === $kind ? '' : $section['title'],
					'html'  => self::paragraphs( $section['text'] ),
				);
			}
		}
		$tasting = self::tasting( $short );
		return array(
			'sheet'       => $sheet,
			'vineyard'    => self::paragraphs( implode( "\n\n", $vineyard ) ),
			'winery_text' => self::paragraphs( implode( "\n\n", $winery ) ),
			'other'       => $other,
			'structured'  => count( $sheet ) >= 2,
			'grapes'      => self::grapes( (string) ( $sheet['grapes'] ?? '' ) ),
			'scores'      => self::scores( (string) ( $sheet['scores'] ?? '' ) ),
			'tasting'     => $tasting['tasting'],
			'temperature' => $tasting['temperature'] ? $tasting['temperature'] : ( self::temperature( (string) ( $sheet['temperature'] ?? '' ) ) ? self::temperature( (string) ( $sheet['temperature'] ?? '' ) ) : self::serving_temperature( $description ) ),
			'pairing'     => $tasting['pairing'],
			'short'       => $tasting['rest'],
		);
	}

	/**
	 * The description cut by its headings: what comes before the first one has an empty
	 * title.
	 *
	 * @param string $html Description.
	 * @return array<int, array{title: string, html: string}>
	 */
	public static function sections( string $html ): array {
		$parts    = preg_split( '~<h[1-6][^>]*>(.*?)</h[1-6]>~isu', $html, -1, PREG_SPLIT_DELIM_CAPTURE );
		$parts    = false === $parts ? array( $html ) : $parts;
		$sections = array(
			array(
				'title' => '',
				'html'  => (string) array_shift( $parts ),
			),
		);
		while ( $parts ) {
			$title      = trim( html_entity_decode( wp_strip_all_tags( (string) array_shift( $parts ) ), ENT_QUOTES ) );
			$title      = trim( (string) preg_replace( '/^[\x{200B}\s]+|[\x{200B}\s]+$/u', '', $title ) );
			$sections[] = array(
				'title' => $title,
				'html'  => (string) array_shift( $parts ),
			);
		}
		return $sections;
	}

	/**
	 * Lines of text of a piece of HTML (breaks, paragraphs and blocks end a line; blank
	 * lines between paragraphs are kept as one empty line).
	 *
	 * @param string $html HTML.
	 * @return string[]
	 */
	public static function lines( string $html ): array {
		$html  = (string) preg_replace( '~<br\s*/?>|</(p|div|li|ul|ol|tr|table)>~i', "\n", $html );
		$html  = (string) preg_replace( '~<(p|div|li|ul|ol)[^>]*>~i', "\n", $html );
		$text  = html_entity_decode( wp_strip_all_tags( $html, false ), ENT_QUOTES | ENT_HTML5 );
		$text  = str_replace( array( "\r", "\xC2\xA0", "\u{200B}" ), array( '', ' ', '' ), $text );
		$lines = array();
		$blank = false;
		foreach ( explode( "\n", $text ) as $line ) {
			$line = trim( (string) preg_replace( '/[ \t]+/', ' ', $line ) );
			if ( '' === $line ) {
				if ( ! $blank && $lines ) {
					$lines[] = '';
				}
				$blank = true;
				continue;
			}
			$blank   = false;
			$lines[] = $line;
		}
		while ( $lines && '' === end( $lines ) ) {
			array_pop( $lines );
		}
		return $lines;
	}

	/**
	 * A line of the sheet as `[field, value]`, or null.
	 *
	 * @param string $line Line.
	 * @return array{0: string, 1: string}|null
	 */
	public static function label( string $line ): ?array {
		if ( preg_match( '/^([^:]{1,40}?)\s*:\s*(.*)$/u', $line, $match ) ) {
			$key = Xlsx::key( $match[1] );
			if ( isset( self::LABELS[ $key ] ) ) {
				return array( self::LABELS[ $key ], self::value( $match[2] ) );
			}
		}
		if ( preg_match( '/^(la bodega|marca|d\.?o\.?(?:ca|p)?\.?|tipo|grado|variedad(?:es)?|tiempo de crianza|añada|viticultura|puntuaci[oó]n(?:es)?)\s+(.+)$/iu', $line, $match ) ) {
			$key = Xlsx::key( $match[1] );
			if ( isset( self::LABELS[ $key ] ) ) {
				return array( self::LABELS[ $key ], self::value( $match[2] ) );
			}
		}
		return null;
	}

	/**
	 * A value without the final dot or spaces.
	 *
	 * @param string $value Value.
	 */
	private static function value( string $value ): string {
		return trim( (string) preg_replace( '/[\s.]+$/u', '', trim( $value ) ) );
	}

	/**
	 * What a section is by its heading: the sheet, «Viñedo y elaboración», the winery or
	 * other.
	 *
	 * @param string $title  Heading.
	 * @param string $winery Winery of the sheet.
	 */
	public static function kind( string $title, string $winery ): string {
		$key = Xlsx::key( $title );
		if ( str_starts_with( $key, 'fichatecnica' ) ) {
			return 'sheet';
		}
		if ( '' === $key ) {
			return 'other';
		}
		if ( str_starts_with( $key, 'vinedo' ) || str_starts_with( $key, 'elaboracion' ) || str_starts_with( $key, 'vinificacion' ) ) {
			return 'vineyard';
		}
		if ( preg_match( '/^(la)?bodegas?/', $key ) || ( '' !== $winery && ( str_contains( $key, Xlsx::key( $winery ) ) || str_contains( Xlsx::key( $winery ), $key ) ) ) ) {
			return 'winery';
		}
		return 'other';
	}

	/**
	 * Lines as paragraphs of HTML (an empty line separates them).
	 *
	 * @param string $text Text.
	 */
	public static function paragraphs( string $text ): string {
		$blocks = preg_split( '/\n\s*\n/', trim( $text ) );
		$blocks = false === $blocks ? array() : $blocks;
		$html   = array();
		foreach ( $blocks as $block ) {
			$block = trim( $block );
			if ( '' !== $block ) {
				$html[] = '<p>' . nl2br( esc_html( $block ), false ) . '</p>';
			}
		}
		return implode( "\n\n", $html );
	}

	/**
	 * Grapes with their %: «90% Tempranillo, 10% Graciano.», «Garnacha y Syrah»,
	 * «Godello 100%».
	 *
	 * @param string $text Text.
	 * @return array<int, array{name: string, pct: int|null}>
	 */
	public static function grapes( string $text ): array {
		$text  = (string) preg_replace( '/\(.*?\)/u', '', $text );
		$parts = preg_split( '/\s*(?:,|;|\/|\s+y\s+|\s+e\s+|\s+\+\s+)\s*/u', $text );
		$parts = false === $parts ? array() : $parts;
		$out   = array();
		$seen  = array();
		foreach ( $parts as $part ) {
			$pct = null;
			if ( preg_match( '/(\d+(?:[.,]\d+)?)\s*%/u', $part, $match ) ) {
				$pct = (int) round( (float) str_replace( ',', '.', $match[1] ) );
			}
			$name = (string) preg_replace( '/\d+(?:[.,]\d+)?\s*%|\b(?:uvas?|variedad(?:es)?|de)\b\s*/iu', ' ', $part );
			$name = (string) preg_replace( '/\b(?:principalmente|tambi[ée]n|contiene|coupage|mayoritariamente|aproximadamente|predominantemente|sobre todo)\b/iu', ' ', $name );
			$name = trim( (string) preg_replace( '/\s+/', ' ', $name ), " .\t-:" );
			$name = trim( (string) preg_replace( array( '/^(?:la|el|los|las)\s+/iu', '/\s+(?:al|en|con|y)$/iu' ), '', $name ) );
			if ( '' === $name || mb_strlen( $name ) > 40 || preg_match( '/\d/', $name ) || substr_count( $name, ' ' ) > 2
				|| preg_match( '/^(?:varias(?:\s+\S+)?|otras?(?:\s+\S+)?|entre\s+otras|blancas?|tintas?|locales(?:\s.*)?|aut[óo]ctonas|una\s+selecci.*|diferentes(?:\s.*)?|distintas)$/iu', $name ) ) {
				continue;
			}
			$name = mb_strtoupper( mb_substr( $name, 0, 1 ) ) . mb_substr( $name, 1 );
			$key  = Xlsx::key( $name );
			if ( isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;
			$out[]        = array(
				'name' => $name,
				'pct'  => null !== $pct && $pct > 0 && $pct <= 100 ? $pct : null,
			);
		}
		return $out;
	}

	/**
	 * Scores: «92 Puntos Parker y 93 Puntos Peñín», «95 Decanter, 95 Tim Atkin y 94
	 * Parker», «+93 Parker», «92+ Puntos Parker.».
	 *
	 * @param string $text Text.
	 * @return array<int, array{points: int, source: string}>
	 */
	public static function scores( string $text ): array {
		$out = array();
		if ( ! preg_match_all( '/\+?(\d{2,3})\+?\.?\s*(?:puntos?|pts\.?)?\s+(?:de\s+(?:la\s+)?)?([^\d,;]+?)(?=\s*(?:,|;|\s+y\s+\+?\d|\s+e\s+\d|$))/iu', $text, $matches, PREG_SET_ORDER ) ) {
			return $out;
		}
		foreach ( $matches as $match ) {
			$points = (int) $match[1];
			$source = self::source_name( trim( $match[2], " .\t" ) );
			if ( $points < 50 || $points > 100 || '' === $source ) {
				continue;
			}
			$out[] = array(
				'points' => $points,
				'source' => $source,
			);
		}
		return $out;
	}

	/**
	 * The name of a critic as the lists know it, or as written (with capitals).
	 *
	 * @param string $written Name as written («parker», «Guía Peñin»).
	 */
	public static function source_name( string $written ): string {
		$written = trim( $written );
		$key     = Xlsx::key( $written );
		$aliases = array(
			'parker'                   => 'Robert Parker Wine Advocate',
			'robertparker'             => 'Robert Parker Wine Advocate',
			'robertparkerwineadvocate' => 'Robert Parker Wine Advocate',
			'wineadvocate'             => 'Robert Parker Wine Advocate',
			'penin'                    => 'Guía Peñín',
			'guiapenin'                => 'Guía Peñín',
			'suckling'                 => 'James Suckling',
			'jamessuckling'            => 'James Suckling',
			'proensa'                  => 'Guía Proensa',
			'guiaproensa'              => 'Guía Proensa',
		);
		if ( isset( $aliases[ $key ] ) ) {
			return $aliases[ $key ];
		}
		$source = Config::source( $written );
		if ( null !== $source ) {
			return $source['name'];
		}
		return '' === $written ? '' : mb_strtoupper( mb_substr( $written, 0, 1 ) ) . mb_substr( $written, 1 );
	}

	/**
	 * Serving temperature written in a text: «16ºC», «14-16 ºC», «entre 8 y 10 grados»,
	 * «de 16 a 18 ºC».
	 *
	 * @param string $text Text.
	 * @return int[]
	 */
	public static function temperature( string $text ): array {
		if ( ! preg_match( '/(\d{1,2})(?:[.,]\d)?\s*(?:º|°|ºC|grados)?\s*(?:[-–]|a|y|hasta)\s*(\d{1,2})(?:[.,]\d)?\s*(?:º|°|grados)/iu', $text, $match )
			&& ! preg_match( '/(\d{1,2})(?:[.,]\d)?\s*(?:º|°|grados)/iu', $text, $match ) ) {
			return array();
		}
		return Fields::temperature( array( (int) $match[1], (int) ( $match[2] ?? $match[1] ) ) );
	}

	/**
	 * Sight, nose and mouth, temperature and pairing from the short description, and what
	 * is left of it without them. A sentence that tells two things («En vista es pajizo y
	 * en nariz tiene…», «…es de 16 grados y marida con…») is cut where the second starts.
	 *
	 * @param string $short Short description.
	 * @return array{tasting: array{sight: string, nose: string, mouth: string}, temperature: int[], pairing: string, rest: string}
	 */
	public static function tasting( string $short ): array {
		$found       = array(
			'sight' => array(),
			'nose'  => array(),
			'mouth' => array(),
		);
		$temperature = array();
		$pairing     = array();
		$kept        = array();
		$paragraphs  = preg_split( '/\n\s*\n/', implode( "\n", self::lines( $short ) ) );
		$paragraphs  = false === $paragraphs ? array() : $paragraphs;
		foreach ( $paragraphs as $paragraph ) {
			$left = array();
			foreach ( self::sentences( $paragraph ) as $sentence ) {
				$pieces = self::clauses( $sentence );
				if ( ! $pieces ) {
					$left[] = $sentence;
					continue;
				}
				foreach ( $pieces as list( $kind, $text ) ) {
					if ( 'temperature' === $kind ) {
						$read = self::temperature( $text );
						if ( ! $read ) {
							$left[] = $text;
							continue;
						}
						$temperature = $temperature ? $temperature : $read;
					} elseif ( 'pairing' === $kind ) {
						$pairing[] = $text;
					} else {
						$found[ $kind ][] = $text;
					}
				}
			}
			if ( $left ) {
				$kept[] = implode( ' ', $left );
			}
		}
		return array(
			'tasting'     => array(
				'sight' => implode( ' ', $found['sight'] ),
				'nose'  => implode( ' ', $found['nose'] ),
				'mouth' => implode( ' ', $found['mouth'] ),
			),
			'temperature' => $temperature,
			'pairing'     => implode( ' ', $pairing ),
			'rest'        => self::paragraphs( implode( "\n\n", $kept ) ),
		);
	}

	/**
	 * Sentences of a paragraph.
	 *
	 * @param string $paragraph Paragraph.
	 * @return string[]
	 */
	public static function sentences( string $paragraph ): array {
		$text      = trim( (string) preg_replace( '/\s*\n\s*/', ' ', $paragraph ) );
		$sentences = preg_split( '/(?<=[.!?])\s+(?=[\p{Lu}¿¡])/u', $text );
		return array_values( array_filter( array_map( 'trim', false === $sentences ? array() : $sentences ), static fn( string $item ): bool => '' !== $item ) );
	}

	/**
	 * Markers of what a clause tells, by kind.
	 *
	 * @return array<string, string>
	 */
	private static function markers(): array {
		return array(
			'temperature' => '/temperatura\s+(?:[óo]ptima\s+|ideal\s+)?(?:de\s+)?(?:servicio|consumo)|temperatura\s+(?:ideal|recomendada)|recomienda\s+(?:beber|consumir|servir|tomar)|serv(?:ir(?:lo)?|ir[áa]|irlo)\s+(?:a|entre)\s+\d|s[íi]rvelo\s+a/iu',
			'pairing'     => '/\bmarid(?:a|ar|aje|an|ar[áa])\b|\bacompañar\b|\bacompañante\b|\bacompaña\s+(?:a|bien|muy|perfectamente|platos|con)\b/iu',
			'sight'       => '/\b(?:en|a\s+la)\s+vista\b|^vista\b|\ben\s+copa\b/iu',
			'nose'        => '/\ben\s+(?:la\s+)?nariz\b|\b(?:su|la|una|con)\s+(?:una\s+)?nariz\b|^nariz\b/iu',
			'mouth'       => '/\ben\s+(?:la\s+)?boca\b|\b(?:su|la|una)\s+boca\b|^boca\b|\ben\s+(?:el\s+)?paladar\b/iu',
		);
	}

	/**
	 * The clauses of a sentence with what each tells, or an empty list when it tells none
	 * of them. A clause starts at a marker that follows «y», a comma or a semicolon; the
	 * text before the first marker goes with it.
	 *
	 * @param string $sentence Sentence.
	 * @return array<int, array{0: string, 1: string}>
	 */
	public static function clauses( string $sentence ): array {
		$hits = array();
		foreach ( self::markers() as $kind => $pattern ) {
			if ( preg_match_all( $pattern, $sentence, $matches, PREG_OFFSET_CAPTURE ) ) {
				foreach ( $matches[0] as $match ) {
					$hits[] = array( (int) $match[1], $kind );
				}
			}
		}
		if ( ! $hits ) {
			return array();
		}
		if ( preg_match( '/temperatura/iu', $sentence ) && ! preg_match( '/\d\s*(?:º|°|grados)/u', $sentence ) ) {
			$hits = array_values( array_filter( $hits, static fn( array $hit ): bool => 'temperature' !== $hit[1] ) );
			if ( ! $hits ) {
				return array();
			}
		}
		usort( $hits, static fn( array $a, array $b ): int => $a[0] <=> $b[0] );
		$cuts    = array( array( 0, $hits[0][1] ) );
		$current = $hits[0][1];
		foreach ( array_slice( $hits, 1 ) as $hit ) {
			if ( $hit[1] === $current ) {
				continue;
			}
			$before = substr( $sentence, max( 0, $hit[0] - 4 ), min( 4, $hit[0] ) );
			if ( ! preg_match( '/(?:\sy\s|,\s|;\s|\se\s)$/u', $before, $separator ) ) {
				continue;
			}
			$cuts[]  = array( $hit[0] - strlen( $separator[0] ) + 1, $hit[1] );
			$current = $hit[1];
		}
		$pieces = array();
		foreach ( $cuts as $index => $cut ) {
			$end  = isset( $cuts[ $index + 1 ] ) ? $cuts[ $index + 1 ][0] : strlen( $sentence );
			$text = trim( substr( $sentence, $cut[0], $end - $cut[0] ) );
			$text = trim( (string) preg_replace( '/^(?:y|e)\s+/u', '', $text ), " ,;\t" );
			if ( '' === $text ) {
				continue;
			}
			$text     = mb_strtoupper( mb_substr( $text, 0, 1 ) ) . mb_substr( $text, 1 );
			$text     = preg_match( '/[.!?…]$/u', $text ) ? $text : $text . '.';
			$pieces[] = array( $cut[1], $text );
		}
		return $pieces;
	}

	/**
	 * What a sentence of the short description tells first: `sight`, `nose`, `mouth`,
	 * `temperature`, `pairing` or null.
	 *
	 * @param string $sentence Sentence.
	 */
	public static function sentence_kind( string $sentence ): ?string {
		$pieces = self::clauses( $sentence );
		return $pieces ? $pieces[0][0] : null;
	}

	/**
	 * Serving temperature told in the sentences of a text (the description, when the short
	 * one does not say it), or empty.
	 *
	 * @param string $html Text.
	 * @return int[]
	 */
	public static function serving_temperature( string $html ): array {
		$paragraphs = preg_split( '/\n\s*\n/', implode( "\n", self::lines( $html ) ) );
		foreach ( false === $paragraphs ? array() : $paragraphs as $paragraph ) {
			foreach ( self::sentences( $paragraph ) as $sentence ) {
				foreach ( self::clauses( $sentence ) as list( $kind, $text ) ) {
					if ( 'temperature' === $kind ) {
						$read = self::temperature( $text );
						if ( $read ) {
							return $read;
						}
					}
				}
			}
		}
		return array();
	}

	/**
	 * The wine type of a written «Tipo» («Tinto Crianza», «Blanco Espumoso», «Cava»,
	 * «Manzanilla»): a colour of the system, or empty.
	 *
	 * @param string $text Text.
	 */
	public static function type_color( string $text ): string {
		$text = strtolower( remove_accents( $text ) );
		$map  = array(
			'espumoso' => '/espumos|\bcava\b|brut|champa|ancestral|\bpet\s*nat/',
			'generoso' => '/generos|manzanilla|\bfino\b|amontillado|oloroso|palo cortado|jerez/',
			'dulce'    => '/\bdulce|moscatel|pedro xim|vendimia tardia|licoroso/',
			'rosado'   => '/rosad|clarete/',
			'blanco'   => '/blanc/',
			'tinto'    => '/tint/',
		);
		foreach ( $map as $color => $pattern ) {
			if ( preg_match( $pattern, $text ) ) {
				return $color;
			}
		}
		return '';
	}

	/**
	 * Slug of the making of a written «Tipo» («Tinto Crianza» → crianza, «Blanco
	 * Fermentado en Barrica» → fermentado-en-barrica), or empty.
	 *
	 * @param string $text Text.
	 */
	public static function making( string $text ): string {
		$text = strtolower( remove_accents( $text ) );
		$map  = array(
			'gran-reserva'          => '/gran reserva/',
			'reserva'               => '/reserva/',
			'joven'                 => '/sin crianza|\bjoven\b/',
			'crianza'               => '/crianza/',
			'roble'                 => '/\broble\b/',
			'fermentado-en-barrica' => '/fermentado en (barrica|bota)/',
			'sobre-lias'            => '/sobre lias/',
			'brut-nature'           => '/brut nature/',
		);
		foreach ( $map as $slug => $pattern ) {
			if ( preg_match( $pattern, $text ) ) {
				return $slug;
			}
		}
		return '';
	}

	/**
	 * Viticulture values of a written text («Ecológica y biodinámica», «Orgánica»).
	 *
	 * @param string $text Text.
	 * @return string[]
	 */
	public static function viticulture( string $text ): array {
		$text   = strtolower( remove_accents( $text ) );
		$values = array();
		$map    = array(
			'ecologica'    => '/ecolog|organic/',
			'biodinamica'  => '/biodinam/',
			'sostenible'   => '/sosten/',
			'tradicional'  => '/tradicion/',
			'convencional' => '/convencion/',
			'natural'      => '/\bnatural/',
		);
		foreach ( $map as $value => $pattern ) {
			if ( preg_match( $pattern, $text ) ) {
				$values[] = $value;
			}
		}
		return $values;
	}

	/**
	 * Slugs of the dishes a pairing sentence names (the default dishes of the module).
	 *
	 * @param string $text Text.
	 * @return string[]
	 */
	public static function dishes( string $text ): array {
		$text  = strtolower( remove_accents( $text ) );
		$map   = array(
			'carnes-blancas' => '/carnes? blancas|\baves?\b|pollo|pavo|conejo|cerdo/',
			'carnes-rojas'   => '/carnes? rojas|parrilla|asados?\b|caza|cordero|ternera|buey|vacuno|chulet|guisos?|estofad|cochinillo|cabrito|venado|jabali|carnes? a la/',
			'ibericos'       => '/iberic|embutido|jamon|chacina|lomo|chorizo|salchich|cecina/',
			'quesos-curados' => '/quesos? (?:curad|anej|viej|azul|fuert|semicurad)|manchego/',
			'quesos-suaves'  => '/quesos? (?:fresc|suave|cremos|tiern|blando|de cabra)/',
			'pescados'       => '/pescad|bacalao|atun|bonito|anchoa|sardina|salmon|merluza|rodaballo|lubina|dorada/',
			'mariscos'       => '/marisc|crustac|ostra|gamba|langost|pulpo|mejill|almeja|vieira/',
			'arroces'        => '/arroz|arroces|paella|risott/',
			'pasta'          => '/\bpastas?\b|lasa|espagu/',
			'verduras'       => '/verdura|ensalad|vegetal|setas|hongos|champi|legumbre/',
			'aperitivo'      => '/aperitiv|tapas|entrantes|frutos secos|aceitunas|aperitivos/',
			'postres'        => '/postre|chocolate|reposteria|tartas?\b|frutas/',
		);
		$found = array();
		foreach ( $map as $slug => $pattern ) {
			if ( preg_match( $pattern, $text ) ) {
				$found[] = $slug;
			}
		}
		if ( ! array_intersect( $found, array( 'quesos-curados', 'quesos-suaves' ) ) && preg_match( '/\bquesos?\b/', $text ) ) {
			$found[] = 'quesos-curados';
		}
		if ( ! array_intersect( $found, array( 'carnes-rojas', 'carnes-blancas' ) ) && preg_match( '/\bcarnes?\b/', $text ) ) {
			$found[] = 'carnes-rojas';
		}
		return $found;
	}
}
