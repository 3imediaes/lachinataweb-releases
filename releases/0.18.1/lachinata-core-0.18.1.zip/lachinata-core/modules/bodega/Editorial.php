<?php
/**
 * The wine texts in the editorial package of the catalog.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * The tasting notes of each wine (sight, nose and mouth) as fields of the editorial package
 * (`wp lachinata catalog export-editorial` / `import-editorial`), and the text of each winery
 * in its section of terms. The module reads and writes its own data; the package carries
 * each text with its fingerprint, so nothing changed on the site since the export is
 * overwritten.
 */
final class Editorial {

	/**
	 * Fields of the package → key of the tasting notes.
	 */
	public const TASTING = array(
		'vista' => 'sight',
		'nariz' => 'nose',
		'boca'  => 'mouth',
	);

	/**
	 * Whether the module is writing the text of a winery.
	 *
	 * @var bool
	 */
	private static bool $writing = false;

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/catalog/editorial_fields', array( self::class, 'fields' ) );
		Hooks::add_filter( 'lachinata/catalog/editorial_terms', array( self::class, 'terms' ) );
		Hooks::add_filter( 'wp_kses_allowed_html', array( self::class, 'allowed' ), 10, 2 );
	}

	/**
	 * The tags of a post for the description of a winery while the module writes it.
	 *
	 * @param mixed $tags    Allowed tags.
	 * @param mixed $context Context.
	 * @return mixed
	 */
	public static function allowed( $tags, $context ) {
		return self::$writing && 'pre_term_description' === $context ? wp_kses_allowed_html( 'post' ) : $tags;
	}

	/**
	 * Sight, nose and mouth, in the wines.
	 *
	 * @param mixed $fields Fields of other modules.
	 * @return mixed
	 */
	public static function fields( $fields ) {
		if ( ! is_array( $fields ) ) {
			return $fields;
		}
		$labels = array(
			'vista' => __( 'Cata: vista', 'lachinata-core' ),
			'nariz' => __( 'Cata: nariz', 'lachinata-core' ),
			'boca'  => __( 'Cata: boca', 'lachinata-core' ),
		);
		foreach ( self::TASTING as $field => $key ) {
			$fields[ $field ] = array(
				'label'   => $labels[ $field ],
				'html'    => false,
				'applies' => static fn( \WC_Product $product ): bool => Fields::is_wine( $product ),
				'read'    => static fn( \WC_Product $product ): string => self::read( $product->get_id(), $key ),
				'write'   => static function ( \WC_Product $product, string $text ) use ( $key ): void {
					self::write( $product->get_id(), $key, $text );
				},
			);
		}
		return $fields;
	}

	/**
	 * A note of the tasting.
	 *
	 * @param int    $id  Product.
	 * @param string $key `sight`, `nose` or `mouth`.
	 */
	public static function read( int $id, string $key ): string {
		return Fields::tasting( Fields::get( $id, Fields::TASTING ) )[ $key ] ?? '';
	}

	/**
	 * Writes a note of the tasting; the other two stay as they were.
	 *
	 * @param int    $id   Product.
	 * @param string $key  `sight`, `nose` or `mouth`.
	 * @param string $text Text.
	 */
	public static function write( int $id, string $key, string $text ): void {
		$tasting         = Fields::tasting( Fields::get( $id, Fields::TASTING ) );
		$tasting[ $key ] = $text;
		update_post_meta( $id, Fields::TASTING, Fields::tasting( $tasting ) );
	}

	/**
	 * The text of each winery («La bodega» of the wine page).
	 *
	 * @param mixed $taxonomies Taxonomies of other modules.
	 * @return mixed
	 */
	public static function terms( $taxonomies ) {
		if ( ! is_array( $taxonomies ) ) {
			return $taxonomies;
		}
		$taxonomies[ Taxonomies::WINERY ] = array(
			'label' => __( 'Bodega', 'lachinata-core' ),
			'read'  => static fn( \WP_Term $term ): string => (string) $term->description,
			'write' => static function ( \WP_Term $term, string $text ): void {
				// WordPress passes term descriptions through its strict filter (no <p>): while
				// the module writes, that filter takes the tags of a post, as the package does.
				self::$writing = true;
				wp_update_term( $term->term_id, $term->taxonomy, array( 'description' => wp_kses_post( $text ) ) );
				self::$writing = false;
			},
		);
		return $taxonomies;
	}
}
