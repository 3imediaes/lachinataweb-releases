<?php
/**
 * Migration of the wines from their descriptions.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

use LaChinata\Core\Services;

defined( 'ABSPATH' ) || exit;

/**
 * `wp lachinata bodega migrate` (10-bodega.md, «Migración»; decisions of Alberto, 30/10):
 *
 * - Reads the technical sheet written in the description and passes it to the wine's
 *   taxonomies and fields: winery (one page per winery, with the text of the «Bodega»
 *   block), origin (Country › Region › D.O.), type, making, grapes with their %, strength,
 *   ageing, viticulture. The description keeps «Viñedo y elaboración» (and any block it
 *   does not know); the original stays in `_lc_bodega_migrado`.
 * - Takes sight, nose, mouth, serving temperature and pairing out of the short description.
 * - The scores of the text enter unpublished, without a vintage until it is confirmed.
 * - Every simple wine becomes variable, with one variation per vintage and format: SKU,
 *   GTIN, prices, stock and weight go to the variation; the product keeps its id, address
 *   and reviews. Without a known vintage the variation is created all the same (with its
 *   format) and the wine goes to the report; once the vintage is known (the sheet «Para
 *   completar» of the Excel), running it again adds it. Wines that are already variable
 *   keep their variations.
 * - Imports what marketing fills in «Para completar» (vintage, D.O., temperature) and
 *   compares the reading with the sheet «Vinos».
 *
 * It only fills what is empty: running it again never overwrites the panel.
 */
final class Migrate {

	/**
	 * Whether nothing is written.
	 *
	 * @var bool
	 */
	private bool $dry;

	/**
	 * Sheets of the Excel (empty without one).
	 *
	 * @var array<string, array<int, array<string, string>>>
	 */
	private array $excel;

	/**
	 * Products asked for (empty: the Bodega and the wines of the Excel).
	 *
	 * @var int[]
	 */
	private array $ids;

	/**
	 * What happened, for the report.
	 *
	 * @var array<string, mixed>
	 */
	private array $report = array();

	/**
	 * Terms created (or that would be) in this run, by taxonomy and key.
	 *
	 * @var array<string, array<string, int>>
	 */
	private array $created = array();

	/**
	 * Prepares a run.
	 *
	 * @param bool                                             $dry   Whether nothing is written.
	 * @param array<string, array<int, array<string, string>>> $excel Sheets of bodega-datos-vinos.xlsx.
	 * @param int[]                                            $ids   Products (empty: all).
	 */
	public function __construct( bool $dry, array $excel = array(), array $ids = array() ) {
		$this->dry   = $dry;
		$this->excel = $excel;
		$this->ids   = array_values( array_filter( array_map( 'absint', $ids ) ) );
	}

	/**
	 * Runs the migration.
	 *
	 * @return array<string, mixed> Report.
	 */
	public function run(): array {
		$this->report = array(
			'dry'        => $this->dry,
			'wines'      => 0,
			'filled'     => 0,
			'converted'  => array(),
			'vintages'   => array(),
			'unknown'    => array(),
			'skipped'    => array(),
			'missing'    => array(),
			'origins'    => array(),
			'unmatched'  => array(),
			'wineries'   => array(),
			'grapes'     => array(),
			'scores'     => array(),
			'other'      => array(),
			'described'  => 0,
			'tasting'    => 0,
			'compare'    => array(),
			'variable'   => 0,
			'errors'     => array(),
			'attributes' => array(
				'vintage' => Config::vintage_attribute(),
				'format'  => Config::format_attribute(),
			),
		);
		$vinos        = $this->rows_by_id( 'Vinos' );
		$complete     = $this->rows_by_id( 'Para completar' );
		$no_wine      = $this->rows_by_id( 'No son vino' );
		foreach ( $this->products( array_keys( $vinos ) ) as $id ) {
			$product = wc_get_product( $id );
			if ( ! $product instanceof \WC_Product || $product->is_type( 'variation' ) ) {
				if ( isset( $vinos[ $id ] ) ) {
					$this->report['missing'][] = array(
						'id'   => $id,
						'name' => Xlsx::cell( $vinos[ $id ], 'Nombre' ),
					);
				}
				continue;
			}
			try {
				$this->wine( $product, $vinos[ $id ] ?? null, $complete[ $id ] ?? null, isset( $no_wine[ $id ] ) );
			} catch ( \Throwable $error ) {
				$this->report['errors'][] = array(
					'id'      => $id,
					'name'    => $product->get_name(),
					'message' => $error->getMessage(),
				);
			}
		}
		return $this->report;
	}

	/**
	 * Rows of a sheet of the Excel by product id.
	 *
	 * @param string $sheet Sheet.
	 * @return array<int, array<string, string>>
	 */
	private function rows_by_id( string $sheet ): array {
		if ( ! $this->excel ) {
			return array();
		}
		$rows = array();
		foreach ( Xlsx::sheet( $this->excel, $sheet ) as $row ) {
			$id = absint( Xlsx::cell( $row, 'ID' ) );
			if ( $id ) {
				$rows[ $id ] = $row;
			}
		}
		return $rows;
	}

	/**
	 * Products to read: the ones asked for, or those of the Bodega (any status but the
	 * bin) and the wines of the Excel.
	 *
	 * @param int[] $excel Ids of the sheet «Vinos».
	 * @return int[]
	 */
	private function products( array $excel ): array {
		if ( $this->ids ) {
			return $this->ids;
		}
		$ids      = array();
		$category = Config::category();
		if ( null !== $category ) {
			$found = get_posts(
				array(
					'post_type'      => 'product',
					'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
					'posts_per_page' => -1,
					'fields'         => 'ids',
					'orderby'        => 'ID',
					'order'          => 'ASC',
					'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
						array(
							'taxonomy' => 'product_cat',
							'terms'    => array( $category->term_id ),
						),
					),
				)
			);
			$ids   = array_map( 'intval', $found );
		}
		$ids = array_values( array_unique( array_merge( $ids, $excel ) ) );
		sort( $ids );
		return $ids;
	}

	/**
	 * One product of the Bodega.
	 *
	 * @param \WC_Product                $product  Product.
	 * @param array<string, string>|null $vino     Row of the sheet «Vinos».
	 * @param array<string, string>|null $complete Row of the sheet «Para completar».
	 * @param bool                       $no_wine  Whether the Excel says it is not wine.
	 */
	private function wine( \WC_Product $product, ?array $vino, ?array $complete, bool $no_wine ): void {
		$id     = $product->get_id();
		$backup = get_post_meta( $id, Fields::MIGRATED, true );
		$backup = is_array( $backup ) ? $backup : array();
		$desc   = isset( $backup['description'] ) ? (string) $backup['description'] : $product->get_description();
		$short  = isset( $backup['excerpt'] ) ? (string) $backup['excerpt'] : $product->get_short_description();
		$parsed = DescriptionParser::parse( $desc, $short );
		$sheet  = $parsed['sheet'];
		$class  = null !== $vino ? Xlsx::key( Xlsx::cell( $vino, 'Clase' ) ) : '';
		$color  = DescriptionParser::type_color( (string) ( $sheet['type'] ?? '' ) );
		if ( '' === $color && null !== $vino ) {
			$color = DescriptionParser::type_color( Xlsx::cell( $vino, 'Color' ) . ' ' . Xlsx::cell( $vino, 'Tipo' ) . ' ' . $class );
		}
		$type_term = Fields::type( $product );
		if ( '' === $color && null === $type_term ) {
			$color = $this->color_from_attributes( $product );
		}
		$accessory = Fields::in_category( $product, Config::accessories() );
		if ( $no_wine || $accessory || ( null === $vino && '' === $color && null === $type_term ) ) {
			$this->report['skipped'][] = array(
				'id'     => $id,
				'name'   => $product->get_name(),
				'reason' => $no_wine ? __( 'el Excel dice que no es vino', 'lachinata-core' ) : ( $accessory ? __( 'accesorio', 'lachinata-core' ) : __( 'sin tipo de vino', 'lachinata-core' ) ),
			);
			return;
		}
		++$this->report['wines'];

		$written_do = null !== $complete && '' !== Xlsx::cell( $complete, 'D.O.' ) ? Xlsx::cell( $complete, 'D.O.' ) : (string) ( $sheet['do'] ?? '' );
		if ( '' === $written_do && null !== $vino ) {
			$written_do = Xlsx::cell( $vino, 'D.O.' );
		}
		$vintage = self::vintage_name( null !== $complete ? Xlsx::cell( $complete, 'Añada' ) : '' );
		if ( '' === $vintage ) {
			$vintage = self::vintage_name( (string) ( $sheet['vintage'] ?? '' ) );
		}
		if ( '' === $vintage && null !== $vino ) {
			$vintage = self::vintage_name( Xlsx::cell( $vino, 'Añada' ) );
		}
		$temperature = null !== $complete ? DescriptionParser::temperature( Xlsx::cell( $complete, 'Temperatura' ) . ' ºC' ) : array();
		if ( ! $temperature ) {
			$temperature = $parsed['temperature'];
		}

		$changed = $this->type( $product, $color );
		$changed = $this->making( $product, (string) ( $sheet['type'] ?? '' ) ) || $changed;
		$region  = $this->origin( $product, $written_do );
		$changed = $this->winery( $product, (string) ( $sheet['winery'] ?? ( null !== $vino ? Xlsx::cell( $vino, 'Bodega' ) : '' ) ), $parsed['winery_text'], $region ) || $changed;
		$changed = $this->grapes( $product, $parsed['grapes'] ) || $changed;
		$changed = $this->meta( $product, Fields::GRADE, Fields::grade_meta( (string) ( $sheet['grade'] ?? '' ) ) ) || $changed;
		$changed = $this->meta( $product, Fields::AGEING, Fields::line( (string) ( $sheet['ageing'] ?? '' ) ) ) || $changed;
		$changed = $this->meta( $product, Fields::VITICULTURE, DescriptionParser::viticulture( (string) ( $sheet['viticulture'] ?? '' ) ) ) || $changed;
		$changed = $this->meta( $product, Fields::TEMPERATURE, $temperature ) || $changed;
		$changed = $this->tasting( $product, $parsed['tasting'] ) || $changed;
		$changed = $this->dishes( $product, $parsed['pairing'] ) || $changed;
		$changed = $this->scores( $product, $parsed['scores'] ) || $changed;
		$changed = $this->texts( $product, $parsed, $backup ) || $changed;
		if ( $changed ) {
			++$this->report['filled'];
		}
		foreach ( $parsed['other'] as $other ) {
			$this->report['other'][] = array(
				'id'    => $id,
				'name'  => $product->get_name(),
				'title' => '' !== $other['title'] ? $other['title'] : __( '(texto sin título)', 'lachinata-core' ),
			);
		}

		if ( $product->is_type( 'simple' ) ) {
			$this->convert( $product, $vintage, $this->format_name( $product, null !== $vino ? Xlsx::cell( $vino, 'Volumen' ) : '' ) );
		} elseif ( $product->is_type( 'variable' ) ) {
			++$this->report['variable'];
			if ( ! empty( $backup['variation'] ) && empty( $backup['vintage'] ) && '' !== $vintage ) {
				$this->add_vintage( $product, (int) $backup['variation'], $vintage );
			}
		}
		if ( null !== $vino ) {
			$this->compare( $product, $vino, $parsed, $vintage );
		}
		if ( ! $this->dry ) {
			$fresh = wc_get_product( $id );
			Scores::refresh( $fresh instanceof \WC_Product ? $fresh : $product );
		}
	}

	/**
	 * A wine colour from the values of the product's attributes («Tinto» in an attribute
	 * of wine type), or empty.
	 *
	 * @param \WC_Product $product Product.
	 */
	private function color_from_attributes( \WC_Product $product ): string {
		foreach ( $product->get_attributes() as $attribute ) {
			if ( ! $attribute instanceof \WC_Product_Attribute ) {
				continue;
			}
			$names = $attribute->is_taxonomy() ? array_map( static fn( $term ): string => $term instanceof \WP_Term ? $term->name : '', $attribute->get_terms() ?? array() ) : $attribute->get_options();
			foreach ( $names as $name ) {
				if ( preg_match( '/^(tinto|blanco|rosado|espumoso|generoso)$/iu', trim( (string) $name ) ) ) {
					return DescriptionParser::type_color( (string) $name );
				}
			}
		}
		return '';
	}

	/**
	 * «2021», «Sin añada» or empty.
	 *
	 * @param string $text Written vintage.
	 */
	public static function vintage_name( string $text ): string {
		if ( preg_match( '/\b(19[5-9]\d|20\d{2})\b/', $text, $match ) ) {
			return $match[1];
		}
		return preg_match( '/sin\s+a[ñn]ada|^n\.?\s*v\.?$|multia[ñn]ada/iu', trim( $text ) ) ? __( 'Sin añada', 'lachinata-core' ) : '';
	}

	/**
	 * Name of the format of a bottle: «75 cl» from the content (`catalog`) or the volume
	 * of the Excel; «75 cl» when nothing says otherwise.
	 *
	 * @param \WC_Product $product Product.
	 * @param string      $volume  Volume of the Excel («750 ml»).
	 */
	public function format_name( \WC_Product $product, string $volume ): string {
		$ml      = null;
		$service = Services::product_content();
		$content = null !== $service ? $service->content( $product ) : null;
		if ( null !== $content ) {
			$ml = Fields::millilitres( $content['amount'], $content['unit'] );
		}
		if ( null === $ml && '' !== $volume ) {
			$ml = Fields::millilitres_of_text( $volume );
		}
		$ml = null !== $ml && $ml > 0 ? $ml : 750.0;
		if ( $ml >= 1000 ) {
			/* translators: %s: litres («1,5»). */
			return sprintf( __( '%s l', 'lachinata-core' ), number_format_i18n( $ml / 1000, fmod( $ml, 1000 ) ? 1 : 0 ) );
		}
		/* translators: %s: centilitres («75»). */
		return sprintf( __( '%s cl', 'lachinata-core' ), number_format_i18n( $ml / 10, fmod( $ml, 10 ) ? 1 : 0 ) );
	}

	/**
	 * Sets the wine type when it has none.
	 *
	 * @param \WC_Product $product Product.
	 * @param string      $color   Colour of the system.
	 */
	private function type( \WC_Product $product, string $color ): bool {
		if ( '' === $color || null !== Fields::type( $product ) ) {
			return false;
		}
		foreach ( $this->terms( Taxonomies::TYPE ) as $term ) {
			if ( Taxonomies::type_color( $term ) === $color ) {
				return $this->set_terms( $product, Taxonomies::TYPE, array( $term->term_id ) );
			}
		}
		$this->report['unmatched'][] = array(
			'id'    => $product->get_id(),
			'name'  => $product->get_name(),
			'field' => __( 'tipo', 'lachinata-core' ),
			'value' => $color,
		);
		return false;
	}

	/**
	 * Sets the making from the written type when it has none.
	 *
	 * @param \WC_Product $product Product.
	 * @param string      $written Written type.
	 */
	private function making( \WC_Product $product, string $written ): bool {
		$slug = DescriptionParser::making( $written );
		if ( '' === $slug || Fields::terms( $product, Taxonomies::MAKING ) ) {
			return false;
		}
		$term = get_term_by( 'slug', $slug, Taxonomies::MAKING );
		return $term instanceof \WP_Term && $this->set_terms( $product, Taxonomies::MAKING, array( $term->term_id ) );
	}

	/**
	 * Sets the origin «España › Región › D.O.» when it has none, creating the terms it
	 * needs. Returns the region (or the country) term id, for the winery.
	 *
	 * @param \WC_Product $product Product.
	 * @param string      $written D.O. as written.
	 */
	private function origin( \WC_Product $product, string $written ): int {
		if ( '' === trim( $written ) ) {
			return 0;
		}
		$found = Origins::find( $written );
		if ( null === $found ) {
			$this->report['unmatched'][] = array(
				'id'    => $product->get_id(),
				'name'  => $product->get_name(),
				'field' => __( 'D.O.', 'lachinata-core' ),
				'value' => $written,
			);
			$found                       = array( trim( (string) preg_replace( '/^(d\.?o\.?(ca|p)?\.?|igp|i\.g\.p\.?)\s*:?\s*/iu', '', trim( $written ) ) ), '' );
		}
		$country = $this->term( Taxonomies::ORIGIN, Origins::COUNTRY, 0 );
		$region  = '' !== $found[1] ? $this->term( Taxonomies::ORIGIN, $found[1], $country ) : 0;
		$leaf    = '' !== $found[0] ? $this->term( Taxonomies::ORIGIN, $found[0], $region ? $region : $country ) : ( $region ? $region : $country );
		if ( ! Fields::terms( $product, Taxonomies::ORIGIN ) && $leaf ) {
			$this->set_terms( $product, Taxonomies::ORIGIN, array( $leaf ) );
		}
		return $region ? $region : $country;
	}

	/**
	 * Sets the winery when it has none, creating its page with the text of the «Bodega»
	 * block and its region.
	 *
	 * @param \WC_Product $product Product.
	 * @param string      $name    Winery as written.
	 * @param string      $text    Text of the block.
	 * @param int         $region  Region term.
	 */
	private function winery( \WC_Product $product, string $name, string $text, int $region ): bool {
		$name = trim( (string) preg_replace( '/\s+/', ' ', $name ), " .\t" );
		if ( '' === $name ) {
			return false;
		}
		$term = $this->term( Taxonomies::WINERY, $name, 0 );
		if ( $term > 0 && ! $this->dry ) {
			$current = get_term( $term, Taxonomies::WINERY );
			if ( $current instanceof \WP_Term && '' === trim( (string) $current->description ) && '' !== $text ) {
				$plain = trim( html_entity_decode( wp_strip_all_tags( str_replace( array( '</p>', '<br>' ), array( "\n\n", "\n" ), $text ) ), ENT_QUOTES ) );
				wp_update_term( $term, Taxonomies::WINERY, array( 'description' => (string) preg_replace( "/\n{3,}/", "\n\n", $plain ) ) );
			}
			if ( $region && ! get_term_meta( $term, Taxonomies::WINERY_ORIGIN, true ) ) {
				update_term_meta( $term, Taxonomies::WINERY_ORIGIN, $region );
			}
		}
		if ( Fields::terms( $product, Taxonomies::WINERY ) || 0 === $term ) {
			return false;
		}
		return $this->set_terms( $product, Taxonomies::WINERY, array( $term ) );
	}

	/**
	 * Sets the grapes with their % when the wine has none.
	 *
	 * @param \WC_Product                                    $product Product.
	 * @param array<int, array{name: string, pct: int|null}> $grapes  Grapes.
	 */
	private function grapes( \WC_Product $product, array $grapes ): bool {
		if ( ! $grapes || Fields::grapes( Fields::get( $product->get_id(), Fields::GRAPES ) ) ) {
			return false;
		}
		$rows = array();
		foreach ( $grapes as $grape ) {
			$term = $this->term( Taxonomies::GRAPE, $grape['name'], 0 );
			if ( $term ) {
				$rows[] = array(
					'term' => $term,
					'pct'  => $grape['pct'],
				);
			}
		}
		if ( ! $rows ) {
			return false;
		}
		if ( ! $this->dry ) {
			update_post_meta( $product->get_id(), Fields::GRAPES, Fields::grapes( $rows ) );
			if ( ! Fields::terms( $product, Taxonomies::GRAPE ) ) {
				wp_set_object_terms( $product->get_id(), array_column( $rows, 'term' ), Taxonomies::GRAPE );
			}
		}
		return true;
	}

	/**
	 * Writes a field when it is empty and the value is not.
	 *
	 * @param \WC_Product $product Product.
	 * @param string      $key     Meta key.
	 * @param mixed       $value   Clean value.
	 */
	private function meta( \WC_Product $product, string $key, $value ): bool {
		if ( empty( $value ) ) {
			return false;
		}
		$current = Fields::get( $product->get_id(), $key );
		if ( ! empty( $current ) ) {
			return false;
		}
		if ( ! $this->dry ) {
			update_post_meta( $product->get_id(), $key, $value );
		}
		return true;
	}

	/**
	 * Fills the tasting notes that are empty.
	 *
	 * @param \WC_Product                                       $product Product.
	 * @param array{sight: string, nose: string, mouth: string} $tasting Tasting read.
	 */
	private function tasting( \WC_Product $product, array $tasting ): bool {
		$current = Fields::tasting( Fields::get( $product->get_id(), Fields::TASTING ) );
		$new     = $current;
		foreach ( $tasting as $key => $text ) {
			if ( '' === $current[ $key ] && '' !== $text ) {
				$new[ $key ] = $text;
			}
		}
		if ( $new === $current ) {
			return false;
		}
		++$this->report['tasting'];
		if ( ! $this->dry ) {
			update_post_meta( $product->get_id(), Fields::TASTING, $new );
		}
		return true;
	}

	/**
	 * Sets the dishes of the pairing sentence when the wine has none.
	 *
	 * @param \WC_Product $product Product.
	 * @param string      $text    Pairing sentence.
	 */
	private function dishes( \WC_Product $product, string $text ): bool {
		if ( '' === $text || Fields::terms( $product, Taxonomies::DISH ) ) {
			return false;
		}
		$ids = array();
		foreach ( DescriptionParser::dishes( $text ) as $slug ) {
			$term = get_term_by( 'slug', $slug, Taxonomies::DISH );
			if ( $term instanceof \WP_Term ) {
				$ids[] = $term->term_id;
			}
		}
		if ( ! $ids ) {
			$this->report['unmatched'][] = array(
				'id'    => $product->get_id(),
				'name'  => $product->get_name(),
				'field' => __( 'maridaje', 'lachinata-core' ),
				'value' => $text,
			);
			return false;
		}
		return $this->set_terms( $product, Taxonomies::DISH, $ids );
	}

	/**
	 * Adds the scores of the text, unpublished and without a vintage, unless the same
	 * critic and points are there.
	 *
	 * @param \WC_Product                                    $product Product.
	 * @param array<int, array{points: int, source: string}> $scores  Scores read.
	 */
	private function scores( \WC_Product $product, array $scores ): bool {
		if ( ! $scores ) {
			return false;
		}
		$rows  = Fields::scores( Fields::get( $product->get_id(), Fields::SCORES ) );
		$added = false;
		foreach ( $scores as $score ) {
			$this->report['scores'][] = array(
				'id'     => $product->get_id(),
				'name'   => $product->get_name(),
				'source' => $score['source'],
				'points' => $score['points'],
				'listed' => null !== Config::source( $score['source'] ),
			);
			foreach ( $rows as $row ) {
				if ( 'score' === $row['kind'] && Config::key( $row['source'] ) === Config::key( $score['source'] ) && $row['points'] === $score['points'] ) {
					continue 2;
				}
			}
			$rows[] = array(
				'kind'      => 'score',
				'source'    => $score['source'],
				'points'    => $score['points'],
				'vintage'   => '',
				'published' => false,
				'note'      => __( 'Del texto de la ficha: falta confirmar la añada.', 'lachinata-core' ),
			);
			$added  = true;
		}
		if ( $added && ! $this->dry ) {
			update_post_meta( $product->get_id(), Fields::SCORES, Fields::scores( $rows ) );
		}
		return $added;
	}

	/**
	 * The description keeps «Viñedo y elaboración» and the blocks it does not know; the
	 * short description loses the tasting, temperature and pairing sentences. Once: the
	 * originals stay in `_lc_bodega_migrado` and a second run does not touch the texts.
	 *
	 * @param \WC_Product          $product Product.
	 * @param array<string, mixed> $parsed  Reading.
	 * @param array<string, mixed> $backup  Backup of a previous run.
	 */
	private function texts( \WC_Product $product, array $parsed, array $backup ): bool {
		if ( isset( $backup['description'] ) || ! $parsed['structured'] ) {
			return false;
		}
		$blocks = array();
		if ( '' !== $parsed['vineyard'] ) {
			$blocks[] = $parsed['vineyard'];
		}
		foreach ( $parsed['other'] as $other ) {
			$blocks[] = ( '' !== $other['title'] ? '<h3>' . esc_html( $other['title'] ) . '</h3>' . "\n\n" : '' ) . $other['html'];
		}
		$tasting = $parsed['tasting'];
		$touched = '' !== $tasting['sight'] . $tasting['nose'] . $tasting['mouth'] . $parsed['pairing'] || $parsed['temperature'];
		++$this->report['described'];
		if ( $this->dry ) {
			return true;
		}
		update_post_meta(
			$product->get_id(),
			Fields::MIGRATED,
			array(
				'at'          => time(),
				'description' => $product->get_description(),
				'excerpt'     => $product->get_short_description(),
			)
		);
		$product = wc_get_product( $product->get_id() );
		if ( ! $product instanceof \WC_Product ) {
			return true;
		}
		$product->set_description( implode( "\n\n", $blocks ) );
		if ( $touched ) {
			$product->set_short_description( (string) $parsed['short'] );
		}
		$product->save();
		return true;
	}

	/**
	 * Turns a simple wine into a variable one with one variation (its vintage and format),
	 * which takes the SKU, GTIN, prices, stock and weight.
	 *
	 * @param \WC_Product $product Simple product.
	 * @param string      $vintage Vintage name, or empty when unknown.
	 * @param string      $format  Format name («75 cl»).
	 */
	private function convert( \WC_Product $product, string $vintage, string $format ): void {
		$vintage_tax = Config::vintage_attribute();
		$format_tax  = Config::format_attribute();
		$id          = $product->get_id();
		if ( '' === $vintage && '' !== $vintage_tax ) {
			$own = wc_get_product_terms( $id, $vintage_tax, array( 'fields' => 'names' ) );
			if ( 1 === count( $own ) ) {
				$vintage = (string) $own[0];
			}
		}
		$label = trim( ( '' !== $vintage ? $vintage : __( 'añada desconocida', 'lachinata-core' ) ) . ' · ' . $format );
		$row   = array(
			'id'      => $id,
			'name'    => $product->get_name(),
			'sku'     => $product->get_sku(),
			'label'   => $label,
			'vintage' => $vintage,
		);
		if ( '' === $vintage ) {
			$this->report['unknown'][] = $row;
		}
		$axes = array();
		if ( '' !== $vintage && '' !== $vintage_tax ) {
			$axes[ $vintage_tax ] = $vintage;
		}
		if ( '' !== $format_tax ) {
			$axes[ $format_tax ] = $format;
		}
		if ( ! $axes ) {
			$row['error']             = __( 'no hay atributo de formato ni añada: crea «Formato» en Productos › Atributos', 'lachinata-core' );
			$this->report['errors'][] = array(
				'id'      => $id,
				'name'    => $product->get_name(),
				'message' => $row['error'],
			);
			return;
		}
		if ( $this->dry ) {
			$this->report['converted'][] = $row;
			return;
		}

		$data = array(
			'sku'        => $product->get_sku(),
			'gtin'       => (string) $product->get_global_unique_id(),
			'regular'    => $product->get_regular_price(),
			'sale'       => $product->get_sale_price(),
			'from'       => $product->get_date_on_sale_from(),
			'to'         => $product->get_date_on_sale_to(),
			'manage'     => $product->get_manage_stock(),
			'quantity'   => $product->get_stock_quantity(),
			'status'     => $product->get_stock_status(),
			'backorders' => $product->get_backorders(),
			'low'        => $product->get_low_stock_amount(),
			'weight'     => $product->get_weight(),
			'length'     => $product->get_length(),
			'width'      => $product->get_width(),
			'height'     => $product->get_height(),
		);
		$product->set_sku( '' );
		$product->set_global_unique_id( '' );
		$product->save();

		wp_set_object_terms( $id, 'variable', 'product_type' );
		\WC_Cache_Helper::invalidate_cache_group( 'product_' . $id );
		wp_cache_delete( $id, 'post_meta' );
		$parent     = new \WC_Product_Variable( $id );
		$attributes = $parent->get_attributes();
		$values     = array();
		foreach ( $axes as $taxonomy => $name ) {
			$term = $this->attribute_term( $taxonomy, $name );
			if ( null === $term ) {
				continue;
			}
			$attribute = $attributes[ $taxonomy ] ?? new \WC_Product_Attribute();
			$attribute->set_id( wc_attribute_taxonomy_id_by_name( $taxonomy ) );
			$attribute->set_name( $taxonomy );
			$attribute->set_options( array_values( array_unique( array_merge( array_map( 'intval', $attribute->get_options() ), array( $term->term_id ) ) ) ) );
			$attribute->set_visible( true );
			$attribute->set_variation( true );
			$attributes[ $taxonomy ] = $attribute;
			$values[ $taxonomy ]     = $term->slug;
		}
		$parent->set_attributes( $attributes );
		$parent->set_manage_stock( false );
		$parent->set_stock_quantity( null );
		$parent->set_regular_price( '' );
		$parent->set_sale_price( '' );
		$parent->set_date_on_sale_from( null );
		$parent->set_date_on_sale_to( null );
		$parent->set_weight( '' );
		$parent->set_length( '' );
		$parent->set_width( '' );
		$parent->set_height( '' );
		$parent->set_default_attributes( $values );
		$parent->save();

		$variation = new \WC_Product_Variation();
		$variation->set_parent_id( $id );
		$variation->set_attributes( $values );
		$variation->set_status( 'publish' );
		$variation->set_sku( $data['sku'] );
		if ( '' !== $data['gtin'] ) {
			$variation->set_global_unique_id( $data['gtin'] );
		}
		$variation->set_regular_price( $data['regular'] );
		$variation->set_sale_price( $data['sale'] );
		$variation->set_date_on_sale_from( $data['from'] );
		$variation->set_date_on_sale_to( $data['to'] );
		$variation->set_manage_stock( $data['manage'] );
		$variation->set_stock_quantity( $data['quantity'] );
		$variation->set_stock_status( $data['status'] );
		$variation->set_backorders( $data['backorders'] );
		$variation->set_low_stock_amount( $data['low'] );
		$variation->set_weight( $data['weight'] );
		$variation->set_length( $data['length'] );
		$variation->set_width( $data['width'] );
		$variation->set_height( $data['height'] );
		$variation_id = $variation->save();
		\WC_Product_Variable::sync( $id );
		wc_delete_product_transients( $id );

		$backup              = get_post_meta( $id, Fields::MIGRATED, true );
		$backup              = is_array( $backup ) ? $backup : array( 'at' => time() );
		$backup['variation'] = $variation_id;
		$backup['vintage']   = $vintage;
		$backup['simple']    = $data['sku'];
		update_post_meta( $id, Fields::MIGRATED, $backup );

		$row['variation']            = $variation_id;
		$this->report['converted'][] = $row;
	}

	/**
	 * Adds the vintage, once known, to a wine converted without it.
	 *
	 * @param \WC_Product $product   Variable product.
	 * @param int         $variation Variation created by the migration.
	 * @param string      $vintage   Vintage name.
	 */
	private function add_vintage( \WC_Product $product, int $variation, string $vintage ): void {
		$taxonomy = Config::vintage_attribute();
		$child    = wc_get_product( $variation );
		if ( '' === $taxonomy || ! $child instanceof \WC_Product_Variation ) {
			return;
		}
		$this->report['vintages'][] = array(
			'id'      => $product->get_id(),
			'name'    => $product->get_name(),
			'vintage' => $vintage,
		);
		if ( $this->dry ) {
			return;
		}
		$term = $this->attribute_term( $taxonomy, $vintage );
		if ( null === $term ) {
			return;
		}
		$parent     = wc_get_product( $product->get_id() );
		$attributes = $parent instanceof \WC_Product ? $parent->get_attributes() : array();
		$attribute  = $attributes[ $taxonomy ] ?? new \WC_Product_Attribute();
		$attribute->set_id( wc_attribute_taxonomy_id_by_name( $taxonomy ) );
		$attribute->set_name( $taxonomy );
		$attribute->set_options( array_values( array_unique( array_merge( array_map( 'intval', $attribute->get_options() ), array( $term->term_id ) ) ) ) );
		$attribute->set_visible( true );
		$attribute->set_variation( true );
		$attributes[ $taxonomy ] = $attribute;
		if ( $parent instanceof \WC_Product ) {
			$parent->set_attributes( $attributes );
			$defaults              = $parent->get_default_attributes();
			$defaults[ $taxonomy ] = $term->slug;
			$parent->set_default_attributes( $defaults );
			$parent->save();
		}
		$values              = $child->get_attributes();
		$values[ $taxonomy ] = $term->slug;
		$child->set_attributes( $values );
		$child->save();
		$backup            = get_post_meta( $product->get_id(), Fields::MIGRATED, true );
		$backup            = is_array( $backup ) ? $backup : array();
		$backup['vintage'] = $vintage;
		update_post_meta( $product->get_id(), Fields::MIGRATED, $backup );
		\WC_Product_Variable::sync( $product->get_id() );
	}

	/**
	 * The term of an attribute by name, created when missing.
	 *
	 * @param string $taxonomy Attribute taxonomy.
	 * @param string $name     Name.
	 */
	private function attribute_term( string $taxonomy, string $name ): ?\WP_Term {
		$name = trim( html_entity_decode( $name, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
		if ( ! taxonomy_exists( $taxonomy ) ) {
			register_taxonomy( $taxonomy, array( 'product', 'product_variation' ) );
		}
		$term = get_term_by( 'name', $name, $taxonomy );
		if ( $term instanceof \WP_Term ) {
			return $term;
		}
		$created = wp_insert_term( $name, $taxonomy );
		if ( is_wp_error( $created ) ) {
			return null;
		}
		$term = get_term( (int) $created['term_id'], $taxonomy );
		return $term instanceof \WP_Term ? $term : null;
	}

	/**
	 * Terms of a taxonomy.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @return \WP_Term[]
	 */
	private function terms( string $taxonomy ): array {
		$terms = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
			)
		);
		return is_array( $terms ) ? array_values( array_filter( $terms, static fn( $term ): bool => $term instanceof \WP_Term ) ) : array();
	}

	/**
	 * A term by name under a parent (case and accents do not matter), created when missing.
	 * In a dry run a missing term is counted and comes back as -1.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @param string $name     Name.
	 * @param int    $under    Parent (0 at the root; ignored in flat taxonomies).
	 */
	private function term( string $taxonomy, string $name, int $under ): int {
		// Names come from HTML («Alonso &amp; Pedrajo»): compared and created as text, so the
		// description and the Excel give the same term (WordPress stores «&» as an entity).
		$name = trim( html_entity_decode( $name, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
		if ( '' === $name ) {
			return 0;
		}
		$key = $under . '|' . self::match_key( $taxonomy, $name );
		if ( isset( $this->created[ $taxonomy ][ $key ] ) ) {
			return $this->created[ $taxonomy ][ $key ];
		}
		$args = array(
			'taxonomy'   => $taxonomy,
			'hide_empty' => false,
		);
		if ( is_taxonomy_hierarchical( $taxonomy ) ) {
			$args['parent'] = max( 0, $under );
		}
		$candidates = get_terms( $args );
		foreach ( is_array( $candidates ) ? $candidates : array() as $term ) {
			if ( $term instanceof \WP_Term && self::match_key( $taxonomy, Taxonomies::name( $term ) ) === self::match_key( $taxonomy, $name ) ) {
				return $term->term_id;
			}
		}
		$this->note_created( $taxonomy, $name );
		if ( $this->dry || $under < 0 ) {
			$this->created[ $taxonomy ][ $key ] = -1;
			return -1;
		}
		$created = wp_insert_term( $name, $taxonomy, is_taxonomy_hierarchical( $taxonomy ) ? array( 'parent' => $under ) : array() );
		if ( is_wp_error( $created ) ) {
			$existing = $created->get_error_data( 'term_exists' );
			return is_numeric( $existing ) ? (int) $existing : 0;
		}
		$this->created[ $taxonomy ][ $key ] = (int) $created['term_id'];
		return (int) $created['term_id'];
	}

	/**
	 * Comparable key of a term's name; a winery is the same with or without «Bodega(s)»
	 * in front.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @param string $name     Name.
	 */
	private static function match_key( string $taxonomy, string $name ): string {
		if ( Taxonomies::WINERY === $taxonomy ) {
			$name = (string) preg_replace( '/^(?:bodegas?|adega|celler)\s+/iu', '', trim( $name ) );
		}
		return Xlsx::key( $name );
	}

	/**
	 * Notes a new term for the report.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @param string $name     Name.
	 */
	private function note_created( string $taxonomy, string $name ): void {
		$bucket = array(
			Taxonomies::WINERY => 'wineries',
			Taxonomies::ORIGIN => 'origins',
			Taxonomies::GRAPE  => 'grapes',
		)[ $taxonomy ] ?? '';
		if ( '' !== $bucket && ! in_array( $name, $this->report[ $bucket ], true ) ) {
			$this->report[ $bucket ][] = $name;
		}
	}

	/**
	 * Sets the terms of a taxonomy (not in a dry run, nor with a term that would be new).
	 *
	 * @param \WC_Product $product  Product.
	 * @param string      $taxonomy Taxonomy.
	 * @param int[]       $ids      Terms.
	 */
	private function set_terms( \WC_Product $product, string $taxonomy, array $ids ): bool {
		$ids = array_values( array_filter( $ids, static fn( int $id ): bool => 0 !== $id ) );
		if ( ! $ids ) {
			return false;
		}
		if ( ! $this->dry && ! in_array( -1, $ids, true ) ) {
			wp_set_object_terms( $product->get_id(), $ids, $taxonomy );
		}
		return true;
	}

	/**
	 * Compares the reading with the sheet «Vinos» (extracted on 29/10 from the same texts).
	 *
	 * @param \WC_Product           $product Product.
	 * @param array<string, string> $vino    Row of the sheet.
	 * @param array<string, mixed>  $parsed  Reading.
	 * @param string                $vintage Vintage decided.
	 */
	private function compare( \WC_Product $product, array $vino, array $parsed, string $vintage ): void {
		$sheet  = $parsed['sheet'];
		$fields = array(
			'Bodega'      => array( Xlsx::cell( $vino, 'Bodega' ), (string) ( $sheet['winery'] ?? '' ) ),
			'D.O.'        => array( Xlsx::cell( $vino, 'D.O.' ), (string) ( $sheet['do'] ?? '' ) ),
			'Tipo'        => array( Xlsx::cell( $vino, 'Tipo' ), (string) ( $sheet['type'] ?? '' ) ),
			'Añada'       => array( self::vintage_name( Xlsx::cell( $vino, 'Añada' ) ), self::vintage_name( (string) ( $sheet['vintage'] ?? '' ) ) ),
			'Grado'       => array( (string) Fields::grade( Xlsx::cell( $vino, 'Grado' ) ), (string) Fields::grade( (string) ( $sheet['grade'] ?? '' ) ) ),
			'Variedades'  => array( Xlsx::cell( $vino, 'Variedades' ), (string) ( $sheet['grapes'] ?? '' ) ),
			'Crianza'     => array( Xlsx::cell( $vino, 'Crianza' ), (string) ( $sheet['ageing'] ?? '' ) ),
			'Viticultura' => array( Xlsx::cell( $vino, 'Viticultura' ), (string) ( $sheet['viticulture'] ?? '' ) ),
			'Temperatura' => array( implode( '-', DescriptionParser::temperature( Xlsx::cell( $vino, 'Temperatura' ) ) ), implode( '-', $parsed['temperature'] ) ),
			'Vista'       => array( Xlsx::cell( $vino, 'Vista' ), $parsed['tasting']['sight'] ),
			'Nariz'       => array( Xlsx::cell( $vino, 'Nariz' ), $parsed['tasting']['nose'] ),
			'Boca'        => array( Xlsx::cell( $vino, 'Boca' ), $parsed['tasting']['mouth'] ),
			'Maridaje'    => array( Xlsx::cell( $vino, 'Maridaje' ), (string) $parsed['pairing'] ),
		);
		foreach ( $fields as $field => $pair ) {
			$excel = Xlsx::key( (string) preg_replace( '/[\s.]+$/u', '', $pair[0] ) );
			$ours  = Xlsx::key( (string) preg_replace( '/[\s.]+$/u', '', $pair[1] ) );
			$same  = $excel === $ours || ( '' !== $excel && '' !== $ours && ( str_starts_with( $ours, $excel ) || str_starts_with( $excel, $ours ) ) );
			if ( ! isset( $this->report['compare'][ $field ] ) ) {
				$this->report['compare'][ $field ] = array(
					'same' => 0,
					'diff' => array(),
				);
			}
			if ( $same ) {
				++$this->report['compare'][ $field ]['same'];
				continue;
			}
			$this->report['compare'][ $field ]['diff'][] = array(
				'id'    => $product->get_id(),
				'name'  => $product->get_name(),
				'excel' => $pair[0],
				'ours'  => $pair[1],
			);
		}
		unset( $vintage );
	}

	/**
	 * The report in Markdown.
	 *
	 * @param array<string, mixed> $report Report of run().
	 */
	public static function markdown( array $report ): string {
		$dry   = ! empty( $report['dry'] );
		$out   = array();
		$out[] = '# Migración de la Bodega' . ( $dry ? ' (en seco)' : '' );
		$out[] = '';
		$out[] = sprintf( 'Generado el %s con `wp lachinata bodega migrate%s`.', wp_date( 'j/n/Y H:i' ), $dry ? ' --dry-run' : '' );
		$out[] = '';
		$out[] = '## Resumen';
		$out[] = '';
		$out[] = '| | |';
		$out[] = '| --- | --- |';
		$out[] = sprintf( '| Vinos leídos | %d |', $report['wines'] );
		$out[] = sprintf( '| Vinos con algún dato nuevo | %d |', $report['filled'] );
		$out[] = sprintf( '| Descripciones reescritas (ficha técnica a campos) | %d |', $report['described'] );
		$out[] = sprintf( '| Vinos con cata sacada de la descripción corta | %d |', $report['tasting'] );
		$out[] = sprintf( '| Vinos simples %s en variables | %d |', $dry ? 'que se convierten' : 'convertidos', count( $report['converted'] ) );
		$out[] = sprintf( '| … de ellos, con la añada desconocida | %d |', count( $report['unknown'] ) );
		$out[] = sprintf( '| Vinos que ya eran variables (no se tocan sus variaciones) | %d |', $report['variable'] );
		$out[] = sprintf( '| Añadas añadidas desde «Para completar» | %d |', count( $report['vintages'] ) );
		$out[] = sprintf( '| Bodegas nuevas | %d |', count( $report['wineries'] ) );
		$out[] = sprintf( '| Orígenes nuevos | %d |', count( $report['origins'] ) );
		$out[] = sprintf( '| Uvas nuevas | %d |', count( $report['grapes'] ) );
		$out[] = sprintf( '| Puntuaciones del texto (sin publicar) | %d |', count( $report['scores'] ) );
		$out[] = sprintf( '| Productos que se saltan (no son vino) | %d |', count( $report['skipped'] ) );
		$out[] = sprintf( '| Errores | %d |', count( $report['errors'] ) );
		$out[] = '';
		$out[] = sprintf( 'Atributos: añada `%s`, formato `%s`.', '' !== $report['attributes']['vintage'] ? $report['attributes']['vintage'] : '(ninguno)', '' !== $report['attributes']['format'] ? $report['attributes']['format'] : '(ninguno)' );
		$out[] = '';

		$out[] = '## Vinos simples ' . ( $dry ? 'que pasan' : 'que han pasado' ) . ' a variables';
		$out[] = '';
		$out[] = 'El producto conserva su ID, su dirección y sus opiniones. El SKU, el GTIN, los precios, el stock y el peso pasan a la variación.';
		$out[] = '';
		if ( $report['converted'] ) {
			$out[] = '| ID | Vino | SKU | Variación |';
			$out[] = '| --- | --- | --- | --- |';
			foreach ( $report['converted'] as $row ) {
				$out[] = sprintf( '| %d | %s | %s | %s%s |', $row['id'], self::cell( $row['name'] ), '' !== $row['sku'] ? $row['sku'] : '—', self::cell( $row['label'] ), isset( $row['variation'] ) ? ' (' . $row['variation'] . ')' : '' );
			}
		} else {
			$out[] = 'Ninguno.';
		}
		$out[] = '';

		$out[] = '## Añadas desconocidas';
		$out[] = '';
		$out[] = 'La variación se crea con su formato. Rellena la añada en `bodega-datos-vinos.xlsx`, hoja «Para completar», y vuelve a ejecutar la migración: la añade a la variación.';
		$out[] = '';
		$out[] = self::list_rows( $report['unknown'], static fn( array $row ): string => sprintf( '%s (%d, SKU %s)', $row['name'], $row['id'], '' !== $row['sku'] ? $row['sku'] : '—' ) );
		$out[] = '';
		if ( $report['vintages'] ) {
			$out[] = '## Añadas añadidas desde el Excel';
			$out[] = '';
			$out[] = self::list_rows( $report['vintages'], static fn( array $row ): string => sprintf( '%s (%d): %s', $row['name'], $row['id'], $row['vintage'] ) );
			$out[] = '';
		}

		foreach ( array(
			'wineries' => 'Bodegas nuevas',
			'origins'  => 'Orígenes nuevos',
			'grapes'   => 'Uvas nuevas',
		) as $key => $title ) {
			$out[] = '## ' . $title;
			$out[] = '';
			$out[] = $report[ $key ] ? implode( ', ', array_map( 'strval', $report[ $key ] ) ) . '.' : 'Ninguna.';
			$out[] = '';
		}

		$out[] = '## Bodegas que pueden estar duplicadas';
		$out[] = '';
		$out[] = 'Solo una propuesta: decide marketing. Se fusionan con «Fusionar con…» en Productos › Bodegas o con `wp lachinata bodega merge-wineries <la que desaparece> <la que se queda>`.';
		$out[] = '';
		$pairs = WineryMerge::duplicates();
		$out[] = $pairs ? implode( "\n", array_map( static fn( array $pair ): string => sprintf( '- %s (%d vinos) / %s (%d vinos)', $pair[0]->name, $pair[0]->count, $pair[1]->name, $pair[1]->count ), $pairs ) ) : 'Ninguna.';
		$out[] = '';

		$out[] = '## Puntuaciones del texto';
		$out[] = '';
		$out[] = 'Entran **sin publicar** y sin añada. Se publican con `wp lachinata bodega import-scores` cuando marketing confirme la añada en `bodega-puntuaciones.xlsx`, o con «Publicar» en el editor.';
		$out[] = '';
		$out[] = self::list_rows( $report['scores'], static fn( array $row ): string => sprintf( '%s (%d): %d %s%s', $row['name'], $row['id'], $row['points'], $row['source'], $row['listed'] ? '' : ' — no está en la lista de críticos' ) );
		$out[] = '';

		$out[] = '## Lo que no se ha reconocido';
		$out[] = '';
		$out[] = self::list_rows( $report['unmatched'], static fn( array $row ): string => sprintf( '%s (%d) · %s: «%s»', $row['name'], $row['id'], $row['field'], mb_substr( (string) $row['value'], 0, 160 ) ) );
		$out[] = '';

		$out[] = '## Bloques que se quedan en la descripción';
		$out[] = '';
		$out[] = 'Títulos que no son ni la ficha técnica, ni «Viñedo y elaboración», ni la bodega: se quedan en la descripción, debajo del viñedo.';
		$out[] = '';
		$out[] = self::list_rows( $report['other'], static fn( array $row ): string => sprintf( '%s (%d): «%s»', $row['name'], $row['id'], $row['title'] ) );
		$out[] = '';

		$out[] = '## Comparación con la hoja «Vinos» del Excel';
		$out[] = '';
		if ( $report['compare'] ) {
			$out[] = '| Campo | Igual | Distinto |';
			$out[] = '| --- | --- | --- |';
			foreach ( $report['compare'] as $field => $data ) {
				$out[] = sprintf( '| %s | %d | %d |', $field, $data['same'], count( $data['diff'] ) );
			}
			$out[] = '';
			foreach ( $report['compare'] as $field => $data ) {
				if ( ! $data['diff'] ) {
					continue;
				}
				$out[] = '### ' . $field;
				$out[] = '';
				$out[] = '| ID | Vino | Excel | Migración |';
				$out[] = '| --- | --- | --- | --- |';
				foreach ( array_slice( $data['diff'], 0, 40 ) as $row ) {
					$out[] = sprintf( '| %d | %s | %s | %s |', $row['id'], self::cell( $row['name'] ), self::cell( mb_substr( (string) $row['excel'], 0, 90 ) ), self::cell( mb_substr( (string) $row['ours'], 0, 90 ) ) );
				}
				if ( count( $data['diff'] ) > 40 ) {
					$out[] = sprintf( '| | … y %d más | | |', count( $data['diff'] ) - 40 );
				}
				$out[] = '';
			}
		} else {
			$out[] = 'Sin Excel (`--xlsx`).';
			$out[] = '';
		}

		$out[] = '## En el Excel y no en la tienda';
		$out[] = '';
		$out[] = self::list_rows( $report['missing'], static fn( array $row ): string => sprintf( '%s (%d)', $row['name'], $row['id'] ) );
		$out[] = '';
		$out[] = '## Se saltan';
		$out[] = '';
		$out[] = self::list_rows( $report['skipped'], static fn( array $row ): string => sprintf( '%s (%d): %s', $row['name'], $row['id'], $row['reason'] ) );
		$out[] = '';
		if ( $report['errors'] ) {
			$out[] = '## Errores';
			$out[] = '';
			$out[] = self::list_rows( $report['errors'], static fn( array $row ): string => sprintf( '%s (%d): %s', $row['name'], $row['id'], $row['message'] ) );
			$out[] = '';
		}
		return implode( "\n", $out );
	}

	/**
	 * A Markdown list, or «Ninguno.».
	 *
	 * @param array<int, array<string, mixed>> $rows   Rows.
	 * @param callable                         $format Row to text.
	 */
	private static function list_rows( array $rows, callable $format ): string {
		if ( ! $rows ) {
			return 'Ninguno.';
		}
		return implode( "\n", array_map( static fn( array $row ): string => '- ' . $format( $row ), $rows ) );
	}

	/**
	 * Text safe in a table cell.
	 *
	 * @param string $text Text.
	 */
	private static function cell( string $text ): string {
		return str_replace( array( '|', "\n" ), array( '\|', ' ' ), $text );
	}
}
