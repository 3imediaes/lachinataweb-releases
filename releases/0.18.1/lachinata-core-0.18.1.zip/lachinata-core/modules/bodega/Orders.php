<?php
/**
 * The case discount and the age box in the order.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * In the order (thank-you page, account, e-mails) the case discount reads «Descuento por
 * caja», without «Cupón» or code, apart from the customer's discounts. Odoo gets it in the
 * `bodega` key of the `lachinata` object, with the age box and the note for the carrier.
 */
final class Orders {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'woocommerce_get_order_item_totals', array( self::class, 'totals' ), 20, 3 );
		Hooks::add_filter( 'lachinata/rest/order', array( self::class, 'rest' ), 10, 2 );
		Hooks::add_filter( 'lachinata/order/discounts', array( self::class, 'summary' ), 10, 3 );
	}

	/**
	 * The case discount of an order (with tax when the prices are shown with it), or 0.
	 *
	 * @param \WC_Order $order       Order.
	 * @param bool      $include_tax Whether with tax.
	 */
	public static function case_discount( \WC_Order $order, bool $include_tax = true ): float {
		$total = 0.0;
		foreach ( $order->get_items( 'coupon' ) as $item ) {
			if ( $item instanceof \WC_Order_Item_Coupon && Cart::CODE === wc_format_coupon_code( $item->get_code() ) ) {
				$total += (float) $item->get_discount() + ( $include_tax ? (float) $item->get_discount_tax() : 0.0 );
			}
		}
		return $total;
	}

	/**
	 * Splits the discount row of the order totals: «Descuento por caja» and, when the
	 * customer had another, «Descuento».
	 *
	 * @param mixed $rows        Rows.
	 * @param mixed $order       Order.
	 * @param mixed $tax_display `incl` or `excl`.
	 * @return mixed
	 */
	public static function totals( $rows, $order, $tax_display = '' ) {
		if ( ! is_array( $rows ) || ! $order instanceof \WC_Order || ! isset( $rows['discount'] ) ) {
			return $rows;
		}
		$include = 'excl' !== ( $tax_display ? $tax_display : get_option( 'woocommerce_tax_display_cart' ) );
		$case    = self::case_discount( $order, $include );
		if ( $case <= 0 ) {
			return $rows;
		}
		$rest = (float) $order->get_total_discount( ! $include ) - $case;
		$new  = array();
		foreach ( $rows as $key => $row ) {
			if ( 'discount' !== $key ) {
				$new[ $key ] = $row;
				continue;
			}
			$new['bodega_case'] = array(
				'label' => __( 'Descuento por caja:', 'lachinata-core' ),
				'value' => '-' . wc_price( $case, array( 'currency' => $order->get_currency() ) ),
			);
			if ( $rest > 0.004 ) {
				$new['discount'] = array(
					'label' => $row['label'],
					'value' => '-' . wc_price( $rest, array( 'currency' => $order->get_currency() ) ),
				);
			}
		}
		return $new;
	}

	/**
	 * Discount lines of the theme's order summary: «Descuento por caja» apart.
	 *
	 * @param mixed $lines Lines (`label`, `amount`).
	 * @param mixed $order Order.
	 * @param mixed $incl  Whether with tax.
	 * @return mixed
	 */
	public static function summary( $lines, $order, $incl = true ) {
		if ( ! is_array( $lines ) || ! $order instanceof \WC_Order ) {
			return $lines;
		}
		$case = self::case_discount( $order, (bool) $incl );
		if ( $case <= 0 ) {
			return $lines;
		}
		$rest = (float) $order->get_total_discount( ! $incl ) - $case;
		$out  = array(
			array(
				'label'  => __( 'Descuento por caja', 'lachinata-core' ),
				'amount' => $case,
			),
		);
		if ( $rest > 0.004 ) {
			$out[] = array(
				'label'  => (string) ( $lines[0]['label'] ?? __( 'Descuento', 'lachinata-core' ) ),
				'amount' => $rest,
			);
		}
		return $out;
	}

	/**
	 * The `bodega` key of the `lachinata` object: the case discount (with tax, as text with
	 * the decimals of the shop), whether the age box was ticked and the note for the
	 * carrier. Null in an order without any of them.
	 *
	 * @param mixed $data  Object.
	 * @param mixed $order Order.
	 * @return mixed
	 */
	public static function rest( $data, $order ) {
		if ( ! is_array( $data ) || ! $order instanceof \WC_Order ) {
			return $data;
		}
		$case    = self::case_discount( $order );
		$age     = $order->get_meta( Checkout::FIELD_META );
		$note    = (string) $order->get_meta( Checkout::NOTE_META );
		$alcohol = Checkout::order_has_alcohol( $order );
		if ( $case <= 0 && '' === (string) $age && '' === $note && ! $alcohol ) {
			return $data;
		}
		$data['bodega'] = array(
			'case_discount' => wc_format_decimal( $case, wc_get_price_decimals() ),
			'alcohol'       => $alcohol,
			'adult'         => in_array( $age, array( true, 1, '1', 'yes', 'true' ), true ),
			'carrier_note'  => '' !== $note ? $note : null,
		);
		return $data;
	}
}
