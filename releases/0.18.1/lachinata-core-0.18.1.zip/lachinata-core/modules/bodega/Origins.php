<?php
/**
 * Spanish wine origins.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

defined( 'ABSPATH' ) || exit;

/**
 * Denominations of origin and wines of the land of Spain with their region, to turn the
 * D.O. written in a description («D.O.Ca. Rioja», «IGP Extremadura», «VT Cádiz») into the
 * origin «España › Región › D.O.». General data of Spain, not of any shop: a name that is
 * not here goes to the report and is created under the country.
 */
final class Origins {

	/**
	 * Name of the country.
	 */
	public const COUNTRY = 'España';

	/**
	 * Canonical name of each origin and its region, by comparable key.
	 *
	 * @return array<string, array{0: string, 1: string}>
	 */
	public static function map(): array {
		$regions = array(
			'Andalucía'            => array( 'Jerez-Xérès-Sherry', 'Manzanilla-Sanlúcar de Barrameda', 'Montilla-Moriles', 'Málaga', 'Sierras de Málaga', 'Condado de Huelva', 'Vino de la Tierra de Cádiz', 'Granada' ),
			'Aragón'               => array( 'Somontano', 'Campo de Borja', 'Calatayud', 'Cariñena' ),
			'Canarias'             => array( 'Valle de la Orotava', 'Valle de Güímar', 'Tacoronte-Acentejo', 'Abona', 'Ycoden-Daute-Isora', 'Lanzarote', 'La Palma', 'El Hierro', 'Gran Canaria', 'La Gomera', 'Islas Canarias' ),
			'Castilla-La Mancha'   => array( 'La Mancha', 'Valdepeñas', 'Méntrida', 'Manchuela', 'Almansa', 'Uclés', 'Ribera del Júcar', 'Mondéjar', 'Vino de la Tierra de Castilla' ),
			'Castilla y León'      => array( 'Ribera del Duero', 'Rueda', 'Toro', 'Bierzo', 'Cigales', 'Arlanza', 'Arribes', 'Tierra de León', 'Tierra del Vino de Zamora', 'Valles de Benavente', 'Cebreros', 'Sierra de Salamanca', 'Valtiendas', 'Vino de la Tierra de Castilla y León' ),
			'Cataluña'             => array( 'Penedès', 'Priorat', 'Montsant', 'Empordà', 'Costers del Segre', 'Conca de Barberà', 'Terra Alta', 'Alella', 'Pla de Bages', 'Tarragona', 'Catalunya', 'Corpinnat', 'Cava', 'Clàssic Penedès' ),
			'Comunidad de Madrid'  => array( 'Vinos de Madrid' ),
			'Comunitat Valenciana' => array( 'Valencia', 'Alicante', 'Utiel-Requena' ),
			'Extremadura'          => array( 'Ribera del Guadiana', 'Vino de la Tierra de Extremadura' ),
			'Galicia'              => array( 'Rías Baixas', 'Ribeira Sacra', 'Ribeiro', 'Valdeorras', 'Monterrei', 'Barbanza e Iria' ),
			'Illes Balears'        => array( 'Binissalem', 'Pla i Llevant', 'Mallorca' ),
			'La Rioja'             => array( 'Rioja' ),
			'Navarra'              => array( 'Navarra' ),
			'País Vasco'           => array( 'Getariako Txakolina', 'Bizkaiko Txakolina', 'Arabako Txakolina' ),
			'Región de Murcia'     => array( 'Jumilla', 'Yecla', 'Bullas' ),
		);
		$map     = array();
		foreach ( $regions as $region => $names ) {
			foreach ( $names as $name ) {
				$map[ self::key( $name ) ] = array( $name, $region );
			}
		}
		$aliases = array(
			'penedes'             => 'Penedès',
			'jerez'               => 'Jerez-Xérès-Sherry',
			'manzanillasanlucar'  => 'Manzanilla-Sanlúcar de Barrameda',
			'sanlucardebarrameda' => 'Manzanilla-Sanlúcar de Barrameda',
			'cadiz'               => 'Vino de la Tierra de Cádiz',
			'extremadura'         => 'Vino de la Tierra de Extremadura',
			'castillayleon'       => 'Vino de la Tierra de Castilla y León',
			'castilla'            => 'Vino de la Tierra de Castilla',
			'vinedosdemadrid'     => 'Vinos de Madrid',
			'madrid'              => 'Vinos de Madrid',
			'larioja'             => 'Rioja',
			'riasbaixas'          => 'Rías Baixas',
			'txakolidegetaria'    => 'Getariako Txakolina',
			'getariakotxakolina'  => 'Getariako Txakolina',
			'bizkaikotxakolina'   => 'Bizkaiko Txakolina',
			'txakolidebizkaia'    => 'Bizkaiko Txakolina',
			'arabakotxakolina'    => 'Arabako Txakolina',
			'barbanzaeiria'       => 'Barbanza e Iria',
			'emporda'             => 'Empordà',
			'conca'               => 'Conca de Barberà',
		);
		foreach ( $aliases as $alias => $name ) {
			$found = $map[ self::key( $name ) ] ?? null;
			if ( null !== $found ) {
				$map[ $alias ] = $found;
			}
		}
		return $map;
	}

	/**
	 * Comparable key of a name: lowercase, without accents, prefixes («D.O.Ca.», «IGP»,
	 * «Vino de la Tierra de»…) or what follows a dash with spaces.
	 *
	 * @param string $name Name.
	 */
	public static function key( string $name ): string {
		$name = trim( html_entity_decode( $name, ENT_QUOTES ) );
		$name = (string) preg_replace( '/\s+[-–]\s+.*$/u', '', $name );
		$name = strtolower( remove_accents( $name ) );
		$name = (string) preg_replace( '/^es-/', '', $name );
		do {
			$before = $name;
			$name   = (string) preg_replace( '/^(d\.?\s*o\.?\s*(ca|p|c)?\.?|denominacion de origen( calificada| protegida)?|i\.?\s*g\.?\s*p\.?|v\.?\s*t\.?|vinos? de la tierra( de)?|vinos? tierra( de)?|ca\.|vino de pago|v\.?\s*p\.?)(?=[\s:.]|$)\s*[:.]?\s*/', '', trim( $name ) );
		} while ( $name !== $before );
		return (string) preg_replace( '/[^a-z0-9]+/', '', $name );
	}

	/**
	 * The origin of a written D.O.: canonical name and region; null when it is not known.
	 * «Vino de España» has no D.O.: the country alone (`['', '']`).
	 *
	 * @param string $written D.O. as written.
	 * @return array{0: string, 1: string}|null
	 */
	public static function find( string $written ): ?array {
		$key = self::key( $written );
		if ( '' === $key ) {
			return null;
		}
		if ( in_array( $key, array( 'espana', 'vinodeespana', 'deespana' ), true ) ) {
			return array( '', '' );
		}
		return self::map()[ $key ] ?? null;
	}
}
