<?php
/**
 * Scores and awards that are shown.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * 10-bodega.md, «Críticos y concursos»: only those of the vintage being seen, published, of a
 * critic or contest of the panel's lists, with 90 points or more and gold medals or better
 * (both thresholds in the panel). At most three: scores first, highest first and, on a tie,
 * in the order of the list; then medals. The rest is kept but not shown. The best published
 * score of the vintages on sale is stored in the product for «Mejor puntuados» and the
 * filter «90 o más».
 */
final class Scores {

	/**
	 * Most badges.
	 */
	public const MAX = 3;

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'woocommerce_after_product_object_save', array( self::class, 'on_save' ) );
	}

	/**
	 * Refreshes the best score of a product when it or one of its variations is saved.
	 *
	 * @param mixed $product Product saved.
	 */
	public static function on_save( $product ): void {
		if ( ! $product instanceof \WC_Product ) {
			return;
		}
		$parent = Fields::parent( $product );
		self::refresh( $parent );
	}

	/**
	 * Stores the best published score of a wine (0 without one).
	 *
	 * @param \WC_Product $product Product.
	 */
	public static function refresh( \WC_Product $product ): void {
		$best    = self::best( $product );
		$current = (int) get_post_meta( $product->get_id(), Fields::BEST, true );
		if ( $best !== $current || '' === get_post_meta( $product->get_id(), Fields::BEST, true ) ) {
			update_post_meta( $product->get_id(), Fields::BEST, $best );
		}
	}

	/**
	 * Best published points among the vintages on sale, or 0.
	 *
	 * @param \WC_Product $product Product.
	 */
	public static function best( \WC_Product $product ): int {
		$active = self::active_vintages( $product );
		$best   = 0;
		foreach ( Fields::scores( Fields::get( $product->get_id(), Fields::SCORES ) ) as $row ) {
			if ( 'score' !== $row['kind'] || ! $row['published'] || ! in_array( $row['vintage'], $active, true ) || null === Config::source( $row['source'] ) ) {
				continue;
			}
			$best = max( $best, $row['points'] );
		}
		return $best;
	}

	/**
	 * Vintages on sale: those of the published variations or, in a product without
	 * variations, those of its attribute.
	 *
	 * @param \WC_Product $product Product.
	 * @return string[] Slugs.
	 */
	public static function active_vintages( \WC_Product $product ): array {
		$taxonomy = Config::vintage_attribute();
		if ( '' === $taxonomy ) {
			return array();
		}
		if ( ! $product->is_type( 'variable' ) ) {
			return array_column( Fields::vintages( $product ), 'slug' );
		}
		$slugs = array();
		foreach ( $product->get_children() as $child_id ) {
			$variation = wc_get_product( $child_id );
			if ( ! $variation instanceof \WC_Product_Variation || 'publish' !== $variation->get_status() ) {
				continue;
			}
			$slug = (string) ( $variation->get_variation_attributes()[ 'attribute_' . $taxonomy ] ?? '' );
			if ( '' !== $slug ) {
				$slugs[] = $slug;
			}
		}
		return array_values( array_unique( $slugs ) );
	}

	/**
	 * Badges of a vintage, as WineScores takes them: `critic` (the short name), `points` or
	 * `medal`, `vintage` (its name).
	 *
	 * @param array<int, array<string, mixed>> $rows    Stored scores and awards.
	 * @param string                           $vintage Slug of the vintage being seen.
	 * @param string                           $name    Name of that vintage («2021»).
	 * @param int                              $max     Most badges.
	 * @return array<int, array{critic: string, points?: int, medal?: string, vintage: string}>
	 */
	public static function visible( array $rows, string $vintage, string $name = '', int $max = self::MAX ): array {
		if ( '' === $vintage ) {
			return array();
		}
		$medals     = Config::medals();
		$worst      = array_search( Config::min_medal(), $medals, true );
		$min_points = Config::min_points();
		$scores     = array();
		$awards     = array();
		foreach ( Fields::scores( $rows ) as $row ) {
			if ( ! $row['published'] || $row['vintage'] !== $vintage ) {
				continue;
			}
			$source = Config::source( $row['source'] );
			if ( null === $source ) {
				continue;
			}
			if ( 'score' === $row['kind'] ) {
				if ( $row['points'] < $min_points ) {
					continue;
				}
				$scores[] = array(
					'critic'   => $source['short'],
					'points'   => $row['points'],
					'vintage'  => '' !== $name ? $name : $vintage,
					'rank'     => $row['points'],
					'position' => $source['position'],
				);
				continue;
			}
			$rank = array_search( $row['medal'], $medals, true );
			if ( false === $rank || false === $worst || $rank > $worst ) {
				continue;
			}
			$awards[] = array(
				'critic'   => $source['short'],
				'medal'    => $row['medal'],
				'vintage'  => '' !== $name ? $name : $vintage,
				'rank'     => -1 * (int) $rank,
				'position' => $source['position'],
			);
		}
		usort( $scores, array( self::class, 'compare' ) );
		usort( $awards, array( self::class, 'compare' ) );
		$list = array_slice( array_merge( $scores, $awards ), 0, max( 0, $max ) );
		return array_map(
			static function ( array $badge ): array {
				unset( $badge['rank'], $badge['position'] );
				return $badge;
			},
			$list
		);
	}

	/**
	 * Order of the badges: highest rank first and, on a tie, the order of the lists.
	 *
	 * @param array{rank: int, position: int} $a A badge.
	 * @param array{rank: int, position: int} $b Another.
	 */
	public static function compare( array $a, array $b ): int {
		$rank = $b['rank'] <=> $a['rank'];
		return 0 !== $rank ? $rank : $a['position'] <=> $b['position'];
	}

	/**
	 * Badges of each vintage of a wine, by slug, for the product page (the selector
	 * switches between them).
	 *
	 * @param \WC_Product $product Product.
	 * @return array<string, array<int, array<string, mixed>>>
	 */
	public static function by_vintage( \WC_Product $product ): array {
		$rows = (array) Fields::get( $product->get_id(), Fields::SCORES );
		$out  = array();
		foreach ( Fields::vintages( $product ) as $vintage ) {
			$badges = self::visible( $rows, $vintage['slug'], $vintage['name'] );
			if ( $badges ) {
				$out[ $vintage['slug'] ] = $badges;
			}
		}
		return $out;
	}

	/**
	 * Highest badge among the vintages on sale, for the card; null without one.
	 *
	 * @param \WC_Product $product Product.
	 * @return array<string, mixed>|null
	 */
	public static function top( \WC_Product $product ): ?array {
		$rows   = (array) Fields::get( $product->get_id(), Fields::SCORES );
		$names  = array_column( Fields::vintages( $product ), 'name', 'slug' );
		$top    = null;
		$weight = -1000;
		foreach ( self::active_vintages( $product ) as $slug ) {
			$badge = self::visible( $rows, $slug, (string) ( $names[ $slug ] ?? $slug ), 1 )[0] ?? null;
			if ( null === $badge ) {
				continue;
			}
			$score = isset( $badge['points'] ) ? (int) $badge['points'] : -100 - (int) array_search( $badge['medal'] ?? '', Config::medals(), true );
			if ( $score > $weight ) {
				$weight = $score;
				$top    = $badge;
			}
		}
		return $top;
	}
}
