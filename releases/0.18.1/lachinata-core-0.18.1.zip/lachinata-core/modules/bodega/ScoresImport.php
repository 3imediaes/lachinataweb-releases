<?php
/**
 * Import of scores and awards.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * `wp lachinata bodega import-scores <file>`: the sheets «Puntuaciones» (Vino, ID, Añada,
 * Crítico, Puntos, ¿Publicar?, Notas) and «Premios» (Vino, ID, Añada, Concurso, Medalla, Año
 * del concurso, ¿Publicar?, Notas) of `bodega-puntuaciones.xlsx`, or a CSV with the same
 * columns (a CSV with «Medalla» is read as awards).
 *
 * - The column ID rules; the example row («Ejemplo…», «no se importa») is left out.
 * - Each row hooks to the vintage of the wine (its term in the vintage attribute); when the
 *   wine does not have that vintage, the row goes to the report.
 * - «¿Publicar?» empty means yes («no», «n», «0» or «false», no).
 * - It can be repeated: the same wine, vintage and critic (or contest) is updated, points
 *   or medal included, not added (a critic or contest appears once per vintage). A score
 *   of the migration without a vintage and with the same points takes the row's vintage.
 * - The critics and contests of the sheet «Listas» that are not on the panel's lists are
 *   added to them.
 */
final class ScoresImport {

	/**
	 * Imports a file.
	 *
	 * @param string $file Path.
	 * @param bool   $dry  Whether nothing is written.
	 * @return array<string, mixed> Report.
	 * @throws \RuntimeException When the file cannot be read.
	 */
	public static function run( string $file, bool $dry ): array {
		$sheets = Xlsx::read( $file );
		$report = array(
			'dry'       => $dry,
			'file'      => basename( $file ),
			'added'     => 0,
			'updated'   => 0,
			'same'      => 0,
			'published' => 0,
			'hidden'    => 0,
			'skipped'   => array(),
			'critics'   => array(),
			'contests'  => array(),
			'products'  => array(),
		);
		$rows   = array();
		if ( isset( $sheets['*'] ) ) {
			$csv  = $sheets['*'];
			$kind = $csv && in_array( 'medalla', array_map( array( Xlsx::class, 'key' ), array_keys( $csv[0] ) ), true ) ? 'award' : 'score';
			foreach ( $csv as $index => $row ) {
				$rows[] = array( $kind, $index + 2, $row );
			}
		} else {
			foreach ( Xlsx::sheet( $sheets, 'Puntuaciones' ) as $index => $row ) {
				$rows[] = array( 'score', $index + 2, $row );
			}
			foreach ( Xlsx::sheet( $sheets, 'Premios' ) as $index => $row ) {
				$rows[] = array( 'award', $index + 2, $row );
			}
			self::lists( Xlsx::sheet( $sheets, 'Listas' ), $dry, $report );
		}

		$pending = array();
		foreach ( $rows as list( $kind, $line, $row ) ) {
			$result = self::row( $kind, $row );
			if ( null === $result ) {
				continue;
			}
			if ( isset( $result['error'] ) ) {
				$report['skipped'][] = array(
					'sheet'  => 'award' === $kind ? 'Premios' : 'Puntuaciones',
					'line'   => $line,
					'wine'   => Xlsx::cell( $row, 'Vino' ),
					'reason' => $result['error'],
				);
				continue;
			}
			$pending[ $result['product'] ][] = $result['score'];
		}

		foreach ( $pending as $product_id => $scores ) {
			$stored  = Fields::scores( Fields::get( (int) $product_id, Fields::SCORES ) );
			$changed = false;
			foreach ( $scores as $score ) {
				$score['published'] ? ++$report['published'] : ++$report['hidden'];
				$match = self::find( $stored, $score );
				if ( null === $match ) {
					$stored[] = $score;
					++$report['added'];
					$changed = true;
					continue;
				}
				$before              = $stored[ $match ];
				$merged              = $before;
				$merged['vintage']   = $score['vintage'];
				$merged['points']    = $score['points'];
				$merged['medal']     = $score['medal'];
				$merged['published'] = $score['published'];
				$merged['year']      = $score['year'] ? $score['year'] : $before['year'];
				$merged['note']      = '' !== $score['note'] ? $score['note'] : $before['note'];
				if ( Fields::scores( array( $merged ) ) === Fields::scores( array( $before ) ) ) {
					++$report['same'];
					continue;
				}
				$stored[ $match ] = $merged;
				++$report['updated'];
				$changed = true;
			}
			if ( $changed ) {
				$report['products'][] = (int) $product_id;
				if ( ! $dry ) {
					update_post_meta( (int) $product_id, Fields::SCORES, Fields::scores( $stored ) );
					$product = wc_get_product( (int) $product_id );
					if ( $product instanceof \WC_Product ) {
						Scores::refresh( $product );
					}
				}
			}
		}
		return $report;
	}

	/**
	 * A row as `{product, score}`, `{error}`, or null when it is empty or the example.
	 *
	 * @param string                $kind `score` or `award`.
	 * @param array<string, string> $row  Row.
	 * @return array<string, mixed>|null
	 */
	public static function row( string $kind, array $row ): ?array {
		$name  = Xlsx::cell( $row, 'Vino' );
		$notes = Xlsx::cell( $row, 'Notas' );
		$id    = absint( Xlsx::cell( $row, 'ID' ) );
		if ( preg_match( '/^ejemplo\b/iu', $name ) || preg_match( '/no se importa/iu', $notes ) ) {
			return null;
		}
		$source = 'award' === $kind ? Xlsx::cell( $row, 'Concurso' ) : Xlsx::cell( $row, 'Crítico' );
		$value  = 'award' === $kind ? Xlsx::cell( $row, 'Medalla' ) : Xlsx::cell( $row, 'Puntos' );
		if ( '' === $source && '' === $value ) {
			return null;
		}
		if ( ! $id ) {
			return array( 'error' => __( 'sin ID', 'lachinata-core' ) );
		}
		$product = wc_get_product( $id );
		if ( ! $product instanceof \WC_Product || $product->is_type( 'variation' ) ) {
			/* translators: %d: product id. */
			return array( 'error' => sprintf( __( 'no hay ningún producto con el ID %d', 'lachinata-core' ), $id ) );
		}
		if ( '' === $source ) {
			return array( 'error' => 'award' === $kind ? __( 'sin concurso', 'lachinata-core' ) : __( 'sin crítico', 'lachinata-core' ) );
		}
		$points = 0;
		if ( 'score' === $kind ) {
			$points = (int) round( (float) str_replace( ',', '.', (string) preg_replace( '/[^\d,.]/', '', $value ) ) );
			if ( $points < 1 || $points > 100 ) {
				/* translators: %s: points as written. */
				return array( 'error' => sprintf( __( 'puntos no válidos: «%s»', 'lachinata-core' ), $value ) );
			}
		} elseif ( '' === $value ) {
			return array( 'error' => __( 'sin medalla', 'lachinata-core' ) );
		}
		$written = Xlsx::cell( $row, 'Añada' );
		if ( '' === $written ) {
			return array( 'error' => __( 'sin añada', 'lachinata-core' ) );
		}
		$vintage = self::vintage( $product, $written );
		if ( null === $vintage ) {
			/* translators: %s: vintage. */
			return array( 'error' => sprintf( __( 'el vino no tiene la añada %s', 'lachinata-core' ), $written ) );
		}
		$publish = strtolower( remove_accents( Xlsx::cell( $row, '¿Publicar?' ) ) );
		$year    = 'award' === $kind ? (int) Xlsx::cell( $row, 'Año del concurso' ) : 0;
		$found   = Config::source( $source );
		return array(
			'product' => $product->get_id(),
			'score'   => array(
				'kind'      => $kind,
				'source'    => null !== $found ? $found['name'] : ( 'score' === $kind ? DescriptionParser::source_name( $source ) : $source ),
				'points'    => $points,
				'medal'     => 'award' === $kind ? self::medal( $value ) : '',
				'vintage'   => $vintage,
				'year'      => $year,
				'published' => ! in_array( $publish, array( 'no', 'n', '0', 'false' ), true ),
				'note'      => $notes,
			),
		);
	}

	/**
	 * Slug of a vintage the wine has, by its name («2021»), or null.
	 *
	 * @param \WC_Product $product Wine.
	 * @param string      $written Vintage as written.
	 */
	public static function vintage( \WC_Product $product, string $written ): ?string {
		$wanted = Migrate::vintage_name( $written );
		$wanted = '' !== $wanted ? $wanted : trim( $written );
		foreach ( Fields::vintages( $product ) as $vintage ) {
			if ( Xlsx::key( $vintage['name'] ) === Xlsx::key( $wanted ) || sanitize_title( $wanted ) === $vintage['slug'] ) {
				return $vintage['slug'];
			}
		}
		return null;
	}

	/**
	 * A medal as the panel's list writes it («oro» → «Oro»).
	 *
	 * @param string $written Medal.
	 */
	private static function medal( string $written ): string {
		foreach ( Config::medals() as $medal ) {
			if ( Xlsx::key( $medal ) === Xlsx::key( $written ) ) {
				return $medal;
			}
		}
		return trim( $written );
	}

	/**
	 * The stored row a new one repeats: same kind, critic (or contest) and vintage; or a
	 * score of the migration without vintage with the same points (or medal).
	 *
	 * @param array<int, array<string, mixed>> $stored Stored rows.
	 * @param array<string, mixed>             $score  New row.
	 */
	private static function find( array $stored, array $score ): ?int {
		$loose = null;
		foreach ( $stored as $index => $row ) {
			if ( $row['kind'] !== $score['kind'] || self::source_key( (string) $row['source'] ) !== self::source_key( (string) $score['source'] ) ) {
				continue;
			}
			if ( '' !== $row['vintage'] && $row['vintage'] === $score['vintage'] ) {
				return (int) $index;
			}
			$same = 'score' === $score['kind'] ? (int) $row['points'] === (int) $score['points'] : Config::key( (string) $row['medal'] ) === Config::key( (string) $score['medal'] );
			if ( $same && '' === $row['vintage'] && null === $loose ) {
				$loose = (int) $index;
			}
		}
		return $loose;
	}

	/**
	 * Comparable name of a critic or contest: its full name when it is on the lists («Parker»
	 * and «Robert Parker Wine Advocate» are the same).
	 *
	 * @param string $source Name as written.
	 */
	private static function source_key( string $source ): string {
		$known = Config::source( $source );
		return Config::key( null !== $known ? $known['name'] : $source );
	}

	/**
	 * Adds to the panel's lists the critics and contests of the sheet «Listas» they lack.
	 *
	 * @param array<int, array<string, string>> $rows   Rows of «Listas».
	 * @param bool                              $dry    Whether nothing is written.
	 * @param array<string, mixed>              $report Report.
	 */
	private static function lists( array $rows, bool $dry, array &$report ): void {
		$critics  = Config::critics();
		$contests = Config::contests();
		foreach ( $rows as $row ) {
			$short = Xlsx::cell( $row, 'Crítico (como se ve)' );
			$full  = Xlsx::cell( $row, 'Nombre completo' );
			if ( '' !== $short || '' !== $full ) {
				$name = '' !== $full ? $full : $short;
				if ( null === Config::source( $name ) && null === Config::source( $short ) ) {
					$critics[]           = array(
						'name'  => $name,
						'short' => '' !== $short ? $short : $name,
					);
					$report['critics'][] = $name;
				}
			}
			$contest = Xlsx::cell( $row, 'Concurso' );
			if ( '' !== $contest && null === Config::source( $contest ) ) {
				$contests[]           = array(
					'name'  => $contest,
					'short' => $contest,
				);
				$report['contests'][] = $contest;
			}
		}
		$module = BodegaModule::instance();
		if ( $dry || null === $module ) {
			return;
		}
		if ( $report['critics'] ) {
			Settings::set( $module, 'critics', $critics );
		}
		if ( $report['contests'] ) {
			Settings::set( $module, 'contests', $contests );
		}
	}

	/**
	 * The report in Markdown.
	 *
	 * @param array<string, mixed> $report Report of run().
	 */
	public static function markdown( array $report ): string {
		$out   = array();
		$out[] = '# Puntuaciones y premios de la Bodega' . ( $report['dry'] ? ' (en seco)' : '' );
		$out[] = '';
		$out[] = sprintf( 'Generado el %s con `wp lachinata bodega import-scores %s%s`.', wp_date( 'j/n/Y H:i' ), $report['file'], $report['dry'] ? ' --dry-run' : '' );
		$out[] = '';
		$out[] = '| | |';
		$out[] = '| --- | --- |';
		$out[] = sprintf( '| Nuevas | %d |', $report['added'] );
		$out[] = sprintf( '| Actualizadas | %d |', $report['updated'] );
		$out[] = sprintf( '| Ya estaban igual | %d |', $report['same'] );
		$out[] = sprintf( '| Publicadas | %d |', $report['published'] );
		$out[] = sprintf( '| Sin publicar | %d |', $report['hidden'] );
		$out[] = sprintf( '| Vinos que cambian | %d |', count( $report['products'] ) );
		$out[] = sprintf( '| Filas que no entran | %d |', count( $report['skipped'] ) );
		$out[] = '';
		if ( $report['critics'] || $report['contests'] ) {
			$out[] = '## Nuevos en las listas del panel';
			$out[] = '';
			if ( $report['critics'] ) {
				$out[] = '- Críticos: ' . implode( ', ', $report['critics'] ) . '.';
			}
			if ( $report['contests'] ) {
				$out[] = '- Concursos: ' . implode( ', ', $report['contests'] ) . '.';
			}
			$out[] = '';
		}
		$out[] = '## Filas que no entran';
		$out[] = '';
		if ( $report['skipped'] ) {
			$out[] = '| Hoja | Fila | Vino | Motivo |';
			$out[] = '| --- | --- | --- | --- |';
			foreach ( $report['skipped'] as $row ) {
				$out[] = sprintf( '| %s | %d | %s | %s |', $row['sheet'], $row['line'], str_replace( '|', '\|', (string) $row['wine'] ), $row['reason'] );
			}
		} else {
			$out[] = 'Ninguna.';
		}
		$out[] = '';
		return implode( "\n", $out );
	}
}
