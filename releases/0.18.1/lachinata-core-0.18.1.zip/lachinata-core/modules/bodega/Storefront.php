<?php
/**
 * What the visitor sees of a wine.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * Data for the theme's holes (theme/HOOKS.md): the wine page in the order of 10-bodega.md
 * (header with scores of the vintage being seen, case selector, age notice, technical
 * sheet, tasting, pairing, the winery and the label), the wine line of the card and the
 * age notice of any product with alcohol. The theme paints the components of the group
 * «Bodega»; without data, no section.
 */
final class Storefront {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/product/wine', array( self::class, 'wine' ), 10, 2 );
		Hooks::add_filter( 'lachinata/product_card/wine', array( self::class, 'card' ), 10, 2 );
		Hooks::add_filter( 'lachinata/product/age_notice', array( self::class, 'age_notice' ), 10, 2 );
		Hooks::add_filter( 'lachinata/product/tint', array( self::class, 'tint' ), 20, 2 );
	}

	/**
	 * Data of the wine page, or null when the product is not a wine.
	 *
	 * @param mixed $wine    Data of other sources.
	 * @param mixed $product Product.
	 * @return mixed
	 */
	public static function wine( $wine, $product ) {
		if ( null !== $wine || ! $product instanceof \WC_Product || ! Fields::is_wine( $product ) ) {
			return $wine;
		}
		$id       = $product->get_id();
		$vintages = Fields::vintages( $product );
		$names    = array_column( $vintages, 'name', 'slug' );
		$current  = self::current_vintage( $product );
		$tasting  = Fields::tasting( Fields::get( $id, Fields::TASTING ) );
		$label    = Fields::label( Fields::get( $id, Fields::LABEL ) );
		$winery   = Fields::term( $product, Taxonomies::WINERY );
		$origin   = Fields::origin( $product );
		$temp     = Fields::temperature( Fields::get( $id, Fields::TEMPERATURE ) );
		$counts   = Fields::counts_for_case( self::default_child( $product ) ?? $product );

		return array(
			'eyebrow'    => implode( ' · ', array_filter( array( Config::category() ? Taxonomies::name( Config::category() ) : __( 'Bodega', 'lachinata-core' ), $origin ? Taxonomies::name( $origin ) : '' ) ) ),
			'subtitle'   => array_values( array_filter( array( $winery ? Taxonomies::name( $winery ) : '', self::type_line( $product ) ) ) ),
			'vintage'    => $current,
			'selected'   => self::default_child( $product ) ? self::default_child( $product )->get_variation_attributes() : array(),
			'vintages'   => $names,
			'scores'     => Scores::by_vintage( $product ),
			'facts'      => self::facts( $product, null, true ),
			'variations' => self::variations( $product ),
			'allergens'  => self::allergens( $label ),
			'tasting'    => array(
				'sight'       => $tasting['sight'],
				'nose'        => $tasting['nose'],
				'mouth'       => $tasting['mouth'],
				'profile'     => Fields::profile( Fields::get( $id, Fields::PROFILE ) ),
				'temperature' => self::temperature_text( $temp ),
			),
			'pairing'    => Pairing::of( $product ),
			'winery'     => $winery ? array_merge( self::winery( $winery ), array( 'products' => self::more_from_winery( $product ) ) ) : null,
			'label'      => '' !== $label['ingredients'] || '' !== $label['nutrition'] || '' !== $label['url'] ? array(
				'ingredients' => $label['ingredients'],
				'nutrition'   => $label['nutrition'],
				'url'         => $label['url'],
			) : null,
			'case'       => $counts || $product->is_type( 'variable' ) ? array_merge(
				array(
					'size'     => Config::CASE_SIZE,
					'discount' => Config::same_discount(),
					'mixed'    => Config::mixed_discount(),
					'href'     => Listing::url(),
					'counts'   => $counts,
				),
				self::case_prices( self::default_child( $product ) ?? $product )
			) : null,
			'age'        => Fields::has_alcohol( $product ) ? Config::text( 'age' ) : '',
		);
	}

	/**
	 * The vintage the page opens with: the default variation's, or the newest on sale.
	 *
	 * @param \WC_Product $product Product.
	 */
	public static function current_vintage( \WC_Product $product ): string {
		$child = self::default_child( $product );
		if ( null !== $child ) {
			$vintage = Fields::vintage_of( $child );
			if ( null !== $vintage ) {
				return $vintage['slug'];
			}
		}
		$active = Scores::active_vintages( $product );
		foreach ( Fields::vintages( $product ) as $vintage ) {
			if ( ! $active || in_array( $vintage['slug'], $active, true ) ) {
				return $vintage['slug'];
			}
		}
		return '';
	}

	/**
	 * The variation the page opens with: the default one or, without a default, the newest
	 * vintage in stock (the 75 cl bottle first). Null in a product without variations.
	 *
	 * @param \WC_Product $product Product.
	 */
	public static function default_child( \WC_Product $product ): ?\WC_Product_Variation {
		if ( ! $product instanceof \WC_Product_Variable ) {
			return null;
		}
		$defaults = $product->get_default_attributes();
		$children = array();
		foreach ( $product->get_children() as $child_id ) {
			$child = wc_get_product( $child_id );
			if ( $child instanceof \WC_Product_Variation && 'publish' === $child->get_status() ) {
				$children[] = $child;
			}
		}
		if ( $defaults ) {
			foreach ( $children as $child ) {
				$match = true;
				foreach ( $defaults as $name => $value ) {
					$own = (string) ( $child->get_variation_attributes()[ 'attribute_' . $name ] ?? '' );
					if ( '' !== $own && (string) $value !== $own ) {
						$match = false;
						break;
					}
				}
				if ( $match ) {
					return $child;
				}
			}
		}
		// Without a default: the newest vintage in stock (then any), the 75 cl bottle first.
		usort(
			$children,
			static function ( \WC_Product_Variation $a, \WC_Product_Variation $b ): int {
				$stock = (int) $b->is_in_stock() <=> (int) $a->is_in_stock();
				if ( 0 !== $stock ) {
					return $stock;
				}
				$vintage = strcmp( (string) ( Fields::vintage_of( $b )['name'] ?? '' ), (string) ( Fields::vintage_of( $a )['name'] ?? '' ) );
				return 0 !== $vintage ? $vintage : (int) Fields::is_standard_bottle( $b ) <=> (int) Fields::is_standard_bottle( $a );
			}
		);
		return $children[0] ?? null;
	}

	/**
	 * «Tinto crianza»: the type and the making.
	 *
	 * @param \WC_Product $product Product.
	 */
	public static function type_line( \WC_Product $product ): string {
		$type   = Fields::type( $product );
		$making = Fields::term( $product, Taxonomies::MAKING );
		if ( null === $type ) {
			return '';
		}
		if ( null === $making ) {
			return Taxonomies::name( $type );
		}
		$lower = function_exists( 'mb_strtolower' ) ? mb_strtolower( Taxonomies::name( $making ) ) : strtolower( Taxonomies::name( $making ) );
		/* translators: 1: wine type («Tinto»), 2: making in lowercase («crianza»). */
		return sprintf( __( '%1$s %2$s', 'lachinata-core' ), Taxonomies::name( $type ), $lower );
	}

	/**
	 * The technical sheet in the order of WineFacts: winery, origin, type and making,
	 * grapes, vintage, strength, ageing, viticulture, serving temperature and volume. A
	 * variation changes the vintage, the strength and the ageing.
	 *
	 * @param \WC_Product      $product   Product.
	 * @param \WC_Product|null $variation Variation, or null for the one the page opens with.
	 * @param bool             $all       Also the rows without value.
	 * @return array<int, array{0: string, 1: string, 2: string}> Label, value and key.
	 */
	public static function facts( \WC_Product $product, ?\WC_Product $variation, bool $all = false ): array {
		$variation = $variation ?? self::default_child( $product ) ?? $product;
		$id        = $product->get_id();
		$winery    = Fields::term( $product, Taxonomies::WINERY );
		$origin    = Fields::origin( $product );
		$vintage   = Fields::vintage_of( $variation );
		$grade     = Fields::grade_of( $variation );
		$viticul   = Fields::viticulture( Fields::get( $id, Fields::VITICULTURE ) );
		$labels    = Fields::viticulture_labels();
		$volume    = self::volume( $variation );
		$rows      = array(
			array( __( 'Bodega', 'lachinata-core' ), $winery ? Taxonomies::name( $winery ) : '', 'winery' ),
			array( __( 'Origen', 'lachinata-core' ), $origin ? implode( ' › ', array_map( static fn( \WP_Term $term ): string => Taxonomies::name( $term ), count( Taxonomies::origin_chain( $origin ) ) > 1 ? array_slice( Taxonomies::origin_chain( $origin ), 1 ) : array( $origin ) ) ) : '', 'origin' ),
			array( __( 'Tipo', 'lachinata-core' ), self::type_line( $product ), 'type' ),
			array( __( 'Uvas', 'lachinata-core' ), self::grapes_text( $product ), 'grapes' ),
			array( __( 'Añada', 'lachinata-core' ), $vintage ? $vintage['name'] : '', 'vintage' ),
			/* translators: %s: alcoholic strength («14,5»). */
			array( __( 'Grado', 'lachinata-core' ), $grade > 0 ? sprintf( __( '%s %% vol.', 'lachinata-core' ), number_format_i18n( $grade, floor( $grade ) === $grade ? 0 : 1 ) ) : '', 'grade' ),
			array( __( 'Crianza', 'lachinata-core' ), Fields::ageing_of( $variation ), 'ageing' ),
			array( __( 'Viticultura', 'lachinata-core' ), implode( ', ', array_map( static fn( string $key ): string => (string) ( $labels[ $key ] ?? $key ), $viticul ) ), 'viticulture' ),
			array( __( 'Temperatura de servicio', 'lachinata-core' ), self::temperature_text( Fields::temperature( Fields::get( $id, Fields::TEMPERATURE ) ) ), 'temperature' ),
			array( __( 'Volumen', 'lachinata-core' ), $volume, 'volume' ),
		);
		return $all ? $rows : array_values( array_filter( $rows, static fn( array $row ): bool => '' !== $row[1] ) );
	}

	/**
	 * What changes with each variation, for the page's script: the vintage, the case flag
	 * and the facts that differ.
	 *
	 * @param \WC_Product $product Product.
	 * @return array<int, array{vintage: string, counts: bool, facts: array<string, string>}>
	 */
	public static function variations( \WC_Product $product ): array {
		if ( ! $product instanceof \WC_Product_Variable ) {
			return array();
		}
		$out = array();
		foreach ( $product->get_children() as $child_id ) {
			$child = wc_get_product( $child_id );
			if ( ! $child instanceof \WC_Product_Variation || 'publish' !== $child->get_status() ) {
				continue;
			}
			$vintage = Fields::vintage_of( $child );
			$facts   = array();
			foreach ( self::facts( $product, $child, true ) as $row ) {
				if ( in_array( $row[2], array( 'vintage', 'grade', 'ageing', 'volume' ), true ) ) {
					$facts[ $row[2] ] = $row[1];
				}
			}
			$out[ $child->get_id() ] = array_merge(
				array(
					'vintage' => $vintage ? $vintage['slug'] : '',
					'name'    => $vintage ? $vintage['name'] : '',
					'counts'  => Fields::counts_for_case( $child ),
					'facts'   => $facts,
				),
				self::case_prices( $child )
			);
		}
		return $out;
	}

	/**
	 * Prices of CaseSelector for a bottle: one bottle, the case of the same wine and what
	 * it saves, as HTML of the shop's currency. The bag calculates the real discount.
	 *
	 * @param \WC_Product $product Product or variation.
	 * @return array{one: string, case: string, save: string}
	 */
	public static function case_prices( \WC_Product $product ): array {
		$price   = (float) wc_get_price_to_display( $product );
		$regular = '' !== $product->get_regular_price() ? (float) wc_get_price_to_display( $product, array( 'price' => $product->get_regular_price() ) ) : $price;
		$full    = $price * Config::CASE_SIZE;
		$case    = round( $full - Config::CASE_SIZE * Cases::saving( $price, $regular, Config::same_discount(), Config::stack_sale() ), wc_get_price_decimals() );
		return array(
			'one'  => wc_price( $price ),
			'case' => wc_price( $case ),
			'save' => wc_price( $full - $case ),
		);
	}

	/**
	 * «90 % Tempranillo, 10 % Graciano».
	 *
	 * @param \WC_Product $product Product.
	 */
	public static function grapes_text( \WC_Product $product ): string {
		$parts = array();
		foreach ( Fields::grapes( Fields::get( $product->get_id(), Fields::GRAPES ) ) as $row ) {
			$term = get_term( $row['term'], Taxonomies::GRAPE );
			if ( ! $term instanceof \WP_Term ) {
				continue;
			}
			/* translators: 1: percentage, 2: grape. */
			$parts[] = null !== $row['pct'] ? sprintf( __( '%1$s %% %2$s', 'lachinata-core' ), number_format_i18n( $row['pct'] ), Taxonomies::name( $term ) ) : Taxonomies::name( $term );
		}
		if ( ! $parts ) {
			$parts = array_map( static fn( \WP_Term $term ): string => Taxonomies::name( $term ), Fields::terms( $product, Taxonomies::GRAPE ) );
		}
		return implode( ', ', $parts );
	}

	/**
	 * «14–16 ºC» or «16 ºC».
	 *
	 * @param int[] $range Temperature.
	 */
	public static function temperature_text( array $range ): string {
		if ( ! $range ) {
			return '';
		}
		if ( $range[0] === $range[1] ) {
			/* translators: %s: temperature in ºC. */
			return sprintf( __( '%s ºC', 'lachinata-core' ), number_format_i18n( $range[0] ) );
		}
		/* translators: 1: lowest temperature, 2: highest temperature, in ºC. */
		return sprintf( __( '%1$s–%2$s ºC', 'lachinata-core' ), number_format_i18n( $range[0] ), number_format_i18n( $range[1] ) );
	}

	/**
	 * Volume of a bottle («75 cl»): its content in `catalog` or its format.
	 *
	 * @param \WC_Product $product Product or variation.
	 */
	public static function volume( \WC_Product $product ): string {
		$service = \LaChinata\Core\Services::product_content();
		$content = null !== $service ? $service->content( $product ) : null;
		if ( null !== $content ) {
			$ml = Fields::millilitres( $content['amount'], $content['unit'] );
			if ( null !== $ml && $ml > 0 ) {
				return $ml >= 1000
					/* translators: %s: litres («1,5»). */
					? sprintf( __( '%s l', 'lachinata-core' ), number_format_i18n( $ml / 1000, fmod( $ml, 1000 ) ? 1 : 0 ) )
					/* translators: %s: centilitres («75»). */
					: sprintf( __( '%s cl', 'lachinata-core' ), number_format_i18n( $ml / 10, fmod( $ml, 10 ) ? 1 : 0 ) );
			}
		}
		return Fields::format_of( $product );
	}

	/**
	 * «sulfitos» and the other allergens of the label, for «Contiene …».
	 *
	 * @param array{ingredients: string, nutrition: string, url: string, sulfites: bool, allergens: string} $label Label.
	 */
	public static function allergens( array $label ): string {
		$list = array();
		if ( $label['sulfites'] ) {
			$list[] = __( 'sulfitos', 'lachinata-core' );
		}
		if ( '' !== $label['allergens'] ) {
			$list[] = $label['allergens'];
		}
		return implode( ', ', $list );
	}

	/**
	 * The winery: name, text, web and the listing of its wines.
	 *
	 * @param \WP_Term $winery Winery.
	 * @return array{name: string, text: string, web: string, href: string, count: int}
	 */
	public static function winery( \WP_Term $winery ): array {
		return array(
			'name'  => Taxonomies::name( $winery ),
			'text'  => (string) $winery->description,
			'web'   => (string) get_term_meta( $winery->term_id, Taxonomies::WINERY_WEB, true ),
			'href'  => Listing::filter_url( 'vino_bodega', $winery->slug ),
			'count' => (int) $winery->count,
		);
	}

	/**
	 * Other wines of the same winery, for «Más vinos de {bodega}» (at most three).
	 *
	 * @param \WC_Product $product Product.
	 * @return \WC_Product[]
	 */
	public static function more_from_winery( \WC_Product $product ): array {
		$winery = Fields::term( $product, Taxonomies::WINERY );
		if ( null === $winery ) {
			return array();
		}
		$ids = get_posts(
			array(
				'post_type'      => 'product',
				'post_status'    => 'publish',
				'posts_per_page' => 3,
				'fields'         => 'ids',
				'post__not_in'   => array( $product->get_id() ),
				'no_found_rows'  => true,
				'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
					array(
						'taxonomy' => Taxonomies::WINERY,
						'terms'    => array( $winery->term_id ),
					),
				),
			)
		);
		return array_values( array_filter( array_map( 'wc_get_product', array_map( 'intval', $ids ) ), static fn( $item ): bool => $item instanceof \WC_Product && $item->is_visible() ) );
	}

	/**
	 * The wine line of the card: type colour, D.O., vintage and the highest badge.
	 *
	 * @param mixed $wine    Data of other sources.
	 * @param mixed $product Product.
	 * @return mixed
	 */
	public static function card( $wine, $product ) {
		if ( null !== $wine || ! $product instanceof \WC_Product || ! Fields::is_wine( $product ) ) {
			return $wine;
		}
		$type     = Fields::type( $product );
		$origin   = Fields::origin( $product );
		$vintages = Fields::vintages( $product );
		$active   = Scores::active_vintages( $product );
		$names    = array();
		foreach ( $vintages as $vintage ) {
			if ( ! $active || in_array( $vintage['slug'], $active, true ) ) {
				$names[] = $vintage['name'];
			}
		}
		return array(
			'type'     => $type ? Taxonomies::type_color( $type ) : '',
			'typeName' => $type ? Taxonomies::name( $type ) : '',
			'origin'   => $origin ? Taxonomies::name( $origin ) : '',
			'vintage'  => 1 === count( $names ) ? $names[0] : '',
			'score'    => Scores::top( $product ),
		);
	}

	/**
	 * The age notice of a product with alcohol (any, not only wines).
	 *
	 * @param mixed $notice  Notice of other sources.
	 * @param mixed $product Product.
	 * @return mixed
	 */
	public static function age_notice( $notice, $product ) {
		if ( '' !== (string) $notice || ! $product instanceof \WC_Product || ! Fields::has_alcohol( $product ) ) {
			return $notice;
		}
		return Config::text( 'age' );
	}

	/**
	 * The Bodega's tint for its products when the category has no other.
	 *
	 * @param mixed $tint    Tint.
	 * @param mixed $product Product.
	 * @return mixed
	 */
	public static function tint( $tint, $product ) {
		if ( '' !== (string) $tint || ! $product instanceof \WC_Product || ! Fields::in_bodega( $product ) ) {
			return $tint;
		}
		return 'bodega';
	}
}
