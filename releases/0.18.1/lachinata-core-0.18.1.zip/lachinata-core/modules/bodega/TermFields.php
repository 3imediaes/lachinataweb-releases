<?php
/**
 * Fields of the wine terms.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * On the screens of Productos › Tipos de vino, Bodegas and Maridajes: the colour of a type
 * (the dot of the card) and its serving temperature by default; the origin, web and logo of
 * a winery (its text is the term's description) with the list of its wines; the store
 * category a dish suggests products from.
 */
final class TermFields {

	private const NONCE = 'lachinata_bodega_term';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		foreach ( array( Taxonomies::TYPE, Taxonomies::WINERY, Taxonomies::DISH ) as $taxonomy ) {
			Hooks::add_action( $taxonomy . '_add_form_fields', array( self::class, 'add_form' ) );
			Hooks::add_action( $taxonomy . '_edit_form_fields', array( self::class, 'edit_form' ) );
			Hooks::add_action( 'created_' . $taxonomy, array( self::class, 'save' ), 10, 2 );
			Hooks::add_action( 'edited_' . $taxonomy, array( self::class, 'save' ), 10, 2 );
		}
		Hooks::add_action( 'admin_enqueue_scripts', array( self::class, 'enqueue' ) );
	}

	/**
	 * The media picker on the wineries' screen.
	 */
	public static function enqueue(): void {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( null === $screen || 'edit-' . Taxonomies::WINERY !== $screen->id ) {
			return;
		}
		wp_enqueue_media();
		wp_add_inline_script(
			'media-editor',
			'document.addEventListener("click",function(e){var b=e.target.closest("[data-lc-logo-choose],[data-lc-logo-remove]");if(!b)return;e.preventDefault();var w=b.closest("[data-lc-logo]"),i=w.querySelector("input"),p=w.querySelector("[data-lc-logo-preview]");if(b.hasAttribute("data-lc-logo-remove")){i.value="";p.innerHTML="";return;}var f=wp.media({multiple:false,library:{type:"image"}});f.on("select",function(){var a=f.state().get("selection").first().toJSON();i.value=a.id;p.innerHTML="<img src=\""+((a.sizes&&a.sizes.thumbnail)||a).url+"\" alt=\"\" style=\"max-width:96px;height:auto\">";});f.open();});'
		);
	}

	/**
	 * Fields of a taxonomy: label, control and help, by name of the field.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @param int    $term_id  Term (0 on the «add» form).
	 * @return array<string, array{0: string, 1: callable, 2: string}>
	 */
	private static function fields( string $taxonomy, int $term_id ): array {
		switch ( $taxonomy ) {
			case Taxonomies::TYPE:
				$term  = $term_id ? get_term( $term_id, Taxonomies::TYPE ) : null;
				$color = $term instanceof \WP_Term ? Taxonomies::color( get_term_meta( $term_id, Taxonomies::TYPE_COLOR, true ) ) : '';
				$temp  = $term_id ? get_term_meta( $term_id, Taxonomies::TYPE_TEMP, true ) : array();
				$temp  = is_array( $temp ) ? Fields::temperature( $temp ) : array();
				return array(
					'lc_bodega_color' => array(
						__( 'Color', 'lachinata-core' ),
						static function () use ( $color ): void {
							echo '<select name="lc_bodega_color" id="lc_bodega_color"><option value="">' . esc_html__( 'Según el nombre', 'lachinata-core' ) . '</option>';
							foreach ( self::color_names() as $value => $label ) {
								printf( '<option value="%1$s"%2$s>%3$s</option>', esc_attr( $value ), selected( $color, $value, false ), esc_html( $label ) );
							}
							echo '</select>';
						},
						__( 'El punto de color de la tarjeta del vino. Sin elegir, se deduce del nombre («Tintos» → tinto).', 'lachinata-core' ),
					),
					'lc_bodega_temp'  => array(
						__( 'Temperatura de servicio de serie', 'lachinata-core' ),
						static function () use ( $temp ): void {
							printf(
								/* translators: 1: lowest temperature field, 2: highest temperature field. */
								esc_html__( 'De %1$s a %2$s ºC', 'lachinata-core' ),
								sprintf( '<input type="number" min="1" max="30" class="small-text" name="lc_bodega_temp[0]" id="lc_bodega_temp" value="%s" aria-label="%s">', esc_attr( (string) ( $temp[0] ?? '' ) ), esc_attr__( 'Desde', 'lachinata-core' ) ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built with esc_attr above.
								sprintf( '<input type="number" min="1" max="30" class="small-text" name="lc_bodega_temp[1]" value="%s" aria-label="%s">', esc_attr( (string) ( $temp[1] ?? '' ) ), esc_attr__( 'Hasta', 'lachinata-core' ) ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built with esc_attr above.
							);
						},
						__( 'La caja «Vino» la propone al elegir este tipo; se puede cambiar en cada vino. Vacía, la habitual de su color.', 'lachinata-core' ),
					),
				);
			case Taxonomies::WINERY:
				$origin = $term_id ? (int) get_term_meta( $term_id, Taxonomies::WINERY_ORIGIN, true ) : 0;
				$web    = $term_id ? (string) get_term_meta( $term_id, Taxonomies::WINERY_WEB, true ) : '';
				$logo   = $term_id ? (int) get_term_meta( $term_id, Taxonomies::WINERY_LOGO, true ) : 0;
				$fields = array(
					'lc_bodega_origin' => array(
						__( 'Origen', 'lachinata-core' ),
						static function () use ( $origin ): void {
							echo '<select name="lc_bodega_origin" id="lc_bodega_origin"><option value="0">' . esc_html__( '—', 'lachinata-core' ) . '</option>';
							foreach ( ProductBox::origins() as $row ) {
								printf( '<option value="%1$d"%2$s>%3$s</option>', (int) $row['id'], selected( $origin, $row['id'], false ), esc_html( $row['label'] ) );
							}
							echo '</select>';
						},
						__( 'Al elegir esta bodega en un vino, la caja «Vino» propone este origen.', 'lachinata-core' ),
					),
					'lc_bodega_web'    => array(
						__( 'Web', 'lachinata-core' ),
						static fn() => printf( '<input type="url" name="lc_bodega_web" id="lc_bodega_web" value="%s" class="regular-text" placeholder="https://">', esc_attr( $web ) ),
						__( 'Opcional.', 'lachinata-core' ),
					),
					'lc_bodega_logo'   => array(
						__( 'Logotipo', 'lachinata-core' ),
						static function () use ( $logo ): void {
							printf(
								'<div data-lc-logo><input type="hidden" name="lc_bodega_logo" id="lc_bodega_logo" value="%1$s"><div data-lc-logo-preview>%2$s</div><p><button type="button" class="button" data-lc-logo-choose>%3$s</button> <button type="button" class="button-link button-link-delete" data-lc-logo-remove>%4$s</button></p></div>',
								esc_attr( $logo ? (string) $logo : '' ),
								$logo ? wp_get_attachment_image( $logo, 'thumbnail', false, array( 'style' => 'max-width:96px;height:auto' ) ) : '',
								esc_html__( 'Elegir imagen', 'lachinata-core' ),
								esc_html__( 'Quitar', 'lachinata-core' )
							);
						},
						__( 'Opcional. El texto de la bodega es la descripción de arriba.', 'lachinata-core' ),
					),
				);
				if ( $term_id ) {
					$fields['lc_bodega_wines'] = array(
						__( 'Sus vinos', 'lachinata-core' ),
						static fn() => self::wines( $term_id ),
						'',
					);
				}
				return $fields;
			case Taxonomies::DISH:
				$category = $term_id ? (int) get_term_meta( $term_id, Taxonomies::DISH_CATEGORY, true ) : 0;
				return array(
					'lc_bodega_category' => array(
						__( 'Categoría para sugerir', 'lachinata-core' ),
						static function () use ( $category ): void {
							wp_dropdown_categories(
								array(
									'taxonomy'          => 'product_cat',
									'name'              => 'lc_bodega_category',
									'id'                => 'lc_bodega_category',
									'selected'          => $category,
									'hide_empty'        => false,
									'hierarchical'      => true,
									'show_option_none'  => __( '—', 'lachinata-core' ),
									'option_none_value' => '0',
								)
							);
						},
						__( 'Si un vino con este plato no tiene productos de maridaje elegidos, la ficha sugiere el más vendido de esta categoría.', 'lachinata-core' ),
					),
				);
		}
		return array();
	}

	/**
	 * Names of the colours.
	 *
	 * @return array<string, string>
	 */
	private static function color_names(): array {
		return array(
			'tinto'    => __( 'Tinto', 'lachinata-core' ),
			'blanco'   => __( 'Blanco', 'lachinata-core' ),
			'rosado'   => __( 'Rosado', 'lachinata-core' ),
			'espumoso' => __( 'Espumoso', 'lachinata-core' ),
			'generoso' => __( 'Generoso', 'lachinata-core' ),
			'dulce'    => __( 'Dulce', 'lachinata-core' ),
		);
	}

	/**
	 * The wines of a winery, with a link to edit each one.
	 *
	 * @param int $term_id Winery.
	 */
	private static function wines( int $term_id ): void {
		$ids = get_posts(
			array(
				'post_type'      => 'product',
				'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
				'posts_per_page' => 100,
				'fields'         => 'ids',
				'orderby'        => 'title',
				'order'          => 'ASC',
				'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
					array(
						'taxonomy' => Taxonomies::WINERY,
						'terms'    => array( $term_id ),
					),
				),
			)
		);
		if ( ! $ids ) {
			echo '<p>' . esc_html__( 'Ningún vino todavía.', 'lachinata-core' ) . '</p>';
			return;
		}
		echo '<ul style="margin:0">';
		foreach ( $ids as $id ) {
			printf( '<li><a href="%1$s">%2$s</a></li>', esc_url( (string) get_edit_post_link( (int) $id ) ), esc_html( get_the_title( (int) $id ) ) );
		}
		echo '</ul>';
	}

	/**
	 * Fields on the «add» form.
	 *
	 * @param mixed $taxonomy Taxonomy.
	 */
	public static function add_form( $taxonomy ): void {
		wp_nonce_field( self::NONCE, self::NONCE . '_nonce' );
		foreach ( self::fields( (string) $taxonomy, 0 ) as $id => [ $label, $control, $help ] ) {
			printf( '<div class="form-field"><label for="%1$s">%2$s</label>', esc_attr( $id ), esc_html( $label ) );
			$control();
			if ( '' !== $help ) {
				echo '<p class="description">' . esc_html( $help ) . '</p>';
			}
			echo '</div>';
		}
	}

	/**
	 * Fields on the «edit» form.
	 *
	 * @param mixed $term Term.
	 */
	public static function edit_form( $term ): void {
		if ( ! $term instanceof \WP_Term ) {
			return;
		}
		wp_nonce_field( self::NONCE, self::NONCE . '_nonce' );
		foreach ( self::fields( $term->taxonomy, $term->term_id ) as $id => [ $label, $control, $help ] ) {
			printf( '<tr class="form-field"><th scope="row"><label for="%1$s">%2$s</label></th><td>', esc_attr( $id ), esc_html( $label ) );
			$control();
			if ( '' !== $help ) {
				echo '<p class="description">' . esc_html( $help ) . '</p>';
			}
			echo '</td></tr>';
		}
	}

	/**
	 * Saves the fields of a term.
	 *
	 * @param mixed $term_id Term.
	 * @param mixed $tt_id   Term taxonomy id.
	 */
	public static function save( $term_id, $tt_id = 0 ): void {
		unset( $tt_id );
		$term_id = (int) $term_id;
		$nonce   = isset( $_POST[ self::NONCE . '_nonce' ] ) ? sanitize_key( wp_unslash( $_POST[ self::NONCE . '_nonce' ] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, self::NONCE ) || ! current_user_can( 'manage_product_terms' ) ) {
			return;
		}
		$term = get_term( $term_id );
		if ( ! $term instanceof \WP_Term ) {
			return;
		}
		$values = array();
		switch ( $term->taxonomy ) {
			case Taxonomies::TYPE:
				$values[ Taxonomies::TYPE_COLOR ] = Taxonomies::color( sanitize_key( wp_unslash( $_POST['lc_bodega_color'] ?? '' ) ) );
				$values[ Taxonomies::TYPE_TEMP ]  = Fields::temperature( array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['lc_bodega_temp'] ?? array() ) ) );
				break;
			case Taxonomies::WINERY:
				$origin                              = absint( $_POST['lc_bodega_origin'] ?? 0 );
				$values[ Taxonomies::WINERY_ORIGIN ] = $origin && get_term( $origin, Taxonomies::ORIGIN ) instanceof \WP_Term ? $origin : 0;
				$values[ Taxonomies::WINERY_WEB ]    = esc_url_raw( wp_unslash( (string) ( $_POST['lc_bodega_web'] ?? '' ) ) );
				$values[ Taxonomies::WINERY_LOGO ]   = absint( $_POST['lc_bodega_logo'] ?? 0 );
				break;
			case Taxonomies::DISH:
				$category                            = absint( $_POST['lc_bodega_category'] ?? 0 );
				$values[ Taxonomies::DISH_CATEGORY ] = $category && get_term( $category, 'product_cat' ) instanceof \WP_Term ? $category : 0;
				break;
		}
		foreach ( $values as $key => $value ) {
			if ( '' === $value || 0 === $value || array() === $value ) {
				delete_term_meta( $term_id, $key );
			} else {
				update_term_meta( $term_id, $key, $value );
			}
		}
	}
}
