<?php
/**
 * Merging two wineries.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * «Fusionar con…» in Productos › Bodegas (and `wp lachinata bodega merge-wineries`): the
 * wines of one winery go to the one that stays, which keeps its texts and data and takes
 * the other's where it has none; the address of the winery that goes away (the listing
 * filtered by it, «?vino_bodega=…») answers with a 301 to the one that stays. Nothing is
 * merged by itself: the list of likely duplicates (the migration's report, `wp lachinata
 * bodega duplicates`) is only a proposal for marketing.
 */
final class WineryMerge {

	/**
	 * Option with the slugs merged: old → the one that stays.
	 */
	public const OPTION = 'lachinata_bodega_merged';

	/**
	 * Action of admin-post.php, also nonce action.
	 */
	private const ACTION = 'lachinata_bodega_merge';

	/**
	 * Words that do not tell two wineries apart, and short forms written both ways.
	 */
	private const GENERIC = array( 'bodega', 'bodegas', 'compania', 'cia', 'vinos', 'vino', 'vinedos', 'finca', 'de', 'do', 'da', 'del', 'dos', 'la', 'las', 'los', 'el', 'y', 'e', 'sl', 'sa', 'sat' );
	private const SHORT   = array(
		'fco'  => 'francisco',
		'hnos' => 'hermanos',
		'sto'  => 'santo',
	);

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'template_redirect', array( self::class, 'redirect' ), 5 );
		if ( is_admin() ) {
			Hooks::add_filter( Taxonomies::WINERY . '_row_actions', array( self::class, 'row_action' ), 10, 2 );
			Hooks::add_action( Taxonomies::WINERY . '_edit_form', array( self::class, 'form' ), 20 );
			Hooks::add_action( 'admin_post_' . self::ACTION, array( self::class, 'handle' ) );
			Hooks::add_action( 'admin_notices', array( self::class, 'notice' ) );
		}
	}

	/**
	 * Words of a winery's name that count: without accents, punctuation or generic words.
	 *
	 * @param string $name Name.
	 * @return string[]
	 */
	public static function words( string $name ): array {
		$plain = Config::key( (string) preg_replace( '/[^\p{L}\p{N}]+/u', ' ', $name ) );
		$words = array();
		$split = preg_split( '/\s+/', $plain );
		foreach ( false === $split ? array() : $split as $word ) {
			$word = self::SHORT[ $word ] ?? $word;
			if ( '' !== $word && ! in_array( $word, self::GENERIC, true ) ) {
				$words[ $word ] = true;
			}
		}
		return array_keys( $words );
	}

	/**
	 * Likely duplicates: same words, or every word of one (two at least) in the other.
	 *
	 * @return array<int, array{0: \WP_Term, 1: \WP_Term}>
	 */
	public static function duplicates(): array {
		$terms = get_terms(
			array(
				'taxonomy'   => Taxonomies::WINERY,
				'hide_empty' => false,
				'orderby'    => 'name',
			)
		);
		$terms = is_array( $terms ) ? array_values( $terms ) : array();
		$words = array();
		foreach ( $terms as $term ) {
			$words[ $term->term_id ] = self::words( Taxonomies::name( $term ) );
		}
		$pairs = array();
		$count = count( $terms );
		for ( $i = 0; $i < $count; $i++ ) {
			for ( $j = $i + 1; $j < $count; $j++ ) {
				$a = $words[ $terms[ $i ]->term_id ];
				$b = $words[ $terms[ $j ]->term_id ];
				if ( ! $a || ! $b ) {
					continue;
				}
				$small = count( $a ) <= count( $b ) ? $a : $b;
				$large = count( $a ) <= count( $b ) ? $b : $a;
				$same  = ! array_diff( $a, $b ) && ! array_diff( $b, $a );
				if ( $same || ( count( $small ) >= 2 && ! array_diff( $small, $large ) ) ) {
					$pairs[] = array( $terms[ $i ], $terms[ $j ] );
				}
			}
		}
		return $pairs;
	}

	/**
	 * Merges a winery into another.
	 *
	 * @param int  $from Winery that goes away.
	 * @param int  $into Winery that stays.
	 * @param bool $dry  Whether nothing is written.
	 * @return array{wines: int[], text: bool, meta: string[]}|\WP_Error
	 */
	public static function merge( int $from, int $into, bool $dry = false ) {
		$old = get_term( $from, Taxonomies::WINERY );
		$new = get_term( $into, Taxonomies::WINERY );
		if ( ! $old instanceof \WP_Term || ! $new instanceof \WP_Term || $from === $into ) {
			return new \WP_Error( 'lachinata_bodega_merge', __( 'Elige dos bodegas distintas.', 'lachinata-core' ) );
		}
		$found  = get_objects_in_term( $from, Taxonomies::WINERY );
		$wines  = is_array( $found ) ? array_map( 'intval', $found ) : array();
		$report = array(
			'wines' => $wines,
			'text'  => '' === trim( $new->description ) && '' !== trim( $old->description ),
			'meta'  => array(),
		);
		foreach ( array( Taxonomies::WINERY_ORIGIN, Taxonomies::WINERY_WEB, Taxonomies::WINERY_LOGO ) as $key ) {
			if ( ! get_term_meta( $into, $key, true ) && get_term_meta( $from, $key, true ) ) {
				$report['meta'][] = $key;
			}
		}
		if ( $dry ) {
			return $report;
		}
		foreach ( $wines as $wine ) {
			wp_set_object_terms( $wine, array( $into ), Taxonomies::WINERY, true );
			wp_remove_object_terms( $wine, array( $from ), Taxonomies::WINERY );
			clean_post_cache( $wine );
		}
		if ( $report['text'] ) {
			wp_update_term( $into, Taxonomies::WINERY, array( 'description' => $old->description ) );
		}
		foreach ( $report['meta'] as $key ) {
			update_term_meta( $into, $key, get_term_meta( $from, $key, true ) );
		}
		$merged = (array) get_option( self::OPTION, array() );
		foreach ( $merged as $slug => $target ) {
			if ( $target === $old->slug ) {
				$merged[ $slug ] = $new->slug;
			}
		}
		$merged[ $old->slug ] = $new->slug;
		update_option( self::OPTION, $merged, false );
		wp_delete_term( $from, Taxonomies::WINERY );
		return $report;
	}

	/**
	 * 301 of the listing filtered by a winery that went away to the one that stays.
	 */
	public static function redirect(): void {
		$merged = (array) get_option( self::OPTION, array() );
		$chosen = Listing::chosen( 'vino_bodega' );
		if ( ! $merged || ! $chosen || ! array_intersect( $chosen, array_keys( $merged ) ) ) {
			return;
		}
		$slugs = array_values( array_unique( array_map( static fn( string $slug ): string => (string) ( $merged[ $slug ] ?? $slug ), $chosen ) ) );
		$url   = add_query_arg( 'vino_bodega', implode( ',', $slugs ), remove_query_arg( 'vino_bodega' ) );
		wp_safe_redirect( $url, 301 );
		exit;
	}

	/**
	 * «Fusionar con…» in the list of wineries.
	 *
	 * @param mixed $actions Row actions.
	 * @param mixed $term    Winery.
	 * @return mixed
	 */
	public static function row_action( $actions, $term ) {
		if ( is_array( $actions ) && $term instanceof \WP_Term && current_user_can( 'manage_product_terms' ) ) {
			$actions['lc_merge'] = sprintf(
				'<a href="%1$s#lc-merge">%2$s</a>',
				esc_url( (string) get_edit_term_link( $term, Taxonomies::WINERY, 'product' ) ),
				esc_html__( 'Fusionar con…', 'lachinata-core' )
			);
		}
		return $actions;
	}

	/**
	 * The merge form under the winery's form.
	 *
	 * @param mixed $term Winery being edited.
	 */
	public static function form( $term ): void {
		if ( ! $term instanceof \WP_Term || ! current_user_can( 'manage_product_terms' ) ) {
			return;
		}
		$others = get_terms(
			array(
				'taxonomy'   => Taxonomies::WINERY,
				'hide_empty' => false,
				'orderby'    => 'name',
				'exclude'    => array( $term->term_id ),
			)
		);
		$likely = array();
		foreach ( self::duplicates() as $pair ) {
			if ( $pair[0]->term_id === $term->term_id ) {
				$likely[] = $pair[1]->term_id;
			} elseif ( $pair[1]->term_id === $term->term_id ) {
				$likely[] = $pair[0]->term_id;
			}
		}
		?>
		<h2 id="lc-merge"><?php esc_html_e( 'Fusionar con…', 'lachinata-core' ); ?></h2>
		<p class="description">
			<?php
			/* translators: %1$s: winery that goes away. */
			echo esc_html( sprintf( __( 'Los vinos de «%1$s» pasan a la bodega que elijas, que conserva sus textos y sus datos (y toma los de esta donde no tenga). «%1$s» desaparece y su dirección lleva a la otra con una 301. No se puede deshacer.', 'lachinata-core' ), Taxonomies::name( $term ) ) );
			?>
		</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return window.confirm(this.dataset.confirm);" data-confirm="<?php echo esc_attr__( '¿Fusionar las dos bodegas? No se puede deshacer.', 'lachinata-core' ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>">
			<input type="hidden" name="from" value="<?php echo esc_attr( (string) $term->term_id ); ?>">
			<?php wp_nonce_field( self::ACTION ); ?>
			<label for="lc-merge-into" class="screen-reader-text"><?php esc_html_e( 'Bodega que se queda', 'lachinata-core' ); ?></label>
			<select id="lc-merge-into" name="into" required>
				<option value=""><?php esc_html_e( 'Bodega que se queda…', 'lachinata-core' ); ?></option>
				<?php foreach ( is_array( $others ) ? $others : array() as $other ) : ?>
					<option value="<?php echo esc_attr( (string) $other->term_id ); ?>">
						<?php
						echo esc_html(
							in_array( $other->term_id, $likely, true )
								/* translators: %s: winery. */
								? sprintf( __( '%s (probable duplicada)', 'lachinata-core' ), Taxonomies::name( $other ) )
								: Taxonomies::name( $other )
						);
						?>
					</option>
				<?php endforeach; ?>
			</select>
			<?php submit_button( __( 'Fusionar', 'lachinata-core' ), 'secondary', 'submit', false ); ?>
		</form>
		<?php
	}

	/**
	 * The result of a merge, on the winery that stays.
	 */
	public static function notice(): void {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only a message.
		$merged = isset( $_GET['lc_merged'] ) ? sanitize_key( wp_unslash( $_GET['lc_merged'] ) ) : '';
		if ( '' === $merged ) {
			return;
		}
		if ( 'error' === $merged ) {
			printf( '<div class="notice notice-error"><p>%s</p></div>', esc_html__( 'Elige dos bodegas distintas.', 'lachinata-core' ) );
			return;
		}
		$count = (int) $merged;
		printf(
			'<div class="notice notice-success"><p>%s</p></div>',
			/* translators: %s: number of wines. */
			esc_html( sprintf( _n( 'Bodegas fusionadas: %s vino ha pasado a esta.', 'Bodegas fusionadas: %s vinos han pasado a esta.', $count, 'lachinata-core' ), number_format_i18n( $count ) ) )
		);
	}

	/**
	 * Merges from the form.
	 */
	public static function handle(): void {
		if ( ! current_user_can( 'manage_product_terms' ) ) {
			wp_die( esc_html__( 'No tienes permiso para fusionar bodegas.', 'lachinata-core' ), 403 );
		}
		check_admin_referer( self::ACTION );
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Checked above.
		$from = isset( $_POST['from'] ) ? absint( wp_unslash( $_POST['from'] ) ) : 0;
		$into = isset( $_POST['into'] ) ? absint( wp_unslash( $_POST['into'] ) ) : 0;
		// phpcs:enable
		$result = self::merge( $from, $into );
		$target = is_wp_error( $result ) ? get_edit_term_link( $from, Taxonomies::WINERY, 'product' ) : get_edit_term_link( $into, Taxonomies::WINERY, 'product' );
		wp_safe_redirect( add_query_arg( 'lc_merged', is_wp_error( $result ) ? 'error' : count( $result['wines'] ), (string) $target ) );
		exit;
	}
}
