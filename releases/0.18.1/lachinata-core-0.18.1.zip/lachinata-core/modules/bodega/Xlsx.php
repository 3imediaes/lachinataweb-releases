<?php
/**
 * A minimal reader of spreadsheets.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

defined( 'ABSPATH' ) || exit;

/**
 * Reads the sheets of an .xlsx (ZipArchive and SimpleXML, no library) or a CSV as rows of
 * text keyed by the header of each column. Shared and inline strings, numbers as written
 * (96, 2021; «96.0» comes back as «96») and empty cells. Rows that are entirely empty are
 * left out; the header is the first row that is not empty.
 */
final class Xlsx {

	/**
	 * Every sheet of a file, by name. A CSV is one sheet called after the file (and also
	 * reachable as «*»).
	 *
	 * @param string $file Path.
	 * @return array<string, array<int, array<string, string>>>
	 * @throws \RuntimeException When the file cannot be read.
	 */
	public static function read( string $file ): array {
		if ( ! is_readable( $file ) ) {
			/* translators: %s: file. */
			throw new \RuntimeException( esc_html( sprintf( __( 'No se puede leer %s.', 'lachinata-core' ), $file ) ) );
		}
		if ( preg_match( '/\.csv$/i', $file ) ) {
			$rows = self::table( self::csv_rows( (string) file_get_contents( $file ) ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- A local file of the command.
			return array(
				basename( $file, '.csv' ) => $rows,
				'*'                       => $rows,
			);
		}
		$sheets = array();
		foreach ( self::raw_sheets( $file ) as $name => $rows ) {
			$sheets[ $name ] = self::table( $rows );
		}
		return $sheets;
	}

	/**
	 * A sheet by name (accents and case do not matter), or an empty list.
	 *
	 * @param array<string, array<int, array<string, string>>> $sheets Sheets.
	 * @param string                                           $name   Name.
	 * @return array<int, array<string, string>>
	 */
	public static function sheet( array $sheets, string $name ): array {
		foreach ( $sheets as $title => $rows ) {
			if ( self::key( (string) $title ) === self::key( $name ) ) {
				return $rows;
			}
		}
		return $sheets['*'] ?? array();
	}

	/**
	 * A cell of a row by its header (the start of the header is enough: «¿Publicar?»
	 * finds «¿Publicar? (vacío = sí)»).
	 *
	 * @param array<string, string> $row    Row.
	 * @param string                $header Header.
	 */
	public static function cell( array $row, string $header ): string {
		$wanted = self::key( $header );
		foreach ( $row as $title => $value ) {
			if ( self::key( (string) $title ) === $wanted ) {
				return trim( $value );
			}
		}
		foreach ( $row as $title => $value ) {
			if ( '' !== $wanted && str_starts_with( self::key( (string) $title ), $wanted ) ) {
				return trim( $value );
			}
		}
		return '';
	}

	/**
	 * Comparable header: lowercase, without accents, punctuation or spaces.
	 *
	 * @param string $text Text.
	 */
	public static function key( string $text ): string {
		$text = strtolower( remove_accents( $text ) );
		return (string) preg_replace( '/[^a-z0-9]+/', '', $text );
	}

	/**
	 * Rows with the first non-empty row as header.
	 *
	 * @param array<int, array<int, string>> $rows Rows as lists of cells.
	 * @return array<int, array<string, string>>
	 */
	public static function table( array $rows ): array {
		$header = null;
		$table  = array();
		foreach ( $rows as $cells ) {
			if ( '' === trim( implode( '', $cells ) ) ) {
				continue;
			}
			if ( null === $header ) {
				$header = array_map( static fn( $title ): string => trim( (string) $title ), $cells );
				continue;
			}
			$row = array();
			foreach ( $header as $index => $title ) {
				if ( '' === $title ) {
					continue;
				}
				$row[ $title ] = trim( (string) ( $cells[ $index ] ?? '' ) );
			}
			$table[] = $row;
		}
		return $table;
	}

	/**
	 * Rows of a CSV (comma or semicolon, whichever the first line uses more).
	 *
	 * @param string $csv Contents.
	 * @return array<int, array<int, string>>
	 */
	public static function csv_rows( string $csv ): array {
		$csv   = (string) preg_replace( '/^\xEF\xBB\xBF/', '', $csv );
		$first = strtok( $csv, "\n" );
		$first = false === $first ? '' : $first;
		$sep   = substr_count( $first, ';' ) > substr_count( $first, ',' ) ? ';' : ',';
		$rows  = array();
		$fh    = fopen( 'php://temp', 'r+' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- In-memory buffer.
		if ( false === $fh ) {
			return array();
		}
		fwrite( $fh, $csv ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite -- In-memory buffer.
		rewind( $fh );
		while ( true ) {
			$cells = fgetcsv( $fh, 0, $sep, '"', '' );
			if ( false === $cells ) {
				break;
			}
			$rows[] = array_map( static fn( $cell ): string => (string) $cell, $cells );
		}
		fclose( $fh ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- In-memory buffer.
		return $rows;
	}

	/**
	 * Cells of every sheet of an .xlsx, by sheet name.
	 *
	 * @param string $file Path.
	 * @return array<string, array<int, array<int, string>>>
	 * @throws \RuntimeException When it is not an .xlsx.
	 */
	private static function raw_sheets( string $file ): array {
		if ( ! class_exists( \ZipArchive::class ) ) {
			throw new \RuntimeException( esc_html( __( 'PHP no tiene ZipArchive: guarda el archivo como CSV.', 'lachinata-core' ) ) );
		}
		$zip = new \ZipArchive();
		if ( true !== $zip->open( $file ) ) {
			/* translators: %s: file. */
			throw new \RuntimeException( esc_html( sprintf( __( '%s no es un .xlsx.', 'lachinata-core' ), $file ) ) );
		}
		$strings = array();
		$shared  = $zip->getFromName( 'xl/sharedStrings.xml' );
		if ( false !== $shared ) {
			$xml = simplexml_load_string( $shared );
			if ( false !== $xml ) {
				foreach ( $xml->si as $item ) {
					$strings[] = self::text( $item );
				}
			}
		}
		$targets = array();
		$rels    = $zip->getFromName( 'xl/_rels/workbook.xml.rels' );
		if ( false !== $rels ) {
			$xml = simplexml_load_string( $rels );
			if ( false !== $xml ) {
				foreach ( $xml->Relationship as $rel ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- XML element.
					$target                         = (string) $rel['Target'];
					$targets[ (string) $rel['Id'] ] = str_starts_with( $target, '/' ) ? ltrim( $target, '/' ) : 'xl/' . $target;
				}
			}
		}
		$sheets   = array();
		$workbook = $zip->getFromName( 'xl/workbook.xml' );
		$xml      = false === $workbook ? false : simplexml_load_string( $workbook );
		if ( false === $xml ) {
			$zip->close();
			/* translators: %s: file. */
			throw new \RuntimeException( esc_html( sprintf( __( '%s no es un .xlsx.', 'lachinata-core' ), $file ) ) );
		}
		foreach ( $xml->sheets->sheet as $sheet ) {
			$attributes                        = $sheet->attributes( 'http://schemas.openxmlformats.org/officeDocument/2006/relationships' );
			$id                                = null !== $attributes ? (string) $attributes['id'] : '';
			$path                              = $targets[ $id ] ?? '';
			$contents                          = '' !== $path ? $zip->getFromName( $path ) : false;
			$sheets[ (string) $sheet['name'] ] = false === $contents ? array() : self::cells( $contents, $strings );
		}
		$zip->close();
		return $sheets;
	}

	/**
	 * Cells of a sheet, by row and column (0-based, gaps filled with '').
	 *
	 * @param string   $contents XML of the sheet.
	 * @param string[] $strings  Shared strings.
	 * @return array<int, array<int, string>>
	 */
	private static function cells( string $contents, array $strings ): array {
		$xml = simplexml_load_string( $contents );
		if ( false === $xml || ! isset( $xml->sheetData ) ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- XML element.
			return array();
		}
		$rows = array();
		foreach ( $xml->sheetData->row as $row ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- XML element.
			$cells = array();
			$next  = 0;
			foreach ( $row->c as $cell ) {
				$ref    = (string) $cell['r'];
				$column = '' !== $ref ? self::column( $ref ) : $next;
				$type   = (string) $cell['t'];
				if ( 's' === $type ) {
					$value = (string) ( $strings[ (int) $cell->v ] ?? '' );
				} elseif ( 'inlineStr' === $type ) {
					$value = isset( $cell->is ) ? self::text( $cell->is ) : '';
				} elseif ( 'b' === $type ) {
					$value = '1' === (string) $cell->v ? '1' : '0';
				} else {
					$value = (string) $cell->v;
					if ( is_numeric( $value ) && floor( (float) $value ) === (float) $value && abs( (float) $value ) < 1e15 ) {
						$value = (string) (int) $value;
					}
				}
				$cells[ $column ] = $value;
				$next             = $column + 1;
			}
			$list = array();
			$max  = $cells ? max( array_keys( $cells ) ) : -1;
			for ( $i = 0; $i <= $max; $i++ ) {
				$list[] = $cells[ $i ] ?? '';
			}
			$rows[] = $list;
		}
		return $rows;
	}

	/**
	 * Text of a string item (plain or with runs).
	 *
	 * @param \SimpleXMLElement $item Item.
	 */
	private static function text( \SimpleXMLElement $item ): string {
		if ( isset( $item->t ) ) {
			return (string) $item->t;
		}
		$text = '';
		foreach ( $item->r as $run ) {
			$text .= (string) $run->t;
		}
		return $text;
	}

	/**
	 * Column index of a reference («AB12» → 27).
	 *
	 * @param string $ref Reference.
	 */
	private static function column( string $ref ): int {
		$letters = (string) preg_replace( '/[^A-Z]/', '', strtoupper( $ref ) );
		$index   = 0;
		$length  = strlen( $letters );
		for ( $i = 0; $i < $length; $i++ ) {
			$index = $index * 26 + ( ord( $letters[ $i ] ) - 64 );
		}
		return $index - 1;
	}
}
