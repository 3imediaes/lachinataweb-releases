/**
 * The case discount of the Bodega in the blocks cart and checkout: it reads «Descuento por
 * caja», without «Cupón» or code, and without the «x» to remove it. It is the virtual coupon
 * the module puts on the bag: nobody types it or takes it away.
 *
 * The blocks' `coupons` filter only changes the label (or leaves the coupon out of the list,
 * and with it the words «Descuento por caja»), so the «x» of that chip is hidden with CSS,
 * found by its accessible name, which carries our label.
 */
import { __ } from '@wordpress/i18n';

const settings = window.lcBodegaCheckout || {};
const blocks = window.wc?.blocksCheckout;
const LABEL = __('Descuento por caja', 'lachinata-core');

if (blocks?.registerCheckoutFilters && settings.code) {
	blocks.registerCheckoutFilters('lachinata-bodega', {
		coupons: (coupons) =>
			coupons.map((coupon) =>
				coupon.code === settings.code
					? { ...coupon, label: LABEL }
					: coupon
			),
	});

	const style = document.createElement('style');
	style.id = 'lachinata-bodega-case-chip';
	style.textContent = `.wc-block-components-totals-discount__coupon-list-item .wc-block-components-chip__remove[aria-label*="${LABEL.replace(/["\\]/g, '\\$&')}"] { display: none; }`;
	document.head.append(style);
}
