/**
 * «Vino» box of the product editor (10-bodega.md, «Edición en el panel»): an ordered card
 * in five tabs (Ficha, Cata, Añadas y puntuaciones, Maridaje, Etiqueta), the state of the
 * card on top and a preview of the page's header on wide screens. The whole state lives in
 * the hidden field `lc_bodega_data` and is saved with the product (ProductBox::save()).
 * Defaults fill, never block; warnings never stop the product from saving.
 */
import apiFetch from '@wordpress/api-fetch';
import {
	Button,
	CheckboxControl,
	ComboboxControl,
	Notice,
	SelectControl,
	Spinner,
	TextControl,
	TextareaControl,
} from '@wordpress/components';
import {
	createRoot,
	render,
	useEffect,
	useMemo,
	useRef,
	useState,
} from '@wordpress/element';
import { __, _n, sprintf } from '@wordpress/i18n';

import './editor.css';

const settings = window.lcBodegaEditor || {};
const TASTING_MAX = 240;

const TABS = () => [
	{ name: 'ficha', title: __('Ficha', 'lachinata-core') },
	{ name: 'cata', title: __('Cata', 'lachinata-core') },
	{ name: 'anadas', title: __('Añadas y puntuaciones', 'lachinata-core') },
	{ name: 'maridaje', title: __('Maridaje', 'lachinata-core') },
	{ name: 'etiqueta', title: __('Etiqueta', 'lachinata-core') },
];

const PROFILE = () => [
	[
		'body',
		__('Ligero', 'lachinata-core'),
		__('Con cuerpo', 'lachinata-core'),
	],
	[
		'oak',
		__('Sin madera', 'lachinata-core'),
		__('Mucha madera', 'lachinata-core'),
	],
	['sweet', __('Seco', 'lachinata-core'), __('Dulce', 'lachinata-core')],
	[
		'acid',
		__('Suave', 'lachinata-core'),
		__('Fresco y ácido', 'lachinata-core'),
	],
];

const temperatureText = (range) => {
	const [from, to] = range || [];
	if (!number(from)) {
		return '';
	}
	return from === to ? `${from} ºC` : `${from}–${to} ºC`;
};
const byId = (list, id) => (list || []).find((item) => item.id === id);
const newId = () => Math.random().toString(36).slice(2, 12);
const lower = (text) => String(text || '').toLowerCase();
const key = (text) => lower(text).normalize('NFD').replace(/[̀-ͯ]/g, '');
const number = (value) => {
	const parsed = parseFloat(String(value).replace(',', '.'));
	return Number.isFinite(parsed) ? parsed : 0;
};

/**
 * The twelve checks of «Completa N de 12», the same as Fields::completeness().
 *
 * @param {Object} v        State.
 * @param {Array}  vintages Vintages of the product.
 */
const completeness = (v, vintages) => {
	const t = v.tasting || {};
	const l = v.label || {};
	const checks = [
		['winery', 'ficha', __('bodega', 'lachinata-core'), !!v.winery],
		['origin', 'ficha', __('origen', 'lachinata-core'), !!v.origin],
		['type', 'ficha', __('tipo', 'lachinata-core'), !!v.type],
		['making', 'ficha', __('elaboración', 'lachinata-core'), !!v.making],
		[
			'grapes',
			'ficha',
			__('uvas', 'lachinata-core'),
			(v.grapes || []).some((g) => g.term),
		],
		['grade', 'ficha', __('grado', 'lachinata-core'), number(v.grade) > 0],
		[
			'ageing',
			'ficha',
			__('crianza', 'lachinata-core'),
			!!String(v.ageing || '').trim(),
		],
		[
			'temperature',
			'ficha',
			__('temperatura', 'lachinata-core'),
			number((v.temperature || [])[0]) > 0,
		],
		[
			'tasting',
			'cata',
			__('cata', 'lachinata-core'),
			!!(t.sight && t.nose && t.mouth),
		],
		[
			'vintage',
			'anadas',
			__('añada', 'lachinata-core'),
			vintages.length > 0,
		],
		[
			'pairing',
			'maridaje',
			__('maridaje', 'lachinata-core'),
			(v.dishes || []).length > 0 || (v.pairing || []).length > 0,
		],
		[
			'label',
			'etiqueta',
			__('ingredientes', 'lachinata-core'),
			!!(l.ingredients || l.url),
		],
	];
	return {
		done: checks.filter((c) => c[3]).length,
		total: checks.length,
		missing: checks.filter((c) => !c[3]),
	};
};

/**
 * Badges shown for a vintage, with the rules of Scores::visible().
 *
 * @param {Array}  scores  Scores and awards.
 * @param {string} vintage Slug of the vintage.
 */
const visibleBadges = (scores, vintage) => {
	const medals = settings.medals || [];
	const worst = medals.indexOf(settings.minMedal);
	const sources = [
		...(settings.critics || []).map((c, i) => ({ ...c, i })),
		...(settings.contests || []).map((c, i) => ({ ...c, i })),
	];
	const source = (name) =>
		sources.find(
			(s) => key(s.name) === key(name) || key(s.short) === key(name)
		);
	const list = (scores || [])
		.filter((s) => s.published && s.vintage === vintage && source(s.source))
		.filter((s) =>
			s.kind === 'award'
				? medals.indexOf(s.medal) !== -1 &&
					worst !== -1 &&
					medals.indexOf(s.medal) <= worst
				: number(s.points) >= (settings.minPoints || 0)
		)
		.map((s) => ({
			...s,
			short: source(s.source).short,
			rank:
				s.kind === 'award'
					? -1000 - medals.indexOf(s.medal)
					: number(s.points),
			pos: source(s.source).i,
		}));
	list.sort((a, b) => b.rank - a.rank || a.pos - b.pos);
	return list.slice(0, 3);
};

const Badge = ({ score }) => (
	<span
		className={`lcb-score${score.kind === 'award' ? ' lcb-score--medal' : ''}`}
	>
		<b>{score.kind === 'award' ? score.medal : score.points}</b>
		<span>{score.short || score.source}</span>
	</span>
);

/**
 * A row of buttons that work as a choice (one or several).
 *
 * @param {Object}              props          Props.
 * @param {string}              props.label    Label.
 * @param {Array}               props.options  `{value, label}`.
 * @param {number|string|Array} props.value    Value (an array when multiple).
 * @param {Function}            props.onChange Change.
 * @param {boolean}             props.multiple Several at once.
 */
const Choice = ({ label, options, value, onChange, multiple = false }) => {
	const on = (option) =>
		multiple ? (value || []).includes(option) : value === option;
	const toggle = (option) => {
		if (multiple) {
			onChange(
				on(option)
					? value.filter((item) => item !== option)
					: [...(value || []), option]
			);
			return;
		}
		const none = typeof option === 'number' ? 0 : '';
		onChange(on(option) ? none : option);
	};
	return (
		<fieldset className="lcb-field">
			<legend className="lcb-label">{label}</legend>
			<div className="lcb-choice">
				{options.map((option) => (
					<Button
						key={option.value}
						variant={on(option.value) ? 'primary' : 'secondary'}
						className={on(option.value) ? 'is-on' : undefined}
						aria-pressed={on(option.value)}
						onClick={() => toggle(option.value)}
						__next40pxDefaultSize
					>
						{option.label}
					</Button>
				))}
			</div>
		</fieldset>
	);
};

const Ficha = ({ v, set, lists, setLists }) => {
	const [newWinery, setNewWinery] = useState(null);
	const [grapeQuery, setGrapeQuery] = useState({});
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState('');
	const type = byId(settings.types, v.type);
	const winery = byId(lists.wineries, v.winery);
	const wineryOrigin =
		winery && winery.origin ? byId(settings.origins, winery.origin) : null;
	const grapes = v.grapes || [];
	const withPct = grapes.filter(
		(g) => g.pct !== null && g.pct !== '' && g.pct !== undefined
	);
	const sum = withPct.reduce((total, g) => total + number(g.pct), 0);

	const chooseType = (id) => {
		const chosen = byId(settings.types, id);
		const next = { type: id };
		if (chosen && chosen.temp && !number((v.temperature || [])[0])) {
			next.temperature = chosen.temp;
		}
		set(next);
	};
	const chooseWinery = (id) => {
		const chosen = byId(lists.wineries, Number(id) || 0);
		const next = { winery: Number(id) || 0 };
		if (chosen && chosen.origin && !v.origin) {
			next.origin = chosen.origin;
		}
		set(next);
	};
	const createWinery = async () => {
		if (!newWinery || !newWinery.name.trim()) {
			return;
		}
		setBusy(true);
		setError('');
		try {
			const created = await apiFetch({
				path: '/lachinata/v1/bodega/wineries',
				method: 'POST',
				data: { name: newWinery.name, origin: newWinery.origin || 0 },
			});
			setLists({
				...lists,
				wineries: [
					...lists.wineries.filter((w) => w.id !== created.id),
					created,
				],
			});
			set({
				winery: created.id,
				origin: v.origin || created.origin || 0,
			});
			setNewWinery(null);
		} catch (e) {
			setError(
				e.message ||
					__('No se ha podido crear la bodega.', 'lachinata-core')
			);
		}
		setBusy(false);
	};
	const createGrape = async (index, name) => {
		if (!name.trim()) {
			return;
		}
		setBusy(true);
		setError('');
		try {
			const created = await apiFetch({
				path: '/lachinata/v1/bodega/grapes',
				method: 'POST',
				data: { name: name.trim() },
			});
			setLists({
				...lists,
				grapes: [
					...lists.grapes.filter((g) => g.id !== created.id),
					created,
				],
			});
			if (!grapes.some((g) => g.term === created.id)) {
				set({
					grapes: grapes.map((g, i) =>
						i === index ? { ...g, term: created.id } : g
					),
				});
			}
			setGrapeQuery({ ...grapeQuery, [index]: '' });
		} catch (e) {
			setError(
				e.message ||
					__('No se ha podido crear la uva.', 'lachinata-core')
			);
		}
		setBusy(false);
	};
	const setGrape = (index, change) =>
		set({
			grapes: grapes.map((g, i) =>
				i === index ? { ...g, ...change } : g
			),
		});
	const originOptions = settings.origins.map((o) => ({
		value: String(o.id),
		label: o.label,
	}));

	return (
		<div className="lcb-panel">
			{error && (
				<Notice status="error" onRemove={() => setError('')}>
					{error}
				</Notice>
			)}
			<div className="lcb-field">
				<ComboboxControl
					label={__('Bodega', 'lachinata-core')}
					value={v.winery ? String(v.winery) : null}
					options={lists.wineries.map((w) => ({
						value: String(w.id),
						label: w.name,
					}))}
					onChange={chooseWinery}
					help={
						wineryOrigin && v.origin && v.origin !== wineryOrigin.id
							? sprintf(
									/* translators: %s: origin of the winery. */
									__(
										'Esta bodega es de %s.',
										'lachinata-core'
									),
									wineryOrigin.label
								)
							: undefined
					}
					__next40pxDefaultSize
					__nextHasNoMarginBottom
				/>
				{wineryOrigin && v.origin !== wineryOrigin.id && (
					<Button
						variant="link"
						onClick={() => set({ origin: wineryOrigin.id })}
					>
						{sprintf(
							/* translators: %s: origin of the winery. */
							__('Usar su origen: %s', 'lachinata-core'),
							wineryOrigin.name
						)}
					</Button>
				)}
				{null === newWinery ? (
					<Button
						variant="link"
						onClick={() =>
							setNewWinery({ name: '', origin: v.origin || 0 })
						}
					>
						{__('+ Nueva bodega', 'lachinata-core')}
					</Button>
				) : (
					<div className="lcb-inline">
						<TextControl
							label={__('Nombre de la bodega', 'lachinata-core')}
							value={newWinery.name}
							onChange={(name) =>
								setNewWinery({ ...newWinery, name })
							}
							__next40pxDefaultSize
							__nextHasNoMarginBottom
						/>
						<ComboboxControl
							label={__('Región', 'lachinata-core')}
							value={
								newWinery.origin
									? String(newWinery.origin)
									: null
							}
							options={originOptions}
							onChange={(id) =>
								setNewWinery({
									...newWinery,
									origin: Number(id) || 0,
								})
							}
							__next40pxDefaultSize
							__nextHasNoMarginBottom
						/>
						<Button
							variant="primary"
							onClick={createWinery}
							disabled={busy}
							isBusy={busy}
						>
							{__('Crear bodega', 'lachinata-core')}
						</Button>
						<Button
							variant="tertiary"
							onClick={() => setNewWinery(null)}
						>
							{__('Cancelar', 'lachinata-core')}
						</Button>
					</div>
				)}
			</div>

			<div className="lcb-field">
				<ComboboxControl
					label={__('Origen', 'lachinata-core')}
					value={v.origin ? String(v.origin) : null}
					options={originOptions}
					onChange={(id) => set({ origin: Number(id) || 0 })}
					help={__(
						'Escribe la D.O. o la región («Ribera del Guadiana») y elige la más concreta: el país y la región van con ella.',
						'lachinata-core'
					)}
					__next40pxDefaultSize
					__nextHasNoMarginBottom
				/>
				<a
					className="lcb-small"
					href={`${settings.termsUrl}lc_origen`}
					target="_blank"
					rel="noreferrer"
				>
					{__('Gestionar orígenes', 'lachinata-core')}
				</a>
			</div>

			<Choice
				label={__('Tipo', 'lachinata-core')}
				options={settings.types.map((t) => ({
					value: t.id,
					label: t.name,
				}))}
				value={v.type}
				onChange={chooseType}
			/>
			<Choice
				label={__('Elaboración', 'lachinata-core')}
				options={settings.makings.map((m) => ({
					value: m.id,
					label: m.name,
				}))}
				value={v.making}
				onChange={(making) => set({ making })}
			/>
			<Choice
				label={__('Viticultura', 'lachinata-core')}
				options={settings.viticulture.map((m) => ({
					value: m.key,
					label: m.name,
				}))}
				value={v.viticulture || []}
				onChange={(viticulture) => set({ viticulture })}
				multiple
			/>

			<fieldset className="lcb-field">
				<legend className="lcb-label">
					{__('Uvas', 'lachinata-core')}
				</legend>
				{grapes.map((row, index) => (
					<div className="lcb-grape" key={index}>
						<ComboboxControl
							label={__('Uva', 'lachinata-core')}
							hideLabelFromVision
							value={row.term ? String(row.term) : null}
							options={[
								...lists.grapes
									.filter(
										(g) =>
											g.id === row.term ||
											!grapes.some(
												(other, i) =>
													i !== index &&
													other.term === g.id
											)
									)
									.map((g) => ({
										value: String(g.id),
										label: g.name,
									})),
								...((grapeQuery[index] || '').trim() &&
								!lists.grapes.some(
									(g) =>
										key(g.name) ===
										key(grapeQuery[index].trim())
								)
									? [
											{
												value: `new:${grapeQuery[index].trim()}`,
												label: sprintf(
													/* translators: %s: name of the new grape. */
													__(
														'Crear «%s»',
														'lachinata-core'
													),
													grapeQuery[index].trim()
												),
											},
										]
									: []),
							]}
							onFilterValueChange={(query) =>
								setGrapeQuery({
									...grapeQuery,
									[index]: query,
								})
							}
							onChange={(id) => {
								if (String(id || '').startsWith('new:')) {
									createGrape(index, String(id).slice(4));
									return;
								}
								setGrape(index, { term: Number(id) || 0 });
							}}
							__next40pxDefaultSize
							__nextHasNoMarginBottom
						/>
						<TextControl
							label={__('Porcentaje', 'lachinata-core')}
							hideLabelFromVision
							type="number"
							min={1}
							max={100}
							value={row.pct ?? ''}
							onChange={(pct) =>
								setGrape(index, {
									pct: pct === '' ? null : Number(pct),
								})
							}
							__next40pxDefaultSize
							__nextHasNoMarginBottom
						/>
						<span aria-hidden="true">%</span>
						<Button
							variant="tertiary"
							isDestructive
							onClick={() =>
								set({
									grapes: grapes.filter(
										(g, i) => i !== index
									),
								})
							}
						>
							{__('Quitar', 'lachinata-core')}
						</Button>
					</div>
				))}
				<div className="lcb-inline">
					<Button
						variant="secondary"
						onClick={() =>
							set({ grapes: [...grapes, { term: 0, pct: null }] })
						}
					>
						{__('+ Uva', 'lachinata-core')}
					</Button>
					{withPct.length > 0 && (
						<span
							className={`lcb-sum${Math.round(sum) === 100 ? ' is-ok' : ' is-warn'}`}
							role="status"
						>
							{Math.round(sum) === 100
								? __('Suma: 100 %', 'lachinata-core')
								: sprintf(
										/* translators: %s: sum of the percentages. */
										__(
											'Suma: %s %% (no llega a 100 %%; se guarda igual)',
											'lachinata-core'
										),
										Math.round(sum)
									)}
						</span>
					)}
				</div>
				<p className="lcb-help">
					{__(
						'El porcentaje es opcional. Si la uva no está en la lista, escríbela y elige «Crear».',
						'lachinata-core'
					)}
				</p>
			</fieldset>

			<div className="lcb-row">
				<TextControl
					label={__('Grado (% vol.)', 'lachinata-core')}
					type="text"
					inputMode="decimal"
					placeholder="14,5"
					value={v.grade ? String(v.grade).replace('.', ',') : ''}
					onChange={(grade) => set({ grade })}
					__next40pxDefaultSize
					__nextHasNoMarginBottom
				/>
				<TextControl
					label={__('Crianza', 'lachinata-core')}
					value={v.ageing || ''}
					placeholder={__(
						'12 meses en barrica de roble francés',
						'lachinata-core'
					)}
					onChange={(ageing) => set({ ageing })}
					__next40pxDefaultSize
					__nextHasNoMarginBottom
				/>
			</div>
			<fieldset className="lcb-field">
				<legend className="lcb-label">
					{__('Temperatura de servicio', 'lachinata-core')}
				</legend>
				<div className="lcb-inline">
					<span>{__('de', 'lachinata-core')}</span>
					<TextControl
						label={__('Desde (ºC)', 'lachinata-core')}
						hideLabelFromVision
						type="number"
						min={1}
						max={30}
						value={(v.temperature || [])[0] || ''}
						onChange={(from) =>
							set({
								temperature: [
									Number(from) || 0,
									(v.temperature || [])[1] ||
										Number(from) ||
										0,
								],
							})
						}
						__next40pxDefaultSize
						__nextHasNoMarginBottom
					/>
					<span>{__('a', 'lachinata-core')}</span>
					<TextControl
						label={__('Hasta (ºC)', 'lachinata-core')}
						hideLabelFromVision
						type="number"
						min={1}
						max={30}
						value={(v.temperature || [])[1] || ''}
						onChange={(to) =>
							set({
								temperature: [
									(v.temperature || [])[0] || Number(to) || 0,
									Number(to) || 0,
								],
							})
						}
						__next40pxDefaultSize
						__nextHasNoMarginBottom
					/>
					<span>ºC</span>
					{type && type.temp && (
						<Button
							variant="link"
							onClick={() => set({ temperature: type.temp })}
						>
							{sprintf(
								/* translators: 1: wine type, 2: lowest, 3: highest temperature. */
								__(
									'Propuesta para %1$s: %2$s–%3$s ºC',
									'lachinata-core'
								),
								lower(type.name),
								type.temp[0],
								type.temp[1]
							)}
						</Button>
					)}
				</div>
			</fieldset>
		</div>
	);
};

const Cata = ({ v, set }) => {
	const tasting = v.tasting || {};
	const profile = v.profile || {};
	const has = Object.keys(profile).length > 0;
	const notes = [
		[
			'sight',
			__('Vista', 'lachinata-core'),
			__('Rojo rubí con ribete violáceo.', 'lachinata-core'),
		],
		[
			'nose',
			__('Nariz', 'lachinata-core'),
			__('Fruta negra, regaliz y un fondo mineral.', 'lachinata-core'),
		],
		[
			'mouth',
			__('Boca', 'lachinata-core'),
			__('Estructurado y fresco, con final balsámico.', 'lachinata-core'),
		],
	];
	return (
		<div className="lcb-panel">
			<div className="lcb-notes">
				{notes.map(([name, label, example]) => {
					const text = tasting[name] || '';
					return (
						<TextareaControl
							key={name}
							label={label}
							value={text}
							rows={3}
							placeholder={sprintf(
								/* translators: %s: example text. */
								__('Por ejemplo: %s', 'lachinata-core'),
								example
							)}
							help={sprintf(
								/* translators: 1: characters written, 2: suggested limit. */
								__(
									'%1$s de %2$s caracteres. Una o dos frases.',
									'lachinata-core'
								),
								text.length,
								TASTING_MAX
							)}
							className={
								text.length > TASTING_MAX ? 'is-long' : ''
							}
							onChange={(value) =>
								set({ tasting: { ...tasting, [name]: value } })
							}
							__nextHasNoMarginBottom
						/>
					);
				})}
			</div>
			<fieldset className="lcb-field">
				<legend className="lcb-label">
					{__('Perfil', 'lachinata-core')}
				</legend>
				<CheckboxControl
					label={__('Sin perfil (no se pinta)', 'lachinata-core')}
					checked={!has}
					onChange={(none) =>
						set({
							profile: none
								? {}
								: { body: 3, oak: 3, sweet: 1, acid: 3 },
						})
					}
					__nextHasNoMarginBottom
				/>
				{has &&
					PROFILE().map(([name, from, to]) => (
						<div
							className="lcb-profile"
							key={name}
							role="radiogroup"
							aria-label={`${from} – ${to}`}
						>
							<span className="lcb-small">{from}</span>
							{[1, 2, 3, 4, 5].map((level) => (
								<button
									type="button"
									key={level}
									role="radio"
									aria-checked={profile[name] === level}
									aria-label={sprintf(
										/* translators: 1: low end, 2: high end, 3: level. */
										__(
											'%1$s a %2$s: %3$s de 5',
											'lachinata-core'
										),
										from,
										to,
										level
									)}
									className={`lcb-dot${(profile[name] || 0) >= level ? ' is-on' : ''}`}
									onClick={() =>
										set({
											profile: {
												...profile,
												[name]: level,
											},
										})
									}
								/>
							))}
							<span className="lcb-small">{to}</span>
						</div>
					))}
			</fieldset>
		</div>
	);
};

const ScoreRow = ({ row, onChange, onRemove, vintages, taken = [] }) => {
	const award = row.kind === 'award';
	const list = award ? settings.contests : settings.critics;
	const known = list.some(
		(s) =>
			key(s.name) === key(row.source) || key(s.short) === key(row.source)
	);
	const options = [
		...(known || !row.source
			? []
			: [
					{
						value: row.source,
						label: sprintf(
							/* translators: %s: name not on the panel's lists. */
							__(
								'%s (no está en la lista: no se pinta)',
								'lachinata-core'
							),
							row.source
						),
					},
				]),
		{
			value: '',
			label: award
				? __('Concurso…', 'lachinata-core')
				: __('Crítico…', 'lachinata-core'),
		},
		...list.map((s) => ({
			value: s.name,
			label: s.short !== s.name ? `${s.short} · ${s.name}` : s.name,
			// A critic or contest once per vintage.
			disabled:
				taken.includes(key(s.name)) || taken.includes(key(s.short)),
		})),
	];
	const selected = known
		? list.find(
				(s) =>
					key(s.name) === key(row.source) ||
					key(s.short) === key(row.source)
			).name
		: row.source;
	return (
		<div className={`lcb-score-row${row.published ? '' : ' is-draft'}`}>
			<SelectControl
				label={
					award
						? __('Concurso', 'lachinata-core')
						: __('Crítico', 'lachinata-core')
				}
				hideLabelFromVision
				value={selected}
				options={options}
				onChange={(source) => onChange({ source })}
				__next40pxDefaultSize
				__nextHasNoMarginBottom
			/>
			{award ? (
				<>
					<SelectControl
						label={__('Medalla', 'lachinata-core')}
						hideLabelFromVision
						value={row.medal || ''}
						options={[
							{
								value: '',
								label: __('Medalla…', 'lachinata-core'),
							},
							...settings.medals.map((m) => ({
								value: m,
								label: m,
							})),
						]}
						onChange={(medal) => onChange({ medal })}
						__next40pxDefaultSize
						__nextHasNoMarginBottom
					/>
					<TextControl
						label={__('Año del concurso', 'lachinata-core')}
						hideLabelFromVision
						placeholder={__('Año', 'lachinata-core')}
						type="number"
						value={row.year || ''}
						onChange={(year) =>
							onChange({ year: Number(year) || 0 })
						}
						__next40pxDefaultSize
						__nextHasNoMarginBottom
					/>
				</>
			) : (
				<TextControl
					label={__('Puntos', 'lachinata-core')}
					hideLabelFromVision
					placeholder={__('Puntos', 'lachinata-core')}
					type="number"
					min={1}
					max={100}
					value={row.points || ''}
					onChange={(points) =>
						onChange({ points: Number(points) || 0 })
					}
					__next40pxDefaultSize
					__nextHasNoMarginBottom
				/>
			)}
			{vintages && (
				<SelectControl
					label={__('Añada', 'lachinata-core')}
					hideLabelFromVision
					value={row.vintage || ''}
					options={[
						{
							value: '',
							label: __('¿De qué añada?', 'lachinata-core'),
						},
						...vintages.map((x) => ({
							value: x.slug,
							label: x.name,
						})),
					]}
					onChange={(vintage) => onChange({ vintage })}
					__next40pxDefaultSize
					__nextHasNoMarginBottom
				/>
			)}
			{row.published ? (
				<Button
					variant="tertiary"
					onClick={() => onChange({ published: false })}
				>
					{__('Ocultar', 'lachinata-core')}
				</Button>
			) : (
				<>
					<span className="lcb-draft">
						{__('Sin publicar', 'lachinata-core')}
					</span>
					<Button
						variant="secondary"
						disabled={!row.vintage}
						onClick={() => onChange({ published: true })}
					>
						{__('Publicar', 'lachinata-core')}
					</Button>
				</>
			)}
			<Button variant="tertiary" isDestructive onClick={onRemove}>
				{__('Quitar', 'lachinata-core')}
			</Button>
			{row.note && <span className="lcb-small lcb-note">{row.note}</span>}
		</div>
	);
};

const Anadas = ({ v, set, vintages, setVintages }) => {
	const [year, setYear] = useState('');
	const [busy, setBusy] = useState(false);
	const [message, setMessage] = useState(null);
	const scores = v.scores || [];
	const slugs = vintages.map((x) => x.slug);
	const orphans = scores.filter((s) => !slugs.includes(s.vintage));

	const update = (id, change) =>
		set({
			scores: scores.map((s) => (s.id === id ? { ...s, ...change } : s)),
		});
	const remove = (id) => set({ scores: scores.filter((s) => s.id !== id) });
	const add = (vintage, kind) =>
		set({
			scores: [
				...scores,
				{
					id: newId(),
					kind,
					source: '',
					points: 0,
					medal: '',
					vintage,
					year: 0,
					published: true,
					note: '',
				},
			],
		});

	const createVintage = async () => {
		setBusy(true);
		setMessage(null);
		try {
			const result = await apiFetch({
				path: `/lachinata/v1/bodega/products/${settings.productId}/vintages`,
				method: 'POST',
				data: { vintage: year.trim() },
			});
			setVintages([
				result.vintage,
				...vintages.filter((x) => x.slug !== result.vintage.slug),
			]);
			setYear('');
			setMessage({
				status: 'success',
				text: sprintf(
					/* translators: %s: vintage. */
					__(
						'Añada %s creada como variación, con el precio, el peso y el formato de la anterior. Revisa su precio y su stock en «Variaciones».',
						'lachinata-core'
					),
					result.vintage.name
				),
			});
			if (window.jQuery) {
				window.jQuery('#woocommerce-product-data').trigger('reload');
			}
		} catch (e) {
			setMessage({
				status: 'error',
				text:
					e.message ||
					__('No se ha podido crear la añada.', 'lachinata-core'),
			});
		}
		setBusy(false);
	};

	const block = (vintage) => {
		const rows = scores.filter((s) => s.vintage === vintage.slug);
		const badges = visibleBadges(scores, vintage.slug);
		return (
			<section className="lcb-vintage" key={vintage.slug}>
				<header>
					<h4>{vintage.name}</h4>
					<div
						className="lcb-badges"
						aria-label={__(
							'Así se verá en la ficha',
							'lachinata-core'
						)}
					>
						{badges.length ? (
							badges.map((b) => <Badge key={b.id} score={b} />)
						) : (
							<span className="lcb-small">
								{__(
									'Sin insignias en la ficha',
									'lachinata-core'
								)}
							</span>
						)}
					</div>
				</header>
				{rows.map((row) => (
					<ScoreRow
						key={row.id}
						row={row}
						taken={rows
							.filter(
								(other) =>
									other.id !== row.id &&
									other.kind === row.kind &&
									other.source
							)
							.map((other) => key(other.source))}
						onChange={(c) => update(row.id, c)}
						onRemove={() => remove(row.id)}
					/>
				))}
				<div className="lcb-inline">
					<Button
						variant="secondary"
						onClick={() => add(vintage.slug, 'score')}
					>
						{__('+ Puntuación', 'lachinata-core')}
					</Button>
					<Button
						variant="secondary"
						onClick={() => add(vintage.slug, 'award')}
					>
						{__('+ Premio', 'lachinata-core')}
					</Button>
				</div>
			</section>
		);
	};

	return (
		<div className="lcb-panel">
			{!settings.attribute && (
				<Notice status="warning" isDismissible={false}>
					{__(
						'No hay atributo de añada. Elígelo en WooCommerce → La Chinata → Bodega para poder enganchar las puntuaciones a su añada.',
						'lachinata-core'
					)}
				</Notice>
			)}
			{message && (
				<Notice
					status={message.status}
					onRemove={() => setMessage(null)}
				>
					{message.text}
				</Notice>
			)}
			<p className="lcb-help">
				{sprintf(
					/* translators: 1: points, 2: medal. */
					__(
						'En la ficha salen, de la añada que se ve, las puntuaciones de %1$s o más y las medallas de %2$s o mejores; como mucho tres.',
						'lachinata-core'
					),
					settings.minPoints,
					lower(settings.minMedal)
				)}
			</p>
			{vintages.length === 0 && (
				<p>
					{__(
						'Este vino aún no tiene añadas. Crea la primera abajo.',
						'lachinata-core'
					)}
				</p>
			)}
			{vintages.map(block)}
			{orphans.length > 0 && (
				<section className="lcb-vintage is-orphan">
					<header>
						<h4>{__('Sin añada confirmada', 'lachinata-core')}</h4>
					</header>
					<p className="lcb-help">
						{__(
							'Vienen de la migración o de la hoja de puntuaciones sin una añada que exista en el vino. Elige su añada y publícalas.',
							'lachinata-core'
						)}
					</p>
					{orphans.map((row) => (
						<ScoreRow
							key={row.id}
							row={row}
							vintages={vintages}
							onChange={(c) => update(row.id, c)}
							onRemove={() => remove(row.id)}
						/>
					))}
				</section>
			)}
			<div className="lcb-inline lcb-new-vintage">
				<TextControl
					label={__('Nueva añada', 'lachinata-core')}
					value={year}
					placeholder="2024"
					onChange={setYear}
					help={__(
						'Cuatro cifras, o «Sin añada». Se crea al momento como variación, copiando el precio, el peso y el formato de la última.',
						'lachinata-core'
					)}
					__next40pxDefaultSize
					__nextHasNoMarginBottom
				/>
				<Button
					variant="primary"
					onClick={createVintage}
					disabled={
						busy ||
						!settings.productId ||
						!year.trim() ||
						!settings.attribute
					}
					isBusy={busy}
				>
					{__('Nueva añada', 'lachinata-core')}
				</Button>
			</div>
			{!settings.variable && (
				<p className="lcb-help">
					{__(
						'Las añadas son variaciones: el vino tiene que ser un «Producto variable» guardado.',
						'lachinata-core'
					)}
				</p>
			)}
		</div>
	);
};

const Maridaje = ({ v, set }) => {
	const [search, setSearch] = useState('');
	const [results, setResults] = useState([]);
	const [loading, setLoading] = useState(false);
	const pairing = v.pairing || [];
	const timer = useRef(null);

	useEffect(() => {
		clearTimeout(timer.current);
		if (search.trim().length < 2) {
			setResults([]);
			return undefined;
		}
		timer.current = setTimeout(async () => {
			setLoading(true);
			try {
				const found = await apiFetch({
					path: `/lachinata/v1/bodega/products?search=${encodeURIComponent(search.trim())}&exclude=${settings.productId}`,
				});
				setResults(found || []);
			} catch {
				setResults([]);
			}
			setLoading(false);
		}, 300);
		return () => clearTimeout(timer.current);
	}, [search]);

	const full = pairing.length >= 3;
	return (
		<div className="lcb-panel">
			<Choice
				label={__('Platos', 'lachinata-core')}
				options={settings.dishes.map((d) => ({
					value: d.id,
					label: d.name,
				}))}
				value={v.dishes || []}
				onChange={(dishes) => set({ dishes })}
				multiple
			/>
			<fieldset className="lcb-field">
				<legend className="lcb-label">
					{__('Productos de la tienda (hasta 3)', 'lachinata-core')}
				</legend>
				<ul className="lcb-products">
					{pairing.map((item) => (
						<li key={item.id}>
							{item.image ? (
								<img src={item.image} alt="" />
							) : (
								<span className="lcb-noimg" />
							)}
							<span>
								<strong>{item.name}</strong>
								<span className="lcb-small">
									{[item.sku, item.price]
										.filter(Boolean)
										.join(' · ')}
								</span>
							</span>
							<Button
								variant="tertiary"
								isDestructive
								onClick={() =>
									set({
										pairing: pairing.filter(
											(p) => p.id !== item.id
										),
									})
								}
							>
								{__('Quitar', 'lachinata-core')}
							</Button>
						</li>
					))}
				</ul>
				{!full && (
					<>
						<TextControl
							label={__(
								'Buscar producto (nombre o SKU)',
								'lachinata-core'
							)}
							value={search}
							onChange={setSearch}
							__next40pxDefaultSize
							__nextHasNoMarginBottom
						/>
						{loading && <Spinner />}
						{results.length > 0 && (
							<ul className="lcb-products lcb-results">
								{results
									.filter(
										(r) =>
											!pairing.some((p) => p.id === r.id)
									)
									.map((item) => (
										<li key={item.id}>
											{item.image ? (
												<img src={item.image} alt="" />
											) : (
												<span className="lcb-noimg" />
											)}
											<span>
												<strong>{item.name}</strong>
												<span className="lcb-small">
													{[item.sku, item.price]
														.filter(Boolean)
														.join(' · ')}
												</span>
											</span>
											<Button
												variant="secondary"
												onClick={() => {
													set({
														pairing: [
															...pairing,
															item,
														].slice(0, 3),
													});
													setSearch('');
												}}
											>
												{__('Añadir', 'lachinata-core')}
											</Button>
										</li>
									))}
							</ul>
						)}
					</>
				)}
			</fieldset>
			<CheckboxControl
				label={__(
					'Sugerir por plato si no hay productos',
					'lachinata-core'
				)}
				help={
					settings.suggest
						? __(
								'La ficha propone el más vendido de la categoría de cada plato.',
								'lachinata-core'
							)
						: __(
								'Las sugerencias están apagadas en los ajustes de la Bodega.',
								'lachinata-core'
							)
				}
				checked={v.suggest !== 'no'}
				onChange={(on) => set({ suggest: on ? '' : 'no' })}
				__nextHasNoMarginBottom
			/>
		</div>
	);
};

const Flag = ({ label, value, fallback, onChange }) => {
	const checked = value === '' ? fallback : value === 'yes';
	return (
		<div className="lcb-flag">
			<CheckboxControl
				label={label}
				checked={checked}
				onChange={(on) => onChange(on ? 'yes' : 'no')}
				help={
					value === ''
						? sprintf(
								/* translators: %s: «sí» or «no». */
								__('De serie: %s.', 'lachinata-core'),
								fallback
									? __('sí', 'lachinata-core')
									: __('no', 'lachinata-core')
							)
						: undefined
				}
				__nextHasNoMarginBottom
			/>
			{value !== '' && (
				<Button variant="link" onClick={() => onChange('')}>
					{__('Volver al valor de serie', 'lachinata-core')}
				</Button>
			)}
		</div>
	);
};

const Etiqueta = ({ v, set }) => {
	const label = v.label || {};
	const change = (c) => set({ label: { ...label, ...c } });
	return (
		<div className="lcb-panel">
			<TextareaControl
				label={__('Ingredientes', 'lachinata-core')}
				value={label.ingredients || ''}
				rows={3}
				onChange={(ingredients) => change({ ingredients })}
				__nextHasNoMarginBottom
			/>
			<TextareaControl
				label={__('Información nutricional', 'lachinata-core')}
				value={label.nutrition || ''}
				rows={3}
				onChange={(nutrition) => change({ nutrition })}
				__nextHasNoMarginBottom
			/>
			<TextControl
				label={__(
					'O enlace a la etiqueta electrónica',
					'lachinata-core'
				)}
				type="url"
				value={label.url || ''}
				placeholder="https://"
				onChange={(url) => change({ url })}
				help={__(
					'Obligatorio en los vinos elaborados desde el 8/12/2023: el texto o el enlace.',
					'lachinata-core'
				)}
				__next40pxDefaultSize
				__nextHasNoMarginBottom
			/>
			<CheckboxControl
				label={__('Contiene sulfitos', 'lachinata-core')}
				checked={!!label.sulfites}
				onChange={(sulfites) => change({ sulfites })}
				__nextHasNoMarginBottom
			/>
			<TextControl
				label={__('Otros alérgenos', 'lachinata-core')}
				value={label.allergens || ''}
				onChange={(allergens) => change({ allergens })}
				__next40pxDefaultSize
				__nextHasNoMarginBottom
			/>
			<Flag
				label={__(
					'Contiene alcohol (avisos de edad y casilla +18)',
					'lachinata-core'
				)}
				value={v.alcohol || ''}
				fallback={!!settings.defaults.alcohol || !!v.type}
				onChange={(alcohol) => set({ alcohol })}
			/>
			<Flag
				label={__('Cuenta para la caja de 6', 'lachinata-core')}
				value={v.case || ''}
				fallback={!!settings.defaults.case || !!v.type}
				onChange={(value) => set({ case: value })}
			/>
		</div>
	);
};

const Preview = ({ v, vintages, lists }) => {
	const [name, setName] = useState(settings.name || '');
	useEffect(() => {
		const input = document.getElementById('title');
		if (!input) {
			return undefined;
		}
		const update = () => setName(input.value);
		input.addEventListener('input', update);
		return () => input.removeEventListener('input', update);
	}, []);
	const type = byId(settings.types, v.type);
	const making = byId(settings.makings, v.making);
	const winery = byId(lists.wineries, v.winery);
	const origin = byId(settings.origins, v.origin);
	const newest = vintages[0];
	const typeLine = type
		? `${type.name}${making ? ` ${lower(making.name)}` : ''}`
		: '';
	const grapes = (v.grapes || [])
		.map((g) => {
			const grape = byId(lists.grapes, g.term);
			if (!grape) {
				return '';
			}
			return g.pct ? `${g.pct} % ${grape.name}` : grape.name;
		})
		.filter(Boolean)
		.join(', ');
	const facts = [
		[
			__('Origen', 'lachinata-core'),
			origin
				? origin.label.split(' › ').slice(1).join(' › ') || origin.name
				: '',
		],
		[__('Uvas', 'lachinata-core'), grapes],
		[
			__('Grado', 'lachinata-core'),
			number(v.grade) > 0
				? `${String(v.grade).replace('.', ',')} % vol.`
				: '',
		],
		[__('Crianza', 'lachinata-core'), v.ageing],
		[__('Temperatura', 'lachinata-core'), temperatureText(v.temperature)],
	].filter((f) => f[1]);
	return (
		<aside
			className="lcb-preview"
			aria-label={__('Vista previa de la ficha', 'lachinata-core')}
		>
			<span className="lcb-preview__title">
				{__('Vista previa', 'lachinata-core')}
			</span>
			<div className="lcb-preview__card">
				<span className="lcb-eyebrow">
					{[__('Bodega', 'lachinata-core'), origin ? origin.name : '']
						.filter(Boolean)
						.join(' · ')}
				</span>
				<strong className="lcb-preview__name">
					{name || __('(sin nombre)', 'lachinata-core')}
				</strong>
				<span className="lcb-small">
					{[
						winery ? winery.name : '',
						typeLine,
						newest ? newest.name : '',
					]
						.filter(Boolean)
						.join(' · ')}
				</span>
				{newest && (
					<div className="lcb-badges">
						{visibleBadges(v.scores, newest.slug).map((b) => (
							<Badge key={b.id} score={b} />
						))}
					</div>
				)}
				{facts.length > 0 && (
					<dl>
						{facts.map(([label, value]) => (
							<div key={label}>
								<dt>{label}</dt>
								<dd>{value}</dd>
							</div>
						))}
					</dl>
				)}
			</div>
		</aside>
	);
};

const Box = () => {
	const field = document.getElementById('lc-bodega-data');
	const [v, setValues] = useState(() => {
		try {
			return JSON.parse(field.value || '{}') || {};
		} catch {
			return {};
		}
	});
	const [tab, setTab] = useState('ficha');
	const [vintages, setVintages] = useState(settings.vintages || []);
	const [lists, setLists] = useState({
		wineries: settings.wineries || [],
		grapes: settings.grapes || [],
	});
	const [duplicating, setDuplicating] = useState(false);
	const [error, setError] = useState('');
	const set = (change) => setValues((current) => ({ ...current, ...change }));

	useEffect(() => {
		const out = {
			...v,
			pairing: (v.pairing || []).map((p) => p.id),
			grade: number(v.grade),
		};
		field.value = JSON.stringify(out);
	}, [v, field]);

	const state = useMemo(() => completeness(v, vintages), [v, vintages]);
	const tabs = TABS();
	const missingIn = (name) =>
		state.missing.filter((m) => m[1] === name).length;

	const duplicate = async () => {
		if (
			// eslint-disable-next-line no-alert
			!window.confirm(
				__(
					'Se crea un borrador con la ficha, la bodega, el origen y las uvas de este vino (sin añadas, cata, puntuaciones ni maridaje). Los cambios sin guardar de este vino no se copian. ¿Seguimos?',
					'lachinata-core'
				)
			)
		) {
			return;
		}
		setDuplicating(true);
		setError('');
		try {
			const result = await apiFetch({
				path: `/lachinata/v1/bodega/products/${settings.productId}/duplicate`,
				method: 'POST',
			});
			window.location.href = result.edit;
		} catch (e) {
			setError(
				e.message ||
					__('No se ha podido crear el vino.', 'lachinata-core')
			);
			setDuplicating(false);
		}
	};

	return (
		<div className="lcb">
			<div
				className={`lcb-state${state.missing.length ? '' : ' is-done'}`}
				role="status"
			>
				<strong>
					{sprintf(
						/* translators: 1: checks done, 2: total. */
						__('Completa %1$s de %2$s', 'lachinata-core'),
						state.done,
						state.total
					)}
				</strong>
				{state.missing.length > 0 && (
					<>
						<span aria-hidden="true"> · </span>
						<span>
							{_n(
								'falta',
								'faltan',
								state.missing.length,
								'lachinata-core'
							)}{' '}
							{state.missing.map((m, i) => (
								<span key={m[0]}>
									{i > 0 &&
										(i === state.missing.length - 1
											? ` ${__('y', 'lachinata-core')} `
											: ', ')}
									<Button
										variant="link"
										onClick={() => setTab(m[1])}
									>
										{m[2]}
									</Button>
								</span>
							))}
						</span>
					</>
				)}
				<span className="lcb-small">
					{__('Los avisos no impiden guardar.', 'lachinata-core')}
				</span>
			</div>
			{error && (
				<Notice status="error" onRemove={() => setError('')}>
					{error}
				</Notice>
			)}
			<div className="lcb-layout">
				<div className="lcb-main">
					<div
						className="lcb-tabs"
						role="tablist"
						aria-label={__('Ficha del vino', 'lachinata-core')}
					>
						{tabs.map((t) => (
							<button
								type="button"
								role="tab"
								key={t.name}
								id={`lcb-tab-${t.name}`}
								aria-selected={tab === t.name}
								aria-controls={`lcb-panel-${t.name}`}
								className={`lcb-tab${tab === t.name ? ' is-active' : ''}`}
								onClick={() => setTab(t.name)}
							>
								{t.title}
								{missingIn(t.name) > 0 && (
									<span
										className="lcb-count"
										aria-label={sprintf(
											/* translators: %s: number of things missing. */
											_n(
												'falta %s',
												'faltan %s',
												missingIn(t.name),
												'lachinata-core'
											),
											missingIn(t.name)
										)}
									>
										{missingIn(t.name)}
									</span>
								)}
							</button>
						))}
					</div>
					<div
						role="tabpanel"
						id={`lcb-panel-${tab}`}
						aria-labelledby={`lcb-tab-${tab}`}
					>
						{tab === 'ficha' && (
							<Ficha
								v={v}
								set={set}
								lists={lists}
								setLists={setLists}
							/>
						)}
						{tab === 'cata' && <Cata v={v} set={set} />}
						{tab === 'anadas' && (
							<Anadas
								v={v}
								set={set}
								vintages={vintages}
								setVintages={setVintages}
							/>
						)}
						{tab === 'maridaje' && <Maridaje v={v} set={set} />}
						{tab === 'etiqueta' && <Etiqueta v={v} set={set} />}
					</div>
					{settings.productId > 0 && (
						<p className="lcb-footer">
							<Button
								variant="secondary"
								onClick={duplicate}
								isBusy={duplicating}
								disabled={duplicating}
							>
								{__(
									'Crear a partir de este vino',
									'lachinata-core'
								)}
							</Button>
							<span className="lcb-small">
								{__(
									'Para dar de alta otro vino de la misma bodega.',
									'lachinata-core'
								)}
							</span>
						</p>
					)}
				</div>
				<Preview v={v} vintages={vintages} lists={lists} />
			</div>
		</div>
	);
};

const mount = () => {
	const root = document.getElementById('lc-bodega-box');
	if (!root || !document.getElementById('lc-bodega-data')) {
		return;
	}
	if (createRoot) {
		createRoot(root).render(<Box />);
	} else {
		render(<Box />, root);
	}
};

if (document.readyState === 'loading') {
	document.addEventListener('DOMContentLoaded', mount);
} else {
	mount();
}
