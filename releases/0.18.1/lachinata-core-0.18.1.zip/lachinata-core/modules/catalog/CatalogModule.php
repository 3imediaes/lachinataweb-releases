<?php
/**
 * Module `catalog`: catalog data that used to live in ACF.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

use LaChinata\Core\Hooks;
use LaChinata\Core\Module;
use LaChinata\Core\Plugin;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Content and unit price, ingredients, label, description image, best-before date,
 * international exclusion, category tint and seals (`tipo`) with icon; main category and
 * card image of the product, look of the product tags, marks of the shipping classes,
 * store categories with campaigns, cross-sell by root category, composite gifts and the
 * catalog health.
 */
final class CatalogModule extends Module {

	/**
	 * Module id.
	 */
	public function id(): string {
		return 'catalog';
	}

	/**
	 * Module name.
	 */
	public function label(): string {
		return __( 'Catálogo', 'lachinata-core' );
	}

	/**
	 * Module description.
	 */
	public function description(): string {
		return __( 'Contenido y precio por unidad, ingredientes, etiquetas, sellos, tinta de categoría, categorías de la tienda, venta cruzada, regalos compuestos y salud del catálogo. Sustituye a ACF.', 'lachinata-core' );
	}

	/**
	 * Version in which the module was added.
	 */
	public function since(): string {
		return '0.2.0';
	}

	/**
	 * Documentation.
	 */
	public function docs(): string {
		return 'plugin/modules/catalog/README.md';
	}

	/**
	 * Requirements.
	 *
	 * @return array{woocommerce: string}
	 */
	public function requires(): array {
		return array( 'woocommerce' => '10.0' );
	}

	/**
	 * Configuration of the shop (it travels in the JSON): store categories and campaigns,
	 * cross-sell by root category, marks of the shipping classes and «¿Es para tu
	 * empresa?» (0.16.0), all by slug, and since 0.17.1 the 301 of a product deleted for
	 * good (`redirect_deleted`, on). Read them clean with Config.
	 *
	 * @return array<string, array{type: 'array'|'bool', default: mixed, export: bool}>
	 */
	public function settings(): array {
		$list = array(
			'type'    => 'array',
			'default' => array(),
			'export'  => true,
		);
		return array(
			'store_categories' => $list,
			'campaigns'        => $list,
			'cross_sell'       => $list,
			'markers'          => $list,
			'watched_fields'   => $list,
			'bulk'             => $list,
			'redirect_deleted' => array(
				'type'    => 'bool',
				'default' => true,
				'export'  => true,
			),
		);
	}

	/**
	 * The module, for Settings.
	 */
	public static function instance(): ?Module {
		return Plugin::instance()->modules()->get( 'catalog' );
	}

	/**
	 * A setting of the module.
	 *
	 * @param string $key Setting key.
	 * @return mixed
	 */
	public static function setting( string $key ) {
		$module = self::instance();
		return null === $module ? null : Settings::get( $module, $key );
	}

	/**
	 * Product, image and term fields («Borrar datos» removes them; the old ACF values stay).
	 *
	 * @return array{product_meta: string[], term_meta: string[]}
	 */
	public function owned_data(): array {
		return array(
			'product_meta' => array( Fields::CONTENT, Fields::REFERENCE, Fields::INGREDIENTS, Fields::LABEL, Fields::IMAGE, Fields::BEST_BEFORE, Fields::NO_SHIP_ABROAD, Fields::MAIN_CATEGORY, Fields::CARD_IMAGE, Changes::META, Gifts::META, Cutouts::META ),
			'term_meta'    => array( Fields::TINT, Fields::ICON, Fields::TAG_TONE, Fields::TAG_IMAGE, Fields::TAG_ORDER, Gifts::KEYWORDS ),
		);
	}

	/**
	 * Declares for `translate` the texts of its settings: the shipping marks, the titles of
	 * the cross-sell and «¿Es para tu empresa?» when the shop wrote its own.
	 *
	 * @param mixed $options Options of other modules.
	 * @return array<string, array<string, mixed>>
	 */
	public static function translatable( $options ): array {
		$options                                 = is_array( $options ) ? $options : array();
		$options['lachinata_catalog_markers']    = array(
			'label' => __( 'Marcas de envío', 'lachinata-core' ),
			'paths' => array( '*.label', '*.notice_label' ),
		);
		$options['lachinata_catalog_cross_sell'] = array(
			'label' => __( 'Venta cruzada', 'lachinata-core' ),
			'paths' => array( '*.title' ),
		);
		$options['lachinata_catalog_bulk']       = array(
			'label' => __( '¿Es para tu empresa?', 'lachinata-core' ),
			'paths' => array( 'title', 'text', 'cta', 'whatsapp_text' ),
		);
		return $options;
	}

	/**
	 * Registers the hooks.
	 */
	public function boot(): void {
		Hooks::add_action( 'init', array( TipoTaxonomy::class, 'register' ), 5 );
		Hooks::add_action( 'template_redirect', array( TipoTaxonomy::class, 'redirect' ), 0 );
		Hooks::add_action( 'init', array( Fields::class, 'register' ) );
		Hooks::add_action( 'init', array( Gifts::class, 'register' ), 5 );
		Hooks::add_filter( 'lachinata/translate/fields', array( Fields::class, 'translatable' ) );
		Hooks::add_filter( 'lachinata/translate/options', array( self::class, 'translatable' ) );
		Hooks::add_filter( 'lachinata/catalog/no_ship_abroad', static fn( $excluded, $product_id ): bool => (bool) $excluded || (bool) Fields::get( (int) $product_id, Fields::NO_SHIP_ABROAD ), 10, 2 );
		$content = new Content();
		Hooks::add_filter( 'lachinata/catalog/service', static fn() => $content );
		Storefront::boot();
		GiftFront::boot();
		Cutouts::boot();
		Changes::boot();
		DeletedRedirect::boot();

		if ( is_admin() ) {
			Admin::boot();
			ProductAdmin::boot();
			TermFields::boot();
			CatalogTab::boot();
			GiftAdmin::boot();
		}

		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::add_command( 'lachinata catalog', NormalizeCommand::class );
		}
	}
}
