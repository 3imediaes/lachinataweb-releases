<?php
/**
 * Cutout product photos: images with a transparent background.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * The main product photos are being replaced with WebP cutouts (no background). Until then
 * both kinds live together: a cutout is painted centred, with air, on the tint of its
 * family; a photo with a background fills its piece. Nobody marks it by hand: an image is
 * a cutout when it has transparent pixels, checked when it is uploaded (or its file is
 * replaced) and with `wp lachinata catalog detect-cutouts` for the existing ones.
 */
final class Cutouts {

	/**
	 * Attachment meta: '1' on a cutout (absent otherwise).
	 */
	public const META = '_lc_catalog_recorte';

	/**
	 * Side of the sample the image is reduced to before looking at its pixels.
	 */
	private const SAMPLE = 64;

	/**
	 * Alpha (GD scale, 0 opaque to 127 transparent) from which a sampled pixel counts as
	 * transparent: at least half. A stray pixel or a thin line averages out in the sample.
	 */
	private const ALPHA = 64;

	/**
	 * Formats that may carry an alpha channel.
	 */
	public const MIME_TYPES = array( 'image/png', 'image/webp', 'image/gif' );

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'wp_generate_attachment_metadata', array( self::class, 'on_metadata' ), 10, 2 );
		Hooks::add_filter( 'lachinata/catalog/cutout', array( self::class, 'filter' ), 10, 2 );
	}

	/**
	 * After WordPress generates the sizes of an uploaded (or replaced) image.
	 *
	 * @param mixed $metadata      Attachment metadata.
	 * @param mixed $attachment_id Attachment id.
	 * @return mixed
	 */
	public static function on_metadata( $metadata, $attachment_id ) {
		self::mark( (int) $attachment_id );
		return $metadata;
	}

	/**
	 * Answer to `lachinata/catalog/cutout`.
	 *
	 * @param mixed $cutout        Current value.
	 * @param mixed $attachment_id Attachment id.
	 */
	public static function filter( $cutout, $attachment_id ): bool {
		return (bool) $cutout || self::is_cutout( (int) $attachment_id );
	}

	/**
	 * Whether an attachment is marked as a cutout.
	 *
	 * @param int $attachment_id Attachment id.
	 */
	public static function is_cutout( int $attachment_id ): bool {
		return $attachment_id > 0 && '1' === get_post_meta( $attachment_id, self::META, true );
	}

	/**
	 * Checks an attachment and saves (or removes) the mark.
	 *
	 * @param int  $attachment_id Attachment id.
	 * @param bool $dry_run       Check only.
	 * @return bool|null Whether it is a cutout; null when it is not an image or its file is missing.
	 */
	public static function mark( int $attachment_id, bool $dry_run = false ): ?bool {
		if ( ! wp_attachment_is_image( $attachment_id ) ) {
			return null;
		}
		$file = get_attached_file( $attachment_id );
		if ( ! is_string( $file ) || ! is_readable( $file ) ) {
			return null;
		}
		$cutout = self::detect( $file );
		if ( ! $dry_run ) {
			if ( $cutout ) {
				update_post_meta( $attachment_id, self::META, '1' );
			} else {
				delete_post_meta( $attachment_id, self::META );
			}
		}
		return $cutout;
	}

	/**
	 * Whether an image file has a transparent background. The header says first whether
	 * the file can carry transparency at all (a JPEG never does, and most PNG and WebP
	 * files declare none); only then are its pixels looked at.
	 *
	 * @param string $file Path.
	 */
	public static function detect( string $file ): bool {
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local file, first bytes only.
		$head = (string) file_get_contents( $file, false, null, 0, 65536 );
		return self::may_have_alpha( $head ) && self::has_transparency( $file );
	}

	/**
	 * Whether the header of an image declares transparency.
	 *
	 * @param string $head First bytes of the file.
	 */
	public static function may_have_alpha( string $head ): bool {
		if ( str_starts_with( $head, "\x89PNG\r\n\x1a\n" ) ) {
			// Colour type in IHDR: 4 grey with alpha, 6 RGBA; others only with a tRNS chunk.
			$type = strlen( $head ) > 25 ? ord( $head[25] ) : 0;
			return 4 === $type || 6 === $type || str_contains( $head, 'tRNS' );
		}
		if ( str_starts_with( $head, 'RIFF' ) && 'WEBP' === substr( $head, 8, 4 ) ) {
			$chunk = substr( $head, 12, 4 );
			if ( 'VP8X' === $chunk ) {
				return strlen( $head ) > 20 && (bool) ( ord( $head[20] ) & 0x10 );
			}
			if ( 'VP8L' === $chunk && strlen( $head ) >= 25 ) {
				// After the signature byte: 14 bits width, 14 bits height, 1 bit alpha.
				$bits = unpack( 'V', substr( $head, 21, 4 ) );
				return is_array( $bits ) && (bool) ( ( (int) $bits[1] >> 28 ) & 1 );
			}
			return false;
		}
		return str_starts_with( $head, 'GIF8' );
	}

	/**
	 * Whether the image has transparent pixels: it is reduced to a small sample, so a
	 * transparent background shows and a stray pixel does not.
	 *
	 * @param string $file Path.
	 */
	private static function has_transparency( string $file ): bool {
		if ( ! function_exists( 'imagecreatefromstring' ) ) {
			return false;
		}
		wp_raise_memory_limit( 'image' );
		$image = @imagecreatefromstring( (string) file_get_contents( $file ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local file; a broken file is just not a cutout.
		if ( false === $image ) {
			return false;
		}
		$sample = imagecreatetruecolor( self::SAMPLE, self::SAMPLE );
		imagealphablending( $sample, false );
		imagesavealpha( $sample, true );
		imagefill( $sample, 0, 0, (int) imagecolorallocatealpha( $sample, 0, 0, 0, 127 ) );
		imagecopyresampled( $sample, $image, 0, 0, 0, 0, self::SAMPLE, self::SAMPLE, imagesx( $image ), imagesy( $image ) );
		for ( $y = 0; $y < self::SAMPLE; $y++ ) {
			for ( $x = 0; $x < self::SAMPLE; $x++ ) {
				if ( ( ( (int) imagecolorat( $sample, $x, $y ) >> 24 ) & 0x7F ) >= self::ALPHA ) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Checks every image that may be a cutout (and those marked, in case their file
	 * changed).
	 *
	 * @param bool $dry_run Report only.
	 * @return array{checked: int, cutouts: int[], added: int[], removed: int[], missing: int[]}
	 */
	public static function run( bool $dry_run ): array {
		$ids    = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'post_mime_type' => implode( ',', self::MIME_TYPES ),
				'posts_per_page' => -1,
				'fields'         => 'ids',
			)
		);
		$marked = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'inherit',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_key'       => self::META, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- One-off command.
			)
		);
		$report = array(
			'checked' => 0,
			'cutouts' => array(),
			'added'   => array(),
			'removed' => array(),
			'missing' => array(),
		);
		foreach ( array_unique( array_map( 'intval', array_merge( $ids, $marked ) ) ) as $id ) {
			$before = self::is_cutout( $id );
			$now    = self::mark( $id, $dry_run );
			if ( null === $now ) {
				$report['missing'][] = $id;
				continue;
			}
			++$report['checked'];
			if ( $now ) {
				$report['cutouts'][] = $id;
			}
			if ( $now && ! $before ) {
				$report['added'][] = $id;
			} elseif ( ! $now && $before ) {
				$report['removed'][] = $id;
			}
		}
		return $report;
	}
}
