<?php
/**
 * A product deleted for good leaves a 301 to its category.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

use LaChinata\Core\Hooks;
use LaChinata\Core\Redirections;

defined( 'ABSPATH' ) || exit;

/**
 * When a product that had a public address is deleted for good (not when it goes to the
 * bin), its address gets a 301 to its main category (or the deepest one) in the list of
 * redirections of the panel, where it can be edited. Setting `redirect_deleted`, on by
 * default. In other languages the same rule applies (`translate`).
 */
final class DeletedRedirect {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'before_delete_post', array( self::class, 'deleted' ), 10, 2 );
	}

	/**
	 * Before a post is deleted for good.
	 *
	 * @param mixed $post_id Post id.
	 * @param mixed $post    Post.
	 */
	public static function deleted( $post_id, $post ): void {
		if ( ! $post instanceof \WP_Post || 'product' !== $post->post_type || ! CatalogModule::setting( 'redirect_deleted' ) ) {
			return;
		}
		if ( ! in_array( $post->post_status, array( 'publish', 'private', 'trash' ), true ) || '' === $post->post_name ) {
			return;
		}
		$category = self::category( (int) $post_id );
		$target   = $category ? get_term_link( $category, 'product_cat' ) : '';
		if ( ! is_string( $target ) || '' === $target ) {
			$target = (string) get_permalink( wc_get_page_id( 'shop' ) );
		}
		Redirections::add( self::address( $post ), $target, 301 );
	}

	/**
	 * Main category of the product, or the deepest of its categories (not the default one).
	 *
	 * @param int $product_id Product id.
	 */
	public static function category( int $product_id ): int {
		$main = Fields::main_category( $product_id );
		if ( $main ) {
			return $main;
		}
		$default = (int) get_option( 'default_product_cat' );
		$deepest = 0;
		$depth   = -1;
		foreach ( wp_get_post_terms( $product_id, 'product_cat', array( 'fields' => 'ids' ) ) as $term_id ) {
			$term_id = (int) $term_id;
			if ( $term_id === $default ) {
				continue;
			}
			$level = count( get_ancestors( $term_id, 'product_cat', 'taxonomy' ) );
			if ( $level > $depth ) {
				$depth   = $level;
				$deepest = $term_id;
			}
		}
		return $deepest;
	}

	/**
	 * The public address the product had (a product in the bin keeps its slug with
	 * «__trashed»).
	 *
	 * @param \WP_Post $post Product.
	 */
	private static function address( \WP_Post $post ): string {
		if ( 'trash' === $post->post_status ) {
			$post              = clone $post;
			$post->post_status = 'publish';
			$desired           = (string) get_post_meta( $post->ID, '_wp_desired_post_slug', true );
			$post->post_name   = '' !== $desired ? $desired : (string) preg_replace( '/__trashed(-\d+)?$/', '', $post->post_name );
		}
		return (string) get_permalink( $post );
	}
}
