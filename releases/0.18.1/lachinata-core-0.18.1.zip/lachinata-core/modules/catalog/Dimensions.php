<?php
/**
 * Dimensions written in the text of a product.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

defined( 'ABSPATH' ) || exit;

/**
 * The line «Dimensiones (l x w x h): A x B x C cm» of any product, in its short description
 * or its description (a paragraph, a list item or a line of its own; decimal comma; final
 * full stop optional), goes to the WooCommerce fields (length, width, height) and leaves the
 * text: an empty list goes with it, and so does an empty «Datos del producto» subtitle.
 * Dimensions already in the fields that are different are never overwritten: the text
 * stays and the report says so. Running it again changes nothing. `catalog normalize` runs it
 * on every product and `migrate-gifts` on the gifts it migrates (#42).
 */
final class Dimensions {

	/**
	 * Subtitle of the product data section, where the dimensions are in the new copy.
	 */
	private const DATA_HEADING = '/^datos del producto$/iu';

	/**
	 * Blank between a subtitle and what follows: spaces, `&nbsp;` and empty paragraphs.
	 */
	private const BLANK = '(?:\s|&nbsp;|<p>(?:\s|&nbsp;)*</p>)*';

	/**
	 * The dimensions out of a text, as numbers.
	 *
	 * @param string $html Text.
	 * @return array{html: string, dimensions: array{0: float, 1: float, 2: float, unit: string}|null, notes: string[]}
	 */
	public static function extract( string $html ): array {
		$number = '(\d+(?:[.,]\d+)?)';
		$line   = 'Dimensiones(?:\s*\([^)]*\))?\s*:\s*' . $number . '\s*[x×]\s*' . $number . '\s*[x×]\s*' . $number . '\s*(mm|cm|m)\b\.?';
		$found  = null;
		$notes  = array();
		// A list item, a paragraph or a line of its own; the first one found.
		foreach ( array( '#<li>\s*' . $line . '\s*</li>#iu', '#<p>\s*' . $line . '\s*</p>#iu', '#^[ \t]*' . $line . '[ \t]*(?:<br\s*/?>)?\r?$#imu' ) as $pattern ) {
			$html = (string) preg_replace_callback(
				$pattern,
				static function ( array $found_match ) use ( &$found ): string {
					$found = array(
						(float) str_replace( ',', '.', $found_match[1] ),
						(float) str_replace( ',', '.', $found_match[2] ),
						(float) str_replace( ',', '.', $found_match[3] ),
						'unit' => strtolower( $found_match[4] ),
					);
					return '';
				},
				$html,
				1
			);
			if ( null !== $found ) {
				break;
			}
		}
		if ( null === $found ) {
			return array(
				'html'       => $html,
				'dimensions' => null,
				'notes'      => $notes,
			);
		}
		$html = (string) preg_replace( '#<ul>\s*</ul>#i', '', $html );
		// The «Datos del producto» subtitle with nothing under it before the next subtitle.
		$html = (string) preg_replace_callback(
			'#<h([2-4])\b[^>]*>((?:(?!</?h[1-6]\b).)*)</h\1>(' . self::BLANK . ')(?=<h[2-4]\b|$)#is',
			static fn( array $found_match ): string => preg_match( self::DATA_HEADING, trim( wp_strip_all_tags( $found_match[2] ) ) ) ? '' : $found_match[0],
			$html
		);
		if ( preg_match( '#<h([2-4])\b[^>]*>\s*Datos del producto\s*</h\1>#iu', $html ) ) {
			$notes[] = '«Datos del producto» conserva otro texto.';
		}
		return array(
			'html'       => rtrim( $html ),
			'dimensions' => $found,
			'notes'      => $notes,
		);
	}

	/**
	 * Reads the dimensions of a product (short description first, then description) and
	 * moves them to its fields and out of its text. Changes the object, never saves it.
	 *
	 * @param \WC_Product $product Product.
	 * @return array{size: string, source: string, notes: string[]} Size written ('' none), where it was (`excerpt`, `description` or ''), notes.
	 */
	public static function apply( \WC_Product $product ): array {
		$out  = array(
			'size'   => '',
			'source' => '',
			'notes'  => array(),
		);
		$unit = (string) get_option( 'woocommerce_dimension_unit', 'cm' );
		foreach ( array(
			'excerpt'     => array( 'get_short_description', 'set_short_description' ),
			'description' => array( 'get_description', 'set_description' ),
		) as $source => $methods ) {
			$found = self::extract( (string) $product->{$methods[0]}() );
			if ( null === $found['dimensions'] ) {
				continue;
			}
			$new  = array_map( static fn( float $value ): string => (string) round( wc_get_dimension( $value, $unit, $found['dimensions']['unit'] ), 2 ), array( $found['dimensions'][0], $found['dimensions'][1], $found['dimensions'][2] ) );
			$old  = array( (string) $product->get_length(), (string) $product->get_width(), (string) $product->get_height() );
			$size = implode( ' × ', $new ) . ' ' . $unit;
			if ( array_filter( $old ) && array_map( 'floatval', $old ) !== array_map( 'floatval', $new ) ) {
				$out['notes'][] = sprintf( 'Medidas del texto (%1$s, %2$s) distintas de las de la ficha (%3$s): no se pisan y el texto se queda.', $size, 'excerpt' === $source ? 'descripción corta' : 'descripción', implode( ' × ', $old ) . ' ' . $unit );
				continue;
			}
			$product->set_length( $new[0] );
			$product->set_width( $new[1] );
			$product->set_height( $new[2] );
			$product->{$methods[1]}( $found['html'] );
			$out['notes'] = array_merge( $out['notes'], $found['notes'] );
			if ( '' === $out['source'] ) {
				$out['size']   = $size;
				$out['source'] = $source;
			}
		}
		return $out;
	}
}
