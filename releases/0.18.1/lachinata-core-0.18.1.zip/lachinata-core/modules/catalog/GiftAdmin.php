<?php
/**
 * «Contenido del regalo» box in the product editor and the keywords of each presentation.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * Rows of product (searched by name or SKU with WooCommerce's own search), units and an
 * optional note, plus the presentation. A product with rows is a composite gift.
 */
final class GiftAdmin {

	/**
	 * Field of the rows.
	 */
	private const FIELD = 'lc_gift';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'add_meta_boxes_product', array( self::class, 'box' ) );
		Hooks::add_action( 'woocommerce_admin_process_product_object', array( self::class, 'save' ) );
		Hooks::add_action( Gifts::TAXONOMY . '_add_form_fields', array( self::class, 'keywords_add' ) );
		Hooks::add_action( Gifts::TAXONOMY . '_edit_form_fields', array( self::class, 'keywords_edit' ) );
		Hooks::add_action( 'created_' . Gifts::TAXONOMY, array( self::class, 'save_keywords' ) );
		Hooks::add_action( 'edited_' . Gifts::TAXONOMY, array( self::class, 'save_keywords' ) );
	}

	/**
	 * Adds the box under the product data.
	 */
	public static function box(): void {
		add_meta_box( 'lc-gift', __( 'Contenido del regalo', 'lachinata-core' ), array( self::class, 'render' ), 'product', 'normal', 'default' );
	}

	/**
	 * Prints the box.
	 *
	 * @param \WP_Post $post Product.
	 */
	public static function render( \WP_Post $post ): void {
		$rows         = Gifts::rows( $post->ID );
		$presentation = Gifts::presentation( $post->ID );
		$terms        = get_terms(
			array(
				'taxonomy'   => Gifts::TAXONOMY,
				'hide_empty' => false,
			)
		);
		wp_nonce_field( 'lc-gift', 'lc_gift_nonce' );
		?>
		<div class="lc-gift-admin" data-lc-gift>
			<p class="description"><?php esc_html_e( 'Los productos que lleva este regalo, con sus unidades. Un producto con contenido es un regalo compuesto: la ficha muestra qué lleva, sin precios. El stock y los pedidos no cambian.', 'lachinata-core' ); ?></p>
			<p>
				<label for="lc-gift-presentation"><?php esc_html_e( 'Presentación', 'lachinata-core' ); ?></label>
				<select id="lc-gift-presentation" name="lc_gift_presentation">
					<option value="0"><?php esc_html_e( '—', 'lachinata-core' ); ?></option>
					<?php foreach ( is_array( $terms ) ? $terms : array() as $term ) : ?>
						<option value="<?php echo (int) $term->term_id; ?>"<?php selected( $presentation ? $presentation->term_id : 0, $term->term_id ); ?>><?php echo esc_html( $term->name ); ?></option>
					<?php endforeach; ?>
				</select>
				<a href="<?php echo esc_url( admin_url( 'edit-tags.php?taxonomy=' . Gifts::TAXONOMY . '&post_type=product' ) ); ?>"><?php esc_html_e( 'Presentaciones', 'lachinata-core' ); ?></a>
			</p>
			<table class="widefat striped">
				<thead><tr><th scope="col"><?php esc_html_e( 'Producto (nombre o SKU)', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Unidades', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Nota (opcional)', 'lachinata-core' ); ?></th><th scope="col"><span class="screen-reader-text"><?php esc_html_e( 'Quitar', 'lachinata-core' ); ?></span></th></tr></thead>
				<tbody data-lc-gift-rows>
					<?php
					foreach ( $rows as $index => $row ) {
						self::row( (string) $index, $row, $post->ID );
					}
					?>
				</tbody>
			</table>
			<template data-lc-gift-template>
				<?php
				self::row(
					'__i__',
					array(
						'id'   => 0,
						'sku'  => '',
						'qty'  => 1,
						'note' => '',
					),
					$post->ID
				);
				?>
			</template>
			<p><button type="button" class="button" data-lc-gift-add><?php esc_html_e( 'Añadir producto', 'lachinata-core' ); ?></button></p>
		</div>
		<?php
	}

	/**
	 * One row of the box.
	 *
	 * @param string                                              $index   Row index.
	 * @param array{id: int, sku: string, qty: int, note: string} $row     Row.
	 * @param int                                                 $gift_id The gift (left out of the search).
	 */
	private static function row( string $index, array $row, int $gift_id ): void {
		$product = '__i__' === $index ? null : Gifts::product( $row );
		$name    = self::FIELD . '[' . $index . ']';
		?>
		<tr>
			<td>
				<select class="wc-product-search" style="width: 100%" name="<?php echo esc_attr( $name ); ?>[id]" data-placeholder="<?php esc_attr_e( 'Busca por nombre o SKU', 'lachinata-core' ); ?>" data-action="woocommerce_json_search_products" data-exclude="<?php echo (int) $gift_id; ?>" aria-label="<?php esc_attr_e( 'Producto', 'lachinata-core' ); ?>">
					<?php if ( $product ) : ?>
						<option value="<?php echo (int) $product->get_id(); ?>" selected><?php echo esc_html( wp_strip_all_tags( $product->get_formatted_name() ) ); ?></option>
					<?php endif; ?>
				</select>
				<input type="hidden" name="<?php echo esc_attr( $name ); ?>[sku]" value="<?php echo esc_attr( $product ? '' : $row['sku'] ); ?>">
				<?php if ( '__i__' !== $index && ! $product ) : ?>
					<p class="description">
						<?php
						/* translators: 1: SKU, 2: product id. */
						echo esc_html( sprintf( __( 'No existe ningún producto con el SKU «%1$s» ni con el ID %2$s. Búscalo de nuevo o quita la fila.', 'lachinata-core' ), $row['sku'], $row['id'] ) );
						?>
					</p>
				<?php endif; ?>
			</td>
			<td><input type="number" class="small-text" min="1" max="<?php echo (int) Gifts::MAX_QTY; ?>" name="<?php echo esc_attr( $name ); ?>[qty]" value="<?php echo (int) $row['qty']; ?>" aria-label="<?php esc_attr_e( 'Unidades', 'lachinata-core' ); ?>"></td>
			<td><input type="text" class="regular-text" name="<?php echo esc_attr( $name ); ?>[note]" value="<?php echo esc_attr( $row['note'] ); ?>" aria-label="<?php esc_attr_e( 'Nota', 'lachinata-core' ); ?>"></td>
			<td><button type="button" class="button-link button-link-delete" data-lc-gift-remove><?php esc_html_e( 'Quitar', 'lachinata-core' ); ?></button></td>
		</tr>
		<?php
	}

	/**
	 * Saves the rows and the presentation.
	 *
	 * @param \WC_Product $product Product.
	 */
	public static function save( \WC_Product $product ): void {
		if ( ! isset( $_POST['lc_gift_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['lc_gift_nonce'] ), 'lc-gift' ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Gifts::clean().
		$rows = isset( $_POST[ self::FIELD ] ) && is_array( $_POST[ self::FIELD ] ) ? wp_unslash( $_POST[ self::FIELD ] ) : array();
		Gifts::save( $product->get_id(), array_values( (array) $rows ) );
		$term = isset( $_POST['lc_gift_presentation'] ) ? absint( $_POST['lc_gift_presentation'] ) : 0;
		wp_set_object_terms( $product->get_id(), $term ? array( $term ) : array(), Gifts::TAXONOMY );
	}

	/**
	 * Keywords field on a new presentation.
	 */
	public static function keywords_add(): void {
		printf(
			'<div class="form-field"><label for="lc-keywords">%1$s</label><input type="text" id="lc-keywords" name="lc_keywords" value=""><p>%2$s</p></div>',
			esc_html__( 'Palabras del nombre', 'lachinata-core' ),
			esc_html__( 'Separadas por comas. Al migrar los regalos, un producto cuyo nombre empiece por una de estas palabras toma esta presentación.', 'lachinata-core' )
		);
	}

	/**
	 * Keywords field on an existing presentation.
	 *
	 * @param \WP_Term $term Presentation.
	 */
	public static function keywords_edit( \WP_Term $term ): void {
		printf(
			'<tr class="form-field"><th scope="row"><label for="lc-keywords">%1$s</label></th><td><input type="text" id="lc-keywords" name="lc_keywords" value="%2$s"><p class="description">%3$s</p></td></tr>',
			esc_html__( 'Palabras del nombre', 'lachinata-core' ),
			esc_attr( implode( ', ', Gifts::keywords( $term->term_id ) ) ),
			esc_html__( 'Separadas por comas. Al migrar los regalos, un producto cuyo nombre empiece por una de estas palabras toma esta presentación.', 'lachinata-core' )
		);
	}

	/**
	 * Saves the keywords (the term form carries WordPress's own nonce).
	 *
	 * @param int $term_id Presentation.
	 */
	public static function save_keywords( int $term_id ): void {
		if ( ! current_user_can( 'manage_product_terms' ) || ! isset( $_POST['lc_keywords'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Checked by edit-tags.php.
			return;
		}
		update_term_meta( $term_id, Gifts::KEYWORDS, implode( ', ', array_filter( array_map( 'trim', explode( ',', sanitize_text_field( wp_unslash( $_POST['lc_keywords'] ) ) ) ) ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Checked by edit-tags.php.
	}
}
