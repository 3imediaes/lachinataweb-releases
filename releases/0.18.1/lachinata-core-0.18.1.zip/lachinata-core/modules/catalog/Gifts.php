<?php
/**
 * Composite gifts: the products a gift holds and its presentation.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

defined( 'ABSPATH' ) || exit;

/**
 * A product with contents is a composite gift (box, basket, bucket, case). For WooCommerce,
 * Odoo and the stock it is still a simple product: the contents never touch stock or
 * orders. Each row keeps the id and the SKU, so it survives a product recreated with the
 * same SKU. The presentation is a term of `lc_presentacion` (one per gift), so `translate`
 * translates it like any term.
 */
final class Gifts {

	/**
	 * Contents: list of {id, sku, qty, note}.
	 */
	public const META = '_lc_catalog_regalo';

	/**
	 * Taxonomy of the presentations.
	 */
	public const TAXONOMY = 'lc_presentacion';

	/**
	 * Term meta: words of the product name that give the presentation when migrating.
	 */
	public const KEYWORDS = '_lc_catalog_palabras';

	/**
	 * Most units of one product in a gift.
	 */
	public const MAX_QTY = 99;

	/**
	 * Registers the taxonomy and the meta.
	 */
	public static function register(): void {
		register_taxonomy(
			self::TAXONOMY,
			array( 'product' ),
			array(
				'labels'            => array(
					'name'          => _x( 'Presentaciones', 'taxonomy general name', 'lachinata-core' ),
					'singular_name' => _x( 'Presentación', 'taxonomy singular name', 'lachinata-core' ),
					'search_items'  => __( 'Buscar presentaciones', 'lachinata-core' ),
					'all_items'     => __( 'Todas las presentaciones', 'lachinata-core' ),
					'edit_item'     => __( 'Editar presentación', 'lachinata-core' ),
					'update_item'   => __( 'Actualizar presentación', 'lachinata-core' ),
					'add_new_item'  => __( 'Añadir presentación', 'lachinata-core' ),
					'new_item_name' => __( 'Nombre de la presentación', 'lachinata-core' ),
					'menu_name'     => __( 'Presentaciones', 'lachinata-core' ),
					'not_found'     => __( 'No hay presentaciones.', 'lachinata-core' ),
				),
				'public'            => false,
				'show_ui'           => true,
				'show_in_menu'      => true,
				'hierarchical'      => false,
				'show_admin_column' => true,
				'show_in_rest'      => true,
				// The gift box chooses it (one per gift).
				'meta_box_cb'       => false,
				'rewrite'           => false,
			)
		);
		register_post_meta(
			'product',
			self::META,
			array(
				'type'              => 'array',
				'single'            => true,
				'default'           => array(),
				'sanitize_callback' => array( self::class, 'clean' ),
				'auth_callback'     => static fn(): bool => current_user_can( 'edit_products' ),
				'show_in_rest'      => array(
					'schema' => array(
						'type'  => 'array',
						'items' => array(
							'type'       => 'object',
							'properties' => array(
								'id'   => array( 'type' => 'integer' ),
								'sku'  => array( 'type' => 'string' ),
								'qty'  => array( 'type' => 'integer' ),
								'note' => array( 'type' => 'string' ),
							),
						),
					),
				),
			)
		);
		register_term_meta(
			self::TAXONOMY,
			self::KEYWORDS,
			array(
				'type'              => 'string',
				'single'            => true,
				'sanitize_callback' => 'sanitize_text_field',
				'show_in_rest'      => true,
			)
		);
	}

	/**
	 * Clean rows: a product (id or SKU), from 1 to 99 units and an optional note. The same
	 * product twice adds up its units.
	 *
	 * @param mixed $value Raw value.
	 * @return array<int, array{id: int, sku: string, qty: int, note: string}>
	 */
	public static function clean( mixed $value ): array {
		$rows = array();
		foreach ( is_array( $value ) ? $value : array() as $row ) {
			$row = is_array( $row ) ? $row : array();
			$id  = absint( $row['id'] ?? 0 );
			$sku = sanitize_text_field( (string) ( $row['sku'] ?? '' ) );
			if ( ! $id && '' === $sku ) {
				continue;
			}
			$qty  = max( 1, min( self::MAX_QTY, absint( $row['qty'] ?? 1 ) ) );
			$key  = $id ? 'id:' . $id : 'sku:' . $sku;
			$note = sanitize_text_field( (string) ( $row['note'] ?? '' ) );
			if ( isset( $rows[ $key ] ) ) {
				$rows[ $key ]['qty'] = min( self::MAX_QTY, $rows[ $key ]['qty'] + $qty );
				continue;
			}
			$rows[ $key ] = array(
				'id'   => $id,
				'sku'  => $sku,
				'qty'  => $qty,
				'note' => $note,
			);
		}
		return array_values( $rows );
	}

	/**
	 * Stored rows of a gift.
	 *
	 * @param int $product_id Product id.
	 * @return array<int, array{id: int, sku: string, qty: int, note: string}>
	 */
	public static function rows( int $product_id ): array {
		return self::clean( get_post_meta( $product_id, self::META, true ) );
	}

	/**
	 * Whether a product is a composite gift.
	 *
	 * @param int $product_id Product id.
	 */
	public static function is_gift( int $product_id ): bool {
		return (bool) self::rows( $product_id );
	}

	/**
	 * Units in the gift (two packs of breadsticks are two products).
	 *
	 * @param int $product_id Product id.
	 */
	public static function units( int $product_id ): int {
		return (int) array_sum( array_column( self::rows( $product_id ), 'qty' ) );
	}

	/**
	 * Saves the rows with the SKU of each product as it is now.
	 *
	 * @param int               $product_id Product id.
	 * @param array<int, mixed> $rows       Rows.
	 */
	public static function save( int $product_id, array $rows ): void {
		$clean = array();
		foreach ( self::clean( $rows ) as $row ) {
			$product = self::product( $row );
			if ( $product ) {
				$row['id']  = $product->get_id();
				$row['sku'] = $product->get_sku();
			}
			$clean[] = $row;
		}
		if ( $clean ) {
			update_post_meta( $product_id, self::META, self::clean( $clean ) );
		} else {
			delete_post_meta( $product_id, self::META );
		}
	}

	/**
	 * Product of a row: by id and, when it no longer exists, by SKU.
	 *
	 * @param array{id: int, sku: string, qty: int, note: string} $row Row.
	 */
	public static function product( array $row ): ?\WC_Product {
		$product = $row['id'] ? wc_get_product( $row['id'] ) : null;
		if ( ! $product instanceof \WC_Product && '' !== $row['sku'] ) {
			$found   = wc_get_product_id_by_sku( $row['sku'] );
			$product = $found ? wc_get_product( $found ) : null;
		}
		return $product instanceof \WC_Product && 'trash' !== $product->get_status() ? $product : null;
	}

	/**
	 * Presentation of a gift (the first term), or null.
	 *
	 * @param int $product_id Product id.
	 */
	public static function presentation( int $product_id ): ?\WP_Term {
		$terms = get_the_terms( $product_id, self::TAXONOMY );
		return is_array( $terms ) && $terms ? $terms[0] : null;
	}

	/**
	 * Presentation for a product name, by the keywords of each presentation: the name starts
	 * with one of them as a whole word, ignoring case and accents («Box M…» is a box; «Pack
	 * Regalo…» is not a gift bag). The first match wins, in the order of the terms.
	 *
	 * @param string $name Product name.
	 */
	public static function presentation_for_name( string $name ): ?\WP_Term {
		$terms = get_terms(
			array(
				'taxonomy'   => self::TAXONOMY,
				'hide_empty' => false,
				'orderby'    => 'term_id',
			)
		);
		$name  = self::fold( trim( $name ) );
		foreach ( is_array( $terms ) ? $terms : array() as $term ) {
			foreach ( self::keywords( $term->term_id ) as $word ) {
				if ( preg_match( '/^' . preg_quote( self::fold( $word ), '/' ) . '($|[^\p{L}\p{N}])/u', $name ) ) {
					return $term;
				}
			}
		}
		return null;
	}

	/**
	 * Keywords of a presentation.
	 *
	 * @param int $term_id Term id.
	 * @return string[]
	 */
	public static function keywords( int $term_id ): array {
		return array_values( array_filter( array_map( 'trim', explode( ',', (string) get_term_meta( $term_id, self::KEYWORDS, true ) ) ) ) );
	}

	/**
	 * Lower case without accents, to compare names.
	 *
	 * @param string $text Text.
	 */
	private static function fold( string $text ): string {
		return mb_strtolower( remove_accents( $text ) );
	}
}
