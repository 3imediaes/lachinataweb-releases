<?php
/**
 * Taxonomy `tipo`: product seals (100% Vegetal, Cruelty free…) with an icon.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

defined( 'ABSPATH' ) || exit;

/**
 * Registers the taxonomy that the current site gets from a plugin that does not travel. In
 * a language other than Spanish its archive (`/en/tipo/{sello}/`, old addresses) goes to the
 * shop in that language, filtered by the seal when the shop filters by it (an attribute
 * `tipo` of WooCommerce with that term).
 */
final class TipoTaxonomy {

	public const TAXONOMY = 'tipo';

	/**
	 * The archive of a seal in another language: 301 to the shop in that language.
	 */
	public static function redirect(): void {
		if ( ! is_tax( self::TAXONOMY ) ) {
			return;
		}
		$languages = \LaChinata\Core\Services::languages();
		$current   = $languages->current();
		if ( $current === $languages->default_language() ) {
			return;
		}
		$shop = (string) get_permalink( wc_get_page_id( 'shop' ) );
		if ( '' === $shop ) {
			return;
		}
		$target    = $languages->url( $shop, $current );
		$term      = get_queried_object();
		$attribute = function_exists( 'wc_attribute_taxonomy_name' ) ? wc_attribute_taxonomy_name( self::TAXONOMY ) : '';
		if ( $term instanceof \WP_Term && '' !== $attribute && taxonomy_exists( $attribute ) && term_exists( $term->slug, $attribute ) ) {
			$target = add_query_arg( 'filter_' . self::TAXONOMY, rawurlencode( $term->slug ), $target );
		}
		wp_safe_redirect( $target, 301, 'lachinata-core' );
		exit;
	}

	/**
	 * Registers the taxonomy.
	 */
	public static function register(): void {
		register_taxonomy(
			self::TAXONOMY,
			array( 'product' ),
			array(
				'labels'            => array(
					'name'          => _x( 'Sellos', 'taxonomy general name', 'lachinata-core' ),
					'singular_name' => _x( 'Sello', 'taxonomy singular name', 'lachinata-core' ),
					'search_items'  => __( 'Buscar sellos', 'lachinata-core' ),
					'all_items'     => __( 'Todos los sellos', 'lachinata-core' ),
					'edit_item'     => __( 'Editar sello', 'lachinata-core' ),
					'update_item'   => __( 'Actualizar sello', 'lachinata-core' ),
					'add_new_item'  => __( 'Añadir sello', 'lachinata-core' ),
					'new_item_name' => __( 'Nombre del sello', 'lachinata-core' ),
					'menu_name'     => __( 'Sellos', 'lachinata-core' ),
					'not_found'     => __( 'No hay sellos.', 'lachinata-core' ),
				),
				'public'            => true,
				'hierarchical'      => false,
				'show_admin_column' => true,
				'show_in_rest'      => true,
				'rewrite'           => array( 'slug' => self::TAXONOMY ),
			)
		);
	}
}
