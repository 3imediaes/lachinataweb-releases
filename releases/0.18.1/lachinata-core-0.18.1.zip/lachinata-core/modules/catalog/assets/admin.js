/**
 * Image pickers of the catalog module (product tab and seal icon) and the rows of
 * «Contenido del regalo».
 */
(() => {
	const { __ } = window.wp.i18n;

	document.addEventListener('click', (event) => {
		const picker = event.target.closest('[data-lc-image-picker]');
		if (!picker) {
			return;
		}
		const input = picker.querySelector('input[type="hidden"]');
		const preview = picker.querySelector('[data-lc-preview]');
		const remove = picker.querySelector('[data-lc-remove]');

		if (event.target.closest('[data-lc-choose]')) {
			event.preventDefault();
			const frame = window.wp.media({
				title: __('Elegir imagen', 'lachinata-core'),
				library: { type: 'image' },
				multiple: false,
			});
			frame.on('select', () => {
				const image = frame.state().get('selection').first().toJSON();
				const thumb = image.sizes?.thumbnail?.url ?? image.url;
				input.value = image.id;
				preview.replaceChildren(
					Object.assign(document.createElement('img'), {
						src: thumb,
						alt: '',
						width: 80,
					})
				);
				remove.hidden = false;
			});
			frame.open();
		}

		if (event.target.closest('[data-lc-remove]')) {
			event.preventDefault();
			input.value = '';
			preview.replaceChildren();
			remove.hidden = true;
		}
	});

	// «Contenido del regalo»: a new row from the template, with WooCommerce's product search.
	let next = 0;
	document.addEventListener('click', (event) => {
		const box = event.target.closest('[data-lc-gift]');
		if (!box) {
			return;
		}
		if (event.target.closest('[data-lc-gift-add]')) {
			event.preventDefault();
			const template = box.querySelector('[data-lc-gift-template]');
			const html = template.innerHTML.replaceAll('__i__', `new${next++}`);
			box.querySelector('[data-lc-gift-rows]').insertAdjacentHTML(
				'beforeend',
				html
			);
			window.jQuery?.(document.body).trigger('wc-enhanced-select-init');
		}
		if (event.target.closest('[data-lc-gift-remove]')) {
			event.preventDefault();
			event.target.closest('tr').remove();
		}
	});
})();
