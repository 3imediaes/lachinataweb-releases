<?php
/**
 * WP-CLI: wp lachinata content.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Content;

use LaChinata\Core\Cli\Output;

defined( 'ABSPATH' ) || exit;

/**
 * Migration of the blog.
 */
final class Cli {

	/**
	 * Migrates the blog: format and section of every entry, the recipes to the block, the
	 * 301 of the old categories and the clicks of Search Console. With --dry-run it writes
	 * nothing and only reports.
	 *
	 * ## OPTIONS
	 *
	 * --map=<file>
	 * : JSON with the choices of the shop (sections, categories, types of dish, difficulties).
	 *
	 * [--gsc=<file>]
	 * : CSV of Search Console (pages: URL, clicks…).
	 *
	 * [--urls=<file>]
	 * : CSV with the live address of each entry (post_id, url_actual): it becomes its slug.
	 *
	 * [--report=<file>]
	 * : Where to write the report in Markdown (without it, on screen).
	 *
	 * [--force]
	 * : Write over the report if it already exists.
	 *
	 * [--dry-run]
	 * : Report only.
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata content migrate --map=blog.json --gsc=gsc.csv --report=informe.md --dry-run
	 *
	 * @param string[]              $args       Positional arguments.
	 * @param array<string, string> $assoc_args Options.
	 */
	public function migrate( array $args, array $assoc_args ): void {
		unset( $args );
		$file = (string) ( $assoc_args['map'] ?? '' );
		$map  = is_readable( $file ) ? json_decode( (string) file_get_contents( $file ), true ) : null; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- A local file of the command.
		if ( ! is_array( $map ) ) {
			\WP_CLI::error( __( 'No se puede leer el mapa (--map, JSON).', 'lachinata-core' ) );
		}
		Output::check( (string) ( $assoc_args['report'] ?? '' ), $assoc_args );
		$dry_run = isset( $assoc_args['dry-run'] );
		$gsc     = isset( $assoc_args['gsc'] ) ? (string) $assoc_args['gsc'] : null;
		$urls    = isset( $assoc_args['urls'] ) ? (string) $assoc_args['urls'] : null;
		$report  = ( new Migration() )->run( $map, $dry_run, $gsc, $urls );
		$text    = Migration::markdown( $report, $dry_run );
		if ( isset( $assoc_args['report'] ) ) {
			Output::write( (string) $assoc_args['report'], $text, $assoc_args );
			/* translators: %s: file. */
			\WP_CLI::success( sprintf( __( 'Informe en %s.', 'lachinata-core' ), (string) $assoc_args['report'] ) );
			return;
		}
		\WP_CLI::log( $text );
	}

	/**
	 * Review of the archive: imports the list and the clicks, proposes for the entries that
	 * are not in the list and, with --apply, applies the list (only once it is approved).
	 *
	 * ## OPTIONS
	 *
	 * [--list=<file>]
	 * : CSV of the list (post_id, url, tipo, clics_16m, propuesta, destino, motivo[, decision_final, destino_final]).
	 *
	 * [--gsc=<file>]
	 * : CSV of Search Console (pages).
	 *
	 * [--apply]
	 * : Apply the pending decisions.
	 *
	 * [--dry-run]
	 * : With --apply, say what would be done without doing it.
	 *
	 * [--report=<file>]
	 * : Where to write the report in Markdown.
	 *
	 * [--force]
	 * : Write over the report if it already exists.
	 *
	 * @param string[]              $args       Positional arguments.
	 * @param array<string, string> $assoc_args Options.
	 */
	public function review( array $args, array $assoc_args ): void {
		unset( $args );
		Output::check( (string) ( $assoc_args['report'] ?? '' ), $assoc_args );
		$out = array( '# Revisión del archivo', '' );
		if ( isset( $assoc_args['list'] ) ) {
			$stats = Archive::import_list( (string) $assoc_args['list'] );
			$out[] = sprintf( '- Lista: %1$d filas, %2$d entradas, %3$d con decisión final; sin entrada: %4$s.', $stats['rows'], $stats['matched'], $stats['final'], $stats['missing'] ? implode( ', ', $stats['missing'] ) : '—' );
		}
		if ( isset( $assoc_args['gsc'] ) ) {
			$stats = Archive::import_gsc( (string) $assoc_args['gsc'] );
			$out[] = sprintf( '- Search Console: %1$d filas, %2$d entradas.', $stats['rows'], $stats['matched'] );
		}
		$out[]    = sprintf( '- Entradas con enlaces internos entrantes: %d.', Archive::count_inbound() );
		$proposed = Archive::propose();
		$out[]    = sprintf( '- Propuestas de las reglas (entradas fuera de la lista): %s.', $proposed ? implode( ', ', array_map( static fn( $key, $value ): string => $key . ' ' . $value, array_keys( $proposed ), $proposed ) ) : '—' );
		$out[]    = '';
		$out[]    = '## Por mejorar';
		$out[]    = '';
		foreach ( Archive::to_improve() as $post ) {
			$out[] = sprintf( '- %1$s · %2$d clics · le falta: %3$s', Archive::label( $post ), (int) get_post_meta( $post->ID, Fields::CLICKS, true ), Archive::lacks( $post ) ? implode( ', ', Archive::lacks( $post ) ) : '—' );
		}
		if ( isset( $assoc_args['apply'] ) ) {
			$dry    = isset( $assoc_args['dry-run'] );
			$result = Archive::apply( $dry );
			$out[]  = '';
			$out[]  = '## ' . ( $dry ? 'Aplicar (en seco)' : 'Aplicado' );
			$out[]  = '';
			foreach ( $result['applied'] as $decision => $count ) {
				$out[] = sprintf( '- %1$s: %2$d', $decision, $count );
			}
			$names = array(
				'gone'    => __( '410', 'lachinata-core' ),
				'post'    => __( '301 a una entrada', 'lachinata-core' ),
				'section' => __( '301 a una sección', 'lachinata-core' ),
				'store'   => __( '301 a una oleoteca', 'lachinata-core' ),
				'product' => __( '301 a un producto', 'lachinata-core' ),
				'url'     => __( '301 a otra página', 'lachinata-core' ),
			);
			$out[] = '';
			$out[] = '### ' . __( 'Destinos', 'lachinata-core' );
			$out[] = '';
			foreach ( $result['targets'] as $type => $count ) {
				$out[] = sprintf( '- %1$s: %2$d', $names[ $type ] ?? $type, $count );
			}
			arsort( $result['paths'] );
			foreach ( $result['paths'] as $path => $count ) {
				$out[] = sprintf( '  - %1$s: %2$d', $path, $count );
			}
			if ( $result['notes'] ) {
				$out[] = '';
				$out[] = '### ' . __( 'Notas', 'lachinata-core' );
				$out[] = '';
			}
			foreach ( $result['notes'] as $note ) {
				$out[] = '- ' . $note;
			}
		}
		$text = implode( "\n", $out ) . "\n";
		if ( isset( $assoc_args['report'] ) ) {
			Output::write( (string) $assoc_args['report'], $text, $assoc_args );
			/* translators: %s: file. */
			\WP_CLI::success( sprintf( __( 'Informe en %s.', 'lachinata-core' ), (string) $assoc_args['report'] ) );
			return;
		}
		\WP_CLI::log( $text );
	}
}
