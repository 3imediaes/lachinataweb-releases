# Blog y recetas (`content`)

Desde la 0.13.0 (incremento 10a). Especificación: `design-system/sistema/08-contenido-seo.md`; composición: sección «Blog y recetas» de `02-plantillas.md` y los tableros Blog, Articulo, Receta y RecetaCocina (y sus versiones de escritorio).

## Qué hace

| Pieza | Cómo | Dónde |
| --- | --- | --- |
| **Modelo.** Las entradas siguen siendo `post` con su URL (`/slug/`). Formato (receta, artículo o noticia) en `_lc_content_formato`; secciones jerárquicas `lc_seccion` en `/blog/{seccion}/` (los tipos de plato son subsecciones de la sección de recetas: `/blog/recetas/postres/`); como mucho 20 temas `lc_tema` en `/blog/tema/{slug}/`; la revista en `/blog/`. Comentarios cerrados | taxonomías, regla de reescritura y `comments_open` | `Model.php`, `SectionFields.php` |
| **«En pocas palabras», revisión y fuentes.** Resumen visible arriba y base de la meta descripción; «Publicado el» siempre y «Actualizado el» solo con una revisión real (la fecha que marca el editor, nunca un guardado); fuentes enlazadas al pie | panel «Blog y recetas» del editor | `Editor.php`, `Dates.php`, `src/editor.js` |
| **Receta estructurada.** Bloque `lachinata/receta`: raciones, preparación, cocción y reposo (el total se calcula), dificultad, cocina, grupos de ingredientes (cantidad, unidad, ingrediente, nota y producto por ID y SKU), pasos con tiempo e imagen, consejos, variantes, conservación y vídeo (enlace, sin reproductor de terceros). Sin nutrición ni valoraciones | bloque dinámico; índice en metadatos al guardar | `Recipe.php`, `RecipeBlock.php`, `blocks/receta/` |
| **Plantillas.** Revista, sección o tema, artículo y receta con los componentes del grupo «Blog» (ArticleCard, RecipeCard, ArticleMeta, SummaryBox, Toc, RecipeHeader, IngredientList, StepList, CookMode, RecipeProducts). Índice automático desde 1.200 palabras | `template_include` con `Templates::locate()` | `Pages.php`, `Html.php`, `templates/content/` |
| **En el navegador.** Raciones que escalan (las cantidades que no son números no cambian), modo cocina con Screen Wake Lock y flechas del teclado, imprimir, la sección que se lee en el índice lateral. Sin JavaScript la receta está entera y sus casillas funcionan | módulo ES | `src/front.js` |
| **Ingredientes de la tienda.** «Ingredientes {marca} de esta receta» justo después de los ingredientes, con el «+» del tema (0.12.3) y «Añadir los N a la bolsa» (`?lc-add-many=`, también sin JavaScript). Un producto despublicado o agotado deja el ingrediente en texto | — | `Html::recipe_products()`, `AddMany.php` |
| **Recetas con un producto.** En la ficha (como mucho 3, debajo de todo lo que sirve para comprar, «Ver todas» a `/blog/recetas/?producto={id}` con `noindex`), en gracias y en el correo de pedido enviado («Ideas para tu {producto}»). Solo en las categorías del ajuste; nunca en la bolsa ni en el checkout | `lachinata/product/after`, `lachinata/thankyou/after`, `woocommerce_email_after_order_table` | `ProductRecipes.php` |
| **Contenido que caduca.** Aviso en las noticias de más de 12 meses (ajuste); lista «para revisar» con las entradas de salud y belleza sin revisar en 12 meses y las que tienen motivos (la migración; en 10b, productos que cambian y oleotecas que cierran) | aviso del panel y filtro de la lista de entradas | `Freshness.php` |
| **Datos estructurados.** `Organization` y `WebSite` en todo el sitio (de «Datos de la empresa», con «Redes» como `sameAs`), `BreadcrumbList`, `BlogPosting` o `Recipe` y `ItemList`. El autor es siempre la organización. Las entidades de Rank Math de esos tipos se quitan; Rank Math sigue con títulos, descripciones, sitemaps y redirecciones | `wp_head`, `rank_math/json_ld` | `Seo.php` |
| **Archivos antiguos.** 301 por regla: categoría a su sección (ajuste `category_sections`), etiqueta a la sección de su entrada más reciente, autor a `/blog/` | `template_redirect` | `Redirects.php` |
| **Referencias a producto** (0.13.1): un enlace a producto lleva `data-lc-product="{id}"`; al pintar, la dirección actual, y sin producto publicado solo el texto. Cada entrada guarda los productos y las oleotecas que menciona | `the_content`, al guardar | `Mentions.php` |
| **Contenido que caduca** (0.13.1): un cambio de ingredientes o sellos de un producto mencionado (posterior a la última revisión), un producto que deja de estar publicado, una oleoteca que cierra (con su aviso en la entrada) o que ya no existe mandan la entrada a «Revisar» con el motivo; una revisión real posterior lo da por resuelto. La lista va por clics | `lachinata/catalog/product_changed`, `product_discontinued`, `lachinata/oleotecas/closed` | `Mentions.php`, `Review.php`, `Freshness.php` |
| **Revisión del archivo** (0.13.1): WooCommerce → La Chinata → Revisión de contenido y `wp lachinata content review`. Importa la lista (con `decision_final` y `destino_final`, que mandan) y el CSV de Search Console, cuenta los enlaces internos entrantes y propone con las reglas de 08 solo para lo que no está en la lista (fusiones: mismo producto principal y título parecido, o misma palabra clave de Rank Math). Con la lista aprobada, la aplica en bloque: «Retirada» con su 410 (solo sin enlaces internos) o su 301 por ID, la principal de una fusión a «Revisar». «Por mejorar»: las de mantener y mejorar, por clics, con lo que les falta | WP-CLI, `admin-post` | `Archive.php`, `ArchiveTab.php`, `Retired.php` |
| **«Retirada»**: estado propio, no público, fuera de listados, búsquedas y sitemaps, con su contenido y métricas; responde 410 o la 301 guardada (por ID; si el destino desaparece, a su sección y la salud lo dice); desde 0.17.1, también bajo otro idioma (`/en/…`, por el contrato `Languages`), con la 301 a la dirección de ese idioma. Se deshace volviendo a publicar | `register_post_status`, `template_redirect` | `Retired.php` |
| **`llms.txt`** (uno por idioma) y **rastreadores** (0.13.1): quién es (Datos de la empresa y un texto), páginas clave (ajuste, buscador de oleotecas, categorías de la tienda), los 30 artículos y las 30 recetas con más clics que tienen resumen (fijar o excluir por entrada); nunca noticias, «Retiradas» ni en «Revisar». `robots.txt`: todos permitidos, reglas por agente en el panel, filtros, parámetros, bolsa, checkout y cuenta cerrados para todos | reescritura, `robots_txt` | `Ai.php` |
| **Migración.** `wp lachinata content migrate --map=… [--gsc=…] [--urls=…] [--report=…] [--dry-run]`: la dirección actual de cada entrada como su slug (`--urls`; el antiguo, con 301), secciones, formato y sección de cada entrada, recetas del esquema de Rank Math y del texto al bloque (analizador de ingredientes que marca lo dudoso; lo que pasa al bloque sale del texto), subsecciones desde `recipeCategory`, lo que está en la categoría de recetas sin serlo (sin esquema ni ingredientes con cantidad: prensa, concursos) al formato y la sección `not_recipe` del mapa, 301 de categorías, clics de Search Console y códigos cortos, con informe en Markdown. Idempotente | WP-CLI | `Migration.php`, `Ingredients.php`, `RecipeText.php`, `Cli.php` |

## Depende de

- WooCommerce 10 (productos de las recetas). Ningún módulo obligatorio.
- Tema `lachinata` para el aspecto (`blog.css`, `components.css`), los hooks de la ficha y de gracias, la bolsa y el «+». Con otro tema las páginas salen con las clases `.lc-*` sin vestir.
- Rank Math (opcional): sin él, el módulo pinta la meta descripción y el canonical de sus páginas.
- Núcleo: `Company` («Datos de la empresa» y «Redes»), `Templates`, `Settings`, `Hooks`.

## Hooks que escucha

- Módulos (0.13.1): `lachinata/catalog/product_changed`, `lachinata/catalog/product_discontinued`, `lachinata/oleotecas/closed`; filtros que pregunta: `lachinata/oleotecas/status`, `slug_of`, `names`.
- WordPress: `init`, `query_vars`, `robots_txt`, `pre_get_posts`, `template_include`, `template_redirect`, `wp_head`, `wp_robots`, `document_title_parts`, `comments_open`, `pings_open`, `pre_insert_term`, `save_post_post`, `enqueue_block_editor_assets`, `admin_notices`, `wp_loaded` (añadir varios), `lc_seccion_add_form_fields`, `lc_seccion_edit_form_fields`, `created_lc_seccion`, `edited_lc_seccion`.
- WooCommerce: `woocommerce_email_after_order_table` (pedido enviado).
- Tema: `lachinata/breadcrumb/items`, `lachinata/view/editorial`, `lachinata/view/blog`, `lachinata/view/secondary`, `lachinata/view/back_url`, `lachinata/app_bar/section`, `lachinata/product/after`, `lachinata/thankyou/after`. Filtros del tema que pregunta en «Ingredientes de esta receta»: `lachinata/product_card/attributes`; desde 0.16.0, `lachinata/catalog/cutout` y `lachinata/product/tint` (una foto recortada, sobre la tinta del producto con `lc-img--recorte`).
- Rank Math: `rank_math/json_ld`, `rank_math/frontend/canonical`, `rank_math/frontend/description`, `rank_math/frontend/title`.
- Núcleo: `lachinata/core/admin_tabs`.
- `lachinata/translate/fields` (0.15.0): declara para `translate` «En pocas palabras», las fuentes y las secciones (nombre, descripción y slug: `/en/blog/{sección}/`). `llms.txt` de cada idioma se escribe en ese idioma (`Languages::switch_to()`) y solo con las entradas que existen en él (`Languages::available()`); `/en/llms.txt` llega como `/llms.txt` en inglés.

## Hooks que emite

- En el navegador: `lachinata:recipe:view`, `:scale`, `:print`, `:cook_mode`, `:ingredient_product` y `lachinata:article:read` (`theme/HOOKS.md`, «Eventos del navegador»), que `tracking` manda a GA4.
- `lachinata/content/published_in` (0.13.1), para `translate`.
- Lee (no emite) `lachinata/category/tint` y `lachinata/product/unit_price` del tema.

## Datos que guarda

- Entradas: `_lc_content_formato`, `_lc_content_resumen`, `_lc_content_revisado`, `_lc_content_fuentes` (panel del editor); `_lc_content_receta`, `_lc_content_producto` (una fila por producto), `_lc_content_minutos`, `_lc_content_palabras` (índice que se reescribe al guardar); `_lc_content_clics` (Search Console) y `_lc_content_revisar` (motivos).
- La receta misma vive en los atributos del bloque `lachinata/receta`, en el contenido de la entrada.
- Entradas (0.13.1): `_lc_content_menciona`, `_lc_content_oleoteca` (índices), `_lc_content_llms`, `_lc_content_poda`, `_lc_content_impresiones`, `_lc_content_entrantes`, `_lc_content_destino`; estado `lc_retirada`.
- Términos de `lc_seccion`: `_lc_content_categoria` y `_lc_content_orden`.
- Taxonomías `lc_seccion` y `lc_tema`; opción `lachinata_content_rewrite` (versión de las reglas de reescritura).
- Las entradas y sus campos son contenido del sitio: «Borrar datos» solo borra los metadatos de término y las opciones.

## REST y API para Odoo

Ninguna ruta propia. Los campos del panel van por la REST de WordPress (`meta` de `post`). Nada para Odoo.

## Ajustes y exportación

WooCommerce → La Chinata → Blog. Viajan en el JSON: `blog_eyebrow`, `blog_title`, `blog_lead` (textos de la revista; sin ellos, «La revista de {marca}» y «Blog»), `recipe_section`, `health_sections`, `product_recipes` y `category_sections` (por slug), `subsection_minimum` (6), `review_months` (12), `news_warning_months` (12), `llms_about`, `llms_articles` (30), `llms_recipes` (30) y `crawlers`. Son de cada sitio y no viajan: `llms_pages` (la página de cada tipo: `about`, `shipping`, `faq`, `contact`; la lista de la 0.13.1 se lee en ese orden) y `own_hosts` (dominios de la tienda en los textos antiguos). Las secciones y los temas son contenido: no viajan.

## Qué pasa al apagarlo

Las entradas vuelven a la plantilla `single.php` del tema, sin receta (el bloque no se pinta), sin `/blog/` ni secciones (404), sin redirecciones de categorías y sin el schema propio (vuelve el de Rank Math). Los datos se quedan y vuelven al encenderlo.

## Pruebas

- PHPUnit (`plugin/modules/content/tests/`): analizador de ingredientes y del texto de las recetas, receta como datos (tiempos, cantidades, productos por ID y SKU, índice), recetas de un producto y su ajuste, modelo (temas, slugs reservados, formatos, comentarios), fechas, noticia antigua, salud y belleza sin revisar, subsecciones, redirecciones, índice y tiempo de lectura, datos estructurados y la migración (en seco, de verdad e idempotente).
- e2e (`tests/e2e/content.spec.mjs`, sobre `tools/seed-blog.php`): revista, receta (raciones, casillas, modo cocina), ingredientes de la tienda y «Añadir los 2», artículo largo con índice y fuentes, noticia antigua, recetas en la ficha con «Ver todas», datos estructurados, archivos antiguos y la receta sin JavaScript.
- Lighthouse: revista, artículo y receta con mínimo 95 (`tools/lighthouse.mjs`).

## Huecos conocidos

- 10b (0.13.1): la sección de las entradas de la antigua «Productos» por la categoría raíz de los productos que enlazan; enlaces a producto en el texto como referencias, revisión del archivo con la poda, `llms.txt`, rastreadores por agente, medición, entradas a «Revisar» cuando cambia un producto y aviso de oleoteca cerrada.
- `translate` (11): textos, ingredientes, pasos y slugs por idioma por el contrato `Languages`; hoy todo es una cadena traducible o contenido del sitio.
- El texto de una receta migrada que no es receta (la introducción) va después de los consejos; el tablero no lo muestra.
