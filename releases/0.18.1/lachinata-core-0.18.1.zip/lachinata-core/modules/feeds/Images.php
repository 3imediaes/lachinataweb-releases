<?php
/**
 * Cutout photos outside the website: feeds and Open Graph.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Feeds;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * Outside the website a transparent background may show black or grey (Merchant Center,
 * WhatsApp and social previews). So a cutout (`lachinata/catalog/cutout`) goes to Google
 * and Meta as a JPEG on white, and the Open Graph image of a product with a cutout is the
 * product on the tint of its family, as a 1200 × 630 JPEG. Both files sit next to the
 * original (`<name>-lc-blanco.jpg`, `<name>-lc-og-<tint>.jpg`), are made the first time
 * they are asked for and again when the original changes, and go with the attachment.
 */
final class Images {

	/**
	 * Open Graph width.
	 */
	public const OG_WIDTH = 1200;

	/**
	 * Open Graph height.
	 */
	public const OG_HEIGHT = 630;

	/**
	 * JPEG quality.
	 */
	private const QUALITY = 85;

	/**
	 * Air around the product in the Open Graph image, per side.
	 */
	private const AIR = 0.08;

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'delete_attachment', array( self::class, 'delete' ) );
		Hooks::add_filter( 'rank_math/opengraph/facebook/image_array', array( self::class, 'rank_math' ) );
		Hooks::add_filter( 'rank_math/opengraph/twitter/image_array', array( self::class, 'rank_math' ) );
		Hooks::add_filter( 'wpseo_opengraph_image', array( self::class, 'yoast' ) );
		Hooks::add_action( 'wp_head', array( self::class, 'head' ), 5 );
	}

	/**
	 * Whether an image is a cutout (module `catalog`).
	 *
	 * @param int $attachment_id Attachment id.
	 */
	public static function is_cutout( int $attachment_id ): bool {
		/** This filter is documented in theme/inc/catalog.php */
		return $attachment_id > 0 && (bool) apply_filters( 'lachinata/catalog/cutout', false, $attachment_id ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingSinceComment -- The theme's hook.
	}

	/**
	 * Image for the feeds: the JPEG on white of a cutout, the original otherwise.
	 *
	 * @param int $attachment_id Attachment id.
	 */
	public static function feed_url( int $attachment_id ): string {
		$url = (string) wp_get_attachment_image_url( $attachment_id, 'full' );
		if ( ! self::is_cutout( $attachment_id ) ) {
			return $url;
		}
		$flat = self::make( $attachment_id, 'blanco', '#ffffff', false );
		return '' !== $flat ? $flat : $url;
	}

	/**
	 * Open Graph image of a product: its cutout on the tint of its family, or '' when its
	 * photo has a background (the SEO plugin's image stays).
	 *
	 * @param \WC_Product $product Product.
	 */
	public static function og_url( \WC_Product $product ): string {
		$id = (int) $product->get_image_id();
		if ( ! self::is_cutout( $id ) ) {
			return '';
		}
		/** This filter is documented in theme/inc/catalog.php */
		$tint = sanitize_key( (string) apply_filters( 'lachinata/product/tint', '', $product ) ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingSinceComment -- The theme's hook.
		$hex  = self::tint_color( $tint );
		return self::make( $id, 'og-' . ( '' !== $hex ? $tint : 'blanco' ), '' !== $hex ? $hex : '#ffffff', true );
	}

	/**
	 * Colour of a tint, from the palette of the theme (`tint-<slug>` in theme.json).
	 *
	 * @param string $tint Tint slug.
	 */
	public static function tint_color( string $tint ): string {
		if ( '' === $tint ) {
			return '';
		}
		foreach ( self::palette() as $slug => $color ) {
			if ( 'tint-' . $tint === $slug ) {
				return $color;
			}
		}
		return '';
	}

	/**
	 * Tints of the theme palette: slug => hex colour.
	 *
	 * @return array<string, string>
	 */
	private static function palette(): array {
		$colors = array();
		$theme  = wp_get_global_settings( array( 'color', 'palette', 'theme' ) );
		foreach ( is_array( $theme ) ? $theme : array() as $entry ) {
			$slug  = is_array( $entry ) ? (string) ( $entry['slug'] ?? '' ) : '';
			$color = is_array( $entry ) ? (string) ( $entry['color'] ?? '' ) : '';
			if ( str_starts_with( $slug, 'tint-' ) && preg_match( '/^#[0-9a-f]{6}$/i', $color ) ) {
				$colors[ $slug ] = $color;
			}
		}
		return $colors;
	}

	/**
	 * Makes (or reuses) a flattened JPEG of an image.
	 *
	 * @param int    $attachment_id Attachment id.
	 * @param string $suffix        File suffix after `-lc-`.
	 * @param string $hex           Background colour.
	 * @param bool   $og            Open Graph canvas (1200 × 630, product with air) instead of the image's own size.
	 * @return string URL, or '' when it cannot be made.
	 */
	private static function make( int $attachment_id, string $suffix, string $hex, bool $og ): string {
		$source = get_attached_file( $attachment_id );
		$url    = wp_get_attachment_url( $attachment_id );
		if ( ! is_string( $source ) || ! is_string( $url ) || ! is_readable( $source ) ) {
			return '';
		}
		$target = self::path( $source, $suffix );
		$link   = trailingslashit( dirname( $url ) ) . rawurlencode( basename( $target ) );
		if ( is_readable( $target ) && filemtime( $target ) >= filemtime( $source ) ) {
			return $link;
		}
		return self::render( $source, $target, $hex, $og ) ? $link : '';
	}

	/**
	 * Path of a derived file.
	 *
	 * @param string $source Original file.
	 * @param string $suffix Suffix after `-lc-`.
	 */
	private static function path( string $source, string $suffix ): string {
		return trailingslashit( dirname( $source ) ) . pathinfo( $source, PATHINFO_FILENAME ) . '-lc-' . $suffix . '.jpg';
	}

	/**
	 * Draws the image on its background and saves it as a JPEG.
	 *
	 * @param string $source Original file.
	 * @param string $target JPEG to write.
	 * @param string $hex    Background colour.
	 * @param bool   $og     Open Graph canvas.
	 */
	private static function render( string $source, string $target, string $hex, bool $og ): bool {
		if ( ! function_exists( 'imagecreatefromstring' ) ) {
			return false;
		}
		wp_raise_memory_limit( 'image' );
		$image = @imagecreatefromstring( (string) file_get_contents( $source ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local file; a broken file keeps the original.
		if ( false === $image ) {
			return false;
		}
		$width    = imagesx( $image );
		$height   = imagesy( $image );
		$canvas_w = $og ? self::OG_WIDTH : $width;
		$canvas_h = $og ? self::OG_HEIGHT : $height;
		$canvas   = imagecreatetruecolor( max( 1, $canvas_w ), max( 1, $canvas_h ) );
		$rgb      = sscanf( $hex, '#%02x%02x%02x' );
		imagefill( $canvas, 0, 0, (int) imagecolorallocate( $canvas, (int) ( $rgb[0] ?? 255 ), (int) ( $rgb[1] ?? 255 ), (int) ( $rgb[2] ?? 255 ) ) );
		imagealphablending( $canvas, true );
		if ( $og ) {
			$scale = min( $canvas_w * ( 1 - 2 * self::AIR ) / $width, $canvas_h * ( 1 - 2 * self::AIR ) / $height );
			$dst_w = (int) round( $width * $scale );
			$dst_h = (int) round( $height * $scale );
			imagecopyresampled( $canvas, $image, (int) ( ( $canvas_w - $dst_w ) / 2 ), (int) ( ( $canvas_h - $dst_h ) / 2 ), 0, 0, $dst_w, $dst_h, $width, $height );
		} else {
			imagecopy( $canvas, $image, 0, 0, 0, 0, $width, $height );
		}
		return imagejpeg( $canvas, $target, self::QUALITY );
	}

	/**
	 * The derived files go with the attachment.
	 *
	 * @param int $attachment_id Attachment id.
	 */
	public static function delete( $attachment_id ): void {
		$source = get_attached_file( (int) $attachment_id );
		if ( ! is_string( $source ) || '' === $source ) {
			return;
		}
		$suffixes = array_merge( array( 'blanco', 'og-blanco' ), array_map( static fn( string $slug ): string => 'og-' . substr( $slug, 5 ), array_keys( self::palette() ) ) );
		foreach ( $suffixes as $suffix ) {
			$file = self::path( $source, $suffix );
			if ( is_file( $file ) ) {
				wp_delete_file( $file );
			}
		}
	}

	/**
	 * Product being viewed, or null.
	 */
	private static function product(): ?\WC_Product {
		if ( ! is_singular( 'product' ) ) {
			return null;
		}
		$product = wc_get_product( get_queried_object_id() );
		return $product instanceof \WC_Product ? $product : null;
	}

	/**
	 * Rank Math: its image of the product photo becomes ours (an image chosen in Rank Math
	 * for that product stays).
	 *
	 * @param mixed $attachment Image Rank Math is about to add.
	 * @return mixed
	 */
	public static function rank_math( $attachment ) {
		$product = self::product();
		if ( null === $product || ! is_array( $attachment ) || ! self::is_photo( $attachment, (int) $product->get_image_id() ) ) {
			return $attachment;
		}
		$og = self::og_url( $product );
		if ( '' === $og ) {
			return $attachment;
		}
		return array(
			'url'    => $og,
			'width'  => self::OG_WIDTH,
			'height' => self::OG_HEIGHT,
			'type'   => 'image/jpeg',
			'alt'    => (string) ( $attachment['alt'] ?? '' ),
		);
	}

	/**
	 * Whether an image of Rank Math is the product photo (any of its sizes).
	 *
	 * @param array<string, mixed> $attachment    Rank Math's image.
	 * @param int                  $attachment_id Product photo.
	 */
	private static function is_photo( array $attachment, int $attachment_id ): bool {
		if ( isset( $attachment['id'] ) ) {
			return (int) $attachment['id'] === $attachment_id;
		}
		$full = (string) wp_get_attachment_url( $attachment_id );
		$stem = '' !== $full ? substr( $full, 0, (int) strrpos( $full, '.' ) ) : '';
		return '' !== $stem && str_starts_with( (string) ( $attachment['url'] ?? '' ), $stem );
	}

	/**
	 * Yoast: the image of a product with a cutout.
	 *
	 * @param mixed $image Theirs.
	 * @return mixed
	 */
	public static function yoast( $image ) {
		$product = self::product();
		$og      = null === $product ? '' : self::og_url( $product );
		return '' === $og ? $image : $og;
	}

	/**
	 * Without an SEO plugin, the Open Graph image of a product with a cutout.
	 */
	public static function head(): void {
		if ( defined( 'RANK_MATH_VERSION' ) || defined( 'WPSEO_VERSION' ) ) {
			return;
		}
		$product = self::product();
		$og      = null === $product ? '' : self::og_url( $product );
		if ( '' === $og ) {
			return;
		}
		printf( '<meta property="og:image" content="%s">' . "\n", esc_url( $og ) );
		printf( '<meta property="og:image:width" content="%d">' . "\n", (int) self::OG_WIDTH );
		printf( '<meta property="og:image:height" content="%d">' . "\n", (int) self::OG_HEIGHT );
		echo '<meta property="og:image:type" content="image/jpeg">' . "\n";
	}
}
