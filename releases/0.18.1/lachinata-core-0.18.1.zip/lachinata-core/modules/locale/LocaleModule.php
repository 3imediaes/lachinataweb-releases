<?php
/**
 * Module `locale`: the visitor's destination.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Locale;

use LaChinata\Core\Hooks;
use LaChinata\Core\Module;
use LaChinata\Core\Plugin;
use LaChinata\Core\Services;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Where the visitor receives the order: the first-visit picker (MarketPicker), the badge
 * in the header (MarketBadge), the `lc_destino` cookie that the cart, the shipping
 * threshold and the delivery estimate read, the way to another shop and the catalogue by
 * destination. Destinations, notes and other shops are settings of each shop; with a
 * single destination and a single language nothing is shown.
 */
final class LocaleModule extends Module {

	/**
	 * Module id.
	 */
	public function id(): string {
		return 'locale';
	}

	/**
	 * Module name.
	 */
	public function label(): string {
		return __( 'Destino', 'lachinata-core' );
	}

	/**
	 * Module description.
	 */
	public function description(): string {
		return __( 'Pregunta en la primera visita dónde se recibe el pedido, lo muestra en la cabecera y en el pie, lleva a otra tienda cuando el destino es suyo y oculta lo que no se envía allí. Los destinos y las otras tiendas se configuran en Destino.', 'lachinata-core' );
	}

	/**
	 * Version in which the module was added.
	 */
	public function since(): string {
		return '0.11.0';
	}

	/**
	 * Documentation.
	 */
	public function docs(): string {
		return 'plugin/modules/locale/README.md';
	}

	/**
	 * Requirements.
	 *
	 * @return array{woocommerce: string}
	 */
	public function requires(): array {
		return array( 'woocommerce' => '10.0' );
	}

	/**
	 * Settings: how the page cache behaves travels; the CDN header belongs to each site.
	 *
	 * @return array<string, array{type: 'bool'|'int'|'float'|'string'|'array', default: mixed, export?: bool}>
	 */
	public function settings(): array {
		return array(
			'cache_mode' => array(
				'type'    => 'string',
				'default' => 'vary',
				'export'  => true,
			),
			'geo_header' => array(
				'type'    => 'string',
				'default' => '',
				'export'  => false,
			),
		);
	}

	/**
	 * The module, for Settings.
	 */
	public static function instance(): ?Module {
		return Plugin::instance()->modules()->get( 'locale' );
	}

	/**
	 * A setting of the module.
	 *
	 * @param string $key Setting key.
	 * @return mixed
	 */
	public static function setting( string $key ) {
		$module = self::instance();
		return null === $module ? null : Settings::get( $module, $key );
	}

	/**
	 * Destinations and other shops, once saved (without it, each site takes its own
	 * countries of sale).
	 *
	 * @return array<string, mixed>
	 */
	public function export_data(): array {
		if ( ! is_array( get_option( Config::DESTINATIONS, null ) ) ) {
			return array();
		}
		return array(
			'destinations' => Config::destinations(),
			'stores'       => Config::stores(),
		);
	}

	/**
	 * Problems of an imported configuration.
	 *
	 * @param array<string, mixed> $data Section.
	 * @return string[]
	 */
	public function validate_data( array $data ): array {
		return $data ? Config::validate( $data ) : array();
	}

	/**
	 * Writes an imported configuration and recalculates the catalogue.
	 *
	 * @param array<string, mixed> $data Section.
	 */
	public function import_data( array $data ): void {
		if ( $data ) {
			Config::save( $data );
			Catalog::schedule();
		}
	}

	/**
	 * Version of the data: v1 calculates the catalogue by destination.
	 */
	public function schema_version(): int {
		return 1;
	}

	/**
	 * Steps of the data.
	 *
	 * @return array<int, callable(): void>
	 */
	public function migrations(): array {
		return array( 1 => array( Catalog::class, 'schedule' ) );
	}

	/**
	 * Destinations, the free shipping threshold of each one of the main list, the cache
	 * mode and the state of the catalogue.
	 *
	 * @return array{configured: bool, credentials: null, notes: string[]}
	 */
	public function health(): array {
		$own   = Config::own();
		$notes = array(
			sprintf(
				/* translators: 1: destinations of this shop, 2: destinations of other shops. */
				__( 'Destinos: %1$d de esta tienda y %2$d de otras tiendas.', 'lachinata-core' ),
				count( $own ),
				count( Config::destinations() ) - count( $own )
			),
		);
		if ( ! Config::selectable( count( Services::languages()->languages() ) ) ) {
			$notes[] = __( 'Un solo destino y un solo idioma: sin selector ni pastilla.', 'lachinata-core' );
		}
		$rules = Services::shipping_rules();
		if ( null === $rules ) {
			$notes[] = __( 'Sin el módulo de envíos, el catálogo no se filtra por destino ni se muestra el umbral de cada uno.', 'lachinata-core' );
		} else {
			foreach ( $own as $destination ) {
				if ( 'main' !== $destination['list'] ) {
					continue;
				}
				$threshold = $rules->free_shipping_from( Config::location( $destination ) );
				$notes[]   = null === $threshold
					/* translators: %s: destination. */
					? sprintf( __( '%s: sin envío gratis.', 'lachinata-core' ), $destination['label'] )
					/* translators: 1: destination, 2: amount («60 €»). */
					: sprintf( __( '%1$s: envío gratis desde %2$s.', 'lachinata-core' ), $destination['label'], Rest::plain_price( $threshold ) );
			}
		}
		$notes[] = 'none' === self::setting( 'cache_mode' )
			? __( 'Caché sin destino: el navegador completa cada página.', 'lachinata-core' )
			: __( 'La caché de página varía por lc_destino (o no hay caché).', 'lachinata-core' );
		if ( Catalog::pending() ) {
			$notes[] = __( 'Recalculando el catálogo por destino.', 'lachinata-core' );
		}
		return array(
			'configured'  => (bool) $own,
			'credentials' => null,
			'notes'       => $notes,
		);
	}

	/**
	 * The taxonomy always; picker, badge and catalogue with more than one destination or
	 * language.
	 */
	public static function boot_storefront(): void {
		Catalog::register();
		if ( Config::selectable( count( Services::languages()->languages() ) ) ) {
			Front::boot();
			Catalog::boot();
		}
	}

	/**
	 * What it keeps beyond its options: the destination of each user.
	 *
	 * @return array{user_meta: string[], options: string[]}
	 */
	public function owned_data(): array {
		return array(
			'user_meta' => array( Visitor::META ),
			'options'   => array( Config::DESTINATIONS, Config::STORES, 'lachinata_locale_indexed' ),
		);
	}

	/**
	 * Declares for `translate` the texts of the destinations (name and note).
	 *
	 * @param mixed $options Options of other modules.
	 * @return array<string, array<string, mixed>>
	 */
	public static function translatable( $options ): array {
		$options                         = is_array( $options ) ? $options : array();
		$options[ Config::DESTINATIONS ] = array(
			'label' => __( 'Destinos', 'lachinata-core' ),
			'paths' => array( '*.label', '*.note' ),
		);
		return $options;
	}

	/**
	 * Registers the hooks.
	 */
	public function boot(): void {
		Visitor::boot();
		Chooser::boot();
		Rest::boot();
		Hooks::add_action( 'init', array( self::class, 'boot_storefront' ), 1 );
		Hooks::add_filter( 'lachinata/translate/options', array( self::class, 'translatable' ) );
		if ( is_admin() ) {
			LocaleTab::boot();
		}
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::add_command( 'lachinata locale', Cli::class );
		}
	}
}
