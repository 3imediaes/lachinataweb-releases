# Módulo `locale`

El destino del visitante: dónde recibe el pedido. Pregunta en la primera visita con el selector (`MarketPicker`) y lo muestra en la cabecera (`MarketBadge`) y en el pie. Lo guarda para que la bolsa, el umbral de envío gratis y la fecha estimada calculen con él. Lleva a otra tienda cuando el destino es suyo y oculta lo que no se envía allí.

Sirve para cualquier tienda: destinos, notas, tiendas de destino y umbrales mostrados son configuración del panel (WooCommerce → La Chinata → Destino), nunca código. **Una tienda con un solo destino y un solo idioma no muestra ni selector, ni pastilla, ni enlace en el pie.**

Especificación: `design-system/sistema/05-localizacion.md` («Elegir destino e idioma al entrar», «Catálogo según destino», «Componentes del sistema») y los componentes `MarketPicker` y `MarketBadge`. Decisiones en `design-system/docs/decisiones.md` («Destino del visitante»). Guía de configuración: `docs/guias/locale.md`.

## Qué hace

| Pieza | Cómo | Dónde |
| --- | --- | --- |
| **Destinos**: id ISO 3166-1 o 3166-2 (`PT`, `ES-IB`), etiqueta, nota opcional (`{envio_gratis}` se cambia por el umbral del destino), tienda (esta o una de «Otras tiendas»), lista (principal, como mucho 8, u «Otro país») y provincias o estados de WooCommerce. Una fila de país sin subdivisión (`ES`) es ese país salvo las subdivisiones con fila propia. Las provincias salen solas para las comunidades españolas (`ES-CN` → `GC`, `TF`) y para cualquier subdivisión con el mismo código en WooCommerce. Sin configuración, los países de venta de WooCommerce, el de la tienda primero | panel, JSON | `Config.php`, `LocaleTab.php` |
| **Cookie `lc_destino`** (un año, `SameSite=Lax`, en el dominio de la tienda) con el id de un destino de esta tienda; meta `_lc_locale_destination` si hay sesión. Al iniciar sesión manda la del perfil; sin ella, el perfil guarda la de la cookie | | `Visitor.php` |
| **Cliente de WooCommerce**: país y provincia (envío y facturación, como su calculadora) en cuanto el visitante tiene sesión de WooCommerce, nunca antes (abrir una sesión le sacaría de la caché). Se aplica una vez por destino: lo que escriba después en el checkout manda | `woocommerce_cart_loaded_from_session`, `woocommerce_add_to_cart` | `Visitor.php` |
| **Destino de las páginas en caché** (`lachinata/shipping/destination`): PromoBar, UspBar y ficha calculan con el destino de la cookie cuando la caché varía por ella. El endpoint de la fecha estimada recibe la cookie como `?destino=ES-IB` y aquí se traduce a `ES:PM` (`lachinata/eta/rest_destination`) | filtros | `Visitor.php` |
| **Selector** con el HTML de `MarketPicker` en una capa del tema: `BottomSheet` en móvil, diálogo de 480 px desde 768 px. Es un formulario `POST` (funciona sin JavaScript: «Cambiar destino» del pie lleva a la misma página con `?lc-destino=elegir`, que lo pinta abierto). Escape cierra, el foco queda atrapado y el fondo inerte (capas del tema). En la primera visita se abre solo con la preselección por ubicación, dicha en el texto de ayuda («Te hemos situado en … por tu conexión»). Si se cierra sin elegir, se aplica la preselección cuando es de esta tienda; si es de otra, no se redirige y no vuelve a salir hasta cerrar el navegador (`lc_destino_visto`). «Otro país» manda sobre la lista. Con un destino de otra tienda, el botón dice «Ir a la tienda de …» | `wp_footer`, `lachinata:layer:open` | `Front.php`, `assets/locale.js` |
| **Ubicación**: la cabecera de país del CDN configurada en el panel (`CF-IPCountry`…) o la geolocalización de WooCommerce (MaxMind o las cabeceras de CDN que conoce). Solo preselecciona | `GET /lachinata/v1/locale?sugerir=1` | `Rest.php` |
| **Cookies después del destino**: el script del `<head>` marca la primera visita (`data-lc-locale-pending` en `<html>`) y `tracking` no muestra su barra hasta `lachinata:locale:done`. Nunca los dos a la vez. En el checkout no hay selector | | `Front::head()`, `tracking/src/consent.js` |
| **Pastilla** `MarketBadge` («Envío a España · Península») al principio de la PromoBar en móvil y en la AppBar de escritorio junto a Oleotecas y Blog; «Cambiar destino» en la línea legal del pie. Abren el selector. El idioma solo aparece si `Contracts\Languages` devuelve más de uno | `lachinata/promo_bar/start`, `lachinata/app_bar/utilities`, `lachinata/footer/legal` | `Front.php` |
| **Al continuar** con un destino de esta tienda: cookie, perfil y cliente de WooCommerce, y se recarga la misma página. Con uno de otra tienda: 302 a la misma ruta en esa tienda con `?destino=ES-CN`. El host sale siempre de «Otras tiendas» (también en `allowed_redirect_hosts`), nunca de la petición; la ruta es solo una ruta. Sin nonce, porque la página va en caché y es una preferencia: solo acepta ids configurados y una petición con Origin o Referer de otro sitio se ignora | `wp_loaded` | `Chooser.php` |
| **Llegada** desde otra tienda (`?destino=ES-CN`): si el destino es de esta tienda, lo guarda; después, 302 a la misma dirección sin el parámetro, o a la home si la ruta no existe aquí | `template_redirect` | `Chooser.php` |
| **«Parece que estás en …»**: si la ubicación apunta a otra tienda y el visitante ya eligió, un `Notice` en la zona de avisos (fija, sin mover la página), una sola vez (`lc_destino_aviso`). «Ir a la tienda» envía el formulario con ese destino: nunca se redirige sin pulsar | | `assets/locale.js` |
| **Catálogo por destino**: taxonomía interna `lc_restriccion`, un término por destino de esta tienda donde el producto no se envía, según `Services::shipping_rules()->shippable()`. Se calcula al guardar el producto y, por lotes de 100 en Action Scheduler, al cambiar las reglas de envío (`lachinata/shipping/changed`) o los destinos. Listados, búsqueda, bloques y `wc_get_products()` filtran con `tax_query` (`pre_get_posts`); relacionados, rutina y «gracias», por sus ids | `pre_get_posts`, `woocommerce_related_products`, `lachinata/product/routine_ids`, `lachinata/thankyou/product_ids` | `Catalog.php` |
| **Ficha de un producto que no se envía**: no se oculta ni da 404. Antes del título, `Notice` warning con el texto de `shipping` («Lo sentimos, este producto no está disponible en tu país.», como lo ponía Country Based Restrictions; desde 0.12.2), y «Cambiar destino» en lugar de la disponibilidad, el formulario y la barra fija. Las restricciones (por clase y por producto) son las de `shipping` | `lachinata/product/can_buy`, `lachinata/product/before_title`, `lachinata/product/before_buy` | `Catalog.php`, `Front::unshippable_notice()`, `Front::unshippable_button()` |
| **Bolsa**: cada línea lo dice (`shipping`, `lachinata/cart/line_note`) y «Tramitar pedido» va desactivado con el motivo debajo mientras haya alguna. El checkout ya da el motivo de `shipping` y no deja pagar | `lachinata/cart/checkout_blocked` | `Catalog.php` |
| **Umbral de envío gratis** del destino en PromoBar, UspBar y bolsa: los dos primeros por `lachinata/shipping/destination`, la bolsa por el cliente de WooCommerce | | `Visitor.php` |
| **Tabla de cookies**: `lc_destino`, `lc_destino_visto` y `lc_destino_aviso`, como necesarias | `lachinata/tracking/services` | `Front::service()` |

## Caché de página

Dos modos, en el panel:

- **La caché varía por `lc_destino`, o no hay caché** (de serie). El servidor pinta cada página para el destino de la cookie: catálogo filtrado, umbral, ficha y contadores. Sin cookie, la variante «sin destino» no oculta nada y abre el selector. Hay que configurar la caché para que guarde una variante por valor de la cookie (WP Rocket, LiteSpeed Cache, Cloudflare con reglas de caché por cookie, Varnish con `hash` de la cookie). Con cinco o seis destinos útiles son pocas variantes.
- **La misma página para todos (caché sin destino)**, para cachés que no pueden variar por cookie (SiteGround con SG Optimizer: su caché dinámica se salta por cookie, pero no guarda variantes). El servidor pinta la página sin destino y:
  - el script del `<head>` pone `data-lc-destino` antes de pintar, y un estilo oculta las tarjetas con `data-lc-no` de ese destino. La rejilla se recoloca sin huecos (una página puede mostrar 11 tarjetas en vez de 12) y los listados no dicen el número de productos (`lachinata/catalog/show_count`);
  - la ficha lleva el aviso marcado con sus destinos (`data-lc-only`), que el mismo estilo muestra en lugar del formulario;
  - la pastilla y el nombre del destino del aviso se completan con un script en línea justo detrás, antes de pintar;
  - los textos de envío gratis de la PromoBar y la UspBar llevan sus plantillas (`data-lc-free`, de `shipping`). Si la página se pintó para otro destino, esperan ocultos en su sitio (`visibility: hidden`, sin mover nada) hasta que `locale.js` escribe la etiqueta del destino y su umbral, que llega por `GET /lachinata/v1/locale?destino=…`. Sin envío gratis, la UspBar lo dice sin cifra y el mensaje de la PromoBar se va;
  - la fecha estimada ya la pide la ficha con la cookie (`eta`).

Sea cual sea el modo, la bolsa, el checkout y `/wp-json/` no van en caché, y la cookie de sesión de WooCommerce saca al visitante de la caché en cuanto tiene bolsa. Medición y recomendación por hosting en `docs/guias/locale.md`.

## Depende de

Ningún módulo. Necesita WooCommerce 10. Con `shipping` (contrato `ShippingRules`, versión 2), el catálogo por destino, el bloqueo de la bolsa y los umbrales; sin él, solo el destino y el selector. Lo pintan el tema (capas, PromoBar, AppBar, ficha, bolsa y listado) y `tracking` (espera al selector).

## Hooks que escucha

- `lachinata/translate/options` (0.17.0): declara para `translate` el nombre y la nota de cada destino, que en otro idioma salen traducidos en el selector.
- `wp_head` (prioridad 0), `wp_enqueue_scripts`, `wp_footer`, `wp_loaded`, `template_redirect`, `init`, `rest_api_init`, `pre_get_posts` y `wp_login`.
- WooCommerce: `woocommerce_cart_loaded_from_session`, `woocommerce_add_to_cart`, `woocommerce_new_product`, `woocommerce_update_product`, `woocommerce_related_products` y `woocommerce_set_cookie_options`. WordPress: `allowed_redirect_hosts`.
- `lachinata_locale_index` (Action Scheduler).
- Del tema: `lachinata/promo_bar/start`, `lachinata/app_bar/utilities`, `lachinata/footer/legal`, `lachinata/product/can_buy`, `lachinata/product/before_title`, `lachinata/product/before_buy`, `lachinata/product_card/attributes`, `lachinata/catalog/show_count`, `lachinata/cart/checkout_blocked`, `lachinata/product/routine_ids` y `lachinata/thankyou/product_ids`.
- Del núcleo: `lachinata/shipping/destination`, `lachinata/shipping/changed` y `lachinata/core/admin_tabs`. De `shipping`: `lachinata/shipping/destination_label`. De `eta`: `lachinata/eta/rest_destination`. De `tracking`: `lachinata/tracking/services`. De `blocks`: `lachinata/blocks/product_ids`.
- Idioma (0.15.0): con más de un idioma (`translate`), el selector ofrece los de `Languages`, preseleccionado el de la página; en el navegador, el elegido la última vez (cookie `lc_idioma`, un año, `SameSite=Lax`) o, si no hay, el del navegador si la tienda lo tiene. La cookie solo preselecciona: no redirige y la caché no varía por ella. La pastilla enseña el código del idioma de la página.

## Hooks que emite

- `lachinata/locale/changed` (acción): han cambiado los destinos o las otras tiendas.
- En el navegador: `lachinata:layer:open` (lo escucha el tema) y `lachinata:locale:done` (lo escucha `tracking`); atributos `data-lc-destino`, `data-lc-locale-pending` y `data-lc-no` (`theme/HOOKS.md`, «Eventos del navegador»).

## Datos que guarda

- Opciones: `lachinata_locale_destinations`, `lachinata_locale_stores`, `lachinata_locale_cache_mode`, `lachinata_locale_geo_header`, `lachinata_locale_indexed` (último cálculo del catálogo) y `lachinata_locale_schema`.
- Meta de usuario `_lc_locale_destination`.
- Taxonomía interna `lc_restriccion` (términos `pt`, `es-ib`… en los productos). Se rehace entera al recalcular; «Borrar datos» no la toca (sin el módulo nadie la lee).
- En la sesión de WooCommerce, `lc_locale_applied` (destino ya aplicado al cliente).
- Cookies `lc_destino`, `lc_destino_visto` y `lc_destino_aviso`.

## REST y API para Odoo

- `GET /lachinata/v1/locale`: `sugerir=1` devuelve el destino de la ubicación (`id`, `hint`, `store`: nombre de la otra tienda o vacío); `destino=ES-IB` devuelve `threshold.value`, el umbral del destino como precio en la moneda de la tienda («200 €», «1 500 Kč») o `null`. Sin caché (`Cache-Control: private, no-store`).
- `POST /lachinata/v1/locale` (`destino`): guarda un destino de esta tienda; responde `reload` (verdadero si el servidor pinta por destino). Solo ids configurados y con Origin o Referer de este sitio.
- Nada para Odoo: el pedido ya lleva la dirección.

## Ajustes y exportación

- Entran en el JSON: los destinos y las otras tiendas (`data`, solo si se han guardado alguna vez; si no, cada sitio toma sus países de venta) y el modo de caché. Al importar se recalcula el catálogo.
- No entra la cabecera de país del CDN (es del hosting de cada sitio).
- WP-CLI: `wp lachinata locale list` y `wp lachinata locale reindex [--now]`.

## Qué pasa al apagarlo

Sin selector, pastilla ni enlace del pie; la barra de cookies sale enseguida. Las páginas en caché vuelven a la zona por defecto de La Chinata → Envíos y el catálogo no se filtra. La cookie se queda en los navegadores, sin efecto. Los destinos, las otras tiendas, el perfil de cada usuario y la taxonomía se conservan para cuando se encienda.

## Pruebas

- `tests/LocaleTest.php`: destinos de serie desde los países de venta; ISO ↔ WooCommerce (`ES-IB` → `PM`, `ES-CN` → `GC`/`TF`, `ES` como el resto de España); validación (más de 8 en la principal, id que no es ISO, tienda desconocida, dirección no válida); un solo destino sin selector; ruta de vuelta (otro host, `//`, `\`, parámetros propios); elegir un destino propio, de otra tienda (solo a su dirección configurada, con la misma ruta) y de «Otro país»; petición de otro sitio ignorada; destino de las páginas y de `eta` por modo de caché; perfil al iniciar sesión; catálogo por destino con un doble de `ShippingRules` (términos, `tax_query`, ids, ficha, tarjetas con `data-lc-no`, contadores); lotes; bolsa bloqueada; notas con `{envio_gratis}`, umbral por REST, etiqueta del destino en los textos de envío gratis, sugerencia y cabecera del CDN; cookies en la tabla.
- `tests/profiles/LocaleProfileTest.php`: los perfiles `es` (siete destinos y dos tiendas más), `canarias` (un destino: sin selector ni pastilla) y `cz` (tres destinos con sus umbrales en coronas; Alemania sin envío gratis).
- `tests/e2e/locale.spec.mjs`: primera visita con selector (y la barra de cookies después), preselección por la cabecera del CDN dicha en el selector, elección de otra tienda (redirección solo al dominio configurado), producto que no se envía en ficha, bolsa y listado, el umbral de cada destino con la moneda de la tienda en la PromoBar, la UspBar, el selector y la bolsa (en los dos modos de caché), y tiendas de un solo destino sin selector ni pastilla. Corre en todos los perfiles.

## Huecos conocidos

- **SiteGround sin medir**: no hay acceso todavía; «Caché sin destino» es el modo recomendado allí, pendiente de medir en el staging de la fase C.
- **Idioma**: la parte de idioma del selector y de la pastilla solo se pinta con más de un idioma (`translate`, incremento 11); hoy nunca.
- Una fila de destino con varias provincias calcula envíos y fechas con la primera.
- Con «Caché sin destino», la paginación cuenta los productos ocultos (páginas de 11 en vez de 12) y la búsqueda por REST de bloques no filtra.
- El aviso «Parece que estás en…» va en la zona de avisos del tema (`[data-lc-toasts]`); sin ella no sale.
