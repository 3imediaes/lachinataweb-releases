<?php
/**
 * `wp lachinata oleotecas`.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

use LaChinata\Core\Cli\Output;

defined( 'ABSPATH' ) || exit;

/**
 * Migration from the old fields and the JSON of the finder.
 */
final class Cli {

	/**
	 * Converts the old fields (ACF) of the published stores to the module's fields. The old
	 * fields are kept. A store already migrated is skipped unless --force.
	 *
	 * ## OPTIONS
	 *
	 * [--map=<file>]
	 * : JSON with the shop's countries, zones and corrections by store (docs/despliegue-oleotecas.md).
	 *
	 * [--dry-run]
	 * : Only the report; nothing is written.
	 *
	 * [--force]
	 * : Migrate again the stores already migrated (overwrites their new fields); also writes
	 * over the report if it already exists.
	 *
	 * [--report=<file>]
	 * : Also writes the report as JSON to this file.
	 *
	 * [--level=<level>]
	 * : Lowest level shown: info, warning or error.
	 * ---
	 * default: warning
	 * ---
	 *
	 * @param array<int, string>    $args       Positional arguments.
	 * @param array<string, string> $assoc_args Options.
	 */
	public function migrate( array $args, array $assoc_args ): void {
		unset( $args );
		Output::check( (string) ( $assoc_args['report'] ?? '' ), $assoc_args );
		$map = array();
		if ( ! empty( $assoc_args['map'] ) ) {
			$raw = file_exists( $assoc_args['map'] ) ? (string) file_get_contents( $assoc_args['map'] ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local file of the command.
			$map = json_decode( $raw, true );
			if ( ! is_array( $map ) ) {
				\WP_CLI::error( __( 'El mapa no es un JSON válido.', 'lachinata-core' ) );
			}
		}
		$write  = empty( $assoc_args['dry-run'] );
		$report = Migration::run( $map, $write, ! empty( $assoc_args['force'] ) );
		$levels = array(
			'info'    => 0,
			'warning' => 1,
			'error'   => 2,
		);
		$min    = $levels[ $assoc_args['level'] ?? 'warning' ] ?? 1;
		$rows   = array();
		$errors = 0;
		foreach ( $report as $store ) {
			foreach ( $store['issues'] as $issue ) {
				$errors += 'error' === $issue['level'] ? 1 : 0;
				if ( ( $levels[ $issue['level'] ] ?? 0 ) >= $min ) {
					$rows[] = array(
						'slug'    => $store['slug'],
						'nivel'   => $issue['level'],
						'campo'   => $issue['field'],
						'detalle' => $issue['message'],
					);
				}
			}
		}
		if ( $rows ) {
			\WP_CLI\Utils\format_items( 'table', $rows, array( 'slug', 'nivel', 'campo', 'detalle' ) );
		}
		if ( ! empty( $assoc_args['report'] ) ) {
			Output::write( (string) $assoc_args['report'], (string) wp_json_encode( $report, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ), $assoc_args );
		}
		$counts = array_count_values( array_column( $report, 'state' ) );
		\WP_CLI::success(
			sprintf(
				/* translators: 1: migrated, 2: dry run, 3: skipped, 4: errors. */
				__( 'Migradas: %1$d · simuladas: %2$d · ya migradas (sin tocar): %3$d · errores: %4$d', 'lachinata-core' ),
				$counts['migrated'] ?? 0,
				$counts['dry-run'] ?? 0,
				$counts['skipped'] ?? 0,
				$errors
			)
		);
		if ( $write ) {
			Data::flush();
		}
	}

	/**
	 * Writes the JSON of the finder again and prints its URL.
	 *
	 * @param array<int, string>    $args       Positional arguments.
	 * @param array<string, string> $assoc_args Options.
	 */
	public function json( array $args, array $assoc_args ): void {
		unset( $args, $assoc_args );
		$state = Data::write();
		if ( null === $state ) {
			\WP_CLI::error( __( 'No se pudo escribir el JSON en uploads.', 'lachinata-core' ) );
		}
		/* translators: 1: «39 oleotecas», 2: URL. */
		\WP_CLI::success( sprintf( __( '%1$s en %2$s', 'lachinata-core' ), Texts::count( $state['count'] ), $state['url'] ) );
	}
}
