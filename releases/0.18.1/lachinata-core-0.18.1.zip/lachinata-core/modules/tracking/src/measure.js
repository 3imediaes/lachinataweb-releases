/**
 * Module `tracking`: the measurement of the shop.
 *
 * One bus, `window.lachinata.track(event, data)`, with GA4 event names and parameters, is
 * the only source; the adapters translate it to each service (GA4, Google Ads, Meta
 * pixel). An adapter works only with its consent and loads its tag after the page `load`,
 * asynchronously. Events of the page wait for the choice: if the visitor accepts, they go;
 * if not, never.
 *
 * Where the events come from: the page data the server prints (`#lc-measure`: view_item,
 * view_cart, search, purchase), the DOM (cards with `data-lc-item`, promotions with
 * `data-lc-promo`) and the events of the theme (`lachinata:cart:add`, `:remove`,
 * `:quantity`, `:view`, `lachinata:content:added`; theme/HOOKS.md).
 *
 * The checkout loads no third-party tag: its steps (begin_checkout, add_shipping_info,
 * add_payment_info and the `lc_*` of the funnel) go to `POST /lachinata/v1/event` and the
 * server sends them to GA4 and Meta, only with consent.
 */

const node = document.getElementById('lc-measure');
const config = node ? JSON.parse(node.textContent) : null;

/**
 * The visitor's choice (filled by the head script and consent.js).
 *
 * @return {{given: boolean, analytics: boolean, marketing: boolean}} Choice.
 */
const consent = () =>
	window.lcConsent || { given: false, analytics: false, marketing: false };

/**
 * Parses a JSON data attribute.
 *
 * @param {Element|null} element Element.
 * @param {string}       name    Dataset key.
 * @return {Object|null} Data.
 */
const read = (element, name) => {
	try {
		return element?.dataset[name]
			? JSON.parse(element.dataset[name])
			: null;
	} catch {
		return null;
	}
};

const withQuantity = (item, quantity) => ({ ...item, quantity });

const value = (items) =>
	Math.round(
		items.reduce((sum, item) => sum + item.price * item.quantity, 0) * 100
	) / 100;

const stripIds = (items) =>
	(items || []).map((item) => {
		const copy = { ...item };
		delete copy.ids;
		return copy;
	});

/**
 * Adds a script once.
 *
 * @param {string} src Source.
 */
const loadScript = (src) => {
	const script = document.createElement('script');
	script.async = true;
	script.src = src;
	document.head.append(script);
};

/**
 * Sends an event to the server (the checkout), with the cookies of the visitor.
 *
 * @param {string} event   Event.
 * @param {Object} params  Parameters.
 * @param {string} eventId Id shared with the pixel.
 */
const relay = (event, params = {}, eventId = '') =>
	window
		.fetch(config.rest, {
			method: 'POST',
			keepalive: true,
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({ event, params, event_id: eventId }),
		})
		.catch(() => {});

const gtag = (...args) => {
	window.dataLayer = window.dataLayer || [];
	(window.gtag || ((...a) => window.dataLayer.push(a)))(...args);
};

let gtagLoaded = false;
const loadGtag = (id) => {
	if (!gtagLoaded) {
		gtagLoaded = true;
		loadScript(
			`https://www.googletagmanager.com/gtag/js?id=${encodeURIComponent(id)}`
		);
		gtag('js', new Date());
	}
};

/**
 * Adapters: who may receive an event, how its tag loads and how an event translates.
 */
const adapters = {
	ga4: {
		on: () =>
			!!config.ga4 &&
			(consent().analytics || (config.cookieless && consent().given)),
		load() {
			loadGtag(config.ga4);
			gtag('config', config.ga4);
		},
		send(name, data) {
			// With the API secret, the purchase of GA4 comes from the server only.
			if (name === 'purchase' && config.ga4Server) {
				return;
			}
			if (name.startsWith('lc_checkout_click')) {
				return;
			}
			const params = { ...data };
			delete params.event_id;
			delete params.user_data;
			gtag('event', name, {
				...params,
				items: data.items ? stripIds(data.items) : undefined,
				send_to: config.ga4,
			});
		},
	},
	ads: {
		on: () =>
			!!config.ads &&
			(consent().marketing || (config.cookieless && consent().given)),
		load() {
			loadGtag(config.ads.id);
			gtag('config', config.ads.id, {
				allow_enhanced_conversions: !!config.ads.enhanced,
			});
		},
		send(name, data) {
			const labels = config.ads.labels || {};
			const conversion = {
				purchase: labels.purchase,
				add_to_cart: labels.add_to_cart,
				lc_checkout_click: labels.checkout,
				generate_lead: labels.lead,
			}[name];
			if (conversion) {
				if (
					name === 'purchase' &&
					config.ads.enhanced &&
					data.user_data &&
					consent().marketing
				) {
					gtag('set', 'user_data', data.user_data);
				}
				gtag('event', 'conversion', {
					send_to: `${config.ads.id}/${conversion}`,
					value: data.value,
					currency: data.currency,
					transaction_id: data.transaction_id,
				});
			}
			if (
				config.ads.remarketing &&
				[
					'view_item',
					'view_item_list',
					'add_to_cart',
					'purchase',
				].includes(name)
			) {
				gtag('event', name, {
					send_to: config.ads.id,
					value: data.value,
					items: (data.items || []).map((item) => ({
						id: item.ids?.google || item.item_id,
						google_business_vertical: 'retail',
					})),
				});
			}
		},
	},
	meta: {
		on: () => !!config.meta && consent().marketing,
		load() {
			/* eslint-disable */
			!(function (f, b, e, v, n, t, s) {
				if (f.fbq) return;
				n = f.fbq = function () {
					n.callMethod
						? n.callMethod.apply(n, arguments)
						: n.queue.push(arguments);
				};
				if (!f._fbq) f._fbq = n;
				n.push = n;
				n.loaded = !0;
				n.version = '2.0';
				n.queue = [];
				t = b.createElement(e);
				t.async = !0;
				t.src = v;
				s = b.getElementsByTagName(e)[0];
				s.parentNode.insertBefore(t, s);
			})(
				window,
				document,
				'script',
				'https://connect.facebook.net/en_US/fbevents.js'
			);
			/* eslint-enable */
			window.fbq('init', config.meta);
			window.fbq('track', 'PageView');
		},
		send(name, data) {
			const ids = (data.items || []).map(
				(item) => item.ids?.meta || item.item_id
			);
			const product = {
				content_ids: ids,
				content_type: 'product',
				contents: (data.items || []).map((item) => ({
					id: item.ids?.meta || item.item_id,
					quantity: item.quantity,
				})),
				value: data.value,
				currency: data.currency,
			};
			const events = {
				view_item: ['ViewContent', product],
				add_to_cart: ['AddToCart', product],
				purchase: ['Purchase', product],
				search: ['Search', { search_string: data.search_term }],
				generate_lead: ['Lead', {}],
				sign_up: [
					data.method === 'newsletter'
						? 'Subscribe'
						: 'CompleteRegistration',
					{},
				],
			};
			if (!events[name]) {
				return;
			}
			window.fbq(
				'track',
				events[name][0],
				events[name][1],
				data.event_id ? { eventID: data.event_id } : {}
			);
		},
	},
};

if (config) {
	const page = [];
	const ready = {};
	let loaded = false;

	/**
	 * Gives an event to every adapter that may take it.
	 *
	 * @param {{name: string, data: Object, sent: Object}} entry Event.
	 */
	const dispatch = (entry) => {
		if (!loaded) {
			return;
		}
		Object.entries(adapters).forEach(([key, adapter]) => {
			if (entry.sent[key] || !adapter.on()) {
				return;
			}
			if (!ready[key]) {
				ready[key] = true;
				adapter.load();
			}
			entry.sent[key] = true;
			try {
				adapter.send(entry.name, entry.data);
			} catch {
				// A service that fails never breaks the page.
			}
		});
	};

	/**
	 * The bus: one event in GA4 names (`add_to_cart`, `view_item`…).
	 *
	 * @param {string} name Event.
	 * @param {Object} data Parameters.
	 */
	const track = (name, data = {}) => {
		const entry = {
			name,
			data: {
				currency: config.currency,
				site_language: config.language,
				...data,
			},
			sent: {},
		};
		if (config.checkout) {
			return;
		}
		page.push(entry);
		dispatch(entry);
	};

	window.lachinata = window.lachinata || {};
	window.lachinata.track = track;

	// Meta keeps one AddToCart: the pixel and the server share its id.
	const addToCart = (items, data = {}) => {
		const eventId = `add-${Date.now()}-${Math.random().toString(16).slice(2, 10)}`;
		track('add_to_cart', {
			value: value(items),
			items,
			event_id: eventId,
			...data,
		});
		if (config.metaServer && consent().marketing && items[0]) {
			relay(
				'add_to_cart',
				{
					product_id: items[0].ids?.product,
					quantity: items[0].quantity,
				},
				eventId
			);
		}
	};

	const lists = (elements) => {
		const groups = {};
		elements.forEach((element) => {
			const item = read(element, 'lcItem');
			if (item) {
				const key = item.item_list_id || '';
				(groups[key] ||= []).push(item);
			}
		});
		Object.values(groups).forEach((items) =>
			track('view_item_list', {
				item_list_id: items[0].item_list_id,
				item_list_name: items[0].item_list_name,
				items,
			})
		);
	};

	const start = () => {
		// Server-side events of the previous request (sign-up, login, newsletter…).
		const next = document.cookie.match(/(?:^|; )lc_track_next=([^;]*)/);
		if (next) {
			document.cookie = 'lc_track_next=; Max-Age=0; path=/';
			try {
				JSON.parse(decodeURIComponent(next[1])).forEach((event) =>
					track(event.n, event.p || {})
				);
			} catch {}
		}
		(config.page || []).forEach((event) => track(event.name, event.data));
		lists([...document.querySelectorAll('.lc-card[data-lc-item]')]);
		const promos = [...document.querySelectorAll('[data-lc-promo]')];
		if (promos.length) {
			track('view_promotion', {
				items: promos.map((promo) => read(promo, 'lcPromo')),
			});
		}
		loaded = true;
		page.forEach(dispatch);
	};

	document.addEventListener('lachinata:consent', () =>
		page.forEach(dispatch)
	);

	document.addEventListener('click', (event) => {
		const card = event.target.closest('.lc-card[data-lc-item]');
		if (
			card &&
			event.target.closest('a') &&
			!event.target.closest('[data-lc-add]')
		) {
			const item = read(card, 'lcItem');
			track('select_item', {
				item_list_id: item.item_list_id,
				item_list_name: item.item_list_name,
				items: [item],
			});
		}
		const entry = event.target.closest('.lc-acard[data-lc-entry]');
		if (entry && event.target.closest('a')) {
			// An entry of the blog in a list (module content): the article is the item.
			track('select_item', {
				item_list_name: entry.dataset.lcList || '',
				items: [
					{
						item_id: `post-${entry.dataset.lcEntry}`,
						item_name:
							entry
								.querySelector('.lc-acard__title')
								?.textContent.trim() || '',
						item_list_name: entry.dataset.lcList || '',
						index: Number(entry.dataset.lcIndex || 0),
					},
				],
			});
		}
		const promo = event.target.closest('[data-lc-promo]');
		if (promo && event.target.closest('a')) {
			const data = read(promo, 'lcPromo');
			track('select_promotion', { ...data, items: [data] });
		}
		if (event.target.closest('[data-lc-checkout]')) {
			track('lc_checkout_click', {});
		}
		// «¿Es para tu empresa?» (BulkCta): only to GA4, like the other own events.
		const bulk = event.target.closest('[data-lc-bulk]');
		if (bulk) {
			const data = read(bulk, 'lcBulk') || {};
			track('lc_bulk_quote', {
				product_id: data.id,
				item_id: data.sku,
				channel: data.channel,
			});
		}
	});

	// The blog (module content): own events, only to GA4 (the adapters of Ads and Meta only
	// take the standard ones).
	[
		['recipe:view', 'lc_recipe_view'],
		['recipe:print', 'lc_recipe_print'],
		['recipe:cook_mode', 'lc_recipe_cook_mode'],
		['recipe:scale', 'lc_recipe_scale'],
		['recipe:ingredient_product', 'lc_ingredient_product'],
		['article:read', 'lc_article_read'],
	].forEach(([event, name]) =>
		document.addEventListener(`lachinata:${event}`, ({ detail }) =>
			track(name, {
				content_id: detail?.id,
				content_title: detail?.title,
				servings: detail?.servings,
				product_id: detail?.product,
			})
		)
	);

	// Bodega (module bodega): «1 botella» or «Caja de 6» on a wine page.
	document.addEventListener('lachinata:wine:case_select', ({ detail }) =>
		track('lc_case_select', {
			case_type: detail?.value,
			product_id: detail?.id,
		})
	);

	document.addEventListener('lachinata:cart:add', ({ detail }) => {
		const item =
			read(detail.element?.closest?.('[data-lc-item]'), 'lcItem') ||
			(config.products || {})[detail.id];
		if (item) {
			addToCart([withQuantity(item, detail.quantity || 1)], {
				source: detail.source,
			});
		}
	});

	document.addEventListener('lachinata:cart:remove', ({ detail }) => {
		const item = read(detail.element, 'lcItem');
		if (item) {
			track('remove_from_cart', { value: value([item]), items: [item] });
		}
	});

	document.addEventListener('lachinata:cart:quantity', ({ detail }) => {
		const item = read(detail.element, 'lcItem');
		const delta = item ? detail.quantity - item.quantity : 0;
		if (delta > 0) {
			addToCart([withQuantity(item, delta)], { source: 'bag' });
		} else if (delta < 0) {
			const removed = [withQuantity(item, -delta)];
			track('remove_from_cart', {
				value: value(removed),
				items: removed,
			});
		}
	});

	document.addEventListener('lachinata:cart:view', ({ detail }) => {
		const items = [
			...(detail.element || document).querySelectorAll(
				'.lc-line[data-lc-item]'
			),
		]
			.map((line) => read(line, 'lcItem'))
			.filter(Boolean);
		track('view_cart', { value: value(items), items });
	});

	document.addEventListener('lachinata:content:added', ({ detail }) =>
		lists(
			(detail.elements || []).flatMap((element) =>
				element.matches('.lc-card[data-lc-item]')
					? [element]
					: [...element.querySelectorAll('.lc-card[data-lc-item]')]
			)
		)
	);

	if (config.checkout) {
		// Checkout: no tag, the server sends what the visitor consented to.
		const allowed = () => consent().analytics || consent().marketing;
		const once = {};
		const send = (event, params = {}) => {
			const key = `${event}:${JSON.stringify(params)}`;
			if (allowed() && !once[key]) {
				once[key] = true;
				relay(event, params);
			}
		};
		// The steps of WooCommerce's hooks are listened to at once (a buyer may choose before
		// the page is idle); the rest waits for it.
		watchSteps(send);
		const watch = () => {
			send('begin_checkout');
			document.addEventListener('lachinata:consent', () =>
				send('begin_checkout')
			);
			watchStores(send);
		};
		// After the page has loaded and when the browser is idle: the checkout comes first.
		const later = () =>
			(window.requestIdleCallback || window.setTimeout)(watch, {
				timeout: 2000,
			});
		if (document.readyState === 'complete') {
			later();
		} else {
			window.addEventListener('load', later);
		}
	} else if (document.readyState === 'complete') {
		window.setTimeout(start, 0);
	} else {
		// Tags load after the page: they never compete with its first paint.
		window.addEventListener('load', () => window.setTimeout(start, 0));
	}
}

/**
 * The steps of the block checkout (WooCommerce's `wp.hooks` actions).
 *
 * @param {(event: string, params?: Object) => void} send Sends an event to the server once.
 */
function watchSteps(send) {
	let paymentSent = false;
	const hooks = window.wp?.hooks;
	hooks?.addAction(
		'experimental__woocommerce_blocks-checkout-set-selected-shipping-rate',
		'lachinata/tracking',
		({ shippingRateId }) =>
			send('add_shipping_info', { shipping_tier: shippingRateId })
	);
	hooks?.addAction(
		'experimental__woocommerce_blocks-checkout-set-active-payment-method',
		'lachinata/tracking',
		({ paymentMethodSlug }) => {
			paymentSent = true;
			send('add_payment_info', { payment_type: paymentMethodSlug });
			if (/express|apple|google|wallet/i.test(paymentMethodSlug)) {
				send('lc_express_pay', { wallet: paymentMethodSlug });
			}
		}
	);
	hooks?.addAction(
		'experimental__woocommerce_blocks-checkout-submit',
		'lachinata/tracking',
		() => {
			// With a single payment method nobody chooses it: it is added when sending.
			const method = window.wp?.data
				?.select('wc/store/payment')
				?.getActivePaymentMethod?.();
			if (method && !paymentSent) {
				send('add_payment_info', { payment_type: method });
			}
		}
	);
	hooks?.addAction(
		'experimental__woocommerce_blocks-checkout-submit',
		'lachinata/tracking/errors',
		() =>
			window.setTimeout(() => {
				const errors =
					window.wp?.data
						?.select('wc/store/validation')
						?.getValidationErrors?.() || {};
				Object.entries(errors).forEach(([field, error]) =>
					send('lc_checkout_error', {
						field: field.slice(0, 60),
						error_type: error?.hidden ? 'hidden' : 'invalid',
					})
				);
			}, 300)
	);
}

/**
 * The `lc_*` events read from the stores of the block checkout (gift, no shipping).
 *
 * @param {(event: string, params?: Object) => void} send Sends an event to the server once.
 */
function watchStores(send) {
	const data = window.wp?.data;
	if (data) {
		let gift = '';
		let cause = '';
		data.subscribe(() => {
			const extension = data
				.select('wc/store/checkout')
				?.getExtensionData?.()?.['lachinata-gift'];
			const now = extension?.open ? extension.via || 'none' : '';
			if (now && now !== gift) {
				send('lc_gift', { channel: now });
			}
			gift = now;
		}, 'wc/store/checkout');
		data.subscribe(() => {
			const cart = data.select('wc/store/cart')?.getCartData?.();
			const reason = cart?.extensions?.['lachinata-shipping']?.cause;
			if (reason && reason !== cause) {
				send('lc_shipping_unavailable', {
					reason,
					country: cart.shippingAddress?.country || '',
				});
			}
			cause = reason || '';
		}, 'wc/store/cart');
	}
}
