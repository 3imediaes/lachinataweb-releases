<?php
/**
 * Own attributes of the products in other languages.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * The attributes a product defines itself (not those of a taxonomy, which are terms) are
 * translated as one field, `attributes` ({key: {name, values}}). In another language their
 * name and the text of each value change where WooCommerce shows them; the values that
 * choose a variation stay in Spanish, so the bag and the orders keep matching.
 */
final class Attributes {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'woocommerce_attribute_label', array( self::class, 'label' ), 20, 3 );
		Hooks::add_filter( 'woocommerce_variation_option_name', array( self::class, 'value' ), 20, 4 );
		Hooks::add_filter( 'woocommerce_attribute', array( self::class, 'values' ), 20, 3 );
	}

	/**
	 * Name of an own attribute.
	 *
	 * @param mixed $label   Label.
	 * @param mixed $name    Attribute name.
	 * @param mixed $product Product, if any.
	 * @return mixed
	 */
	public static function label( $label, $name = '', $product = null ) {
		$pair = self::pair( $product );
		if ( null === $pair || ! is_string( $label ) ) {
			return $label;
		}
		foreach ( $pair[0] as $key => $attribute ) {
			if ( $attribute['name'] === $label && '' !== ( $pair[1][ $key ]['name'] ?? '' ) ) {
				return $pair[1][ $key ]['name'];
			}
		}
		return $label;
	}

	/**
	 * Text of a value (the chips of the formats).
	 *
	 * @param mixed $value     Value.
	 * @param mixed $term      Term (null for own attributes).
	 * @param mixed $attribute Attribute name.
	 * @param mixed $product   Product.
	 * @return mixed
	 */
	public static function value( $value, $term = null, $attribute = '', $product = null ) {
		unset( $term, $attribute );
		return is_string( $value ) ? self::translate_value( $value, $product ) : $value;
	}

	/**
	 * Values in «Información adicional».
	 *
	 * @param mixed $html      HTML.
	 * @param mixed $attribute Attribute.
	 * @param mixed $values    Values.
	 * @return mixed
	 */
	public static function values( $html, $attribute = null, $values = array() ) {
		global $product;
		if ( ! $attribute instanceof \WC_Product_Attribute || $attribute->is_taxonomy() || ! is_array( $values ) ) {
			return $html;
		}
		$translated = array_map( fn( $value ) => is_string( $value ) ? esc_html( self::translate_value( $value, $product ) ) : $value, $values );
		return wpautop( wptexturize( implode( ', ', $translated ) ) );
	}

	/**
	 * A value in the language of the request.
	 *
	 * @param string $value   Value.
	 * @param mixed  $product Product.
	 */
	private static function translate_value( string $value, $product ): string {
		$pair = self::pair( $product );
		if ( null === $pair ) {
			return $value;
		}
		foreach ( $pair[0] as $key => $attribute ) {
			$index = array_search( $value, $attribute['values'], true );
			if ( false !== $index && '' !== ( $pair[1][ $key ]['values'][ $index ] ?? '' ) ) {
				return (string) $pair[1][ $key ]['values'][ $index ];
			}
		}
		return $value;
	}

	/**
	 * Spanish and translated own attributes of a product in the language of the request.
	 *
	 * @param mixed $product Product (a variation counts as its product).
	 * @return array{0: array<string, array{name: string, values: string[]}>, 1: array<string, array<string, mixed>>}|null
	 */
	private static function pair( $product ): ?array {
		if ( ! $product instanceof \WC_Product ) {
			return null;
		}
		$language = Service::instance()->current();
		if ( Config::default_language() === $language || ! isset( Config::languages()[ $language ] ) ) {
			return null;
		}
		$id   = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();
		$text = Store::text( 'post', $id, 'attributes', $language );
		$data = null === $text ? null : json_decode( $text, true );
		if ( ! is_array( $data ) ) {
			return null;
		}
		return array( Fields::attributes( $id ), $data );
	}
}
