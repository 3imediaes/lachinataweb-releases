<?php
/**
 * Client of the Claude API.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

defined( 'ABSPATH' ) || exit;

/**
 * The Messages API for the changes of the day and the Message Batches API (half price) for
 * the batches, through the HTTP API of WordPress: the plugin carries no libraries of
 * Composer. Retries what can be retried (429, 5xx, 529 overloaded, network) waiting what the
 * API asks (`retry-after`) or longer each time. Errors carry the status and the type of the
 * API, never the key nor the request.
 */
final class Claude {

	/**
	 * Base address of the API.
	 */
	public const BASE = 'https://api.anthropic.com/v1';

	/**
	 * Version of the API.
	 */
	public const VERSION = '2026-10-21';

	/**
	 * Beta of the server-side fallback when a model declines (Messages API only).
	 */
	public const FALLBACK_BETA = 'server-side-fallback-2026-07-01';

	/**
	 * Attempts of a request.
	 */
	private const ATTEMPTS = 3;

	/**
	 * Sends a message and returns the answer.
	 *
	 * @param array<string, mixed> $body Body of the request.
	 * @return array<string, mixed>
	 * @throws ClaudeError When the API fails.
	 */
	public static function message( array $body ): array {
		$body['fallbacks'] = 'default';
		return self::request( 'POST', self::BASE . '/messages', $body, array( self::FALLBACK_BETA ) );
	}

	/**
	 * Creates a batch: custom id → body of a message.
	 *
	 * @param array<string, array<string, mixed>> $requests Requests.
	 * @return array<string, mixed> The batch (id, processing_status…).
	 * @throws ClaudeError When the API fails.
	 */
	public static function create_batch( array $requests ): array {
		$list = array();
		foreach ( $requests as $custom_id => $params ) {
			$list[] = array(
				'custom_id' => (string) $custom_id,
				'params'    => $params,
			);
		}
		return self::request( 'POST', self::BASE . '/messages/batches', array( 'requests' => $list ) );
	}

	/**
	 * State of a batch.
	 *
	 * @param string $batch Batch id.
	 * @return array<string, mixed>
	 * @throws ClaudeError When the API fails.
	 */
	public static function batch( string $batch ): array {
		return self::request( 'GET', self::BASE . '/messages/batches/' . rawurlencode( $batch ) );
	}

	/**
	 * Results of an ended batch, by custom id: {type, message}.
	 *
	 * @param string $url Address of the results (`results_url`).
	 * @return array<string, array{type: string, message: array<string, mixed>}>
	 * @throws ClaudeError When the API fails.
	 */
	public static function results( string $url ): array {
		$raw   = self::send( 'GET', $url, null );
		$out   = array();
		$lines = preg_split( '/\r?\n/', $raw );
		foreach ( false === $lines ? array() : $lines as $line ) {
			$row = json_decode( $line, true );
			if ( ! is_array( $row ) || ! isset( $row['custom_id'] ) ) {
				continue;
			}
			$result                            = is_array( $row['result'] ?? null ) ? $row['result'] : array();
			$out[ (string) $row['custom_id'] ] = array(
				'type'    => (string) ( $result['type'] ?? 'errored' ),
				'message' => is_array( $result['message'] ?? null ) ? $result['message'] : array(),
			);
		}
		return $out;
	}

	/**
	 * Text of an answer (its text blocks).
	 *
	 * @param array<string, mixed> $message Answer.
	 */
	public static function text( array $message ): string {
		$text = '';
		foreach ( is_array( $message['content'] ?? null ) ? $message['content'] : array() as $block ) {
			if ( is_array( $block ) && 'text' === ( $block['type'] ?? '' ) ) {
				$text .= (string) ( $block['text'] ?? '' );
			}
		}
		return $text;
	}

	/**
	 * A request with JSON in and out.
	 *
	 * @param string                    $method Method.
	 * @param string                    $url    Address.
	 * @param array<string, mixed>|null $body   Body.
	 * @param string[]                  $betas  Betas.
	 * @return array<string, mixed>
	 * @throws ClaudeError When the API fails.
	 */
	private static function request( string $method, string $url, ?array $body = null, array $betas = array() ): array {
		$data = json_decode( self::send( $method, $url, $body, $betas ), true );
		if ( ! is_array( $data ) ) {
			throw new ClaudeError( esc_html__( 'La API de Claude ha respondido algo que no es JSON.', 'lachinata-core' ), 0, 'invalid_response' );
		}
		return $data;
	}

	/**
	 * Sends a request, retrying what can be retried.
	 *
	 * @param string                    $method Method.
	 * @param string                    $url    Address.
	 * @param array<string, mixed>|null $body   Body.
	 * @param string[]                  $betas  Betas.
	 * @return string Body of the answer.
	 * @throws ClaudeError When the API fails.
	 */
	private static function send( string $method, string $url, ?array $body, array $betas = array() ): string {
		$key = Secret::key();
		if ( null === $key ) {
			throw new ClaudeError( esc_html__( 'Falta la clave de la API de Claude, o no se puede leer: vuelve a pegarla.', 'lachinata-core' ), 401, 'authentication_error' );
		}
		$headers = array(
			'x-api-key'         => $key,
			'anthropic-version' => self::VERSION,
			'content-type'      => 'application/json',
		);
		if ( $betas ) {
			$headers['anthropic-beta'] = implode( ',', $betas );
		}
		$error = null;
		$wait  = null;
		for ( $attempt = 1; $attempt <= self::ATTEMPTS; $attempt++ ) {
			$response = wp_remote_request(
				$url,
				array(
					'method'  => $method,
					'headers' => $headers,
					'body'    => null === $body ? null : wp_json_encode( $body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
					'timeout' => 120,
				)
			);
			if ( is_wp_error( $response ) ) {
				$error = new ClaudeError( esc_html__( 'No se ha podido conectar con la API de Claude.', 'lachinata-core' ), 0, 'connection_error' );
			} else {
				$status = (int) wp_remote_retrieve_response_code( $response );
				$raw    = (string) wp_remote_retrieve_body( $response );
				if ( $status >= 200 && $status < 300 ) {
					return $raw;
				}
				$error = ClaudeError::from( $status, $raw );
				if ( ! $error->retryable() ) {
					throw $error;
				}
				$wait = (int) wp_remote_retrieve_header( $response, 'retry-after' );
			}
			if ( $attempt < self::ATTEMPTS ) {
				self::pause( max( $wait ?? 0, 2 ** $attempt ) );
			}
			$wait = null;
		}
		throw $error;
	}

	/**
	 * Waits before retrying (at most a minute; the tests make it instant).
	 *
	 * @param int $seconds Seconds.
	 */
	private static function pause( int $seconds ): void {
		/**
		 * Seconds to wait before retrying a request to the Claude API.
		 *
		 * @since 0.17.0
		 *
		 * @param int $seconds What the API asked, or longer each attempt.
		 */
		$seconds = (int) apply_filters( 'lachinata/translate/retry_wait', min( 60, $seconds ) );
		if ( $seconds > 0 ) {
			sleep( $seconds );
		}
	}
}
