<?php
/**
 * Error of the Claude API.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

defined( 'ABSPATH' ) || exit;

/**
 * An error with the status and the type the API gave (`rate_limit_error`,
 * `overloaded_error`…), and its message without anything of the request.
 */
final class ClaudeError extends \RuntimeException {

	/**
	 * Type of the API error.
	 *
	 * @var string
	 */
	private string $type;

	/**
	 * New error.
	 *
	 * @param string $message Message for people.
	 * @param int    $status  HTTP status (0 without answer).
	 * @param string $type    Type of the API error.
	 */
	public function __construct( string $message, int $status, string $type ) {
		parent::__construct( $message, $status );
		$this->type = $type;
	}

	/**
	 * From an answer of the API.
	 *
	 * @param int    $status HTTP status.
	 * @param string $raw    Body.
	 */
	public static function from( int $status, string $raw ): self {
		$data    = json_decode( $raw, true );
		$error   = is_array( $data ) && is_array( $data['error'] ?? null ) ? $data['error'] : array();
		$type    = sanitize_key( (string) ( $error['type'] ?? 'api_error' ) );
		$message = wp_strip_all_tags( (string) ( $error['message'] ?? '' ) );
		return new self(
			/* translators: 1: HTTP status, 2: error type, 3: message of the API. */
			sprintf( __( 'La API de Claude ha respondido %1$d (%2$s): %3$s', 'lachinata-core' ), $status, $type, mb_substr( $message, 0, 300 ) ),
			$status,
			$type
		);
	}

	/**
	 * Type of the API error.
	 */
	public function type(): string {
		return $this->type;
	}

	/**
	 * Whether trying again may work: rate limit, overload, server errors and the network.
	 */
	public function retryable(): bool {
		$status = $this->getCode();
		return 0 === $status || 408 === $status || 409 === $status || 429 === $status || $status >= 500;
	}

	/**
	 * Whether it stops the whole queue: no key, a key not valid or without credit.
	 */
	public function fatal(): bool {
		return in_array( $this->getCode(), array( 401, 402, 403 ), true );
	}
}
