<?php
/**
 * WP-CLI: wp lachinata translate.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

use LaChinata\Core\Cli\Output;

defined( 'ABSPATH' ) || exit;

/**
 * Translations by hand and their state: write a field, import a file of translations (the
 * test ones of 11b), export them, see how many there are and recalculate where each page
 * exists; since 0.17.0, the batches with Claude (`run`, `retry`, `tick`, `daily`), the glossary
 * (`glossary-suggest`, `glossary-import`, `glossary-export`) and, since 0.17.1, the move from
 * TranslatePress (`migrate-tp`).
 */
final class Cli {

	/**
	 * Format of the file of translations.
	 */
	public const FORMAT = 'lachinata-traducciones';

	/**
	 * Writes the translation of a field.
	 *
	 * ## OPTIONS
	 *
	 * <type>
	 * : post or term.
	 *
	 * <id>
	 * : Post or term id.
	 *
	 * <field>
	 * : Field (name, description, slug…).
	 *
	 * <language>
	 * : Locale (en_GB).
	 *
	 * <text>
	 * : Translated text.
	 *
	 * [--status=<status>]
	 * : auto, edited or outdated.
	 * ---
	 * default: edited
	 * ---
	 *
	 * [--origin=<origin>]
	 * : claude, person or import.
	 * ---
	 * default: person
	 * ---
	 *
	 * @param string[]              $args       Arguments.
	 * @param array<string, string> $assoc_args Options.
	 */
	public function set( array $args, array $assoc_args ): void {
		list( $type, $id, $field, $language, $text ) = $args;
		$error                                       = self::write( $type, (int) $id, $field, $language, $text, (string) ( $assoc_args['status'] ?? Store::EDITED ), (string) ( $assoc_args['origin'] ?? 'person' ) );
		if ( '' !== $error ) {
			\WP_CLI::error( $error );
		}
		Availability::refresh( $type, (int) $id );
		\WP_CLI::success( Availability::is( $type, (int) $id, $language ) ? __( 'Guardada. La página existe en ese idioma.', 'lachinata-core' ) : __( 'Guardada. La página aún no existe en ese idioma: faltan campos.', 'lachinata-core' ) );
	}

	/**
	 * Shows the translations of an object.
	 *
	 * ## OPTIONS
	 *
	 * <type>
	 * : post or term.
	 *
	 * <id>
	 * : Post or term id.
	 *
	 * [--format=<format>]
	 * : table or json.
	 * ---
	 * default: table
	 * ---
	 *
	 * @param string[]              $args       Arguments.
	 * @param array<string, string> $assoc_args Options.
	 */
	public function get( array $args, array $assoc_args ): void {
		$rows = array();
		foreach ( Store::all( $args[0], (int) $args[1] ) as $language => $fields ) {
			foreach ( $fields as $field => $row ) {
				$rows[] = array(
					'language' => $language,
					'field'    => $field,
					'status'   => $row['status'],
					'origin'   => $row['origin'],
					'text'     => mb_strimwidth( $row['text'], 0, 80, '…' ),
				);
			}
		}
		\WP_CLI\Utils\format_items( (string) ( $assoc_args['format'] ?? 'table' ), $rows, array( 'language', 'field', 'status', 'origin', 'text' ) );
	}

	/**
	 * Imports a file of translations.
	 *
	 * The file: {"formato": "lachinata-traducciones", "version": 1, "traducciones": [
	 * {"objeto": {...}, "idioma": "en_GB", "campos": {"name": "…"}}]}. The object is
	 * {"tipo": "post", "id": 12}, {"post_type": "product", "sku": "X"}, {"post_type":
	 * "page", "slug": "tienda"}, {"pagina": "cart"} (a page of WooCommerce) or
	 * {"taxonomia": "product_cat", "slug": "aceites"}.
	 *
	 * ## OPTIONS
	 *
	 * <file>
	 * : JSON file.
	 *
	 * [--dry-run]
	 * : Says what it would write, without writing.
	 *
	 * @param string[]              $args       Arguments.
	 * @param array<string, string> $assoc_args Options.
	 */
	public function import( array $args, array $assoc_args ): void {
		$json = file_get_contents( $args[0] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- a local file of the command.
		$data = is_string( $json ) ? json_decode( $json, true ) : null;
		if ( ! is_array( $data ) ) {
			\WP_CLI::error( __( 'El archivo no es JSON.', 'lachinata-core' ) );
		}
		$report = self::import_data( $data, isset( $assoc_args['dry-run'] ) );
		foreach ( $report['errors'] as $error ) {
			\WP_CLI::warning( $error );
		}
		/* translators: 1: fields written, 2: objects. */
		\WP_CLI::success( sprintf( __( '%1$d campos en %2$d objetos.', 'lachinata-core' ), $report['fields'], $report['objects'] ) );
	}

	/**
	 * Exports the translations of a language.
	 *
	 * ## OPTIONS
	 *
	 * --language=<language>
	 * : Locale.
	 *
	 * [--file=<file>]
	 * : Where to write; without it, to the screen.
	 *
	 * [--force]
	 * : Write over the file if it already exists.
	 *
	 * @param string[]              $args       Arguments.
	 * @param array<string, string> $assoc_args Options.
	 */
	public function export( array $args, array $assoc_args ): void {
		unset( $args );
		global $wpdb;
		$language = (string) $assoc_args['language'];
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table, a command.
		$rows = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT object_type, object_id, field, text FROM %i WHERE language = %s ORDER BY object_type, object_id, field', Store::table(), $language ), ARRAY_A );
		$out  = array();
		foreach ( $rows as $row ) {
			$key = $row['object_type'] . ':' . $row['object_id'];
			if ( ! isset( $out[ $key ] ) ) {
				$out[ $key ] = array(
					'objeto' => array(
						'tipo' => (string) $row['object_type'],
						'id'   => (int) $row['object_id'],
					),
					'idioma' => $language,
					'campos' => array(),
				);
			}
			$out[ $key ]['campos'][ (string) $row['field'] ] = (string) $row['text'];
		}
		$json = (string) wp_json_encode(
			array(
				'formato'      => self::FORMAT,
				'version'      => 1,
				'traducciones' => array_values( $out ),
			),
			JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
		);
		if ( empty( $assoc_args['file'] ) ) {
			\WP_CLI::line( $json );
			return;
		}
		Output::write( (string) $assoc_args['file'], $json . "\n", $assoc_args );
		\WP_CLI::success( (string) $assoc_args['file'] );
	}

	/**
	 * How many translations there are by language and state.
	 *
	 * @param string[]              $args       Arguments.
	 * @param array<string, string> $assoc_args Options.
	 */
	public function status( array $args, array $assoc_args ): void {
		unset( $args, $assoc_args );
		$rows = array();
		foreach ( Store::counts() as $language => $states ) {
			$rows[] = array(
				'language' => $language,
				'auto'     => $states[ Store::AUTO ] ?? 0,
				'edited'   => $states[ Store::EDITED ] ?? 0,
				'outdated' => $states[ Store::OUTDATED ] ?? 0,
				'pages'    => count( Entries::all( $language ) ),
			);
		}
		\WP_CLI\Utils\format_items( 'table', $rows, array( 'language', 'auto', 'edited', 'outdated', 'pages' ) );
	}

	/**
	 * Launches a batch: what a kind needs in a language enters the queue, with the words and
	 * the estimated cost. With --dry-run, only counts.
	 *
	 * ## OPTIONS
	 *
	 * --lang=<locale>
	 * : Language (en_GB).
	 *
	 * --type=<kind>
	 * : product, page, post, the other translatable post types, term or option.
	 *
	 * [--limit=<number>]
	 * : Objects at most.
	 *
	 * [--dry-run]
	 * : Count only.
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata translate run --lang=en_GB --type=product --limit=30 --dry-run
	 *
	 * @param string[]              $args       Arguments.
	 * @param array<string, string> $assoc_args Options.
	 */
	public function run( array $args, array $assoc_args ): void {
		unset( $args );
		$language = (string) ( $assoc_args['lang'] ?? '' );
		$kind     = (string) ( $assoc_args['type'] ?? '' );
		if ( ! isset( Config::languages()[ $language ] ) ) {
			/* translators: %s: locale. */
			\WP_CLI::error( sprintf( __( 'El idioma %s no está configurado.', 'lachinata-core' ), $language ) );
		}
		if ( ! isset( Runner::kinds()[ $kind ] ) ) {
			/* translators: %s: kinds. */
			\WP_CLI::error( sprintf( __( 'Tipo desconocido. Puede ser: %s.', 'lachinata-core' ), implode( ', ', array_keys( Runner::kinds() ) ) ) );
		}
		$dry_run = (bool) \WP_CLI\Utils\get_flag_value( $assoc_args, 'dry-run', false );
		$done    = Runner::launch( $language, $kind, (int) ( $assoc_args['limit'] ?? 0 ), $dry_run );
		\WP_CLI::success(
			sprintf(
				/* translators: 1: dry run or done, 2: objects, 3: words, 4: estimated cost, 5: fields to «Revisar». */
				__( '%1$s: %2$d fichas, %3$d palabras, unos %4$s USD con la API por lotes; %5$d campos corregidos por una persona irán a «Revisar».', 'lachinata-core' ),
				$dry_run ? __( 'Simulación', 'lachinata-core' ) : __( 'En la cola', 'lachinata-core' ),
				$done['objects'],
				$done['words'],
				number_format_i18n( $done['estimate'], 2 ),
				$done['review']
			)
		);
		if ( ! $dry_run ) {
			$blocked = Spend::blocked();
			\WP_CLI::log( '' === $blocked ? __( 'La cola los envía en la próxima pasada (cada cinco minutos), o ahora con wp lachinata translate tick.', 'lachinata-core' ) : $blocked );
		}
	}

	/**
	 * The move from TranslatePress: the strings a person corrected there (short ones) as
	 * proposals of the glossary and, with --csv (Search Console's list of old addresses of
	 * the language), what each one answers now, by clicks. Changes nothing else.
	 *
	 * ## OPTIONS
	 *
	 * [--language=<locale>]
	 * : Language (by default, the first one besides Spanish).
	 *
	 * [--csv=<file>]
	 * : Old addresses (columns url and, if any, clics_16m).
	 *
	 * [--report=<file>]
	 * : Report in Markdown (default: on screen).
	 *
	 * [--missing=<file>]
	 * : The addresses that answer 404, as a CSV for the list of redirections (url, destino_url empty).
	 *
	 * [--limit=<n>]
	 * : Addresses at most, the ones with most clicks first.
	 *
	 * [--skip-glossary]
	 * : Only the report.
	 *
	 * [--force]
	 * : Write over the report or the CSV if they already exist.
	 *
	 * @subcommand migrate-tp
	 *
	 * @param string[]              $args       Arguments.
	 * @param array<string, string> $assoc_args Options.
	 */
	public function migrate_tp( array $args, array $assoc_args ): void {
		unset( $args );
		$languages = array_keys( Config::languages() );
		$language  = (string) ( $assoc_args['language'] ?? ( $languages[0] ?? '' ) );
		if ( '' === $language || ! isset( Config::languages()[ $language ] ) ) {
			\WP_CLI::error( __( 'Ese idioma no está entre los de la tienda.', 'lachinata-core' ) );
		}
		Output::check( (string) ( $assoc_args['report'] ?? '' ), $assoc_args );
		Output::check( (string) ( $assoc_args['missing'] ?? '' ), $assoc_args );
		if ( empty( $assoc_args['skip-glossary'] ) ) {
			/* translators: %d: proposals. */
			\WP_CLI::log( sprintf( __( '%d cadenas de TranslatePress, propuestas al glosario.', 'lachinata-core' ), TranslatePress::propose( $language ) ) );
		}
		if ( empty( $assoc_args['csv'] ) ) {
			return;
		}
		$file = (string) $assoc_args['csv'];
		if ( ! is_readable( $file ) ) {
			/* translators: %s: file. */
			\WP_CLI::error( sprintf( __( 'No se puede leer %s.', 'lachinata-core' ), $file ) );
		}
		$rows     = TranslatePress::report( (string) file_get_contents( $file ), absint( $assoc_args['limit'] ?? 0 ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local file.
		$markdown = TranslatePress::markdown( $rows );
		if ( ! empty( $assoc_args['missing'] ) ) {
			Output::write( (string) $assoc_args['missing'], TranslatePress::missing_csv( $rows ), $assoc_args );
		}
		if ( empty( $assoc_args['report'] ) ) {
			\WP_CLI::line( $markdown );
			return;
		}
		Output::write( (string) $assoc_args['report'], $markdown, $assoc_args );
		\WP_CLI::success( (string) $assoc_args['report'] );
	}

	/**
	 * Runs the daily batch of what is «Revisado» now: it goes out if its estimate is below
	 * the ceiling of the panel.
	 *
	 * @param string[]              $args       Arguments.
	 * @param array<string, string> $assoc_args Options.
	 */
	public function daily( array $args, array $assoc_args ): void {
		unset( $args, $assoc_args );
		$done    = Runner::daily();
		$message = sprintf(
			/* translators: 1: objects, 2: words, 3: estimated cost in USD, 4: ceiling in USD. */
			__( '%1$d fichas «Revisadas», %2$d palabras, unos %3$s USD (umbral: %4$s USD).', 'lachinata-core' ),
			$done['objects'],
			$done['words'],
			number_format_i18n( $done['estimate'], 2 ),
			number_format_i18n( Runner::ceiling(), 2 )
		);
		if ( $done['sent'] ) {
			\WP_CLI::success( $message . ' ' . __( 'Pasan a una tanda.', 'lachinata-core' ) );
		} else {
			\WP_CLI::log( $message . ' ' . __( 'No sale: espera a que alguien la lance.', 'lachinata-core' ) );
		}
	}

	/**
	 * Runs the queue now: collects the batches that ended, translates the urgent items and
	 * sends the pending batches.
	 *
	 * @param string[]              $args       Arguments.
	 * @param array<string, string> $assoc_args Options.
	 */
	public function tick( array $args, array $assoc_args ): void {
		unset( $args, $assoc_args );
		$done = Runner::tick();
		if ( '' !== $done['stopped'] ) {
			\WP_CLI::warning( $done['stopped'] );
		}
		\WP_CLI::success(
			sprintf(
				/* translators: 1: items collected from batches, 2: translated now, 3: sent in a batch, 4: spent this month, 5: limit. */
				__( '%1$d recogidos de lotes, %2$d traducidos al momento, %3$d enviados en un lote. Este mes: %4$s de %5$s USD.', 'lachinata-core' ),
				$done['collected'],
				$done['translated'],
				$done['batched'],
				number_format_i18n( Spend::spent(), 4 ),
				number_format_i18n( Spend::limit(), 2 )
			)
		);
	}

	/**
	 * Sends back to the queue the items that failed (and, with --review, those in «Revisar»).
	 *
	 * ## OPTIONS
	 *
	 * [--review]
	 * : Also the items in «Revisar».
	 *
	 * @param string[]              $args       Arguments.
	 * @param array<string, string> $assoc_args Options.
	 */
	public function retry( array $args, array $assoc_args ): void {
		unset( $args );
		$count = Queue::retry( (bool) \WP_CLI\Utils\get_flag_value( $assoc_args, 'review', false ) );
		/* translators: %d: items. */
		\WP_CLI::success( sprintf( __( '%d vuelven a la cola.', 'lachinata-core' ), $count ) );
	}

	/**
	 * Proposes the initial glossary from the catalogue, as CSV to review before it goes to
	 * marketing: the brand and its ranges, the designations of origin and, with
	 * --wine-category, the names of the wines, wineries, D.O. and grapes as «no traducir».
	 * Nothing is saved.
	 *
	 * ## OPTIONS
	 *
	 * [--wine-category=<slug>]
	 * : Category of the wines (with its subcategories).
	 *
	 * [--file=<file>]
	 * : Writes the CSV there.
	 *
	 * [--force]
	 * : Write over the file if it already exists.
	 *
	 * @subcommand glossary-suggest
	 *
	 * @param string[]              $args       Arguments.
	 * @param array<string, string> $assoc_args Options.
	 */
	public function glossary_suggest( array $args, array $assoc_args ): void {
		unset( $args );
		$csv = GlossarySuggest::csv( GlossarySuggest::rows( (string) ( $assoc_args['wine-category'] ?? '' ) ) );
		if ( empty( $assoc_args['file'] ) ) {
			\WP_CLI::line( $csv );
			return;
		}
		Output::write( (string) $assoc_args['file'], $csv, $assoc_args );
		\WP_CLI::success( (string) $assoc_args['file'] );
	}

	/**
	 * Replaces the glossary with a CSV (language, term, translation; a translation empty
	 * keeps the term).
	 *
	 * ## OPTIONS
	 *
	 * <file>
	 * : CSV.
	 *
	 * @subcommand glossary-import
	 *
	 * @param string[]              $args       Arguments.
	 * @param array<string, string> $assoc_args Options.
	 */
	public function glossary_import( array $args, array $assoc_args ): void {
		unset( $assoc_args );
		$file = (string) ( $args[0] ?? '' );
		if ( ! is_readable( $file ) ) {
			/* translators: %s: file. */
			\WP_CLI::error( sprintf( __( 'No se puede leer %s.', 'lachinata-core' ), $file ) );
		}
		$rows = Glossary::from_csv( (string) file_get_contents( $file ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- a local file of the command.
		Glossary::save( $rows );
		/* translators: %d: terms. */
		\WP_CLI::success( sprintf( __( '%d términos en el glosario.', 'lachinata-core' ), count( $rows ) ) );
	}

	/**
	 * Prints the glossary as CSV.
	 *
	 * @subcommand glossary-export
	 *
	 * @param string[]              $args       Arguments.
	 * @param array<string, string> $assoc_args Options.
	 */
	public function glossary_export( array $args, array $assoc_args ): void {
		unset( $args, $assoc_args );
		\WP_CLI::line( Glossary::to_csv() );
	}

	/**
	 * Recalculates where each translated page exists (after changing what is required).
	 *
	 * @param string[]              $args       Arguments.
	 * @param array<string, string> $assoc_args Options.
	 */
	public function refresh( array $args, array $assoc_args ): void {
		unset( $args, $assoc_args );
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table, a command.
		$objects = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT DISTINCT object_type, object_id FROM %i', Store::table() ), ARRAY_A );
		foreach ( $objects as $object ) {
			Sync::object( (string) $object['object_type'], (int) $object['object_id'], false );
		}
		/* translators: %d: objects. */
		\WP_CLI::success( sprintf( __( '%d objetos recalculados.', 'lachinata-core' ), count( $objects ) ) );
	}

	/**
	 * Writes a file of translations.
	 *
	 * @param array<string, mixed> $data    File.
	 * @param bool                 $dry_run Without writing.
	 * @return array{objects: int, fields: int, errors: string[]}
	 */
	public static function import_data( array $data, bool $dry_run = false ): array {
		$report = array(
			'objects' => 0,
			'fields'  => 0,
			'errors'  => array(),
		);
		if ( self::FORMAT !== ( $data['formato'] ?? '' ) ) {
			$report['errors'][] = __( 'No es un archivo de traducciones de La Chinata.', 'lachinata-core' );
			return $report;
		}
		foreach ( (array) ( $data['traducciones'] ?? array() ) as $index => $entry ) {
			$entry  = is_array( $entry ) ? $entry : array();
			$object = self::find( is_array( $entry['objeto'] ?? null ) ? $entry['objeto'] : array() );
			if ( null === $object ) {
				/* translators: %d: position in the file. */
				$report['errors'][] = sprintf( __( 'Entrada %d: no se encuentra el objeto.', 'lachinata-core' ), (int) $index + 1 );
				continue;
			}
			$language = (string) ( $entry['idioma'] ?? '' );
			++$report['objects'];
			foreach ( (array) ( $entry['campos'] ?? array() ) as $field => $text ) {
				$error = $dry_run ? self::check( $object[0], $object[1], (string) $field, $language ) : self::write( $object[0], $object[1], (string) $field, $language, (string) $text, Store::AUTO, 'import' );
				if ( '' !== $error ) {
					$report['errors'][] = $error;
					continue;
				}
				++$report['fields'];
			}
			if ( ! $dry_run ) {
				Availability::refresh( $object[0], $object[1] );
			}
		}
		return $report;
	}

	/**
	 * Writes one field, with the fingerprint of its Spanish now; '' or the problem.
	 *
	 * @param string $type     «post» or «term».
	 * @param int    $id       Object id.
	 * @param string $field    Field.
	 * @param string $language Locale.
	 * @param string $text     Text.
	 * @param string $status   State.
	 * @param string $origin   Origin.
	 */
	private static function write( string $type, int $id, string $field, string $language, string $text, string $status, string $origin ): string {
		$error = self::check( $type, $id, $field, $language );
		if ( '' !== $error ) {
			return $error;
		}
		$subtype = (string) Fields::subtype( $type, $id );
		$def     = Fields::of( $type, $subtype )[ $field ];
		Store::put( $type, $subtype, $id, $field, $language, Editor::clean( $text, $def['format'] ), Store::fingerprint( Fields::source( $type, $id, $def ) ), $status, $origin );
		return '';
	}

	/**
	 * '' when a field of an object can be translated to a language, or the problem.
	 *
	 * @param string $type     «post» or «term».
	 * @param int    $id       Object id.
	 * @param string $field    Field.
	 * @param string $language Locale.
	 */
	private static function check( string $type, int $id, string $field, string $language ): string {
		if ( ! isset( Config::languages()[ $language ] ) ) {
			/* translators: %s: locale. */
			return sprintf( __( '%s no es un idioma de la tienda.', 'lachinata-core' ), $language );
		}
		$subtype = in_array( $type, array( 'post', 'term' ), true ) ? Fields::subtype( $type, $id ) : null;
		if ( null === $subtype ) {
			/* translators: 1: type, 2: id. */
			return sprintf( __( 'No existe %1$s %2$d.', 'lachinata-core' ), $type, $id );
		}
		if ( ! isset( Fields::of( $type, $subtype )[ $field ] ) ) {
			/* translators: 1: field, 2: kind of object (post and product). */
			return sprintf( __( '%1$s no es un campo traducible de %2$s.', 'lachinata-core' ), $field, $type . ':' . $subtype );
		}
		return '';
	}

	/**
	 * The object of an entry of the file.
	 *
	 * @param array<string, mixed> $ref Reference.
	 * @return array{0: string, 1: int}|null
	 */
	private static function find( array $ref ): ?array {
		if ( isset( $ref['tipo'], $ref['id'] ) ) {
			return array( (string) $ref['tipo'], (int) $ref['id'] );
		}
		if ( isset( $ref['pagina'] ) && function_exists( 'wc_get_page_id' ) ) {
			$id = (int) wc_get_page_id( (string) $ref['pagina'] );
			return $id > 0 ? array( 'post', $id ) : null;
		}
		if ( isset( $ref['post_type'], $ref['sku'] ) && function_exists( 'wc_get_product_id_by_sku' ) ) {
			$id = (int) wc_get_product_id_by_sku( (string) $ref['sku'] );
			return $id > 0 ? array( 'post', $id ) : null;
		}
		if ( isset( $ref['post_type'], $ref['slug'] ) ) {
			$post = get_page_by_path( (string) $ref['slug'], OBJECT, (string) $ref['post_type'] );
			return $post instanceof \WP_Post ? array( 'post', $post->ID ) : null;
		}
		if ( isset( $ref['taxonomia'], $ref['slug'] ) ) {
			$term = get_term_by( 'slug', (string) $ref['slug'], (string) $ref['taxonomia'] );
			return $term instanceof \WP_Term ? array( 'term', $term->term_id ) : null;
		}
		return null;
	}
}
