<?php
/**
 * The controls a translation passes before it is published.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

defined( 'ABSPATH' ) || exit;

/**
 * The seven controls of 07: there is no review before publishing, so they are strict. A
 * translation that fails one is not published and goes to «Revisar» with the reason.
 */
final class Controls {

	/**
	 * Common words of each language, to tell the language of a text.
	 */
	private const WORDS = array(
		'es' => array( 'el', 'la', 'los', 'las', 'de', 'del', 'que', 'y', 'en', 'con', 'para', 'por', 'una', 'un', 'es', 'su', 'sus', 'al', 'como', 'más', 'este', 'esta' ),
		'en' => array( 'the', 'and', 'of', 'to', 'with', 'for', 'in', 'is', 'a', 'an', 'its', 'this', 'that', 'it', 'on', 'from', 'as', 'your', 'our', 'are' ),
		'de' => array( 'der', 'die', 'das', 'und', 'mit', 'für', 'ist', 'ein', 'eine', 'von', 'zu', 'den', 'dem', 'des', 'auf', 'nicht', 'sie', 'ihr' ),
		'fr' => array( 'le', 'la', 'les', 'et', 'des', 'du', 'pour', 'avec', 'est', 'une', 'un', 'dans', 'sur', 'au', 'aux', 'ce', 'cette', 'vous', 'votre' ),
	);

	/**
	 * Checks one field.
	 *
	 * @param string                                                           $source      Spanish.
	 * @param string                                                           $translation Translation.
	 * @param array{format?: string, max?: int, label?: string, name?: string} $field       Definition (format, max).
	 * @param string                                                           $language    Locale.
	 * @return string[] Reasons (none: it passes).
	 */
	public static function check( string $source, string $translation, array $field, string $language ): array {
		$format = (string) ( $field['format'] ?? 'text' );
		$name   = (string) ( $field['name'] ?? '' );
		if ( '' === trim( $translation ) ) {
			return array( __( 'La traducción está vacía.', 'lachinata-core' ) );
		}
		if ( 'slug' === $name ) {
			return sanitize_title( $translation ) === $translation ? array() : array( __( 'El slug no es válido (minúsculas, números y guiones).', 'lachinata-core' ) );
		}
		$reasons = array();
		if ( 'json' === $format ) {
			$from = json_decode( $source, true );
			$to   = json_decode( $translation, true );
			if ( ! is_array( $to ) || ! is_array( $from ) || self::shape( $from ) !== self::shape( $to ) ) {
				$reasons[] = __( 'La lista traducida no tiene la misma forma que la española.', 'lachinata-core' );
				return $reasons;
			}
		}
		foreach ( array(
			self::figures( $source, $translation ),
			self::glossary( $source, $translation, $language ),
			self::markup( $source, $translation ),
			self::placeholders( $source, $translation ),
			self::length( $translation, (int) ( $field['max'] ?? 0 ) ),
			self::language( $translation, $language, $source ),
			self::additions( $source, $translation ),
		) as $reason ) {
			if ( '' !== $reason ) {
				$reasons[] = $reason;
			}
		}
		return $reasons;
	}

	/**
	 * 1. Same figures: numbers, percentages, quantities, units and prices. The digits are
	 * compared group by group, so «2,5» and «2.5», or «1.000» and «1,000», are the same.
	 *
	 * @param string $source      Spanish.
	 * @param string $translation Translation.
	 */
	public static function figures( string $source, string $translation ): string {
		$from = self::digits( $source );
		$to   = self::digits( $translation );
		if ( $from !== $to ) {
			/* translators: 1: figures in Spanish, 2: figures in the translation. */
			return sprintf( __( 'Las cifras no coinciden (%1$s / %2$s).', 'lachinata-core' ), $from ? implode( ' ', $from ) : '—', $to ? implode( ' ', $to ) : '—' );
		}
		if ( substr_count( $source, '%' ) - self::placeholder_count( $source ) !== substr_count( $translation, '%' ) - self::placeholder_count( $translation ) ) {
			return __( 'Los porcentajes no coinciden.', 'lachinata-core' );
		}
		return '';
	}

	/**
	 * 2. Glossary: the fixed terms with their translation and the kept ones untouched.
	 *
	 * @param string $source      Spanish.
	 * @param string $translation Translation.
	 * @param string $language    Locale.
	 */
	public static function glossary( string $source, string $translation, string $language ): string {
		$plain   = wp_strip_all_tags( $translation );
		$missing = array();
		foreach ( Glossary::in( $source, $language ) as $row ) {
			if ( ! Glossary::has( $plain, $row['translation'] ) || ( $row['keep'] && false === mb_strpos( $plain, $row['term'] ) ) ) {
				$missing[] = $row['keep'] ? $row['term'] : $row['term'] . ' → ' . $row['translation'];
			}
		}
		/* translators: %s: terms. */
		return $missing ? sprintf( __( 'Glosario: falta %s.', 'lachinata-core' ), implode( ', ', $missing ) ) : '';
	}

	/**
	 * 3. Markup and blocks: the same tags in the same order (lists, tables, the underlined
	 * allergens), the same blocks, shortcodes and links.
	 *
	 * @param string $source      Spanish.
	 * @param string $translation Translation.
	 */
	public static function markup( string $source, string $translation ): string {
		if ( self::tags( $source ) !== self::tags( $translation ) ) {
			return __( 'El HTML no tiene la misma estructura que el español.', 'lachinata-core' );
		}
		if ( self::blocks( $source ) !== self::blocks( $translation ) ) {
			return __( 'Los bloques o los códigos cortos no coinciden con el español.', 'lachinata-core' );
		}
		if ( self::links( $source ) !== self::links( $translation ) ) {
			return __( 'Los enlaces no coinciden con el español.', 'lachinata-core' );
		}
		return '';
	}

	/**
	 * 4. Placeholders of the strings (`%1$s`, `%s`, `{nombre}`), all of them and untouched.
	 *
	 * @param string $source      Spanish.
	 * @param string $translation Translation.
	 */
	public static function placeholders( string $source, string $translation ): string {
		return self::markers( $source ) === self::markers( $translation ) ? '' : __( 'Faltan o sobran marcadores de las cadenas.', 'lachinata-core' );
	}

	/**
	 * 5. Length: the limit of the field (SEO title 60, description 155, interface labels).
	 *
	 * @param string $translation Translation.
	 * @param int    $max         Limit (0: none).
	 */
	public static function length( string $translation, int $max ): string {
		$length = mb_strlen( wp_strip_all_tags( $translation ) );
		/* translators: 1: characters, 2: limit. */
		return $max > 0 && $length > $max ? sprintf( __( 'Demasiado larga: %1$d caracteres de %2$d.', 'lachinata-core' ), $length, $max ) : '';
	}

	/**
	 * 6. Language: the text is in the language asked (common words), when it is long enough
	 * to tell. The «no traducir» terms of the Spanish do not count («José Gil Viñedos en San
	 * Vicente de la Sonsierra» is a name).
	 *
	 * @param string $translation Translation.
	 * @param string $language    Locale.
	 * @param string $source      Spanish.
	 */
	public static function language( string $translation, string $language, string $source = '' ): string {
		$code  = strtolower( (string) strtok( $language, '_' ) );
		$plain = wp_strip_all_tags( $translation );
		foreach ( '' === $source ? array() : Glossary::in( $source, $language ) as $row ) {
			if ( $row['keep'] ) {
				$plain = str_replace( $row['term'], ' ', $plain );
			}
		}
		$words = preg_split( '/[^\p{L}]+/u', mb_strtolower( $plain ), -1, PREG_SPLIT_NO_EMPTY );
		$words = false === $words ? array() : $words;
		if ( count( $words ) < 8 || ! isset( self::WORDS[ $code ] ) ) {
			return '';
		}
		$scores = array();
		foreach ( self::WORDS as $lang => $list ) {
			$scores[ $lang ] = count( array_intersect( $words, $list ) );
		}
		arsort( $scores );
		$best = (string) array_key_first( $scores );
		return $best === $code || $scores[ $best ] === $scores[ $code ] ? '' : __( 'El texto no parece estar en el idioma pedido.', 'lachinata-core' );
	}

	/**
	 * 7. Nothing added or left out: not more than 40 % longer or shorter than the Spanish
	 * (texts of some length; a name can change a lot).
	 *
	 * @param string $source      Spanish.
	 * @param string $translation Translation.
	 */
	public static function additions( string $source, string $translation ): string {
		$from = mb_strlen( trim( wp_strip_all_tags( $source ) ) );
		$to   = mb_strlen( trim( wp_strip_all_tags( $translation ) ) );
		if ( $from < 60 ) {
			return '';
		}
		$ratio = $to / $from;
		/* translators: %d: difference in percent. */
		return $ratio > 1.4 || $ratio < 0.6 ? sprintf( __( 'La longitud cambia un %d %% respecto al español: puede faltar o sobrar texto.', 'lachinata-core' ), (int) round( abs( $ratio - 1 ) * 100 ) ) : '';
	}

	/**
	 * Groups of digits of a text, sorted (without markup, links and placeholders).
	 *
	 * @param string $text Text.
	 * @return string[]
	 */
	private static function digits( string $text ): array {
		$text = (string) preg_replace( '/<!--.*?-->/s', ' ', $text );
		$text = (string) preg_replace( '/\b(?:href|src)="[^"]*"/i', ' ', $text );
		$text = (string) preg_replace( '/%\d+\$[sd]|%[sd]/', ' ', wp_strip_all_tags( $text ) );
		preg_match_all( '/\d+/', $text, $matches );
		$found = array_map( static fn( string $digits ): string => '' === ltrim( $digits, '0' ) ? '0' : ltrim( $digits, '0' ), $matches[0] );
		sort( $found );
		return $found;
	}

	/**
	 * How many printf placeholders a text has.
	 *
	 * @param string $text Text.
	 */
	private static function placeholder_count( string $text ): int {
		return (int) preg_match_all( '/%(?:\d+\$)?[sd]/', $text );
	}

	/**
	 * Placeholders of a text, sorted.
	 *
	 * @param string $text Text.
	 * @return string[]
	 */
	private static function markers( string $text ): array {
		preg_match_all( '/%(?:\d+\$)?[sd]|\{[a-z_]+\}/', $text, $matches );
		$found = $matches[0];
		sort( $found );
		return $found;
	}

	/**
	 * Tag names in order (opening and closing).
	 *
	 * @param string $text Text.
	 * @return string[]
	 */
	private static function tags( string $text ): array {
		$text = (string) preg_replace( '/<!--.*?-->/s', '', $text );
		preg_match_all( '#<(/?)([a-z][a-z0-9]*)\b#i', $text, $matches, PREG_SET_ORDER );
		return array_map( static fn( array $m ): string => $m[1] . strtolower( $m[2] ), $matches );
	}

	/**
	 * Block comments and shortcodes in order.
	 *
	 * @param string $text Text.
	 * @return string[]
	 */
	private static function blocks( string $text ): array {
		preg_match_all( '#<!--\s*(/?wp:[a-z0-9/-]+)|\[(/?[a-z_-]+)#i', $text, $matches, PREG_SET_ORDER );
		return array_map( static fn( array $m ): string => strtolower( '' !== $m[1] ? $m[1] : $m[2] ), $matches );
	}

	/**
	 * Addresses of the links, in order.
	 *
	 * @param string $text Text.
	 * @return string[]
	 */
	private static function links( string $text ): array {
		preg_match_all( '/\bhref\s*=\s*"([^"]*)"/i', $text, $matches );
		return $matches[1];
	}

	/**
	 * Keys of a list at every level, to compare two lists.
	 *
	 * @param array<mixed> $data List.
	 * @return array<mixed>
	 */
	private static function shape( array $data ): array {
		$out = array();
		foreach ( $data as $key => $value ) {
			$out[ $key ] = is_array( $value ) ? self::shape( $value ) : 1;
		}
		return $out;
	}
}
