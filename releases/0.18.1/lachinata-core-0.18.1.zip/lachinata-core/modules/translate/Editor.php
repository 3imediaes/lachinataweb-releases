<?php
/**
 * The translations beside the Spanish, in the editor.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * In the editor of each product, page and entry (and of each category or term), one tab per
 * language with the Spanish and the translation field by field, side by side, and its state;
 * since 0.17.0, «Volver a traducir» on each field and «Proponer al glosario» on each language.
 * Changing a field makes it «Editada» (by a person): an automatic translation never
 * overwrites it. There is no editing from the public side.
 */
final class Editor {

	/**
	 * Nonce field and action.
	 */
	private const NONCE = 'lc_translate_nonce';

	/**
	 * Field of the form.
	 */
	private const FIELD = 'lc_translate';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'add_meta_boxes', array( self::class, 'meta_box' ), 20, 2 );
		Hooks::add_action( 'save_post', array( self::class, 'save_post' ), 30, 2 );
		Hooks::add_action( 'admin_init', array( self::class, 'terms' ) );
		Hooks::add_action( 'admin_head', array( self::class, 'style' ) );
	}

	/**
	 * The box in the editors of translatable kinds with addresses.
	 *
	 * @param mixed $post_type Post type.
	 */
	public static function meta_box( $post_type ): void {
		$post_type = (string) $post_type;
		if ( ! Config::languages() || ! Availability::whole( 'post', $post_type ) ) {
			return;
		}
		add_meta_box( 'lc-translate', __( 'Traducciones', 'lachinata-core' ), array( self::class, 'box' ), $post_type, 'normal', 'low' );
	}

	/**
	 * The box of a post.
	 *
	 * @param \WP_Post $post Post.
	 */
	public static function box( \WP_Post $post ): void {
		wp_nonce_field( 'lc_translate_post_' . $post->ID, self::NONCE );
		self::tabs( 'post', $post->ID, $post->post_type );
	}

	/**
	 * Saves the box of a post.
	 *
	 * @param mixed $post_id Post id.
	 * @param mixed $post    Post.
	 */
	public static function save_post( $post_id, $post = null ): void {
		$post_id = (int) $post_id;
		if ( ! $post instanceof \WP_Post || wp_is_post_revision( $post_id ) || ! isset( $_POST[ self::NONCE ], $_POST[ self::FIELD ] ) ) {
			return;
		}
		if ( ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST[ self::NONCE ] ) ), 'lc_translate_post_' . $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- each field is cleaned by its format in save().
		self::save( 'post', $post_id, $post->post_type, (array) wp_unslash( $_POST[ self::FIELD ] ) );
	}

	/**
	 * The rows in the edit screens of the translatable taxonomies.
	 */
	public static function terms(): void {
		if ( ! Config::languages() ) {
			return;
		}
		foreach ( Fields::subtypes( 'term' ) as $taxonomy ) {
			Hooks::add_action( $taxonomy . '_edit_form', array( self::class, 'term_box' ), 20 );
			Hooks::add_action( 'edited_' . $taxonomy, array( self::class, 'save_term' ), 20 );
		}
	}

	/**
	 * The translations of a term, under its form.
	 *
	 * @param mixed $term Term.
	 */
	public static function term_box( $term ): void {
		if ( ! $term instanceof \WP_Term ) {
			return;
		}
		echo '<div id="lc-translate" class="postbox"><h2 class="hndle">' . esc_html__( 'Traducciones', 'lachinata-core' ) . '</h2><div class="inside">';
		wp_nonce_field( 'lc_translate_term_' . $term->term_id, self::NONCE );
		self::tabs( 'term', $term->term_id, $term->taxonomy );
		echo '</div></div>';
	}

	/**
	 * Saves the translations of a term.
	 *
	 * @param mixed $term_id Term id.
	 */
	public static function save_term( $term_id ): void {
		$term_id = (int) $term_id;
		$term    = get_term( $term_id );
		if ( ! $term instanceof \WP_Term || ! isset( $_POST[ self::NONCE ], $_POST[ self::FIELD ] ) ) {
			return;
		}
		if ( ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST[ self::NONCE ] ) ), 'lc_translate_term_' . $term_id ) || ! current_user_can( 'edit_term', $term_id ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- each field is cleaned by its format in save().
		self::save( 'term', $term_id, $term->taxonomy, (array) wp_unslash( $_POST[ self::FIELD ] ) );
	}

	/**
	 * Writes what changed: a changed field is «Editada» by a person, with the fingerprint
	 * of the Spanish it was written for; an emptied one is deleted.
	 *
	 * @param string               $type    «post» or «term».
	 * @param int                  $id      Object id.
	 * @param string               $subtype Post type or taxonomy.
	 * @param array<string, mixed> $posted  Fields by language.
	 * @return int Fields changed.
	 */
	public static function save( string $type, int $id, string $subtype, array $posted ): int {
		$fields  = Fields::of( $type, $subtype );
		$changed = 0;
		foreach ( array_keys( Config::languages() ) as $language ) {
			$values = isset( $posted[ $language ] ) && is_array( $posted[ $language ] ) ? $posted[ $language ] : array();
			$rows   = Store::get( $type, $id, $language );
			$again  = is_array( $values['__retranslate'] ?? null ) ? $values['__retranslate'] : array();
			$term   = is_array( $values['__glossary'] ?? null ) ? $values['__glossary'] : array();
			if ( '' !== trim( (string) ( $term['term'] ?? '' ) ) ) {
				Glossary::propose( $language, (string) $term['term'], (string) ( $term['translation'] ?? '' ), __( 'Editor', 'lachinata-core' ) );
			}
			foreach ( $fields as $name => $field ) {
				if ( ! empty( $again[ $name ] ) && isset( $rows[ $name ] ) ) {
					// «Volver a traducir»: the correction is dropped and the field goes first in the queue.
					Translator::retranslate( $type, $id, $name, $language );
					continue;
				}
				if ( ! array_key_exists( $name, $values ) ) {
					continue;
				}
				$text   = self::clean( (string) $values[ $name ], $field['format'] );
				$before = $rows[ $name ]['text'] ?? '';
				if ( 'json' === $field['format'] && '' !== $text && ! is_array( json_decode( $text, true ) ) ) {
					continue;
				}
				if ( $before === $text ) {
					continue;
				}
				$hash     = Store::fingerprint( Fields::source( $type, $id, $field ) );
				$changed += Store::put( $type, $subtype, $id, $name, $language, $text, $hash, Store::EDITED, 'person' ) ? 1 : 0;
			}
		}
		if ( $changed > 0 ) {
			Availability::refresh( $type, $id );
			/**
			 * A person changed translations in the editor (the memory of 11c listens).
			 *
			 * @since 0.15.0
			 *
			 * @param string $type    «post» or «term».
			 * @param int    $id      Object id.
			 * @param int    $changed Fields changed.
			 */
			do_action( 'lachinata/translate/edited', $type, $id, $changed );
		}
		return $changed;
	}

	/**
	 * A text cleaned by its format.
	 *
	 * @param string $text   Text.
	 * @param string $format «text», «html» or «blocks».
	 */
	public static function clean( string $text, string $format ): string {
		$text = str_replace( array( "\r\n", "\r" ), "\n", $text );
		if ( 'text' === $format ) {
			return trim( sanitize_textarea_field( $text ) );
		}
		if ( 'json' === $format ) {
			$value = json_decode( $text, true );
			return is_array( $value ) ? (string) wp_json_encode( map_deep( $value, 'sanitize_textarea_field' ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) : trim( $text );
		}
		return trim( current_user_can( 'unfiltered_html' ) ? $text : wp_kses_post( $text ) );
	}

	/**
	 * State of a field for people.
	 *
	 * @param array{text: string, hash: string, status: string, origin: string, updated: string}|null $row  Translation.
	 * @param string                                                                                  $hash Fingerprint of the Spanish now.
	 */
	public static function state( ?array $row, string $hash ): string {
		if ( null === $row ) {
			return __( 'Sin traducir', 'lachinata-core' );
		}
		if ( Store::OUTDATED === $row['status'] || ( '' !== $row['hash'] && $row['hash'] !== $hash ) ) {
			return __( 'Desfasada: el español cambió', 'lachinata-core' );
		}
		return Store::EDITED === $row['status'] || 'person' === $row['origin'] ? __( 'Editada', 'lachinata-core' ) : __( 'Automática', 'lachinata-core' );
	}

	/**
	 * One tab per language with the fields side by side.
	 *
	 * @param string $type    «post» or «term».
	 * @param int    $id      Object id.
	 * @param string $subtype Post type or taxonomy.
	 */
	private static function tabs( string $type, int $id, string $subtype ): void {
		$fields    = Fields::of( $type, $subtype );
		$languages = Config::languages();
		$service   = Service::instance();
		if ( count( $languages ) > 1 ) {
			echo '<p class="lc-translate-tabs">';
			foreach ( $languages as $locale => $language ) {
				printf( '<a class="button" href="#lc-translate-%1$s">%2$s</a> ', esc_attr( $language['code'] ), esc_html( $service->label( $locale ) ) );
			}
			echo '</p>';
		}
		foreach ( $languages as $locale => $language ) {
			$rows    = Store::get( $type, $id, $locale );
			$exists  = Availability::is( $type, $id, $locale );
			$missing = array();
			printf( '<section class="lc-translate" id="lc-translate-%1$s"><h3>%2$s</h3>', esc_attr( $language['code'] ), esc_html( $service->label( $locale ) ) );
			echo '<table class="widefat striped lc-translate__table"><thead><tr>';
			echo '<th scope="col">' . esc_html__( 'Campo', 'lachinata-core' ) . '</th><th scope="col">' . esc_html__( 'Español', 'lachinata-core' ) . '</th><th scope="col">' . esc_html( $service->label( $locale ) ) . '</th>';
			echo '</tr></thead><tbody>';
			foreach ( $fields as $name => $field ) {
				$source = Fields::source( $type, $id, $field );
				$row    = $rows[ $name ] ?? null;
				if ( $field['required'] && Fields::has_text( $source ) && null === $row ) {
					$missing[] = $field['label'];
				}
				$input = sprintf( 'lc-translate-%1$s-%2$s', $language['code'], $name );
				printf(
					'<tr><th scope="row"><label for="%1$s">%2$s</label><p class="description">%3$s</p></th><td><div class="lc-translate__source" data-no-translation>%4$s</div></td><td>%5$s</td></tr>',
					esc_attr( $input ),
					esc_html( $field['label'] ),
					esc_html( self::state( $row, Store::fingerprint( $source ) ) ),
					'text' === $field['format'] ? esc_html( $source ) : '<pre>' . esc_html( $source ) . '</pre>',
					sprintf(
						'<textarea id="%1$s" name="%2$s[%3$s][%4$s]" rows="%5$d" class="large-text"%6$s>%7$s</textarea>%8$s%9$s',
						esc_attr( $input ),
						esc_attr( self::FIELD ),
						esc_attr( $locale ),
						esc_attr( $name ),
						'text' === $field['format'] ? 2 : 8,
						$field['max'] > 0 ? ' maxlength="' . esc_attr( (string) $field['max'] ) . '"' : '',
						esc_textarea( (string) ( $row['text'] ?? '' ) ),
						$field['max'] > 0
							/* translators: %d: maximum characters. */
							? '<p class="description">' . esc_html( sprintf( __( 'Hasta %d caracteres.', 'lachinata-core' ), $field['max'] ) ) . '</p>'
							: '',
						null === $row ? '' : sprintf(
							'<label><input type="checkbox" name="%1$s[%2$s][__retranslate][%3$s]" value="1"> %4$s</label>',
							esc_attr( self::FIELD ),
							esc_attr( $locale ),
							esc_attr( $name ),
							esc_html__( 'Volver a traducir (descarta esta traducción y la pone la primera en la cola)', 'lachinata-core' )
						)
					)
				);
			}
			echo '</tbody></table>';
			printf(
				'<p class="lc-translate__glossary"><strong>%1$s</strong> <label>%2$s <input type="text" name="%3$s[%4$s][__glossary][term]"></label> <label>%5$s <input type="text" name="%3$s[%4$s][__glossary][translation]"></label> <span class="description">%6$s</span></p>',
				esc_html__( 'Proponer al glosario:', 'lachinata-core' ),
				esc_html__( 'término en español', 'lachinata-core' ),
				esc_attr( self::FIELD ),
				esc_attr( $locale ),
				esc_html__( 'traducción', 'lachinata-core' ),
				esc_html__( 'Vacía, el término no se traduce. Queda como propuesta en Traducción → Glosario.', 'lachinata-core' )
			);
			if ( $exists ) {
				$url = 'post' === $type ? $service->post_url( $id, $locale ) : $service->term_url( $id, $locale );
				/* translators: %s: language («English»). */
				printf( '<p class="lc-translate__state">%1$s <a href="%2$s">%3$s</a></p>', esc_html( sprintf( __( 'Existe en %s:', 'lachinata-core' ), $service->label( $locale ) ) ), esc_url( $url ), esc_html( $url ) );
			} elseif ( $missing ) {
				/* translators: 1: language («English»), 2: fields («Nombre, Descripción»). */
				printf( '<p class="lc-translate__state">%s</p>', esc_html( sprintf( __( 'No existe en %1$s hasta que estén traducidos: %2$s.', 'lachinata-core' ), $service->label( $locale ), implode( ', ', $missing ) ) ) );
			}
			echo '</section>';
		}
	}

	/**
	 * The two columns of the box.
	 */
	public static function style(): void {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( null === $screen || ! in_array( $screen->base, array( 'post', 'term' ), true ) ) {
			return;
		}
		echo '<style>.lc-translate__table th[scope=row]{width:14%}.lc-translate__table td{width:43%;vertical-align:top}.lc-translate__source{max-height:16em;overflow:auto;white-space:pre-wrap}.lc-translate__source pre{white-space:pre-wrap;margin:0;font-size:12px}.lc-translate__state{font-weight:600}</style>';
	}
}
