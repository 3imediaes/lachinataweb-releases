<?php
/**
 * What is translated of each kind of object.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

defined( 'ABSPATH' ) || exit;

/**
 * The translatable fields of each kind of object («post:product», «term:product_cat»), with
 * where the Spanish lives (a field of the post or the term, or a meta key), its format and
 * whether the page needs it to exist in a language. The module brings those of WordPress,
 * WooCommerce and Rank Math; each module adds its own with `lachinata/translate/fields`, so
 * `translate` never knows their classes. Ingredients and nutrition are never declared
 * (07-traduccion.md: they come from the application of La Chinata).
 */
final class Fields {

	/**
	 * Where a field lives.
	 */
	public const POST      = 'post';
	public const META      = 'meta';
	public const TERM      = 'term';
	public const TERM_META = 'term_meta';

	/**
	 * Source of the own attributes of a product (not of a taxonomy): name and values of each
	 * one, as a JSON list ({key: {name, values}}). Since 0.17.0.
	 */
	public const ATTRIBUTES = 'attributes';

	/**
	 * Fields by kind, once built.
	 *
	 * @var array<string, array<string, array{label: string, source: string, key: string, format: string, required: bool, fallback: string, max: int}>>|null
	 */
	private static ?array $fields = null;

	/**
	 * Meta keys that are translated, by meta type («post», «term»).
	 *
	 * @var array<string, array<string, true>>|null
	 */
	private static ?array $meta = null;

	/**
	 * Every kind with its fields.
	 *
	 * @return array<string, array<string, array{label: string, source: string, key: string, format: string, required: bool, fallback: string, max: int}>>
	 */
	public static function all(): array {
		if ( null === self::$fields ) {
			/**
			 * Translatable fields by kind of object: «post:{post type}» or «term:{taxonomy}» →
			 * field → definition. A definition says:
			 * - `label`: name for people («Descripción corta»);
			 * - `source`: where the Spanish is: `post` (a column of the post: post_title,
			 *   post_excerpt, post_content), `meta` (post meta), `term` (name, description)
			 *   or `term_meta`;
			 * - `key`: the column or the meta key;
			 * - `format`: `text`, `html`, `blocks` or `json` (a list kept as an array, like the
			 *   questions of a zone: translated as JSON with the same keys);
			 * - `required`: whether the page needs it translated to exist in a language (when
			 *   the Spanish is not empty). Default true;
			 * - `fallback`: what a page in another language shows without the translation:
			 *   `source` (the Spanish, default) or `empty` (nothing: SEO, where the plugin
			 *   writes its own from the translated title);
			 * - `max`: length limit in characters (0, none).
			 *
			 * The slug is the field `slug` of each kind that has addresses.
			 *
			 * @since 0.15.0
			 *
			 * @param array<string, array<string, array<string, mixed>>> $fields Fields of WordPress, WooCommerce and Rank Math.
			 */
			$raw          = (array) apply_filters( 'lachinata/translate/fields', self::defaults() );
			self::$fields = array();
			foreach ( $raw as $kind => $fields ) {
				if ( ! is_string( $kind ) || ! preg_match( '/^(post|term):[a-z0-9_-]+$/', $kind ) || ! is_array( $fields ) ) {
					continue;
				}
				foreach ( $fields as $name => $field ) {
					if ( is_string( $name ) && is_array( $field ) && isset( $field['source'], $field['key'] ) ) {
						self::$fields[ $kind ][ $name ] = self::normalize( $field, $name );
					}
				}
			}
		}
		return self::$fields;
	}

	/**
	 * Fields of a kind.
	 *
	 * @param string $type    «post» or «term».
	 * @param string $subtype Post type or taxonomy.
	 * @return array<string, array{label: string, source: string, key: string, format: string, required: bool, fallback: string, max: int}>
	 */
	public static function of( string $type, string $subtype ): array {
		return self::all()[ $type . ':' . $subtype ] ?? array();
	}

	/**
	 * Whether a kind of object is translated.
	 *
	 * @param string $type    «post» or «term».
	 * @param string $subtype Post type or taxonomy.
	 */
	public static function translatable( string $type, string $subtype ): bool {
		return array() !== self::of( $type, $subtype );
	}

	/**
	 * Subtypes of a type with translatable fields.
	 *
	 * @param string $type «post» or «term».
	 * @return string[]
	 */
	public static function subtypes( string $type ): array {
		$out = array();
		foreach ( array_keys( self::all() ) as $kind ) {
			if ( str_starts_with( $kind, $type . ':' ) ) {
				$out[] = substr( $kind, strlen( $type ) + 1 );
			}
		}
		return $out;
	}

	/**
	 * Whether a meta key is translated for some kind of that meta type.
	 *
	 * @param string $meta_type «post» or «term».
	 * @param string $key       Meta key.
	 */
	public static function is_meta( string $meta_type, string $key ): bool {
		if ( null === self::$meta ) {
			self::$meta = array(
				'post' => array(),
				'term' => array(),
			);
			foreach ( self::all() as $fields ) {
				foreach ( $fields as $field ) {
					if ( self::META === $field['source'] || self::ATTRIBUTES === $field['source'] ) {
						self::$meta['post'][ $field['key'] ] = true;
					} elseif ( self::TERM_META === $field['source'] ) {
						self::$meta['term'][ $field['key'] ] = true;
					}
				}
			}
		}
		return isset( self::$meta[ $meta_type ][ $key ] );
	}

	/**
	 * The field of a kind stored in a meta key.
	 *
	 * @param string $type    «post» or «term».
	 * @param string $subtype Post type or taxonomy.
	 * @param string $key     Meta key.
	 */
	public static function by_meta( string $type, string $subtype, string $key ): ?string {
		foreach ( self::of( $type, $subtype ) as $name => $field ) {
			if ( in_array( $field['source'], array( self::META, self::TERM_META ), true ) && $field['key'] === $key ) {
				return $name;
			}
		}
		return null;
	}

	/**
	 * The Spanish of a field, as it is stored (never translated).
	 *
	 * @param string                                                                                                        $type  «post» or «term».
	 * @param int                                                                                                           $id    Object id.
	 * @param array{label: string, source: string, key: string, format: string, required: bool, fallback: string, max: int} $field Definition.
	 */
	public static function source( string $type, int $id, array $field ): string {
		unset( $type );
		return Front::raw(
			static function () use ( $id, $field ): string {
				switch ( $field['source'] ) {
					case self::POST:
						return (string) get_post_field( $field['key'], $id, 'raw' );
					case self::META:
						return self::scalar( get_post_meta( $id, $field['key'], true ) );
					case self::TERM:
						$term = get_term( $id );
						return $term instanceof \WP_Term && isset( $term->{$field['key']} ) ? (string) $term->{$field['key']} : '';
					case self::TERM_META:
						return self::scalar( get_term_meta( $id, $field['key'], true ) );
					case self::ATTRIBUTES:
						return self::scalar( self::attributes( $id ) );
				}
				return '';
			}
		);
	}

	/**
	 * Whether a Spanish text has something to translate: words, not only markup, block
	 * comments or shortcodes (the bag and the checkout are blocks without text).
	 *
	 * @param string $text Text.
	 */
	public static function has_text( string $text ): bool {
		return '' !== trim( wp_strip_all_tags( strip_shortcodes( $text ) ) );
	}

	/**
	 * A stored value as text: a list as JSON.
	 *
	 * @param mixed $value Meta value.
	 */
	private static function scalar( $value ): string {
		if ( is_array( $value ) ) {
			return $value ? (string) wp_json_encode( $value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) : '';
		}
		return is_scalar( $value ) ? (string) $value : '';
	}

	/**
	 * Own attributes of a product (not of a taxonomy): key → {name, values}.
	 *
	 * @param int $id Product id.
	 * @return array<string, array{name: string, values: string[]}>
	 */
	public static function attributes( int $id ): array {
		$out = array();
		$raw = get_post_meta( $id, '_product_attributes', true );
		foreach ( is_array( $raw ) ? $raw : array() as $key => $attribute ) {
			if ( ! is_array( $attribute ) || ! empty( $attribute['is_taxonomy'] ) ) {
				continue;
			}
			$values = array_values( array_filter( array_map( 'trim', explode( '|', (string) ( $attribute['value'] ?? '' ) ) ), static fn( string $value ): bool => '' !== $value ) );
			$name   = trim( (string) ( $attribute['name'] ?? '' ) );
			if ( '' !== $name || $values ) {
				$out[ (string) $key ] = array(
					'name'   => $name,
					'values' => $values,
				);
			}
		}
		return $out;
	}

	/**
	 * Every field of an object with its Spanish.
	 *
	 * @param string $type «post» or «term».
	 * @param int    $id   Object id.
	 * @return array<string, string>
	 */
	public static function sources( string $type, int $id ): array {
		$out = array();
		foreach ( self::of( $type, (string) self::subtype( $type, $id ) ) as $name => $field ) {
			$out[ $name ] = self::source( $type, $id, $field );
		}
		return $out;
	}

	/**
	 * Post type or taxonomy of an object, null when it does not exist.
	 *
	 * @param string $type «post» or «term».
	 * @param int    $id   Object id.
	 */
	public static function subtype( string $type, int $id ): ?string {
		if ( 'post' === $type ) {
			$post_type = get_post_type( $id );
			return false === $post_type ? null : $post_type;
		}
		$term = Front::raw( static fn() => get_term( $id ) );
		return $term instanceof \WP_Term ? $term->taxonomy : null;
	}

	/**
	 * Forgets the built list (tests; a module switched on in the same request).
	 */
	public static function reset(): void {
		self::$fields = null;
		self::$meta   = null;
	}

	/**
	 * A definition with every key.
	 *
	 * @param array<string, mixed> $field Definition.
	 * @param string               $name  Field.
	 * @return array{label: string, source: string, key: string, format: string, required: bool, fallback: string, max: int}
	 */
	private static function normalize( array $field, string $name ): array {
		$format = (string) ( $field['format'] ?? 'text' );
		return array(
			'label'    => (string) ( $field['label'] ?? $name ),
			'source'   => (string) $field['source'],
			'key'      => (string) $field['key'],
			'format'   => in_array( $format, array( 'text', 'html', 'blocks', 'json' ), true ) ? $format : 'text',
			'required' => (bool) ( $field['required'] ?? true ),
			'fallback' => 'empty' === ( $field['fallback'] ?? '' ) ? 'empty' : 'source',
			'max'      => max( 0, (int) ( $field['max'] ?? 0 ) ),
		);
	}

	/**
	 * Fields of WordPress, WooCommerce and Rank Math.
	 *
	 * @return array<string, array<string, array<string, mixed>>>
	 */
	private static function defaults(): array {
		$slug     = array(
			'label'    => __( 'Slug', 'lachinata-core' ),
			'source'   => self::POST,
			'key'      => 'post_name',
			'required' => false,
		);
		$seo      = array(
			'seo_title'       => array(
				'label'    => __( 'Título SEO', 'lachinata-core' ),
				'source'   => self::META,
				'key'      => 'rank_math_title',
				'required' => false,
				'fallback' => 'empty',
				'max'      => 60,
			),
			'seo_description' => array(
				'label'    => __( 'Descripción SEO', 'lachinata-core' ),
				'source'   => self::META,
				'key'      => 'rank_math_description',
				'required' => false,
				'fallback' => 'empty',
				'max'      => 155,
			),
			'og_title'        => array(
				'label'    => __( 'Título para redes', 'lachinata-core' ),
				'source'   => self::META,
				'key'      => 'rank_math_facebook_title',
				'required' => false,
				'fallback' => 'empty',
			),
			'og_description'  => array(
				'label'    => __( 'Descripción para redes', 'lachinata-core' ),
				'source'   => self::META,
				'key'      => 'rank_math_facebook_description',
				'required' => false,
				'fallback' => 'empty',
			),
		);
		$term     = array(
			'name'        => array(
				'label'  => __( 'Nombre', 'lachinata-core' ),
				'source' => self::TERM,
				'key'    => 'name',
			),
			'description' => array(
				'label'  => __( 'Descripción', 'lachinata-core' ),
				'source' => self::TERM,
				'key'    => 'description',
				'format' => 'html',
			),
			'slug'        => array(
				'label'    => __( 'Slug', 'lachinata-core' ),
				'source'   => self::TERM,
				'key'      => 'slug',
				'required' => false,
			),
		);
		$term_seo = array(
			'seo_title'       => array_merge( $seo['seo_title'], array( 'source' => self::TERM_META ) ),
			'seo_description' => array_merge( $seo['seo_description'], array( 'source' => self::TERM_META ) ),
		);

		$out = array(
			'post:product'           => array_merge(
				array(
					'name'              => array(
						'label'  => __( 'Nombre', 'lachinata-core' ),
						'source' => self::POST,
						'key'    => 'post_title',
					),
					'short_description' => array(
						'label'  => __( 'Descripción corta', 'lachinata-core' ),
						'source' => self::POST,
						'key'    => 'post_excerpt',
						'format' => 'html',
					),
					'description'       => array(
						'label'  => __( 'Descripción', 'lachinata-core' ),
						'source' => self::POST,
						'key'    => 'post_content',
						'format' => 'html',
					),
					'slug'              => $slug,
					'attributes'        => array(
						'label'    => __( 'Atributos propios', 'lachinata-core' ),
						'source'   => self::ATTRIBUTES,
						'key'      => '_product_attributes',
						'format'   => 'json',
						'required' => false,
					),
				),
				$seo
			),
			'post:product_variation' => array(
				'description' => array(
					'label'  => __( 'Descripción de la variación', 'lachinata-core' ),
					'source' => self::META,
					'key'    => '_variation_description',
					'format' => 'html',
				),
			),
			'post:page'              => array_merge(
				array(
					'title'   => array(
						'label'  => __( 'Título', 'lachinata-core' ),
						'source' => self::POST,
						'key'    => 'post_title',
					),
					'content' => array(
						'label'  => __( 'Contenido', 'lachinata-core' ),
						'source' => self::POST,
						'key'    => 'post_content',
						'format' => 'blocks',
					),
					'slug'    => $slug,
				),
				$seo
			),
			'post:post'              => array_merge(
				array(
					'title'   => array(
						'label'  => __( 'Título', 'lachinata-core' ),
						'source' => self::POST,
						'key'    => 'post_title',
					),
					'excerpt' => array(
						'label'  => __( 'Entradilla', 'lachinata-core' ),
						'source' => self::POST,
						'key'    => 'post_excerpt',
					),
					'content' => array(
						'label'  => __( 'Contenido', 'lachinata-core' ),
						'source' => self::POST,
						'key'    => 'post_content',
						'format' => 'blocks',
					),
					'slug'    => $slug,
				),
				$seo
			),
			'post:attachment'        => array(
				'alt' => array(
					'label'    => __( 'Texto alternativo', 'lachinata-core' ),
					'source'   => self::META,
					'key'      => '_wp_attachment_image_alt',
					'required' => false,
				),
			),
			'post:nav_menu_item'     => array(
				'title' => array(
					'label'    => __( 'Etiqueta', 'lachinata-core' ),
					'source'   => self::POST,
					'key'      => 'post_title',
					'required' => false,
				),
			),
			'term:product_cat'       => array_merge( $term, $term_seo ),
			'term:product_tag'       => array_merge( $term, $term_seo ),
			'term:category'          => array_merge( $term, $term_seo ),
		);
		if ( function_exists( 'wc_get_attribute_taxonomy_names' ) ) {
			foreach ( wc_get_attribute_taxonomy_names() as $taxonomy ) {
				$out[ 'term:' . $taxonomy ] = array(
					'name' => $term['name'],
					'slug' => $term['slug'],
				);
			}
		}
		return $out;
	}
}
