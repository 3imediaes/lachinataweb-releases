<?php
/**
 * Glossary of each language.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

defined( 'ABSPATH' ) || exit;

/**
 * Terms with a fixed translation («AOVE» → «EVOO») and terms that are never translated
 * (brand, ranges, designations of origin, names of wines, wineries and grapes). It goes in
 * the settings of the module, so it travels in the JSON export. The proposals (from the
 * editor or from TranslatePress) wait apart until someone accepts them.
 */
final class Glossary {

	/**
	 * Option with the proposals (not exported: they are pending work, not configuration).
	 */
	public const PROPOSALS = 'lachinata_translate_glossary_proposals';

	/**
	 * Terms of a language: rows {term, translation, keep}.
	 *
	 * @param string $language Locale.
	 * @return array<int, array{term: string, translation: string, keep: bool}>
	 */
	public static function terms( string $language ): array {
		$out = array();
		foreach ( self::clean( TranslateModule::setting( 'glossary' ) ) as $row ) {
			if ( '' === $row['language'] || $row['language'] === $language ) {
				$out[] = array(
					'term'        => $row['term'],
					'translation' => $row['keep'] ? $row['term'] : $row['translation'],
					'keep'        => $row['keep'],
				);
			}
		}
		return $out;
	}

	/**
	 * Valid rows: a term, and a translation unless it is kept; the language empty for
	 * «no traducir» in every language.
	 *
	 * @param mixed $rows Rows.
	 * @return array<int, array{language: string, term: string, translation: string, keep: bool}>
	 */
	public static function clean( $rows ): array {
		$out  = array();
		$seen = array();
		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$term        = trim( sanitize_text_field( (string) ( $row['term'] ?? '' ) ) );
			$translation = trim( sanitize_text_field( (string) ( $row['translation'] ?? '' ) ) );
			$keep        = ! empty( $row['keep'] ) || '' === $translation;
			$language    = (string) ( $row['language'] ?? '' );
			$language    = preg_match( '/^[a-z]{2,3}(_[A-Z]{2})?$/', $language ) ? $language : '';
			$key         = $language . '|' . mb_strtolower( $term );
			if ( '' === $term || isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;
			$out[]        = array(
				'language'    => $language,
				'term'        => $term,
				'translation' => $keep ? '' : $translation,
				'keep'        => $keep,
			);
		}
		return $out;
	}

	/**
	 * Terms of a language that appear in a text (whole words; ignoring case, except the «no
	 * traducir» ones, which are names: «La Provincia» is a wine, «la provincia» is not).
	 *
	 * @param string $text     Spanish.
	 * @param string $language Locale.
	 * @return array<int, array{term: string, translation: string, keep: bool}>
	 */
	public static function in( string $text, string $language ): array {
		$plain = wp_strip_all_tags( $text );
		return array_values( array_filter( self::terms( $language ), static fn( array $row ): bool => self::has( $plain, $row['term'], $row['keep'] ) ) );
	}

	/**
	 * Whether a text has a term as a whole word (ignoring case unless asked).
	 *
	 * @param string $text Text.
	 * @param string $term Term.
	 * @param bool   $exact Same case.
	 */
	public static function has( string $text, string $term, bool $exact = false ): bool {
		return '' !== $term && 1 === preg_match( '/(?<![\p{L}\p{N}])' . preg_quote( $term, '/' ) . '(?![\p{L}\p{N}])/u' . ( $exact ? '' : 'i' ), $text );
	}

	/**
	 * Proposes a term (from the editor, or from TranslatePress).
	 *
	 * @param string $language    Locale.
	 * @param string $term        Spanish.
	 * @param string $translation Translation ('' to keep it).
	 * @param string $from        Where it comes from.
	 */
	public static function propose( string $language, string $term, string $translation, string $from ): void {
		$term = trim( sanitize_text_field( $term ) );
		if ( '' === $term ) {
			return;
		}
		$all = self::proposals();
		$all[ $language . '|' . mb_strtolower( $term ) ] = array(
			'language'    => $language,
			'term'        => $term,
			'translation' => trim( sanitize_text_field( $translation ) ),
			'from'        => sanitize_text_field( $from ),
		);
		update_option( self::PROPOSALS, $all, false );
	}

	/**
	 * Proposals waiting, by key.
	 *
	 * @return array<string, array{language: string, term: string, translation: string, from: string}>
	 */
	public static function proposals(): array {
		$all = get_option( self::PROPOSALS, array() );
		return is_array( $all ) ? $all : array();
	}

	/**
	 * Accepts or discards a proposal.
	 *
	 * @param string $key    Key of the proposal.
	 * @param bool   $accept Whether it goes to the glossary.
	 */
	public static function decide( string $key, bool $accept ): void {
		$all = self::proposals();
		if ( ! isset( $all[ $key ] ) ) {
			return;
		}
		if ( $accept ) {
			$rows   = self::clean( TranslateModule::setting( 'glossary' ) );
			$rows[] = array(
				'language'    => $all[ $key ]['language'],
				'term'        => $all[ $key ]['term'],
				'translation' => $all[ $key ]['translation'],
				'keep'        => '' === $all[ $key ]['translation'],
			);
			self::save( $rows );
		}
		unset( $all[ $key ] );
		update_option( self::PROPOSALS, $all, false );
	}

	/**
	 * Saves the glossary.
	 *
	 * @param array<int, array<string, mixed>> $rows Rows.
	 */
	public static function save( array $rows ): void {
		$module = TranslateModule::instance();
		if ( null !== $module ) {
			\LaChinata\Core\Settings::set( $module, 'glossary', self::clean( $rows ) );
		}
	}

	/**
	 * Rows from a CSV (language, term, translation; a translation empty keeps the term).
	 *
	 * @param string $csv CSV.
	 * @return array<int, array{language: string, term: string, translation: string, keep: bool}>
	 */
	public static function from_csv( string $csv ): array {
		$rows  = array();
		$lines = preg_split( '/\r?\n/', trim( $csv ) );
		$lines = false === $lines ? array() : $lines;
		foreach ( $lines as $index => $line ) {
			$cells = str_getcsv( $line, ',', '"', '' );
			if ( 0 === $index && in_array( strtolower( (string) ( $cells[0] ?? '' ) ), array( 'idioma', 'language' ), true ) ) {
				continue;
			}
			$rows[] = array(
				'language'    => trim( (string) ( $cells[0] ?? '' ) ),
				'term'        => (string) ( $cells[1] ?? '' ),
				'translation' => (string) ( $cells[2] ?? '' ),
			);
		}
		return self::clean( $rows );
	}

	/**
	 * The glossary as CSV.
	 *
	 * @param array<int, array{language: string, term: string, translation: string, keep: bool}>|null $rows Rows (the saved ones by default).
	 */
	public static function to_csv( ?array $rows = null ): string {
		$rows   = $rows ?? self::clean( TranslateModule::setting( 'glossary' ) );
		$handle = fopen( 'php://temp', 'r+' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- In-memory buffer.
		if ( false === $handle ) {
			return '';
		}
		fputcsv( $handle, array( 'idioma', 'termino', 'traduccion' ), ',', '"', '' );
		foreach ( $rows as $row ) {
			fputcsv( $handle, array( $row['language'], $row['term'], $row['translation'] ), ',', '"', '' );
		}
		rewind( $handle );
		$csv = (string) stream_get_contents( $handle );
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- In-memory buffer.
		return $csv;
	}
}
