<?php
/**
 * Proposal of the initial glossary.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

use LaChinata\Core\Company;

defined( 'ABSPATH' ) || exit;

/**
 * Reads the catalogue and proposes the glossary: the brand (trade name, brands of
 * WooCommerce and «oleoteca», 07), the designations of origin written in names and descriptions, and, from the
 * wines, their names and the winery, brand, D.O. and grapes of their technical sheet
 * («La bodega: …», «D.O.CA: …», «Variedad: 78% Tempranillo, …»), all «no traducir». Also the
 * fixed terms of 07 for the languages of the shop. Nothing is saved: the list is reviewed
 * and approved by marketing before it is imported.
 */
final class GlossarySuggest {

	/**
	 * Words of the brand of 07, never translated.
	 */
	private const KEEP = array( 'Oleoteca', 'Oleotecas' );

	/**
	 * Fixed translations of 07 by language code.
	 */
	private const FIXED = array(
		'en' => array( 'AOVE' => 'EVOO' ),
		'de' => array( 'AOVE' => 'natives Olivenöl extra' ),
		'fr' => array( 'AOVE' => "huile d'olive vierge extra" ),
	);

	/**
	 * Rows of the proposal: {language, term, translation, reason}.
	 *
	 * @param string $wine_category Slug of the category of the wines ('' none).
	 * @return array<int, array{language: string, term: string, translation: string, reason: string}>
	 */
	public static function rows( string $wine_category = '' ): array {
		$rows = array();
		$add  = static function ( string $term, string $reason, string $language = '', string $translation = '' ) use ( &$rows ): void {
			$term = trim( (string) preg_replace( '/\s+/u', ' ', $term ), " \t.,;:" );
			if ( '' === $term || mb_strlen( $term ) < 2 || mb_strlen( $term ) > 80 ) {
				return;
			}
			$key = $language . '|' . mb_strtolower( $term );
			if ( ! isset( $rows[ $key ] ) ) {
				$rows[ $key ] = array(
					'language'    => $language,
					'term'        => $term,
					'translation' => $translation,
					'reason'      => $reason,
				);
			}
		};

		$add( Company::trade_name(), __( 'Marca', 'lachinata-core' ) );
		if ( taxonomy_exists( 'product_brand' ) ) {
			$brands = get_terms(
				array(
					'taxonomy'   => 'product_brand',
					'hide_empty' => false,
					'fields'     => 'names',
				)
			);
			foreach ( is_array( $brands ) ? $brands : array() as $brand ) {
				$add( (string) $brand, __( 'Marca (WooCommerce)', 'lachinata-core' ) );
			}
		}
		foreach ( self::KEEP as $term ) {
			$add( $term, __( 'Palabra de marca (07)', 'lachinata-core' ) );
		}
		foreach ( array_keys( Config::languages() ) as $language ) {
			foreach ( self::FIXED[ strtolower( (string) strtok( $language, '_' ) ) ] ?? array() as $term => $translation ) {
				$add( $term, __( 'Traducción fija (07)', 'lachinata-core' ), $language, $translation );
			}
		}

		$wines = array();
		if ( '' !== $wine_category ) {
			$wines = get_posts(
				array(
					'post_type'      => 'product',
					'post_status'    => 'publish',
					'posts_per_page' => -1,
					'fields'         => 'ids',
					'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- A command.
						array(
							'taxonomy'         => 'product_cat',
							'field'            => 'slug',
							'terms'            => $wine_category,
							'include_children' => true,
						),
					),
				)
			);
		}
		foreach ( $wines as $id ) {
			$sheet = self::sheet( (string) get_post_field( 'post_content', (int) $id, 'raw' ) );
			if ( ! self::is_wine( $sheet ) ) {
				continue;
			}
			$add( (string) get_the_title( (int) $id ), __( 'Vino', 'lachinata-core' ) );
			foreach ( $sheet as $label => $value ) {
				if ( preg_match( '/bodega/iu', $label ) ) {
					$add( $value, __( 'Bodega', 'lachinata-core' ) );
				} elseif ( preg_match( '/^marca$/iu', $label ) ) {
					$add( $value, __( 'Vino (marca)', 'lachinata-core' ) );
				} elseif ( preg_match( '/^(d\.?\s?o\.?\s?(ca|p)?\.?|denominaci[oó]n|i\.?g\.?p\.?|vino de la tierra)/iu', $label ) ) {
					$add( self::origin_name( $value ), __( 'D.O. de vino', 'lachinata-core' ) );
				} elseif ( preg_match( '/^(variedad|variedades|uvas?)$/iu', $label ) ) {
					foreach ( self::grapes( $value ) as $grape ) {
						$add( $grape, __( 'Uva', 'lachinata-core' ) );
					}
				}
			}
		}

		$all = get_posts(
			array(
				'post_type'      => 'product',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'fields'         => 'ids',
			)
		);
		foreach ( $all as $id ) {
			$text = get_the_title( (int) $id ) . "\n" . wp_strip_all_tags( (string) get_post_field( 'post_content', (int) $id, 'raw' ) );
			foreach ( self::origins( $text ) as $origin ) {
				$add( $origin, __( 'Denominación de origen', 'lachinata-core' ) );
			}
		}
		return array_values( $rows );
	}

	/**
	 * The technical sheet of a description: label → value («La bodega» → «José Gil»).
	 *
	 * @param string $html Description.
	 * @return array<string, string>
	 */
	public static function sheet( string $html ): array {
		$text = wp_strip_all_tags( str_replace( array( '<br>', '<br/>', '<br />', '</p>', '</li>' ), "\n", $html ) );
		preg_match_all( '/^\s*([\p{L}][\p{L}\. ]{0,30}?)\s*:\s*(.+?)\s*$/mu', $text, $matches, PREG_SET_ORDER );
		$out = array();
		foreach ( $matches as $match ) {
			$label = trim( $match[1] );
			if ( ! isset( $out[ $label ] ) ) {
				$out[ $label ] = trim( html_entity_decode( $match[2], ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
			}
		}
		return $out;
	}

	/**
	 * Whether a technical sheet is of a wine (it has a variety or a D.O.), not an accessory.
	 *
	 * @param array<string, string> $sheet Sheet.
	 */
	private static function is_wine( array $sheet ): bool {
		foreach ( array_keys( $sheet ) as $label ) {
			if ( preg_match( '/^(variedad|variedades|uvas?|d\.?\s?o)/iu', $label ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Grapes of «78% Tempranillo, 20% Garnacha Tinta y 2% Viura».
	 *
	 * @param string $value Variety.
	 * @return string[]
	 */
	public static function grapes( string $value ): array {
		$parts = preg_split( '/\s*(?:,|;|\/|\+|\by\b|\be\b)\s*/u', $value );
		$parts = false === $parts ? array() : $parts;
		$out   = array();
		foreach ( $parts as $part ) {
			$grape = trim( (string) preg_replace( '/^\d+(?:[.,]\d+)?\s*%\s*(de\s+)?|\(.*?\)|\d+(?:[.,]\d+)?\s*%/u', '', $part ) );
			if ( '' !== $grape && ! preg_match( '/\d/', $grape ) ) {
				$out[] = $grape;
			}
		}
		return $out;
	}

	/**
	 * Designations of origin written in a text («D.O.P. Pimentón de la Vera», «Denominación
	 * de Origen Protegida Gata-Hurdes»).
	 *
	 * @param string $text Text.
	 * @return string[]
	 */
	public static function origins( string $text ): array {
		preg_match_all( '/(?<![\p{L}])(?:D\.[ ]?O\.[ ]?P\.?|D\.[ ]?O\.?[ ]?Ca\.?|D\.[ ]?O\.?|DOP|IGP|I\.G\.P\.|Denominaci[oó]n de Origen(?: Protegida| Calificada)?)[ \t]*:?[ \t]+«?"?((?:[A-ZÁÉÍÓÚÑ][\p{L}\-]{2,})(?:[ \t]+(?:de|del|de la|de las|de los|y)?[ \t]*[A-ZÁÉÍÓÚÑ][\p{L}\-]{2,}){0,4})/u', $text, $matches );
		$skip = array( 'protegida', 'calificada', 'origen', 'tipo', 'botella' );
		return array_values( array_unique( array_filter( array_map( 'trim', $matches[1] ), static fn( string $name ): bool => ! in_array( mb_strtolower( (string) strtok( $name, ' ' ) ), $skip, true ) ) ) );
	}

	/**
	 * Name of a designation without its prefix nor what follows a dash («D.O.CA. Rioja» →
	 * «Rioja»; «DO Ribera del Duero - Gumiel de Mercado» → «Ribera del Duero»).
	 *
	 * @param string $value Value of the sheet.
	 */
	public static function origin_name( string $value ): string {
		$value = (string) preg_replace( '/^(?:D\.?\s?O\.?\s?(?:Ca|P)?\.?|DOP|IGP|I\.?G\.?P\.?|VT|Ca\.)\s*:?\s*/iu', '', trim( $value ) );
		return trim( (string) preg_replace( '/\s+-\s+.*$/u', '', $value ) );
	}

	/**
	 * The proposal as CSV (language, term, translation, reason).
	 *
	 * @param array<int, array{language: string, term: string, translation: string, reason: string}> $rows Rows.
	 */
	public static function csv( array $rows ): string {
		$handle = fopen( 'php://temp', 'r+' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- In-memory buffer.
		if ( false === $handle ) {
			return '';
		}
		fputcsv( $handle, array( 'idioma', 'termino', 'traduccion', 'motivo' ), ',', '"', '' );
		foreach ( $rows as $row ) {
			fputcsv( $handle, array( $row['language'], $row['term'], $row['translation'], $row['reason'] ), ',', '"', '' );
		}
		rewind( $handle );
		$csv = (string) stream_get_contents( $handle );
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- In-memory buffer.
		return $csv;
	}
}
