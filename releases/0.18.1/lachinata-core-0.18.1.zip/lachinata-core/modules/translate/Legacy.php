<?php
/**
 * Old addresses in another language.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

use LaChinata\Core\Hooks;
use LaChinata\Core\Redirections;

defined( 'ABSPATH' ) || exit;

/**
 * What answers 404 in a language other than Spanish, by generic rules and in this order
 * (07-traduccion.md, «Migración desde TranslatePress»; nothing tied to the catalogue):
 * 1. A slug that changed (`_wp_old_slug`, as `wp_old_slug_redirect()` does in Spanish): to
 *    the current address of its post.
 * 2. A Spanish address with a rule in the list of redirections of the panel: the same rule
 *    (a 410 stays 410; a 301 goes to its destination in this language).
 * 3. A page of a listing that no longer exists (`/page/26/`): 301 to page 1 of the listing in
 *    this language.
 * 4. Rubbish (`/comment-page-1/`, any query): 410.
 * Anything else stays 404. A post or term goes with 301 to its address in the language when
 * it is translated and with 302 to the Spanish one when not (tomorrow it may be): the
 * destination is worked out on each request, never kept.
 */
final class Legacy {

	/**
	 * Registers the hooks: after the 301/410 of retired entries (`content`, priority 0) and
	 * the 302/301 of `Router::missing()` (1), before `wp_old_slug_redirect()` (10).
	 */
	public static function boot(): void {
		Hooks::add_action( 'template_redirect', array( self::class, 'respond' ), 2 );
	}

	/**
	 * Answers a 404 in another language.
	 */
	public static function respond(): void {
		if ( ! is_404() ) {
			return;
		}
		$service  = Service::instance();
		$language = $service->current();
		$source   = $service->source_url();
		if ( Config::default_language() === $language || '' === $source ) {
			return;
		}
		$target = self::target( $source, $language );
		if ( null === $target ) {
			return;
		}
		if ( 410 === $target['code'] ) {
			global $wp_query;
			$wp_query->set_404();
			status_header( 410 );
			nocache_headers();
			return;
		}
		wp_safe_redirect( $target['url'], $target['code'], 'La Chinata' );
		exit;
	}

	/**
	 * Where a Spanish address that answers 404 goes in a language: {url, code}, or null (404).
	 *
	 * @param string $source   Spanish address of the request, with its query.
	 * @param string $language Locale.
	 * @return array{url: string, code: int}|null
	 */
	public static function target( string $source, string $language ): ?array {
		$path = Redirections::path( $source );
		$post = self::old_slug( $path );
		if ( $post ) {
			return self::to_object( 'post', $post, $language );
		}
		$rule = Redirections::match( $path );
		if ( null !== $rule ) {
			return '' === $rule['url'] ? array(
				'url'  => '',
				'code' => 410,
			) : self::to_url( $rule['url'], $language );
		}
		if ( preg_match( '#^(.*?)/?page/\d+$#', $path, $match ) ) {
			return array(
				'url'  => Service::instance()->url( home_url( '' === $match[1] ? '/' : '/' . $match[1] . '/' ), $language ),
				'code' => 301,
			);
		}
		$query = (string) wp_parse_url( $source, PHP_URL_QUERY );
		if ( '' !== $query || preg_match( '#(^|/)comment-page-\d+$#', $path ) ) {
			return array(
				'url'  => '',
				'code' => 410,
			);
		}
		return null;
	}

	/**
	 * The published post whose old slug is the last segment of a path (without `.html`).
	 *
	 * @param string $path Path without the slashes at the ends.
	 */
	public static function old_slug( string $path ): int {
		$segments = explode( '/', $path );
		$stem     = sanitize_title( (string) preg_replace( '/\.html?$/i', '', (string) end( $segments ) ) );
		if ( '' === $stem ) {
			return 0;
		}
		$ids = get_posts(
			array(
				'post_type'        => array_values( get_post_types( array( 'public' => true ) ) ),
				'post_status'      => 'publish',
				'posts_per_page'   => 1,
				'fields'           => 'ids',
				'orderby'          => 'modified',
				'order'            => 'DESC',
				'suppress_filters' => true,
				'meta_query'       => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Only on a 404 in another language.
					array(
						'key'   => '_wp_old_slug',
						'value' => $stem,
					),
				),
			)
		);
		return $ids ? (int) $ids[0] : 0;
	}

	/**
	 * A post or term in a language: 301 when it is translated, 302 to the Spanish one when not.
	 *
	 * @param string $type     post or term.
	 * @param int    $id       Id.
	 * @param string $language Locale.
	 * @return array{url: string, code: int}|null
	 */
	private static function to_object( string $type, int $id, string $language ): ?array {
		$service    = Service::instance();
		$translated = Availability::is( $type, $id, $language );
		$wanted     = $translated ? $language : Config::default_language();
		$url        = 'post' === $type ? $service->post_url( $id, $wanted ) : $service->term_url( $id, $wanted );
		return '' === $url ? null : array(
			'url'  => $url,
			'code' => $translated ? 301 : 302,
		);
	}

	/**
	 * Any address of the site in a language: its post or term when it is one, otherwise the
	 * address with the prefix (301).
	 *
	 * @param string $url      Destination of a rule.
	 * @param string $language Locale.
	 * @return array{url: string, code: int}|null
	 */
	private static function to_url( string $url, string $language ): ?array {
		$object = Service::object( $url );
		if ( null !== $object ) {
			return self::to_object( $object[0], $object[1], $language );
		}
		return array(
			'url'  => Service::instance()->url( $url, $language ),
			'code' => 301,
		);
	}
}
