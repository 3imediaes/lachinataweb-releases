<?php
/**
 * Legal pages in other languages.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * A translated legal page (those of «Datos de la empresa» and the terms of WooCommerce)
 * ends with a line that says the Spanish prevails, configurable for each language and on by
 * default (30/10). It is added when the page is shown, never stored: it does not change the
 * translation nor its controls. Their translations never publish themselves (`Translator`).
 */
final class Legal {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'the_content', array( self::class, 'content' ), 30 );
	}

	/**
	 * The line at the end of a legal page in another language.
	 *
	 * @param mixed $content Content.
	 * @return mixed
	 */
	public static function content( $content ) {
		if ( ! is_string( $content ) || ! in_the_loop() || ! is_main_query() || ! is_singular( 'page' ) ) {
			return $content;
		}
		return self::append( $content, (int) get_the_ID(), Service::instance()->current() );
	}

	/**
	 * Adds the line of a language to the content of a legal page.
	 *
	 * @param string $content  Content.
	 * @param int    $page_id  Page id.
	 * @param string $language Locale.
	 */
	public static function append( string $content, int $page_id, string $language ): string {
		if ( Config::default_language() === $language || ! isset( Config::languages()[ $language ] ) || ! Translator::legal( 'post', $page_id ) ) {
			return $content;
		}
		$rules = Prompt::instructions( $language );
		if ( ! $rules['legal_on'] || '' === $rules['legal_line'] ) {
			return $content;
		}
		return $content . "\n" . '<p class="lc-legal-note"><em>' . esc_html( $rules['legal_line'] ) . '</em></p>';
	}
}
