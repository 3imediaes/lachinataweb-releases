<?php
/**
 * Translation memory.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * Paragraphs already translated, reused before asking Claude. Only exact matches, after
 * normalising spaces and markup (07, decided on 30/10): nothing approximate. What a person
 * corrected wins over everything else and is never replaced by a translation of Claude.
 */
final class Memory {

	/**
	 * Table name, without the prefix.
	 */
	public const TABLE = 'lc_translate_memory';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'lachinata/translate/edited', array( self::class, 'edited' ), 10, 2 );
	}

	/**
	 * Full table name.
	 */
	public static function table(): string {
		global $wpdb;
		return $wpdb->prefix . self::TABLE;
	}

	/**
	 * Creates the table (migration 2; idempotent).
	 */
	public static function install(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table   = self::table();
		$charset = $wpdb->get_charset_collate();
		dbDelta(
			"CREATE TABLE {$table} (
				hash char(40) NOT NULL,
				language varchar(12) NOT NULL,
				text longtext NOT NULL,
				origin varchar(10) NOT NULL DEFAULT 'claude',
				updated_at datetime NOT NULL,
				PRIMARY KEY  (hash,language)
			) {$charset};"
		);
	}

	/**
	 * Paragraphs of a text: blocks of HTML (paragraphs, items, headings, cells, quotes) or
	 * text separated by blank lines. Joining them back with their separators gives the text.
	 *
	 * @param string $text Text.
	 * @return array{0: string[], 1: string[]} Paragraphs and the separators after each one.
	 */
	public static function split( string $text ): array {
		$parts = preg_split( '#((?:(?<=</p>|</li>|</h1>|</h2>|</h3>|</h4>|</h5>|</h6>|</td>|</th>|</blockquote>|-->)\s*)|\n\s*\n)#i', $text, -1, PREG_SPLIT_DELIM_CAPTURE );
		$parts = is_array( $parts ) ? $parts : array( $text );
		$paras = array();
		$seps  = array();
		$count = count( $parts );
		for ( $index = 0; $index < $count; $index += 2 ) {
			$paras[] = (string) $parts[ $index ];
			$seps[]  = (string) ( $parts[ $index + 1 ] ?? '' );
		}
		return array( $paras, $seps );
	}

	/**
	 * A paragraph as it is compared: entities decoded, spaces collapsed, no spaces between
	 * tags and tag names in lower case.
	 *
	 * @param string $paragraph Paragraph.
	 */
	public static function normalize( string $paragraph ): string {
		$text = html_entity_decode( $paragraph, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$text = (string) preg_replace( '/\s+/u', ' ', $text );
		$text = (string) preg_replace( '/>\s+</', '><', $text );
		$text = (string) preg_replace_callback( '#</?[A-Za-z][A-Za-z0-9]*#', static fn( array $m ): string => strtolower( $m[0] ), $text );
		return trim( $text );
	}

	/**
	 * Key of a paragraph.
	 *
	 * @param string $paragraph Paragraph.
	 */
	public static function key( string $paragraph ): string {
		return sha1( self::normalize( $paragraph ) );
	}

	/**
	 * The whole text from memory, or null when a paragraph with words is missing.
	 *
	 * @param string $text     Spanish.
	 * @param string $language Locale.
	 */
	public static function recall( string $text, string $language ): ?string {
		global $wpdb;
		[ $paras, $seps ] = self::split( $text );
		$keys             = array();
		foreach ( $paras as $para ) {
			if ( Fields::has_text( $para ) ) {
				$keys[] = self::key( $para );
			}
		}
		if ( ! $keys ) {
			return null;
		}
		$keys         = array_values( array_unique( $keys ) );
		$placeholders = implode( ',', array_fill( 0, count( $keys ), '%s' ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- placeholders built for the list; own table.
		$found = (array) $wpdb->get_results( $wpdb->prepare( "SELECT hash, text FROM %i WHERE language = %s AND hash IN ({$placeholders})", self::table(), $language, ...$keys ), OBJECT_K );
		$out   = '';
		foreach ( $paras as $index => $para ) {
			if ( Fields::has_text( $para ) ) {
				$key = self::key( $para );
				if ( ! isset( $found[ $key ] ) ) {
					return null;
				}
				$out .= (string) $found[ $key ]->text;
			} else {
				$out .= $para;
			}
			$out .= $seps[ $index ];
		}
		return $out;
	}

	/**
	 * Learns the paragraphs of a translation, when they pair one to one with the Spanish.
	 * A paragraph corrected by a person is only replaced by another person.
	 *
	 * @param string $source      Spanish.
	 * @param string $translation Translation.
	 * @param string $language    Locale.
	 * @param string $origin      «claude» or «person».
	 * @return int Paragraphs learned.
	 */
	public static function learn( string $source, string $translation, string $language, string $origin ): int {
		global $wpdb;
		[ $from ] = self::split( $source );
		[ $to ]   = self::split( $translation );
		if ( count( $from ) !== count( $to ) ) {
			return 0;
		}
		$learned = 0;
		$now     = current_time( 'mysql', true );
		foreach ( $from as $index => $para ) {
			if ( ! Fields::has_text( $para ) || ! Fields::has_text( $to[ $index ] ) ) {
				continue;
			}
			$key = self::key( $para );
			if ( 'person' !== $origin ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table.
				$current = $wpdb->get_var( $wpdb->prepare( 'SELECT origin FROM %i WHERE hash = %s AND language = %s', self::table(), $key, $language ) );
				if ( 'person' === $current ) {
					continue;
				}
			}
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table.
			$wpdb->replace(
				self::table(),
				array(
					'hash'       => $key,
					'language'   => $language,
					'text'       => trim( $to[ $index ] ),
					'origin'     => 'person' === $origin ? 'person' : 'claude',
					'updated_at' => $now,
				)
			);
			++$learned;
		}
		return $learned;
	}

	/**
	 * A person changed translations in the editor: they enter the memory and win.
	 *
	 * @param mixed $type «post» or «term».
	 * @param mixed $id   Object id.
	 */
	public static function edited( $type, $id ): void {
		$type = (string) $type;
		$id   = (int) $id;
		foreach ( array_keys( Config::languages() ) as $language ) {
			$sources = Fields::sources( $type, $id );
			foreach ( Store::get( $type, $id, $language ) as $field => $row ) {
				if ( Store::EDITED === $row['status'] && 'person' === $row['origin'] && 'slug' !== $field && isset( $sources[ $field ] ) ) {
					self::learn( $sources[ $field ], $row['text'], $language, 'person' );
				}
			}
		}
	}

	/**
	 * Paragraphs in memory, by language.
	 *
	 * @return array<string, int>
	 */
	public static function counts(): array {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table, panel.
		$rows = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT language, COUNT(*) AS total FROM %i GROUP BY language', self::table() ), ARRAY_A );
		return array_column( $rows, 'total', 'language' );
	}
}
