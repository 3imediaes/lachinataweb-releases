<?php
/**
 * Texts kept in options.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * Some texts live in options, not in posts or terms: the destinations of `locale`, the home
 * and the PromoBar of `blocks`, the shipping marks and «¿Es para tu empresa?» of `catalog`,
 * the title of the payment methods. Each module declares its options with
 * `lachinata/translate/options` and the paths of the texts inside them; `translate` keeps
 * the translations in its table (kind «option», one object per option) and, in another
 * language, returns the option with the translated texts. The option itself never changes.
 */
final class Options {

	/**
	 * Options being read in Spanish (to skip the filter).
	 *
	 * @var array<string, true>
	 */
	private static array $raw = array();

	/**
	 * Declarations, once built.
	 *
	 * @var array<string, array{label: string, paths: string[], max: int}>|null
	 */
	private static ?array $declared = null;

	/**
	 * Registers the hooks on `init`: the declarations ask for the payment methods of
	 * WooCommerce and translate their labels, which cannot happen earlier.
	 */
	public static function boot(): void {
		Hooks::add_action( 'init', array( self::class, 'register' ), 20 );
	}

	/**
	 * The option in the language of the request, and its changes.
	 */
	public static function register(): void {
		foreach ( array_keys( self::all() ) as $name ) {
			Hooks::add_filter( 'option_' . $name, array( self::class, 'translate' ), 20, 2 );
			Hooks::add_action( 'update_option_' . $name, array( self::class, 'changed' ), 20, 3 );
			Hooks::add_action( 'add_option_' . $name, array( self::class, 'added' ), 20, 2 );
		}
	}

	/**
	 * The declared options: name → {label, paths, max}.
	 *
	 * @return array<string, array{label: string, paths: string[], max: int}>
	 */
	public static function all(): array {
		if ( null === self::$declared && ! did_action( 'init' ) ) {
			return array();
		}
		if ( null === self::$declared ) {
			/**
			 * Options with texts to translate: option name → {label, paths, max}. A path
			 * points to a text inside the option, with `.` between levels and `*` for every
			 * key of a level (`*.label`, `title`); `max` limits the length (0, none).
			 *
			 * @since 0.17.0
			 *
			 * @param array<string, array<string, mixed>> $options The titles and descriptions of the payment methods of WooCommerce.
			 */
			$raw            = (array) apply_filters( 'lachinata/translate/options', self::defaults() );
			self::$declared = array();
			foreach ( $raw as $name => $option ) {
				if ( ! is_string( $name ) || ! preg_match( '/^[a-z0-9_-]+$/i', $name ) || ! is_array( $option ) ) {
					continue;
				}
				$paths = array_values( array_filter( array_map( 'strval', (array) ( $option['paths'] ?? array() ) ), static fn( string $path ): bool => '' !== $path ) );
				if ( $paths ) {
					self::$declared[ $name ] = array(
						'label' => (string) ( $option['label'] ?? $name ),
						'paths' => $paths,
						'max'   => max( 0, (int) ( $option['max'] ?? 0 ) ),
					);
				}
			}
		}
		return self::$declared;
	}

	/**
	 * The payment methods of WooCommerce: title and description of each.
	 *
	 * @return array<string, array{label: string, paths: string[], max: int}>
	 */
	private static function defaults(): array {
		$out = array();
		if ( function_exists( 'WC' ) && WC()->payment_gateways() ) {
			foreach ( WC()->payment_gateways()->payment_gateways() as $gateway ) {
				$out[ 'woocommerce_' . $gateway->id . '_settings' ] = array(
					/* translators: %s: payment method. */
					'label' => sprintf( __( 'Pago: %s', 'lachinata-core' ), wp_strip_all_tags( (string) $gateway->get_method_title() ) ),
					'paths' => array( 'title', 'description', 'instructions' ),
					'max'   => 0,
				);
			}
		}
		return $out;
	}

	/**
	 * Object id of an option in the table.
	 *
	 * @param string $name Option name.
	 */
	public static function id( string $name ): int {
		return (int) sprintf( '%u', crc32( $name ) );
	}

	/**
	 * Option name of an object id, or null.
	 *
	 * @param int $id Object id.
	 */
	public static function name( int $id ): ?string {
		foreach ( array_keys( self::all() ) as $name ) {
			if ( self::id( $name ) === $id ) {
				return $name;
			}
		}
		return null;
	}

	/**
	 * The Spanish texts of an option: path → text.
	 *
	 * @param string $name Option name.
	 * @return array<string, string>
	 */
	public static function sources( string $name ): array {
		$declared = self::all()[ $name ] ?? null;
		if ( null === $declared ) {
			return array();
		}
		self::$raw[ $name ] = true;
		$value              = get_option( $name );
		unset( self::$raw[ $name ] );
		$out = array();
		foreach ( $declared['paths'] as $path ) {
			foreach ( self::find( $value, explode( '.', $path ), '' ) as $key => $text ) {
				if ( Fields::has_text( $text ) ) {
					$out[ $key ] = $text;
				}
			}
		}
		return $out;
	}

	/**
	 * Texts at a path: concrete path → text.
	 *
	 * @param mixed    $value Value.
	 * @param string[] $parts Rest of the path.
	 * @param string   $done  Path walked.
	 * @return array<string, string>
	 */
	private static function find( $value, array $parts, string $done ): array {
		if ( ! $parts ) {
			return is_string( $value ) ? array( $done => $value ) : array();
		}
		if ( ! is_array( $value ) ) {
			return array();
		}
		$part = array_shift( $parts );
		$keys = '*' === $part ? array_keys( $value ) : array( $part );
		$out  = array();
		foreach ( $keys as $key ) {
			if ( array_key_exists( $key, $value ) ) {
				$out += self::find( $value[ $key ], $parts, '' === $done ? (string) $key : $done . '.' . $key );
			}
		}
		return $out;
	}

	/**
	 * Writes a text at a concrete path.
	 *
	 * @param mixed    $value Value.
	 * @param string[] $parts Path.
	 * @param string   $text  Text.
	 * @return mixed
	 */
	private static function write( $value, array $parts, string $text ) {
		if ( ! $parts ) {
			return $text;
		}
		if ( ! is_array( $value ) ) {
			return $value;
		}
		$part = array_shift( $parts );
		if ( array_key_exists( $part, $value ) ) {
			$value[ $part ] = self::write( $value[ $part ], $parts, $text );
		}
		return $value;
	}

	/**
	 * In another language, the option with its translated texts.
	 *
	 * @param mixed $value  Option value.
	 * @param mixed $option Option name.
	 * @return mixed
	 */
	public static function translate( $value, $option ) {
		$option   = (string) $option;
		$language = Service::instance()->current();
		if ( isset( self::$raw[ $option ] ) || Config::default_language() === $language || ! isset( Config::languages()[ $language ] ) ) {
			return $value;
		}
		foreach ( Store::get( 'option', self::id( $option ), $language ) as $path => $row ) {
			$value = self::write( $value, explode( '.', (string) $path ), $row['text'] );
		}
		return $value;
	}

	/**
	 * An option was saved: its outdated translations, and the queue.
	 *
	 * @param mixed $old    Old value.
	 * @param mixed $value  New value.
	 * @param mixed $option Option name.
	 */
	public static function changed( $old, $value, $option ): void {
		unset( $old, $value );
		Translator::refresh( 'option', (string) $option, self::id( (string) $option ) );
	}

	/**
	 * An option was added.
	 *
	 * @param mixed $option Option name.
	 * @param mixed $value  Value.
	 */
	public static function added( $option, $value ): void {
		unset( $value );
		Translator::refresh( 'option', (string) $option, self::id( (string) $option ) );
	}

	/**
	 * Forgets the declarations (tests).
	 */
	public static function reset(): void {
		self::$declared = null;
	}
}
