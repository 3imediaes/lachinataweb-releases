<?php
/**
 * The translation queue.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

defined( 'ABSPATH' ) || exit;

/**
 * What waits to be translated, what is being translated in a batch and what waits for a
 * person («Revisar»). The translations themselves only reach `Store` once they pass the
 * controls: a proposal that fails one stays here, never on the page. One open item (pending
 * or in a batch) per object and language; asking again only raises its priority, except for
 * an item of a batch, which stays in it.
 */
final class Queue {

	/**
	 * Table name, without the prefix.
	 */
	public const TABLE = 'lc_translate_queue';

	/**
	 * Waiting to be sent.
	 */
	public const PENDING = 'pending';

	/**
	 * Sent in a batch, waiting for its result.
	 */
	public const BATCHED = 'batched';

	/**
	 * Waiting for a person.
	 */
	public const REVIEW = 'review';

	/**
	 * Done (kept for the month's figures and the sample).
	 */
	public const DONE = 'done';

	/**
	 * Failed with an error of the API (retried by `retry`).
	 */
	public const FAILED = 'failed';

	/**
	 * Priorities: the outdated first, then the changes of the day, then the batches, and last
	 * what passed to «Revisado», waiting for the batch of the early morning.
	 */
	public const OUTDATED = 0;

	/**
	 * A change of the day.
	 */
	public const CHANGE = 1;

	/**
	 * Part of a batch launched from the panel or WP-CLI.
	 */
	public const BATCH = 2;

	/**
	 * Passed to «Revisado»: waits for the daily batch (or for a batch launched by hand).
	 */
	public const REVIEWED = 3;

	/**
	 * Full table name.
	 */
	public static function table(): string {
		global $wpdb;
		return $wpdb->prefix . self::TABLE;
	}

	/**
	 * Creates the table (migration 2; idempotent).
	 */
	public static function install(): void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table   = self::table();
		$charset = $wpdb->get_charset_collate();
		dbDelta(
			"CREATE TABLE {$table} (
				id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
				object_type varchar(8) NOT NULL,
				object_subtype varchar(64) NOT NULL,
				object_id bigint(20) unsigned NOT NULL,
				language varchar(12) NOT NULL,
				priority tinyint(3) unsigned NOT NULL DEFAULT 1,
				status varchar(10) NOT NULL DEFAULT 'pending',
				batch_id varchar(64) NOT NULL DEFAULT '',
				reason text NOT NULL,
				proposal longtext NOT NULL,
				words int(10) unsigned NOT NULL DEFAULT 0,
				cost decimal(12,6) NOT NULL DEFAULT 0,
				created_at datetime NOT NULL,
				updated_at datetime NOT NULL,
				PRIMARY KEY  (id),
				KEY object (object_type,object_id,language),
				KEY next (status,priority,id),
				KEY batch (batch_id)
			) {$charset};"
		);
	}

	/**
	 * Puts an object in the queue for a language, or raises the priority of its open item.
	 *
	 * @param string $type     «post», «term» or «option».
	 * @param string $subtype  Post type, taxonomy or option name.
	 * @param int    $id       Object id.
	 * @param string $language Locale.
	 * @param int    $priority OUTDATED, CHANGE or BATCH.
	 * @return int Item id.
	 */
	public static function add( string $type, string $subtype, int $id, string $language, int $priority = self::CHANGE ): int {
		global $wpdb;
		$open = self::open( $type, $id, $language );
		$now  = current_time( 'mysql', true );
		if ( null !== $open ) {
			// An item waiting for a batch stays there (translated with the Spanish of then); what
			// waits for the daily batch only moves to a batch launched by hand.
			$waiting = (int) $open['priority'] >= self::BATCH;
			if ( self::PENDING === $open['status'] && $priority < (int) $open['priority'] && ( ! $waiting || self::BATCH === $priority ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table.
				$wpdb->update(
					self::table(),
					array(
						'priority'   => $priority,
						'updated_at' => $now,
					),
					array( 'id' => (int) $open['id'] )
				);
			}
			return (int) $open['id'];
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery -- own table.
		$wpdb->insert(
			self::table(),
			array(
				'object_type'    => $type,
				'object_subtype' => $subtype,
				'object_id'      => $id,
				'language'       => $language,
				'priority'       => $priority,
				'status'         => self::PENDING,
				'reason'         => '',
				'proposal'       => '',
				'created_at'     => $now,
				'updated_at'     => $now,
			)
		);
		return (int) $wpdb->insert_id;
	}

	/**
	 * The open item (pending or in a batch) of an object in a language.
	 *
	 * @param string $type     Type.
	 * @param int    $id       Object id.
	 * @param string $language Locale.
	 * @return array<string, mixed>|null
	 */
	public static function open( string $type, int $id, string $language ): ?array {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table, read before writing.
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE object_type = %s AND object_id = %d AND language = %s AND status IN (%s, %s) ORDER BY id DESC LIMIT 1', self::table(), $type, $id, $language, self::PENDING, self::BATCHED ), ARRAY_A );
		return is_array( $row ) ? $row : null;
	}

	/**
	 * One item.
	 *
	 * @param int $item Item id.
	 * @return array<string, mixed>|null
	 */
	public static function get( int $item ): ?array {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table.
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM %i WHERE id = %d', self::table(), $item ), ARRAY_A );
		return is_array( $row ) ? $row : null;
	}

	/**
	 * Pending items, the most urgent first.
	 *
	 * @param int      $limit    How many.
	 * @param int|null $priority Only this priority (null: any).
	 * @param int|null $max      Only up to this priority.
	 * @return array<int, array<string, mixed>>
	 */
	public static function pending( int $limit, ?int $priority = null, ?int $max = null ): array {
		global $wpdb;
		$where = '';
		$args  = array( self::table(), self::PENDING );
		if ( null !== $priority ) {
			$where  = ' AND priority = %d';
			$args[] = $priority;
		} elseif ( null !== $max ) {
			$where  = ' AND priority <= %d';
			$args[] = $max;
		}
		$args[] = max( 1, $limit );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- own table; the condition is fixed text and its value goes in $args.
		return (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM %i WHERE status = %s{$where} ORDER BY priority ASC, id ASC LIMIT %d", ...$args ), ARRAY_A );
	}

	/**
	 * Items in a state.
	 *
	 * @param string $status   State.
	 * @param int    $limit    How many.
	 * @param string $language Only this language ('' any).
	 * @return array<int, array<string, mixed>>
	 */
	public static function in( string $status, int $limit = 100, string $language = '' ): array {
		global $wpdb;
		if ( '' === $language ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table.
			return (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE status = %s ORDER BY updated_at DESC, id DESC LIMIT %d', self::table(), $status, max( 1, $limit ) ), ARRAY_A );
		}
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table.
		return (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE status = %s AND language = %s ORDER BY updated_at DESC, id DESC LIMIT %d', self::table(), $status, $language, max( 1, $limit ) ), ARRAY_A );
	}

	/**
	 * Items of a batch.
	 *
	 * @param string $batch Batch id of the API.
	 * @return array<int, array<string, mixed>>
	 */
	public static function of_batch( string $batch ): array {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table.
		return (array) $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i WHERE batch_id = %s AND status = %s', self::table(), $batch, self::BATCHED ), ARRAY_A );
	}

	/**
	 * Batches still open.
	 *
	 * @return string[]
	 */
	public static function open_batches(): array {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table.
		return array_map( 'strval', (array) $wpdb->get_col( $wpdb->prepare( 'SELECT DISTINCT batch_id FROM %i WHERE status = %s AND batch_id <> \'\'', self::table(), self::BATCHED ) ) );
	}

	/**
	 * Changes an item.
	 *
	 * @param int                  $item Item id.
	 * @param array<string, mixed> $data Columns: status, batch_id, reason, proposal (array), words, cost.
	 */
	public static function update( int $item, array $data ): void {
		global $wpdb;
		if ( isset( $data['proposal'] ) && is_array( $data['proposal'] ) ) {
			$data['proposal'] = (string) wp_json_encode( $data['proposal'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		}
		$data['updated_at'] = current_time( 'mysql', true );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table.
		$wpdb->update( self::table(), $data, array( 'id' => $item ) );
	}

	/**
	 * The proposal of an item: field → {text, reason}.
	 *
	 * @param array<string, mixed> $item Item row.
	 * @return array<string, array{text: string, reason: string, source: string}>
	 */
	public static function proposal( array $item ): array {
		$data = json_decode( (string) ( $item['proposal'] ?? '' ), true );
		$out  = array();
		foreach ( is_array( $data ) ? $data : array() as $field => $row ) {
			if ( is_string( $field ) && is_array( $row ) ) {
				$out[ $field ] = array(
					'text'   => (string) ( $row['text'] ?? '' ),
					'reason' => (string) ( $row['reason'] ?? '' ),
					'source' => (string) ( $row['source'] ?? '' ),
				);
			}
		}
		return $out;
	}

	/**
	 * Items by state and language.
	 *
	 * @return array<string, array<string, int>>
	 */
	public static function counts(): array {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table, panel.
		$rows = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT language, status, COUNT(*) AS total FROM %i GROUP BY language, status', self::table() ), ARRAY_A );
		$out  = array();
		foreach ( $rows as $row ) {
			$out[ (string) $row['language'] ][ (string) $row['status'] ] = (int) $row['total'];
		}
		return $out;
	}

	/**
	 * Words and cost of the items done since a date, by language.
	 *
	 * @param string $since GMT date (Y-m-d H:i:s).
	 * @return array<string, array{words: int, cost: float, items: int}>
	 */
	public static function totals( string $since ): array {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table, panel.
		$rows = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT language, SUM(words) AS words, SUM(cost) AS cost, COUNT(*) AS items FROM %i WHERE updated_at >= %s AND status IN (%s, %s) GROUP BY language', self::table(), $since, self::DONE, self::REVIEW ), ARRAY_A );
		$out  = array();
		foreach ( $rows as $row ) {
			$out[ (string) $row['language'] ] = array(
				'words' => (int) $row['words'],
				'cost'  => (float) $row['cost'],
				'items' => (int) $row['items'],
			);
		}
		return $out;
	}

	/**
	 * Items waiting for the daily batch.
	 */
	public static function reviewed(): int {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table, panel.
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE status = %s AND priority = %d', self::table(), self::PENDING, self::REVIEWED ) );
	}

	/**
	 * What waits for the daily batch passes to a batch.
	 *
	 * @return int Items.
	 */
	public static function release(): int {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table.
		return (int) $wpdb->query( $wpdb->prepare( 'UPDATE %i SET priority = %d, updated_at = %s WHERE status = %s AND priority = %d', self::table(), self::BATCH, current_time( 'mysql', true ), self::PENDING, self::REVIEWED ) );
	}

	/**
	 * Back to pending: failed items and, when asked, those waiting for a person.
	 *
	 * @param bool $review Also those in «Revisar».
	 * @return int Items.
	 */
	public static function retry( bool $review = false ): int {
		global $wpdb;
		$statuses = $review ? array( self::FAILED, self::REVIEW ) : array( self::FAILED );
		$total    = 0;
		foreach ( $statuses as $status ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table.
			$total += (int) $wpdb->query( $wpdb->prepare( 'UPDATE %i SET status = %s, batch_id = \'\', updated_at = %s WHERE status = %s', self::table(), self::PENDING, current_time( 'mysql', true ), $status ) );
		}
		return $total;
	}

	/**
	 * Deletes the items of an object (it was deleted).
	 *
	 * @param string $type Type.
	 * @param int    $id   Object id.
	 */
	public static function forget( string $type, int $id ): void {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table.
		$wpdb->delete(
			self::table(),
			array(
				'object_type' => $type,
				'object_id'   => $id,
			)
		);
	}
}
