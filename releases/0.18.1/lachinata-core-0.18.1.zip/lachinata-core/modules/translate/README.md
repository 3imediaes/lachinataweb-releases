# Módulo `translate`

Sustituye a TranslatePress (`design-system/sistema/07-traduccion.md`). Desde la 0.15.0 (11b): tabla de traducciones, direcciones por idioma, `hreflang`, sitemaps, editor lado a lado, correos en el idioma del pedido y el contrato `Languages` v2. Claude, glosario, memoria, los siete controles, colas, panel y migración desde TranslatePress llegan en la 0.17.0 (11c).

## Qué hace

- **Traducciones como campos de la misma ficha**, nunca copias: un producto es uno solo en todos los idiomas (mismo ID, stock, precio, pedidos y medición). Se guardan en la tabla `{prefijo}lc_translate`: objeto (tipo, subtipo e ID), campo, idioma, texto, huella del español del que sale, estado (`auto`, `edited`, `outdated`), origen (`claude`, `person`, `import`) y fecha. El slug traducido va en la misma tabla, en su columna, con un índice único por idioma.
- **Qué se traduce**: lo declarado en `lachinata/translate/fields`. El módulo trae lo de WordPress, WooCommerce y Rank Math (nombre, descripciones, slug, descripción de cada variación, texto alternativo, etiqueta de los elementos de menú, títulos y descripciones SEO, nombre y descripción de categorías, etiquetas y términos de atributo); cada módulo añade lo suyo (`catalog`, `content`, `oleotecas`). Nunca ingredientes ni valores nutricionales: vendrán de la aplicación de La Chinata, y hasta entonces se ve el español.
- **Una página existe en un idioma solo si está traducida entera**: cada campo obligatorio cuyo español tiene texto, traducido. Si no, no hay dirección en ese idioma: sus enlaces llevan a la española, no sale en `hreflang` ni en el sitemap de ese idioma, y pedirla en `/en/…` lleva a la española con una 302 (con lo que siga: endpoint y parámetros). Las imágenes, los elementos de menú, las variaciones y los términos sin dirección se traducen campo a campo. La home existe siempre (son los bloques de la home).
- **Direcciones**: un subdirectorio por idioma (`/en/`), el español sin prefijo. El idioma lo da la dirección, nunca el navegador ni la IP. La dirección traducida es la española con el slug del objeto traducido y los segmentos que son páginas o términos traducidos (`/tienda/` → `/en/shop/`, `/blog/recetas/x/` → `/en/blog/recipes/y/`); conserva la forma (`.html`). Por dentro, la petición se convierte en la española y la resuelve WordPress (o Permalink Manager); la API REST bajo `/en/wp-json/` conserva sus rutas y responde en inglés. Un objeto pedido con su slug español va a su dirección traducida con una 301. Los endpoints internos de WooCommerce no se traducen.
- **SEO**: `hreflang` entre los idiomas en que existe la página, con `x-default` al español; la canónica de cada idioma es ella misma (WordPress y Rank Math la sacan del enlace permanente, que ya sale traducido); los títulos y descripciones de Rank Math leen el texto traducido; un sitemap por idioma en el índice de Rank Math (`translate-en-sitemap.xml`) o, sin Rank Math, en el de WordPress, solo con lo que existe en ese idioma. `og:locale` y `lang` salen del idioma de la petición.
- **Textos en la página**: títulos, contenido y extractos de las entradas de la consulta (copias: la caché de objetos guarda siempre el español), getters de los productos y variaciones, metadatos declarados, términos, menús y, en correos y en las páginas de pedido recibido y cuenta, los nombres de las líneas del pedido. Las cadenas de interfaz salen de los `.mo` del tema y del plugin (`tools/i18n/`) y de los paquetes de idioma de WordPress y WooCommerce.
- **Editor lado a lado**: en productos, páginas y entradas, una caja «Traducciones» con una pestaña por idioma, el español y la traducción campo a campo, y su estado («Automática», «Editada», «Desfasada: el español cambió», «Sin traducir»); en categorías y términos, debajo del formulario. Cambiar un campo lo deja «Editada» por una persona. Debajo dice si la página existe en ese idioma y, si no, qué falta. No hay edición desde la parte pública. Desde 0.17.0, «Volver a traducir» en cada campo (descarta la traducción y lo pone el primero en la cola) y «Proponer al glosario» en cada idioma.
- **Cuando cambia el español**, la traducción de ese campo pasa a «Desfasada» y sigue publicada hasta que se traduzca de nuevo; una editada conserva su origen «persona» y nunca se pisa. Borrar un producto o un término borra sus traducciones.
- **Correos en el idioma del pedido**: el pedido guarda el idioma en que se hizo (`_lc_translate_language`) y los correos al comprador salen en él (asunto, textos del tema, nombres de los productos y enlaces); los de la tienda, siempre en el idioma del sitio. Las líneas del pedido guardan los nombres en español, que son los que leen Odoo y el panel.
- **WP-CLI**: `wp lachinata translate set|get|import|export|status|refresh`; desde 0.17.0, `run --lang= --type= [--limit=] [--dry-run]`, `tick`, `retry [--review]`, `glossary-suggest [--wine-category=] [--file=]`, `glossary-import <csv>` y `glossary-export`.
- **Traducción con Claude** (0.17.0, `Claude.php`, `Prompt.php`, `Translator.php`):
  - API de Claude por la API HTTP de WordPress (el plugin no lleva librerías de Composer): Messages API para los cambios del día y Message Batches API, a mitad de precio, para las tandas. Reintenta 429, 529 y 5xx con lo que pida `retry-after`; un 401, 402 o 403 para la cola. Modelo de serie `claude-sonnet-5-5`, esfuerzo `medium`, salida JSON con esquema (una clave por campo) y, en las peticiones sueltas, el respaldo del servidor si el modelo rechaza (`fallbacks: "default"`).
  - Una petición por objeto, con todos sus campos: instrucciones de marca del idioma (tono, tratamiento, unidades métricas, cifras intactas, sin añadir afirmaciones), los términos del glosario que aparecen y el contexto (tipo, categoría y nombre del producto).
  - **Clave** cifrada con las claves de `wp-config.php` (`Secret.php`): nunca en la exportación, los registros ni los mensajes de error, y el panel no la vuelve a mostrar. Si no se puede descifrar, aviso «vuelve a pegarla» y la cola parada. En desarrollo, `LACHINATA_DEV_CLAUDE_API_KEY` (solo en sitios `local` o `development`).
  - **Gasto** (`Spend.php`): límite mensual en USD, de serie 0 (la cola no corre). Se controla con el coste real de cada respuesta (los tokens que dice haber usado, al precio de su modelo; los lotes, a mitad). Precios por modelo en el código, corregibles en el panel. El estimado antes de una tanda es solo un aviso. Una tanda se envía hasta donde quepa en lo que queda del límite.
- **Cola** (`Queue.php`, `Runner.php`): tabla propia, un elemento abierto por objeto e idioma. Cada cinco minutos (Action Scheduler) y justo después de un cambio: recoge los lotes terminados, traduce uno a uno lo urgente (primero lo «Desfasado», después los cambios del día) y envía las tandas.
  - Entra lo que pasa a «Revisado» y lo que cambia en algo ya «Revisado» (al momento); términos, menús y textos de ajustes, siempre. Un elemento que ya espera en una tanda se queda en ella.
  - **Tanda diaria:** lo que pasa a «Revisado» es el texto que ya existía, a menudo cientos de golpe, y espera a la tanda de las 4:00 (hora de la tienda). Sale sola si su coste estimado está por debajo del umbral del panel (de serie 5 USD; con 0, siempre a mano); si no, espera a que alguien la lance en «Tandas» («Lanzarla ahora») o con una tanda a mano. Editar algo que espera no lo hace pasar al momento.
  - Un campo corregido por una persona no se vuelve a traducir: si su español cambia, va a «Revisar».
- **Controles** (`Controls.php`): los siete de 07 (cifras, glosario, HTML y bloques con sus enlaces, marcadores, longitud, idioma, sin añadidos de más de un 40 %). Lo que pasa se publica («Automática», origen Claude) y entra en la memoria; lo que falla no se publica y va a «Revisar» con el motivo, con la propuesta al lado del español.
- **Páginas legales** (`Legal.php`): las de «Datos de la empresa» y las condiciones de WooCommerce se traducen pero nunca se publican solas: esperan en «Revisar» a que una persona las apruebe. En otro idioma terminan con una línea configurable por idioma, encendida de serie («In case of discrepancy, the Spanish version prevails.»), que se añade al mostrarlas y no se guarda.
- **Memoria** (`Memory.php`): párrafos ya traducidos, por coincidencia exacta después de normalizar espacios y HTML; nada aproximado. Se usa antes de llamar a la API; lo corregido por una persona (`lachinata/translate/edited`) manda y Claude no lo pisa.
- **Glosario** (`Glossary.php`, `GlossarySuggest.php`): por idioma, términos con traducción fija y «no traducir»; viaja en el JSON. Los de «no traducir» son nombres y se buscan con sus mayúsculas («La Provincia» es un vino; «la provincia de Cáceres», no); los fijos, sin distinguirlas. El control de idioma no cuenta los «no traducir» como español. Propuestas desde el editor («Proponer al glosario»), aparte, hasta que alguien las acepta. `glossary-suggest` propone la lista inicial desde el catálogo (marca, «oleoteca», denominaciones de origen y, con `--wine-category`, vinos, bodegas, D.O. y uvas de la ficha técnica) para revisarla antes de pasarla a marketing.
- **Textos de los ajustes** (`Options.php`): los módulos declaran sus opciones con `lachinata/translate/options` (destinos de `locale`; marcas de envío, venta cruzada y «¿Es para tu empresa?» de `catalog`; de serie, las pasarelas de WooCommerce). En otro idioma la opción sale con los textos traducidos; la opción no cambia.
- **Atributos propios** (`Attributes.php`): los que define el producto (no los de una taxonomía) se traducen como un campo (`attributes`); en otro idioma cambian su nombre y el texto de cada valor donde los enseña WooCommerce y en los formatos de la ficha. El valor que elige la variación sigue en español, así que la bolsa y los pedidos casan.
- **Direcciones antiguas** (`Legacy.php`, 0.17.1): lo que da 404 en otro idioma se resuelve por reglas, sin tablas atadas al catálogo, y en este orden. 1) Un slug cambiado (`_wp_old_slug`, como `wp_old_slug_redirect()` en español) va a la dirección actual de su objeto. 2) Si la dirección en español tiene regla en la lista de redirecciones del panel (la de Rank Math), se aplica la misma: un 410 sigue siendo 410 y una 301 va a su destino en ese idioma. 3) Una página de un listado que ya no existe (`/page/26/`) va con 301 a la página 1 del listado en ese idioma. 4) La basura (`/comment-page-1/`, cualquier parámetro) da 410. Lo demás, 404. Un objeto va con 301 a su dirección en el idioma si está traducido, y con 302 a la española si no; el destino se calcula en cada petición y nunca se guarda.
- **Migración desde TranslatePress** (`TranslatePress.php`, 0.17.1): `wp lachinata translate migrate-tp` propone al glosario las cadenas que una persona corrigió en TranslatePress (cortas, hasta cuatro palabras y sin cifras; las que se quedaron igual, como «no traducir»). Con `--csv` (la lista de Search Console) pide al sitio cada dirección antigua y escribe un informe por clics; con `--missing`, un CSV de los 404 (`url`, `destino_url` vacío) que se puede rellenar y cargar en la lista de redirecciones. No guarda tablas de direcciones, y no escribe encima de un informe o un CSV que ya existe sin `--force`.
- **Panel** (`TranslateTab.php`): idiomas; API de Claude (clave, modelo, esfuerzo, límite, precio); instrucciones de cada idioma; glosario con sus propuestas; tandas (fichas, palabras y coste estimado antes de lanzar; la cola por idioma; reintentar); «Revisar» (publicar, volver a traducir, descartar); muestra semanal de 20 traducciones por idioma; y este mes (fichas, palabras, coste, correcciones, gasto por mes y memoria). Avisa si la cola está parada y de lo que lleva más de 7 días «Desfasado».

## Depende de

- WooCommerce 10.0 o superior.
- Nada de otros módulos. `catalog`, `content` y `oleotecas` declaran sus campos con `lachinata/translate/fields`, y `locale` y `catalog` sus textos de ajustes con `lachinata/translate/options`, si están encendidos.
- Del núcleo: `SourceStatus` (qué está «Revisado»), `Company` (las páginas legales y el nombre comercial para las instrucciones) y, desde 0.17.1, `Redirections` (la lista de redirecciones del panel, de Rank Math).
- Para traducir: una clave de la API de Claude y un límite de gasto mayor que 0. Action Scheduler (de WooCommerce) mueve la cola.
- Paquetes de idioma de WordPress y WooCommerce de cada idioma (Escritorio → Actualizaciones, o `wp language core install en_GB` y `wp language plugin install woocommerce en_GB`): la salud avisa si falta el de WooCommerce. Sin el de WordPress, los correos no cambian de idioma (WordPress solo cambia a idiomas instalados).

## Hooks que escucha

- `lachinata/languages/service`: sirve `Contracts\Languages` (v2).
- `locale` (prioridad 1), `do_parse_request`, `parse_request`, `template_redirect`, `home_url`, `post_link`, `post_type_link`, `page_link`, `term_link`, `post_type_archive_link`: direcciones por idioma.
- `the_posts`, `the_title`, `get_the_excerpt`, `content_pagination`, `get_post_metadata`, `get_term_metadata`, `get_term`, `get_terms`, `woocommerce_product_get_name`, `woocommerce_product_get_short_description`, `woocommerce_product_get_description`, `woocommerce_product_variation_get_name`, `woocommerce_order_item_get_name`, `wp_setup_nav_menu_item`: textos.
- `wp_head` (`hreflang`), `rank_math/sitemap/providers`, `wp_sitemaps_init`, `rank_math/replacements`, `rank_math/frontend/description`.
- `save_post`, `woocommerce_update_product`, `woocommerce_update_product_variation`, `added_post_meta`, `updated_post_meta`, `deleted_post_meta`, `edited_term`, `created_term` (0.17.0), `added_term_meta`, `updated_term_meta`, `deleted_post`, `delete_term`, `shutdown`: el español que cambia.
- `woocommerce_checkout_create_order`, `woocommerce_store_api_checkout_update_order_meta`, `woocommerce_checkout_create_order_line_item`, `woocommerce_email_classes`, `woocommerce_email_recipient_{id}`, `woocommerce_allow_restoring_email_locale`: correos.
- `add_meta_boxes`, `admin_init`, `{taxonomía}_edit_form`, `edited_{taxonomía}`, `admin_head`: editor. `lachinata/core/admin_tabs` y `admin_post_lachinata_translate_settings`: pestaña.
- `lachinata/source_status/changed` (0.17.0): lo que pasa a «Revisado» entra en la cola y espera a la tanda diaria.
- Desde 0.17.0: `action_scheduler_init`, `lachinata_translate_tick` (la cola) y `lachinata_translate_daily` (la tanda diaria), `lachinata/translate/edited` (la memoria), `lachinata/translate/options` y, por cada opción declarada, `option_{opción}`, `update_option_{opción}` y `add_option_{opción}`; `woocommerce_attribute_label`, `woocommerce_variation_option_name` y `woocommerce_attribute` (atributos propios); `the_content` (línea de las páginas legales).
- Desde 0.17.1: `template_redirect` (prioridad 2) para las direcciones antiguas en otro idioma.

## Hooks que emite

- `lachinata/translate/fields` (filtro): campos traducibles por tipo de objeto. Catálogo en `plugin/HOOKS.md`.
- `lachinata/translate/availability_changed` (acción): cambian los idiomas en que existe un objeto.
- `lachinata/translate/edited` (acción): una persona cambió traducciones en el editor.
- `lachinata/translate/options` (filtro, 0.17.0): opciones con textos que traducir.
- `lachinata/translate/retry_wait` (filtro, 0.17.0): espera antes de reintentar una petición a la API.

## Datos que guarda

- Tabla `{prefijo}lc_translate` (migración 1). Desde 0.17.0 (migración 2), la cola `{prefijo}lc_translate_queue` y la memoria `{prefijo}lc_translate_memory`; las traducciones de los textos de ajustes van en `lc_translate` con el tipo `option`.
- `_lc_translate_in` (metadato de entrada y de término, una fila por idioma): idiomas en que existe, recalculado al escribir una traducción o cambiar el español.
- `_lc_translate_language` (metadato de pedido): idioma en que se hizo. Lo lee `tracking`.
- Opciones `lachinata_translate_languages` y `lachinata_translate_only_reviewed`; transitorios `lachinata_translate_slugs_{idioma}`. Desde 0.17.0: `lachinata_translate_model`, `_effort`, `_limit`, `_prices`, `_instructions` y `_glossary` (ajustes), `lachinata_translate_api_key` (la clave cifrada; no se exporta), `lachinata_translate_spend` (gasto por mes) y `lachinata_translate_glossary_proposals` (propuestas; no se exportan).

## REST y API para Odoo

Nada propio. La API REST de WordPress y la Store API responden en el idioma de la dirección (`/en/wp-json/…`). El objeto `lachinata` de los pedidos no cambia; los nombres de las líneas siguen en español.

## Ajustes y exportación

WooCommerce → La Chinata → Traducción: los idiomas (locale, código de la dirección y de `hreflang`, nombre) y «Solo productos, páginas y entradas con el español Revisado» (encendido de serie). Desde 0.17.0, también el modelo, el esfuerzo, el límite de gasto (0 de serie), las correcciones de precio, las instrucciones de cada idioma (tono, tratamiento, línea de las páginas legales) y el glosario. Todo entra en el JSON exportado, salvo la clave de la API, el gasto y las propuestas de glosario. Las traducciones no van en el JSON: se exportan aparte con `wp lachinata translate export --language=en_GB`.

## Qué pasa al apagarlo

La cola se para (lo que espera se queda en la tabla). El contrato `Languages` vuelve a un solo idioma, el del sitio: no hay prefijos, ni `hreflang`, ni sitemaps por idioma, y el selector de `locale` no enseña idiomas. `/en/…` deja de existir. La tabla, los metadatos y los idiomas de los pedidos se conservan; «Borrar datos» borra las tablas (traducciones, cola y memoria) y los metadatos de entradas y términos, nunca los de los pedidos.

## Pruebas

- `plugin/modules/translate/tests/TranslateTest.php`: tabla y slugs únicos, cuándo existe una página, direcciones en los dos sentidos (también la API REST bajo `/en/`), una petición a `/en/` con sus textos y `hreflang`, metadatos y términos, el contrato, el editor, el español que cambia, correos e importación.
- `plugin/modules/translate/tests/ClaudeTest.php` (0.17.0, la API siempre simulada con `pre_http_request`): la clave cifrada, no exportada e ilegible; precios, lotes a mitad, corrección del panel y el límite; los siete controles; la memoria (exacta, persona sobre Claude); traducir al momento con un 529 reintentado; «Revisar» y aprobar; un campo corregido que no se pisa; páginas legales y su línea; una tanda enviada y recogida; una clave no válida que para la cola; textos de ajustes; atributos propios; glosario y su propuesta desde la ficha técnica de los vinos.
- `plugin/modules/translate/tests/LegacyTest.php` (0.17.1): slug cambiado (302 sin inglés, 301 con inglés), regla de la lista del panel, listado paginado, basura y lo que sigue en 404; las cadenas de TranslatePress como propuestas; el informe y el CSV de los 404.
- `theme/tests/WooCommerceStringsTest.php`: los avisos clásicos dicen «bolsa».
- `tests/e2e/translate.spec.mjs` (perfiles `es` y `all`; en `canarias` y `cz`, sin `/en/`): ficha, categoría, página y receta en inglés, lo no traducido al español, sitemap y `llms.txt`, el selector y la cookie `lc_idioma`, un pedido en inglés con su correo; desde 0.17.1, las direcciones antiguas de `/en/` por regla (slug cambiado, regla de Rank Math, listado paginado, basura, sellos y entradas retiradas).
- Traducciones de prueba: `tools/fixtures/traducciones-en.json` (`npm run env:seed`).

## Huecos conocidos

- La migración desde TranslatePress con sus 301, 302 y 410 de `/en/`: 0.17.1.
- La home y la `PromoBar` no son textos de ajustes: son bloques de una página y un menú, y se traducen como tales.
- Textos de la receta fuera del bloque: sin traducir.
- El control de idioma cuenta palabras frecuentes: con menos de 8 palabras no dice nada.
- La memoria solo aprende cuando los párrafos de la traducción casan uno a uno con los del español.
- Un producto con un campo obligatorio nuevo en español (una descripción que antes no tenía) deja de existir en inglés hasta que se traduzca.
