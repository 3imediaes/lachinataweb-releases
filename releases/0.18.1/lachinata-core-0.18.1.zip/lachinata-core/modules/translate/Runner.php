<?php
/**
 * Runs the translation queue.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

use LaChinata\Core\Hooks;
use LaChinata\Core\SourceStatus;

defined( 'ABSPATH' ) || exit;

/**
 * Every five minutes (and right after a change), with Action Scheduler: collects the batches
 * that ended, translates the changes of the day one by one (the outdated first) and sends the
 * batches launched from the panel to the Batches API, as many as fit in what is left of the
 * monthly limit. Every day at 04:00 (time of the shop), what passed to «Revisado» becomes a
 * batch if its estimate is below the ceiling of the panel; if not, it waits for someone to
 * launch it. Nothing runs without a key, a price for the model and a limit above 0.
 */
final class Runner {

	/**
	 * Action of Action Scheduler.
	 */
	public const TICK = 'lachinata_translate_tick';

	/**
	 * Daily action: the batch of what is «Revisado».
	 */
	public const DAILY = 'lachinata_translate_daily';

	/**
	 * Option with the last daily batch: {date, objects, words, estimate, sent}.
	 */
	public const DAILY_OPTION = 'lachinata_translate_daily';

	/**
	 * Hour of the daily batch, time of the shop.
	 */
	private const DAILY_HOUR = 4;

	/**
	 * Group of the actions.
	 */
	public const GROUP = 'lachinata-translate';

	/**
	 * Items translated one by one in a run.
	 */
	private const NOW = 10;

	/**
	 * Items in a batch at most.
	 */
	private const BATCH_SIZE = 500;

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'action_scheduler_init', array( self::class, 'schedule' ) );
		Hooks::add_action( self::TICK, array( self::class, 'tick' ) );
		Hooks::add_action( self::DAILY, array( self::class, 'daily' ) );
	}

	/**
	 * Schedules the run every five minutes and the daily batch.
	 */
	public static function schedule(): void {
		if ( ! function_exists( 'as_has_scheduled_action' ) || ! function_exists( 'as_schedule_recurring_action' ) ) {
			return;
		}
		if ( ! as_has_scheduled_action( self::TICK, array(), self::GROUP ) ) {
			as_schedule_recurring_action( time() + 60, 5 * MINUTE_IN_SECONDS, self::TICK, array(), self::GROUP );
		}
		if ( ! as_has_scheduled_action( self::DAILY, array(), self::GROUP ) ) {
			as_schedule_recurring_action( self::next_daily(), DAY_IN_SECONDS, self::DAILY, array(), self::GROUP );
		}
	}

	/**
	 * Next 04:00 of the shop, as a timestamp.
	 */
	public static function next_daily(): int {
		$now  = new \DateTimeImmutable( 'now', wp_timezone() );
		$next = $now->setTime( self::DAILY_HOUR, 0 );
		return ( $next <= $now ? $next->modify( '+1 day' ) : $next )->getTimestamp();
	}

	/**
	 * What waits for the daily batch: objects, words and estimate with the Batches API.
	 *
	 * @return array{objects: int, words: int, estimate: float}
	 */
	public static function waiting(): array {
		$out = array(
			'objects'  => 0,
			'words'    => 0,
			'estimate' => 0.0,
		);
		foreach ( Queue::pending( 100000, Queue::REVIEWED ) as $item ) {
			$out['words'] += Translator::prepare( $item )['words'];
			++$out['objects'];
		}
		$out['estimate'] = Spend::estimate( $out['words'], $out['objects'] );
		return $out;
	}

	/**
	 * The daily batch: what is «Revisado» passes to a batch when its estimate is below the
	 * ceiling of the panel; if not, it waits for someone to launch it. It is kept for the
	 * panel either way.
	 *
	 * @return array{date: string, objects: int, words: int, estimate: float, sent: bool}
	 */
	public static function daily(): array {
		$waiting = self::waiting();
		$sent    = $waiting['objects'] > 0 && '' === Spend::blocked() && $waiting['estimate'] < self::ceiling();
		if ( $sent ) {
			Queue::release();
			self::kick();
		}
		$done = array_merge( array( 'date' => current_time( 'mysql', true ) ), $waiting, array( 'sent' => $sent ) );
		update_option( self::DAILY_OPTION, $done, false );
		return $done;
	}

	/**
	 * Ceiling of the daily batch in estimated USD (0: always by hand).
	 */
	public static function ceiling(): float {
		return max( 0.0, (float) TranslateModule::setting( 'daily_max' ) );
	}

	/**
	 * A run right away (after a change), unless one is waiting.
	 */
	public static function kick(): void {
		if ( function_exists( 'as_enqueue_async_action' ) && function_exists( 'as_has_scheduled_action' ) && '' === Spend::blocked() && ! as_has_scheduled_action( self::TICK, array( 'now' ), self::GROUP ) ) {
			as_enqueue_async_action( self::TICK, array( 'now' ), self::GROUP );
		}
	}

	/**
	 * One run.
	 *
	 * @return array{collected: int, translated: int, batched: int, stopped: string}
	 */
	public static function tick(): array {
		$done            = array(
			'collected'  => 0,
			'translated' => 0,
			'batched'    => 0,
			'stopped'    => '',
		);
		$done['stopped'] = Spend::blocked();
		if ( '' !== $done['stopped'] ) {
			return $done;
		}
		try {
			$done['collected']  = self::collect();
			$done['translated'] = self::now( self::NOW );
			$done['batched']    = self::send();
		} catch ( ClaudeError $error ) {
			$done['stopped'] = $error->getMessage();
		}
		return $done;
	}

	/**
	 * Translates the urgent items one by one.
	 *
	 * @param int $limit How many at most.
	 * @return int Items translated.
	 * @throws ClaudeError When the key fails.
	 */
	public static function now( int $limit ): int {
		$count = 0;
		foreach ( Queue::pending( $limit, null, Queue::CHANGE ) as $item ) {
			if ( '' !== Spend::blocked() ) {
				break;
			}
			Translator::run( $item );
			++$count;
		}
		return $count;
	}

	/**
	 * Sends the pending items of the batches to the Batches API, while the estimate fits in
	 * what is left of the limit.
	 *
	 * @return int Items sent.
	 * @throws ClaudeError When the API fails.
	 */
	public static function send(): int {
		$left     = Spend::remaining();
		$requests = array();
		$items    = array();
		foreach ( Queue::pending( self::BATCH_SIZE, Queue::BATCH ) as $item ) {
			$prepared = Translator::prepare( $item );
			if ( null === $prepared['body'] ) {
				Translator::apply( $item, $prepared, array(), 0.0 );
				continue;
			}
			$estimate = Spend::estimate( $prepared['words'], 1 );
			if ( $estimate > $left ) {
				break;
			}
			$left                               -= $estimate;
			$requests[ 'q' . (int) $item['id'] ] = $prepared['body'];
			$items[]                             = (int) $item['id'];
		}
		if ( ! $requests ) {
			return 0;
		}
		$batch = Claude::create_batch( $requests );
		$id    = (string) ( $batch['id'] ?? '' );
		foreach ( $items as $item ) {
			Queue::update(
				$item,
				array(
					'status'   => Queue::BATCHED,
					'batch_id' => $id,
				)
			);
		}
		return count( $items );
	}

	/**
	 * Collects the batches that ended.
	 *
	 * @return int Items collected.
	 * @throws ClaudeError When the API fails.
	 */
	public static function collect(): int {
		$count = 0;
		foreach ( Queue::open_batches() as $batch ) {
			$state = Claude::batch( $batch );
			if ( 'ended' !== ( $state['processing_status'] ?? '' ) || empty( $state['results_url'] ) ) {
				continue;
			}
			$results = Claude::results( (string) $state['results_url'] );
			foreach ( Queue::of_batch( $batch ) as $item ) {
				$result = $results[ 'q' . (int) $item['id'] ] ?? null;
				if ( null === $result || 'succeeded' !== $result['type'] ) {
					Queue::update(
						(int) $item['id'],
						array(
							'status'   => Queue::FAILED,
							'batch_id' => '',
							/* translators: %s: result type of the batch (errored, expired, canceled). */
							'reason'   => sprintf( __( 'El lote no lo ha traducido (%s).', 'lachinata-core' ), null === $result ? 'missing' : $result['type'] ),
						)
					);
					continue;
				}
				Translator::handle( $item, Translator::prepare( $item ), $result['message'], true );
				++$count;
			}
		}
		return $count;
	}

	/**
	 * Kinds of objects for the batches: «product» (with its variations), the other post
	 * types, «term» (every taxonomy) and «option».
	 *
	 * @return array<string, string> Kind → label.
	 */
	public static function kinds(): array {
		$out = array();
		foreach ( Fields::subtypes( 'post' ) as $post_type ) {
			if ( 'product_variation' === $post_type ) {
				continue;
			}
			$object            = get_post_type_object( $post_type );
			$out[ $post_type ] = $object ? (string) $object->labels->name : $post_type;
		}
		$out['term']   = __( 'Categorías, etiquetas y términos', 'lachinata-core' );
		$out['option'] = __( 'Textos de los ajustes', 'lachinata-core' );
		return $out;
	}

	/**
	 * Objects of a kind that can enter the queue: [type, subtype, id].
	 *
	 * @param string $kind Kind.
	 * @return array<int, array{0: string, 1: string, 2: int}>
	 */
	public static function objects( string $kind ): array {
		$out = array();
		if ( 'option' === $kind ) {
			foreach ( array_keys( Options::all() ) as $name ) {
				$out[] = array( Translator::OPTION, $name, Options::id( $name ) );
			}
			return $out;
		}
		if ( 'term' === $kind ) {
			foreach ( Fields::subtypes( 'term' ) as $taxonomy ) {
				$ids = get_terms(
					array(
						'taxonomy'   => $taxonomy,
						'hide_empty' => false,
						'fields'     => 'ids',
					)
				);
				foreach ( is_array( $ids ) ? $ids : array() as $id ) {
					$out[] = array( 'term', $taxonomy, (int) $id );
				}
			}
			return $out;
		}
		$types = 'product' === $kind ? array( 'product', 'product_variation' ) : array( $kind );
		$query = array(
			'post_type'      => $types,
			'post_status'    => 'nav_menu_item' === $kind ? 'any' : array( 'publish' ),
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'orderby'        => 'ID',
			'order'          => 'ASC',
		);
		if ( 'product' === $kind ) {
			// Variations are «publish» or «private»; their product decides.
			$query['post_status'] = array( 'publish', 'private' );
		}
		if ( in_array( $kind, SourceStatus::post_types(), true ) && TranslateModule::setting( 'only_reviewed' ) && 'product' !== $kind ) {
			$query['meta_query'] = array( SourceStatus::meta_query( SourceStatus::REVIEWED ) ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Batch launched by hand.
		}
		foreach ( get_posts( $query ) as $id ) {
			$out[] = array( 'post', (string) get_post_type( (int) $id ), (int) $id );
		}
		return $out;
	}

	/**
	 * Launches a batch: what a kind needs in a language enters the queue (or only counts, in
	 * a dry run). The words and the estimate are a warning; the limit controls with the real
	 * cost.
	 *
	 * @param string $language Locale.
	 * @param string $kind     Kind.
	 * @param int    $limit    Objects at most (0: all).
	 * @param bool   $dry_run  Count only.
	 * @return array{objects: int, words: int, estimate: float, review: int}
	 */
	public static function launch( string $language, string $kind, int $limit = 0, bool $dry_run = false ): array {
		$out = array(
			'objects'  => 0,
			'words'    => 0,
			'estimate' => 0.0,
			'review'   => 0,
		);
		foreach ( self::objects( $kind ) as $object ) {
			if ( $limit > 0 && $out['objects'] >= $limit ) {
				break;
			}
			[ $type, $subtype, $id ] = $object;
			if ( ! Translator::eligible( $type, $subtype, $id ) ) {
				continue;
			}
			$needs = Translator::needs( $type, $subtype, $id, $language );
			if ( ! $needs['todo'] && ! $needs['changed'] ) {
				continue;
			}
			++$out['objects'];
			$out['review'] += count( $needs['changed'] );
			foreach ( $needs['todo'] as $field ) {
				$out['words'] += Translator::words( $field['text'] );
			}
			if ( ! $dry_run ) {
				Queue::add( $type, $subtype, $id, $language, Queue::BATCH );
			}
		}
		$out['estimate'] = Spend::estimate( $out['words'], $out['objects'] );
		return $out;
	}
}
