<?php
/**
 * The key of the Claude API.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

defined( 'ABSPATH' ) || exit;

/**
 * The key goes in the panel and is kept encrypted with the keys of `wp-config.php` (decided
 * on 30/10). If they change, it cannot be read: the panel says «vuelve a pegarla» and the
 * queue stops. It never goes in the settings export, the logs or an error message, and the
 * panel never shows it back. In development it can come from `LACHINATA_DEV_CLAUDE_API_KEY`
 * (`.wp-env.override.json`), only on a local or development site.
 */
final class Secret {

	/**
	 * Option with the encrypted key (not autoloaded, not exported).
	 */
	public const OPTION = 'lachinata_translate_api_key';

	/**
	 * No key.
	 */
	public const NONE = 'none';

	/**
	 * A key that can be read.
	 */
	public const OK = 'ok';

	/**
	 * A key that can no longer be decrypted.
	 */
	public const UNREADABLE = 'unreadable';

	/**
	 * Saves a key ('' removes it).
	 *
	 * @param string $key Key.
	 */
	public static function save( string $key ): void {
		$key = trim( $key );
		if ( '' === $key ) {
			delete_option( self::OPTION );
			return;
		}
		$nonce = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
		update_option( self::OPTION, base64_encode( $nonce . sodium_crypto_secretbox( $key, $nonce, self::box() ) ), false ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Binary to text for the option.
	}

	/**
	 * The key, or null without one (or when it cannot be read).
	 */
	public static function key(): ?string {
		if ( defined( 'LACHINATA_DEV_CLAUDE_API_KEY' ) && in_array( wp_get_environment_type(), array( 'local', 'development' ), true ) ) {
			$dev = (string) constant( 'LACHINATA_DEV_CLAUDE_API_KEY' );
			if ( '' !== $dev ) {
				return $dev;
			}
		}
		$stored = get_option( self::OPTION, '' );
		if ( ! is_string( $stored ) || '' === $stored ) {
			return null;
		}
		$raw = base64_decode( $stored, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- Text to binary of the option.
		if ( false === $raw || strlen( $raw ) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ) {
			return null;
		}
		try {
			$key = sodium_crypto_secretbox_open( substr( $raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ), substr( $raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ), self::box() );
		} catch ( \SodiumException $e ) {
			return null;
		}
		return false === $key || '' === $key ? null : $key;
	}

	/**
	 * State of the key: none, ok or unreadable.
	 */
	public static function state(): string {
		if ( null !== self::key() ) {
			return self::OK;
		}
		$stored = get_option( self::OPTION, '' );
		return is_string( $stored ) && '' !== $stored ? self::UNREADABLE : self::NONE;
	}

	/**
	 * Encryption key derived from the keys and salts of `wp-config.php`.
	 */
	private static function box(): string {
		return sodium_crypto_generichash( wp_salt( 'auth' ) . wp_salt( 'secure_auth' ) . 'lachinata-translate', '', SODIUM_CRYPTO_SECRETBOX_KEYBYTES );
	}
}
