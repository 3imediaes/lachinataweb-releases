<?php
/**
 * The languages of the shop, served to the other modules.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

use LaChinata\Core\Contracts\Languages;
use LaChinata\Core\Languages\SiteLanguage;

defined( 'ABSPATH' ) || exit;

/**
 * `Contracts\Languages` (version 2) with the languages of the settings and the
 * translations of the table. The language of a request is the one of its address; an email,
 * a feed or `llms.txt` switch to another with switch_to() and come back with restore().
 */
final class Service implements Languages {

	/**
	 * The instance served by `lachinata/languages/service`.
	 *
	 * @var self|null
	 */
	private static ?self $instance = null;

	/**
	 * Language of the address of this request, '' for the default.
	 *
	 * @var string
	 */
	private string $request = '';

	/**
	 * Spanish address of this request (without prefix and with the Spanish slugs).
	 *
	 * @var string
	 */
	private string $source_url = '';

	/**
	 * Languages switched to, the last one on top, with whether WordPress switched its
	 * strings (it does not when the locale is already that one).
	 *
	 * @var array<int, array{0: string, 1: bool}>
	 */
	private array $stack = array();

	/**
	 * The instance.
	 */
	public static function instance(): self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Forgets the request (tests).
	 */
	public static function reset(): void {
		self::$instance = null;
	}

	/**
	 * Sets the language of the address of the request.
	 *
	 * @param string $language Locale, '' for the default.
	 */
	public function set_request( string $language ): void {
		$this->request = $language;
	}

	/**
	 * Keeps the Spanish address of the request.
	 *
	 * @param string $url Address.
	 */
	public function set_source_url( string $url ): void {
		$this->source_url = $url;
	}

	/**
	 * Languages of the shop, the default first.
	 *
	 * @return string[]
	 */
	public function languages(): array {
		return Config::all();
	}

	/**
	 * The default language.
	 */
	public function default_language(): string {
		return Config::default_language();
	}

	/**
	 * Name of a language: the one of the settings, or WordPress's.
	 *
	 * @param string $language Locale.
	 */
	public function label( string $language ): string {
		$label = Config::label( $language );
		return '' !== $label ? $label : ( new SiteLanguage() )->label( $language );
	}

	/**
	 * Title and descriptions of a product or variation in a language; the Spanish when it
	 * does not exist there.
	 *
	 * @param \WC_Product $product  Product or variation.
	 * @param string      $language Locale.
	 * @return array{title: string, description: string, short_description: string}
	 */
	public function product_texts( \WC_Product $product, string $language ): array {
		return Front::raw(
			function () use ( $product, $language ): array {
				$texts = array(
					'title'             => $product->get_name(),
					'description'       => (string) $product->get_description(),
					'short_description' => (string) $product->get_short_description(),
				);
				if ( $language === $this->default_language() ) {
					return $texts;
				}
				if ( $product instanceof \WC_Product_Variation ) {
					$parent = $product->get_parent_id();
					if ( Availability::is( 'post', $parent, $language ) ) {
						$texts['title'] = Front::variation_name( $texts['title'], $parent, $language );
					}
					$texts['description'] = Store::text( 'post', $product->get_id(), 'description', $language ) ?? $texts['description'];
					return $texts;
				}
				$id = $product->get_id();
				if ( ! Availability::is( 'post', $id, $language ) ) {
					return $texts;
				}
				return array(
					'title'             => Store::text( 'post', $id, 'name', $language ) ?? $texts['title'],
					'description'       => Store::text( 'post', $id, 'description', $language ) ?? $texts['description'],
					'short_description' => Store::text( 'post', $id, 'short_description', $language ) ?? $texts['short_description'],
				);
			}
		);
	}

	/**
	 * Name of a term in a language.
	 *
	 * @param \WP_Term $term     Term.
	 * @param string   $language Locale.
	 */
	public function term_name( \WP_Term $term, string $language ): string {
		$name = Front::raw( static fn(): string => (string) ( get_term( $term->term_id )->name ?? $term->name ) );
		if ( $language === $this->default_language() || ! Availability::is( 'term', $term->term_id, $language ) ) {
			return $name;
		}
		return Store::text( 'term', $term->term_id, 'name', $language ) ?? $name;
	}

	/**
	 * Any address of the site in a language: the one of its post when it is one, otherwise
	 * with the prefix and the slugs of pages and terms translated.
	 *
	 * @param string $url      Address.
	 * @param string $language Locale.
	 */
	public function url( string $url, string $language ): string {
		$source = self::to_source( $url );
		if ( '' !== $this->source_url && untrailingslashit( strtok( $source, '?#' ) ) === untrailingslashit( strtok( $this->source_url, '?#' ) ) ) {
			$alternates = $this->alternates();
			if ( isset( $alternates[ $language ] ) ) {
				return $alternates[ $language ];
			}
		}
		if ( $language === $this->default_language() ) {
			return $source;
		}
		$object = Front::raw( static fn(): ?array => self::object_of( $source ) );
		if ( null !== $object ) {
			return 'post' === $object[0] ? $this->post_url( $object[1], $language ) : $this->term_url( $object[1], $language );
		}
		return Links::generic( $source, $language );
	}

	/**
	 * The Spanish address of any address of the site: without the prefix and with the
	 * Spanish slugs (`/en/shop/x/` → `/tienda/x/`).
	 *
	 * @param string $url Address.
	 */
	public static function to_source( string $url ): string {
		$parts = Links::split( $url );
		if ( null === $parts ) {
			return $url;
		}
		$language = Links::language_of( $parts['path'] );
		if ( null === $language ) {
			return $url;
		}
		$stripped = Links::split( Links::strip( $url ) );
		return null === $stripped ? $url : $parts['root'] . Router::resolve( $stripped['path'], $language ) . $parts['rest'];
	}

	/**
	 * The Spanish address of the current request, with its query ('' before parsing it).
	 */
	public function source_url(): string {
		return $this->source_url;
	}

	/**
	 * The post or term of a Spanish address: [type, id], or null.
	 *
	 * @param string $url Spanish address.
	 * @return array{0: string, 1: int}|null
	 */
	public static function object( string $url ): ?array {
		return Front::raw( static fn(): ?array => self::object_of( $url ) );
	}

	/**
	 * The post or term of a Spanish address, by the slug of its last segment and checking
	 * that its address is that one; WordPress's lookup for the rest.
	 *
	 * @param string $url Spanish address.
	 * @return array{0: string, 1: int}|null
	 */
	private static function object_of( string $url ): ?array {
		$parts = Links::split( $url );
		if ( null === $parts ) {
			return null;
		}
		$path     = untrailingslashit( $parts['path'] );
		$segments = explode( '/', trim( $path, '/' ) );
		$stem     = (string) preg_replace( '/\.html?$/i', '', rawurldecode( (string) end( $segments ) ) );
		$same     = static fn( string $link ): bool => untrailingslashit( (string) wp_parse_url( $link, PHP_URL_PATH ) ) === untrailingslashit( (string) wp_parse_url( $url, PHP_URL_PATH ) );
		if ( '' !== $stem ) {
			$types = array_values( array_filter( Fields::subtypes( 'post' ), static fn( string $type ): bool => Availability::whole( 'post', $type ) ) );
			$ids   = $types ? get_posts(
				array(
					'name'             => $stem,
					'post_type'        => $types,
					'post_status'      => 'publish',
					'posts_per_page'   => 5,
					'fields'           => 'ids',
					'suppress_filters' => true,
				)
			) : array();
			foreach ( $ids as $id ) {
				if ( $same( (string) get_permalink( (int) $id ) ) ) {
					return array( 'post', (int) $id );
				}
			}
			$taxonomies = array_values( array_filter( Fields::subtypes( 'term' ), static fn( string $taxonomy ): bool => Availability::whole( 'term', $taxonomy ) && taxonomy_exists( $taxonomy ) ) );
			$terms      = $taxonomies ? get_terms(
				array(
					'taxonomy'   => $taxonomies,
					'slug'       => $stem,
					'hide_empty' => false,
				)
			) : array();
			foreach ( is_array( $terms ) ? $terms : array() as $term ) {
				$link = $term instanceof \WP_Term ? get_term_link( $term ) : '';
				if ( is_string( $link ) && $same( $link ) ) {
					return array( 'term', $term->term_id );
				}
			}
		}
		$id = url_to_postid( $url );
		return $id > 0 ? array( 'post', $id ) : null;
	}

	/**
	 * Language of this request.
	 */
	public function current(): string {
		if ( $this->stack ) {
			return $this->stack[ count( $this->stack ) - 1 ][0];
		}
		return '' !== $this->request ? $this->request : $this->default_language();
	}

	/**
	 * Code of a language in the addresses and in `hreflang`.
	 *
	 * @param string $language Locale.
	 */
	public function code( string $language ): string {
		return Config::code( $language );
	}

	/**
	 * Whether a post or a term exists in a language.
	 *
	 * @param string $type     «post» or «term».
	 * @param int    $id       Object id.
	 * @param string $language Locale.
	 */
	public function available( string $type, int $id, string $language ): bool {
		return Availability::is( $type, $id, $language );
	}

	/**
	 * Address of a post in a language.
	 *
	 * @param int    $post_id  Post id.
	 * @param string $language Locale.
	 */
	public function post_url( int $post_id, string $language ): string {
		$url = Front::raw( static fn(): string => (string) get_permalink( $post_id ) );
		return '' === $url ? '' : Links::post( $url, $post_id, $language );
	}

	/**
	 * Address of a term in a language.
	 *
	 * @param int    $term_id  Term id.
	 * @param string $language Locale.
	 */
	public function term_url( int $term_id, string $language ): string {
		$url = Front::raw(
			static function () use ( $term_id ): string {
				$link = get_term_link( $term_id );
				return is_string( $link ) ? $link : '';
			}
		);
		return '' === $url ? '' : Links::term( $url, $term_id, $language );
	}

	/**
	 * The current page in each language where it exists.
	 *
	 * @return array<string, string>
	 */
	public function alternates(): array {
		$object = get_queried_object();
		$out    = array();
		foreach ( $this->languages() as $language ) {
			if ( $object instanceof \WP_Post && is_singular() ) {
				if ( Availability::is( 'post', $object->ID, $language ) ) {
					$out[ $language ] = $this->post_url( $object->ID, $language );
				}
			} elseif ( $object instanceof \WP_Term ) {
				if ( Availability::is( 'term', $object->term_id, $language ) ) {
					$out[ $language ] = $this->term_url( $object->term_id, $language );
				}
			} elseif ( '' !== $this->source_url ) {
				$out[ $language ] = Links::generic( $this->source_url, $language );
			}
		}
		return $out;
	}

	/**
	 * Renders what follows in a language: texts, links and the strings of WordPress.
	 *
	 * @param string $language Locale.
	 */
	public function switch_to( string $language ): void {
		$language      = in_array( $language, $this->languages(), true ) ? $language : $this->default_language();
		$this->stack[] = array( $language, switch_to_locale( $language ) );
	}

	/**
	 * Whether something is rendered in a language switched to (an email, a feed).
	 */
	public function switched(): bool {
		return array() !== $this->stack;
	}

	/**
	 * Back to the language before the last switch_to().
	 */
	public function restore(): void {
		$last = array_pop( $this->stack );
		if ( null !== $last && $last[1] ) {
			restore_previous_locale();
		}
	}
}
