<?php
/**
 * Prices and spending of the Claude API.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

defined( 'ABSPATH' ) || exit;

/**
 * The monthly limit is checked against the real cost: the tokens each answer says it used,
 * at the price of its model (the Batches API at half price). The estimate before a batch is
 * only a warning. The prices live here and are updated with each version; the panel can
 * correct them if the API changes them. A limit of 0 (the default) means the queue does not
 * run; a model without a price never runs either.
 */
final class Spend {

	/**
	 * Option with the spending by month («2026-10» → USD).
	 */
	public const OPTION = 'lachinata_translate_spend';

	/**
	 * USD per million tokens: input and output (29/10/2026).
	 */
	public const PRICES = array(
		'claude-sonnet-5-5' => array( 2.0, 10.0 ),
		'claude-opus-5-5'   => array( 4.0, 20.0 ),
		'claude-haiku-5-5'  => array( 0.10, 0.50 ),
		'claude-fable-5-1'  => array( 10.0, 50.0 ),
	);

	/**
	 * Discount of the Batches API.
	 */
	public const BATCH = 0.5;

	/**
	 * Price of a model: the panel's correction or the table; null when unknown.
	 *
	 * @param string $model Model id.
	 * @return array{0: float, 1: float}|null
	 */
	public static function price( string $model ): ?array {
		$override = TranslateModule::setting( 'prices' );
		if ( is_array( $override ) && isset( $override[ $model ] ) && is_array( $override[ $model ] ) ) {
			$input  = (float) ( $override[ $model ][0] ?? $override[ $model ]['input'] ?? 0 );
			$output = (float) ( $override[ $model ][1] ?? $override[ $model ]['output'] ?? 0 );
			if ( $input > 0 && $output > 0 ) {
				return array( $input, $output );
			}
		}
		return self::PRICES[ $model ] ?? null;
	}

	/**
	 * Cost of an answer from its `usage`.
	 *
	 * @param string               $model Model id.
	 * @param array<string, mixed> $usage Usage of the answer.
	 * @param bool                 $batch Sent in a batch.
	 */
	public static function cost( string $model, array $usage, bool $batch = false ): float {
		$price = self::price( $model );
		if ( null === $price ) {
			return 0.0;
		}
		$input = (int) ( $usage['input_tokens'] ?? 0 )
			+ 1.25 * (int) ( $usage['cache_creation_input_tokens'] ?? 0 )
			+ 0.1 * (int) ( $usage['cache_read_input_tokens'] ?? 0 );
		$cost  = ( $input * $price[0] + (int) ( $usage['output_tokens'] ?? 0 ) * $price[1] ) / 1000000;
		return $batch ? $cost * self::BATCH : $cost;
	}

	/**
	 * Estimated cost of translating some words (a warning, not the control): about 1,4
	 * tokens a word in, the instructions of each request, and twice the words out
	 * (translation and reasoning).
	 *
	 * @param int  $words    Words of Spanish.
	 * @param int  $requests Requests.
	 * @param bool $batch    In a batch.
	 */
	public static function estimate( int $words, int $requests, bool $batch = true ): float {
		$price = self::price( self::model() );
		if ( null === $price ) {
			return 0.0;
		}
		$input  = 1.4 * $words + 1200 * $requests;
		$output = 2.8 * $words + 100 * $requests;
		$cost   = ( $input * $price[0] + $output * $price[1] ) / 1000000;
		return $batch ? $cost * self::BATCH : $cost;
	}

	/**
	 * The model of the panel.
	 */
	public static function model(): string {
		$model = (string) TranslateModule::setting( 'model' );
		return '' !== $model ? $model : 'claude-sonnet-5-5';
	}

	/**
	 * The monthly limit in USD.
	 */
	public static function limit(): float {
		return max( 0.0, (float) TranslateModule::setting( 'limit' ) );
	}

	/**
	 * What this month has spent.
	 */
	public static function spent(): float {
		$all = get_option( self::OPTION, array() );
		return is_array( $all ) ? (float) ( $all[ gmdate( 'Y-m' ) ] ?? 0 ) : 0.0;
	}

	/**
	 * What is left this month.
	 */
	public static function remaining(): float {
		return max( 0.0, self::limit() - self::spent() );
	}

	/**
	 * Adds a cost to this month.
	 *
	 * @param float $cost USD.
	 */
	public static function add( float $cost ): void {
		if ( $cost <= 0 ) {
			return;
		}
		$all   = get_option( self::OPTION, array() );
		$all   = is_array( $all ) ? $all : array();
		$month = gmdate( 'Y-m' );
		// Twelve months are enough for the panel.
		$all[ $month ] = round( (float) ( $all[ $month ] ?? 0 ) + $cost, 6 );
		krsort( $all );
		update_option( self::OPTION, array_slice( $all, 0, 12, true ), false );
	}

	/**
	 * By month, newest first.
	 *
	 * @return array<string, float>
	 */
	public static function months(): array {
		$all = get_option( self::OPTION, array() );
		return is_array( $all ) ? array_map( 'floatval', $all ) : array();
	}

	/**
	 * Why the queue cannot run now, or '' when it can.
	 */
	public static function blocked(): string {
		if ( ! Config::languages() ) {
			return __( 'No hay otros idiomas.', 'lachinata-core' );
		}
		$state = Secret::state();
		if ( Secret::UNREADABLE === $state ) {
			return __( 'La clave de la API no se puede leer (han cambiado las claves de wp-config.php): vuelve a pegarla.', 'lachinata-core' );
		}
		if ( Secret::NONE === $state ) {
			return __( 'Falta la clave de la API de Claude.', 'lachinata-core' );
		}
		if ( null === self::price( self::model() ) ) {
			/* translators: %s: model id. */
			return sprintf( __( 'No hay precio para el modelo %s: corrígelo en Precios o elige otro modelo.', 'lachinata-core' ), self::model() );
		}
		if ( self::limit() <= 0 ) {
			return __( 'El límite de gasto es 0: la cola no corre hasta que pongas uno.', 'lachinata-core' );
		}
		if ( self::spent() >= self::limit() ) {
			/* translators: %s: limit in USD. */
			return sprintf( __( 'Se ha alcanzado el límite de gasto de este mes (%s USD): la cola está parada.', 'lachinata-core' ), number_format_i18n( self::limit(), 2 ) );
		}
		return '';
	}
}
