<?php
/**
 * Translations that follow the Spanish.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * When the Spanish of something changes, its translations of the fields that changed pass
 * to «Desfasada» (they stay published until they are translated again; an edited one keeps
 * its origin «person», so it is never overwritten) and the languages where it exists are
 * recalculated. Deleting a post or a term deletes its translations. The objects touched in a
 * request are processed once, at the end, when WooCommerce and Rank Math have saved their
 * meta too.
 */
final class Sync {

	/**
	 * Objects touched in this request, by «type:id».
	 *
	 * @var array<string, array{0: string, 1: int}>
	 */
	private static array $dirty = array();

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'save_post', array( self::class, 'post' ), 20 );
		Hooks::add_action( 'woocommerce_update_product', array( self::class, 'post' ), 20 );
		Hooks::add_action( 'woocommerce_update_product_variation', array( self::class, 'post' ), 20 );
		Hooks::add_action( 'updated_post_meta', array( self::class, 'post_meta' ), 20, 3 );
		Hooks::add_action( 'added_post_meta', array( self::class, 'post_meta' ), 20, 3 );
		Hooks::add_action( 'deleted_post_meta', array( self::class, 'post_meta' ), 20, 3 );
		Hooks::add_action( 'edited_term', array( self::class, 'term' ), 20 );
		Hooks::add_action( 'created_term', array( self::class, 'term' ), 20 );
		Hooks::add_action( 'updated_term_meta', array( self::class, 'term_meta' ), 20, 3 );
		Hooks::add_action( 'added_term_meta', array( self::class, 'term_meta' ), 20, 3 );
		Hooks::add_action( 'deleted_post', array( self::class, 'deleted_post' ) );
		Hooks::add_action( 'delete_term', array( self::class, 'deleted_term' ) );
		Hooks::add_action( 'shutdown', array( self::class, 'flush' ), 0 );
	}

	/**
	 * A post was saved.
	 *
	 * @param mixed $post_id Post id.
	 */
	public static function post( $post_id ): void {
		$post_id = (int) $post_id;
		if ( $post_id > 0 && ! wp_is_post_revision( $post_id ) && Fields::translatable( 'post', (string) get_post_type( $post_id ) ) ) {
			self::$dirty[ 'post:' . $post_id ] = array( 'post', $post_id );
		}
	}

	/**
	 * Meta of a post changed.
	 *
	 * @param mixed $meta_id Meta id.
	 * @param mixed $post_id Post id.
	 * @param mixed $key     Meta key.
	 */
	public static function post_meta( $meta_id, $post_id, $key ): void {
		unset( $meta_id );
		if ( is_string( $key ) && Fields::is_meta( 'post', $key ) ) {
			self::post( $post_id );
		}
	}

	/**
	 * A term was saved.
	 *
	 * @param mixed $term_id Term id.
	 */
	public static function term( $term_id ): void {
		$term_id = (int) $term_id;
		$term    = get_term( $term_id );
		if ( $term instanceof \WP_Term && Fields::translatable( 'term', $term->taxonomy ) ) {
			self::$dirty[ 'term:' . $term_id ] = array( 'term', $term_id );
		}
	}

	/**
	 * Meta of a term changed.
	 *
	 * @param mixed $meta_id Meta id.
	 * @param mixed $term_id Term id.
	 * @param mixed $key     Meta key.
	 */
	public static function term_meta( $meta_id, $term_id, $key ): void {
		unset( $meta_id );
		if ( is_string( $key ) && Fields::is_meta( 'term', $key ) ) {
			self::term( $term_id );
		}
	}

	/**
	 * A post was deleted: its translations go.
	 *
	 * @param mixed $post_id Post id.
	 */
	public static function deleted_post( $post_id ): void {
		Store::delete( 'post', (int) $post_id );
		Queue::forget( 'post', (int) $post_id );
		unset( self::$dirty[ 'post:' . (int) $post_id ] );
	}

	/**
	 * A term was deleted: its translations go.
	 *
	 * @param mixed $term_id Term id.
	 */
	public static function deleted_term( $term_id ): void {
		Store::delete( 'term', (int) $term_id );
		Queue::forget( 'term', (int) $term_id );
		unset( self::$dirty[ 'term:' . (int) $term_id ] );
	}

	/**
	 * Processes the objects touched in this request.
	 */
	public static function flush(): void {
		$dirty       = self::$dirty;
		self::$dirty = array();
		foreach ( $dirty as $object ) {
			self::object( $object[0], $object[1] );
		}
	}

	/**
	 * Marks as outdated the translations whose Spanish changed and recalculates the
	 * languages of an object.
	 *
	 * @param string $type    «post» or «term».
	 * @param int    $id      Object id.
	 * @param bool   $enqueue Whether what needs a translation enters the queue.
	 * @return int Translations marked outdated.
	 */
	public static function object( string $type, int $id, bool $enqueue = true ): int {
		$subtype = Fields::subtype( $type, $id );
		if ( null === $subtype ) {
			return 0;
		}
		$marked = 0;
		$hashes = array();
		foreach ( Fields::of( $type, $subtype ) as $name => $field ) {
			$hashes[ $name ] = Store::fingerprint( Fields::source( $type, $id, $field ) );
		}
		foreach ( array_keys( Config::languages() ) as $language ) {
			foreach ( Store::get( $type, $id, $language ) as $name => $row ) {
				if ( isset( $hashes[ $name ] ) && '' !== $row['hash'] && $row['hash'] !== $hashes[ $name ] && Store::OUTDATED !== $row['status'] ) {
					Store::mark( $type, $id, $name, $language, Store::OUTDATED );
					++$marked;
				}
			}
		}
		if ( ( 'post' === $type && 'page' === $subtype ) || 'term' === $type ) {
			// Its slug may be a segment of other addresses.
			Slugs::flush();
		}
		Availability::refresh( $type, $id );
		// What changed, or is new, enters the queue (11c).
		if ( $enqueue ) {
			Translator::refresh( $type, $subtype, $id );
		}
		return $marked;
	}
}
