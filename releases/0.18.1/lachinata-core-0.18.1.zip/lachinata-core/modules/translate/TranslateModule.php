<?php
/**
 * Module `translate`: the shop in other languages.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

use LaChinata\Core\Hooks;
use LaChinata\Core\Module;
use LaChinata\Core\Plugin;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Replaces TranslatePress (07-traduccion.md). Translations are fields of the same post or
 * term, kept in its own table, never copies: one product in every language, with the same
 * id, stock, price and orders. Each language lives in its subdirectory (`/en/`) with
 * translated addresses, `hreflang` and its sitemap; a page exists in a language only when it
 * is translated whole. It serves `Contracts\Languages`; the other modules declare their
 * fields with `lachinata/translate/fields`. Off, there is a single language and the
 * translations stay. Since 0.17.0 Claude translates what is reviewed, through the queue,
 * the glossary, the memory and the seven controls, within a monthly limit.
 */
final class TranslateModule extends Module {

	/**
	 * Module id.
	 */
	public function id(): string {
		return 'translate';
	}

	/**
	 * Module name.
	 */
	public function label(): string {
		return __( 'Traducción', 'lachinata-core' );
	}

	/**
	 * Module description.
	 */
	public function description(): string {
		return __( 'Sirve la tienda en otros idiomas, cada uno en su subdirectorio (/en/) con direcciones traducidas, hreflang y su sitemap. Las traducciones son campos de la misma ficha y se corrigen en el editor, al lado del español. Los idiomas se configuran en Traducción.', 'lachinata-core' );
	}

	/**
	 * Version in which the module was added.
	 */
	public function since(): string {
		return '0.15.0';
	}

	/**
	 * Documentation.
	 */
	public function docs(): string {
		return 'plugin/modules/translate/README.md';
	}

	/**
	 * Requirements.
	 *
	 * @return array{woocommerce: string}
	 */
	public function requires(): array {
		return array( 'woocommerce' => '10.0' );
	}

	/**
	 * Settings: the languages of the shop, whether only the reviewed Spanish enters the
	 * queue (07, «Primero el español») and, since 0.17.0, the model, effort, monthly limit in
	 * USD (0: the queue does not run), the ceiling of the daily batch of what is «Revisado»
	 * (estimated USD; 0: always by hand), price corrections, instructions of each language and
	 * the glossary. The key of the API is not a setting: it never travels in the export.
	 *
	 * @return array<string, array{type: 'bool'|'int'|'float'|'string'|'array', default: mixed, export?: bool}>
	 */
	public function settings(): array {
		return array(
			'languages'     => array(
				'type'    => 'array',
				'default' => array(),
				'export'  => true,
			),
			'only_reviewed' => array(
				'type'    => 'bool',
				'default' => true,
				'export'  => true,
			),
			'model'         => array(
				'type'    => 'string',
				'default' => 'claude-sonnet-5-5',
				'export'  => true,
			),
			'effort'        => array(
				'type'    => 'string',
				'default' => 'medium',
				'export'  => true,
			),
			'limit'         => array(
				'type'    => 'float',
				'default' => 0.0,
				'export'  => true,
			),
			'daily_max'     => array(
				'type'    => 'float',
				'default' => 5.0,
				'export'  => true,
			),
			'prices'        => array(
				'type'    => 'array',
				'default' => array(),
				'export'  => true,
			),
			'instructions'  => array(
				'type'    => 'array',
				'default' => array(),
				'export'  => true,
			),
			'glossary'      => array(
				'type'    => 'array',
				'default' => array(),
				'export'  => true,
			),
		);
	}

	/**
	 * The module, for Settings.
	 */
	public static function instance(): ?Module {
		return Plugin::instance()->modules()->get( 'translate' );
	}

	/**
	 * A setting of the module.
	 *
	 * @param string $key Setting key.
	 * @return mixed
	 */
	public static function setting( string $key ) {
		$module = self::instance();
		return null === $module ? null : Settings::get( $module, $key );
	}

	/**
	 * Version of the data: v1 creates the table of translations; v2 (0.17.0), the queue and
	 * the translation memory.
	 */
	public function schema_version(): int {
		return 2;
	}

	/**
	 * Steps of the data.
	 *
	 * @return array<int, callable(): void>
	 */
	public function migrations(): array {
		return array(
			1 => array( Store::class, 'install' ),
			2 => static function (): void {
				Queue::install();
				Memory::install();
			},
		);
	}

	/**
	 * The languages, how many translations each one has and the strings of WordPress and
	 * WooCommerce in each language.
	 *
	 * @return array{configured: bool, credentials: null, notes: string[]}
	 */
	public function health(): array {
		$languages = Config::languages();
		$notes     = array();
		if ( ! $languages ) {
			$notes[] = __( 'Sin otros idiomas: la tienda sale solo en el suyo.', 'lachinata-core' );
		}
		$counts = Store::counts();
		foreach ( $languages as $locale => $language ) {
			$states  = $counts[ $locale ] ?? array();
			$notes[] = sprintf(
				/* translators: 1: language, 2: code, 3: translated fields, 4: outdated fields. */
				__( '%1$s (/%2$s/): %3$d campos traducidos, %4$d desfasados.', 'lachinata-core' ),
				'' !== $language['label'] ? $language['label'] : $locale,
				$language['code'],
				array_sum( $states ),
				$states[ Store::OUTDATED ] ?? 0
			);
			if ( ! is_readable( WP_LANG_DIR . '/plugins/woocommerce-' . $locale . '.mo' ) ) {
				/* translators: %s: locale. */
				$notes[] = sprintf( __( 'Faltan las cadenas de WooCommerce en %1$s: Escritorio → Actualizaciones, o wp language plugin install woocommerce %1$s.', 'lachinata-core' ), $locale );
			}
		}
		$notes[] = self::setting( 'only_reviewed' )
			? __( 'Solo el español «Revisado» entra en la cola de traducción.', 'lachinata-core' )
			: __( 'Todo el español entra en la cola de traducción, revisado o no.', 'lachinata-core' );
		return array(
			'configured'  => (bool) $languages,
			'credentials' => null,
			'notes'       => $notes,
		);
	}

	/**
	 * What it keeps beyond its options: the table, where each page exists and the language
	 * of each order (never deleted: it is the order's history).
	 *
	 * @return array{product_meta: string[], term_meta: string[], order_meta: string[], tables: string[]}
	 */
	public function owned_data(): array {
		return array(
			'product_meta' => array( Availability::META ),
			'term_meta'    => array( Availability::META ),
			'order_meta'   => array( Emails::META ),
			'tables'       => array( Store::TABLE, Queue::TABLE, Memory::TABLE ),
		);
	}

	/**
	 * The Spanish of a post passed to «Revisado»: it waits in the queue for the batch of the
	 * early morning (a product with its variations).
	 *
	 * @param mixed $post_id Post id.
	 * @param mixed $status  New state.
	 */
	public static function reviewed( $post_id, $status ): void {
		$post_id = (int) $post_id;
		if ( \LaChinata\Core\SourceStatus::REVIEWED !== $status || $post_id <= 0 ) {
			return;
		}
		$post_type = (string) get_post_type( $post_id );
		Translator::refresh( 'post', $post_type, $post_id, Queue::REVIEWED );
		if ( 'product' === $post_type ) {
			foreach ( get_children(
				array(
					'post_parent' => $post_id,
					'post_type'   => 'product_variation',
					'fields'      => 'ids',
				)
			) as $variation ) {
				Translator::refresh( 'post', 'product_variation', (int) $variation, Queue::REVIEWED );
			}
		}
	}

	/**
	 * Serves the languages of the shop.
	 *
	 * @param mixed $languages Service of another module, or null.
	 * @return mixed
	 */
	public static function service( $languages ) {
		return null === $languages ? Service::instance() : $languages;
	}

	/**
	 * Registers the hooks. The service and the panel always; addresses, texts, SEO and
	 * emails only with another language.
	 */
	public function boot(): void {
		Config::capture();
		Hooks::add_filter( 'lachinata/languages/service', array( self::class, 'service' ) );
		if ( is_admin() ) {
			TranslateTab::boot();
		}
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::add_command( 'lachinata translate', Cli::class );
		}
		if ( ! Config::languages() ) {
			return;
		}
		Router::boot();
		Legacy::boot();
		Front::boot();
		Seo::boot();
		Sync::boot();
		Emails::boot();
		Memory::boot();
		Options::boot();
		Attributes::boot();
		Legal::boot();
		Runner::boot();
		Hooks::add_action( 'lachinata/source_status/changed', array( self::class, 'reviewed' ), 10, 2 );
		if ( is_admin() ) {
			Editor::boot();
		}
	}
}
