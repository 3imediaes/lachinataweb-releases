<?php
/**
 * The move from TranslatePress.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

defined( 'ABSPATH' ) || exit;

/**
 * What is taken from TranslatePress (07-traduccion.md, «Migración desde TranslatePress»):
 * not its translations of content, only the strings a person corrected there, short ones
 * (up to four words), as proposals of the glossary. The old addresses of `/en/` need no
 * table: `Legacy` and `Router` answer them by rule. `report()` asks the site for each old
 * address (Search Console's list) and says what it answers now, by clicks.
 */
final class TranslatePress {

	/**
	 * Status of a string corrected by a person in TranslatePress.
	 */
	private const HUMAN = 2;

	/**
	 * Words of a string that can be a term of the glossary, at most.
	 */
	private const WORDS = 4;

	/**
	 * Strings corrected by a person in TranslatePress for a language: original → translation.
	 *
	 * @param string        $language Locale («en_GB»: takes the table of any English).
	 * @param string[]|null $tables   Tables of TranslatePress (null: the ones in the database).
	 * @return array<string, string>
	 */
	public static function strings( string $language, ?array $tables = null ): array {
		global $wpdb;
		$code   = strtolower( (string) strtok( $language, '_' ) );
		$prefix = $wpdb->prefix . 'trp_dictionary_';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- tables of another plugin, read once by a command.
		$tables = $tables ?? (array) $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $prefix ) . '%' ) );
		$out    = array();
		foreach ( $tables as $table ) {
			$pair = explode( '_', substr( (string) $table, strlen( $prefix ) ) );
			if ( count( $pair ) < 4 || $code !== $pair[2] ) {
				continue;
			}
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- idem.
			$columns = (array) $wpdb->get_col( $wpdb->prepare( 'SHOW COLUMNS FROM %i', $table ) );
			if ( in_array( 'original', $columns, true ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- idem.
				$rows = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT original, translated FROM %i WHERE status = %d', $table, self::HUMAN ), ARRAY_A );
			} elseif ( in_array( 'original_id', $columns, true ) ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- idem.
				$rows = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT o.original, d.translated FROM %i d JOIN %i o ON o.id = d.original_id WHERE d.status = %d', $table, $wpdb->prefix . 'trp_original_strings', self::HUMAN ), ARRAY_A );
			} else {
				continue;
			}
			foreach ( $rows as $row ) {
				$original   = trim( wp_strip_all_tags( html_entity_decode( (string) $row['original'], ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) );
				$translated = trim( wp_strip_all_tags( html_entity_decode( (string) $row['translated'], ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ) );
				$words      = preg_split( '/\s+/u', $original, -1, PREG_SPLIT_NO_EMPTY );
				$words      = false === $words ? array() : $words;
				if ( '' === $original || '' === $translated || count( $words ) > self::WORDS || mb_strlen( $original ) > 60 || preg_match( '/\d/', $original ) ) {
					continue;
				}
				$out[ $original ] = $translated;
			}
		}
		return $out;
	}

	/**
	 * The strings as proposals of the glossary (a string kept as it was is a «no traducir»).
	 *
	 * @param string        $language Locale.
	 * @param string[]|null $tables   Tables of TranslatePress (null: the ones in the database).
	 * @return int Proposals.
	 */
	public static function propose( string $language, ?array $tables = null ): int {
		$count = 0;
		foreach ( self::strings( $language, $tables ) as $original => $translated ) {
			if ( null === self::known( $original, $language ) ) {
				Glossary::propose( $language, $original, $original === $translated ? '' : $translated, 'TranslatePress' );
				++$count;
			}
		}
		return $count;
	}

	/**
	 * The term of the glossary that is this one, or null.
	 *
	 * @param string $term     Term.
	 * @param string $language Locale.
	 * @return array{term: string, translation: string, keep: bool}|null
	 */
	private static function known( string $term, string $language ): ?array {
		foreach ( Glossary::terms( $language ) as $row ) {
			if ( mb_strtolower( $row['term'] ) === mb_strtolower( $term ) ) {
				return $row;
			}
		}
		return null;
	}

	/**
	 * What each old address answers now: rows {url, clicks, code, location}, by clicks.
	 *
	 * @param string $csv   Search Console's list (columns `url` and, if any, `clics_16m`).
	 * @param int    $limit Addresses at most (0: all).
	 * @return array<int, array{url: string, clicks: int, code: int, location: string}>
	 */
	public static function report( string $csv, int $limit = 0 ): array {
		$lines = preg_split( '/\r\n|\r|\n/', trim( $csv ) );
		$lines = false === $lines ? array() : $lines;
		$head  = array_map( static fn( $cell ): string => strtolower( trim( (string) $cell, " \t\"\u{FEFF}" ) ), str_getcsv( (string) array_shift( $lines ), ',', '"', '' ) );
		$url   = array_search( 'url', $head, true );
		$click = array_search( 'clics_16m', $head, true );
		if ( false === $url ) {
			return array();
		}
		$rows = array();
		foreach ( $lines as $line ) {
			$cells = str_getcsv( $line, ',', '"', '' );
			$path  = trim( (string) ( $cells[ $url ] ?? '' ) );
			if ( '' === $path || isset( $rows[ $path ] ) ) {
				continue;
			}
			$rows[ $path ] = array(
				'url'      => $path,
				'clicks'   => false === $click ? 0 : (int) ( $cells[ $click ] ?? 0 ),
				'code'     => 0,
				'location' => '',
			);
		}
		uasort( $rows, static fn( array $a, array $b ): int => $b['clicks'] <=> $a['clicks'] );
		$rows = array_values( $rows );
		if ( $limit > 0 ) {
			$rows = array_slice( $rows, 0, $limit );
		}
		$parts  = wp_parse_url( home_url( '/' ) );
		$origin = ( $parts['scheme'] ?? 'http' ) . '://' . ( $parts['host'] ?? '' ) . ( isset( $parts['port'] ) ? ':' . $parts['port'] : '' );
		foreach ( $rows as $index => $row ) {
			$answer = wp_remote_head(
				wp_parse_url( $row['url'], PHP_URL_HOST ) ? $row['url'] : $origin . '/' . ltrim( $row['url'], '/' ),
				array(
					'redirection' => 0,
					'timeout'     => 20,
					'sslverify'   => false,
				)
			);
			if ( is_wp_error( $answer ) ) {
				$rows[ $index ]['location'] = $answer->get_error_message();
				continue;
			}
			$rows[ $index ]['code']     = (int) wp_remote_retrieve_response_code( $answer );
			$rows[ $index ]['location'] = (string) wp_remote_retrieve_header( $answer, 'location' );
		}
		return $rows;
	}

	/**
	 * The report as Markdown: totals by answer and the addresses that answer 404, by clicks.
	 *
	 * @param array<int, array{url: string, clicks: int, code: int, location: string}> $rows Rows.
	 */
	public static function markdown( array $rows ): string {
		$totals = array();
		foreach ( $rows as $row ) {
			$totals[ $row['code'] ] = ( $totals[ $row['code'] ] ?? 0 ) + 1;
		}
		ksort( $totals );
		$lines = array( '# Direcciones antiguas de otro idioma', '', '| Respuesta | Direcciones |', '| --- | --- |' );
		foreach ( $totals as $code => $total ) {
			$lines[] = sprintf( '| %s | %d |', 0 === $code ? 'sin respuesta' : (string) $code, $total );
		}
		$lines[] = '';
		$lines[] = '## 404, por clics';
		$lines[] = '';
		foreach ( $rows as $row ) {
			if ( 404 === $row['code'] ) {
				$lines[] = sprintf( '- %s (%d clics)', $row['url'], $row['clicks'] );
			}
		}
		$lines[] = '';
		$lines[] = '## Todas';
		$lines[] = '';
		$lines[] = '| Dirección | Clics | Respuesta | Destino |';
		$lines[] = '| --- | --- | --- | --- |';
		foreach ( $rows as $row ) {
			$lines[] = sprintf( '| %s | %d | %d | %s |', $row['url'], $row['clicks'], $row['code'], $row['location'] );
		}
		return implode( "\n", $lines ) . "\n";
	}

	/**
	 * The addresses that answer 404 as a CSV for the list of redirections (`url`,
	 * `destino_url` empty, `clics_16m`), to fill by hand.
	 *
	 * @param array<int, array{url: string, clicks: int, code: int, location: string}> $rows Rows.
	 */
	public static function missing_csv( array $rows ): string {
		$lines = array( 'url,destino_url,clics_16m' );
		foreach ( $rows as $row ) {
			if ( 404 === $row['code'] ) {
				$lines[] = sprintf( '"%s",,%d', str_replace( '"', '""', $row['url'] ), $row['clicks'] );
			}
		}
		return implode( "\n", $lines ) . "\n";
	}
}
