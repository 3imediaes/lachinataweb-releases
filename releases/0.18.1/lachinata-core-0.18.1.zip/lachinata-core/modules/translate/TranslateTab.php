<?php
/**
 * WooCommerce → La Chinata → Traducción.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

use LaChinata\Core\Admin\Screen;
use LaChinata\Core\Hooks;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * The languages of the shop and, since 0.17.0, everything of Claude: the key, the model and
 * the monthly limit, the instructions of each language, the glossary with its proposals,
 * the batches (words and estimate before launching), «Revisar», the weekly sample and the
 * figures of the month. A notice says when the queue is stopped and what has been outdated
 * for more than 7 days.
 */
final class TranslateTab {

	/**
	 * Tab id.
	 */
	public const TAB = 'translate';

	/**
	 * Action of admin-post.php, also nonce action.
	 */
	private const SAVE = 'lachinata_translate_settings';

	/**
	 * Sections of the tab.
	 */
	private const SECTIONS = array( 'languages', 'claude', 'instructions', 'glossary', 'batches', 'review', 'sample', 'month' );

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/core/admin_tabs', array( self::class, 'tab' ), 40 );
		Hooks::add_action( 'admin_post_' . self::SAVE, array( self::class, 'handle' ) );
	}

	/**
	 * Adds the tab after Destino.
	 *
	 * @param array<string, array{label: string, render: callable}> $tabs Tabs.
	 * @return array<string, array{label: string, render: callable}>
	 */
	public static function tab( array $tabs ): array {
		$position = array_search( 'locale', array_keys( $tabs ), true );
		$position = false === $position ? count( $tabs ) : $position + 1;
		$tab      = array(
			self::TAB => array(
				'label'  => __( 'Traducción', 'lachinata-core' ),
				'render' => array( self::class, 'render' ),
			),
		);
		return array_slice( $tabs, 0, $position, true ) + $tab + $tabs;
	}

	/**
	 * Prints the tab.
	 */
	public static function render(): void {
		$section = isset( $_GET['section'] ) && in_array( $_GET['section'], self::SECTIONS, true ) ? sanitize_key( $_GET['section'] ) : 'languages'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Navigation only.
		$review  = (int) array_sum( array_map( static fn( array $states ): int => (int) ( $states[ Queue::REVIEW ] ?? 0 ), Queue::counts() ) );
		Screen::section_links(
			self::TAB,
			array(
				'languages'    => __( 'Idiomas', 'lachinata-core' ),
				'claude'       => __( 'API de Claude', 'lachinata-core' ),
				'instructions' => __( 'Instrucciones', 'lachinata-core' ),
				'glossary'     => __( 'Glosario', 'lachinata-core' ),
				'batches'      => __( 'Tandas', 'lachinata-core' ),
				/* translators: %s: items waiting for a person. */
				'review'       => sprintf( __( 'Revisar (%s)', 'lachinata-core' ), number_format_i18n( $review ) ),
				'sample'       => __( 'Muestra', 'lachinata-core' ),
				'month'        => __( 'Este mes', 'lachinata-core' ),
			),
			$section
		);
		self::notices();
		switch ( $section ) {
			case 'claude':
				self::render_claude();
				break;
			case 'instructions':
				self::render_instructions();
				break;
			case 'glossary':
				self::render_glossary();
				break;
			case 'batches':
				self::render_batches();
				break;
			case 'review':
				self::render_review();
				break;
			case 'sample':
				self::render_sample();
				break;
			case 'month':
				self::render_month();
				break;
			default:
				self::render_languages();
		}
	}

	/**
	 * Whether the queue is stopped, and what has been outdated for more than 7 days.
	 */
	private static function notices(): void {
		if ( ! Config::languages() ) {
			return;
		}
		$blocked = Spend::blocked();
		if ( '' !== $blocked ) {
			printf( '<div class="notice notice-warning inline"><p>%s</p></div>', esc_html( $blocked ) );
		}
		$stale = self::stale();
		if ( $stale > 0 ) {
			printf(
				'<div class="notice notice-warning inline"><p>%s</p></div>',
				/* translators: %s: translations. */
				esc_html( sprintf( _n( '%s traducción lleva más de 7 días «Desfasada» (puede ser el límite de gasto).', '%s traducciones llevan más de 7 días «Desfasadas» (puede ser el límite de gasto).', $stale, 'lachinata-core' ), number_format_i18n( $stale ) ) )
			);
		}
	}

	/**
	 * Outdated items still open after 7 days.
	 */
	public static function stale(): int {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table, panel.
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE priority = %d AND status IN (%s, %s, %s) AND created_at < %s', Queue::table(), Queue::OUTDATED, Queue::PENDING, Queue::BATCHED, Queue::FAILED, gmdate( 'Y-m-d H:i:s', time() - 7 * DAY_IN_SECONDS ) ) );
	}

	/**
	 * Start of a form of the tab.
	 *
	 * @param string $section Section that saves.
	 */
	private static function form( string $section ): void {
		printf( '<form method="post" action="%s">', esc_url( admin_url( 'admin-post.php' ) ) );
		printf( '<input type="hidden" name="action" value="%1$s"><input type="hidden" name="section" value="%2$s">', esc_attr( self::SAVE ), esc_attr( $section ) );
		wp_nonce_field( self::SAVE );
	}

	/**
	 * Languages.
	 */
	private static function render_languages(): void {
		$rows = array();
		foreach ( Config::languages() as $locale => $language ) {
			$rows[] = array(
				'locale' => $locale,
				'code'   => $language['code'],
				'label'  => $language['label'],
			);
		}
		$rows[] = array(
			'locale' => '',
			'code'   => '',
			'label'  => '',
		);
		$counts = Store::counts();
		self::form( 'languages' );
		?>
			<h2><?php esc_html_e( 'Idiomas', 'lachinata-core' ); ?></h2>
			<p class="description">
				<?php
				printf(
					/* translators: %s: language of the site («es_ES»). */
					esc_html__( 'El idioma del sitio (%s) es siempre el origen y va sin prefijo. Cada otro idioma vive en su subdirectorio.', 'lachinata-core' ),
					'<code>' . esc_html( Config::default_language() ) . '</code>'
				);
				?>
			</p>
			<table class="widefat striped" style="max-width:48em">
				<thead><tr><th scope="col"><?php esc_html_e( 'Locale', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Código (dirección y hreflang)', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Nombre', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Traducciones', 'lachinata-core' ); ?></th></tr></thead>
				<tbody>
					<?php foreach ( $rows as $index => $row ) : ?>
						<tr>
							<td><label class="screen-reader-text" for="lc-tr-locale-<?php echo esc_attr( (string) $index ); ?>"><?php esc_html_e( 'Locale', 'lachinata-core' ); ?></label><input id="lc-tr-locale-<?php echo esc_attr( (string) $index ); ?>" type="text" name="languages[<?php echo esc_attr( (string) $index ); ?>][locale]" value="<?php echo esc_attr( $row['locale'] ); ?>" placeholder="en_GB" class="regular-text" style="width:8em"></td>
							<td><label class="screen-reader-text" for="lc-tr-code-<?php echo esc_attr( (string) $index ); ?>"><?php esc_html_e( 'Código', 'lachinata-core' ); ?></label><input id="lc-tr-code-<?php echo esc_attr( (string) $index ); ?>" type="text" name="languages[<?php echo esc_attr( (string) $index ); ?>][code]" value="<?php echo esc_attr( $row['code'] ); ?>" placeholder="en" style="width:5em"></td>
							<td><label class="screen-reader-text" for="lc-tr-label-<?php echo esc_attr( (string) $index ); ?>"><?php esc_html_e( 'Nombre', 'lachinata-core' ); ?></label><input id="lc-tr-label-<?php echo esc_attr( (string) $index ); ?>" type="text" name="languages[<?php echo esc_attr( (string) $index ); ?>][label]" value="<?php echo esc_attr( $row['label'] ); ?>" placeholder="English"></td>
							<td><?php echo '' === $row['locale'] ? '' : esc_html( number_format_i18n( array_sum( $counts[ $row['locale'] ] ?? array() ) ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<p class="description"><?php esc_html_e( 'Para quitar un idioma, vacía su fila: sus traducciones se conservan.', 'lachinata-core' ); ?></p>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Qué se traduce', 'lachinata-core' ); ?></th>
					<td>
						<label><input type="checkbox" name="only_reviewed" value="1" <?php checked( (bool) TranslateModule::setting( 'only_reviewed' ) ); ?>> <?php esc_html_e( 'Solo productos, páginas y entradas con el español «Revisado»', 'lachinata-core' ); ?></label>
						<p class="description"><?php esc_html_e( 'Términos, menús, oleotecas y textos de los ajustes no tienen estado y se traducen siempre.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
		<?php
	}

	/**
	 * Key, model, effort, limit and prices.
	 */
	private static function render_claude(): void {
		$state  = Secret::state();
		$model  = Spend::model();
		$price  = Spend::price( $model );
		$prices = TranslateModule::setting( 'prices' );
		$fix    = is_array( $prices ) && isset( $prices[ $model ] ) && is_array( $prices[ $model ] ) ? $prices[ $model ] : array();
		self::form( 'claude' );
		?>
			<h2><?php esc_html_e( 'API de Claude', 'lachinata-core' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="lc-tr-key"><?php esc_html_e( 'Clave de la API', 'lachinata-core' ); ?></label></th>
					<td>
						<input id="lc-tr-key" type="password" name="api_key" value="" class="regular-text" autocomplete="off" placeholder="<?php echo esc_attr( Secret::OK === $state ? __( 'Guardada', 'lachinata-core' ) : 'sk-ant-…' ); ?>">
						<p class="description">
							<?php
							if ( Secret::OK === $state ) {
								esc_html_e( 'Hay una clave guardada, cifrada. Escribe otra solo para cambiarla.', 'lachinata-core' );
							} elseif ( Secret::UNREADABLE === $state ) {
								esc_html_e( 'La clave guardada no se puede leer (han cambiado las claves de wp-config.php): vuelve a pegarla.', 'lachinata-core' );
							} else {
								esc_html_e( 'Se guarda cifrada con las claves de wp-config.php. No viaja en la exportación ni se vuelve a mostrar.', 'lachinata-core' );
							}
							?>
						</p>
						<?php if ( Secret::NONE !== $state ) : ?>
							<label><input type="checkbox" name="api_key_remove" value="1"> <?php esc_html_e( 'Quitar la clave', 'lachinata-core' ); ?></label>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="lc-tr-model"><?php esc_html_e( 'Modelo', 'lachinata-core' ); ?></label></th>
					<td><input id="lc-tr-model" type="text" name="model" value="<?php echo esc_attr( $model ); ?>" class="regular-text"><p class="description"><?php esc_html_e( 'De serie, claude-sonnet-5-5.', 'lachinata-core' ); ?></p></td>
				</tr>
				<tr>
					<th scope="row"><label for="lc-tr-effort"><?php esc_html_e( 'Esfuerzo', 'lachinata-core' ); ?></label></th>
					<td>
						<select id="lc-tr-effort" name="effort">
							<?php foreach ( array( 'low', 'medium', 'high' ) as $effort ) : ?>
								<option value="<?php echo esc_attr( $effort ); ?>" <?php selected( Prompt::effort(), $effort ); ?>><?php echo esc_html( $effort ); ?></option>
							<?php endforeach; ?>
						</select>
						<p class="description"><?php esc_html_e( 'Cuánto razona el modelo antes de traducir. Más esfuerzo, más tokens de salida.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="lc-tr-limit"><?php esc_html_e( 'Límite de gasto al mes (USD)', 'lachinata-core' ); ?></label></th>
					<td>
						<input id="lc-tr-limit" type="number" min="0" step="0.01" name="limit" value="<?php echo esc_attr( (string) Spend::limit() ); ?>" style="width:8em">
						<p class="description">
							<?php
							printf(
								/* translators: 1: spent this month, 2: limit. */
								esc_html__( 'Este mes: %1$s de %2$s USD, con el coste real que devuelve la API. Con 0, la cola no corre. Al alcanzarlo, la cola se para y avisa.', 'lachinata-core' ),
								esc_html( number_format_i18n( Spend::spent(), 2 ) ),
								esc_html( number_format_i18n( Spend::limit(), 2 ) )
							);
							?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="lc-tr-daily"><?php esc_html_e( 'Tanda diaria de lo «Revisado» (USD)', 'lachinata-core' ); ?></label></th>
					<td>
						<input id="lc-tr-daily" type="number" min="0" step="0.01" name="daily_max" value="<?php echo esc_attr( (string) Runner::ceiling() ); ?>" style="width:8em">
						<p class="description"><?php esc_html_e( 'Cada día a las 4:00, lo que ha pasado a «Revisado» sale en una tanda si su coste estimado está por debajo de esta cifra. Si la supera, espera a que alguien la lance en «Tandas». Con 0, siempre a mano.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Precio del modelo (USD por millón de tokens)', 'lachinata-core' ); ?></th>
					<td>
						<label><?php esc_html_e( 'Entrada', 'lachinata-core' ); ?> <input type="number" min="0" step="0.01" name="price_input" value="<?php echo esc_attr( (string) ( $fix[0] ?? '' ) ); ?>" placeholder="<?php echo esc_attr( null === $price ? '' : (string) $price[0] ); ?>" style="width:6em"></label>
						<label><?php esc_html_e( 'Salida', 'lachinata-core' ); ?> <input type="number" min="0" step="0.01" name="price_output" value="<?php echo esc_attr( (string) ( $fix[1] ?? '' ) ); ?>" placeholder="<?php echo esc_attr( null === $price ? '' : (string) $price[1] ); ?>" style="width:6em"></label>
						<p class="description"><?php esc_html_e( 'Vacío, el precio que trae el plugin. Solo si la API cambia sus precios. Los lotes van a mitad de precio.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
		<?php
	}

	/**
	 * Instructions of each language.
	 */
	private static function render_instructions(): void {
		self::form( 'instructions' );
		echo '<h2>' . esc_html__( 'Instrucciones de marca', 'lachinata-core' ) . '</h2>';
		echo '<p class="description">' . esc_html__( 'Van en cada petición, junto con unidades métricas siempre, cifras intactas y sin añadir afirmaciones.', 'lachinata-core' ) . '</p>';
		foreach ( Config::languages() as $locale => $language ) {
			$rules = Prompt::instructions( $locale );
			$key   = esc_attr( $locale );
			printf( '<h3>%s</h3><table class="form-table" role="presentation">', esc_html( '' !== $language['label'] ? $language['label'] : $locale ) );
			printf( '<tr><th scope="row"><label for="lc-tr-tone-%1$s">%2$s</label></th><td><textarea id="lc-tr-tone-%1$s" name="instructions[%1$s][tone]" rows="3" class="large-text">%3$s</textarea></td></tr>', $key, esc_html__( 'Tono', 'lachinata-core' ), esc_textarea( $rules['tone'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $key is escaped.
			printf( '<tr><th scope="row"><label for="lc-tr-address-%1$s">%2$s</label></th><td><input id="lc-tr-address-%1$s" type="text" name="instructions[%1$s][address]" value="%3$s" style="width:8em"></td></tr>', $key, esc_html__( 'Tratamiento', 'lachinata-core' ), esc_attr( $rules['address'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $key is escaped.
			printf(
				'<tr><th scope="row"><label for="lc-tr-legal-%1$s">%2$s</label></th><td><input id="lc-tr-legal-%1$s" type="text" name="instructions[%1$s][legal_line]" value="%3$s" class="large-text"><label><input type="checkbox" name="instructions[%1$s][legal_on]" value="1" %4$s> %5$s</label><p class="description">%6$s</p></td></tr></table>',
				$key, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above.
				esc_html__( 'Línea de las páginas legales', 'lachinata-core' ),
				esc_attr( $rules['legal_line'] ),
				checked( $rules['legal_on'], true, false ),
				esc_html__( 'Añadirla al final de las páginas legales traducidas', 'lachinata-core' ),
				esc_html__( 'Las páginas legales de «Datos de la empresa» y las condiciones de WooCommerce no se publican solas: se traducen y esperan en «Revisar» hasta que una persona las aprueba.', 'lachinata-core' )
			);
		}
		submit_button();
		echo '</form>';
	}

	/**
	 * Glossary and proposals.
	 */
	private static function render_glossary(): void {
		self::form( 'glossary' );
		?>
			<h2><?php esc_html_e( 'Glosario', 'lachinata-core' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Una línea por término: idioma, término en español y traducción fija. Con la traducción vacía, el término no se traduce nunca (marca, gamas, denominaciones de origen, vinos, bodegas, uvas). Con el idioma vacío, vale para todos.', 'lachinata-core' ); ?></p>
			<label class="screen-reader-text" for="lc-tr-glossary"><?php esc_html_e( 'Glosario en CSV', 'lachinata-core' ); ?></label>
			<textarea id="lc-tr-glossary" name="glossary" rows="16" class="large-text code"><?php echo esc_textarea( Glossary::to_csv() ); ?></textarea>
			<?php submit_button(); ?>
		</form>
		<?php
		$proposals = Glossary::proposals();
		if ( ! $proposals ) {
			return;
		}
		echo '<h2>' . esc_html__( 'Propuestas', 'lachinata-core' ) . '</h2><table class="widefat striped" style="max-width:60em"><thead><tr>';
		echo '<th scope="col">' . esc_html__( 'Idioma', 'lachinata-core' ) . '</th><th scope="col">' . esc_html__( 'Término', 'lachinata-core' ) . '</th><th scope="col">' . esc_html__( 'Traducción', 'lachinata-core' ) . '</th><th scope="col">' . esc_html__( 'De dónde', 'lachinata-core' ) . '</th><th scope="col"></th></tr></thead><tbody>';
		foreach ( $proposals as $key => $row ) {
			echo '<tr><td>' . esc_html( $row['language'] ) . '</td><td>' . esc_html( $row['term'] ) . '</td><td>' . esc_html( '' !== $row['translation'] ? $row['translation'] : __( '(no traducir)', 'lachinata-core' ) ) . '</td><td>' . esc_html( $row['from'] ) . '</td><td>';
			self::form( 'proposal' );
			printf( '<input type="hidden" name="proposal" value="%1$s"><button class="button button-primary" name="decision" value="accept">%2$s</button> <button class="button" name="decision" value="discard">%3$s</button></form>', esc_attr( (string) $key ), esc_html__( 'Aceptar', 'lachinata-core' ), esc_html__( 'Descartar', 'lachinata-core' ) );
			echo '</td></tr>';
		}
		echo '</tbody></table>';
	}

	/**
	 * Batches: what a kind needs in a language, with words and estimate, and the button.
	 */
	private static function render_batches(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Reading the choice of the form (GET).
		$languages = Config::languages();
		$language  = isset( $_GET['language'] ) ? sanitize_text_field( wp_unslash( $_GET['language'] ) ) : (string) array_key_first( $languages );
		$kinds     = Runner::kinds();
		$kind      = isset( $_GET['kind'] ) ? sanitize_key( wp_unslash( $_GET['kind'] ) ) : 'product';
		$limit     = isset( $_GET['limit'] ) ? absint( $_GET['limit'] ) : 0;
		$calc      = ! empty( $_GET['calc'] ) && isset( $languages[ $language ], $kinds[ $kind ] );
		// phpcs:enable
		echo '<h2>' . esc_html__( 'Tandas', 'lachinata-core' ) . '</h2>';
		echo '<p class="description">' . esc_html__( 'Lo que ya existe se traduce por tandas, con la API por lotes (a mitad de precio y sin prisa). Calcula primero: verás cuántas fichas, palabras y el coste estimado. El límite de gasto lo controla el coste real.', 'lachinata-core' ) . '</p>';
		printf( '<form method="get" action="%s">', esc_url( admin_url( 'admin.php' ) ) );
		echo '<input type="hidden" name="page" value="' . esc_attr( Screen::SLUG ) . '"><input type="hidden" name="tab" value="' . esc_attr( self::TAB ) . '"><input type="hidden" name="section" value="batches"><input type="hidden" name="calc" value="1">';
		echo '<label for="lc-tr-b-lang">' . esc_html__( 'Idioma', 'lachinata-core' ) . '</label> <select id="lc-tr-b-lang" name="language">';
		foreach ( $languages as $locale => $row ) {
			printf( '<option value="%1$s" %2$s>%3$s</option>', esc_attr( $locale ), selected( $language, $locale, false ), esc_html( '' !== $row['label'] ? $row['label'] : $locale ) );
		}
		echo '</select> <label for="lc-tr-b-kind">' . esc_html__( 'Qué', 'lachinata-core' ) . '</label> <select id="lc-tr-b-kind" name="kind">';
		foreach ( $kinds as $value => $label ) {
			printf( '<option value="%1$s" %2$s>%3$s</option>', esc_attr( $value ), selected( $kind, $value, false ), esc_html( $label ) );
		}
		echo '</select> <label for="lc-tr-b-limit">' . esc_html__( 'Como mucho', 'lachinata-core' ) . '</label> <input id="lc-tr-b-limit" type="number" min="0" name="limit" value="' . esc_attr( (string) $limit ) . '" style="width:6em"> ';
		submit_button( __( 'Calcular', 'lachinata-core' ), 'secondary', '', false );
		echo '</form>';
		if ( $calc ) {
			$estimate = Runner::launch( $language, $kind, $limit, true );
			printf(
				'<p><strong>%s</strong></p>',
				esc_html(
					sprintf(
						/* translators: 1: objects, 2: words, 3: estimated cost in USD, 4: fields corrected by a person that go to «Revisar». */
						__( '%1$s fichas, %2$s palabras, unos %3$s USD con la API por lotes. %4$s campos corregidos por una persona irán a «Revisar».', 'lachinata-core' ),
						number_format_i18n( $estimate['objects'] ),
						number_format_i18n( $estimate['words'] ),
						number_format_i18n( $estimate['estimate'], 2 ),
						number_format_i18n( $estimate['review'] )
					)
				)
			);
			if ( $estimate['objects'] > 0 ) {
				self::form( 'launch' );
				printf( '<input type="hidden" name="language" value="%1$s"><input type="hidden" name="kind" value="%2$s"><input type="hidden" name="limit" value="%3$d">', esc_attr( $language ), esc_attr( $kind ), (int) $limit );
				submit_button( __( 'Lanzar la tanda', 'lachinata-core' ), 'primary', '', false );
				echo '</form>';
			}
		}
		self::render_daily();
		$counts = Queue::counts();
		echo '<h3>' . esc_html__( 'Cola', 'lachinata-core' ) . '</h3><table class="widefat striped" style="max-width:48em"><thead><tr><th scope="col">' . esc_html__( 'Idioma', 'lachinata-core' ) . '</th><th scope="col">' . esc_html__( 'Pendientes', 'lachinata-core' ) . '</th><th scope="col">' . esc_html__( 'En un lote', 'lachinata-core' ) . '</th><th scope="col">' . esc_html__( 'Revisar', 'lachinata-core' ) . '</th><th scope="col">' . esc_html__( 'Con error', 'lachinata-core' ) . '</th></tr></thead><tbody>';
		foreach ( $languages as $locale => $row ) {
			$states = $counts[ $locale ] ?? array();
			printf( '<tr><td>%1$s</td><td>%2$s</td><td>%3$s</td><td>%4$s</td><td>%5$s</td></tr>', esc_html( '' !== $row['label'] ? $row['label'] : $locale ), esc_html( number_format_i18n( $states[ Queue::PENDING ] ?? 0 ) ), esc_html( number_format_i18n( $states[ Queue::BATCHED ] ?? 0 ) ), esc_html( number_format_i18n( $states[ Queue::REVIEW ] ?? 0 ) ), esc_html( number_format_i18n( $states[ Queue::FAILED ] ?? 0 ) ) );
		}
		echo '</tbody></table>';
		self::form( 'retry' );
		submit_button( __( 'Reintentar los que dieron error', 'lachinata-core' ), 'secondary', '', false );
		echo '</form>';
	}

	/**
	 * What is «Revisado» and waits for the daily batch, the last one and the button.
	 */
	private static function render_daily(): void {
		$waiting = Queue::reviewed();
		$last    = get_option( Runner::DAILY_OPTION );
		echo '<h3>' . esc_html__( 'Tanda diaria de lo «Revisado»', 'lachinata-core' ) . '</h3>';
		if ( is_array( $last ) && isset( $last['date'], $last['objects'] ) && $last['objects'] > 0 ) {
			$date = wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) strtotime( $last['date'] . ' UTC' ) );
			echo '<p>' . esc_html(
				empty( $last['sent'] )
					/* translators: 1: date, 2: objects, 3: estimated cost in USD, 4: ceiling in USD. */
					? sprintf( __( 'La del %1$s no salió: %2$s fichas, unos %3$s USD, por encima de %4$s USD (o la cola estaba parada).', 'lachinata-core' ), $date, number_format_i18n( (int) $last['objects'] ), number_format_i18n( (float) $last['estimate'], 2 ), number_format_i18n( Runner::ceiling(), 2 ) )
					/* translators: 1: date, 2: objects, 3: estimated cost in USD. */
					: sprintf( __( 'La del %1$s salió: %2$s fichas, unos %3$s USD.', 'lachinata-core' ), $date, number_format_i18n( (int) $last['objects'] ), number_format_i18n( (float) $last['estimate'], 2 ) )
			) . '</p>';
		}
		if ( $waiting <= 0 ) {
			echo '<p>' . esc_html__( 'No hay nada «Revisado» esperando.', 'lachinata-core' ) . '</p>';
			return;
		}
		/* translators: %s: objects. */
		echo '<p>' . esc_html( sprintf( _n( '%s ficha «Revisada» espera a la tanda de las 4:00.', '%s fichas «Revisadas» esperan a la tanda de las 4:00.', $waiting, 'lachinata-core' ), number_format_i18n( $waiting ) ) ) . '</p>';
		self::form( 'release' );
		submit_button( __( 'Lanzarla ahora', 'lachinata-core' ), 'secondary', '', false );
		echo '</form>';
	}

	/**
	 * «Revisar»: each item with the Spanish, the proposal and the reason.
	 */
	private static function render_review(): void {
		$items = Queue::in( Queue::REVIEW, 50 );
		echo '<h2>' . esc_html__( 'Revisar', 'lachinata-core' ) . '</h2>';
		if ( ! $items ) {
			echo '<p>' . esc_html__( 'No hay nada esperando.', 'lachinata-core' ) . '</p>';
			return;
		}
		echo '<p class="description">' . esc_html__( '«Publicar» publica la propuesta tal como está (o mantiene la corrección de una persona). Para cambiar algo, ábrela en el editor.', 'lachinata-core' ) . '</p>';
		foreach ( $items as $item ) {
			$title = self::title( $item );
			$link  = self::edit_link( $item );
			printf( '<div class="card" style="max-width:none"><h3>%1$s <small>(%2$s)</small></h3><p><strong>%3$s</strong></p>', esc_html( $title ), esc_html( (string) $item['language'] ), esc_html( (string) $item['reason'] ) );
			$proposal = Queue::proposal( $item );
			if ( $proposal ) {
				echo '<table class="widefat striped"><thead><tr><th scope="col">' . esc_html__( 'Campo', 'lachinata-core' ) . '</th><th scope="col">' . esc_html__( 'Español', 'lachinata-core' ) . '</th><th scope="col">' . esc_html__( 'Propuesta', 'lachinata-core' ) . '</th></tr></thead><tbody>';
				foreach ( $proposal as $field => $row ) {
					printf( '<tr><th scope="row">%1$s<p class="description">%2$s</p></th><td><pre style="white-space:pre-wrap">%3$s</pre></td><td><pre style="white-space:pre-wrap">%4$s</pre></td></tr>', esc_html( $field ), esc_html( $row['reason'] ), esc_html( $row['source'] ), esc_html( $row['text'] ) );
				}
				echo '</tbody></table>';
			}
			self::form( 'review' );
			printf( '<input type="hidden" name="item" value="%d"><p>', (int) $item['id'] );
			if ( $proposal ) {
				printf( '<button class="button button-primary" name="decision" value="approve">%s</button> ', esc_html__( 'Publicar', 'lachinata-core' ) );
			}
			printf( '<button class="button" name="decision" value="retry">%1$s</button> <button class="button" name="decision" value="discard">%2$s</button>', esc_html__( 'Volver a traducir', 'lachinata-core' ), esc_html__( 'Descartar', 'lachinata-core' ) );
			if ( '' !== $link ) {
				printf( ' <a class="button-link" href="%1$s">%2$s</a>', esc_url( $link ), esc_html__( 'Abrir en el editor', 'lachinata-core' ) );
			}
			echo '</p></form></div>';
		}
	}

	/**
	 * Weekly sample: 20 automatic translations of each language, the same all week.
	 */
	private static function render_sample(): void {
		global $wpdb;
		echo '<h2>' . esc_html__( 'Muestra de la semana', 'lachinata-core' ) . '</h2>';
		echo '<p class="description">' . esc_html__( '20 traducciones publicadas al azar en cada idioma, las mismas toda la semana, para leerlas cuando se pueda. Lo que corrijas en el editor entra en la memoria.', 'lachinata-core' ) . '</p>';
		$seed = (int) gmdate( 'oW' );
		foreach ( Config::languages() as $locale => $language ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table, panel.
			$rows = (array) $wpdb->get_results( $wpdb->prepare( 'SELECT object_type, object_subtype, object_id, field, text FROM %i WHERE language = %s AND status = %s AND origin = %s AND field NOT IN (%s, %s) ORDER BY RAND(%d) LIMIT 20', Store::table(), $locale, Store::AUTO, 'claude', 'slug', 'attributes', $seed ), ARRAY_A );
			printf( '<h3>%s</h3>', esc_html( '' !== $language['label'] ? $language['label'] : $locale ) );
			if ( ! $rows ) {
				echo '<p>' . esc_html__( 'Todavía no hay traducciones automáticas.', 'lachinata-core' ) . '</p>';
				continue;
			}
			echo '<table class="widefat striped"><thead><tr><th scope="col">' . esc_html__( 'Ficha', 'lachinata-core' ) . '</th><th scope="col">' . esc_html__( 'Campo', 'lachinata-core' ) . '</th><th scope="col">' . esc_html__( 'Traducción', 'lachinata-core' ) . '</th></tr></thead><tbody>';
			foreach ( $rows as $row ) {
				$item = array(
					'object_type'    => $row['object_type'],
					'object_subtype' => $row['object_subtype'],
					'object_id'      => $row['object_id'],
				);
				$link = self::edit_link( $item );
				printf( '<tr><td>%1$s</td><td>%2$s</td><td>%3$s</td></tr>', '' !== $link ? '<a href="' . esc_url( $link ) . '">' . esc_html( self::title( $item ) ) . '</a>' : esc_html( self::title( $item ) ), esc_html( (string) $row['field'] ), esc_html( wp_trim_words( wp_strip_all_tags( (string) $row['text'] ), 40 ) ) );
			}
			echo '</tbody></table>';
		}
	}

	/**
	 * Figures of the month: words, cost and corrections by language, and the months.
	 */
	private static function render_month(): void {
		global $wpdb;
		$since  = gmdate( 'Y-m-01 00:00:00' );
		$totals = Queue::totals( $since );
		echo '<h2>' . esc_html__( 'Este mes', 'lachinata-core' ) . '</h2><table class="widefat striped" style="max-width:48em"><thead><tr><th scope="col">' . esc_html__( 'Idioma', 'lachinata-core' ) . '</th><th scope="col">' . esc_html__( 'Fichas', 'lachinata-core' ) . '</th><th scope="col">' . esc_html__( 'Palabras enviadas', 'lachinata-core' ) . '</th><th scope="col">' . esc_html__( 'Coste (USD)', 'lachinata-core' ) . '</th><th scope="col">' . esc_html__( 'Correcciones', 'lachinata-core' ) . '</th></tr></thead><tbody>';
		foreach ( Config::languages() as $locale => $language ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- own table, panel.
			$edited = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE language = %s AND origin = %s AND updated_at >= %s', Store::table(), $locale, 'person', $since ) );
			$row    = $totals[ $locale ] ?? array(
				'words' => 0,
				'cost'  => 0.0,
				'items' => 0,
			);
			printf( '<tr><td>%1$s</td><td>%2$s</td><td>%3$s</td><td>%4$s</td><td>%5$s</td></tr>', esc_html( '' !== $language['label'] ? $language['label'] : $locale ), esc_html( number_format_i18n( $row['items'] ) ), esc_html( number_format_i18n( $row['words'] ) ), esc_html( number_format_i18n( $row['cost'], 2 ) ), esc_html( number_format_i18n( $edited ) ) );
		}
		echo '</tbody></table><h3>' . esc_html__( 'Gasto por mes', 'lachinata-core' ) . '</h3><ul>';
		foreach ( Spend::months() as $month => $cost ) {
			printf( '<li>%1$s: %2$s USD</li>', esc_html( $month ), esc_html( number_format_i18n( $cost, 2 ) ) );
		}
		echo '</ul>';
		$memory = Memory::counts();
		/* translators: %s: paragraphs. */
		printf( '<p>%s</p>', esc_html( sprintf( __( 'Memoria de traducción: %s párrafos.', 'lachinata-core' ), number_format_i18n( (int) array_sum( $memory ) ) ) ) );
	}

	/**
	 * Name of the object of an item.
	 *
	 * @param array<string, mixed> $item Item.
	 */
	private static function title( array $item ): string {
		$type = (string) $item['object_type'];
		$id   = (int) $item['object_id'];
		if ( Translator::OPTION === $type ) {
			return Options::all()[ (string) $item['object_subtype'] ]['label'] ?? (string) $item['object_subtype'];
		}
		if ( 'term' === $type ) {
			$term = get_term( $id );
			return $term instanceof \WP_Term ? $term->name : '#' . $id;
		}
		return (string) get_the_title( $id ) . ' (#' . $id . ')';
	}

	/**
	 * Editor of the object of an item, or ''.
	 *
	 * @param array<string, mixed> $item Item.
	 */
	private static function edit_link( array $item ): string {
		$type = (string) $item['object_type'];
		$id   = (int) $item['object_id'];
		if ( 'term' === $type ) {
			return (string) get_edit_term_link( $id );
		}
		if ( 'post' === $type ) {
			$post_id = 'product_variation' === $item['object_subtype'] ? (int) wp_get_post_parent_id( $id ) : $id;
			return (string) get_edit_post_link( $post_id, 'raw' );
		}
		return '';
	}

	/**
	 * Saves a section, or runs its action.
	 */
	public static function handle(): void {
		Screen::check( self::SAVE );
		$module = TranslateModule::instance();
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Screen::check().
		$section = isset( $_POST['section'] ) ? sanitize_key( wp_unslash( $_POST['section'] ) ) : 'languages';
		$back    = array( 'section' => in_array( $section, self::SECTIONS, true ) ? $section : 'languages' );
		if ( null === $module ) {
			Screen::redirect( self::TAB, $back );
		}
		$messages = array( __( 'Ajustes guardados.', 'lachinata-core' ) );
		$errors   = array();
		switch ( $section ) {
			case 'claude':
				if ( ! empty( $_POST['api_key_remove'] ) ) {
					Secret::save( '' );
				} elseif ( ! empty( $_POST['api_key'] ) ) {
					Secret::save( sanitize_text_field( wp_unslash( $_POST['api_key'] ) ) );
				}
				$model = isset( $_POST['model'] ) ? sanitize_text_field( wp_unslash( $_POST['model'] ) ) : '';
				Settings::set( $module, 'model', preg_match( '/^[a-z0-9.-]+$/', $model ) ? $model : 'claude-sonnet-5-5' );
				$effort = isset( $_POST['effort'] ) ? sanitize_key( wp_unslash( $_POST['effort'] ) ) : 'medium';
				Settings::set( $module, 'effort', in_array( $effort, array( 'low', 'medium', 'high' ), true ) ? $effort : 'medium' );
				Settings::set( $module, 'limit', max( 0.0, (float) sanitize_text_field( wp_unslash( $_POST['limit'] ?? '0' ) ) ) );
				Settings::set( $module, 'daily_max', max( 0.0, (float) sanitize_text_field( wp_unslash( $_POST['daily_max'] ?? '0' ) ) ) );
				$prices = TranslateModule::setting( 'prices' );
				$prices = is_array( $prices ) ? $prices : array();
				$input  = (float) sanitize_text_field( wp_unslash( $_POST['price_input'] ?? '0' ) );
				$output = (float) sanitize_text_field( wp_unslash( $_POST['price_output'] ?? '0' ) );
				if ( $input > 0 && $output > 0 ) {
					$prices[ Spend::model() ] = array( $input, $output );
				} else {
					unset( $prices[ Spend::model() ] );
				}
				Settings::set( $module, 'prices', $prices );
				break;
			case 'instructions':
				$posted = isset( $_POST['instructions'] ) && is_array( $_POST['instructions'] ) ? wp_unslash( $_POST['instructions'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Cleaned field by field below.
				$clean  = array();
				foreach ( array_keys( Config::languages() ) as $locale ) {
					$row              = is_array( $posted[ $locale ] ?? null ) ? $posted[ $locale ] : array();
					$clean[ $locale ] = array(
						'tone'       => sanitize_textarea_field( (string) ( $row['tone'] ?? '' ) ),
						'address'    => sanitize_text_field( (string) ( $row['address'] ?? '' ) ),
						'legal_line' => sanitize_text_field( (string) ( $row['legal_line'] ?? '' ) ),
						'legal_on'   => ! empty( $row['legal_on'] ),
					);
				}
				Settings::set( $module, 'instructions', $clean );
				break;
			case 'glossary':
				Glossary::save( Glossary::from_csv( isset( $_POST['glossary'] ) ? sanitize_textarea_field( wp_unslash( $_POST['glossary'] ) ) : '' ) );
				break;
			case 'proposal':
				Glossary::decide( isset( $_POST['proposal'] ) ? sanitize_text_field( wp_unslash( $_POST['proposal'] ) ) : '', 'accept' === sanitize_key( wp_unslash( $_POST['decision'] ?? '' ) ) );
				$back['section'] = 'glossary';
				$messages        = array( __( 'Hecho.', 'lachinata-core' ) );
				break;
			case 'launch':
				$language = isset( $_POST['language'] ) ? sanitize_text_field( wp_unslash( $_POST['language'] ) ) : '';
				$kind     = isset( $_POST['kind'] ) ? sanitize_key( wp_unslash( $_POST['kind'] ) ) : '';
				if ( isset( Config::languages()[ $language ], Runner::kinds()[ $kind ] ) ) {
					$done = Runner::launch( $language, $kind, absint( $_POST['limit'] ?? 0 ) );
					Runner::kick();
					/* translators: 1: objects, 2: estimated cost in USD. */
					$messages = array( sprintf( __( 'Tanda lanzada: %1$s fichas en la cola (unos %2$s USD).', 'lachinata-core' ), number_format_i18n( $done['objects'] ), number_format_i18n( $done['estimate'], 2 ) ) );
				}
				$back['section'] = 'batches';
				break;
			case 'release':
				/* translators: %s: objects. */
				$messages        = array( sprintf( __( 'Tanda lanzada: %s fichas en la cola.', 'lachinata-core' ), number_format_i18n( Queue::release() ) ) );
				$back['section'] = 'batches';
				Runner::kick();
				break;
			case 'retry':
				/* translators: %s: items. */
				$messages        = array( sprintf( __( '%s vuelven a la cola.', 'lachinata-core' ), number_format_i18n( Queue::retry() ) ) );
				$back['section'] = 'batches';
				Runner::kick();
				break;
			case 'review':
				$item     = absint( $_POST['item'] ?? 0 );
				$decision = isset( $_POST['decision'] ) ? sanitize_key( wp_unslash( $_POST['decision'] ) ) : '';
				$row      = Queue::get( $item );
				if ( 'approve' === $decision ) {
					/* translators: %s: fields. */
					$messages = array( sprintf( __( '%s campos publicados.', 'lachinata-core' ), number_format_i18n( Translator::approve( $item ) ) ) );
				} elseif ( 'retry' === $decision && null !== $row ) {
					foreach ( array_keys( Queue::proposal( $row ) ) as $field ) {
						Translator::retranslate( (string) $row['object_type'], (int) $row['object_id'], (string) $field, (string) $row['language'] );
					}
					Translator::discard( $item );
					Queue::add( (string) $row['object_type'], (string) $row['object_subtype'], (int) $row['object_id'], (string) $row['language'], Queue::OUTDATED );
					$messages = array( __( 'Vuelve a la cola.', 'lachinata-core' ) );
				} else {
					Translator::discard( $item );
					$messages = array( __( 'Descartada.', 'lachinata-core' ) );
				}
				break;
			default:
				$posted = isset( $_POST['languages'] ) && is_array( $_POST['languages'] ) ? map_deep( wp_unslash( $_POST['languages'] ), 'sanitize_text_field' ) : array();
				$rows   = array_values( array_filter( (array) $posted, static fn( $row ): bool => is_array( $row ) && '' !== trim( (string) ( $row['locale'] ?? '' ) ) ) );
				$errors = Config::validate( $rows );
				$clean  = array();
				foreach ( Config::clean( $rows ) as $locale => $language ) {
					$clean[] = array_merge( array( 'locale' => $locale ), $language );
				}
				Settings::set( $module, 'languages', $clean );
				Settings::set( $module, 'only_reviewed', ! empty( $_POST['only_reviewed'] ) );
				Config::reset();
				Slugs::flush();
				flush_rewrite_rules( false );
		}
		// phpcs:enable
		Screen::flash( $errors ? 'error' : 'success', $errors ? $errors : $messages );
		Screen::redirect( self::TAB, $back );
	}
}
