<?php
/**
 * Translating an object with Claude.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Translate;

use LaChinata\Core\Company;
use LaChinata\Core\SourceStatus;

defined( 'ABSPATH' ) || exit;

/**
 * For an item of the queue: which fields need a translation (none yet, or «Desfasada» and
 * not corrected by a person), what the memory already knows, the request, the controls and
 * the result. What passes is published (`Store`, «Automática», origin Claude) and enters the
 * memory; what fails, a field corrected by a person whose Spanish changed, and every legal
 * page wait in «Revisar».
 */
final class Translator {

	/**
	 * Kind of the options in the table.
	 */
	public const OPTION = 'option';

	/**
	 * The Spanish of each field of an object: name → {text, format, max, label}.
	 *
	 * @param string $type    «post», «term» or «option».
	 * @param string $subtype Post type, taxonomy or option name.
	 * @param int    $id      Object id.
	 * @return array<string, array{text: string, format: string, max: int, label: string}>
	 */
	public static function sources( string $type, string $subtype, int $id ): array {
		$out = array();
		if ( self::OPTION === $type ) {
			$declared = Options::all()[ $subtype ] ?? null;
			foreach ( null === $declared ? array() : Options::sources( $subtype ) as $path => $text ) {
				$out[ $path ] = array(
					'text'   => $text,
					'format' => wp_strip_all_tags( $text ) === $text ? 'text' : 'html',
					'max'    => $declared['max'] ?? 0,
					'label'  => $path,
				);
			}
			return $out;
		}
		foreach ( Fields::of( $type, $subtype ) as $name => $field ) {
			$text = Fields::source( $type, $id, $field );
			if ( 'slug' === $name ? '' === trim( $text ) : ! Fields::has_text( $text ) ) {
				continue;
			}
			$out[ $name ] = array(
				'text'   => $text,
				'format' => $field['format'],
				'max'    => $field['max'],
				'label'  => $field['label'],
			);
		}
		return $out;
	}

	/**
	 * What an object needs in a language: the fields to translate and those corrected by a
	 * person whose Spanish changed.
	 *
	 * @param string $type     Type.
	 * @param string $subtype  Subtype.
	 * @param int    $id       Object id.
	 * @param string $language Locale.
	 * @return array{todo: array<string, array{text: string, format: string, max: int, label: string}>, changed: array<string, array{text: string, format: string, max: int, label: string}>}
	 */
	public static function needs( string $type, string $subtype, int $id, string $language ): array {
		$rows    = Store::get( $type, $id, $language );
		$todo    = array();
		$changed = array();
		foreach ( self::sources( $type, $subtype, $id ) as $name => $field ) {
			$row = $rows[ $name ] ?? null;
			if ( null === $row ) {
				$todo[ $name ] = $field;
				continue;
			}
			$current = '' === $row['hash'] || Store::fingerprint( $field['text'] ) === $row['hash'];
			if ( $current && Store::OUTDATED !== $row['status'] ) {
				continue;
			}
			if ( 'person' === $row['origin'] ) {
				$changed[ $name ] = $field;
			} else {
				$todo[ $name ] = $field;
			}
		}
		return array(
			'todo'    => $todo,
			'changed' => $changed,
		);
	}

	/**
	 * Whether an object enters the queue: a post published (a variation, if its product is),
	 * with its Spanish «Revisado» when the shop asks for it (07, «Primero el español»); terms,
	 * menus and options always.
	 *
	 * @param string $type    Type.
	 * @param string $subtype Subtype.
	 * @param int    $id      Object id.
	 */
	public static function eligible( string $type, string $subtype, int $id ): bool {
		if ( 'post' !== $type ) {
			return true;
		}
		$post_id = 'product_variation' === $subtype ? (int) wp_get_post_parent_id( $id ) : $id;
		if ( $post_id <= 0 || ( 'nav_menu_item' !== $subtype && 'publish' !== get_post_status( $post_id ) ) ) {
			return false;
		}
		$parent_type = (string) get_post_type( $post_id );
		if ( ! in_array( $parent_type, SourceStatus::post_types(), true ) || ! TranslateModule::setting( 'only_reviewed' ) ) {
			return true;
		}
		return SourceStatus::is_reviewed( $post_id );
	}

	/**
	 * After a change: marks outdated what changed (options; posts and terms do it in `Sync`)
	 * and puts the object in the queue of each language where it needs something: the
	 * outdated first, then the changes of the day (translated right away). What passes to
	 * «Revisado» goes in a batch: it is the existing text, often hundreds at once.
	 *
	 * @param string   $type     Type.
	 * @param string   $subtype  Subtype.
	 * @param int      $id       Object id.
	 * @param int|null $priority Priority (null: outdated or change).
	 * @return int Items in the queue.
	 */
	public static function refresh( string $type, string $subtype, int $id, ?int $priority = null ): int {
		if ( ! self::eligible( $type, $subtype, $id ) ) {
			return 0;
		}
		$added = 0;
		foreach ( array_keys( Config::languages() ) as $language ) {
			$outdated = false;
			if ( self::OPTION === $type ) {
				$sources = self::sources( $type, $subtype, $id );
				foreach ( Store::get( $type, $id, $language ) as $name => $row ) {
					if ( isset( $sources[ $name ] ) && '' !== $row['hash'] && Store::fingerprint( $sources[ $name ]['text'] ) !== $row['hash'] && Store::OUTDATED !== $row['status'] ) {
						Store::mark( $type, $id, (string) $name, $language, Store::OUTDATED );
					}
				}
			}
			foreach ( Store::get( $type, $id, $language ) as $row ) {
				$outdated = $outdated || Store::OUTDATED === $row['status'];
			}
			$needs = self::needs( $type, $subtype, $id, $language );
			if ( $needs['todo'] || $needs['changed'] ) {
				Queue::add( $type, $subtype, $id, $language, $priority ?? ( $outdated ? Queue::OUTDATED : Queue::CHANGE ) );
				++$added;
			}
		}
		if ( $added ) {
			Runner::kick();
		}
		return $added;
	}

	/**
	 * Context of an object for the model: kind, category and name.
	 *
	 * @param string $type    Type.
	 * @param string $subtype Subtype.
	 * @param int    $id      Object id.
	 * @return array<string, string>
	 */
	public static function context( string $type, string $subtype, int $id ): array {
		if ( self::OPTION === $type ) {
			return array( 'kind' => 'shop setting: ' . ( Options::all()[ $subtype ]['label'] ?? $subtype ) );
		}
		if ( 'term' === $type ) {
			$taxonomy = get_taxonomy( $subtype );
			return array( 'kind' => 'term of ' . ( $taxonomy ? $taxonomy->labels->singular_name : $subtype ) );
		}
		$product_id = 'product_variation' === $subtype ? (int) wp_get_post_parent_id( $id ) : $id;
		$context    = array( 'kind' => 'product_variation' === $subtype ? 'product variation' : $subtype );
		if ( in_array( $subtype, array( 'product', 'product_variation' ), true ) ) {
			$product             = wc_get_product( $product_id );
			$context['product']  = $product ? $product->get_name() : '';
			$terms               = get_the_terms( $product_id, 'product_cat' );
			$context['category'] = is_array( $terms ) ? implode( ' › ', array_map( static fn( \WP_Term $term ): string => $term->name, array_slice( $terms, 0, 3 ) ) ) : '';
		}
		return $context;
	}

	/**
	 * Whether an object is a legal page (those of «Datos de la empresa» and the terms of
	 * WooCommerce): translated, it waits in «Revisar» until a person approves it.
	 *
	 * @param string $type Type.
	 * @param int    $id   Object id.
	 */
	public static function legal( string $type, int $id ): bool {
		if ( 'post' !== $type || $id <= 0 ) {
			return false;
		}
		$company = Company::get();
		$pages   = array_map( static fn( string $key ): int => (int) ( $company[ $key ] ?? 0 ), Company::PAGES );
		$pages[] = function_exists( 'wc_terms_and_conditions_page_id' ) ? (int) wc_terms_and_conditions_page_id() : 0;
		return in_array( $id, array_filter( $pages ), true );
	}

	/**
	 * What an item needs before asking: the request (null when nothing is left to ask), the
	 * fields found in memory and those corrected by a person.
	 *
	 * @param array<string, mixed> $item Item.
	 * @return array{body: array<string, mixed>|null, todo: array<string, array{text: string, format: string, max: int, label: string}>, memory: array<string, string>, changed: array<string, array{text: string, format: string, max: int, label: string}>, words: int}
	 */
	public static function prepare( array $item ): array {
		$type     = (string) $item['object_type'];
		$subtype  = (string) $item['object_subtype'];
		$id       = (int) $item['object_id'];
		$language = (string) $item['language'];
		$needs    = self::needs( $type, $subtype, $id, $language );
		$memory   = array();
		$ask      = array();
		$words    = 0;
		foreach ( $needs['todo'] as $name => $field ) {
			$recalled = 'slug' === $name ? null : Memory::recall( $field['text'], $language );
			if ( null !== $recalled ) {
				$memory[ $name ] = $recalled;
			} else {
				$ask[ $name ] = $field;
				$words       += self::words( $field['text'] );
			}
		}
		return array(
			'body'    => $ask ? Prompt::body( $language, self::context( $type, $subtype, $id ), $ask ) : null,
			'todo'    => $needs['todo'],
			'memory'  => $memory,
			'changed' => $needs['changed'],
			'words'   => $words,
		);
	}

	/**
	 * Translates an item now (Messages API) and applies the result.
	 *
	 * @param array<string, mixed> $item Item.
	 * @return string State of the item afterwards.
	 * @throws ClaudeError When the key fails (it stops the queue).
	 */
	public static function run( array $item ): string {
		if ( ! self::exists( $item ) || ! self::eligible( (string) $item['object_type'], (string) $item['object_subtype'], (int) $item['object_id'] ) ) {
			Queue::update( (int) $item['id'], array( 'status' => Queue::DONE ) );
			return Queue::DONE;
		}
		$prepared = self::prepare( $item );
		if ( null === $prepared['body'] ) {
			return self::apply( $item, $prepared, array(), 0.0 );
		}
		try {
			$message = Claude::message( $prepared['body'] );
		} catch ( ClaudeError $error ) {
			Queue::update(
				(int) $item['id'],
				array(
					'status' => Queue::FAILED,
					'reason' => $error->getMessage(),
				)
			);
			if ( $error->fatal() ) {
				throw $error;
			}
			return Queue::FAILED;
		}
		return self::handle( $item, $prepared, $message, false );
	}

	/**
	 * Applies an answer of the API to an item.
	 *
	 * @param array<string, mixed>                                                                                                                                                                                                                                       $item     Item.
	 * @param array{body: array<string, mixed>|null, todo: array<string, array{text: string, format: string, max: int, label: string}>, memory: array<string, string>, changed: array<string, array{text: string, format: string, max: int, label: string}>, words: int} $prepared What was asked.
	 * @param array<string, mixed>                                                                                                                                                                                                                                       $message  Answer.
	 * @param bool                                                                                                                                                                                                                                                       $batch    Answered in a batch.
	 * @return string State of the item afterwards.
	 */
	public static function handle( array $item, array $prepared, array $message, bool $batch ): string {
		$cost = Spend::cost( (string) ( $message['model'] ?? Spend::model() ), is_array( $message['usage'] ?? null ) ? $message['usage'] : array(), $batch );
		Spend::add( $cost );
		$stop = (string) ( $message['stop_reason'] ?? '' );
		$data = json_decode( Claude::text( $message ), true );
		if ( 'end_turn' !== $stop || ! is_array( $data ) ) {
			$reason = 'refusal' === $stop
				? __( 'El modelo ha rechazado la petición.', 'lachinata-core' )
				: ( 'max_tokens' === $stop ? __( 'La respuesta se ha cortado (límite de tokens).', 'lachinata-core' ) : __( 'La respuesta no es el JSON pedido.', 'lachinata-core' ) );
			Queue::update(
				(int) $item['id'],
				array(
					'status' => Queue::REVIEW,
					'reason' => $reason,
					'words'  => $prepared['words'],
					'cost'   => $cost,
				)
			);
			return Queue::REVIEW;
		}
		$translations = array();
		foreach ( array_keys( $prepared['todo'] ) as $name ) {
			if ( isset( $data[ $name ] ) && is_string( $data[ $name ] ) ) {
				$translations[ $name ] = 'slug' === $name ? sanitize_title( $data[ $name ] ) : $data[ $name ];
			}
		}
		return self::apply( $item, $prepared, $translations, $cost );
	}

	/**
	 * Publishes what passes the controls and leaves the rest in «Revisar».
	 *
	 * @param array<string, mixed>                                                                                                                                                                                                                                       $item         Item.
	 * @param array{body: array<string, mixed>|null, todo: array<string, array{text: string, format: string, max: int, label: string}>, memory: array<string, string>, changed: array<string, array{text: string, format: string, max: int, label: string}>, words: int} $prepared     What was asked.
	 * @param array<string, string>                                                                                                                                                                                                                                      $translations Field → translation from the API.
	 * @param float                                                                                                                                                                                                                                                      $cost         Cost of the answer.
	 * @return string State of the item afterwards.
	 */
	public static function apply( array $item, array $prepared, array $translations, float $cost ): string {
		$type     = (string) $item['object_type'];
		$subtype  = (string) $item['object_subtype'];
		$id       = (int) $item['object_id'];
		$language = (string) $item['language'];
		$legal    = self::legal( $type, $id );
		$review   = array();
		$store    = self::OPTION === $type ? self::OPTION : $subtype;
		foreach ( $prepared['todo'] as $name => $field ) {
			$text = $translations[ $name ] ?? $prepared['memory'][ $name ] ?? null;
			if ( null === $text ) {
				$review[ $name ] = array(
					'text'   => '',
					'reason' => __( 'Sin traducción en la respuesta.', 'lachinata-core' ),
					'source' => $field['text'],
				);
				continue;
			}
			$reasons = Controls::check( $field['text'], $text, $field + array( 'name' => $name ), $language );
			if ( $legal ) {
				$reasons[] = __( 'Página legal: la publica una persona después de leerla.', 'lachinata-core' );
			}
			if ( $reasons ) {
				$review[ $name ] = array(
					'text'   => $text,
					'reason' => implode( ' ', $reasons ),
					'source' => $field['text'],
				);
				continue;
			}
			Store::put( $type, $store, $id, $name, $language, $text, Store::fingerprint( $field['text'] ), Store::AUTO, 'claude' );
			if ( 'slug' !== $name && isset( $translations[ $name ] ) ) {
				Memory::learn( $field['text'], $text, $language, 'claude' );
			}
		}
		foreach ( $prepared['changed'] as $name => $field ) {
			$review[ $name ] = array(
				'text'   => (string) Store::text( $type, $id, $name, $language ),
				'reason' => __( 'Corregida por una persona y el español ha cambiado.', 'lachinata-core' ),
				'source' => $field['text'],
			);
		}
		if ( 'option' !== $type ) {
			Availability::refresh( $type, $id );
		}
		$status = $review ? Queue::REVIEW : Queue::DONE;
		Queue::update(
			(int) $item['id'],
			array(
				'status'   => $status,
				'batch_id' => '',
				'reason'   => $review ? implode( ' · ', array_unique( array_column( $review, 'reason' ) ) ) : '',
				'proposal' => $review,
				'words'    => $prepared['words'],
				'cost'     => $cost,
			)
		);
		return $status;
	}

	/**
	 * Publishes the proposal of an item in «Revisar» (a person read it): the proposed texts,
	 * and the corrected ones as they are, now from the new Spanish.
	 *
	 * @param int $item_id Item id.
	 * @return int Fields published.
	 */
	public static function approve( int $item_id ): int {
		$item = Queue::get( $item_id );
		if ( null === $item || Queue::REVIEW !== $item['status'] ) {
			return 0;
		}
		$type      = (string) $item['object_type'];
		$id        = (int) $item['object_id'];
		$language  = (string) $item['language'];
		$sources   = self::sources( $type, (string) $item['object_subtype'], $id );
		$store     = self::OPTION === $type ? self::OPTION : (string) $item['object_subtype'];
		$published = 0;
		foreach ( Queue::proposal( $item ) as $name => $row ) {
			if ( '' === $row['text'] || ! isset( $sources[ $name ] ) ) {
				continue;
			}
			$current = Store::get( $type, $id, $language )[ $name ] ?? null;
			$edited  = null !== $current && 'person' === $current['origin'];
			Store::put( $type, $store, $id, $name, $language, $row['text'], Store::fingerprint( $sources[ $name ]['text'] ), $edited ? Store::EDITED : Store::AUTO, $edited ? 'person' : 'claude' );
			++$published;
		}
		if ( 'option' !== $type ) {
			Availability::refresh( $type, $id );
		}
		Queue::update( $item_id, array( 'status' => Queue::DONE ) );
		return $published;
	}

	/**
	 * Discards an item in «Revisar» (nothing is published).
	 *
	 * @param int $item_id Item id.
	 */
	public static function discard( int $item_id ): void {
		$item = Queue::get( $item_id );
		if ( null !== $item && Queue::REVIEW === $item['status'] ) {
			Queue::update(
				$item_id,
				array(
					'status' => Queue::DONE,
					'reason' => __( 'Descartada.', 'lachinata-core' ),
				)
			);
		}
	}

	/**
	 * «Volver a traducir» a field: the correction is dropped and the field goes first in the
	 * queue.
	 *
	 * @param string $type     Type.
	 * @param int    $id       Object id.
	 * @param string $field    Field.
	 * @param string $language Locale.
	 */
	public static function retranslate( string $type, int $id, string $field, string $language ): void {
		$subtype = self::OPTION === $type ? (string) Options::name( $id ) : (string) Fields::subtype( $type, $id );
		$current = Store::get( $type, $id, $language )[ $field ] ?? null;
		if ( '' === $subtype || null === $current ) {
			return;
		}
		Store::put( $type, self::OPTION === $type ? self::OPTION : $subtype, $id, $field, $language, $current['text'], $current['hash'], Store::OUTDATED, 'claude' );
		Queue::add( $type, $subtype, $id, $language, Queue::OUTDATED );
		Runner::kick();
	}

	/**
	 * Words of a text (without markup).
	 *
	 * @param string $text Text.
	 */
	public static function words( string $text ): int {
		$words = preg_split( '/\s+/u', trim( wp_strip_all_tags( $text ) ), -1, PREG_SPLIT_NO_EMPTY );
		return false === $words ? 0 : count( $words );
	}

	/**
	 * Whether the object of an item still exists.
	 *
	 * @param array<string, mixed> $item Item.
	 */
	private static function exists( array $item ): bool {
		$type = (string) $item['object_type'];
		if ( self::OPTION === $type ) {
			return isset( Options::all()[ (string) $item['object_subtype'] ] );
		}
		return null !== Fields::subtype( $type, (int) $item['object_id'] );
	}
}
