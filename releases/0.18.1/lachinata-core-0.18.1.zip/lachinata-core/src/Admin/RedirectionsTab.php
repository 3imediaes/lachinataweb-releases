<?php
/**
 * WooCommerce → La Chinata → Redirecciones.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Admin;

use LaChinata\Core\Redirections;

defined( 'ABSPATH' ) || exit;

/**
 * Imports a CSV into the list of redirections of the panel (Rank Math's), which has no
 * import of its own: `url`, `destino_url` and optionally `codigo`. The rules are then edited
 * there.
 */
final class RedirectionsTab {

	/**
	 * Tab id.
	 */
	public const TAB = 'redirections';

	/**
	 * Action of admin-post.php, also the nonce action.
	 */
	private const SAVE = 'lachinata_core_redirections';

	/**
	 * Largest CSV accepted.
	 */
	private const MAX_BYTES = 2 * MB_IN_BYTES;

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_filter( 'lachinata/core/admin_tabs', array( self::class, 'tab' ), 8 );
		add_action( 'admin_post_' . self::SAVE, array( self::class, 'handle' ) );
	}

	/**
	 * Adds the tab before Exportar/importar.
	 *
	 * @param array<string, array{label: string, render: callable}> $tabs Tabs.
	 * @return array<string, array{label: string, render: callable}>
	 */
	public static function tab( array $tabs ): array {
		$tab      = array(
			self::TAB => array(
				'label'  => __( 'Redirecciones', 'lachinata-core' ),
				'render' => array( self::class, 'render' ),
			),
		);
		$position = array_search( 'transfer', array_keys( $tabs ), true );
		$position = false === $position ? count( $tabs ) : $position;
		return array_slice( $tabs, 0, $position, true ) + $tab + $tabs;
	}

	/**
	 * Prints the tab.
	 */
	public static function render(): void {
		echo '<p>' . esc_html__( 'Las 301, 302 y 410 de la tienda están en la lista de redirecciones de Rank Math, donde se editan. Aquí se carga un CSV en esa lista, con las columnas url y destino_url (y, si hace falta, codigo: 301 de serie; 410 sin destino). Una dirección que ya tiene regla la conserva.', 'lachinata-core' ) . '</p>';
		if ( ! Redirections::available() ) {
			echo '<div class="notice notice-warning inline"><p>' . esc_html__( 'Activa Rank Math y su módulo de redirecciones (Rank Math → Panel → Módulos) para usar la lista.', 'lachinata-core' ) . '</p></div>';
			return;
		}
		printf( '<p><a href="%1$s">%2$s</a></p>', esc_url( admin_url( 'admin.php?page=rank-math-redirections' ) ), esc_html__( 'Abrir la lista de redirecciones', 'lachinata-core' ) );
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE ); ?>">
			<?php wp_nonce_field( self::SAVE ); ?>
			<p>
				<label for="lc-redirections-csv"><?php esc_html_e( 'Archivo CSV', 'lachinata-core' ); ?></label><br>
				<input type="file" id="lc-redirections-csv" name="lc_redirections" accept=".csv,text/csv" required>
			</p>
			<p><label><input type="checkbox" name="dry_run" value="1" checked> <?php esc_html_e( 'Solo comprobar (no añade nada)', 'lachinata-core' ); ?></label></p>
			<?php submit_button( __( 'Importar', 'lachinata-core' ) ); ?>
		</form>
		<?php
	}

	/**
	 * Imports the uploaded CSV and goes back with what happened.
	 */
	public static function handle(): void {
		Screen::check( self::SAVE );
		$file = $_FILES['lc_redirections'] ?? null; // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Screen::check(); only tmp_name, error and size are read.
		if ( ! is_array( $file ) || UPLOAD_ERR_OK !== ( $file['error'] ?? UPLOAD_ERR_NO_FILE ) || ! is_uploaded_file( (string) $file['tmp_name'] ) ) {
			Screen::flash( 'error', array( __( 'No se ha recibido ningún archivo.', 'lachinata-core' ) ) );
			Screen::redirect( self::TAB );
		}
		if ( (int) $file['size'] > self::MAX_BYTES ) {
			Screen::flash( 'error', array( __( 'El archivo es demasiado grande.', 'lachinata-core' ) ) );
			Screen::redirect( self::TAB );
		}
		$dry_run = ! empty( $_POST['dry_run'] ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Screen::check().
		$done    = Redirections::import( (string) file_get_contents( (string) $file['tmp_name'] ), $dry_run ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local uploaded file.
		$summary = sprintf(
			$dry_run
				/* translators: 1: rules that would be added, 2: addresses that already have a rule. */
				? __( 'Comprobado: se añadirían %1$s reglas; %2$s direcciones ya tienen la suya.', 'lachinata-core' )
				/* translators: 1: rules added, 2: addresses that already have a rule. */
				: __( 'Añadidas %1$s reglas; %2$s direcciones ya tenían la suya.', 'lachinata-core' ),
			number_format_i18n( $done['added'] ),
			number_format_i18n( $done['kept'] )
		);
		Screen::flash( $done['errors'] ? 'warning' : 'success', array_merge( array( $summary ), array_slice( $done['errors'], 0, 20 ) ) );
		Screen::redirect( self::TAB );
	}
}
