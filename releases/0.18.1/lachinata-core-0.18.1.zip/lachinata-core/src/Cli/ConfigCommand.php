<?php
/**
 * WP-CLI: wp lachinata export / import.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Cli;

use LaChinata\Core\Admin\Screen;
use LaChinata\Core\Config\Exporter;
use LaChinata\Core\Config\Importer;
use LaChinata\Core\Plugin;
use WP_CLI;

defined( 'ABSPATH' ) || exit;

/**
 * Copies the configuration (enabled modules and their settings) between sites.
 */
final class ConfigCommand {

	/**
	 * Exports the configuration as JSON.
	 *
	 * ## OPTIONS
	 *
	 * [--file=<file>]
	 * : Write to this file instead of the standard output.
	 *
	 * [--modules=<ids>]
	 * : Comma separated module ids. All by default.
	 *
	 * [--force]
	 * : Write over the file if it already exists.
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata export --file=lachinata-es.json
	 *
	 * @param string[]              $args       Positional arguments.
	 * @param array<string, string> $assoc_args Named arguments.
	 */
	public function export( array $args, array $assoc_args ): void {
		$only = isset( $assoc_args['modules'] ) ? array_filter( array_map( 'trim', explode( ',', $assoc_args['modules'] ) ) ) : null;
		$json = Exporter::to_json( Exporter::export( Plugin::instance()->modules(), $only ) );
		if ( empty( $assoc_args['file'] ) ) {
			WP_CLI::line( rtrim( $json ) );
			return;
		}
		Output::write( (string) $assoc_args['file'], $json, $assoc_args );
		WP_CLI::success( sprintf( 'Configuración exportada en %s.', $assoc_args['file'] ) );
	}

	/**
	 * Imports a configuration exported from another site.
	 *
	 * Shows what changes and asks before writing. Nothing is written if the file has errors.
	 *
	 * ## OPTIONS
	 *
	 * <file>
	 * : JSON file made by `wp lachinata export` or the admin screen.
	 *
	 * [--modules=<ids>]
	 * : Comma separated module ids to import. All in the file by default.
	 *
	 * [--dry-run]
	 * : Show the changes without writing them.
	 *
	 * [--yes]
	 * : Do not ask for confirmation.
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata import lachinata-es.json --dry-run
	 *
	 * @param string[]                   $args       Positional arguments.
	 * @param array<string, string|bool> $assoc_args Named arguments.
	 */
	public function import( array $args, array $assoc_args ): void {
		$file = $args[0];
		if ( ! is_readable( $file ) ) {
			WP_CLI::error( sprintf( 'No se puede leer %s.', $file ) );
		}
		$document = Importer::decode( (string) file_get_contents( $file ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local file.
		if ( null === $document ) {
			WP_CLI::error( 'El archivo no es un JSON válido.' );
		}
		$only     = isset( $assoc_args['modules'] ) && is_string( $assoc_args['modules'] ) ? array_filter( array_map( 'trim', explode( ',', $assoc_args['modules'] ) ) ) : null;
		$importer = new Importer( Plugin::instance()->modules() );
		$plan     = $importer->plan( $document, $only );

		foreach ( $plan->warnings as $warning ) {
			WP_CLI::warning( $warning );
		}
		if ( $plan->errors ) {
			foreach ( $plan->errors as $error ) {
				WP_CLI::warning( $error );
			}
			WP_CLI::error( 'No se ha importado nada.' );
		}
		if ( ! $plan->changes ) {
			WP_CLI::success( 'La configuración del archivo ya coincide con la de este sitio.' );
			return;
		}

		$rows = array_map(
			static fn( array $change ): array => array(
				'module' => $change['module'],
				'field'  => $change['field'],
				'from'   => Screen::format_value( $change['from'] ),
				'to'     => Screen::format_value( $change['to'] ),
			),
			$plan->changes
		);
		WP_CLI\Utils\format_items( 'table', $rows, array( 'module', 'field', 'from', 'to' ) );

		if ( WP_CLI\Utils\get_flag_value( $assoc_args, 'dry-run', false ) ) {
			WP_CLI::success( sprintf( 'Simulación: %s, nada escrito.', self::changes( count( $plan->changes ) ) ) );
			return;
		}
		WP_CLI::confirm( '¿Importar estos cambios?', $assoc_args );
		$importer->apply( $plan );
		WP_CLI::success( sprintf( 'Configuración importada: %s.', self::changes( count( $plan->changes ) ) ) );
	}

	/**
	 * «1 cambio», «3 cambios».
	 *
	 * @param int $count Number of changes.
	 */
	private static function changes( int $count ): string {
		return sprintf( 1 === $count ? '%d cambio' : '%d cambios', $count );
	}
}
