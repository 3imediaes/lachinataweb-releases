<?php
/**
 * WP-CLI: wp lachinata module.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Cli;

use LaChinata\Core\Config\Exporter;
use LaChinata\Core\Health;
use LaChinata\Core\Plugin;
use WP_CLI;

defined( 'ABSPATH' ) || exit;

/**
 * Lists, enables and disables modules (same as WooCommerce → La Chinata → Módulos), shows
 * their health and deletes their data. Disabling is the emergency switch without the panel
 * (also LACHINATA_DISABLE_MODULES in wp-config.php).
 */
final class ModuleCommand {

	/**
	 * Lists the modules and their state.
	 *
	 * ## OPTIONS
	 *
	 * [--format=<format>]
	 * : table, json or csv.
	 * ---
	 * default: table
	 * ---
	 *
	 * @param string[]              $args       Positional arguments.
	 * @param array<string, string> $assoc_args Named arguments.
	 */
	public function list( array $args, array $assoc_args ): void {
		$modules = Plugin::instance()->modules();
		$rows    = array();
		foreach ( $modules->all() as $id => $module ) {
			$rows[] = array(
				'id'      => $id,
				'label'   => $module->label(),
				'enabled' => in_array( $id, $modules->enabled(), true ) ? 'yes' : 'no',
				'active'  => $modules->is_active( $id ) ? 'yes' : 'no',
				'missing' => implode( ' ', $modules->missing_requirements( $module ) ),
			);
		}
		WP_CLI\Utils\format_items( $assoc_args['format'] ?? 'table', $rows, array( 'id', 'label', 'enabled', 'active', 'missing' ) );
	}

	/**
	 * Enables a module.
	 *
	 * ## OPTIONS
	 *
	 * <id>
	 * : Module id.
	 *
	 * @param string[] $args Positional arguments.
	 */
	public function enable( array $args ): void {
		$this->assert_exists( $args[0] );
		Plugin::instance()->modules()->enable( $args[0] );
		WP_CLI::success( sprintf( 'Módulo %s activado.', $args[0] ) );
	}

	/**
	 * Disables a module.
	 *
	 * ## OPTIONS
	 *
	 * <id>
	 * : Module id.
	 *
	 * @param string[] $args Positional arguments.
	 */
	public function disable( array $args ): void {
		$this->assert_exists( $args[0] );
		Plugin::instance()->modules()->disable( $args[0] );
		WP_CLI::success( sprintf( 'Módulo %s desactivado.', $args[0] ) );
	}

	/**
	 * State of each module: running, configured, credentials, last incident, data version
	 * (as in WooCommerce → Estado).
	 *
	 * ## OPTIONS
	 *
	 * [--format=<format>]
	 * : table, json or csv.
	 * ---
	 * default: table
	 * ---
	 *
	 * @param string[]              $args       Positional arguments.
	 * @param array<string, string> $assoc_args Named arguments.
	 */
	public function status( array $args, array $assoc_args ): void {
		$rows = array();
		foreach ( Health::rows() as $id => $row ) {
			$rows[] = array(
				'id'          => $id,
				'state'       => $row['state'],
				'configured'  => null === $row['configured'] ? '-' : ( $row['configured'] ? 'yes' : 'no' ),
				'credentials' => null === $row['credentials'] ? '-' : ( $row['credentials'] ? 'yes' : 'no' ),
				'data'        => $row['schema'] . '/' . $row['schema_target'],
				'incident'    => null === $row['incident'] ? '' : wp_date( 'Y-m-d H:i', $row['incident']['last'] ) . ' ' . $row['incident']['message'],
			);
		}
		WP_CLI\Utils\format_items( $assoc_args['format'] ?? 'table', $rows, array( 'id', 'state', 'configured', 'credentials', 'data', 'incident' ) );
	}

	/**
	 * Deletes a module's data (options, transients, product, term and user meta; never order
	 * meta), after writing its configuration as JSON. The module must be off.
	 *
	 * ## OPTIONS
	 *
	 * <id>
	 * : Module id.
	 *
	 * [--file=<file>]
	 * : Where to write the copy. Default: lachinata-<id>-<date>.json in the current directory.
	 *
	 * [--force]
	 * : Write the copy over the file if it already exists.
	 *
	 * [--yes]
	 * : Do not ask for confirmation.
	 *
	 * @subcommand delete-data
	 *
	 * @param string[]              $args       Positional arguments.
	 * @param array<string, string> $assoc_args Named arguments.
	 */
	public function delete_data( array $args, array $assoc_args ): void {
		$this->assert_exists( $args[0] );
		$registry = Plugin::instance()->modules();
		$module   = $registry->get( $args[0] );
		if ( null === $module || in_array( $args[0], $registry->enabled(), true ) ) {
			WP_CLI::error( sprintf( 'Apaga antes el módulo %1$s (wp lachinata module disable %1$s).', $args[0] ) );
		}
		$file = (string) ( $assoc_args['file'] ?? 'lachinata-' . $args[0] . '-' . gmdate( 'Ymd-His' ) . '.json' );
		Output::check( $file, $assoc_args );
		WP_CLI::confirm( sprintf( '¿Borrar los datos del módulo %s? Los pedidos no se tocan.', $args[0] ), $assoc_args );

		// Output::write() stops the command when it cannot write the copy: nothing is deleted then.
		Output::write( $file, Exporter::to_json( Exporter::export( $registry, array( $args[0] ) ) ), $assoc_args );
		$deleted = $registry->delete_data( $module );
		WP_CLI::success( sprintf( 'Copia en %1$s. Borradas %2$d opciones y %3$d valores de campos.', $file, $deleted['options'], $deleted['meta'] ) );
	}

	/**
	 * Stops with an error when the module does not exist.
	 *
	 * @param string $id Module id.
	 */
	private function assert_exists( string $id ): void {
		if ( null === Plugin::instance()->modules()->get( $id ) ) {
			WP_CLI::error( sprintf( 'No existe el módulo %s.', $id ) );
		}
	}
}
