<?php
/**
 * Files written by the commands.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Cli;

use WP_CLI;

defined( 'ABSPATH' ) || exit;

/**
 * A command never writes over a file that already exists unless it is asked with `--force`
 * (a report or a list of someone else in the same folder would be lost). Every command of
 * the plugin and its modules that writes to a path it is given goes through here.
 */
final class Output {

	/**
	 * Stops the command when the file exists and it was not asked with `--force` (before a
	 * long run, so it does not end in nothing).
	 *
	 * @param string               $file       Path ('' passes).
	 * @param array<string, mixed> $assoc_args Named arguments of the command (`force`).
	 */
	public static function check( string $file, array $assoc_args ): void {
		if ( '' !== $file && file_exists( $file ) && empty( $assoc_args['force'] ) ) {
			/* translators: %s: file. */
			WP_CLI::error( sprintf( __( '%s ya existe: no se sobrescribe. Elige otro nombre o añade --force.', 'lachinata-core' ), $file ) );
		}
	}

	/**
	 * Writes a file, or stops the command: when it exists without `--force`, or when it cannot
	 * be written.
	 *
	 * @param string               $file       Path.
	 * @param string               $contents   Contents.
	 * @param array<string, mixed> $assoc_args Named arguments of the command (`force`).
	 */
	public static function write( string $file, string $contents, array $assoc_args ): void {
		self::check( $file, $assoc_args );
		if ( false === file_put_contents( $file, $contents ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- WP-CLI writes to the local disk.
			/* translators: %s: file. */
			WP_CLI::error( sprintf( __( 'No se pudo escribir %s.', 'lachinata-core' ), $file ) );
		}
	}
}
