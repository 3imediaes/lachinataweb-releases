<?php
/**
 * WP-CLI: wp lachinata redirections.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Cli;

use LaChinata\Core\Redirections;
use WP_CLI;

defined( 'ABSPATH' ) || exit;

/**
 * The list of redirections of the panel (Rank Math's), as in WooCommerce → La Chinata →
 * Redirecciones.
 */
final class RedirectionsCommand {

	/**
	 * Imports a CSV (url, destino_url and optionally codigo) into the list.
	 *
	 * ## OPTIONS
	 *
	 * <file>
	 * : CSV file.
	 *
	 * [--dry-run]
	 * : Count only.
	 *
	 * @param string[]              $args       Positional arguments.
	 * @param array<string, string> $assoc_args Named arguments.
	 */
	public function import( array $args, array $assoc_args ): void {
		$file = (string) ( $args[0] ?? '' );
		if ( ! is_readable( $file ) ) {
			/* translators: %s: file. */
			WP_CLI::error( sprintf( __( 'No se puede leer %s.', 'lachinata-core' ), $file ) );
		}
		$dry_run = (bool) WP_CLI\Utils\get_flag_value( $assoc_args, 'dry-run', false );
		$done    = Redirections::import( (string) file_get_contents( $file ), $dry_run ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local file.
		foreach ( $done['errors'] as $error ) {
			WP_CLI::warning( $error );
		}
		WP_CLI::success(
			sprintf(
				$dry_run
					/* translators: 1: rules that would be added, 2: addresses that already have a rule. */
					? __( 'Comprobado: se añadirían %1$s reglas; %2$s direcciones ya tienen la suya.', 'lachinata-core' )
					/* translators: 1: rules added, 2: addresses that already have a rule. */
					: __( 'Añadidas %1$s reglas; %2$s direcciones ya tenían la suya.', 'lachinata-core' ),
				number_format_i18n( $done['added'] ),
				number_format_i18n( $done['kept'] )
			)
		);
	}
}
