<?php
/**
 * The list of redirections of the panel.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core;

defined( 'ABSPATH' ) || exit;

/**
 * The 301, 302 and 410 of the shop live in Rank Math's list (Rank Math → Redirecciones), the
 * one people edit: the modules add to it (a product deleted for good, a CSV) and read from
 * it (the same rule in each language), never a list of their own. Without Rank Math and its
 * module of redirections, nothing is added and nothing matches.
 */
final class Redirections {

	/**
	 * Rank Math's table of redirections.
	 */
	private const DB = 'RankMath\Redirections\DB';

	/**
	 * Codes a row can take.
	 */
	public const CODES = array( 301, 302, 307, 410, 451 );

	/**
	 * Whether the list is there (Rank Math with its module of redirections on).
	 */
	public static function available(): bool {
		return class_exists( self::DB ) && is_callable( array( self::DB, 'add' ) ) && is_callable( array( self::DB, 'match_redirections' ) );
	}

	/**
	 * Path of an address as the list keeps it: without the domain nor the slashes at the ends
	 * («/aceite-milagroso.html» → «aceite-milagroso.html»).
	 *
	 * @param string $url Address or path.
	 */
	public static function path( string $url ): string {
		$path = (string) wp_parse_url( $url, PHP_URL_PATH );
		$home = trim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
		$path = trim( rawurldecode( $path ), '/' );
		if ( '' !== $home && str_starts_with( $path . '/', $home . '/' ) ) {
			$path = trim( substr( $path, strlen( $home ) ), '/' );
		}
		return $path;
	}

	/**
	 * The rule of a path: {url, code} (url '' for 410 and 451), or null.
	 *
	 * @param string $url Address or path.
	 * @return array{url: string, code: int}|null
	 */
	public static function match( string $url ): ?array {
		$path = self::path( $url );
		if ( '' === $path || ! self::available() ) {
			return null;
		}
		$found = call_user_func( array( self::DB, 'match_redirections' ), $path );
		if ( ! is_array( $found ) ) {
			return null;
		}
		$code = (int) ( $found['header_code'] ?? 301 );
		return array(
			'url'  => in_array( $code, array( 410, 451 ), true ) ? '' : (string) ( $found['url_to'] ?? '' ),
			'code' => $code,
		);
	}

	/**
	 * Adds a rule, unless the path already has one. Exact comparison, active.
	 *
	 * @param string $from Address or path.
	 * @param string $to   Destination (absolute or relative to the home); '' for 410 and 451.
	 * @param int    $code Code.
	 * @return bool Whether it was added.
	 */
	public static function add( string $from, string $to, int $code = 301 ): bool {
		$path = self::path( $from );
		$gone = in_array( $code, array( 410, 451 ), true );
		if ( '' === $path || ! in_array( $code, self::CODES, true ) || ( ! $gone && '' === $to ) || ! self::available() || null !== self::match( $path ) ) {
			return false;
		}
		$to = $gone ? '' : ( wp_parse_url( $to, PHP_URL_HOST ) ? $to : home_url( '/' . ltrim( $to, '/' ) ) );
		if ( ! $gone && self::path( $to ) === $path ) {
			return false;
		}
		return (bool) call_user_func(
			array( self::DB, 'add' ),
			array(
				'sources'     => array(
					array(
						'pattern'    => $path,
						'comparison' => 'exact',
						'ignore'     => '',
					),
				),
				'url_to'      => esc_url_raw( $to ),
				'header_code' => (string) $code,
			)
		);
	}

	/**
	 * Imports a CSV into the list: columns `url` and `destino_url`, and optionally `codigo`
	 * (301 by default; 410 or 451 without a destination). A path that already has a rule
	 * keeps it.
	 *
	 * @param string $csv     Contents.
	 * @param bool   $dry_run Count only.
	 * @return array{added: int, kept: int, errors: string[]}
	 */
	public static function import( string $csv, bool $dry_run = false ): array {
		$out = array(
			'added'  => 0,
			'kept'   => 0,
			'errors' => array(),
		);
		if ( ! self::available() ) {
			$out['errors'][] = __( 'Hace falta Rank Math con su módulo de redirecciones.', 'lachinata-core' );
			return $out;
		}
		$lines = preg_split( '/\r\n|\r|\n/', trim( $csv ) );
		$lines = false === $lines ? array() : $lines;
		$head  = array_map( static fn( $cell ): string => strtolower( trim( (string) $cell, " \t\"\u{FEFF}" ) ), str_getcsv( (string) array_shift( $lines ), ',', '"', '' ) );
		$from  = array_search( 'url', $head, true );
		$to    = array_search( 'destino_url', $head, true );
		$code  = array_search( 'codigo', $head, true );
		if ( false === $from || false === $to ) {
			$out['errors'][] = __( 'El CSV necesita las columnas url y destino_url.', 'lachinata-core' );
			return $out;
		}
		foreach ( $lines as $number => $line ) {
			if ( '' === trim( $line ) ) {
				continue;
			}
			$cells  = str_getcsv( $line, ',', '"', '' );
			$source = trim( (string) ( $cells[ $from ] ?? '' ) );
			$target = trim( (string) ( $cells[ $to ] ?? '' ) );
			$status = false !== $code && '' !== trim( (string) ( $cells[ $code ] ?? '' ) ) ? (int) $cells[ $code ] : ( '' === $target ? 0 : 301 );
			$gone   = in_array( $status, array( 410, 451 ), true );
			if ( '' === self::path( $source ) || ! in_array( $status, self::CODES, true ) || ( ! $gone && '' === $target ) ) {
				/* translators: 1: line number, 2: line. */
				$out['errors'][] = sprintf( __( 'Línea %1$d sin dirección, destino o código válido: %2$s', 'lachinata-core' ), $number + 2, $line );
				continue;
			}
			if ( null !== self::match( $source ) ) {
				++$out['kept'];
				continue;
			}
			if ( $dry_run || self::add( $source, $target, $status ) ) {
				++$out['added'];
			} else {
				/* translators: 1: line number, 2: line. */
				$out['errors'][] = sprintf( __( 'Línea %1$d no se ha podido añadir (¿apunta a sí misma?): %2$s', 'lachinata-core' ), $number + 2, $line );
			}
		}
		return $out;
	}
}
