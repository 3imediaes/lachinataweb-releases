<?php
/**
 * The `lachinata` object of an order in WooCommerce's REST API.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Rest;

defined( 'ABSPATH' ) || exit;

/**
 * Everything La Chinata adds to an order, in one object `lachinata` of the order in the REST
 * API (`wc/v3/orders`, and the order webhooks, which use the same response), for Odoo
 * (docs/api-odoo.md). WooCommerce's own fields are left as they are.
 *
 * Every key is always there, `null` when it does not apply or its module is off, so the
 * shape never changes: `invoice` and `newsletter` (module checkout), `delivery` (eta),
 * `shipping` (the core, from the order's shipping line; `carrier` from the odoo module, `live`
 * from the shipping module) and
 * `gift` (module gift). Modules fill theirs with `lachinata/rest/order`.
 */
final class OrderData {

	/**
	 * Version of the object: it changes only when a key changes meaning or is removed.
	 */
	public const VERSION = 1;

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_filter( 'woocommerce_rest_prepare_shop_order_object', array( self::class, 'prepare' ), 10, 2 );
	}

	/**
	 * Adds `lachinata` to an order of the REST API.
	 *
	 * @param mixed $response Response.
	 * @param mixed $order    Order.
	 * @return mixed
	 */
	public static function prepare( $response, $order ): mixed {
		if ( $response instanceof \WP_REST_Response && $order instanceof \WC_Order ) {
			$data              = (array) $response->get_data();
			$data['lachinata'] = self::of( $order );
			$response->set_data( $data );
		}
		return $response;
	}

	/**
	 * The object of an order.
	 *
	 * @param \WC_Order $order Order.
	 * @return array<string, mixed>
	 */
	public static function of( \WC_Order $order ): array {
		$keys = array(
			'version'    => self::VERSION,
			'invoice'    => null,
			'newsletter' => null,
			'delivery'   => null,
			'shipping'   => self::shipping( $order ),
			'gift'       => null,
			'shipment'   => null,
			'bodega'     => null,
		);

		/**
		 * The `lachinata` object of an order in the REST API. Each module fills its key
		 * (checkout: invoice; newsletter: newsletter; eta: delivery; shipping: shipping.live; gift: gift;
		 * shipment: shipment; bodega: bodega, since 0.18.0).
		 * Keys are never removed: a module that has nothing to say leaves `null`.
		 *
		 * @since 0.6.1
		 *
		 * @param array<string, mixed> $data  Object, with every key.
		 * @param \WC_Order            $order Order.
		 */
		$data = (array) apply_filters( 'lachinata/rest/order', $keys, $order );
		return array_merge( $keys, array_intersect_key( $data, $keys ) );
	}

	/**
	 * The shipping line of the order (La Chinata sends one package): the method and the
	 * instance Odoo maps to a carrier, its title and price. Null without shipping.
	 *
	 * @param \WC_Order $order Order.
	 * @return array{method_id: string, instance_id: int, title: string, total: string, carrier: string|null, live: null}|null
	 */
	private static function shipping( \WC_Order $order ): ?array {
		$line = current( $order->get_items( 'shipping' ) );
		if ( ! $line instanceof \WC_Order_Item_Shipping ) {
			return null;
		}
		return array(
			'method_id'   => $line->get_method_id(),
			'instance_id' => (int) $line->get_instance_id(),
			'title'       => $line->get_method_title(),
			'total'       => wc_format_decimal( $line->get_total(), wc_get_price_decimals() ),
			'carrier'     => self::carrier( $order ),
			'live'        => null,
		);
	}

	/**
	 * Name of the carrier that takes the order («Correos Express»), or null when nobody knows
	 * it. Informative: Odoo maps the carrier from `instance_id` itself.
	 *
	 * @param \WC_Order $order Order.
	 */
	public static function carrier( \WC_Order $order ): ?string {
		$line = current( $order->get_items( 'shipping' ) );
		if ( ! $line instanceof \WC_Order_Item_Shipping ) {
			return null;
		}

		/**
		 * Name of the carrier of an order, from its shipping instance (module `odoo`: the map
		 * instance → carrier of WooCommerce → La Chinata → Odoo).
		 *
		 * @since 0.7.0
		 *
		 * @param string|null $carrier     Carrier name, null when unknown.
		 * @param int         $instance_id Shipping instance id.
		 * @param \WC_Order   $order       Order.
		 */
		$carrier = apply_filters( 'lachinata/order/carrier', null, (int) $line->get_instance_id(), $order );
		return is_string( $carrier ) && '' !== trim( $carrier ) ? trim( $carrier ) : null;
	}
}
