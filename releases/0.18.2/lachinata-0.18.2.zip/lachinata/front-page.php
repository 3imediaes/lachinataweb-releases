<?php
/**
 * Home. Editorial blocks come from the front page content (theme patterns): what is
 * before the «More» block goes on top (hero, campaign) and what is after it at the end
 * (history, oleotecas). Between them, the sections the catalog fills: category tiles,
 * UspBar, TOP 10 and one section per category.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

get_header();

$lachinata_top    = '';
$lachinata_bottom = '';
if ( have_posts() ) {
	the_post();
	$lachinata_parts  = get_extended( (string) get_post_field( 'post_content', get_the_ID() ) );
	$lachinata_top    = (string) apply_filters( 'the_content', $lachinata_parts['main'] ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core hook.
	$lachinata_bottom = '' !== trim( $lachinata_parts['extended'] ) ? (string) apply_filters( 'the_content', $lachinata_parts['extended'] ) : ''; // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core hook.
}
$lachinata_tree = lachinata_category_tree();

if ( ! str_contains( $lachinata_top, '<h1' ) ) {
	echo '<h1 class="screen-reader-text">' . esc_html( lachinata_shop_name() ) . '</h1>';
}
?>
<div class="lc-home">
	<?php if ( $lachinata_top ) : ?>
		<div class="lc-home__content lc-blocks"><?php echo $lachinata_top; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the_content. ?></div>
	<?php endif; ?>

	<?php if ( $lachinata_tree ) : ?>
		<section class="lc-container lc-home__tiles" aria-label="<?php esc_attr_e( 'Categorías', 'lachinata' ); ?>">
			<div class="lc-tiles">
				<?php foreach ( $lachinata_tree as $lachinata_index => $lachinata_cat ) : ?>
					<?php
					lachinata_part(
						'category-tile',
						array(
							'title' => lachinata_term_name( $lachinata_cat['term'] ),
							'href'  => lachinata_term_url( $lachinata_cat['term'] ),
							'tint'  => $lachinata_cat['tint'],
							'big'   => 0 === $lachinata_index,
							'text'  => 0 === $lachinata_index ? implode( ', ', wp_list_pluck( array_slice( $lachinata_cat['children'], 0, 4 ), 'name' ) ) : '',
						)
					);
					?>
				<?php endforeach; ?>
			</div>
		</section>
	<?php endif; ?>

	<?php lachinata_part( 'usp-bar', array( 'class' => 'lc-home__usp' ) ); ?>

	<?php
	$lachinata_top10 = wc_get_products(
		array(
			'status'     => 'publish',
			'visibility' => 'catalog',
			'limit'      => 10,
			'orderby'    => 'popularity',
			'order'      => 'DESC',
		)
	);
	?>
	<?php if ( $lachinata_top10 ) : ?>
		<section class="lc-block lc-container" aria-labelledby="lc-top10">
			<?php
			lachinata_part(
				'section-header',
				array(
					'eyebrow' => __( 'Lo más vendido', 'lachinata' ),
					'title'   => __( 'TOP 10', 'lachinata' ),
					'id'      => 'lc-top10',
					'more'    => __( 'Ver todo', 'lachinata' ),
					'href'    => add_query_arg( 'orderby', 'popularity', wc_get_page_permalink( 'shop' ) ),
				)
			);
			?>
			<div class="lc-carousel">
				<?php foreach ( array_values( $lachinata_top10 ) as $lachinata_index => $lachinata_product ) : ?>
					<?php
					lachinata_part(
						'product-card',
						array(
							'product' => $lachinata_product,
							'list'    => array(
								'id'    => 'home_top10',
								'name'  => __( 'TOP 10', 'lachinata' ),
								'index' => $lachinata_index + 1,
							),
						)
					);
					?>
				<?php endforeach; ?>
			</div>
		</section>
	<?php endif; ?>

	<?php
	/**
	 * Categories that get their own section on the home (all top-level ones by default).
	 *
	 * @since 0.2.0
	 *
	 * @param array<int, array{term: WP_Term, tint: string, children: WP_Term[]}> $sections Category tree.
	 */
	$lachinata_sections = (array) apply_filters( 'lachinata/home/category_sections', $lachinata_tree );
	foreach ( $lachinata_sections as $lachinata_cat ) :
		$lachinata_term     = $lachinata_cat['term'];
		$lachinata_products = wc_get_products(
			array(
				'status'     => 'publish',
				'visibility' => 'catalog',
				'limit'      => 4,
				'category'   => array( $lachinata_term->slug ),
				'orderby'    => 'popularity',
				'order'      => 'DESC',
			)
		);
		if ( ! $lachinata_products ) {
			continue;
		}
		?>
		<section class="lc-block lc-container lc-home__category" aria-labelledby="lc-home-cat-<?php echo esc_attr( (string) $lachinata_term->term_id ); ?>">
			<?php
			lachinata_part(
				'section-header',
				array(
					'title' => lachinata_term_name( $lachinata_term ),
					'id'    => 'lc-home-cat-' . $lachinata_term->term_id,
					/* translators: %s: number of products. */
					'more'  => sprintf( __( 'Ver los %s', 'lachinata' ), number_format_i18n( (int) $lachinata_term->count ) ),
					'href'  => lachinata_term_url( $lachinata_term ),
				)
			);
			?>
			<?php if ( $lachinata_cat['children'] ) : ?>
				<div class="lc-home__lines">
					<?php foreach ( array_slice( $lachinata_cat['children'], 0, 2 ) as $lachinata_child ) : ?>
						<?php
						lachinata_part(
							'category-tile',
							array(
								'title'    => lachinata_term_name( $lachinata_child ),
								'href'     => lachinata_term_url( $lachinata_child ),
								'tint'     => $lachinata_cat['tint'],
								'photo_id' => (int) get_term_meta( $lachinata_child->term_id, 'thumbnail_id', true ),
								'cta'      => __( 'Ver la línea', 'lachinata' ),
							)
						);
						?>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
			<div class="lc-grid lc-home__grid">
				<?php foreach ( array_values( $lachinata_products ) as $lachinata_index => $lachinata_product ) : ?>
					<?php
					lachinata_part(
						'product-card',
						array(
							'product' => $lachinata_product,
							'tint'    => $lachinata_cat['tint'],
							'list'    => array(
								'id'    => 'home_category_' . $lachinata_term->term_id,
								'name'  => lachinata_term_name( $lachinata_term ),
								'index' => $lachinata_index + 1,
							),
						)
					);
					?>
				<?php endforeach; ?>
			</div>
			<div class="lc-home__all">
				<?php
				echo lachinata_button(
					__( 'Ver todos los productos', 'lachinata' ),
					array(
						'variant' => 'secondary',
						'block'   => true,
						'icon'    => 'arrow-right',
						'href'    => lachinata_term_url( $lachinata_term ),
					)
				); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped 
				?>
			</div>
		</section>
	<?php endforeach; ?>

	<?php if ( $lachinata_bottom ) : ?>
		<div class="lc-home__content lc-blocks"><?php echo $lachinata_bottom; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- the_content. ?></div>
	<?php endif; ?>
</div>
<?php
get_footer();
