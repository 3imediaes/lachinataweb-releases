<?php
/**
 * The bag: one markup for the /bolsa/ page (works without JavaScript through
 * WooCommerce's classic cart form handler) and for the BottomSheet, which loads the same
 * markup as a fragment (?lc-partial=cart) so cached pages never carry anyone's bag.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Whether the request asks for the bag fragment.
 */
function lachinata_is_cart_partial(): bool {
	return isset( $_REQUEST['lc-partial'] ) && 'cart' === $_REQUEST['lc-partial']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only switch of the template.
}

/**
 * Renders the bag page (or its fragment) whatever the cart page content is.
 *
 * @param string $template Template.
 */
function lachinata_cart_template( string $template ): string {
	if ( ! function_exists( 'is_cart' ) || ! is_cart() ) {
		return $template;
	}
	return get_template_directory() . ( lachinata_is_cart_partial() ? '/templates/cart-partial.php' : '/templates/cart-page.php' );
}
add_filter( 'template_include', 'lachinata_cart_template', 20 );

/**
 * Keeps the fragment mode across WooCommerce's redirects after an action of the bag: any
 * action asked with ?lc-partial=cart answers with the bag. WooCommerce sends removing,
 * undoing and removing a coupon back to the page they came from (the referer: a product
 * page when the sheet is open there), which has no bag form.
 *
 * @param string $location Redirect URL.
 */
function lachinata_cart_partial_redirect( string $location ): string {
	if ( ! lachinata_is_cart_partial() || ! function_exists( 'wc_get_cart_url' ) ) {
		return $location;
	}
	$cart = wc_get_cart_url();
	if ( ! str_starts_with( $location, $cart ) ) {
		// Only removed_item, which keeps «Deshacer» alive; never an action to repeat.
		wp_parse_str( (string) wp_parse_url( $location, PHP_URL_QUERY ), $query );
		$location = isset( $query['removed_item'] ) ? add_query_arg( 'removed_item', '1', $cart ) : $cart;
	}
	return add_query_arg( 'lc-partial', 'cart', $location );
}
add_filter( 'wp_redirect', 'lachinata_cart_partial_redirect' );

/**
 * «Añadido a tu bolsa» message with the system wording.
 *
 * @param string            $message  Default HTML.
 * @param array<int, float> $products Product id => quantity.
 */
function lachinata_added_to_cart_message( string $message, array $products ): string {
	$names = array();
	foreach ( array_keys( $products ) as $product_id ) {
		$names[] = '«' . wp_strip_all_tags( get_the_title( $product_id ) ) . '»';
	}
	return esc_html(
		sprintf(
			/* translators: %s: product names. */
			_n( 'Has añadido %s a tu bolsa.', 'Has añadido %s a tu bolsa.', count( $names ), 'lachinata' ),
			wp_sprintf_l( '%l', $names )
		)
	);
}
add_filter( 'wc_add_to_cart_message_html', 'lachinata_added_to_cart_message', 10, 2 );

/**
 * Data of one cart line for the CartLine component.
 *
 * @param string               $key  Cart item key.
 * @param array<string, mixed> $item Cart item.
 * @return array<string, mixed>|null
 */
function lachinata_cart_line( string $key, array $item ): ?array {
	$product = $item['data'] ?? null;
	if ( ! $product instanceof WC_Product || ! $product->exists() || $item['quantity'] <= 0 ) {
		return null;
	}
	$parent = $product->is_type( 'variation' ) ? wc_get_product( $product->get_parent_id() ) : $product;
	$meta   = wp_strip_all_tags( wc_get_formatted_cart_item_data( $item, true ) );
	$unit   = lachinata_unit_price( $product );
	$max    = $product->get_max_purchase_quantity();
	/**
	 * Note under a cart line (for example «No se envía a Alemania»). Empty by default.
	 *
	 * @since 0.2.0
	 *
	 * @param string               $note Note text.
	 * @param array<string, mixed> $item Cart item.
	 */
	$note = (string) apply_filters( 'lachinata/cart/line_note', '', $item );

	return array(
		'key'      => $key,
		'name'     => $product->get_name(),
		'href'     => $product->is_visible() ? ( $product instanceof WC_Product_Variation ? $product->get_permalink( $item ) : $product->get_permalink() ) : '',
		'image_id' => (int) ( $product->get_image_id() ? $product->get_image_id() : ( $parent ? $parent->get_image_id() : 0 ) ),
		'tint'     => $parent ? lachinata_product_tint( $parent ) : '',
		'meta'     => trim( implode( ' · ', array_filter( array( str_replace( "\n", ' · ', trim( $meta ) ), wp_strip_all_tags( $unit ) ) ) ) ),
		'note'     => $note,
		'qty'      => (int) $item['quantity'],
		'max'      => $max > 0 ? $max : 99,
		'total'    => WC()->cart->get_product_subtotal( $product, $item['quantity'] ),
		'remove'   => wc_get_cart_remove_url( $key ),
		'sold_one' => $product->is_sold_individually(),
	);
}

/**
 * WooCommerce's classic texts that say «carrito», in the system's words («bolsa», tú):
 * notices of the bag without JavaScript, stock limits, restored orders and the labels of its
 * templates. Keyed by WooCommerce's original text; the theme's string is the one translated
 * into each language. Rebuilt when the language changes (an email in another language).
 *
 * @return array<string, string|array{0: array{0: string, 1: string, singular: string, plural: string, context: null, domain: string|null}}>
 */
function lachinata_woocommerce_strings(): array {
	static $strings = array();
	$locale         = determine_locale();
	if ( isset( $strings[ $locale ] ) ) {
		return $strings[ $locale ];
	}
	$strings[ $locale ] = array(
		'View cart'                                        => __( 'Ver bolsa', 'lachinata' ),
		'Update cart'                                      => __( 'Actualizar bolsa', 'lachinata' ),
		'Cart updated.'                                    => __( 'Bolsa actualizada.', 'lachinata' ),
		/* translators: %s: product name in quotes. */
		'%s removed.'                                      => __( '%s ha salido de tu bolsa.', 'lachinata' ),
		'Undo?'                                            => __( 'Deshacer', 'lachinata' ),
		'Cart totals'                                      => __( 'Total de la bolsa', 'lachinata' ),
		'Add to cart'                                      => __( 'Añadir a la bolsa', 'lachinata' ),
		'No products in the cart.'                         => __( 'Tu bolsa está vacía.', 'lachinata' ),
		'Your cart is currently empty.'                    => __( 'Tu bolsa está vacía.', 'lachinata' ),
		/* translators: %s: product name. */
		'Add to cart: &ldquo;%s&rdquo;'                    => __( 'Añadir a la bolsa: «%s»', 'lachinata' ),
		/* translators: %s: product name. */
		'Remove %s from cart'                              => __( 'Quitar %s de la bolsa', 'lachinata' ),
		/* translators: %s: product name. */
		'&ldquo;%s&rdquo; has been added to your cart'     => __( '«%s» se ha añadido a tu bolsa', 'lachinata' ),
		/* translators: %s: product name. */
		'&ldquo;%s&rdquo; has been removed from your cart' => __( '«%s» ha salido de tu bolsa', 'lachinata' ),
		/* translators: %s: product name. */
		'You cannot add another "%s" to your cart.'        => __( 'No puedes añadir otro «%s» a tu bolsa.', 'lachinata' ),
		/* translators: %s: product name. */
		'You can only have 1 %s in your cart.'             => __( 'Solo puedes tener 1 %s en tu bolsa.', 'lachinata' ),
		/* translators: %s: product name. */
		'You cannot add &quot;%s&quot; to the cart because the product is out of stock.' => __( 'No puedes añadir «%s» a la bolsa porque está agotado.', 'lachinata' ),
		/* translators: 1: units in stock, 2: units already in the bag. */
		'You cannot add that amount to the cart &mdash; we have %1$s in stock and you already have %2$s in your cart.' => __( 'No puedes añadir esa cantidad: nos quedan %1$s y ya tienes %2$s en tu bolsa.', 'lachinata' ),
		/* translators: 1: product name, 2: units in stock. */
		'You cannot add that amount of &quot;%1$s&quot; to the cart because there is not enough stock (%2$s remaining).' => __( 'No puedes añadir esa cantidad de «%1$s» a la bolsa: solo nos quedan %2$s.', 'lachinata' ),
		/* translators: %s: product name. */
		'Sorry, "%s" is not in stock. Please edit your cart and try again. We apologize for any inconvenience caused.' => __( '«%s» está agotado. Cambia tu bolsa y vuelve a intentarlo.', 'lachinata' ),
		/* translators: %s: product name. */
		'%s has been removed from your cart because it can no longer be purchased. Please contact us if you need assistance.' => __( '%s ha salido de tu bolsa porque ya no se puede comprar. Si necesitas ayuda, escríbenos.', 'lachinata' ),
		/* translators: 1: product name, 2: link to add it again. */
		'%1$s has been removed from your cart because it has since been modified. You can add it back to your cart <a href="%2$s">here</a>.' => __( '%1$s ha salido de tu bolsa porque ha cambiado. Puedes <a href="%2$s">volver a añadirlo</a>.', 'lachinata' ),
		'An item which is no longer available was removed from your cart.' => __( 'Hemos quitado de tu bolsa un producto que ya no está disponible.', 'lachinata' ),
		'Please choose a product to add to your cart&hellip;' => __( 'Elige un producto para añadirlo a tu bolsa…', 'lachinata' ),
		'Please choose the quantity of items you wish to add to your cart&hellip;' => __( 'Elige cuántas unidades quieres añadir a tu bolsa…', 'lachinata' ),
		'The cart has been filled with the items from your previous order.' => __( 'Hemos puesto en tu bolsa los productos de tu pedido anterior.', 'lachinata' ),
		/* translators: %s: coupon code. */
		'Coupon "%s" cannot be applied because it is not valid.' => __( 'El cupón «%s» no es válido.', 'lachinata' ),
		/* translators: %s: coupon code. */
		'Coupon "%s" cannot be applied because it does not exist.' => __( 'El cupón «%s» no existe.', 'lachinata' ),
		/* translators: %s: coupon code. */
		'Sorry, it seems the coupon "%s" is invalid - it has now been removed from your order.' => __( 'El cupón «%s» ya no es válido y lo hemos quitado de tu pedido.', 'lachinata' ),
		/* translators: %s: coupon code. */
		'Please enter a valid email to use coupon code "%s".' => __( 'Escribe un correo válido para usar el cupón «%s».', 'lachinata' ),
		/* translators: %s: coupon code. */
		'Please enter a valid email at checkout to use coupon code "%s".' => __( 'Al finalizar la compra, escribe un correo válido para usar el cupón «%s».', 'lachinata' ),
		/* translators: %s: coupon code. */
		'Coupon code "%s" already applied!'                => __( 'Ya has aplicado el cupón «%s».', 'lachinata' ),
		/* translators: %s: coupon code. */
		'Sorry, coupon "%s" has already been applied and cannot be used in conjunction with other coupons.' => __( 'Ya tienes el cupón «%s», que no se puede combinar con otros.', 'lachinata' ),
		/* translators: %s: coupon code. */
		'Usage limit for coupon "%s" has been reached.'    => __( 'El cupón «%s» ya no tiene usos disponibles.', 'lachinata' ),
		/* translators: %s: coupon code. */
		'Usage limit for coupon "%s" has been reached. Please try again after some time, or contact us for help.' => __( 'El cupón «%s» ya no tiene usos disponibles. Vuelve a intentarlo más tarde o escríbenos.', 'lachinata' ),
		/* translators: %s: coupon code. */
		'Coupon "%s" has expired.'                         => __( 'El cupón «%s» ha caducado.', 'lachinata' ),
		/* translators: %s: coupon code. */
		'Sorry, coupon "%s" is not applicable to your cart contents.' => __( 'El cupón «%s» no vale para lo que hay en tu bolsa.', 'lachinata' ),
		/* translators: %s: coupon code. */
		'Sorry, coupon "%s" is not applicable to selected products.' => __( 'El cupón «%s» no vale para los productos de tu bolsa.', 'lachinata' ),
		/* translators: %s: coupon code. */
		'Sorry, coupon "%s" is not valid for sale items.'  => __( 'El cupón «%s» no vale para productos rebajados.', 'lachinata' ),
		'%s has been added to your cart.'                  => array(
			/* translators: %s: product names. */
			_n_noop( '%s se ha añadido a tu bolsa.', '%s se han añadido a tu bolsa.', 'lachinata' ),
		),
		'%d item from your previous order is currently unavailable and could not be added to your cart.' => array(
			/* translators: %d: number of products. */
			_n_noop( '%d producto de tu pedido anterior no está disponible y no se ha añadido a tu bolsa.', '%d productos de tu pedido anterior no están disponibles y no se han añadido a tu bolsa.', 'lachinata' ),
		),
	);
	return $strings[ $locale ];
}

/**
 * A text of WooCommerce in the system's words.
 *
 * @param string $translation Translation of WooCommerce.
 * @param string $text        Original text.
 */
function lachinata_woocommerce_gettext( string $translation, string $text ): string {
	$own = lachinata_woocommerce_strings()[ $text ] ?? null;
	return is_string( $own ) ? $own : $translation;
}
add_filter( 'gettext_woocommerce', 'lachinata_woocommerce_gettext', 10, 2 );

/**
 * The product name in quotes of WooCommerce's notices («Deshacer» after removing), with
 * Spanish quotes.
 *
 * @param string $translation Translation of WooCommerce.
 * @param string $text        Original text.
 * @param string $context     Context.
 */
function lachinata_woocommerce_gettext_context( string $translation, string $text, string $context ): string {
	if ( '&ldquo;%s&rdquo;' !== $text || 'Item name in quotes' !== $context ) {
		return $translation;
	}
	/* translators: %s: product name. */
	return _x( '«%s»', 'Item name in quotes', 'lachinata' );
}
add_filter( 'gettext_with_context_woocommerce', 'lachinata_woocommerce_gettext_context', 10, 3 );

/**
 * A text of WooCommerce with plural forms in the system's words.
 *
 * @param string $translation Translation of WooCommerce.
 * @param string $single      Original singular.
 * @param string $plural      Original plural.
 * @param int    $number      Number.
 */
function lachinata_woocommerce_ngettext( string $translation, string $single, string $plural, int $number ): string {
	unset( $plural );
	$own = lachinata_woocommerce_strings()[ $single ] ?? null;
	return is_array( $own ) ? translate_nooped_plural( $own[0], $number, 'lachinata' ) : $translation;
}
add_filter( 'ngettext_woocommerce', 'lachinata_woocommerce_ngettext', 10, 4 );
