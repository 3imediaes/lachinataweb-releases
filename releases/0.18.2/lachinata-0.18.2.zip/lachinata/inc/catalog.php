<?php
/**
 * Catalog data as the templates need it. Everything that changes between stores
 * (tints, unit price, tabs, seals, badges) comes through lachinata/… filters with a
 * neutral default, so the theme works with plain WooCommerce.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Tint of a product category ('' = no tint, surface-2 / surface-3 backgrounds).
 *
 * @param WP_Term $term Category.
 */
function lachinata_category_tint( WP_Term $term ): string {
	/**
	 * Tint of a product category: cosmetica, aceites, gourmet, regalos, hogar or ''.
	 *
	 * @since 0.2.0
	 *
	 * @param string  $tint Tint ('' by default).
	 * @param WP_Term $term Category.
	 */
	return (string) apply_filters( 'lachinata/category/tint', '', $term );
}

/**
 * Tint of a product.
 *
 * @param WC_Product $product Product.
 */
function lachinata_product_tint( WC_Product $product ): string {
	/**
	 * Tint of a product, used behind its photo and in the cart line.
	 *
	 * @since 0.2.0
	 *
	 * @param string     $tint    Tint ('' by default).
	 * @param WC_Product $product Product.
	 */
	return (string) apply_filters( 'lachinata/product/tint', '', $product );
}

/**
 * Content of a product as written on its label: «500 ml», «300 g».
 *
 * @param WC_Product $product Product or variation.
 */
function lachinata_product_content( WC_Product $product ): string {
	/**
	 * Content of a product («500 ml»), shown in the order lines of the emails.
	 *
	 * @since 0.8.0
	 *
	 * @param string     $content Content ('' by default).
	 * @param WC_Product $product Product or variation.
	 */
	return (string) apply_filters( 'lachinata/product/content', '', $product );
}

/**
 * Unit price line: «500 ml | 9,33 € / 1 l».
 *
 * @param WC_Product $product Product or variation.
 * @return string HTML.
 */
function lachinata_unit_price( WC_Product $product ): string {
	/**
	 * Content and price per reference quantity of a product or variation.
	 *
	 * @since 0.2.0
	 *
	 * @param string     $html    HTML ('' by default: nothing is shown).
	 * @param WC_Product $product Product or variation.
	 */
	return (string) apply_filters( 'lachinata/product/unit_price', '', $product );
}

/**
 * Format line of a product card: the unit price, or what a module puts instead («6
 * productos · Caja de regalo» for a composite gift).
 *
 * @param WC_Product $product Product.
 * @return string HTML.
 */
function lachinata_card_meta( WC_Product $product ): string {
	/**
	 * Format line of a product card.
	 *
	 * @since 0.16.0
	 *
	 * @param string     $html    HTML (the unit price by default).
	 * @param WC_Product $product Product.
	 */
	return (string) apply_filters( 'lachinata/product_card/meta', lachinata_unit_price( $product ), $product );
}

/**
 * A composite gift (box, basket, bucket, case): what it holds, its presentation, the
 * allergens of the set and its dimensions and weight from WooCommerce. Null when the
 * product is not one.
 *
 * @param WC_Product $product Product.
 * @return array{count: int, presentation: string, items: array<int, array{name: string, meta: string, qty: int, image_id: int, tint: string, href: string, description: string, ingredients: string, allergens: string}>, allergens: string, traces: string, dimensions: string, weight: string}|null
 */
function lachinata_product_gift( WC_Product $product ): ?array {
	/**
	 * What a composite gift holds. Null by default (not a gift). Items without prices: the
	 * gift is bought whole.
	 *
	 * @since 0.16.0
	 *
	 * @param array|null $gift    `count` (units), `presentation`, `items` (`name`, `meta`, `qty`, `image_id`, `tint`, `href` ('' without a page), `description`, `ingredients` (HTML), `allergens`), `allergens` and `traces` of the set.
	 * @param WC_Product $product Product.
	 */
	$gift = apply_filters( 'lachinata/product/gift', null, $product );
	if ( ! is_array( $gift ) || empty( $gift['items'] ) || ! is_array( $gift['items'] ) ) {
		return null;
	}
	$items = array();
	foreach ( $gift['items'] as $item ) {
		$item    = is_array( $item ) ? $item : array();
		$items[] = array(
			'name'        => (string) ( $item['name'] ?? '' ),
			'meta'        => (string) ( $item['meta'] ?? '' ),
			'qty'         => max( 1, (int) ( $item['qty'] ?? 1 ) ),
			'image_id'    => (int) ( $item['image_id'] ?? 0 ),
			'tint'        => sanitize_key( (string) ( $item['tint'] ?? '' ) ),
			'href'        => (string) ( $item['href'] ?? '' ),
			'description' => (string) ( $item['description'] ?? '' ),
			'ingredients' => (string) ( $item['ingredients'] ?? '' ),
			'allergens'   => (string) ( $item['allergens'] ?? '' ),
		);
	}
	return array(
		'count'        => (int) ( $gift['count'] ?? array_sum( array_column( $items, 'qty' ) ) ),
		'presentation' => (string) ( $gift['presentation'] ?? '' ),
		'items'        => $items,
		'allergens'    => (string) ( $gift['allergens'] ?? '' ),
		'traces'       => (string) ( $gift['traces'] ?? '' ),
		'dimensions'   => $product->has_dimensions() ? html_entity_decode( wp_strip_all_tags( wc_format_dimensions( $product->get_dimensions( false ) ) ), ENT_QUOTES, 'UTF-8' ) : '',
		'weight'       => $product->has_weight() ? wc_format_weight( (float) $product->get_weight() ) : '',
	);
}

/**
 * The wine page of a product (module bodega), or null when it is not a wine.
 *
 * @param WC_Product $product Product.
 * @return array<string, mixed>|null
 */
function lachinata_product_wine( WC_Product $product ): ?array {
	/**
	 * Data of a wine page: `eyebrow`, `subtitle` (winery and «Tinto crianza»), `vintage`
	 * (slug of the one the page opens with), `vintages` (slug → name), `scores` (slug →
	 * WineScores badges), `facts` (label, value, key), `variations` (id → `vintage`,
	 * `name`, `counts`, `facts`, `one`, `case`, `save`), `allergens`, `tasting`, `pairing`
	 * (`dishes`, `products`, `wine`), `winery` (`name`, `text`, `href`, `products`),
	 * `label` (`ingredients`, `nutrition`, `url`), `case` (CaseSelector) and `age`. Null
	 * by default: the product page of every product.
	 *
	 * @since 0.18.0
	 *
	 * @param array<string, mixed>|null $wine    Wine data.
	 * @param WC_Product                $product Product.
	 */
	$wine = apply_filters( 'lachinata/product/wine', null, $product );
	return is_array( $wine ) ? $wine : null;
}

/**
 * Age notice of a product with alcohol («Venta solo a mayores de 18 años…»), or ''.
 *
 * @param WC_Product $product Product.
 */
function lachinata_product_age_notice( WC_Product $product ): string {
	/**
	 * Text of the age notice of a product (AgeNotice). Empty by default (no notice).
	 *
	 * @since 0.18.0
	 *
	 * @param string     $text    Text.
	 * @param WC_Product $product Product.
	 */
	return (string) apply_filters( 'lachinata/product/age_notice', '', $product );
}

/**
 * «¿Es para tu empresa?» under «Añadir a la bolsa», or null.
 *
 * @param WC_Product $product Product.
 * @return array{href: string, title: string, text: string, cta: string, min: int, sku: string, channel: string}|null
 */
function lachinata_product_bulk_cta( WC_Product $product ): ?array {
	/**
	 * Link to ask for a quote for business gifts (BulkCta). Null by default (not shown).
	 *
	 * @since 0.16.0
	 *
	 * @param array|null $cta     `href`, `title`, `text`, `cta`, `min`, `sku` and `channel` (`page`, `whatsapp`).
	 * @param WC_Product $product Product.
	 */
	$cta = apply_filters( 'lachinata/product/bulk_cta', null, $product );
	if ( ! is_array( $cta ) || empty( $cta['href'] ) ) {
		return null;
	}
	return array(
		'href'    => (string) $cta['href'],
		'title'   => (string) ( $cta['title'] ?? '' ),
		'text'    => (string) ( $cta['text'] ?? '' ),
		'cta'     => (string) ( $cta['cta'] ?? '' ),
		'min'     => (int) ( $cta['min'] ?? 0 ),
		'sku'     => (string) ( $cta['sku'] ?? '' ),
		'channel' => (string) ( $cta['channel'] ?? '' ),
	);
}

/**
 * Price shown for a product: the lowest variation price for variable products.
 *
 * @param WC_Product $product Product.
 * @return string HTML.
 */
function lachinata_display_price( WC_Product $product ): string {
	$price = $product instanceof WC_Product_Variable ? $product->get_variation_price( 'min', true ) : wc_get_price_to_display( $product );
	return wc_price( (float) $price );
}

/**
 * Tax note under prices: WooCommerce's «price display suffix» setting.
 */
function lachinata_price_note(): string {
	$suffix = (string) get_option( 'woocommerce_price_display_suffix', '' );
	return '' === $suffix ? '' : wp_kses_post( $suffix );
}

/**
 * Badges of a product: «-20 %» when it is on sale, then all its product tags (the shop
 * decides how many and which), then what modules add. Cards and the product page show
 * them all, stacked.
 *
 * @param WC_Product $product Product.
 * @return array<int, array{text: string, tone: string, image_id?: int, term_id?: int}>
 */
function lachinata_product_badges( WC_Product $product ): array {
	$badges = array();
	if ( $product->is_on_sale() ) {
		$regular  = (float) $product->get_regular_price();
		$sale     = (float) $product->get_sale_price();
		$badges[] = array(
			'text' => $regular > 0 && $sale > 0
				/* translators: %s: discount percentage. */
				? sprintf( __( '-%s %%', 'lachinata' ), number_format_i18n( round( ( 1 - $sale / $regular ) * 100 ) ) )
				: __( 'Oferta', 'lachinata' ),
			'tone' => 'promo',
		);
	}
	$tags = get_the_terms( $product->get_id(), 'product_tag' );
	foreach ( is_array( $tags ) ? $tags : array() as $tag ) {
		$badges[] = array(
			'text'     => lachinata_term_name( $tag ),
			'tone'     => '',
			'image_id' => 0,
			'term_id'  => $tag->term_id,
		);
	}
	/**
	 * Badges of a product card and product page, in the order they are shown. A badge with
	 * `term_id` comes from a product tag (the module `catalog` gives it its tone, image and
	 * order); `image_id` is a small decorative image before the text (since 0.12.2).
	 *
	 * @since 0.2.0
	 *
	 * @param array<int, array{text: string, tone: string, image_id?: int, term_id?: int}> $badges  Badges (tone '' = neutral).
	 * @param WC_Product                                                                   $product Product.
	 */
	return (array) apply_filters( 'lachinata/product_card/badges', $badges, $product );
}

/**
 * Mark of the shipping class of a product on its card (the «Refrigerado» pill), or null.
 *
 * @param WC_Product $product Product.
 * @return array{icon: string, label: string}|null
 */
function lachinata_product_marker( WC_Product $product ): ?array {
	/**
	 * Mark of a product on its card, in the lower left corner of the photo: a pill with
	 * its text and, optionally, an icon of the sprite before it ('' for none; since 0.12.3,
	 * before it was an icon with an accessible name). The module `catalog` gives the one
	 * of the shipping class (refrigerated goods).
	 *
	 * @since 0.12.2
	 *
	 * @param array{icon: string, label: string}|null $marker  Null by default (no mark).
	 * @param WC_Product                              $product Product.
	 */
	$marker = apply_filters( 'lachinata/product_card/marker', null, $product );
	return is_array( $marker ) && ! empty( $marker['label'] )
		? array(
			'icon'  => (string) ( $marker['icon'] ?? '' ),
			'label' => (string) $marker['label'],
		)
		: null;
}

/**
 * Data a ProductCard needs.
 *
 * @param WC_Product $product Product.
 * @param string     $tint    Tint of the listing (the root category being viewed); the
 *                            product's own (its main category) when ''.
 * @return array<string, mixed>
 */
function lachinata_card_data( WC_Product $product, string $tint = '' ): array {
	$badges = lachinata_product_badges( $product );
	$old    = '';
	if ( $product->is_on_sale() && ! $product->is_type( 'variable' ) ) {
		$old = wc_price( (float) wc_get_price_to_display( $product, array( 'price' => $product->get_regular_price() ) ) );
	}
	/**
	 * Photo of a product on its card: another one of the gallery when the featured image is
	 * a setting shot (module `catalog`, «Imagen de tarjeta»).
	 *
	 * @since 0.12.2
	 *
	 * @param int        $image_id Attachment id (the featured image by default).
	 * @param WC_Product $product  Product.
	 */
	$image_id = (int) apply_filters( 'lachinata/product_card/image_id', (int) $product->get_image_id(), $product );
	$add_id   = lachinata_card_add_id( $product );
	return array(
		'id'         => $product->get_id(),
		'name'       => $product->get_name(),
		'href'       => $product->get_permalink(),
		'image_id'   => $image_id,
		'tint'       => '' !== $tint ? $tint : lachinata_product_tint( $product ),
		'badges'     => $badges,
		'badge'      => $badges[0] ?? null,
		'marker'     => lachinata_product_marker( $product ),
		'rating'     => wc_review_ratings_enabled() && $product->get_review_count() ? (float) $product->get_average_rating() : null,
		'reviews'    => (int) $product->get_review_count(),
		'meta'       => lachinata_card_meta( $product ),
		'price'      => lachinata_display_price( $product ),
		'price_from' => $product instanceof WC_Product_Variable && $product->get_variation_price( 'min' ) !== $product->get_variation_price( 'max' ),
		'old'        => $old,
		'sold_out'   => ! $product->is_in_stock(),
		'direct_add' => $add_id > 0,
		'add_id'     => $add_id,
		'wine'       => lachinata_card_wine( $product ),
	);
}

/**
 * What the card's «+» adds directly: a simple product, or the only variation of a
 * variable one (a wine with a single vintage); 0 when the product page has to choose.
 *
 * @param WC_Product $product Product.
 */
function lachinata_card_add_id( WC_Product $product ): int {
	if ( ! $product->is_purchasable() || ! $product->is_in_stock() || $product->is_sold_individually() ) {
		return 0;
	}
	if ( $product->is_type( 'simple' ) ) {
		return $product->get_id();
	}
	if ( ! $product instanceof WC_Product_Variable ) {
		return 0;
	}
	$children = $product->get_visible_children();
	if ( 1 !== count( $children ) ) {
		return 0;
	}
	$variation = wc_get_product( (int) $children[0] );
	if ( ! $variation instanceof WC_Product_Variation || ! $variation->is_purchasable() || ! $variation->is_in_stock() || in_array( '', $variation->get_variation_attributes(), true ) ) {
		return 0;
	}
	return $variation->get_id();
}

/**
 * The wine line of a card: type colour and name, D.O., vintage and the highest score.
 * Null when the product is not a wine.
 *
 * @param WC_Product $product Product.
 * @return array{type: string, type_name: string, origin: string, vintage: string, score: array<string, mixed>|null}|null
 */
function lachinata_card_wine( WC_Product $product ): ?array {
	/**
	 * Wine data of a card (module bodega): `type` (colour of the system: tinto, blanco,
	 * rosado, espumoso, generoso, dulce), `typeName`, `origin` (the D.O.), `vintage` (when
	 * there is a single one) and `score` (`critic` and `points` or `medal`, or null). Null
	 * by default: the card shows its format line.
	 *
	 * @since 0.18.0
	 *
	 * @param array<string, mixed>|null $wine    Wine data.
	 * @param WC_Product                $product Product.
	 */
	$wine = apply_filters( 'lachinata/product_card/wine', null, $product );
	if ( ! is_array( $wine ) ) {
		return null;
	}
	return array(
		'type'      => sanitize_key( (string) ( $wine['type'] ?? '' ) ),
		'type_name' => (string) ( $wine['typeName'] ?? '' ),
		'origin'    => (string) ( $wine['origin'] ?? '' ),
		'vintage'   => (string) ( $wine['vintage'] ?? '' ),
		'score'     => is_array( $wine['score'] ?? null ) ? $wine['score'] : null,
	);
}

/**
 * A WineScore badge (critic and points, or contest and medal).
 *
 * @param array<string, mixed> $score `critic`, `points` or `medal`, `vintage`.
 * @param string               $extra_class Extra class.
 * @return string HTML, escaped.
 */
function lachinata_wine_score( array $score, string $extra_class = '' ): string {
	$critic = (string) ( $score['critic'] ?? '' );
	$medal  = (string) ( $score['medal'] ?? '' );
	$points = (string) ( $score['points'] ?? '' );
	$label  = '' !== $medal
		/* translators: 1: medal, 2: contest. */
		? sprintf( __( 'Medalla de %1$s · %2$s', 'lachinata' ), $medal, $critic )
		/* translators: 1: points, 2: critic. */
		: sprintf( __( '%1$s puntos · %2$s', 'lachinata' ), $points, $critic );
	if ( ! empty( $score['vintage'] ) ) {
		/* translators: 1: score and critic, 2: vintage. */
		$label = sprintf( __( '%1$s, añada %2$s', 'lachinata' ), $label, (string) $score['vintage'] );
	}
	return sprintf(
		'<span class="%1$s" role="img" aria-label="%2$s" data-no-translation><b class="lc-wscore__pts" aria-hidden="true">%3$s</b><span class="lc-wscore__critic" aria-hidden="true">%4$s</span></span>',
		esc_attr( lachinata_cx( 'lc-wscore', '' !== $medal ? 'lc-wscore--medal' : '', $extra_class ) ),
		esc_attr( $label ),
		esc_html( '' !== $medal ? $medal : $points ),
		esc_html( $critic )
	);
}

/**
 * Categories of the shop (header, menu, search and home) with their children: the list
 * the shop configures (module `catalog`, with its seasonal campaigns) or, without one,
 * every top-level category in WooCommerce's order. The default «Uncategorized» category
 * is left out by id, not by slug.
 *
 * @return array<int, array{term: WP_Term, tint: string, children: WP_Term[]}>
 */
function lachinata_category_tree(): array {
	static $tree = null;
	if ( null !== $tree ) {
		return $tree;
	}
	/**
	 * Categories of the shop, in order, as term ids. The module `catalog` gives the list
	 * configured in La Chinata → Catálogo, with the campaigns running today.
	 *
	 * @since 0.12.2
	 *
	 * @param int[]|null $ids Null by default: every top-level category with products.
	 */
	$ids     = apply_filters( 'lachinata/catalog/categories', null );
	$parents = is_array( $ids )
		? ( $ids ? get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'include'    => array_map( 'intval', $ids ),
				'hide_empty' => true,
				'orderby'    => 'include',
			)
		) : array() )
		: get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'parent'     => 0,
				'hide_empty' => true,
				'exclude'    => array( (int) get_option( 'default_product_cat', 0 ) ),
				'orderby'    => 'menu_order',
			)
		);
	$tree    = array();
	foreach ( is_array( $parents ) ? $parents : array() as $parent ) {
		$children = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'parent'     => $parent->term_id,
				'hide_empty' => true,
				'orderby'    => 'menu_order',
			)
		);
		$tree[]   = array(
			'term'     => $parent,
			'tint'     => lachinata_category_tint( $parent ),
			'children' => is_array( $children ) ? $children : array(),
		);
	}
	return $tree;
}

/**
 * The name of a term for a context (#48). WordPress keeps the «&» and the quotes of a term's
 * name as HTML entities («Click &amp; Collect»): decoded once and escaped once, `html`, `attr`
 * or `text` (plain: JSON-LD, a value escaped later). The twin of the plugin's
 * `LaChinata\Core\Terms::name()`, which the theme never calls.
 *
 * @param WP_Term|string $term    Term, or a name as WordPress keeps it.
 * @param string         $context `text` (default), `html` or `attr`.
 */
function lachinata_term_name( WP_Term|string $term, string $context = 'text' ): string {
	$name = html_entity_decode( $term instanceof WP_Term ? (string) $term->name : $term, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	return match ( $context ) {
		'html'  => esc_html( $name ),
		'attr'  => esc_attr( $name ),
		default => $name,
	};
}

/**
 * Link to a term, or '' on error.
 *
 * @param WP_Term $term Term.
 */
function lachinata_term_url( WP_Term $term ): string {
	$link = get_term_link( $term );
	return is_string( $link ) ? $link : '';
}

/**
 * Whether a product photo is a cutout (transparent background): it is painted centred,
 * with air, on the tint of its family (`lc-img--recorte`); a photo with a background fills
 * its piece.
 *
 * @param int $image_id Attachment id.
 */
function lachinata_image_cutout( int $image_id ): bool {
	if ( ! $image_id ) {
		return false;
	}
	/**
	 * Whether an image is a cutout product photo. The module `catalog` marks it when the
	 * image has transparency.
	 *
	 * @since 0.16.0
	 *
	 * @param bool $cutout   False by default.
	 * @param int  $image_id Attachment id.
	 */
	return (bool) apply_filters( 'lachinata/catalog/cutout', false, $image_id );
}

/**
 * `wp_get_attachment_image()` of a product photo, with `lc-img--recorte` on a cutout.
 *
 * @param int                  $image_id Attachment id.
 * @param string               $size     Image size.
 * @param array<string, mixed> $attrs    Attributes.
 */
function lachinata_attachment_image( int $image_id, string $size, array $attrs = array() ): string {
	if ( lachinata_image_cutout( $image_id ) ) {
		$attrs['class'] = lachinata_cx( (string) ( $attrs['class'] ?? 'attachment-' . $size . ' size-' . $size ), 'lc-img--recorte' );
	}
	return wp_get_attachment_image( $image_id, $size, false, $attrs );
}

/**
 * Product photo as an <img> with width/height, or the category halo when there is none.
 *
 * @param int    $image_id   Attachment id.
 * @param string $size       Image size.
 * @param string $halo_class Halo class (lc-card__halo, lc-line__halo…).
 * @param bool   $eager      Load eagerly (first screen).
 * @param string $sizes      Sizes attribute (rendered width of the image).
 */
function lachinata_product_image( int $image_id, string $size, string $halo_class, bool $eager = false, string $sizes = '' ): string {
	if ( ! $image_id ) {
		return sprintf( '<span class="%s" aria-hidden="true"></span>', esc_attr( $halo_class ) );
	}
	return lachinata_attachment_image(
		$image_id,
		$size,
		array(
			'alt'           => '',
			'loading'       => $eager ? 'eager' : 'lazy',
			'fetchpriority' => $eager ? 'high' : null,
			'decoding'      => 'async',
			'sizes'         => '' !== $sizes ? $sizes : null,
		)
	);
}
