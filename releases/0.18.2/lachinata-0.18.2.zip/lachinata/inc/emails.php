<?php
/**
 * Transactional emails: one frame for every email the shop sends (06-correos.md, tableros
 * «Correos transaccionales» y «Correos · móvil»).
 *
 * The frame (`woocommerce/emails/email-header.php` and `email-footer.php`) prints the
 * preheader, the card, the logo, eyebrow, title and lead, the key facts and the one button;
 * each email template adds its body (lines, totals, addresses) and the footer closes with
 * «¿Alguna duda?» and the reason for the email. What each email says lives here, by email
 * id; modules add their pieces through filters and actions (theme/HOOKS.md, «Correos»):
 *
 * - `lachinata/email/intro`   eyebrow, title, lead and preheader.
 * - `lachinata/email/facts`   the key facts (2–3 columns; a missing one leaves no gap).
 * - `lachinata/email/button`  the button (label, URL, primary or secondary).
 * - `lachinata/email/layout`  which parts of the order the email shows.
 * - `lachinata/email/after_title` and `lachinata/email/before_lines`: HTML of the module
 *   (badge, note), written with the `lc-mail-*` classes of lachinata_email_styles().
 *
 * The styles go through `woocommerce_email_styles`, so WooCommerce inlines them when it
 * sends; only the mobile rules stay in a <style> block. Plain text emails keep
 * WooCommerce's own templates, with the subjects of this file.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Colours of the frame (06-correos.md). Email clients do not read custom properties, so
 * the values of tokens.json are copied here.
 */
const LACHINATA_EMAIL_COLORS = array(
	'ink'            => '#231f20',
	'ink-soft'       => '#4c4c4c',
	'ink-muted'      => '#747474',
	'surface'        => '#ffffff',
	'surface-2'      => '#fafafa',
	'surface-3'      => '#f0f0f0',
	'line'           => '#e8ebed',
	'line-strong'    => '#d1d1d1',
	'success-strong' => '#2b7d12',
);

/**
 * Registers the email hooks.
 */
function lachinata_email_hooks(): void {
	// The frame is ours: WooCommerce's block email editor and «email improvements» templates
	// would replace it.
	add_filter( 'pre_option_woocommerce_feature_email_improvements_enabled', 'lachinata_email_feature_off' );
	add_filter( 'pre_option_woocommerce_feature_block_email_editor_enabled', 'lachinata_email_feature_off' );

	// Colours of WooCommerce → Ajustes → Correos, fixed to the frame's so nothing stock clashes.
	$colors = array(
		'woocommerce_email_base_color'            => LACHINATA_EMAIL_COLORS['ink'],
		'woocommerce_email_background_color'      => LACHINATA_EMAIL_COLORS['surface-2'],
		'woocommerce_email_body_background_color' => LACHINATA_EMAIL_COLORS['surface'],
		'woocommerce_email_text_color'            => LACHINATA_EMAIL_COLORS['ink'],
		'woocommerce_email_footer_text_color'     => LACHINATA_EMAIL_COLORS['ink-muted'],
	);
	foreach ( $colors as $option => $color ) {
		add_filter( 'pre_option_' . $option, static fn() => $color );
	}

	// Modules ask before leaving their pieces to the frame (theme/HOOKS.md, «Correos»).
	add_filter( 'lachinata/email/frame', '__return_true' );
	add_filter( 'woocommerce_email_styles', 'lachinata_email_styles', 5 );
	add_action( 'woocommerce_email_header', 'lachinata_email_begin', 1, 2 );
	foreach ( array_merge( array_keys( lachinata_email_subjects() ), array( 'customer_invoice_paid' ) ) as $lachinata_id ) {
		add_filter( 'woocommerce_email_subject_' . $lachinata_id, 'lachinata_email_subject', 10, 3 );
	}
}
add_action( 'after_setup_theme', 'lachinata_email_hooks' );

/**
 * The email being written. WooCommerce passes it to the `woocommerce_email_header` action
 * but not to the header, footer and addresses templates, so it is kept here.
 *
 * @param WC_Email|null $email Email to keep (with $set).
 * @param bool          $set   Keep $email instead of reading.
 */
function lachinata_email_current( ?WC_Email $email = null, bool $set = false ): ?WC_Email {
	static $current = null;
	if ( $set ) {
		$current = $email;
	}
	return $current;
}

/**
 * `woocommerce_email_header`, first: keeps the email (null for WooCommerce's wrap_message).
 *
 * @param mixed $heading Heading.
 * @param mixed $email   Email.
 */
function lachinata_email_begin( $heading = '', $email = null ): void {
	unset( $heading );
	lachinata_email_current( $email instanceof WC_Email ? $email : null, true );
}

/**
 * A WooCommerce feature switched off.
 */
function lachinata_email_feature_off(): string {
	return 'no';
}

/**
 * The CSS of the frame. It replaces WooCommerce's (styled for its own markup) and is
 * inlined by WooCommerce; the media query stays in the <head> for the clients that read it.
 *
 * @param mixed $css WooCommerce's CSS.
 */
function lachinata_email_styles( $css = '' ): string {
	unset( $css );
	$c    = LACHINATA_EMAIL_COLORS;
	$font = "font-family:'DIN Pro',Arial,Helvetica,sans-serif;";
	$text = $font . 'margin:0;';
	return "
body{margin:0;padding:0;background:{$c['surface-2']};-webkit-text-size-adjust:100%;}
a{color:{$c['ink']};}
h2{{$font}font-size:15px;line-height:22px;font-weight:500;color:{$c['ink']};margin:24px 0 4px;}
ul{margin:0;padding:0 0 0 18px;}
li{{$font}font-size:14px;line-height:20px;font-weight:300;color:{$c['ink-soft']};}
.lc-mail{background:{$c['surface-2']};padding:24px 0;}
.lc-mail-preheader{display:none;max-height:0;overflow:hidden;font-size:1px;line-height:1px;color:{$c['surface-2']};}
.lc-mail-outer{padding:0 12px;}
.lc-mail-card{width:600px;max-width:100%;background:{$c['surface']};border:1px solid {$c['line']};border-top:4px solid {$c['ink']};}
.lc-mail-foot{width:600px;max-width:100%;}
.lc-mail-head{padding:22px 32px;border-bottom:1px solid {$c['line']};}
.lc-mail-logo{display:block;border:0;height:20px;width:143px;}
.lc-mail-body{padding:32px;{$font}color:{$c['ink-soft']};}
.lc-mail-eyebrow{{$text}font-size:12px;line-height:16px;font-weight:500;color:{$c['ink-muted']};letter-spacing:.12em;text-transform:uppercase;}
.lc-mail-title{{$text}font-size:24px;line-height:30px;font-weight:500;color:{$c['ink']};margin-top:6px;}
.lc-mail-lead{{$text}font-size:16px;line-height:24px;font-weight:300;color:{$c['ink-soft']};margin-top:12px;}
.lc-mail-text{{$text}font-size:16px;line-height:24px;font-weight:300;color:{$c['ink-soft']};margin-top:20px;}
.lc-mail-caption{{$text}font-size:13px;line-height:18px;font-weight:300;color:{$c['ink-muted']};margin-top:20px;}
.lc-mail-badge{display:inline-block;padding:3px 8px;background:{$c['ink']};color:{$c['surface']};{$font}font-size:11px;line-height:14px;font-weight:500;letter-spacing:.08em;text-transform:uppercase;}
.lc-mail-badges{margin:8px 0 0;}
.lc-mail-facts{margin-top:24px;background:{$c['surface-2']};}
.lc-mail-facts__cell{padding:16px 20px;}
.lc-mail-facts__row{table-layout:fixed;}
.lc-mail-fact{padding:0 16px 0 0;vertical-align:top;word-wrap:break-word;overflow-wrap:anywhere;}
.lc-mail-label{{$text}font-size:12px;line-height:16px;font-weight:500;color:{$c['ink-muted']};letter-spacing:.08em;text-transform:uppercase;}
.lc-mail-fact__value{{$text}font-size:16px;line-height:22px;font-weight:500;color:{$c['ink']};margin-top:4px;}
.lc-mail-fact__note{{$text}font-size:13px;line-height:18px;font-weight:300;color:{$c['ink-soft']};margin-top:2px;}
.lc-mail-btn{margin-top:24px;}
.lc-mail-btn__cell{background:{$c['ink']};border:1px solid {$c['ink']};}
.lc-mail-btn__cell a.lc-mail-btn__link{display:inline-block;padding:14px 28px;{$font}font-size:15px;line-height:20px;font-weight:500;color:{$c['surface']};text-decoration:none;}
.lc-mail-btn--secondary .lc-mail-btn__cell{background:{$c['surface']};}
.lc-mail-btn--secondary .lc-mail-btn__cell a.lc-mail-btn__link{color:{$c['ink']};}
.lc-mail-note{margin-top:24px;}
.lc-mail-note__cell{padding:14px 16px;border-left:3px solid {$c['ink']};background:{$c['surface-2']};}
.lc-mail-note__title{{$text}font-size:15px;line-height:22px;font-weight:500;color:{$c['ink']};}
.lc-mail-note__text{{$text}font-size:14px;line-height:20px;font-weight:300;color:{$c['ink-soft']};margin-top:2px;}
.lc-mail-note__text p{{$text}font-size:14px;line-height:20px;font-weight:300;color:{$c['ink-soft']};margin-top:2px;}
.lc-mail-lines{margin-top:28px;border-top:1px solid {$c['line-strong']};border-bottom:1px solid {$c['line-strong']};}
.lc-mail-line--next td{border-top:1px solid {$c['line']};}
.lc-mail-line__thumb{padding:14px 0;width:64px;vertical-align:top;}
.lc-mail-line__img{display:block;width:64px;height:64px;border:0;}
.lc-mail-line__main{padding:14px 12px;vertical-align:top;}
.lc-mail-line--compact .lc-mail-line__main{padding-left:0;}
.lc-mail-line__amount{padding:14px 0;vertical-align:top;text-align:right;white-space:nowrap;}
.lc-mail-line__name{{$text}font-size:16px;line-height:22px;font-weight:500;color:{$c['ink']};}
.lc-mail-line__meta{{$text}font-size:14px;line-height:20px;font-weight:300;color:{$c['ink-muted']};margin-top:2px;}
.lc-mail-line__price{{$text}font-size:16px;line-height:22px;font-weight:500;color:{$c['ink']};}
.lc-mail-line__unit{{$text}font-size:13px;line-height:18px;font-weight:300;color:{$c['ink-muted']};margin-top:2px;}
.lc-mail-totals{margin-top:12px;}
.lc-mail-totals__cell{padding:4px 0;vertical-align:top;}
.lc-mail-totals__label{{$text}font-size:15px;line-height:22px;font-weight:300;color:{$c['ink-soft']};}
.lc-mail-totals__value{{$text}font-size:15px;line-height:22px;font-weight:300;color:{$c['ink']};}
.lc-mail-totals__free{color:{$c['success-strong']};}
.lc-mail-totals__total{padding:12px 0 0;border-top:1px solid {$c['line']};vertical-align:top;}
.lc-mail-totals__total-label{{$text}font-size:18px;line-height:24px;font-weight:500;color:{$c['ink']};}
.lc-mail-totals__total-value{{$text}font-size:20px;line-height:24px;font-weight:500;color:{$c['ink']};}
.lc-mail-totals__tax{{$text}font-size:13px;line-height:18px;font-weight:300;color:{$c['ink-muted']};}
.lc-mail-addresses{margin-top:28px;}
.lc-mail-address{padding:0 16px 16px 0;vertical-align:top;word-wrap:break-word;overflow-wrap:anywhere;}
.lc-mail-address__text{{$text}font-size:15px;line-height:22px;font-weight:300;color:{$c['ink']};margin-top:6px;}
.lc-mail-fields{margin-top:12px;}
.lc-mail-fields p{{$text}font-size:14px;line-height:20px;font-weight:300;color:{$c['ink-soft']};margin-top:4px;}
.lc-mail-help{margin-top:32px;border-top:1px solid {$c['line']};}
.lc-mail-help__cell{padding:20px 0 0;}
.lc-mail-help__title{{$text}font-size:15px;line-height:22px;font-weight:500;color:{$c['ink']};}
.lc-mail-help__text{{$text}font-size:14px;line-height:20px;font-weight:300;color:{$c['ink-soft']};margin-top:2px;}
.lc-mail-help__text a{color:{$c['ink']};font-weight:500;}
.lc-mail-foot__cell{padding:24px 32px 8px;text-align:center;}
.lc-mail-foot__line{{$text}font-size:13px;line-height:18px;font-weight:300;color:{$c['ink-muted']};}
.lc-mail-foot__links{{$text}font-size:13px;line-height:18px;font-weight:300;color:{$c['ink-muted']};margin-top:8px;}
.lc-mail-foot__links a{color:{$c['ink-muted']};text-decoration:underline;}
.lc-mail-foot__why{{$text}font-size:12px;line-height:16px;font-weight:300;color:{$c['ink-muted']};margin-top:12px;}
.lc-mail-foot__why a{color:{$c['ink-muted']};text-decoration:underline;}
.lc-mail-extra{margin-top:24px;}
.lc-mail-extra p,.lc-mail-extra li{{$font}font-size:14px;line-height:20px;font-weight:300;color:{$c['ink-soft']};}
.lc-mail-extra h2,.lc-mail-extra h3{{$font}font-size:15px;line-height:22px;font-weight:500;color:{$c['ink']};margin:16px 0 4px;}
.lc-mail-extra a{color:{$c['ink']};}
@media (max-width:480px){
.lc-mail-card,.lc-mail-foot{width:100%!important;}
.lc-mail-pad{padding-left:16px!important;padding-right:16px!important;}
.lc-mail-stack{display:block!important;width:100%!important;padding-right:0!important;padding-bottom:12px!important;}
.lc-mail-btn{width:100%!important;}
.lc-mail-btn td{display:block!important;}
.lc-mail-btn a{display:block!important;text-align:center!important;}
}
";
}

/**
 * The order of an email, or null.
 *
 * @param WC_Email|null $email Email.
 */
function lachinata_email_order( ?WC_Email $email ): ?WC_Order {
	$object = null === $email ? null : $email->object;
	return $object instanceof WC_Order ? $object : null;
}

/**
 * Email id, or '' outside an email.
 *
 * @param WC_Email|null $email Email.
 */
function lachinata_email_id( ?WC_Email $email ): string {
	return null === $email ? '' : (string) $email->id;
}

/**
 * Shop name in the emails («La Chinata»): the trade name of the plugin's company data, else
 * the sender of WooCommerce's emails, else the site name.
 */
function lachinata_email_brand(): string {
	$company = lachinata_company_value( 'trade_name' );
	if ( '' !== $company ) {
		return $company;
	}
	$name = trim( wp_specialchars_decode( (string) get_option( 'woocommerce_email_from_name' ), ENT_QUOTES ) );
	return '' !== $name ? $name : lachinata_shop_name();
}

/**
 * Domain of the site without www («lachinata.es»).
 */
function lachinata_email_domain(): string {
	$host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
	return (string) preg_replace( '/^www\./', '', $host );
}

/**
 * Text of a price for a subject or an alt text: «69,85 €», without HTML.
 *
 * @param float  $amount Amount.
 * @param string $currency Currency.
 */
function lachinata_email_plain_price( float $amount, string $currency = '' ): string {
	return html_entity_decode( wp_strip_all_tags( wc_price( $amount, array( 'currency' => $currency ) ) ), ENT_QUOTES, 'UTF-8' );
}

/**
 * Where the buyer sees the order: the account if the order has one, the order received
 * page (with its key) for a guest.
 *
 * @param WC_Order $order Order.
 */
function lachinata_email_order_url( WC_Order $order ): string {
	return $order->get_customer_id() ? $order->get_view_order_url() : $order->get_checkout_order_received_url();
}

/**
 * Customer service of the shop (core of the plugin, «Atención al cliente»).
 *
 * @return array{phone: string, whatsapp: string, email: string, hours: string, phone_url: string, whatsapp_url: string}
 */
function lachinata_contact(): array {
	$defaults = array(
		'phone'        => '',
		'whatsapp'     => '',
		'email'        => '',
		'hours'        => '',
		'phone_url'    => '',
		'whatsapp_url' => '',
	);
	/**
	 * Customer service contact of the shop: phone, WhatsApp, email and hours, with the
	 * tel: and wa.me links. Empty by default (the email help then says only «responde a
	 * este correo»).
	 *
	 * @since 0.8.0
	 *
	 * @param array<string, string> $contact Empty values.
	 */
	$contact = (array) apply_filters( 'lachinata/contact', $defaults );
	$out     = array();
	foreach ( $defaults as $key => $empty ) {
		$out[ $key ] = is_string( $contact[ $key ] ?? null ) ? $contact[ $key ] : $empty;
	}
	/**
	 * The keys are all there.
	 *
	 * @var array{phone: string, whatsapp: string, email: string, hours: string, phone_url: string, whatsapp_url: string} $out
	 */
	return $out;
}

/**
 * Subjects of the inventory (06-correos.md), by email id. {order_number} and {site_title}
 * are WooCommerce's; {first_name}, {refund} and {total} are filled by
 * lachinata_email_subject().
 *
 * @return array<string, string>
 */
function lachinata_email_subjects(): array {
	return array(
		'customer_processing_order' => __( 'Gracias, {first_name}. Tu pedido {order_number} está en marcha', 'lachinata' ),
		'customer_on_hold_order'    => __( 'Tu pedido {order_number} espera el pago', 'lachinata' ),
		'customer_completed_order'  => __( 'Tu pedido {order_number} ya está en camino', 'lachinata' ),
		'customer_refunded_order'   => __( 'Te hemos devuelto {refund} del pedido {order_number}', 'lachinata' ),
		'customer_note'             => '{note}',
		'customer_new_account'      => __( 'Tu cuenta en {site_title} ya está lista', 'lachinata' ),
		'customer_reset_password'   => __( 'Elige una nueva contraseña', 'lachinata' ),
		'customer_invoice'          => __( 'Tu pedido {order_number} de {site_title}', 'lachinata' ),
		'customer_failed_order'     => __( 'No hemos podido completar tu pedido {order_number}', 'lachinata' ),
		'customer_cancelled_order'  => __( 'Hemos cancelado tu pedido {order_number}', 'lachinata' ),
		'new_order'                 => __( 'Nuevo pedido {order_number} · {total}', 'lachinata' ),
		'cancelled_order'           => __( 'Pedido {order_number} cancelado', 'lachinata' ),
		'failed_order'              => __( 'Pago fallido del pedido {order_number}', 'lachinata' ),
	);
}

/**
 * Subject of an email of the inventory, unless the shop wrote its own in WooCommerce →
 * Ajustes → Correos.
 *
 * @param mixed $subject Subject.
 * @param mixed $item    Object of the email.
 * @param mixed $email   Email.
 */
function lachinata_email_subject( $subject, $item = null, $email = null ): string {
	$subject = (string) $subject;
	if ( ! $email instanceof WC_Email ) {
		return $subject;
	}
	// The setting that holds the shop's own subject: paid invoices and refunds have theirs.
	$setting = 'subject';
	if ( 'woocommerce_email_subject_customer_invoice_paid' === current_filter() ) {
		$setting = 'subject_paid';
	} elseif ( 'customer_refunded_order' === $email->id ) {
		$setting = ! empty( $email->partial_refund ) ? 'subject_partial' : 'subject_full';
	}
	if ( lachinata_email_customized( $email, $setting ) ) {
		return $subject;
	}
	$text  = lachinata_email_subjects()[ $email->id ] ?? '';
	$order = $item instanceof WC_Order ? $item : null;
	if ( '' === $text ) {
		return $subject;
	}
	if ( 'customer_processing_order' === $email->id && null !== $order && '' === trim( $order->get_billing_first_name() ) ) {
		$text = __( 'Tu pedido {order_number} está en marcha', 'lachinata' );
	}
	if ( 'customer_invoice' === $email->id && null !== $order && $order->needs_payment() ) {
		$text = __( 'Paga tu pedido {order_number} de {site_title}', 'lachinata' );
	}
	if ( 'customer_on_hold_order' === $email->id && null !== $order && lachinata_email_is_transfer( $order ) ) {
		$text = __( 'Tu pedido {order_number} espera la transferencia', 'lachinata' );
	}
	$values = array(
		'{order_number}' => null === $order ? '' : $order->get_order_number(),
		'{site_title}'   => lachinata_email_brand(),
		'{first_name}'   => null === $order ? '' : trim( $order->get_billing_first_name() ),
		'{total}'        => null === $order ? '' : lachinata_email_plain_price( (float) $order->get_total(), $order->get_currency() ),
		'{refund}'       => null === $order ? '' : lachinata_email_plain_price( lachinata_email_refund_amount( $email, $order ), $order->get_currency() ),
		'{note}'         => lachinata_email_note_summary( $email ),
	);
	$text   = $email->format_string( strtr( $text, $values ) );
	/**
	 * Subject of an email of the frame (the gift module adds «· regalo» to the shop's).
	 *
	 * @since 0.8.0
	 *
	 * @param string   $text  Subject.
	 * @param WC_Email $email Email.
	 */
	return (string) apply_filters( 'lachinata/email/subject', $text, $email );
}

/**
 * Whether the shop wrote its own value of a text setting of an email (subject, heading) in
 * WooCommerce → Ajustes → Correos. WC_Email::get_option() fills the default in once read,
 * so the saved settings are read as they are.
 *
 * @param WC_Email $email Email.
 * @param string   $key   Setting (subject, subject_full, heading…).
 */
function lachinata_email_customized( WC_Email $email, string $key ): bool {
	$saved = get_option( $email->get_option_key(), array() );
	return is_array( $saved ) && '' !== trim( (string) ( $saved[ $key ] ?? '' ) );
}

/**
 * Amount of the refund of a refund email (the partial one, or what the order has refunded).
 *
 * @param WC_Email $email Email.
 * @param WC_Order $order Order.
 */
function lachinata_email_refund_amount( WC_Email $email, WC_Order $order ): float {
	$refund = property_exists( $email, 'refund' ) ? $email->refund : null;
	return $refund instanceof WC_Order_Refund ? abs( (float) $refund->get_amount() ) : (float) $order->get_total_refunded();
}

/**
 * The note of a customer note email, cut to a subject («la nota resumida»).
 *
 * @param WC_Email $email Email.
 */
function lachinata_email_note_summary( WC_Email $email ): string {
	$note = property_exists( $email, 'customer_note' ) ? trim( wp_strip_all_tags( (string) $email->customer_note ) ) : '';
	if ( '' === $note ) {
		return __( 'Una nota sobre tu pedido', 'lachinata' );
	}
	$note = (string) preg_replace( '/\s+/', ' ', $note );
	return mb_strlen( $note ) > 70 ? rtrim( mb_substr( $note, 0, 69 ), ' .,;:' ) . '…' : $note;
}

/**
 * «23 de octubre de 2026» (or «23 oct 2026, 10:42» with the time) of an order.
 *
 * @param WC_Order $order    Order.
 * @param bool     $with_time With the time (internal emails).
 */
function lachinata_email_order_date( WC_Order $order, bool $with_time = false ): string {
	$date = $order->get_date_created();
	if ( null === $date ) {
		return '';
	}
	return $with_time
		/* translators: date and time of an order in an internal email (PHP date()): «23 oct 2026, 10:42». */
		? wp_date( _x( 'j M Y, H:i', 'internal email date', 'lachinata' ), $date->getTimestamp() )
		/* translators: date of an order in an email (PHP date()): «23 de octubre de 2026». */
		: wp_date( _x( 'j \d\e F \d\e Y', 'email date', 'lachinata' ), $date->getTimestamp() );
}

/**
 * Eyebrow, title, lead and preheader of an email.
 *
 * @param WC_Email|null $email   Email.
 * @param string        $heading WooCommerce's heading (title of the emails outside the inventory).
 * @return array{eyebrow: string, title: string, lead: string, preheader: string}
 */
function lachinata_email_intro( ?WC_Email $email, string $heading = '' ): array {
	$order  = lachinata_email_order( $email );
	$id     = lachinata_email_id( $email );
	$number = null === $order ? '' : $order->get_order_number();
	$name   = null === $order ? '' : trim( $order->get_billing_first_name() );
	/* translators: %s: order number. */
	$order_eyebrow = sprintf( __( 'Pedido %s', 'lachinata' ), $number );
	$intro         = array(
		'eyebrow'   => '',
		'title'     => $heading,
		'lead'      => '',
		'preheader' => '',
	);

	if ( null !== $order ) {
		switch ( $id ) {
			case 'customer_processing_order':
				$intro = array(
					/* translators: 1: order number, 2: order date. */
					'eyebrow'   => sprintf( __( 'Pedido %1$s · %2$s', 'lachinata' ), $number, lachinata_email_order_date( $order ) ),
					/* translators: %s: buyer's first name. */
					'title'     => '' !== $name ? sprintf( __( 'Gracias, %s. Tu pedido está en marcha.', 'lachinata' ), $name ) : __( 'Gracias. Tu pedido está en marcha.', 'lachinata' ),
					'lead'      => __( 'Hemos recibido tu pedido y el pago. Lo preparamos en nuestro almacén y te avisaremos en cuanto salga.', 'lachinata' ),
					/* translators: %s: order number. */
					'preheader' => sprintf( __( 'Pedido %s confirmado', 'lachinata' ), $number ),
				);
				break;
			case 'customer_on_hold_order':
				$transfer = lachinata_email_is_transfer( $order );
				$intro    = array(
					/* translators: 1: order number, 2: order date. */
					'eyebrow'   => sprintf( __( 'Pedido %1$s · %2$s', 'lachinata' ), $number, lachinata_email_order_date( $order ) ),
					'title'     => $transfer ? __( 'Tu pedido espera la transferencia', 'lachinata' ) : __( 'Tu pedido espera el pago', 'lachinata' ),
					'lead'      => $transfer
						? __( 'Lo tenemos reservado y lo preparamos en cuanto llegue la transferencia.', 'lachinata' )
						: __( 'Lo tenemos reservado y lo prepararemos en cuanto recibamos el pago.', 'lachinata' ),
					'preheader' => $transfer
						/* translators: %s: order number. */
						? sprintf( __( 'Tu pedido %s espera la transferencia', 'lachinata' ), $number )
						/* translators: %s: order number. */
						: sprintf( __( 'Tu pedido %s espera el pago', 'lachinata' ), $number ),
				);
				break;
			case 'customer_completed_order':
				$intro = array(
					'eyebrow'   => $order_eyebrow,
					'title'     => __( 'Tu pedido ya está en camino', 'lachinata' ),
					'lead'      => __( 'Ha salido hoy de nuestro almacén. Si tienes cualquier duda con la entrega, escríbenos.', 'lachinata' ),
					/* translators: %s: order number. */
					'preheader' => sprintf( __( 'Tu pedido %s ha salido', 'lachinata' ), $number ),
				);
				break;
			case 'customer_refunded_order':
				$refund = lachinata_email_plain_price( null === $email ? 0.0 : lachinata_email_refund_amount( $email, $order ), $order->get_currency() );
				$intro  = array(
					'eyebrow'   => $order_eyebrow,
					/* translators: %s: refunded amount («69,85 €»). */
					'title'     => sprintf( __( 'Te hemos devuelto %s', 'lachinata' ), $refund ),
					'lead'      => lachinata_email_is_paypal( $order )
						? __( 'La devolución va a tu cuenta de PayPal, con la que pagaste.', 'lachinata' )
						: __( 'La devolución va al mismo medio con el que pagaste. Según tu banco, puede tardar unos días en aparecer.', 'lachinata' ),
					/* translators: 1: refunded amount, 2: order number. */
					'preheader' => sprintf( __( 'Devolución de %1$s del pedido %2$s', 'lachinata' ), $refund, $number ),
				);
				break;
			case 'customer_note':
				$intro = array(
					'eyebrow'   => $order_eyebrow,
					'title'     => __( 'Una nota sobre tu pedido', 'lachinata' ),
					'lead'      => $email instanceof WC_Email_Customer_Note ? trim( wp_strip_all_tags( (string) $email->customer_note ) ) : '',
					'preheader' => null === $email ? '' : lachinata_email_note_summary( $email ),
				);
				break;
			case 'customer_invoice':
				$pay   = $order->needs_payment();
				$intro = array(
					/* translators: 1: order number, 2: order date. */
					'eyebrow'   => sprintf( __( 'Pedido %1$s · %2$s', 'lachinata' ), $number, lachinata_email_order_date( $order ) ),
					'title'     => $pay ? __( 'Tu pedido está listo para pagar', 'lachinata' ) : __( 'El detalle de tu pedido', 'lachinata' ),
					'lead'      => $pay ? lachinata_email_pay_lead() : __( 'Aquí tienes lo que pediste, con los importes y las direcciones.', 'lachinata' ),
					'preheader' => $pay
						/* translators: %s: order number. */
						? sprintf( __( 'Paga tu pedido %s', 'lachinata' ), $number )
						/* translators: %s: order number. */
						: sprintf( __( 'El detalle de tu pedido %s', 'lachinata' ), $number ),
				);
				break;
			case 'customer_failed_order':
				$intro = array(
					'eyebrow'   => $order_eyebrow,
					'title'     => __( 'No hemos podido completar tu pedido', 'lachinata' ),
					'lead'      => __( 'El pago no se ha completado, así que no te hemos cobrado nada. Puedes volver a intentarlo con la misma tarjeta o con otro método.', 'lachinata' ),
					/* translators: %s: order number. */
					'preheader' => sprintf( __( 'El pago del pedido %s no se ha completado', 'lachinata' ), $number ),
				);
				break;
			case 'customer_cancelled_order':
				$intro = array(
					'eyebrow'   => $order_eyebrow,
					'title'     => __( 'Hemos cancelado tu pedido', 'lachinata' ),
					'lead'      => __( 'Hemos cancelado tu pedido y no te hemos cobrado nada. Si aún lo quieres, puedes volver a hacerlo en la tienda.', 'lachinata' ),
					/* translators: %s: order number. */
					'preheader' => sprintf( __( 'Hemos cancelado tu pedido %s', 'lachinata' ), $number ),
				);
				break;
			case 'new_order':
				$total = lachinata_email_plain_price( (float) $order->get_total(), $order->get_currency() );
				$intro = array(
					/* translators: 1: site domain, 2: date and time. */
					'eyebrow'   => sprintf( __( 'Nuevo pedido · %1$s · %2$s', 'lachinata' ), lachinata_email_domain(), lachinata_email_order_date( $order, true ) ),
					/* translators: 1: order number, 2: order total. */
					'title'     => sprintf( __( 'Pedido %1$s · %2$s', 'lachinata' ), $number, $total ),
					'lead'      => '',
					/* translators: 1: order number, 2: order total. */
					'preheader' => sprintf( __( 'Nuevo pedido %1$s · %2$s', 'lachinata' ), $number, $total ),
				);
				break;
			case 'cancelled_order':
			case 'failed_order':
				$buyer = trim( $order->get_formatted_billing_full_name() );
				$intro = array(
					/* translators: 1: site domain, 2: date and time. */
					'eyebrow'   => sprintf( __( 'Pedido · %1$s · %2$s', 'lachinata' ), lachinata_email_domain(), lachinata_email_order_date( $order, true ) ),
					'title'     => 'failed_order' === $id
						/* translators: %s: order number. */
						? sprintf( __( 'Pago fallido del pedido %s', 'lachinata' ), $number )
						/* translators: %s: order number. */
						: sprintf( __( 'Pedido %s cancelado', 'lachinata' ), $number ),
					'lead'      => 'failed_order' === $id
						/* translators: %s: buyer's name. */
						? sprintf( __( 'El pago de %s no se ha completado. El pedido queda como fallido y no se ha cobrado nada.', 'lachinata' ), $buyer )
						/* translators: %s: buyer's name. */
						: sprintf( __( 'El pedido de %s ha pasado a cancelado. Si ya estaba preparado, no debe salir del almacén.', 'lachinata' ), $buyer ),
					'preheader' => '',
				);
				break;
		}
	}

	if ( 'customer_new_account' === $id ) {
		$intro = array(
			'eyebrow'   => __( 'Tu cuenta', 'lachinata' ),
			'title'     => __( 'Tu cuenta ya está lista', 'lachinata' ),
			'lead'      => __( 'Desde ella puedes seguir tus pedidos, repetir una compra y guardar tus direcciones para la próxima vez.', 'lachinata' ),
			'preheader' => __( 'Tu cuenta ya está lista', 'lachinata' ),
		);
	} elseif ( 'customer_reset_password' === $id ) {
		$login = $email instanceof WC_Email_Customer_Reset_Password ? (string) $email->user_login : '';
		$user  = '' !== $login ? get_user_by( 'login', $login ) : false;
		$who   = $user instanceof WP_User ? $user->user_email : $login;
		$intro = array(
			'eyebrow'   => __( 'Tu cuenta', 'lachinata' ),
			'title'     => __( 'Restablece tu contraseña', 'lachinata' ),
			/* translators: %s: account email or user name. */
			'lead'      => sprintf( __( 'Hemos recibido una petición para cambiar la contraseña de la cuenta %s. Pulsa el botón para elegir una nueva.', 'lachinata' ), $who ),
			'preheader' => __( 'Elige una nueva contraseña para tu cuenta', 'lachinata' ),
		);
	}

	// A heading written by the shop in WooCommerce → Ajustes → Correos wins over the title.
	if ( null !== $email && '' !== $heading && lachinata_email_customized( $email, 'heading' ) ) {
		$intro['title'] = $heading;
	}

	/**
	 * Eyebrow, title, lead and preheader of an email.
	 *
	 * @since 0.8.0
	 *
	 * @param array{eyebrow: string, title: string, lead: string, preheader: string} $intro Texts (plain).
	 * @param WC_Email|null                                                          $email Email.
	 */
	$intro = (array) apply_filters( 'lachinata/email/intro', $intro, $email );
	return array(
		'eyebrow'   => (string) ( $intro['eyebrow'] ?? '' ),
		'title'     => (string) ( $intro['title'] ?? '' ),
		'lead'      => (string) ( $intro['lead'] ?? '' ),
		'preheader' => (string) ( $intro['preheader'] ?? '' ),
	);
}

/**
 * Which parts of the order an email shows.
 *
 * @param WC_Email|null $email Email.
 * @return array{lines: string, totals: bool, addresses: bool, help: bool, instructions: bool}
 */
function lachinata_email_layout( ?WC_Email $email ): array {
	$id       = lachinata_email_id( $email );
	$customer = null !== $email && $email->is_customer_email();
	$layouts  = array(
		'customer_processing_order' => array( 'full', true, true, true ),
		'customer_on_hold_order'    => array( 'full', true, true, true ),
		'customer_completed_order'  => array( 'compact', false, false, true ),
		'customer_refunded_order'   => array( 'compact', false, false, true ),
		'customer_note'             => array( 'none', false, false, true ),
		'customer_invoice'          => array( 'full', true, true, true ),
		'customer_failed_order'     => array( 'none', false, false, true ),
		'customer_cancelled_order'  => array( 'none', false, false, true ),
		'customer_new_account'      => array( 'none', false, false, false ),
		'customer_reset_password'   => array( 'none', false, false, false ),
		'new_order'                 => array( 'compact', true, true, false ),
		'cancelled_order'           => array( 'compact', false, false, false ),
		'failed_order'              => array( 'compact', false, false, false ),
	);
	$row      = $layouts[ $id ] ?? array( 'full', true, true, $customer );
	$layout   = array(
		'lines'        => $row[0],
		'totals'       => $row[1],
		'addresses'    => $row[2],
		'help'         => $row[3],
		// What extensions print before the order table (payment instructions, a carrier's
		// table) only helps while the order is under way.
		'instructions' => ! in_array( $id, array( 'customer_refunded_order', 'customer_note', 'customer_failed_order', 'customer_cancelled_order' ), true )
			&& ! ( 'customer_on_hold_order' === $id && null !== lachinata_email_order( $email ) && lachinata_email_is_transfer( lachinata_email_order( $email ) ) ),
	);
	/**
	 * Which parts of the order an email shows: lines (full, compact without photo, none),
	 * totals, addresses, «¿Alguna duda?» and what extensions print before the order table.
	 *
	 * @since 0.8.0
	 *
	 * @param array{lines: string, totals: bool, addresses: bool, help: bool, instructions: bool} $layout Parts.
	 * @param WC_Email|null                                                   $email  Email.
	 */
	$layout = (array) apply_filters( 'lachinata/email/layout', $layout, $email );
	return array(
		'lines'        => in_array( $layout['lines'] ?? '', array( 'full', 'compact', 'none' ), true ) ? (string) $layout['lines'] : 'full',
		'totals'       => (bool) ( $layout['totals'] ?? false ),
		'addresses'    => (bool) ( $layout['addresses'] ?? false ),
		'help'         => (bool) ( $layout['help'] ?? false ),
		'instructions' => (bool) ( $layout['instructions'] ?? true ),
	);
}

/**
 * Shipping line of an order, or null.
 *
 * @param WC_Order $order Order.
 */
function lachinata_email_shipping_item( WC_Order $order ): ?WC_Order_Item_Shipping {
	$line = current( $order->get_items( 'shipping' ) );
	return $line instanceof WC_Order_Item_Shipping ? $line : null;
}

/**
 * Cost of the shipping line as shown in the order («Gratis» when it is zero).
 *
 * @param WC_Order               $order Order.
 * @param WC_Order_Item_Shipping $line  Shipping line.
 */
function lachinata_email_shipping_cost( WC_Order $order, WC_Order_Item_Shipping $line ): string {
	$cost = (float) $line->get_total() + ( 'excl' === get_option( 'woocommerce_tax_display_cart' ) ? 0.0 : (float) $line->get_total_tax() );
	return $cost > 0 ? lachinata_email_plain_price( $cost, $order->get_currency() ) : __( 'Gratis', 'lachinata' );
}

/**
 * Note under the payment: «Cobrado» when WooCommerce counts the order as paid, «Pendiente»
 * while it waits for the payment (06-correos.md, «Reglas de contenido de las piezas»).
 *
 * @param WC_Order $order Order.
 */
function lachinata_email_paid_note( WC_Order $order ): string {
	return $order->is_paid() ? __( 'Cobrado', 'lachinata' ) : __( 'Pendiente', 'lachinata' );
}

/**
 * How the order is paid, as people read it: only the method and, with a card, its last four
 * digits («Tarjeta ···· 4242», «PayPal»). Never the account, email or id a gateway puts in
 * the order's title («PayPal (nombre@correo.es)»): the method's own title is used.
 *
 * @param WC_Order $order Order.
 */
function lachinata_order_payment_label( WC_Order $order ): string {
	$method   = (string) $order->get_payment_method();
	$gateways = function_exists( 'WC' ) && WC()->payment_gateways() ? WC()->payment_gateways()->payment_gateways() : array();
	$gateway  = $gateways[ $method ] ?? null;
	$label    = $gateway instanceof WC_Payment_Gateway ? (string) $gateway->get_title() : '';
	$label    = '' !== trim( wp_strip_all_tags( $label ) ) ? $label : $order->get_payment_method_title();
	$label    = trim( (string) preg_replace( '/\s*\(.*\)\s*$/', '', wp_strip_all_tags( $label ) ) );
	/**
	 * Payment method of an order as the emails show it (module checkout: «Tarjeta ···· 4242»).
	 *
	 * @since 0.8.0
	 *
	 * @param string   $label Method title without the gateway's details.
	 * @param WC_Order $order Order.
	 */
	return (string) apply_filters( 'lachinata/order/payment_label', $label, $order );
}

/**
 * Whether the order is paid by bank transfer (WooCommerce's BACS).
 *
 * @param WC_Order $order Order.
 */
function lachinata_email_is_transfer( WC_Order $order ): bool {
	return 'bacs' === $order->get_payment_method();
}

/**
 * Whether the order is paid with PayPal.
 *
 * @param WC_Order $order Order.
 */
function lachinata_email_is_paypal( WC_Order $order ): bool {
	$method = (string) $order->get_payment_method();
	return str_starts_with( $method, 'ppcp' ) || str_contains( $method, 'paypal' );
}

/**
 * A phone as the country writes it: «600 000 000» in Spain (without +34 when the address is
 * Spanish); elsewhere, as it was typed.
 *
 * @param string $phone   Phone.
 * @param string $country Country of the address.
 */
function lachinata_email_phone( string $phone, string $country ): string {
	$digits = (string) preg_replace( '/\D/', '', $phone );
	if ( 'ES' === $country ) {
		$digits = 11 === strlen( $digits ) && str_starts_with( $digits, '34' ) ? substr( $digits, 2 ) : $digits;
		if ( 9 === strlen( $digits ) ) {
			return implode( ' ', str_split( $digits, 3 ) );
		}
	}
	return trim( $phone );
}

/**
 * Key facts of an email: label, value and note, keyed so a module can replace one.
 *
 * @param WC_Email|null $email Email.
 * @return array<string, array{label: string, value: string, note: string}>
 */
function lachinata_email_facts( ?WC_Email $email ): array {
	$order = lachinata_email_order( $email );
	$facts = array();
	$id    = lachinata_email_id( $email );
	if ( null !== $order ) {
		$shipping = lachinata_email_shipping_item( $order );
		$address  = array(
			/* translators: label of the delivery address in the key facts of an email. */
			'label' => 'customer_completed_order' === $id ? __( 'Entrega en', 'lachinata' ) : __( 'Dirección', 'lachinata' ),
			'value' => trim( $order->get_shipping_address_1() ),
			'note'  => trim( $order->get_shipping_postcode() . ' ' . $order->get_shipping_city() ),
		);
		$method   = lachinata_order_payment_label( $order );
		// A phone order has no method yet: the value is «Pendiente» and nothing goes under it.
		$payment  = '' === $method && ! $order->is_paid()
			? array(
				'label' => __( 'Pago', 'lachinata' ),
				'value' => __( 'Pendiente', 'lachinata' ),
				'note'  => '',
			)
			: array(
				'label' => __( 'Pago', 'lachinata' ),
				'value' => $method,
				'note'  => lachinata_email_paid_note( $order ),
			);
		$delivery = null === $shipping ? null : array(
			'label' => __( 'Envío', 'lachinata' ),
			'value' => $shipping->get_name(),
			'note'  => lachinata_email_shipping_cost( $order, $shipping ),
		);
		$total    = array(
			'label' => __( 'Importe', 'lachinata' ),
			'value' => lachinata_email_plain_price( (float) $order->get_total(), $order->get_currency() ),
			'note'  => lachinata_email_tax_note( $order ),
		);
		switch ( $id ) {
			case 'customer_invoice':
				// The payment link of a phone order: what to pay; the dates go in its note.
				$facts = $order->needs_payment()
					? array(
						'amount'  => $total,
						'payment' => $payment,
						'address' => $address,
					)
					: array(
						'delivery' => $delivery,
						'address'  => $address,
						'payment'  => $payment,
					);
				break;
			case 'customer_processing_order':
				$facts = array(
					'delivery' => $delivery,
					'address'  => $address,
					'payment'  => $payment,
				);
				break;
			case 'customer_on_hold_order':
				$facts = array(
					'amount'  => $total,
					'payment' => $payment,
					'address' => $address,
				);
				break;
			case 'customer_completed_order':
				$facts = array( 'address' => $address );
				break;
			case 'customer_refunded_order':
				$paypal = lachinata_email_is_paypal( $order );
				$facts  = array(
					'amount' => array(
						'label' => __( 'Importe', 'lachinata' ),
						'value' => lachinata_email_plain_price( null === $email ? 0.0 : lachinata_email_refund_amount( $email, $order ), $order->get_currency() ),
						'note'  => $order->get_total_refunded() >= (float) $order->get_total() ? __( 'Todo el pedido', 'lachinata' ) : __( 'Parte del pedido', 'lachinata' ),
					),
					// PayPal: where it goes and no time. A card: the bank's days, as a third fact.
					'method' => array(
						'label' => __( 'Devuelto a', 'lachinata' ),
						'value' => lachinata_order_payment_label( $order ),
						'note'  => $paypal ? __( 'En tu cuenta de PayPal', 'lachinata' ) : __( 'El mismo medio de pago', 'lachinata' ),
					),
				);
				if ( ! $paypal ) {
					$facts['term'] = array(
						'label' => __( 'Plazo', 'lachinata' ),
						'value' => __( '5–10 días hábiles', 'lachinata' ),
						'note'  => __( 'Según tu banco', 'lachinata' ),
					);
				}
				break;
			case 'new_order':
			case 'cancelled_order':
			case 'failed_order':
				$phone   = $order->get_billing_phone() ? $order->get_billing_phone() : $order->get_shipping_phone();
				$contact = array_filter( array( $order->get_billing_email(), lachinata_email_phone( $phone, $order->get_shipping_country() ? $order->get_shipping_country() : $order->get_billing_country() ) ) );
				$facts   = array(
					'customer' => array(
						'label' => __( 'Cliente', 'lachinata' ),
						'value' => trim( $order->get_formatted_billing_full_name() ),
						'note'  => implode( ' · ', $contact ),
					),
					'shipping' => null === $shipping ? null : array(
						'label' => __( 'Envío', 'lachinata' ),
						/* translators: 1: shipping method, 2: shipping instance id. */
						'value' => sprintf( __( '%1$s · ID %2$s', 'lachinata' ), $shipping->get_name(), (string) $shipping->get_instance_id() ),
						'note'  => lachinata_email_shipping_cost( $order, $shipping ),
					),
					'payment'  => $payment,
				);
				break;
		}
	}
	$facts = array_filter( $facts );

	/**
	 * Key facts of an email (06-correos.md, `facts`): 2–3 at most. The eta module puts the
	 * delivery dates, shipment the carrier and the tracking number.
	 *
	 * @since 0.8.0
	 *
	 * @param array<string, array{label: string, value: string, note?: string}> $facts Facts by key (plain text).
	 * @param WC_Order|null                                                      $order Order.
	 * @param WC_Email|null                                                      $email Email.
	 */
	$facts = (array) apply_filters( 'lachinata/email/facts', $facts, $order, $email );
	$out   = array();
	foreach ( $facts as $key => $fact ) {
		if ( ! is_array( $fact ) || '' === trim( (string) ( $fact['value'] ?? '' ) ) ) {
			continue;
		}
		$out[ (string) $key ] = array(
			'label' => (string) ( $fact['label'] ?? '' ),
			'value' => (string) $fact['value'],
			'note'  => (string) ( $fact['note'] ?? '' ),
		);
	}
	return array_slice( $out, 0, 3, true );
}

/**
 * «IVA incluido» (each language names its VAT: DPH in Czech), or «Impuestos incluidos»
 * outside the EU.
 *
 * @param WC_Order $order Order.
 */
function lachinata_email_tax_note( WC_Order $order ): string {
	if ( wc_tax_enabled() && 'excl' === get_option( 'woocommerce_tax_display_cart' ) ) {
		return '';
	}
	$eu = in_array( $order->get_billing_country() ? $order->get_billing_country() : WC()->countries->get_base_country(), WC()->countries->get_european_union_countries( 'eu_vat' ), true );
	return $eu ? __( 'IVA incluido', 'lachinata' ) : __( 'Impuestos incluidos', 'lachinata' );
}

/**
 * The button of an email, or null.
 *
 * @param WC_Email|null $email Email.
 * @return array{label: string, url: string, variant: string}|null
 */
function lachinata_email_button( ?WC_Email $email ): ?array {
	$order  = lachinata_email_order( $email );
	$id     = lachinata_email_id( $email );
	$button = null;
	$view   = null === $order ? null : array(
		'label'   => __( 'Ver mi pedido', 'lachinata' ),
		'url'     => lachinata_email_order_url( $order ),
		'variant' => 'primary',
	);
	switch ( $id ) {
		case 'customer_processing_order':
		case 'customer_completed_order':
		case 'customer_refunded_order':
		case 'customer_note':
			$button = $view;
			break;
		case 'customer_on_hold_order':
			$button = $view;
			break;
		case 'customer_invoice':
			$button = null !== $order && $order->needs_payment()
				? array(
					/* translators: %s: order total («69,85 €»). */
					'label'   => sprintf( __( 'Pagar %s', 'lachinata' ), lachinata_email_plain_price( (float) $order->get_total(), $order->get_currency() ) ),
					'url'     => $order->get_checkout_payment_url(),
					'variant' => 'primary',
				)
				: $view;
			break;
		case 'customer_failed_order':
			if ( null !== $order ) {
				$button = array(
					'label'   => __( 'Volver a intentarlo', 'lachinata' ),
					'url'     => $order->needs_payment() ? $order->get_checkout_payment_url() : (string) wc_get_page_permalink( 'shop' ),
					'variant' => 'primary',
				);
			}
			break;
		case 'customer_cancelled_order':
			$button = array(
				'label'   => __( 'Volver a la tienda', 'lachinata' ),
				'url'     => (string) wc_get_page_permalink( 'shop' ),
				'variant' => 'primary',
			);
			break;
		case 'new_order':
		case 'cancelled_order':
		case 'failed_order':
			if ( null !== $order ) {
				$button = array(
					'label'   => __( 'Abrir en WooCommerce', 'lachinata' ),
					'url'     => $order->get_edit_order_url(),
					'variant' => 'primary',
				);
			}
			break;
		case 'customer_new_account':
			$set    = $email instanceof WC_Email_Customer_New_Account ? (string) $email->set_password_url : '';
			$button = array(
				'label'   => '' !== $set ? __( 'Elegir mi contraseña', 'lachinata' ) : __( 'Entrar en mi cuenta', 'lachinata' ),
				'url'     => '' !== $set ? $set : (string) wc_get_page_permalink( 'myaccount' ),
				'variant' => 'primary',
			);
			break;
		case 'customer_reset_password':
			$key    = $email instanceof WC_Email_Customer_Reset_Password ? (string) $email->reset_key : '';
			$user   = $email instanceof WC_Email_Customer_Reset_Password ? (int) $email->user_id : 0;
			$button = '' === $key ? null : array(
				'label'   => __( 'Elegir nueva contraseña', 'lachinata' ),
				'url'     => add_query_arg(
					array(
						'key'   => $key,
						'id'    => $user,
						'login' => rawurlencode( $email instanceof WC_Email_Customer_Reset_Password ? (string) $email->user_login : '' ),
					),
					wc_get_endpoint_url( 'lost-password', '', wc_get_page_permalink( 'myaccount' ) )
				),
				'variant' => 'primary',
			);
			break;
	}

	/**
	 * The one button of an email: label (without the arrow), URL and variant (primary, or
	 * secondary for the notice to a gift's recipient). Null: no button.
	 *
	 * @since 0.8.0
	 *
	 * @param array{label: string, url: string, variant: string}|null $button Button.
	 * @param WC_Email|null                                          $email  Email.
	 */
	$button = apply_filters( 'lachinata/email/button', $button, $email );
	if ( ! is_array( $button ) || '' === (string) ( $button['url'] ?? '' ) || '' === (string) ( $button['label'] ?? '' ) ) {
		return null;
	}
	return array(
		'label'   => (string) $button['label'],
		'url'     => (string) $button['url'],
		'variant' => 'secondary' === ( $button['variant'] ?? '' ) ? 'secondary' : 'primary',
	);
}

/**
 * HTML of the key facts.
 *
 * @param array<string, array{label: string, value: string, note: string}> $facts Facts.
 */
function lachinata_email_facts_html( array $facts ): string {
	if ( ! $facts ) {
		return '';
	}
	$width = (int) floor( 100 / count( $facts ) ) . '%';
	$cells = '';
	foreach ( $facts as $fact ) {
		$cells .= sprintf(
			'<td class="lc-mail-fact lc-mail-stack" width="%1$s" valign="top"><p class="lc-mail-label">%2$s</p><p class="lc-mail-fact__value">%3$s</p>%4$s</td>',
			esc_attr( $width ),
			esc_html( $fact['label'] ),
			esc_html( $fact['value'] ),
			'' !== $fact['note'] ? '<p class="lc-mail-fact__note">' . esc_html( $fact['note'] ) . '</p>' : ''
		);
	}
	return '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" class="lc-mail-facts"><tr><td class="lc-mail-facts__cell"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" class="lc-mail-facts__row"><tr>' . $cells . '</tr></table></td></tr></table>';
}

/**
 * HTML of the button: «Verbo + objeto →».
 *
 * @param array{label: string, url: string, variant: string} $button Button.
 */
function lachinata_email_button_html( array $button ): string {
	$secondary = 'secondary' === $button['variant'];
	return sprintf(
		'<table role="presentation" cellpadding="0" cellspacing="0" class="lc-mail-btn%1$s"><tr><td align="center" bgcolor="%2$s" class="lc-mail-btn__cell"><a href="%3$s" class="lc-mail-btn__link">%4$s&nbsp;&rarr;</a></td></tr></table>',
		$secondary ? ' lc-mail-btn--secondary' : '',
		esc_attr( $secondary ? LACHINATA_EMAIL_COLORS['surface'] : LACHINATA_EMAIL_COLORS['ink'] ),
		esc_url( $button['url'] ),
		esc_html( $button['label'] )
	);
}

/**
 * HTML of a note: a title and a text, with the black rule on the left.
 *
 * @param string $title Title (plain).
 * @param string $html  Text (HTML, already escaped).
 */
function lachinata_email_note( string $title, string $html ): string {
	return sprintf(
		'<table role="presentation" width="100%%" cellpadding="0" cellspacing="0" class="lc-mail-note"><tr><td class="lc-mail-note__cell">%1$s<div class="lc-mail-note__text">%2$s</div></td></tr></table>',
		'' !== $title ? '<p class="lc-mail-note__title">' . esc_html( $title ) . '</p>' : '',
		$html
	);
}

/**
 * «Datos para la transferencia» of an order waiting for a bank transfer: holder, IBAN, bank
 * and the reference «Pedido {nº}», from WooCommerce's bank transfer settings (BACS).
 *
 * @param WC_Order $order Order.
 */
function lachinata_email_transfer_note( WC_Order $order ): string {
	$accounts = get_option( 'woocommerce_bacs_accounts', array() );
	$lines    = array();
	foreach ( is_array( $accounts ) ? $accounts : array() as $account ) {
		if ( ! is_array( $account ) ) {
			continue;
		}
		$rows = array(
			__( 'Titular', 'lachinata' ) => (string) ( $account['account_name'] ?? '' ),
			__( 'IBAN', 'lachinata' )    => (string) ( $account['iban'] ?? '' ),
			__( 'Banco', 'lachinata' )   => (string) ( $account['bank_name'] ?? '' ),
		);
		foreach ( $rows as $label => $value ) {
			if ( '' !== trim( $value ) ) {
				/* translators: 1: label («IBAN»), 2: value. */
				$lines[] = sprintf( esc_html__( '%1$s: %2$s', 'lachinata' ), esc_html( $label ), '<span data-no-translation>' . esc_html( trim( $value ) ) . '</span>' );
			}
		}
	}
	/* translators: %s: order number. */
	$lines[] = sprintf( esc_html__( 'Concepto: %s', 'lachinata' ), '<span data-no-translation>' . esc_html( sprintf( __( 'Pedido %s', 'lachinata' ), $order->get_order_number() ) ) . '</span>' );
	return lachinata_email_note( __( 'Datos para la transferencia', 'lachinata' ), '<p>' . implode( '<br>', $lines ) . '</p>' );
}

/**
 * «La fecha de entrega empieza a contar cuando pagues» in the payment link of an order made
 * by phone, with the dates if it is paid today (module eta, `lachinata/email/pay_today`).
 *
 * @param WC_Order $order Order.
 */
function lachinata_email_pay_note( WC_Order $order ): string {
	/**
	 * When an order waiting for its payment arrives if it is paid today, as a sentence
	 * («Si lo pagas hoy, llega jue 24 – vie 25 oct.»); empty without dates.
	 *
	 * @since 0.8.0
	 *
	 * @param string   $text  Empty by default.
	 * @param WC_Order $order Order.
	 */
	$text = trim( (string) apply_filters( 'lachinata/email/pay_today', '', $order ) );
	return lachinata_email_note( __( 'La fecha de entrega empieza a contar cuando pagues', 'lachinata' ), '' === $text ? '' : '<p>' . esc_html( $text ) . '</p>' );
}

/**
 * Between the key facts and the button: the transfer details of an order waiting for a bank
 * transfer, since paying is what there is to do and it needs the IBAN and the reference.
 *
 * @param WC_Order|null $order Order.
 * @param WC_Email|null $email Email.
 */
function lachinata_email_after_facts( ?WC_Order $order, ?WC_Email $email ): string {
	if ( null !== $order && 'customer_on_hold_order' === lachinata_email_id( $email ) && lachinata_email_is_transfer( $order ) ) {
		return lachinata_email_transfer_note( $order );
	}
	return '';
}

/**
 * The theme's notes before the product lines: the delivery of an order still to pay.
 *
 * @param WC_Order      $order Order.
 * @param WC_Email|null $email Email.
 */
function lachinata_email_order_notes( WC_Order $order, ?WC_Email $email ): string {
	$id = lachinata_email_id( $email );
	if ( 'customer_invoice' === $id && $order->needs_payment() ) {
		return lachinata_email_pay_note( $order );
	}
	return '';
}

/**
 * Background colour of a product's tint for the email thumbnail («#e5fceb»).
 *
 * @param WC_Product|null $product Product.
 */
function lachinata_email_tint( ?WC_Product $product ): string {
	static $palette = null;
	if ( null === $palette ) {
		$palette = array();
		foreach ( (array) wp_get_global_settings( array( 'color', 'palette', 'theme' ) ) as $color ) {
			if ( is_array( $color ) && isset( $color['slug'], $color['color'] ) ) {
				$palette[ (string) $color['slug'] ] = (string) $color['color'];
			}
		}
	}
	$tint = null === $product ? '' : lachinata_product_tint( $product );
	return $palette[ 'tint-' . $tint ] ?? LACHINATA_EMAIL_COLORS['surface-3'];
}

/**
 * Second line of a product line: content, options and units («300 g · 2 ud»).
 *
 * @param WC_Order_Item_Product $item Line.
 * @param WC_Product|null       $product Product.
 */
function lachinata_email_line_meta( WC_Order_Item_Product $item, ?WC_Product $product ): string {
	$parts   = array();
	$content = null === $product ? '' : lachinata_product_content( $product );
	if ( '' !== $content ) {
		$parts[] = $content;
	} elseif ( $product instanceof WC_Product_Variation ) {
		foreach ( $product->get_variation_attributes( false ) as $taxonomy => $value ) {
			$term    = taxonomy_exists( $taxonomy ) ? get_term_by( 'slug', $value, $taxonomy ) : false;
			$parts[] = $term instanceof WP_Term ? lachinata_term_name( $term ) : (string) $value;
		}
	}
	$quantity = abs( (int) $item->get_quantity() );
	if ( $quantity > 1 ) {
		/* translators: %s: number of units («2 ud»). */
		$parts[] = sprintf( __( '%s ud', 'lachinata' ), number_format_i18n( $quantity ) );
	}
	return implode( ' · ', array_filter( $parts ) );
}

/**
 * Lines an email lists: what was refunded in a refund email (when the refund has lines),
 * the order's otherwise.
 *
 * @param WC_Order      $order Order.
 * @param WC_Email|null $email Email.
 * @return array<int|string, WC_Order_Item>
 */
function lachinata_email_items( WC_Order $order, ?WC_Email $email ): array {
	$refund = null !== $email && property_exists( $email, 'refund' ) ? $email->refund : null;
	if ( $refund instanceof WC_Order_Refund && $refund->get_items() ) {
		return $refund->get_items();
	}
	return $order->get_items();
}

/**
 * HTML of the product lines.
 *
 * @param WC_Order                         $order   Order.
 * @param array<int|string, WC_Order_Item> $items   Lines.
 * @param bool                             $compact Without photo (shipped email, internal emails).
 */
function lachinata_email_lines( WC_Order $order, array $items, bool $compact ): string {
	$rows = lachinata_email_line_rows( $order, $items, $compact );
	return '' === $rows ? '' : '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" class="lc-mail-lines">' . $rows . '</table>';
}

/**
 * Rows of the product lines (<tr>), for lachinata_email_lines() and email-order-items.php.
 *
 * @param WC_Order                         $order   Order.
 * @param array<int|string, WC_Order_Item> $items   Lines.
 * @param bool                             $compact Without photo.
 */
function lachinata_email_line_rows( WC_Order $order, array $items, bool $compact ): string {
	$rows  = '';
	$first = true;
	foreach ( $items as $item ) {
		if ( ! $item instanceof WC_Order_Item_Product ) {
			continue;
		}
		$product  = $item->get_product();
		$product  = $product instanceof WC_Product ? $product : null;
		$quantity = abs( (int) $item->get_quantity() );
		$amount   = abs( (float) $item->get_subtotal() + ( 'excl' === get_option( 'woocommerce_tax_display_cart' ) ? 0.0 : (float) $item->get_subtotal_tax() ) );
		$meta     = lachinata_email_line_meta( $item, $product );
		$thumb    = '';
		if ( ! $compact ) {
			$image = null === $product ? '' : (string) wp_get_attachment_image_url( (int) $product->get_image_id(), 'thumbnail' );
			$thumb = sprintf(
				'<td class="lc-mail-line__thumb" width="64" valign="top">%s</td>',
				'' !== $image
					? sprintf( '<img src="%1$s" width="64" height="64" alt="%2$s" class="lc-mail-line__img" style="background:%3$s">', esc_url( $image ), esc_attr( $item->get_name() ), esc_attr( lachinata_email_tint( $product ) ) )
					: sprintf( '<div style="width:64px;height:64px;background:%s;"></div>', esc_attr( lachinata_email_tint( $product ) ) )
			);
		}
		ob_start();
		/**
		 * WooCommerce: start of the item meta in an email (add-ons print here).
		 *
		 * @since 2.3.0
		 */
		do_action( 'woocommerce_order_item_meta_start', $item->get_id(), $item, $order, false ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook.
		/**
		 * WooCommerce: end of the item meta in an email.
		 *
		 * @since 2.3.0
		 */
		do_action( 'woocommerce_order_item_meta_end', $item->get_id(), $item, $order, false ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook.
		$extra = trim( (string) ob_get_clean() );
		$rows .= sprintf(
			'<tr class="lc-mail-line%1$s%2$s">%3$s<td class="lc-mail-line__main" valign="top"><p class="lc-mail-line__name">%4$s</p>%5$s%6$s</td><td class="lc-mail-line__amount" align="right" valign="top"><p class="lc-mail-line__price" data-no-translation>%7$s</p>%8$s</td></tr>',
			$first ? '' : ' lc-mail-line--next',
			$compact ? ' lc-mail-line--compact' : '',
			$thumb,
			esc_html( $item->get_name() ),
			'' !== $meta ? '<p class="lc-mail-line__meta">' . esc_html( $meta ) . '</p>' : '',
			'' !== $extra ? '<div class="lc-mail-line__meta">' . wp_kses_post( $extra ) . '</div>' : '',
			esc_html( lachinata_email_plain_price( $amount, $order->get_currency() ) ),
			$quantity > 1
				/* translators: %s: price of one unit. */
				? '<p class="lc-mail-line__unit" data-no-translation>' . esc_html( sprintf( __( '%s / ud', 'lachinata' ), lachinata_email_plain_price( $amount / $quantity, $order->get_currency() ) ) ) . '</p>'
				: ''
		);
		$first = false;
	}
	return $rows;
}

/**
 * HTML of the totals: subtotal, discounts and fees, shipping (with «Gratis»), refunds and
 * total with the tax note.
 *
 * @param WC_Order $order Order.
 */
function lachinata_email_totals( WC_Order $order ): string {
	$rows = '';
	$row  = static function ( string $label, string $value, bool $free = false ) use ( &$rows ): void {
		$rows .= sprintf(
			'<tr><td class="lc-mail-totals__cell"><p class="lc-mail-totals__label">%1$s</p></td><td class="lc-mail-totals__cell" align="right"><p class="lc-mail-totals__value%2$s" data-no-translation>%3$s</p></td></tr>',
			esc_html( $label ),
			$free ? ' lc-mail-totals__free' : '',
			esc_html( $value )
		);
	};
	foreach ( $order->get_order_item_totals() as $key => $total ) {
		if ( in_array( $key, array( 'shipping', 'payment_method', 'order_total' ), true ) ) {
			continue;
		}
		$row( rtrim( wp_strip_all_tags( (string) $total['label'] ), ': ' ), html_entity_decode( wp_strip_all_tags( (string) $total['value'] ), ENT_QUOTES, 'UTF-8' ) );
		if ( 'cart_subtotal' === $key ) {
			foreach ( $order->get_items( 'shipping' ) as $line ) {
				if ( ! $line instanceof WC_Order_Item_Shipping ) {
					continue;
				}
				/**
				 * Label of the shipping line in the totals of an email (eta adds the dates:
				 * «Envío estándar · jue 24 – vie 25 oct»).
				 *
				 * @since 0.8.0
				 *
				 * @param string                 $label Method name.
				 * @param WC_Order_Item_Shipping $line  Shipping line.
				 * @param WC_Order               $order Order.
				 */
				$label = (string) apply_filters( 'lachinata/email/shipping_label', $line->get_name(), $line, $order );
				$cost  = lachinata_email_shipping_cost( $order, $line );
				$row( $label, $cost, __( 'Gratis', 'lachinata' ) === $cost );
			}
		}
	}
	$tax   = lachinata_email_tax_note( $order );
	$rows .= sprintf(
		'<tr><td class="lc-mail-totals__total"><p class="lc-mail-totals__total-label">%1$s</p></td><td class="lc-mail-totals__total" align="right"><p class="lc-mail-totals__total-value" data-no-translation>%2$s</p>%3$s</td></tr>',
		esc_html__( 'Total', 'lachinata' ),
		esc_html( lachinata_email_plain_price( (float) $order->get_total() - (float) $order->get_total_refunded(), $order->get_currency() ) ),
		'' !== $tax ? '<p class="lc-mail-totals__tax">' . esc_html( $tax ) . '</p>' : ''
	);
	return '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" class="lc-mail-totals">' . $rows . '</table>';
}

/**
 * Lines of an address for an email.
 *
 * @param WC_Order $order Order.
 * @param string   $type  shipping or billing.
 * @return string[]
 */
function lachinata_email_address_lines( WC_Order $order, string $type ): array {
	$get   = static fn( string $field ): string => trim( (string) call_user_func( array( $order, "get_{$type}_{$field}" ) ) );
	$state = $get( 'state' );
	$state = '' !== $state ? ( WC()->countries->get_states( $get( 'country' ) )[ $state ] ?? $state ) : '';
	$place = trim( $get( 'postcode' ) . ' ' . $get( 'city' ) ) . ( '' !== $state && $state !== $get( 'city' ) ? ', ' . $state : '' );
	$lines = array(
		trim( $get( 'first_name' ) . ' ' . $get( 'last_name' ) ),
		$get( 'company' ),
		trim( $get( 'address_1' ) . ' ' . $get( 'address_2' ) ),
		$place,
	);
	if ( $get( 'country' ) !== WC()->countries->get_base_country() && '' !== $get( 'country' ) ) {
		$lines[] = WC()->countries->get_countries()[ $get( 'country' ) ] ?? $get( 'country' );
	}
	return array_values( array_filter( $lines ) );
}

/**
 * HTML of the shipping and billing addresses, in two columns.
 *
 * @param WC_Order $order Order.
 */
function lachinata_email_addresses( WC_Order $order ): string {
	$shipping = lachinata_email_address_lines( $order, 'shipping' );
	$billing  = lachinata_email_address_lines( $order, 'billing' );
	$columns  = array();
	if ( $shipping ) {
		$phone     = lachinata_email_phone( $order->get_shipping_phone(), $order->get_shipping_country() );
		$columns[] = array( __( 'Envío', 'lachinata' ), array_merge( $shipping, array_filter( array( $phone ) ) ) );
	}
	$same = array_slice( $billing, 1 ) === array_slice( $shipping, 1 );
	if ( $billing ) {
		$columns[] = array(
			__( 'Facturación', 'lachinata' ),
			array_values(
				array_filter(
					array_merge(
						$same && $shipping ? array( $billing[0], __( 'La misma dirección que la de envío', 'lachinata' ) ) : $billing,
						array( $order->get_billing_email() )
					)
				)
			),
		);
	}
	if ( ! $columns ) {
		return '';
	}
	$cells = '';
	foreach ( $columns as $column ) {
		$cells .= sprintf(
			'<td class="lc-mail-address lc-mail-stack" width="50%%" valign="top"><p class="lc-mail-label">%1$s</p><p class="lc-mail-address__text" data-no-translation>%2$s</p></td>',
			esc_html( $column[0] ),
			implode( '<br>', array_map( 'esc_html', $column[1] ) )
		);
	}
	return '<table role="presentation" width="100%" cellpadding="0" cellspacing="0" class="lc-mail-addresses"><tr>' . $cells . '</tr></table>';
}

/**
 * Lead of the email of a phone order: Apple Pay and Google Pay only if the shop offers them
 * (`lachinata/checkout/wallets`, the checkout module with Stripe).
 */
function lachinata_email_pay_lead(): string {
	/** This filter is documented in theme/woocommerce/checkout/form-pay.php */
	return (bool) apply_filters( 'lachinata/checkout/wallets', false ) // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingSinceComment -- Documented there.
		? __( 'Lo hemos preparado contigo por teléfono. Puedes pagarlo con tarjeta, Apple Pay, Google Pay o PayPal desde el botón.', 'lachinata' )
		: __( 'Lo hemos preparado contigo por teléfono. Puedes pagarlo con tarjeta o PayPal desde el botón.', 'lachinata' );
}

/**
 * HTML of «¿Alguna duda?»: WhatsApp (or phone) of the shop, «responde a este correo» and
 * the opening hours, from «Atención al cliente».
 */
function lachinata_email_help(): string {
	$contact = lachinata_contact();
	$link    = static fn( string $url, string $text ): string => sprintf( '<a href="%1$s" data-no-translation>%2$s</a>', esc_url( $url, array( 'https', 'tel' ) ), esc_html( $text ) );
	if ( '' !== $contact['whatsapp'] && '' !== $contact['whatsapp_url'] ) {
		/* translators: %s: WhatsApp number of the shop, as a link. */
		$text = sprintf( esc_html__( 'Escríbenos por WhatsApp al %s o responde a este correo.', 'lachinata' ), $link( $contact['whatsapp_url'], $contact['whatsapp'] ) );
	} elseif ( '' !== $contact['phone'] && '' !== $contact['phone_url'] ) {
		/* translators: %s: phone of the shop, as a link. */
		$text = sprintf( esc_html__( 'Llámanos al %s o responde a este correo.', 'lachinata' ), $link( $contact['phone_url'], $contact['phone'] ) );
	} else {
		$text = esc_html__( 'Responde a este correo y te ayudamos.', 'lachinata' );
	}
	if ( '' !== $contact['hours'] ) {
		$text .= ' ' . esc_html( $contact['hours'] );
	}
	return sprintf(
		'<table role="presentation" width="100%%" cellpadding="0" cellspacing="0" class="lc-mail-help"><tr><td class="lc-mail-help__cell"><p class="lc-mail-help__title">%1$s</p><p class="lc-mail-help__text">%2$s</p></td></tr></table>',
		esc_html__( '¿Alguna duda?', 'lachinata' ),
		$text
	);
}

/**
 * First line of the footer: «La Chinata · Plasencia, Cáceres · desde 1932», with the city
 * and province of the shop in WooCommerce → Ajustes → Generales.
 */
function lachinata_email_footer_place(): string {
	$city    = trim( (string) get_option( 'woocommerce_store_city' ) );
	$base    = explode( ':', (string) get_option( 'woocommerce_default_country' ) );
	$state   = isset( $base[1] ) ? (string) ( WC()->countries->get_states( $base[0] )[ $base[1] ] ?? '' ) : '';
	$place   = implode( ', ', array_filter( array( $city, $state !== $city ? $state : '' ) ) );
	$parts   = array_filter( array( lachinata_email_brand(), $place ) );
	$parts[] = __( 'desde 1932', 'lachinata' );
	return implode( ' · ', $parts );
}

/**
 * First line of the footer as HTML (the gift module adds «¿Qué es La Chinata?» to the
 * recipient's).
 *
 * @param WC_Email|null $email Email.
 */
function lachinata_email_footer_line( ?WC_Email $email = null ): string {
	/**
	 * First line of the footer of an email (HTML): the shop and its city.
	 *
	 * @since 0.8.0
	 *
	 * @param string        $html  «La Chinata · Plasencia, Cáceres · desde 1932», escaped.
	 * @param WC_Email|null $email Email.
	 */
	return (string) apply_filters( 'lachinata/email/footer_line', esc_html( lachinata_email_footer_place() ), $email );
}

/**
 * Links of the footer (06-correos.md, «Pie según destinatario»): for the buyer, the «Pie de
 * correos» menu or, without it, Mi cuenta and Privacidad; none in the internal emails; the
 * gift module leaves the recipient's without them (no account).
 *
 * @param WC_Email|null $email Email.
 * @return array<int, array{title: string, url: string}>
 */
function lachinata_email_footer_links( ?WC_Email $email = null ): array {
	if ( null !== $email && ! $email->is_customer_email() ) {
		return array();
	}
	/**
	 * Links of the footer of an email; an empty list leaves the line out.
	 *
	 * @since 0.8.0
	 *
	 * @param array<int, array{title: string, url: string}>|null $links Null: the theme's.
	 * @param WC_Email|null                                      $email Email.
	 */
	$filtered = apply_filters( 'lachinata/email/footer_links', null, $email );
	if ( is_array( $filtered ) ) {
		return $filtered;
	}
	$links = array();
	foreach ( lachinata_menu( 'email-footer' ) as $item ) {
		$links[] = array(
			'title' => $item['title'],
			'url'   => $item['url'],
		);
	}
	if ( $links ) {
		return $links;
	}
	$account = (string) wc_get_page_permalink( 'myaccount' );
	if ( '' !== $account ) {
		$links[] = array(
			'title' => __( 'Mi cuenta', 'lachinata' ),
			'url'   => $account,
		);
	}
	$privacy = get_privacy_policy_url();
	if ( '' !== $privacy ) {
		$links[] = array(
			'title' => __( 'Privacidad', 'lachinata' ),
			'url'   => $privacy,
		);
	}
	return $links;
}

/**
 * Why the reader gets the email (last line of the footer), as HTML.
 *
 * @param WC_Email|null $email Email.
 */
function lachinata_email_reason( ?WC_Email $email ): string {
	$domain = lachinata_email_domain();
	$id     = lachinata_email_id( $email );
	if ( null !== $email && ! $email->is_customer_email() ) {
		/* translators: %s: site domain. */
		$text = sprintf( __( 'Correo interno de la tienda %s.', 'lachinata' ), $domain );
	} elseif ( in_array( $id, array( 'customer_new_account', 'customer_reset_password' ), true ) || null === lachinata_email_order( $email ) ) {
		/* translators: %s: site domain. */
		$text = sprintf( __( 'Recibes este correo porque tienes una cuenta en %s.', 'lachinata' ), $domain );
	} else {
		/* translators: %s: site domain. */
		$text = sprintf( __( 'Recibes este correo porque has hecho un pedido en %s.', 'lachinata' ), $domain );
	}
	/**
	 * Last line of the footer of an email: why the reader gets it (HTML; the gift module
	 * writes its own for the recipient).
	 *
	 * @since 0.8.0
	 *
	 * @param string        $html  Line, escaped.
	 * @param WC_Email|null $email Email.
	 */
	return (string) apply_filters( 'lachinata/email/footer_note', esc_html( $text ), $email );
}
