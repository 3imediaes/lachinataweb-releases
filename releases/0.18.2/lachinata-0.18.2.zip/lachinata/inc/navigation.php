<?php
/**
 * Menus as plain data for the system components.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Items of a menu location as a tree.
 *
 * @param string $location Menu location.
 * @return array<int, array{title: string, url: string, text: string, icon: string, current: bool, children: array<int, array<string, mixed>>}>
 */
function lachinata_menu( string $location ): array {
	$locations = get_nav_menu_locations();
	if ( empty( $locations[ $location ] ) ) {
		return array();
	}
	$items = wp_get_nav_menu_items( $locations[ $location ] );
	if ( ! is_array( $items ) ) {
		return array();
	}
	_wp_menu_item_classes_by_context( $items );
	/**
	 * URL of the section the current view belongs to, so its menu link is marked as current
	 * (the AppBar's `section`): a module's pages under one entry, such as every page of the
	 * store finder under «Oleotecas». '' for none.
	 *
	 * @since 0.12.0
	 *
	 * @param string $url URL of the section.
	 */
	$section = untrailingslashit( (string) apply_filters( 'lachinata/app_bar/section', '' ) );

	$by_id = array();
	foreach ( $items as $item ) {
		$classes            = array_filter( (array) $item->classes, static fn( $c ): bool => '' !== $c && ! str_starts_with( (string) $c, 'menu-item' ) && ! str_starts_with( (string) $c, 'current' ) );
		$by_id[ $item->ID ] = array(
			'title'    => (string) $item->title,
			'url'      => (string) $item->url,
			'text'     => (string) $item->description,
			'icon'     => $classes ? (string) reset( $classes ) : '',
			'current'  => in_array( 'current-menu-item', (array) $item->classes, true ) || ( '' !== $section && untrailingslashit( (string) $item->url ) === $section ),
			'parent'   => (int) $item->menu_item_parent,
			'children' => array(),
		);
	}
	$tree = array();
	foreach ( array_reverse( $by_id, true ) as $id => $item ) {
		if ( $item['parent'] && isset( $by_id[ $item['parent'] ] ) ) {
			array_unshift( $by_id[ $item['parent'] ]['children'], $by_id[ $id ] );
		}
	}
	foreach ( $by_id as $item ) {
		if ( ! $item['parent'] ) {
			$tree[] = $item;
		}
	}
	return $tree;
}

/**
 * Category of the current view (archive term or the main category of a product).
 */
function lachinata_current_category(): ?WP_Term {
	if ( is_tax( 'product_cat' ) ) {
		$term = get_queried_object();
		return $term instanceof WP_Term ? $term : null;
	}
	if ( is_singular( 'product' ) ) {
		$product = wc_get_product( get_queried_object_id() );
		return $product instanceof WC_Product ? lachinata_product_main_category( $product ) : null;
	}
	return null;
}

/**
 * Main category of a product: the one the shop marks as main (module `catalog`) or,
 * without it, its deepest category. Never just the first one of the list.
 *
 * @param WC_Product $product Product.
 */
function lachinata_product_main_category( WC_Product $product ): ?WP_Term {
	$id    = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();
	$terms = get_the_terms( $id, 'product_cat' );
	$terms = is_array( $terms ) ? $terms : array();
	usort( $terms, static fn( WP_Term $a, WP_Term $b ): int => count( get_ancestors( $b->term_id, 'product_cat', 'taxonomy' ) ) <=> count( get_ancestors( $a->term_id, 'product_cat', 'taxonomy' ) ) );
	/**
	 * Main category of a product (breadcrumb, eyebrow, cross-sell, tint).
	 *
	 * @since 0.12.2
	 *
	 * @param int        $term_id Category id: the deepest one by default, 0 without categories.
	 * @param WC_Product $product Product.
	 */
	$term_id = (int) apply_filters( 'lachinata/product/main_category', $terms ? $terms[0]->term_id : 0, $product );
	$term    = $term_id ? get_term( $term_id, 'product_cat' ) : null;
	return $term instanceof WP_Term ? $term : null;
}

/**
 * Top-level ancestor of a category.
 *
 * @param WP_Term $term Category.
 */
function lachinata_root_category( WP_Term $term ): WP_Term {
	$ancestors = get_ancestors( $term->term_id, 'product_cat', 'taxonomy' );
	$root      = $ancestors ? get_term( (int) end( $ancestors ), 'product_cat' ) : $term;
	return $root instanceof WP_Term ? $root : $term;
}

/**
 * Whether the view is a secondary one (AppBar shows «Volver» instead of the menu).
 */
function lachinata_is_secondary_view(): bool {
	$secondary = is_singular( 'product' ) || ( function_exists( 'is_account_page' ) && is_account_page() && ! is_page( wc_get_page_id( 'myaccount' ) ) );
	/**
	 * Whether the view is a secondary one: the mobile AppBar shows «Volver» instead of the
	 * menu (a page of a module, such as a store of `oleotecas`).
	 *
	 * @since 0.12.0
	 *
	 * @param bool $secondary Product page or a subpage of the account.
	 */
	return (bool) apply_filters( 'lachinata/view/secondary', $secondary );
}

/**
 * Where «Volver» of the mobile AppBar goes.
 *
 * @param string $url The theme's choice (the product's category, or home).
 */
function lachinata_back_url( string $url ): string {
	/**
	 * Where «Volver» goes on a secondary view (a store goes to its zone).
	 *
	 * @since 0.12.0
	 *
	 * @param string $url The product's category, or home.
	 */
	return (string) apply_filters( 'lachinata/view/back_url', $url );
}

/**
 * Breadcrumb items: [label, url] with the last one current.
 *
 * @return array<int, array{0: string, 1: string}>
 */
function lachinata_breadcrumb_items(): array {
	$items = array( array( __( 'Inicio', 'lachinata' ), home_url( '/' ) ) );
	$term  = lachinata_current_category();

	if ( is_shop() ) {
		$items[] = array( __( 'Tienda', 'lachinata' ), '' );
	} else {
		if ( $term ) {
			$ancestors = array_reverse( get_ancestors( $term->term_id, 'product_cat', 'taxonomy' ) );
			foreach ( $ancestors as $ancestor_id ) {
				$ancestor = get_term( $ancestor_id, 'product_cat' );
				if ( $ancestor instanceof WP_Term ) {
					$items[] = array( lachinata_term_name( $ancestor ), lachinata_term_url( $ancestor ) );
				}
			}
			$items[] = array( lachinata_term_name( $term ), is_singular( 'product' ) ? lachinata_term_url( $term ) : '' );
		}
		if ( is_singular() && ! is_front_page() ) {
			$items[] = array( get_the_title(), '' );
		} elseif ( is_search() ) {
			$items[] = array( __( 'Búsqueda', 'lachinata' ), '' );
		} elseif ( is_tax() && ! $term ) {
			$items[] = array( single_term_title( '', false ), '' );
		}
	}
	/**
	 * Breadcrumb items, [label, url] each, the last one the current page (url '' for an item
	 * without a link). A module fills the trail of its pages (Oleotecas › País › Zona › tienda).
	 *
	 * @since 0.12.0
	 *
	 * @param array<int, array{0: string, 1: string}> $items Inicio, categories and the page.
	 */
	$items = apply_filters( 'lachinata/breadcrumb/items', $items );
	return is_array( $items ) ? array_values( $items ) : array();
}
