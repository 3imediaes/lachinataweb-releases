<?php
/**
 * AgeNotice: a discreet line with «+18» in the product page and the bag of products with
 * alcohol. Args: text, class.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_text = (string) ( $args['text'] ?? '' );
if ( '' === $lachinata_text ) {
	return;
}
?>
<p class="<?php echo esc_attr( lachinata_cx( 'lc-age', 'caption', $args['class'] ?? '' ) ); ?>">
	<span class="lc-age__badge" aria-hidden="true">+18</span>
	<?php echo esc_html( $lachinata_text ); ?>
</p>
