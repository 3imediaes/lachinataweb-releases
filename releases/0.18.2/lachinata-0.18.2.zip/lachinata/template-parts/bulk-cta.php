<?php
/**
 * BulkCta («¿Es para tu empresa?»): link to ask for a quote for business gifts, under «Añadir
 * a la bolsa». Args: cta (lachinata_product_bulk_cta()), product (WC_Product).
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_cta     = $args['cta'] ?? null;
$lachinata_product = $args['product'] ?? null;
if ( ! is_array( $lachinata_cta ) || ! $lachinata_product instanceof WC_Product ) {
	return;
}
$lachinata_chat = 'whatsapp' === $lachinata_cta['channel'];
// What tracking sends with lc_bulk_quote.
$lachinata_data = (string) wp_json_encode(
	array(
		'id'      => $lachinata_product->get_id(),
		'sku'     => $lachinata_cta['sku'],
		'channel' => $lachinata_cta['channel'],
	)
);
?>
<a href="<?php echo esc_url( $lachinata_cta['href'] ); ?>" class="lc-bulk lc-buy__bulk" data-lc-bulk="<?php echo esc_attr( $lachinata_data ); ?>"<?php echo $lachinata_chat ? ' target="_blank" rel="noopener"' : ''; ?>>
	<span class="lc-bulk__in">
		<span class="lc-bulk__ic" aria-hidden="true"><?php echo lachinata_icon( 'gift' ); ?></span>
		<span class="lc-bulk__text">
			<span class="label"><?php echo esc_html( $lachinata_cta['title'] ); ?></span>
			<span class="body-sm"><?php echo esc_html( $lachinata_cta['text'] ); ?></span>
		</span>
		<span class="lc-bulk__go label"><?php echo esc_html( $lachinata_cta['cta'] ); ?><?php echo lachinata_icon( 'arrow-right', array( 'size' => 'sm' ) ); ?></span>
	</span>
</a>
