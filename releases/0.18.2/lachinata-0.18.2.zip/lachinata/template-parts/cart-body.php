<?php
/**
 * Bag content: CartLine list, notices, coupon, OrderSummary and «Tramitar pedido».
 * A real form posted to WooCommerce's cart handler; the script enhances it.
 * Args: context (page|sheet).
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_cart  = WC()->cart;
$lachinata_sheet = 'sheet' === ( $args['context'] ?? 'page' );
$lachinata_count = $lachinata_cart ? $lachinata_cart->get_cart_contents_count() : 0;
?>
<form class="lc-cart" action="<?php echo esc_url( wc_get_cart_url() ); ?>" method="post" data-lc-cart-form data-lc-count="<?php echo esc_attr( (string) $lachinata_count ); ?>">
	<?php wc_print_notices(); ?>
	<?php if ( ! $lachinata_cart || $lachinata_cart->is_empty() ) : ?>
		<div class="lc-cart__empty">
			<p class="body"><?php esc_html_e( 'Tu bolsa está vacía.', 'lachinata' ); ?></p>
			<?php
			echo lachinata_button(
				__( 'Ver la tienda', 'lachinata' ),
				array(
					'href' => wc_get_page_permalink( 'shop' ),
					'icon' => 'arrow-right',
				)
			); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped 
			?>
		</div>
	<?php else : ?>
		<div class="lc-cart__grid">
			<div class="lc-cart__lines">
				<?php
				/**
				 * Progress of the case of wine in the bag (CaseProgress): `count`, `size`,
				 * `discount`, `href` and `cta`. Null by default (not shown).
				 *
				 * @since 0.18.0
				 *
				 * @param array<string, mixed>|null $progress Progress.
				 */
				lachinata_part( 'case-progress', array( 'progress' => apply_filters( 'lachinata/cart/case_progress', null ) ) );
				?>
				<?php foreach ( $lachinata_cart->get_cart() as $lachinata_key => $lachinata_item ) : ?>
					<?php
					$lachinata_line = lachinata_cart_line( (string) $lachinata_key, $lachinata_item );
					if ( null === $lachinata_line ) {
						continue;
					}
					?>
					<?php
					/**
					 * Extra attributes of a line of the bag (`data-*`), as the measurement data of `tracking`.
					 *
					 * @since 0.10.0
					 *
					 * @param array<string, string> $attributes Attributes; none by default.
					 * @param array<string, mixed>  $item       Cart item.
					 * @param string                $key        Cart item key.
					 */
					$lachinata_line_attributes = (array) apply_filters( 'lachinata/cart/line_attributes', array(), $lachinata_item, (string) $lachinata_key );
					?>
					<div class="lc-line"<?php echo lachinata_attrs( array_filter( $lachinata_line_attributes, static fn( $name ): bool => str_starts_with( (string) $name, 'data-' ), ARRAY_FILTER_USE_KEY ) ); ?>>
						<div class="lc-line__media"<?php echo $lachinata_line['tint'] ? ' style="background: var(--tint-' . esc_attr( $lachinata_line['tint'] ) . ')"' : ''; ?>>
							<?php echo lachinata_product_image( $lachinata_line['image_id'], 'woocommerce_gallery_thumbnail', 'lc-line__halo', false, '88px' ); ?>
						</div>
						<div class="lc-line__body">
							<?php if ( $lachinata_line['href'] ) : ?>
								<a href="<?php echo esc_url( $lachinata_line['href'] ); ?>" class="lc-line__name h4"><?php echo esc_html( $lachinata_line['name'] ); ?></a>
							<?php else : ?>
								<span class="lc-line__name h4"><?php echo esc_html( $lachinata_line['name'] ); ?></span>
							<?php endif; ?>
							<?php if ( $lachinata_line['meta'] ) : ?>
								<span class="lc-line__meta body-sm" data-no-translation><?php echo esc_html( $lachinata_line['meta'] ); ?></span>
							<?php endif; ?>
							<?php if ( $lachinata_line['note'] ) : ?>
								<span class="lc-line__note caption"><?php echo lachinata_icon( 'info', array( 'size' => 'sm' ) ); ?><?php echo esc_html( $lachinata_line['note'] ); ?></span>
							<?php endif; ?>
							<div class="lc-line__foot">
								<?php
								if ( $lachinata_line['sold_one'] ) {
									printf( '<input type="hidden" name="cart[%s][qty]" value="1">', esc_attr( $lachinata_line['key'] ) );
								} else {
									echo lachinata_stepper(
										array(
											'name'  => 'cart[' . $lachinata_line['key'] . '][qty]',
											'value' => $lachinata_line['qty'],
											'min'   => 0,
											'max'   => $lachinata_line['max'],
											/* translators: %s: product name. */
											'label' => sprintf( __( 'Cantidad de %s', 'lachinata' ), $lachinata_line['name'] ),
										)
									);
								}
								?>
								<span class="price" data-no-translation><?php echo wp_kses_post( $lachinata_line['total'] ); ?></span>
								<a href="<?php echo esc_url( $lachinata_line['remove'] ); ?>" class="lc-line__remove" data-lc-remove aria-label="<?php echo esc_attr( sprintf( /* translators: %s: product name. */ __( 'Quitar %s de la bolsa', 'lachinata' ), $lachinata_line['name'] ) ); ?>" title="<?php esc_attr_e( 'Quitar', 'lachinata' ); ?>"><?php echo lachinata_icon( 'trash', array( 'size' => 'sm' ) ); ?></a>
							</div>
						</div>
					</div>
				<?php endforeach; ?>
				<?php
				echo lachinata_button(
					__( 'Actualizar bolsa', 'lachinata' ),
					array(
						'variant' => 'secondary',
						'type'    => 'submit',
						'class'   => 'lc-cart__update',
						'attrs'   => array(
							'name'  => 'update_cart',
							'value' => '1',
						),
					)
				); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped 
				?>
			</div>
			<div class="lc-cart__aside">
				<?php
				/**
				 * Notices above the bag summary (the shipping module prints «Te faltan X € para el envío gratis»).
				 *
				 * @since 0.2.0
				 */
				do_action( 'lachinata/cart/notices' );
				?>
				<div class="lc-summary">
					<?php if ( wc_coupons_enabled() ) : ?>
						<div class="lc-summary__coupon">
							<div class="lc-field" style="flex: 1">
								<div class="lc-field__box">
									<input type="text" name="coupon_code" autocomplete="off" placeholder="<?php esc_attr_e( 'Código de descuento', 'lachinata' ); ?>" aria-label="<?php esc_attr_e( 'Código de descuento', 'lachinata' ); ?>">
								</div>
							</div>
							<?php
							echo lachinata_button(
								__( 'Aplicar', 'lachinata' ),
								array(
									'variant' => 'secondary',
									'type'    => 'submit',
									'attrs'   => array(
										'name'  => 'apply_coupon',
										'value' => '1',
									),
								)
							); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped 
							?>
						</div>
					<?php endif; ?>
					<dl class="lc-summary__lines body-sm">
						<div class="lc-summary__line">
							<dt><?php esc_html_e( 'Subtotal', 'lachinata' ); ?></dt>
							<dd data-no-translation><?php echo wp_kses_post( $lachinata_cart->get_cart_subtotal() ); ?></dd>
						</div>
						<?php foreach ( $lachinata_cart->get_coupons() as $lachinata_code => $lachinata_coupon ) : ?>
							<?php
							/**
							 * A discount line of the bag summary: its `label` and whether it can be
							 * removed (`removable`). The case discount of the Bodega reads «Descuento
							 * por caja» and has no «Quitar».
							 *
							 * @since 0.18.0
							 *
							 * @param array{label: string, removable: bool} $line Line.
							 * @param string                                $code Coupon code.
							 */
							$lachinata_coupon_line = (array) apply_filters(
								'lachinata/cart/coupon',
								array(
									/* translators: %s: coupon code. */
									'label'     => sprintf( __( 'Descuento (%s)', 'lachinata' ), $lachinata_code ),
									'removable' => true,
								),
								(string) $lachinata_code
							);
							?>
							<div class="lc-summary__line">
								<dt>
									<?php echo esc_html( (string) ( $lachinata_coupon_line['label'] ?? '' ) ); ?>
									<?php if ( ! empty( $lachinata_coupon_line['removable'] ) ) : ?>
										<a class="lc-summary__remove" href="<?php echo esc_url( wp_nonce_url( add_query_arg( 'remove_coupon', rawurlencode( (string) $lachinata_code ), wc_get_cart_url() ), 'woocommerce-cart' ) ); ?>" data-lc-remove><?php esc_html_e( 'Quitar', 'lachinata' ); ?></a>
									<?php endif; ?>
								</dt>
								<dd data-no-translation>−<?php echo wp_kses_post( wc_price( (float) $lachinata_cart->get_coupon_discount_amount( (string) $lachinata_code, ! $lachinata_cart->display_prices_including_tax() ) ) ); ?></dd>
							</div>
						<?php endforeach; ?>
						<?php if ( $lachinata_cart->needs_shipping() ) : ?>
							<div class="lc-summary__line">
								<dt><?php echo esc_html_x( 'Envío', 'summary line', 'lachinata' ); ?></dt>
								<dd>
									<?php
									/**
									 * Shipping line of the bag summary (the shipping module prints the chosen
									 * method, its price and the delivery range). HTML, escaped by whoever fills it.
									 *
									 * @since 0.4.0
									 *
									 * @param string  $html Default text.
									 * @param WC_Cart $cart Cart.
									 */
									echo wp_kses_post( (string) apply_filters( 'lachinata/cart/shipping_summary', esc_html__( 'Se calcula con tu dirección', 'lachinata' ), $lachinata_cart ) );
									?>
								</dd>
							</div>
						<?php endif; ?>
					</dl>
					<div class="lc-summary__total">
						<span class="h4"><?php esc_html_e( 'Total', 'lachinata' ); ?></span>
						<span class="price-lg" data-no-translation><?php echo wp_kses_post( wc_price( (float) $lachinata_cart->get_total( 'edit' ) ) ); ?></span>
					</div>
					<?php if ( wc_tax_enabled() && $lachinata_cart->display_prices_including_tax() && lachinata_price_note() ) : ?>
						<span class="lc-summary__note caption"><?php echo wp_kses_post( lachinata_price_note() ); ?></span>
					<?php endif; ?>
				</div>
				<?php
				/**
				 * Why the bag cannot go to the checkout yet ('' when it can): «Tramitar pedido» is
				 * then off and the reason is said under it (locale: a line that does not ship to
				 * the destination).
				 *
				 * @since 0.11.0
				 *
				 * @param string  $reason Plain text.
				 * @param WC_Cart $cart   Cart.
				 */
				$lachinata_blocked = (string) apply_filters( 'lachinata/cart/checkout_blocked', '', $lachinata_cart );
				echo lachinata_button(
					__( 'Tramitar pedido', 'lachinata' ),
					'' === $lachinata_blocked ? array(
						'href'  => wc_get_checkout_url(),
						'size'  => 'lg',
						'block' => true,
						'icon'  => 'arrow-right',
						'attrs' => array( 'data-lc-checkout' => true ),
					) : array(
						'size'  => 'lg',
						'block' => true,
						'icon'  => 'arrow-right',
						'attrs' => array(
							'disabled'         => true,
							'aria-describedby' => 'lc-checkout-blocked',
						),
					)
				); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped 
				?>
				<?php if ( '' !== $lachinata_blocked ) : ?>
					<p class="lc-cart__blocked body-sm" id="lc-checkout-blocked"><?php echo esc_html( $lachinata_blocked ); ?></p>
				<?php endif; ?>
				<?php
				lachinata_part(
					'age-notice',
					array(
						/**
						 * Age notice of the bag when it holds a product with alcohol (AgeNotice).
						 * Empty by default.
						 *
						 * @since 0.18.0
						 *
						 * @param string $text Text.
						 */
						'text'  => (string) apply_filters( 'lachinata/cart/age_notice', '' ),
						'class' => 'lc-cart__age',
					)
				);
				?>
				<?php if ( $lachinata_sheet ) : ?>
					<a class="lc-cart__full label" href="<?php echo esc_url( wc_get_cart_url() ); ?>"><?php esc_html_e( 'Ver la bolsa completa', 'lachinata' ); ?></a>
				<?php endif; ?>
			</div>
		</div>
	<?php endif; ?>
	<?php wp_nonce_field( 'woocommerce-cart', 'woocommerce-cart-nonce' ); ?>
</form>
