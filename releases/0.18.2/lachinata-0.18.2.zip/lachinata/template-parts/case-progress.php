<?php
/**
 * CaseProgress: how many bottles the mixed case has and how many are missing, in the bag
 * (sheet and page), above the lines. Args: progress (`count`, `size`, `discount`, `href`,
 * `cta`).
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_progress = $args['progress'] ?? null;
if ( ! is_array( $lachinata_progress ) ) {
	return;
}
$lachinata_size     = max( 1, (int) ( $lachinata_progress['size'] ?? 6 ) );
$lachinata_count    = max( 0, (int) ( $lachinata_progress['count'] ?? 0 ) );
$lachinata_discount = (float) ( $lachinata_progress['discount'] ?? 0 );
$lachinata_left     = ( $lachinata_size - ( $lachinata_count % $lachinata_size ) ) % $lachinata_size;
$lachinata_boxes    = intdiv( $lachinata_count, $lachinata_size );
$lachinata_done     = $lachinata_count > 0 && 0 === $lachinata_left;
$lachinata_on       = $lachinata_done ? $lachinata_size : $lachinata_count % $lachinata_size;
$lachinata_pct      = number_format_i18n( $lachinata_discount, floor( $lachinata_discount ) === $lachinata_discount ? 0 : 1 );
?>
<div class="<?php echo esc_attr( lachinata_cx( 'lc-cprog', $lachinata_done ? 'lc-cprog--done' : '' ) ); ?>" role="status">
	<span class="lc-cprog__ic" aria-hidden="true"><?php echo lachinata_icon( $lachinata_done ? 'check' : 'wine', array( 'size' => 'sm' ) ); ?></span>
	<div class="lc-cprog__body">
		<p class="body-sm">
			<?php if ( $lachinata_done ) : ?>
				<strong>
					<?php
					echo esc_html(
						sprintf(
							/* translators: 1: number of cases, 2: bottles in a case. */
							_n( '%1$s caja de %2$s completa', '%1$s cajas de %2$s completas', $lachinata_boxes, 'lachinata' ),
							number_format_i18n( $lachinata_boxes ),
							number_format_i18n( $lachinata_size )
						)
					);
					?>
				</strong>
				<?php
				/* translators: %s: discount («5»). */
				echo esc_html( sprintf( __( ' · −%s %% en esas botellas.', 'lachinata' ), $lachinata_pct ) );
				?>
			<?php else : ?>
				<?php
				/* translators: %s: bottles in the bag. */
				echo esc_html( sprintf( _n( 'Llevas %s botella.', 'Llevas %s botellas.', $lachinata_count, 'lachinata' ), number_format_i18n( $lachinata_count ) ) );
				?>
				<strong>
					<?php
					/* translators: %s: bottles missing. */
					echo esc_html( sprintf( __( 'Añade %s más', 'lachinata' ), number_format_i18n( $lachinata_left ) ) );
					?>
				</strong>
				<?php
				/* translators: %s: discount («5»). */
				echo esc_html( sprintf( __( 'y tu caja variada tiene un −%s %%.', 'lachinata' ), $lachinata_pct ) );
				?>
			<?php endif; ?>
		</p>
		<span class="lc-cprog__bar" aria-hidden="true"><?php echo str_repeat( '<i class="on"></i>', $lachinata_on ) . str_repeat( '<i></i>', $lachinata_size - $lachinata_on ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup. ?></span>
		<?php if ( ! $lachinata_done && ! empty( $lachinata_progress['href'] ) ) : ?>
			<a href="<?php echo esc_url( (string) $lachinata_progress['href'] ); ?>" class="lc-cprog__link label"><?php echo esc_html( (string) ( $lachinata_progress['cta'] ?? __( 'Ver vinos', 'lachinata' ) ) ); ?><?php echo lachinata_icon( 'arrow-right', array( 'size' => 'sm' ) ); ?></a>
		<?php endif; ?>
	</div>
</div>
