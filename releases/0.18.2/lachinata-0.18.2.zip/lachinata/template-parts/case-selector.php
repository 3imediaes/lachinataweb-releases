<?php
/**
 * CaseSelector: «1 botella» or «Caja de 6», between the price and «Añadir a la bolsa», in
 * the buy form. Choosing the case puts the quantity at 6 and the stepper goes 6 by 6 (the
 * script; without it, the bag rounds the quantity up to the case). The bag calculates the
 * discount; this only announces it. Args: case (`size`, `discount`, `mixed`, `href`,
 * `counts`, `one`, `case`, `save` as HTML of prices).
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_case = $args['case'] ?? null;
if ( ! is_array( $lachinata_case ) ) {
	return;
}
$lachinata_size  = max( 2, (int) ( $lachinata_case['size'] ?? 6 ) );
$lachinata_pct   = (float) ( $lachinata_case['discount'] ?? 0 );
$lachinata_mixed = (float) ( $lachinata_case['mixed'] ?? 0 );
$lachinata_fmt   = static fn( float $value ): string => number_format_i18n( $value, floor( $value ) === $value ? 0 : 1 );
?>
<fieldset class="lc-case lc-buy__case" data-lc-case<?php echo empty( $lachinata_case['counts'] ) ? ' hidden' : ''; ?>>
	<legend class="screen-reader-text"><?php esc_html_e( 'Cómo lo quieres', 'lachinata' ); ?></legend>
	<div class="lc-case__opts">
		<label class="lc-case__opt lc-case__opt--on">
			<input type="radio" name="lc_case" value="one" checked data-lc-case-input>
			<span class="label"><?php esc_html_e( '1 botella', 'lachinata' ); ?></span>
			<span class="body-sm" data-lc-case-one data-no-translation><?php echo wp_kses_post( (string) ( $lachinata_case['one'] ?? '' ) ); ?></span>
		</label>
		<label class="lc-case__opt">
			<input type="radio" name="lc_case" value="case" data-lc-case-input data-lc-case-size="<?php echo esc_attr( (string) $lachinata_size ); ?>">
			<span class="lc-case__head">
				<span class="label">
					<?php
					/* translators: %s: bottles in a case. */
					echo esc_html( sprintf( __( 'Caja de %s', 'lachinata' ), number_format_i18n( $lachinata_size ) ) );
					?>
				</span>
				<?php if ( $lachinata_pct > 0 ) : ?>
					<?php /* translators: %s: discount («10»). */ ?>
					<span class="lc-case__pct caption"><?php echo esc_html( sprintf( __( '−%s %%', 'lachinata' ), $lachinata_fmt( $lachinata_pct ) ) ); ?></span>
				<?php endif; ?>
			</span>
			<span class="body-sm" data-lc-case-total data-no-translation><?php echo wp_kses_post( (string) ( $lachinata_case['case'] ?? '' ) ); ?></span>
			<?php if ( $lachinata_pct > 0 ) : ?>
				<span class="caption lc-case__save">
					<?php
					/* translators: %s: amount saved, as a price. */
					echo wp_kses_post( sprintf( __( 'Ahorras %s', 'lachinata' ), '<span data-lc-case-save data-no-translation>' . (string) ( $lachinata_case['save'] ?? '' ) . '</span>' ) );
					?>
				</span>
			<?php endif; ?>
		</label>
	</div>
	<?php if ( $lachinata_mixed > 0 && ! empty( $lachinata_case['href'] ) ) : ?>
		<a href="<?php echo esc_url( (string) $lachinata_case['href'] ); ?>" class="lc-case__mix body-sm">
			<?php
			/* translators: 1: bottles in a case, 2: discount («5»). */
			echo esc_html( sprintf( __( 'O arma tu caja con %1$s vinos distintos: −%2$s %%', 'lachinata' ), number_format_i18n( $lachinata_size ), $lachinata_fmt( $lachinata_mixed ) ) );
			?>
			<?php echo lachinata_icon( 'arrow-right', array( 'size' => 'sm' ) ); ?>
		</a>
	<?php endif; ?>
</fieldset>
