<?php
/**
 * GiftContents («Qué lleva»): the facts of a composite gift, its products as a mosaic of
 * photos (without prices or add buttons) and the allergens of the set. Each product opens
 * its summary (GiftItem) in a BottomSheet, a dialog on desktop; without JavaScript it links
 * to its page. A product without a page stays in the mosaic, without a link. Args: gift
 * (lachinata_product_gift()).
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_gift = $args['gift'] ?? null;
if ( ! is_array( $lachinata_gift ) ) {
	return;
}
$lachinata_facts = array_filter(
	array(
		array(
			__( 'Contiene', 'lachinata' ),
			/* translators: %s: number of products in a gift. */
			sprintf( _n( '%s producto', '%s productos', $lachinata_gift['count'], 'lachinata' ), number_format_i18n( $lachinata_gift['count'] ) ),
			'package',
		),
		array( __( 'Presentación', 'lachinata' ), $lachinata_gift['presentation'], 'gift' ),
		array( __( 'Medidas', 'lachinata' ), $lachinata_gift['dimensions'], 'ruler' ),
		array( __( 'Peso', 'lachinata' ), $lachinata_gift['weight'], 'weight' ),
	),
	static fn( array $fact ): bool => '' !== $fact[1]
);
// Photo of a product on the colour of its family, with what goes over it.
$lachinata_media = static function ( array $item, string $classes, string $size, string $sizes, string $over = '' ): string {
	return sprintf(
		'<span class="%1$s" style="background: var(--tint-%2$s)" aria-hidden="true">%3$s%4$s</span>',
		esc_attr( $classes ),
		esc_attr( '' !== $item['tint'] ? $item['tint'] : 'regalos' ),
		$item['image_id']
			? lachinata_attachment_image(
				$item['image_id'],
				$size,
				array(
					'alt'     => '',
					'loading' => 'lazy',
					'sizes'   => $sizes,
				)
			)
			: '<span class="lc-card__halo"></span>',
		$over
	);
};
?>
<section id="contenido" class="lc-gcont lc-product__gift" aria-labelledby="lc-gift-title">
	<h2 class="h3 lc-gcont__title" id="lc-gift-title"><?php esc_html_e( 'Qué lleva', 'lachinata' ); ?></h2>
	<?php if ( $lachinata_facts ) : ?>
		<dl class="lc-gcont__facts">
			<?php foreach ( $lachinata_facts as $lachinata_fact ) : ?>
				<div class="lc-gcont__fact">
					<span class="lc-gcont__ficon" aria-hidden="true"><?php echo lachinata_icon( $lachinata_fact[2], array( 'size' => 'sm' ) ); ?></span>
					<dt class="caption"><?php echo esc_html( $lachinata_fact[0] ); ?></dt>
					<dd class="label"><?php echo esc_html( $lachinata_fact[1] ); ?></dd>
				</div>
			<?php endforeach; ?>
		</dl>
	<?php endif; ?>
	<ul class="lc-gcont__grid">
		<?php foreach ( $lachinata_gift['items'] as $lachinata_index => $lachinata_item ) : ?>
			<?php
			$lachinata_label = implode(
				', ',
				array_filter(
					array(
						$lachinata_item['qty'] > 1
							/* translators: 1: units, 2: product name. */
							? sprintf( __( '%1$s × %2$s', 'lachinata' ), number_format_i18n( $lachinata_item['qty'] ), $lachinata_item['name'] )
							: $lachinata_item['name'],
						$lachinata_item['meta'],
					)
				)
			);
			$lachinata_open  = sprintf(
				/* translators: %s: product and format («2 × Picos Rústicos, 140 g»). */
				__( '%s. Ver detalle', 'lachinata' ),
				$lachinata_label
			);
			$lachinata_inner = $lachinata_media(
				$lachinata_item,
				'lc-gcont__media',
				'woocommerce_thumbnail',
				'(min-width: 1024px) 180px, 45vw',
				( $lachinata_item['qty'] > 1 ? '<span class="lc-gcont__qty label">' . esc_html( '×' . number_format_i18n( $lachinata_item['qty'] ) ) . '</span>' : '' )
					. ( '' !== $lachinata_item['href'] ? '<span class="lc-gcont__more">' . lachinata_icon( 'plus', array( 'size' => 'sm' ) ) . '</span>' : '' )
			)
				. '<span class="label lc-gcont__name" aria-hidden="true">' . esc_html( $lachinata_item['name'] ) . '</span>'
				. ( '' !== $lachinata_item['meta'] ? '<span class="caption lc-gcont__meta" aria-hidden="true" data-no-translation>' . esc_html( $lachinata_item['meta'] ) . '</span>' : '' );
			?>
			<li>
				<?php if ( '' !== $lachinata_item['href'] ) : ?>
					<a class="lc-gcont__tile" href="<?php echo esc_url( $lachinata_item['href'] ); ?>" data-lc-open="gift-item-<?php echo (int) $lachinata_index; ?>" aria-haspopup="dialog" aria-label="<?php echo esc_attr( $lachinata_open ); ?>"><?php echo $lachinata_inner; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above. ?></a>
				<?php else : ?>
					<div class="lc-gcont__tile" role="group" aria-label="<?php echo esc_attr( $lachinata_label ); ?>"><?php echo $lachinata_inner; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above. ?></div>
				<?php endif; ?>
			</li>
		<?php endforeach; ?>
	</ul>
	<?php if ( '' !== $lachinata_gift['allergens'] || '' !== $lachinata_gift['traces'] ) : ?>
		<div class="lc-gcont__allergens body-sm">
			<?php echo lachinata_icon( 'info', array( 'size' => 'sm' ) ); ?>
			<div>
				<?php if ( '' !== $lachinata_gift['allergens'] ) : ?>
					<p><strong><?php esc_html_e( 'Contiene:', 'lachinata' ); ?></strong> <?php echo esc_html( $lachinata_gift['allergens'] . '.' ); ?></p>
				<?php endif; ?>
				<?php if ( '' !== $lachinata_gift['traces'] ) : ?>
					<p><strong><?php esc_html_e( 'Puede contener trazas de:', 'lachinata' ); ?></strong> <?php echo esc_html( $lachinata_gift['traces'] . '.' ); ?></p>
				<?php endif; ?>
				<p class="caption"><?php esc_html_e( 'Ingredientes y alérgenos de cada producto en su ficha.', 'lachinata' ); ?></p>
			</div>
		</div>
	<?php endif; ?>
</section>
<?php foreach ( $lachinata_gift['items'] as $lachinata_index => $lachinata_item ) : ?>
	<?php
	if ( '' === $lachinata_item['href'] ) {
		continue;
	}
	$lachinata_id = 'lc-gift-item-' . $lachinata_index;
	?>
	<div class="lc-layer lc-layer--sheet lc-layer--dialog" data-lc-layer="gift-item-<?php echo (int) $lachinata_index; ?>" hidden>
		<div class="lc-layer__overlay" data-lc-close></div>
		<div class="lc-sheet" role="dialog" aria-modal="true" aria-labelledby="<?php echo esc_attr( $lachinata_id ); ?>" tabindex="-1">
			<div class="lc-sheet__grab" aria-hidden="true"></div>
			<div class="lc-sheet__head">
				<h2 class="h3" id="<?php echo esc_attr( $lachinata_id ); ?>" style="margin: 0"><?php esc_html_e( 'En este regalo', 'lachinata' ); ?></h2>
				<?php echo lachinata_icon_button( 'close', __( 'Cerrar', 'lachinata' ), array( 'attrs' => array( 'data-lc-close' => '' ) ) ); ?>
			</div>
			<div class="lc-sheet__body">
				<div class="lc-gitem">
					<div class="lc-gitem__head">
						<?php echo $lachinata_media( $lachinata_item, 'lc-gthumb', 'woocommerce_thumbnail', '88px' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper. ?>
						<div class="lc-gitem__titles">
							<span class="h4"><?php echo esc_html( $lachinata_item['name'] ); ?></span>
							<?php
							$lachinata_meta = array_filter(
								array(
									$lachinata_item['meta'],
									$lachinata_item['qty'] > 1
										/* translators: %s: units of a product in a gift. */
										? sprintf( _n( '%s unidad', '%s unidades', $lachinata_item['qty'], 'lachinata' ), number_format_i18n( $lachinata_item['qty'] ) )
										: '',
								)
							);
							?>
							<?php if ( $lachinata_meta ) : ?>
								<span class="body-sm lc-gitem__meta"><?php echo esc_html( implode( ' · ', $lachinata_meta ) ); ?></span>
							<?php endif; ?>
						</div>
					</div>
					<?php if ( '' !== $lachinata_item['description'] ) : ?>
						<p class="body-sm" style="margin: 0"><?php echo esc_html( $lachinata_item['description'] ); ?></p>
					<?php endif; ?>
					<?php if ( '' !== $lachinata_item['ingredients'] || '' !== $lachinata_item['allergens'] ) : ?>
						<dl class="lc-gitem__info">
							<?php if ( '' !== $lachinata_item['ingredients'] ) : ?>
								<div><dt class="label"><?php esc_html_e( 'Ingredientes', 'lachinata' ); ?></dt><dd class="body-sm"><?php echo wp_kses_post( $lachinata_item['ingredients'] ); ?></dd></div>
							<?php endif; ?>
							<?php if ( '' !== $lachinata_item['allergens'] ) : ?>
								<div><dt class="label"><?php esc_html_e( 'Alérgenos', 'lachinata' ); ?></dt><dd class="body-sm"><?php echo esc_html( $lachinata_item['allergens'] ); ?></dd></div>
							<?php endif; ?>
						</dl>
					<?php endif; ?>
					<a href="<?php echo esc_url( $lachinata_item['href'] ); ?>" class="lc-gitem__link label"><?php esc_html_e( 'Ver el producto', 'lachinata' ); ?><?php echo lachinata_icon( 'arrow-right', array( 'size' => 'sm' ) ); ?></a>
				</div>
			</div>
		</div>
	</div>
<?php endforeach; ?>
