<?php
/**
 * GiftSummary: thumbnails of what a composite gift holds, the number of products, the
 * presentation, dimensions and weight. Leads to GiftContents on the same page. Args: gift
 * (lachinata_product_gift()), max (thumbnails shown, 3 by default).
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_gift = $args['gift'] ?? null;
if ( ! is_array( $lachinata_gift ) ) {
	return;
}
$lachinata_max   = (int) ( $args['max'] ?? 3 );
$lachinata_shown = array_slice( $lachinata_gift['items'], 0, $lachinata_max );
$lachinata_rest  = count( $lachinata_gift['items'] ) - count( $lachinata_shown );
$lachinata_count = sprintf(
	/* translators: %s: number of products in a gift. */
	_n( '%s producto', '%s productos', $lachinata_gift['count'], 'lachinata' ),
	number_format_i18n( $lachinata_gift['count'] )
);
$lachinata_label = sprintf(
	/* translators: %s: number of products («7 productos»). */
	__( 'Ver qué lleva: %s', 'lachinata' ),
	$lachinata_count
);
$lachinata_line2 = implode( ' · ', array_filter( array( $lachinata_gift['dimensions'], $lachinata_gift['weight'] ) ) );
?>
<a href="#contenido" class="lc-gsum lc-buy__gift" aria-label="<?php echo esc_attr( $lachinata_label ); ?>">
	<span class="lc-gsum__thumbs">
		<?php foreach ( $lachinata_shown as $lachinata_item ) : ?>
			<span class="lc-gthumb lc-gthumb--sm" style="background: var(--tint-<?php echo esc_attr( '' !== $lachinata_item['tint'] ? $lachinata_item['tint'] : 'regalos' ); ?>)" aria-hidden="true">
				<?php
				echo $lachinata_item['image_id']
					? lachinata_attachment_image(
						$lachinata_item['image_id'],
						'woocommerce_gallery_thumbnail',
						array(
							'alt'     => '',
							'loading' => 'lazy',
						)
					)
					: '<span class="lc-card__halo"></span>';
				?>
			</span>
		<?php endforeach; ?>
		<?php if ( $lachinata_rest > 0 ) : ?>
			<span class="lc-gthumb lc-gthumb--sm lc-gsum__more caption" aria-hidden="true"><?php echo esc_html( '+' . number_format_i18n( $lachinata_rest ) ); ?></span>
		<?php endif; ?>
	</span>
	<span class="lc-gsum__text" aria-hidden="true">
		<span class="label"><?php echo esc_html( '' !== $lachinata_gift['presentation'] ? $lachinata_count . ' · ' . $lachinata_gift['presentation'] : $lachinata_count ); ?></span>
		<?php if ( '' !== $lachinata_line2 ) : ?>
			<span class="caption lc-gsum__meta" data-no-translation><?php echo esc_html( $lachinata_line2 ); ?></span>
		<?php endif; ?>
	</span>
	<?php echo lachinata_icon( 'chevron-down', array( 'class' => 'lc-gsum__go' ) ); ?>
</a>
