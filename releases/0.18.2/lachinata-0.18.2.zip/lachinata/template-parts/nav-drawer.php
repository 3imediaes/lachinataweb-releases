<?php
/**
 * NavDrawer: search, categories in an accordion with their tint, utilities.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_current = lachinata_current_category();
$lachinata_root    = $lachinata_current ? lachinata_root_category( $lachinata_current ) : null;
?>
<div class="lc-layer lc-layer--left" id="lc-menu" data-lc-layer="menu" hidden>
	<div class="lc-layer__overlay" data-lc-close></div>
	<div class="lc-drawer" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'Menú', 'lachinata' ); ?>" tabindex="-1">
		<div class="lc-drawer__head">
			<?php echo lachinata_logo( 18 ); ?>
			<?php echo lachinata_icon_button( 'close', __( 'Cerrar menú', 'lachinata' ), array( 'attrs' => array( 'data-lc-close' => '' ) ) ); ?>
		</div>
		<form class="lc-drawer__search" role="search" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">
			<div class="lc-field lc-field--icon">
				<div class="lc-field__box">
					<?php echo lachinata_icon( 'search', array( 'size' => 'sm' ) ); ?>
					<input type="search" name="s" placeholder="<?php esc_attr_e( 'Buscar producto, línea o ingrediente', 'lachinata' ); ?>" aria-label="<?php esc_attr_e( 'Buscar', 'lachinata' ); ?>" autocomplete="off">
					<input type="hidden" name="post_type" value="product">
				</div>
			</div>
		</form>
		<ul class="lc-drawer__list">
			<?php foreach ( lachinata_category_tree() as $lachinata_index => $lachinata_cat ) : ?>
				<?php
				$lachinata_open = $lachinata_root ? $lachinata_root->term_id === $lachinata_cat['term']->term_id : false;
				$lachinata_id   = 'lc-menu-cat-' . $lachinata_cat['term']->term_id;
				?>
				<li class="lc-drawer__item<?php echo $lachinata_open ? ' lc-drawer__item--open' : ''; ?>">
					<button type="button" class="lc-drawer__cat h4" aria-expanded="<?php echo $lachinata_open ? 'true' : 'false'; ?>" aria-controls="<?php echo esc_attr( $lachinata_id ); ?>" data-lc-toggle>
						<span class="lc-drawer__swatch" style="background: <?php echo esc_attr( $lachinata_cat['tint'] ? 'var(--tint-' . $lachinata_cat['tint'] . ')' : 'var(--surface-3)' ); ?>" aria-hidden="true"></span>
						<?php echo esc_html( lachinata_term_name( $lachinata_cat['term'] ) ); ?>
						<?php echo lachinata_icon( 'chevron-down', array( 'class' => 'lc-drawer__chev' ) ); ?>
					</button>
					<ul class="lc-drawer__sub body" id="<?php echo esc_attr( $lachinata_id ); ?>"<?php echo $lachinata_open ? '' : ' hidden'; ?>>
						<li><a href="<?php echo esc_url( lachinata_term_url( $lachinata_cat['term'] ) ); ?>" class="lc-drawer__all">
							<?php
							/* translators: %s: category name. */
							echo esc_html( sprintf( __( 'Ver todo %s', 'lachinata' ), lachinata_term_name( $lachinata_cat['term'] ) ) );
							?>
						</a></li>
						<?php foreach ( $lachinata_cat['children'] as $lachinata_child ) : ?>
							<li><a href="<?php echo esc_url( lachinata_term_url( $lachinata_child ) ); ?>"<?php echo $lachinata_current && $lachinata_current->term_id === $lachinata_child->term_id ? ' aria-current="page"' : ''; ?>><?php echo esc_html( lachinata_term_name( $lachinata_child ) ); ?></a></li>
						<?php endforeach; ?>
					</ul>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php $lachinata_utility = lachinata_menu( 'utility' ); ?>
		<?php if ( $lachinata_utility || has_action( 'lachinata/nav_drawer/utilities' ) ) : ?>
			<div class="lc-drawer__util body-sm">
				<?php foreach ( $lachinata_utility as $lachinata_item ) : ?>
					<a href="<?php echo esc_url( $lachinata_item['url'] ); ?>"><?php echo lachinata_icon( '' !== $lachinata_item['icon'] ? $lachinata_item['icon'] : 'arrow-right', array( 'size' => 'sm' ) ); ?><?php echo esc_html( $lachinata_item['title'] ); ?></a>
				<?php endforeach; ?>
				<?php
				/**
				 * End of the drawer utilities (the locale module adds «España / Península · Español» here).
				 *
				 * @since 0.2.0
				 */
				do_action( 'lachinata/nav_drawer/utilities' );
				?>
			</div>
		<?php endif; ?>
	</div>
</div>
