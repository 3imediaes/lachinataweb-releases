<?php
/**
 * PairingRow («Marida con»): the dishes and up to three products of the shop, each with
 * «Añadir los dos», a form posted to the bag with the wine (the quantity and vintage of the
 * page go with it) and the product. Nothing without dishes or products. Args: pairing
 * (`dishes`, `products` WC_Product[], `wine` name), product (the wine).
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_pairing = (array) ( $args['pairing'] ?? array() );
$lachinata_wine    = $args['product'] ?? null;
$lachinata_dishes  = array_filter( array_map( 'strval', (array) ( $lachinata_pairing['dishes'] ?? array() ) ) );
$lachinata_items   = array_filter( (array) ( $lachinata_pairing['products'] ?? array() ), static fn( $item ): bool => $item instanceof WC_Product );
if ( ( ! $lachinata_dishes && ! $lachinata_items ) || ! $lachinata_wine instanceof WC_Product ) {
	return;
}
$lachinata_name = (string) ( $lachinata_pairing['wine'] ?? $lachinata_wine->get_name() );
?>
<section class="lc-pairing" aria-labelledby="lc-pairing-title">
	<h2 class="h3 lc-pairing__title" id="lc-pairing-title"><?php esc_html_e( 'Marida con', 'lachinata' ); ?></h2>
	<?php if ( $lachinata_dishes ) : ?>
		<div class="lc-pairing__dishes">
			<?php foreach ( $lachinata_dishes as $lachinata_dish ) : ?>
				<span class="lc-chip label"><?php echo esc_html( $lachinata_dish ); ?></span>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
	<?php if ( $lachinata_items ) : ?>
		<ul class="lc-pairing__list">
			<?php foreach ( $lachinata_items as $lachinata_item ) : ?>
				<?php
				$lachinata_card = lachinata_card_data( $lachinata_item );
				$lachinata_meta = wp_strip_all_tags( (string) $lachinata_card['meta'] );
				?>
				<li class="lc-pairing__item">
					<span class="lc-gthumb" style="background: var(--tint-<?php echo esc_attr( '' !== $lachinata_card['tint'] ? $lachinata_card['tint'] : 'regalos' ); ?>)" aria-hidden="true">
						<?php
						echo $lachinata_card['image_id']
							? lachinata_attachment_image(
								(int) $lachinata_card['image_id'],
								'woocommerce_gallery_thumbnail',
								array(
									'alt'     => '',
									'loading' => 'lazy',
								)
							)
							: '<span class="lc-card__halo"></span>';
						?>
					</span>
					<span class="lc-pairing__info">
						<a href="<?php echo esc_url( (string) $lachinata_card['href'] ); ?>" class="label"><?php echo esc_html( (string) $lachinata_card['name'] ); ?></a>
						<span class="caption lc-pairing__meta" data-no-translation><?php echo wp_kses_post( implode( ' · ', array_filter( array( esc_html( $lachinata_meta ), (string) $lachinata_card['price'] ) ) ) ); ?></span>
					</span>
					<?php if ( $lachinata_item->is_type( 'simple' ) && $lachinata_item->is_in_stock() && $lachinata_wine->is_in_stock() ) : ?>
						<form method="post" action="<?php echo esc_url( wc_get_cart_url() ); ?>" class="lc-pairing__form" data-lc-pair>
							<input type="hidden" name="lc-bodega-pair" value="<?php echo esc_attr( (string) $lachinata_item->get_id() ); ?>">
							<input type="hidden" name="lc-bodega-wine" value="<?php echo esc_attr( (string) $lachinata_wine->get_id() ); ?>">
							<input type="hidden" name="quantity" value="1" data-lc-pair-qty>
							<?php
							echo lachinata_button(
								__( 'Añadir los dos', 'lachinata' ),
								array(
									'variant'   => 'secondary',
									'size'      => 'sm',
									'icon_left' => 'bag',
									'type'      => 'submit',
									'attrs'     => array(
										/* translators: 1: wine, 2: product. */
										'aria-label'   => sprintf( __( 'Añadir %1$s y %2$s a la bolsa', 'lachinata' ), $lachinata_name, (string) $lachinata_card['name'] ),
										'data-lc-name' => sprintf( '%1$s + %2$s', $lachinata_name, (string) $lachinata_card['name'] ),
									),
								)
							);
							?>
						</form>
					<?php else : ?>
						<?php
						echo lachinata_button(
							__( 'Ver', 'lachinata' ),
							array(
								'variant' => 'secondary',
								'size'    => 'sm',
								'href'    => (string) $lachinata_card['href'],
							)
						);
						?>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
</section>
