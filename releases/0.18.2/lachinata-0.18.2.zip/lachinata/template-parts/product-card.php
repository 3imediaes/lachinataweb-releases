<?php
/**
 * ProductCard (compact; «wide» for short lists). Args: product (WC_Product), layout, eager,
 * tint (of the listing: the root category being viewed; the product's main category when
 * empty) and list (`id`, `name` and `index` of the list the card is in, for measurement).
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_product = $args['product'] ?? null;
if ( ! $lachinata_product instanceof WC_Product ) {
	return;
}
$lachinata_card = lachinata_card_data( $lachinata_product, (string) ( $args['tint'] ?? '' ) );
$lachinata_wide = 'wide' === ( $args['layout'] ?? 'compact' );
$lachinata_add  = sprintf(
	/* translators: %s: product name. */
	__( 'Añadir %s a la bolsa', 'lachinata' ),
	$lachinata_card['name']
);
?>
<?php
/**
 * Extra attributes of a product card (`data-*`), as the measurement data of `tracking`.
 *
 * @since 0.10.0
 *
 * @param array<string, string> $attributes Attributes; none by default.
 * @param WC_Product            $product    Product.
 * @param array<string, mixed>  $args       Arguments of the card (list: id, name, index).
 */
$lachinata_attributes = (array) apply_filters( 'lachinata/product_card/attributes', array(), $lachinata_product, (array) ( $args ?? array() ) );
?>
<article class="<?php echo esc_attr( lachinata_cx( 'lc-card', $lachinata_wide ? 'lc-card--wide' : '' ) ); ?>"<?php echo lachinata_attrs( array_filter( $lachinata_attributes, static fn( $name ): bool => str_starts_with( (string) $name, 'data-' ), ARRAY_FILTER_USE_KEY ) ); ?>>
	<a class="lc-card__media" href="<?php echo esc_url( $lachinata_card['href'] ); ?>" tabindex="-1" aria-hidden="true"<?php echo $lachinata_card['tint'] ? ' style="background: var(--tint-' . esc_attr( $lachinata_card['tint'] ) . ')"' : ''; ?>>
		<?php echo lachinata_product_image( $lachinata_card['image_id'], 'woocommerce_thumbnail', 'lc-card__halo', ! empty( $args['eager'] ), '(min-width: 1024px) 300px, (min-width: 480px) 33vw, 50vw' ); ?>
		<?php if ( $lachinata_card['badges'] ) : ?>
			<div class="lc-card__badges">
				<?php
				foreach ( $lachinata_card['badges'] as $lachinata_badge ) {
					echo lachinata_badge( (string) $lachinata_badge['text'], (string) $lachinata_badge['tone'], '', (int) ( $lachinata_badge['image_id'] ?? 0 ) );
				}
				?>
			</div>
		<?php endif; ?>
		<?php if ( ! empty( $lachinata_card['wine']['score'] ) ) : ?>
			<?php echo lachinata_wine_score( $lachinata_card['wine']['score'], 'lc-card__score' ); ?>
		<?php endif; ?>
		<?php if ( $lachinata_card['marker'] ) : ?>
			<span class="lc-card__marker caption"><?php echo '' !== $lachinata_card['marker']['icon'] ? lachinata_icon( $lachinata_card['marker']['icon'], array( 'size' => 'sm' ) ) : ''; ?><?php echo esc_html( $lachinata_card['marker']['label'] ); ?></span>
		<?php endif; ?>
	</a>
	<div class="lc-card__body">
		<?php // Rating and format keep their place when empty: prices line up across a row. ?>
		<div class="lc-card__rating">
			<?php
			if ( null !== $lachinata_card['rating'] ) {
				echo lachinata_rating( $lachinata_card['rating'], $lachinata_card['reviews'] );
			}
			?>
		</div>
		<a href="<?php echo esc_url( $lachinata_card['href'] ); ?>" class="lc-card__name h4"><?php echo esc_html( $lachinata_card['name'] ); ?></a>
		<?php if ( $lachinata_card['wine'] ) : ?>
			<span class="lc-card__meta lc-card__wine body-sm" data-no-translation>
				<?php if ( '' !== $lachinata_card['wine']['type'] ) : ?>
					<span class="<?php echo esc_attr( 'lc-wdot lc-wdot--' . $lachinata_card['wine']['type'] ); ?>" aria-hidden="true"></span>
				<?php endif; ?>
				<span>
					<?php if ( '' !== $lachinata_card['wine']['type_name'] ) : ?>
						<span class="screen-reader-text"><?php echo esc_html( $lachinata_card['wine']['type_name'] ); ?> · </span>
					<?php endif; ?>
					<?php echo esc_html( implode( ' · ', array_filter( array( $lachinata_card['wine']['origin'], $lachinata_card['wine']['vintage'] ) ) ) ); ?>
				</span>
			</span>
		<?php else : ?>
			<span class="lc-card__meta body-sm" data-no-translation><?php echo wp_kses_post( $lachinata_card['meta'] ); ?></span>
		<?php endif; ?>
		<div class="lc-card__foot">
			<?php
			echo lachinata_price(
				array(
					'now' => $lachinata_card['price_from']
						/* translators: %s: lowest price. */
						? sprintf( __( 'Desde %s', 'lachinata' ), $lachinata_card['price'] )
						: $lachinata_card['price'],
					'old' => $lachinata_card['old'],
				)
			);
			if ( $lachinata_card['sold_out'] ) {
				echo lachinata_badge( __( 'Agotado', 'lachinata' ), 'soldout' );
			} elseif ( $lachinata_card['direct_add'] ) {
				// Plain add-to-cart link as no-JS fallback; the script adds through the Store API.
				$lachinata_href = add_query_arg( 'add-to-cart', $lachinata_card['add_id'], wc_get_cart_url() );
				if ( $lachinata_wide ) {
					echo lachinata_button(
						__( 'Añadir', 'lachinata' ),
						array(
							'variant'   => 'cart',
							'size'      => 'sm',
							'icon_left' => 'bag',
							'href'      => $lachinata_href,
							'class'     => 'lc-card__add',
							'attrs'     => array(
								'data-lc-add' => $lachinata_card['add_id'],
								'aria-label'  => $lachinata_add,
								'rel'         => 'nofollow',
							),
						)
					);
				} else {
					printf(
						'<a href="%1$s" class="lc-btn lc-btn--cart lc-card__add" aria-label="%2$s" data-lc-add="%3$d" rel="nofollow">%4$s</a>',
						esc_url( $lachinata_href ),
						esc_attr( $lachinata_add ),
						(int) $lachinata_card['add_id'],
						lachinata_icon( 'plus', array( 'size' => 'sm' ) )
					);
				}
			} else {
				// Variable products open the product page (format chips) instead of adding blindly.
				printf(
					'<a href="%1$s" class="lc-btn lc-btn--cart lc-card__add%5$s" aria-label="%2$s">%3$s%4$s</a>',
					esc_url( $lachinata_card['href'] ),
					/* translators: %s: product name. */
					esc_attr( sprintf( __( 'Elegir formato de %s', 'lachinata' ), $lachinata_card['name'] ) ),
					lachinata_icon( $lachinata_wide ? 'bag' : 'plus', array( 'size' => 'sm' ) ),
					$lachinata_wide ? esc_html__( 'Elegir', 'lachinata' ) : '',
					$lachinata_wide ? ' lc-btn--sm' : ''
				);
			}
			?>
		</div>
	</div>
</article>
