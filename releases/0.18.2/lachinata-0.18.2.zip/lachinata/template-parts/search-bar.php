<?php
/**
 * SearchBar at full screen with suggestions (categories, recent searches, products).
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_categories = array();
foreach ( lachinata_category_tree() as $lachinata_cat ) {
	foreach ( array_merge( array( $lachinata_cat['term'] ), $lachinata_cat['children'] ) as $lachinata_term ) {
		$lachinata_categories[] = array(
			'name' => lachinata_term_name( $lachinata_term ),
			'url'  => lachinata_term_url( $lachinata_term ),
			'tint' => $lachinata_cat['tint'],
		);
	}
}
?>
<div class="lc-layer lc-layer--full" data-lc-layer="search" hidden>
	<div class="lc-search" role="search" aria-label="<?php esc_attr_e( 'Buscar en la tienda', 'lachinata' ); ?>">
		<form class="lc-search__row" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">
			<div class="lc-field lc-field--icon">
				<div class="lc-field__box">
					<?php echo lachinata_icon( 'search', array( 'size' => 'sm' ) ); ?>
					<input type="search" name="s" placeholder="<?php esc_attr_e( 'Buscar', 'lachinata' ); ?>" aria-label="<?php esc_attr_e( 'Buscar', 'lachinata' ); ?>" autocomplete="off" enterkeyhint="search" data-lc-search-input aria-controls="lc-search-sug">
					<input type="hidden" name="post_type" value="product">
				</div>
			</div>
			<?php
			echo lachinata_button(
				__( 'Cancelar', 'lachinata' ),
				array(
					'variant' => 'ghost',
					'attrs'   => array( 'data-lc-close' => '' ),
				)
			);
			?>
		</form>
		<ul class="lc-search__sug body" id="lc-search-sug" data-lc-search-sug aria-live="polite"></ul>
		<script type="application/json" data-lc-search-categories><?php echo wp_json_encode( $lachinata_categories, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG ); ?></script>
	</div>
</div>
