<?php
/**
 * TastingNotes: sight, nose and mouth, the profile in bars (only when it is filled) and the
 * serving temperature. Nothing without data. Args: tasting (`sight`, `nose`, `mouth`,
 * `profile` with `body`, `oak`, `sweet`, `acid` from 1 to 5, `temperature`).
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_tasting = (array) ( $args['tasting'] ?? array() );
$lachinata_notes   = array_filter(
	array(
		__( 'Vista', 'lachinata' ) => (string) ( $lachinata_tasting['sight'] ?? '' ),
		__( 'Nariz', 'lachinata' ) => (string) ( $lachinata_tasting['nose'] ?? '' ),
		__( 'Boca', 'lachinata' )  => (string) ( $lachinata_tasting['mouth'] ?? '' ),
	)
);
$lachinata_profile = (array) ( $lachinata_tasting['profile'] ?? array() );
$lachinata_scales  = array(
	'body'  => array( __( 'Ligero', 'lachinata' ), __( 'Con cuerpo', 'lachinata' ) ),
	'oak'   => array( __( 'Sin madera', 'lachinata' ), __( 'Mucha madera', 'lachinata' ) ),
	'sweet' => array( __( 'Seco', 'lachinata' ), __( 'Dulce', 'lachinata' ) ),
	'acid'  => array( __( 'Suave', 'lachinata' ), __( 'Fresco y ácido', 'lachinata' ) ),
);
$lachinata_bars    = array_filter( $lachinata_scales, static fn( $key ): bool => ! empty( $lachinata_profile[ $key ] ), ARRAY_FILTER_USE_KEY );
$lachinata_temp    = (string) ( $lachinata_tasting['temperature'] ?? '' );
if ( ! $lachinata_notes && ! $lachinata_bars ) {
	return;
}
?>
<section class="lc-taste" aria-labelledby="lc-taste-title">
	<h2 class="h3 lc-taste__title" id="lc-taste-title"><?php esc_html_e( 'Cata', 'lachinata' ); ?></h2>
	<?php if ( $lachinata_notes ) : ?>
		<dl class="lc-taste__notes">
			<?php foreach ( $lachinata_notes as $lachinata_label => $lachinata_note ) : ?>
				<div><dt class="label"><?php echo esc_html( (string) $lachinata_label ); ?></dt><dd class="body-sm"><?php echo esc_html( $lachinata_note ); ?></dd></div>
			<?php endforeach; ?>
		</dl>
	<?php endif; ?>
	<?php if ( $lachinata_bars ) : ?>
		<div class="lc-taste__profile">
			<?php foreach ( $lachinata_bars as $lachinata_key => $lachinata_ends ) : ?>
				<?php $lachinata_level = max( 1, min( 5, (int) $lachinata_profile[ $lachinata_key ] ) ); ?>
				<?php /* translators: 1: low end of the scale, 2: high end, 3: level from 1 to 5. */ ?>
				<div class="lc-taste__row" role="img" aria-label="<?php echo esc_attr( sprintf( __( '%1$s a %2$s: %3$s de 5', 'lachinata' ), $lachinata_ends[0], $lachinata_ends[1], number_format_i18n( $lachinata_level ) ) ); ?>">
					<span class="caption" aria-hidden="true"><?php echo esc_html( $lachinata_ends[0] ); ?></span>
					<span class="lc-taste__bar" aria-hidden="true"><?php echo str_repeat( '<i class="on"></i>', $lachinata_level ) . str_repeat( '<i></i>', 5 - $lachinata_level ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup. ?></span>
					<span class="caption" aria-hidden="true"><?php echo esc_html( $lachinata_ends[1] ); ?></span>
				</div>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
	<?php if ( '' !== $lachinata_temp ) : ?>
		<p class="body-sm lc-taste__temp">
			<?php echo lachinata_icon( 'wine', array( 'size' => 'sm' ) ); ?>
			<?php
			/* translators: %s: serving temperature («14–16 ºC»). */
			echo esc_html( sprintf( __( 'Sírvelo a %s.', 'lachinata' ), $lachinata_temp ) );
			?>
		</p>
	<?php endif; ?>
</section>
