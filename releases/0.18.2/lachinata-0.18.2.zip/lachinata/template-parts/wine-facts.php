<?php
/**
 * WineFacts: the technical sheet in two columns (three from 720 px of the block). Rows
 * without value are not painted; the ones that change with the vintage (vintage, strength,
 * ageing, volume) carry `data-lc-fact` for the script. Args: facts (label, value, key),
 * allergens («sulfitos»).
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_facts     = (array) ( $args['facts'] ?? array() );
$lachinata_allergens = (string) ( $args['allergens'] ?? '' );
$lachinata_filled    = array_filter( $lachinata_facts, static fn( $row ): bool => '' !== (string) ( $row[1] ?? '' ) );
if ( ! $lachinata_filled && '' === $lachinata_allergens ) {
	return;
}
?>
<section class="lc-wfacts" aria-labelledby="lc-wfacts-title">
	<h2 class="h3 lc-wfacts__title" id="lc-wfacts-title"><?php esc_html_e( 'Ficha técnica', 'lachinata' ); ?></h2>
	<dl class="lc-wfacts__list">
		<?php foreach ( $lachinata_facts as $lachinata_row ) : ?>
			<?php $lachinata_value = (string) ( $lachinata_row[1] ?? '' ); ?>
			<div data-lc-fact="<?php echo esc_attr( (string) ( $lachinata_row[2] ?? '' ) ); ?>"<?php echo '' === $lachinata_value ? ' hidden' : ''; ?>>
				<dt class="caption"><?php echo esc_html( (string) ( $lachinata_row[0] ?? '' ) ); ?></dt>
				<dd class="body-sm" data-no-translation><?php echo esc_html( $lachinata_value ); ?></dd>
			</div>
		<?php endforeach; ?>
	</dl>
	<?php if ( '' !== $lachinata_allergens ) : ?>
		<p class="caption lc-wfacts__note">
			<?php
			/* translators: %s: allergens («sulfitos»). */
			echo esc_html( sprintf( __( 'Contiene %s.', 'lachinata' ), $lachinata_allergens ) );
			?>
		</p>
	<?php endif; ?>
</section>
