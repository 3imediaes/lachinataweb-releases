<?php
/**
 * WineScores: badges of critics and contests of each vintage; only the vintage being seen
 * is shown (the script switches them with the vintage). Args: scores (vintage slug → list
 * of `critic`, `points` or `medal`, `vintage`), vintage (slug of the one being seen).
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_scores  = (array) ( $args['scores'] ?? array() );
$lachinata_vintage = (string) ( $args['vintage'] ?? '' );
if ( ! $lachinata_scores ) {
	return;
}
foreach ( $lachinata_scores as $lachinata_slug => $lachinata_list ) :
	if ( ! $lachinata_list ) {
		continue;
	}
	?>
	<div class="lc-wscores lc-buy__scores" data-lc-vintage="<?php echo esc_attr( (string) $lachinata_slug ); ?>"<?php echo (string) $lachinata_slug === $lachinata_vintage ? '' : ' hidden'; ?>>
		<?php foreach ( (array) $lachinata_list as $lachinata_score ) : ?>
			<?php echo lachinata_wine_score( (array) $lachinata_score ); ?>
		<?php endforeach; ?>
	</div>
	<?php
endforeach;
