<?php
/**
 * «La bodega»: its text and «Más vinos de {bodega}» with up to three cards. Nothing without
 * text or other wines. Args: winery (`name`, `text`, `href`), products (WC_Product[]).
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_winery = $args['winery'] ?? null;
$lachinata_more   = array_filter( (array) ( $args['products'] ?? array() ), static fn( $item ): bool => $item instanceof WC_Product );
if ( ! is_array( $lachinata_winery ) || ( '' === trim( (string) ( $lachinata_winery['text'] ?? '' ) ) && ! $lachinata_more ) ) {
	return;
}
?>
<div class="lc-wine__winery">
	<?php if ( '' !== trim( (string) $lachinata_winery['text'] ) ) : ?>
		<section class="lc-wine__about" aria-labelledby="lc-winery-title">
			<h2 class="h3" id="lc-winery-title"><?php esc_html_e( 'La bodega', 'lachinata' ); ?></h2>
			<div class="body-sm lc-wine__text"><?php echo wp_kses_post( wpautop( (string) $lachinata_winery['text'] ) ); ?></div>
		</section>
	<?php endif; ?>
	<?php if ( $lachinata_more ) : ?>
		<section class="lc-wine__more" aria-labelledby="lc-winery-more">
			<?php
			lachinata_part(
				'section-header',
				array(
					/* translators: %s: winery. */
					'title' => sprintf( __( 'Más vinos de %s', 'lachinata' ), (string) $lachinata_winery['name'] ),
					'id'    => 'lc-winery-more',
					'more'  => __( 'Ver todos', 'lachinata' ),
					'href'  => (string) ( $lachinata_winery['href'] ?? '' ),
				)
			);
			?>
			<div class="lc-carousel lc-wine__cards">
				<?php foreach ( array_values( $lachinata_more ) as $lachinata_index => $lachinata_item ) : ?>
					<?php
					lachinata_part(
						'product-card',
						array(
							'product' => $lachinata_item,
							'list'    => array(
								'id'    => 'winery',
								'name'  => sprintf( __( 'Más vinos de %s', 'lachinata' ), (string) $lachinata_winery['name'] ), // phpcs:ignore WordPress.WP.I18n.MissingTranslatorsComment -- Same string as above.
								'index' => $lachinata_index + 1,
							),
						)
					);
					?>
				<?php endforeach; ?>
			</div>
		</section>
	<?php endif; ?>
</div>
