<?php
/**
 * Frame of every email, top (06-correos.md, «El marco»): preheader, white card with the
 * 4 px ink rule on surface-2, logo, eyebrow, title, lead, the module's pieces after the
 * title, the key facts and the one button. The email template goes on after it and
 * email-footer.php closes the card.
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package LaChinata\Theme
 * @version 10.7.0
 *
 * @var string $email_heading Heading of WooCommerce (title of the emails outside the inventory).
 */

defined( 'ABSPATH' ) || exit;

$lachinata_email  = lachinata_email_current();
$lachinata_intro  = lachinata_email_intro( $lachinata_email, (string) ( $email_heading ?? '' ) );
$lachinata_order  = lachinata_email_order( $lachinata_email );
$lachinata_facts  = lachinata_email_facts( $lachinata_email );
$lachinata_button = lachinata_email_button( $lachinata_email );
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=<?php bloginfo( 'charset' ); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="color-scheme" content="light only">
		<meta name="supported-color-schemes" content="light only">
		<title><?php echo esc_html( '' !== $lachinata_intro['title'] ? $lachinata_intro['title'] : lachinata_email_brand() ); ?></title>
	</head>
	<body <?php echo is_rtl() ? 'rightmargin' : 'leftmargin'; ?>="0" marginwidth="0" topmargin="0" marginheight="0" offset="0">
		<div class="lc-mail" dir="<?php echo is_rtl() ? 'rtl' : 'ltr'; ?>">
			<?php if ( '' !== $lachinata_intro['preheader'] ) : ?>
				<div class="lc-mail-preheader -emogrifier-keep"><?php echo esc_html( $lachinata_intro['preheader'] ); ?></div>
			<?php endif; ?>
			<table role="presentation" width="100%" cellpadding="0" cellspacing="0">
				<tr>
					<td align="center" class="lc-mail-outer">
						<table role="presentation" width="600" cellpadding="0" cellspacing="0" class="lc-mail-card">
							<tr>
								<td align="center" class="lc-mail-head lc-mail-pad">
									<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img src="<?php echo esc_url( get_template_directory_uri() . '/assets/img/email/logo@2x.png' ); ?>" width="143" height="20" alt="<?php echo esc_attr( lachinata_email_brand() ); ?>" class="lc-mail-logo"></a>
								</td>
							</tr>
							<tr>
								<td class="lc-mail-body lc-mail-pad">
									<?php if ( '' !== $lachinata_intro['eyebrow'] ) : ?>
										<p class="lc-mail-eyebrow"><?php echo esc_html( $lachinata_intro['eyebrow'] ); ?></p>
									<?php endif; ?>
									<?php if ( '' !== $lachinata_intro['title'] ) : ?>
										<h1 class="lc-mail-title"><?php echo esc_html( $lachinata_intro['title'] ); ?></h1>
									<?php endif; ?>
									<?php if ( '' !== $lachinata_intro['lead'] ) : ?>
										<p class="lc-mail-lead"><?php echo nl2br( esc_html( $lachinata_intro['lead'] ) ); ?></p>
									<?php endif; ?>
									<?php
									/**
									 * After the title and lead of an email: the module's badges
									 * («Regalo» in the internal email), with the lc-mail-* classes.
									 *
									 * @since 0.8.0
									 *
									 * @param WC_Order|null $order Order of the email.
									 * @param WC_Email|null $email Email.
									 */
									do_action( 'lachinata/email/after_title', $lachinata_order, $lachinata_email );
									echo lachinata_email_facts_html( $lachinata_facts );
									// What to do before the button: the transfer details of an order to pay by transfer.
									echo lachinata_email_after_facts( $lachinata_order, $lachinata_email );
									if ( null !== $lachinata_button ) {
										echo lachinata_email_button_html( $lachinata_button );
									}
