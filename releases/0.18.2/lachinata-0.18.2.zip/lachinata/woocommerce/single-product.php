<?php
/**
 * Product page: gallery, buy column (sticky on desktop), seals, UspBar, what a composite
 * gift holds, tabs, help, cross-sell and the StickyCta on mobile.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

get_header();

while ( have_posts() ) :
	the_post();
	$lachinata_product = wc_get_product( get_the_ID() );
	if ( ! $lachinata_product instanceof WC_Product ) {
		continue;
	}
	/**
	 * WooCommerce: before the product (notices, structured data hooks).
	 *
	 * @since 0.2.0
	 */
	do_action( 'woocommerce_before_single_product' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.HookCommentWrongStyle, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook.

	$lachinata_tint    = lachinata_product_tint( $lachinata_product );
	$lachinata_badges  = lachinata_product_badges( $lachinata_product );
	$lachinata_images  = array_values( array_filter( array_merge( array( (int) $lachinata_product->get_image_id() ), array_map( 'intval', $lachinata_product->get_gallery_image_ids() ) ) ) );
	$lachinata_cat     = lachinata_current_category();
	$lachinata_eyebrow = $lachinata_cat ? implode( ' · ', array_unique( array( lachinata_term_name( lachinata_root_category( $lachinata_cat ) ), lachinata_term_name( $lachinata_cat ) ) ) ) : '';
	$lachinata_tabs    = lachinata_product_tabs( $lachinata_product );
	$lachinata_reviews = wc_reviews_enabled() && comments_open();
	$lachinata_cross   = lachinata_cross_sell( $lachinata_product );
	$lachinata_unit    = lachinata_unit_price( $lachinata_product );
	$lachinata_gift    = lachinata_product_gift( $lachinata_product );
	$lachinata_wine    = lachinata_product_wine( $lachinata_product );
	$lachinata_age     = lachinata_product_age_notice( $lachinata_product );
	if ( $lachinata_wine && '' !== (string) ( $lachinata_wine['eyebrow'] ?? '' ) ) {
		$lachinata_eyebrow = (string) $lachinata_wine['eyebrow'];
	}
	/**
	 * Detail rows of the product (best-before date…).
	 *
	 * @since 0.2.0
	 *
	 * @param array<int, array{label: string, value: string}> $rows    Rows.
	 * @param WC_Product                                    $product Product.
	 */
	$lachinata_details = (array) apply_filters( 'lachinata/product/details', array(), $lachinata_product );
	/**
	 * Seals of the product (images with name and archive link).
	 *
	 * @since 0.2.0
	 *
	 * @param array<int, array{name: string, url: string, image_id: int}> $seals   Seals.
	 * @param WC_Product                                                $product Product.
	 */
	$lachinata_seals = (array) apply_filters( 'lachinata/product/seals', array(), $lachinata_product );
	?>
	<?php lachinata_part( 'breadcrumb', array( 'class' => 'lc-container lc-product__crumbs' ) ); ?>
	<div id="product-<?php the_ID(); ?>" <?php wc_product_class( 'lc-product lc-container', $lachinata_product ); ?>>
		<?php // Gallery and buy column: the sticky column never leaves this row. ?>
		<div class="lc-product__main">
		<section class="lc-gallery" aria-label="<?php esc_attr_e( 'Imágenes del producto', 'lachinata' ); ?>"<?php echo $lachinata_tint ? ' style="--lc-media-bg: var(--tint-' . esc_attr( $lachinata_tint ) . ')"' : ''; ?>>
			<div class="lc-gallery__main">
				<div class="lc-gallery__track" data-lc-gallery tabindex="0" role="region" aria-label="<?php esc_attr_e( 'Desliza para ver más imágenes', 'lachinata' ); ?>">
					<?php if ( $lachinata_images ) : ?>
						<?php foreach ( $lachinata_images as $lachinata_index => $lachinata_image ) : ?>
							<figure class="lc-gallery__slide" id="lc-img-<?php echo esc_attr( (string) $lachinata_index ); ?>">
								<?php
								echo lachinata_attachment_image(
									$lachinata_image,
									'woocommerce_single',
									array(
										'alt'           => 0 === $lachinata_index ? $lachinata_product->get_name() : '',
										'loading'       => $lachinata_index ? 'lazy' : 'eager',
										'fetchpriority' => $lachinata_index ? null : 'high',
										'sizes'         => '(min-width: 1024px) 50vw, 100vw',
										'data-lc-variation-image' => 0 === $lachinata_index ? '' : null,
									)
								);
								?>
							</figure>
						<?php endforeach; ?>
					<?php else : ?>
						<figure class="lc-gallery__slide"><span class="lc-card__halo" aria-hidden="true"></span></figure>
					<?php endif; ?>
				</div>
				<?php
				if ( $lachinata_badges ) {
					echo '<div class="lc-gallery__badges">';
					foreach ( $lachinata_badges as $lachinata_badge ) {
						echo lachinata_badge( (string) $lachinata_badge['text'], (string) $lachinata_badge['tone'], '', (int) ( $lachinata_badge['image_id'] ?? 0 ) );
					}
					echo '</div>';
				}
				if ( count( $lachinata_images ) > 1 ) {
					/* translators: 1: current image, 2: number of images. */
					printf( '<span class="lc-gallery__count caption" data-lc-gallery-count aria-hidden="true">%s</span>', esc_html( sprintf( __( '%1$s / %2$s', 'lachinata' ), 1, count( $lachinata_images ) ) ) );
				}
				?>
			</div>
			<?php if ( count( $lachinata_images ) > 1 ) : ?>
				<div class="lc-gallery__thumbs">
					<?php foreach ( $lachinata_images as $lachinata_index => $lachinata_image ) : ?>
						<a href="#lc-img-<?php echo esc_attr( (string) $lachinata_index ); ?>" class="lc-gallery__thumb" data-lc-thumb="<?php echo esc_attr( (string) $lachinata_index ); ?>"<?php echo 0 === $lachinata_index ? ' aria-current="true"' : ''; ?>>
							<span class="screen-reader-text">
								<?php
								/* translators: %s: image number. */
								echo esc_html( sprintf( __( 'Imagen %s', 'lachinata' ), $lachinata_index + 1 ) );
								?>
							</span>
							<?php
							echo lachinata_attachment_image(
								$lachinata_image,
								'woocommerce_gallery_thumbnail',
								array(
									'alt'     => '',
									'loading' => 'lazy',
								)
							);
							?>
						</a>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</section>

		<section class="lc-buy" aria-labelledby="lc-product-title">
			<?php
			/**
			 * Before the title of the product page («Lo sentimos, este producto no está
			 * disponible en tu país», module locale).
			 *
			 * @since 0.12.2
			 *
			 * @param WC_Product $product Product.
			 */
			do_action( 'lachinata/product/before_title', $lachinata_product );
			?>
			<?php if ( $lachinata_eyebrow ) : ?>
				<span class="eyebrow lc-buy__eyebrow"><?php echo esc_html( $lachinata_eyebrow ); ?></span>
			<?php endif; ?>
			<h1 class="h1 lc-buy__title" id="lc-product-title"><?php echo esc_html( $lachinata_product->get_name() ); ?></h1>
			<?php if ( $lachinata_wine ) : ?>
				<?php $lachinata_vintage_name = (string) ( $lachinata_wine['vintages'][ $lachinata_wine['vintage'] ?? '' ] ?? '' ); ?>
				<p class="body-sm lc-buy__subtitle" data-no-translation>
					<?php echo esc_html( implode( ' · ', array_filter( array_map( 'strval', (array) ( $lachinata_wine['subtitle'] ?? array() ) ) ) ) ); ?>
					<span data-lc-wine-vintage<?php echo '' === $lachinata_vintage_name ? ' hidden' : ''; ?>><?php echo esc_html( ( ! empty( $lachinata_wine['subtitle'] ) ? ' · ' : '' ) . $lachinata_vintage_name ); ?></span>
				</p>
				<?php
				lachinata_part(
					'wine-scores',
					array(
						'scores'  => (array) ( $lachinata_wine['scores'] ?? array() ),
						'vintage' => (string) ( $lachinata_wine['vintage'] ?? '' ),
					)
				);
				?>
			<?php endif; ?>
			<?php if ( wc_review_ratings_enabled() && $lachinata_product->get_review_count() ) : ?>
				<a href="#lc-tab-reviews" class="lc-buy__rating" data-lc-tab-link="reviews"><?php echo lachinata_rating( (float) $lachinata_product->get_average_rating(), $lachinata_product->get_review_count(), true, true ); ?></a>
			<?php endif; ?>
			<?php
			echo lachinata_price(
				array(
					'now'   => lachinata_display_price( $lachinata_product ),
					'old'   => $lachinata_product->is_on_sale() && ! $lachinata_product->is_type( 'variable' ) ? wc_price( (float) wc_get_price_to_display( $lachinata_product, array( 'price' => $lachinata_product->get_regular_price() ) ) ) : '',
					'note'  => lachinata_price_note(),
					'unit'  => $lachinata_unit,
					'large' => true,
					'class' => 'lc-buy__price',
				)
			);
			/**
			 * The short description, right after the price (#41): its own markup (paragraphs,
			 * bold, lists), translated like the rest of the product; nothing when it is empty.
			 * WooCommerce's filter, as its template does.
			 *
			 * @since 0.17.2
			 */
			$lachinata_excerpt = (string) apply_filters( 'woocommerce_short_description', $lachinata_product->get_short_description() ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook.
			if ( '' !== trim( wp_strip_all_tags( $lachinata_excerpt ) ) ) {
				echo '<div class="body lc-buy__excerpt">' . wp_kses_post( $lachinata_excerpt ) . '</div>';
			}
			lachinata_part( 'gift-summary', array( 'gift' => $lachinata_gift ) );
			/**
			 * Notices of the product page under the price, such as «Envío refrigerado» with its
			 * conditions (module catalog, from the shipping configuration). `html` may hold
			 * inline markup; `icon` is one of the sprite.
			 *
			 * @since 0.12.2
			 *
			 * @param array<int, array{tone: string, icon: string, html: string}> $notices Notices, none by default.
			 * @param WC_Product                                                  $product Product.
			 */
			foreach ( (array) apply_filters( 'lachinata/product/notices', array(), $lachinata_product ) as $lachinata_notice ) {
				echo lachinata_notice( (string) ( $lachinata_notice['html'] ?? '' ), (string) ( $lachinata_notice['tone'] ?? 'info' ), 'lc-buy__notice', (string) ( $lachinata_notice['icon'] ?? '' ) );
			}
			/**
			 * Whether the product page shows the availability and the buy form (false: the
			 * product does not ship to the visitor's destination, locale module). The page is
			 * never hidden.
			 *
			 * @since 0.11.0
			 *
			 * @param bool       $can_buy Show the buy form.
			 * @param WC_Product $product Product.
			 */
			$lachinata_can_buy = (bool) apply_filters( 'lachinata/product/can_buy', true, $lachinata_product );
			/**
			 * Before the availability and the buy form («Cambiar destino» when the product does
			 * not ship to the visitor, locale module).
			 *
			 * @since 0.11.0
			 *
			 * @param WC_Product $product Product.
			 */
			do_action( 'lachinata/product/before_buy', $lachinata_product );
			if ( $lachinata_can_buy ) {
				lachinata_part( 'product-availability', array( 'product' => $lachinata_product ) );
				lachinata_part(
					'product-buy',
					array(
						'product' => $lachinata_product,
						'wine'    => $lachinata_wine,
					)
				);
				lachinata_part(
					'bulk-cta',
					array(
						'cta'     => lachinata_product_bulk_cta( $lachinata_product ),
						'product' => $lachinata_product,
					)
				);
			}
			?>
			<?php
			lachinata_part(
				'age-notice',
				array(
					'text'  => $lachinata_age,
					'class' => 'lc-buy__age',
				)
			);
			?>
			<?php if ( $lachinata_seals ) : ?>
				<ul class="lc-seals" aria-label="<?php esc_attr_e( 'Sellos', 'lachinata' ); ?>">
					<?php foreach ( $lachinata_seals as $lachinata_seal ) : ?>
						<li>
							<a href="<?php echo esc_url( $lachinata_seal['url'] ); ?>" class="lc-seals__item">
								<?php
								echo $lachinata_seal['image_id']
									? wp_get_attachment_image(
										(int) $lachinata_seal['image_id'],
										'thumbnail',
										false,
										array(
											'alt'     => '',
											'loading' => 'lazy',
											'class'   => 'lc-seals__img',
										)
									)
									: '<span class="lc-seals__img lc-seals__img--empty" aria-hidden="true">' . lachinata_icon( 'check' ) . '</span>';
								?>
								<span class="caption"><?php echo esc_html( $lachinata_seal['name'] ); ?></span>
							</a>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
			<?php
			lachinata_part(
				'usp-bar',
				array(
					'layout' => 'row',
					'class'  => 'lc-buy__usp',
				)
			);
			?>
		</section>
		</div>

		<?php if ( $lachinata_wine ) : ?>
			<div class="lc-wine">
				<?php
				lachinata_part(
					'wine-facts',
					array(
						'facts'     => (array) ( $lachinata_wine['facts'] ?? array() ),
						'allergens' => (string) ( $lachinata_wine['allergens'] ?? '' ),
					)
				);
				lachinata_part( 'tasting-notes', array( 'tasting' => (array) ( $lachinata_wine['tasting'] ?? array() ) ) );
				lachinata_part(
					'pairing-row',
					array(
						'pairing' => (array) ( $lachinata_wine['pairing'] ?? array() ),
						'product' => $lachinata_product,
					)
				);
				?>
			</div>
			<?php
			lachinata_part(
				'wine-winery',
				array(
					'winery'   => $lachinata_wine['winery'] ?? null,
					'products' => (array) ( $lachinata_wine['winery']['products'] ?? array() ),
				)
			);
			?>
			<script type="application/json" data-lc-wine><?php echo wp_json_encode( (array) ( $lachinata_wine['variations'] ?? array() ), JSON_HEX_TAG | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ); ?></script>
		<?php endif; ?>

		<?php lachinata_part( 'gift-contents', array( 'gift' => $lachinata_gift ) ); ?>

		<div class="lc-product__info">
			<?php
			$lachinata_panels = $lachinata_tabs;
			if ( $lachinata_reviews ) {
				$lachinata_panels[] = array(
					'id'      => 'reviews',
					/* translators: %s: number of reviews. */
					'title'   => sprintf( __( 'Opiniones (%s)', 'lachinata' ), number_format_i18n( $lachinata_product->get_review_count() ) ),
					'content' => '',
				);
			}
			?>
			<?php if ( $lachinata_panels ) : ?>
				<div class="lc-product__tabs" data-lc-tabs>
					<div class="lc-tabs label" role="tablist" aria-label="<?php esc_attr_e( 'Información del producto', 'lachinata' ); ?>">
						<?php foreach ( $lachinata_panels as $lachinata_index => $lachinata_panel ) : ?>
							<button type="button" role="tab" id="lc-tab-btn-<?php echo esc_attr( $lachinata_panel['id'] ); ?>" aria-controls="lc-tab-<?php echo esc_attr( $lachinata_panel['id'] ); ?>" aria-selected="<?php echo 0 === $lachinata_index ? 'true' : 'false'; ?>"<?php echo $lachinata_index ? ' tabindex="-1"' : ''; ?>><?php echo esc_html( $lachinata_panel['title'] ); ?></button>
						<?php endforeach; ?>
					</div>
					<?php foreach ( $lachinata_panels as $lachinata_index => $lachinata_panel ) : ?>
						<div class="lc-tabs__panel body" role="tabpanel" id="lc-tab-<?php echo esc_attr( $lachinata_panel['id'] ); ?>" aria-labelledby="lc-tab-btn-<?php echo esc_attr( $lachinata_panel['id'] ); ?>" tabindex="0" data-lc-panel>
							<h2 class="h3 lc-tabs__heading"><?php echo esc_html( $lachinata_panel['title'] ); ?></h2>
							<?php if ( 'reviews' === $lachinata_panel['id'] ) : ?>
								<?php comments_template(); ?>
							<?php else : ?>
								<div class="lc-prose"><?php echo wp_kses_post( $lachinata_panel['content'] ); ?></div>
								<?php if ( 'description' === $lachinata_panel['id'] && $lachinata_details ) : ?>
									<dl class="lc-details body-sm">
										<?php foreach ( $lachinata_details as $lachinata_row ) : ?>
											<div><dt><?php echo esc_html( $lachinata_row['label'] ); ?></dt><dd><?php echo esc_html( $lachinata_row['value'] ); ?></dd></div>
										<?php endforeach; ?>
									</dl>
								<?php endif; ?>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
			<?php $lachinata_label = $lachinata_wine['label'] ?? null; ?>
			<?php if ( is_array( $lachinata_label ) ) : ?>
				<div class="lc-acc lc-wine__label">
					<div class="lc-acc__item">
						<button type="button" class="lc-acc__btn h4" aria-expanded="false" aria-controls="lc-wine-label" data-lc-toggle>
							<?php esc_html_e( 'Ingredientes e información nutricional', 'lachinata' ); ?>
							<?php echo lachinata_icon( 'chevron-down' ); ?>
						</button>
						<div class="lc-acc__panel body-sm" id="lc-wine-label" hidden>
							<?php if ( '' !== (string) $lachinata_label['ingredients'] ) : ?>
								<p><strong><?php esc_html_e( 'Ingredientes', 'lachinata' ); ?></strong><br><?php echo nl2br( esc_html( (string) $lachinata_label['ingredients'] ) ); ?></p>
							<?php endif; ?>
							<?php if ( '' !== (string) $lachinata_label['nutrition'] ) : ?>
								<p><strong><?php esc_html_e( 'Información nutricional', 'lachinata' ); ?></strong><br><?php echo nl2br( esc_html( (string) $lachinata_label['nutrition'] ) ); ?></p>
							<?php endif; ?>
							<?php if ( '' !== (string) $lachinata_label['url'] ) : ?>
								<p><a href="<?php echo esc_url( (string) $lachinata_label['url'] ); ?>" rel="noopener" target="_blank"><?php esc_html_e( 'Ver la etiqueta electrónica', 'lachinata' ); ?><?php echo lachinata_icon( 'external', array( 'size' => 'sm' ) ); ?></a></p>
							<?php endif; ?>
						</div>
					</div>
				</div>
			<?php endif; ?>
			<?php $lachinata_help = lachinata_menu( 'help' ); ?>
			<?php if ( $lachinata_help ) : ?>
				<aside class="lc-product__help lc-acc" aria-label="<?php esc_attr_e( 'Ayuda', 'lachinata' ); ?>">
					<?php foreach ( $lachinata_help as $lachinata_index => $lachinata_item ) : ?>
						<div class="lc-acc__item">
							<button type="button" class="lc-acc__btn h4" aria-expanded="false" aria-controls="lc-help-<?php echo esc_attr( (string) $lachinata_index ); ?>" data-lc-toggle>
								<?php echo esc_html( $lachinata_item['title'] ); ?>
								<?php echo lachinata_icon( 'chevron-down' ); ?>
							</button>
							<div class="lc-acc__panel body-sm" id="lc-help-<?php echo esc_attr( (string) $lachinata_index ); ?>" hidden>
								<p><?php echo esc_html( $lachinata_item['text'] ); ?></p>
								<?php if ( $lachinata_item['url'] && '#' !== $lachinata_item['url'] ) : ?>
									<a href="<?php echo esc_url( $lachinata_item['url'] ); ?>"><?php esc_html_e( 'Más información', 'lachinata' ); ?></a>
								<?php endif; ?>
							</div>
						</div>
					<?php endforeach; ?>
				</aside>
			<?php endif; ?>
		</div>
	</div>

	<?php if ( $lachinata_cross['products'] ) : ?>
		<section class="lc-block lc-container" aria-labelledby="lc-cross-title">
			<?php
			lachinata_part(
				'section-header',
				array(
					'title' => $lachinata_cross['title'],
					'id'    => 'lc-cross-title',
					'more'  => $lachinata_cat ? __( 'Ver más', 'lachinata' ) : '',
					'href'  => $lachinata_cat ? lachinata_term_url( $lachinata_cat ) : '',
				)
			);
			?>
			<div class="lc-carousel">
				<?php foreach ( $lachinata_cross['products'] as $lachinata_index => $lachinata_item ) : ?>
					<?php
					lachinata_part(
						'product-card',
						array(
							'product' => $lachinata_item,
							'list'    => array(
								'id'    => 'related',
								'name'  => $lachinata_cross['title'],
								'index' => $lachinata_index + 1,
							),
						)
					);
					?>
				<?php endforeach; ?>
			</div>
		</section>
	<?php endif; ?>

	<?php
	/**
	 * Product page, under everything that serves to buy (purchase, description, reviews and
	 * cross-sell).
	 *
	 * @since 0.13.0
	 *
	 * @param WC_Product $product Product.
	 */
	do_action( 'lachinata/product/after', $lachinata_product );

	if ( $lachinata_can_buy ) {
		lachinata_part( 'sticky-cta', array( 'product' => $lachinata_product ) );
	}
	?>
	<?php
	/**
	 * WooCommerce: after the product.
	 *
	 * @since 0.2.0
	 */
	do_action( 'woocommerce_after_single_product' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.HookCommentWrongStyle, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook.
endwhile;

get_footer();
