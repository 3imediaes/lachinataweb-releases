<?php
/**
 * WooCommerce → La Chinata → Bodega.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

use LaChinata\Core\Admin\Screen;
use LaChinata\Core\Hooks;
use LaChinata\Core\Settings;
use LaChinata\Core\Terms;

defined( 'ABSPATH' ) || exit;

/**
 * The settings of the Bodega: its category and attributes, the cases, the lists of critics
 * and contests with what is shown, pairing, texts and the listing; and the wines whose card
 * is not complete. Lists are written one per line, with «|» between fields.
 */
final class BodegaTab {

	/**
	 * Tab id.
	 */
	public const TAB = 'bodega';

	/**
	 * Action of admin-post.php, also nonce action.
	 */
	private const SAVE = 'lachinata_bodega_settings';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/core/admin_tabs', array( self::class, 'tab' ), 36 );
		Hooks::add_action( 'admin_post_' . self::SAVE, array( self::class, 'handle' ) );
	}

	/**
	 * Adds the tab after Catálogo.
	 *
	 * @param array<string, array{label: string, render: callable}> $tabs Tabs.
	 * @return array<string, array{label: string, render: callable}>
	 */
	public static function tab( array $tabs ): array {
		$position = array_search( 'catalog', array_keys( $tabs ), true );
		$position = false === $position ? count( $tabs ) : $position + 1;
		$tab      = array(
			self::TAB => array(
				'label'  => __( 'Bodega', 'lachinata-core' ),
				'render' => array( self::class, 'render' ),
			),
		);
		return array_slice( $tabs, 0, $position, true ) + $tab + $tabs;
	}

	/**
	 * Lines of a list of `{name, short}`: «Nombre completo | Como se ve».
	 *
	 * @param array<int, array{name: string, short: string}> $rows List.
	 */
	private static function named_lines( array $rows ): string {
		return implode( "\n", array_map( static fn( array $row ): string => $row['name'] === $row['short'] ? $row['name'] : $row['name'] . ' | ' . $row['short'], $rows ) );
	}

	/**
	 * Prints the tab.
	 */
	public static function render(): void {
		$module = BodegaModule::instance();
		if ( null === $module ) {
			return;
		}
		$categories  = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
				'orderby'    => 'name',
			)
		);
		$categories  = is_array( $categories ) ? $categories : array();
		$attributes  = wc_get_attribute_taxonomies();
		$texts       = (array) Settings::get( $module, 'texts' );
		$chips       = implode( "\n", array_map( static fn( array $chip ): string => $chip['label'] . ' | ' . implode( ', ', $chip['types'] ) . ( '' !== $chip['category'] ? ' | ' . $chip['category'] : '' ), Config::chips() ) );
		$entries     = implode( "\n", array_map( static fn( array $entry ): string => implode( ' | ', array( $entry['title'], $entry['url'], $entry['eyebrow'], $entry['text'], $entry['cta'], $entry['tint'] ) ), Config::entries() ) );
		$select      = static function ( string $name, string $current, array $options ): void {
			printf( '<select name="%s">', esc_attr( $name ) );
			foreach ( $options as $value => $label ) {
				printf( '<option value="%1$s"%2$s>%3$s</option>', esc_attr( (string) $value ), selected( (string) $value, $current, false ), esc_html( (string) $label ) );
			}
			echo '</select>';
		};
		$cat_options = array( '' => __( '— Ninguna —', 'lachinata-core' ) );
		foreach ( $categories as $category ) {
			$cat_options[ $category->slug ] = Terms::name( $category ) . ' (' . $category->slug . ')';
		}
		$att_options = array( '' => __( 'El que se llame así (de serie)', 'lachinata-core' ) );
		foreach ( $attributes as $attribute ) {
			$att_options[ wc_attribute_taxonomy_name( $attribute->attribute_name ) ] = $attribute->attribute_label;
		}
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE ); ?>">
			<?php wp_nonce_field( self::SAVE ); ?>
			<h2><?php esc_html_e( 'Catálogo', 'lachinata-core' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Categoría de la Bodega', 'lachinata-core' ); ?></th>
					<td>
						<?php $select( 'category', (string) Settings::get( $module, 'category' ), $cat_options ); ?>
						<p class="description"><?php esc_html_e( 'Su listado lleva los filtros de vino y de ella cuelgan las páginas de tipo y origen («…/tintos/», «…/extremadura/»). Que salga en el menú principal es configuración del menú y de la lista de categorías de la tienda.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Subcategoría de accesorios', 'lachinata-core' ); ?></th>
					<td>
						<?php $select( 'accessories_category', (string) Settings::get( $module, 'accessories_category' ), $cat_options ); ?>
						<p class="description"><?php esc_html_e( 'Sin alcohol ni caja de serie, y con su chip en el listado.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Atributo de añada', 'lachinata-core' ); ?></th>
					<td><?php $select( 'vintage_attribute', (string) Settings::get( $module, 'vintage_attribute' ), $att_options ); ?> <span class="description"><?php echo esc_html( '' !== Config::vintage_attribute() ? sprintf( /* translators: %s: attribute taxonomy. */ __( 'Ahora: %s', 'lachinata-core' ), Config::vintage_attribute() ) : __( 'Ahora: ninguno', 'lachinata-core' ) ); ?></span></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Atributo de formato', 'lachinata-core' ); ?></th>
					<td><?php $select( 'format_attribute', (string) Settings::get( $module, 'format_attribute' ), $att_options ); ?> <span class="description"><?php echo esc_html( '' !== Config::format_attribute() ? sprintf( /* translators: %s: attribute taxonomy. */ __( 'Ahora: %s', 'lachinata-core' ), Config::format_attribute() ) : __( 'Ahora: ninguno', 'lachinata-core' ) ); ?></span></td>
				</tr>
			</table>

			<h2><?php esc_html_e( 'Cajas de 6', 'lachinata-core' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="lc-case-same"><?php esc_html_e( 'Caja de 6 iguales (%)', 'lachinata-core' ); ?></label></th>
					<td><input id="lc-case-same" type="number" min="0" max="100" step="0.5" name="case_same" value="<?php echo esc_attr( (string) Config::same_discount() ); ?>" class="small-text"></td>
				</tr>
				<tr>
					<th scope="row"><label for="lc-case-mixed"><?php esc_html_e( 'Caja de 6 variada (%)', 'lachinata-core' ); ?></label></th>
					<td>
						<input id="lc-case-mixed" type="number" min="0" max="100" step="0.5" name="case_mixed" value="<?php echo esc_attr( (string) Config::mixed_discount() ); ?>" class="small-text">
						<p class="description"><?php esc_html_e( 'Primero se forman las cajas de iguales; con lo que sobra, las variadas. Solo cuentan los vinos con «Cuenta para la caja».', 'lachinata-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Con otros descuentos', 'lachinata-core' ); ?></th>
					<td>
						<label><input type="checkbox" name="stack_sale" value="1" <?php checked( Config::stack_sale() ); ?>> <?php esc_html_e( 'Sumar a la oferta del producto', 'lachinata-core' ); ?></label><br>
						<label><input type="checkbox" name="stack_coupons" value="1" <?php checked( Config::stack_coupons() ); ?>> <?php esc_html_e( 'Sumar a los cupones del cliente', 'lachinata-core' ); ?></label>
						<p class="description"><?php esc_html_e( 'De serie, apagados: con una oferta, cada línea se queda con el mayor de los dos descuentos; con un cupón, el pedido se queda con lo que salga más barato y la bolsa lo avisa. Los cupones de envío gratis siempre se suman.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
			</table>

			<h2><?php esc_html_e( 'Críticos y concursos', 'lachinata-core' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="lc-critics"><?php esc_html_e( 'Críticos', 'lachinata-core' ); ?></label></th>
					<td>
						<textarea id="lc-critics" name="critics" rows="8" class="large-text code"><?php echo esc_textarea( self::named_lines( Config::critics() ) ); ?></textarea>
						<p class="description"><?php esc_html_e( 'Uno por línea, por peso: «Nombre completo | Como se ve en la insignia». El orden desempata.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="lc-contests"><?php esc_html_e( 'Concursos', 'lachinata-core' ); ?></label></th>
					<td><textarea id="lc-contests" name="contests" rows="6" class="large-text code"><?php echo esc_textarea( self::named_lines( Config::contests() ) ); ?></textarea></td>
				</tr>
				<tr>
					<th scope="row"><label for="lc-medals"><?php esc_html_e( 'Medallas', 'lachinata-core' ); ?></label></th>
					<td><textarea id="lc-medals" name="medals" rows="5" class="regular-text code"><?php echo esc_textarea( implode( "\n", Config::medals() ) ); ?></textarea><p class="description"><?php esc_html_e( 'Una por línea, de mejor a peor.', 'lachinata-core' ); ?></p></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Qué se enseña', 'lachinata-core' ); ?></th>
					<td>
						<label><?php esc_html_e( 'Puntuaciones desde', 'lachinata-core' ); ?> <input type="number" min="0" max="100" name="min_points" value="<?php echo esc_attr( (string) Config::min_points() ); ?>" class="small-text"></label>
						&nbsp; <label><?php esc_html_e( 'Medallas desde', 'lachinata-core' ); ?> <?php $select( 'min_medal', Config::min_medal(), array_combine( Config::medals(), Config::medals() ) ); ?></label>
						<p class="description"><?php esc_html_e( 'Solo de la añada que se ve y como mucho tres: primero las puntuaciones. Lo demás se guarda pero no se enseña.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
			</table>

			<h2><?php esc_html_e( 'Maridaje, edad y textos', 'lachinata-core' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Maridaje', 'lachinata-core' ); ?></th>
					<td><label><input type="checkbox" name="suggest_pairing" value="1" <?php checked( Config::suggest_pairing() ); ?>> <?php esc_html_e( 'Sugerir un producto por plato cuando el vino no tiene productos elegidos', 'lachinata-core' ); ?></label><p class="description"><?php esc_html_e( 'El más vendido de la categoría que se elige en cada plato (Productos › Maridajes).', 'lachinata-core' ); ?></p></td>
				</tr>
				<tr>
					<th scope="row"><label for="lc-age"><?php esc_html_e( 'Aviso de edad', 'lachinata-core' ); ?></label></th>
					<td><textarea id="lc-age" name="texts[age]" rows="2" class="large-text" placeholder="<?php echo esc_attr( Config::text( 'age' ) ); ?>"><?php echo esc_textarea( (string) ( $texts['age'] ?? '' ) ); ?></textarea></td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Nota para el transportista', 'lachinata-core' ); ?></th>
					<td>
						<label><input type="checkbox" name="carrier_note" value="1" <?php checked( Config::carrier_note() ); ?>> <?php esc_html_e( 'Añadirla a los pedidos con alcohol (la lee Odoo)', 'lachinata-core' ); ?></label>
						<textarea name="texts[carrier_note]" rows="2" class="large-text" placeholder="<?php echo esc_attr( Config::text( 'carrier_note' ) ); ?>"><?php echo esc_textarea( (string) ( $texts['carrier_note'] ?? '' ) ); ?></textarea>
					</td>
				</tr>
			</table>

			<h2><?php esc_html_e( 'Listado', 'lachinata-core' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="lc-eyebrow"><?php esc_html_e( 'Antetítulo y texto', 'lachinata-core' ); ?></label></th>
					<td>
						<input id="lc-eyebrow" type="text" name="texts[eyebrow]" value="<?php echo esc_attr( (string) ( $texts['eyebrow'] ?? '' ) ); ?>" class="regular-text">
						<textarea name="texts[intro]" rows="2" class="large-text" aria-label="<?php esc_attr_e( 'Texto del listado', 'lachinata-core' ); ?>"><?php echo esc_textarea( (string) ( $texts['intro'] ?? '' ) ); ?></textarea>
						<p class="description"><?php esc_html_e( 'Sin texto, el listado dice cuántos vinos hay.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="lc-chips"><?php esc_html_e( 'Chips de tipo', 'lachinata-core' ); ?></label></th>
					<td>
						<textarea id="lc-chips" name="chips" rows="6" class="large-text code" placeholder="Tintos | tintos&#10;Generosos y dulces | generosos, dulces&#10;Accesorios | | accesorios-vino"><?php echo esc_textarea( $chips ); ?></textarea>
						<p class="description"><?php esc_html_e( 'Uno por línea: «Etiqueta | tipos (slugs, separados por comas) | categoría (slug, opcional)». Vacío: un chip por tipo con vinos y el de accesorios.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="lc-featured-origin"><?php esc_html_e( 'Origen destacado', 'lachinata-core' ); ?></label></th>
					<td>
						<?php
						$origins = get_terms(
							array(
								'taxonomy'   => Taxonomies::ORIGIN,
								'hide_empty' => false,
								'orderby'    => 'name',
							)
						);
						$options = array( '' => __( '— Ninguno —', 'lachinata-core' ) );
						foreach ( is_array( $origins ) ? $origins : array() as $origin ) {
							$options[ $origin->slug ] = Terms::name( $origin );
						}
						$select( 'featured_origin', (string) Settings::get( $module, 'featured_origin' ), $options );
						?>
						<p class="description"><?php esc_html_e( 'Su entrada («Vinos de Extremadura») sale delante siempre que tenga vinos. «Mejor puntuados» sale cuando hay puntuaciones publicadas que se enseñan, y «Arma tu caja» con descuento de caja variada.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="lc-entries"><?php esc_html_e( 'Entradas', 'lachinata-core' ); ?></label></th>
					<td>
						<textarea id="lc-entries" name="entries" rows="4" class="large-text code" placeholder="Regalos con vino | /regalos/ | Ideas | Packs con vino | Ver | cream"><?php echo esc_textarea( $entries ); ?></textarea>
						<p class="description"><?php esc_html_e( 'Entradas más, detrás de las automáticas. Una por línea: «Título | dirección | antetítulo | texto | botón | tinta».', 'lachinata-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="lc-landing-min"><?php esc_html_e( 'Páginas de tipo y origen', 'lachinata-core' ); ?></label></th>
					<td><?php esc_html_e( 'Se indexan con', 'lachinata-core' ); ?> <input id="lc-landing-min" type="number" min="1" name="landing_min" value="<?php echo esc_attr( (string) Config::landing_min() ); ?>" class="small-text"> <?php esc_html_e( 'vinos o más. Las combinaciones de filtros, nunca.', 'lachinata-core' ); ?></td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
		<?php
		self::render_incomplete();
	}

	/**
	 * The wines of the Bodega whose card is not complete.
	 */
	private static function render_incomplete(): void {
		$category = Config::category();
		echo '<h2>' . esc_html__( 'Fichas de vino sin completar', 'lachinata-core' ) . '</h2>';
		if ( null === $category ) {
			echo '<p>' . esc_html__( 'Elige antes la categoría de la Bodega.', 'lachinata-core' ) . '</p>';
			return;
		}
		$ids  = wc_get_products(
			array(
				'status'   => array( 'publish', 'draft', 'pending', 'private' ),
				'limit'    => -1,
				'return'   => 'ids',
				'category' => array( $category->slug ),
			)
		);
		$rows = array();
		foreach ( is_array( $ids ) ? $ids : array() as $id ) {
			$product = wc_get_product( (int) $id );
			if ( ! $product instanceof \WC_Product || ! Fields::is_wine( $product ) ) {
				continue;
			}
			$state = Fields::completeness( $product );
			if ( $state['missing'] ) {
				$rows[] = array( $product, $state );
			}
		}
		if ( ! $rows ) {
			echo '<p>' . esc_html__( 'Todas las fichas de vino están completas.', 'lachinata-core' ) . '</p>';
			return;
		}
		/* translators: %s: number of wines. */
		echo '<p>' . esc_html( sprintf( _n( '%s vino sin completar.', '%s vinos sin completar.', count( $rows ), 'lachinata-core' ), number_format_i18n( count( $rows ) ) ) ) . '</p>';
		echo '<table class="widefat striped"><thead><tr><th scope="col">' . esc_html__( 'Vino', 'lachinata-core' ) . '</th><th scope="col">' . esc_html__( 'Completa', 'lachinata-core' ) . '</th><th scope="col">' . esc_html__( 'Falta', 'lachinata-core' ) . '</th></tr></thead><tbody>';
		foreach ( array_slice( $rows, 0, 200 ) as [ $product, $state ] ) {
			printf(
				'<tr><td><a href="%1$s">%2$s</a></td><td>%3$s</td><td>%4$s</td></tr>',
				esc_url( (string) get_edit_post_link( $product->get_id() ) ),
				esc_html( $product->get_name() ),
				/* translators: 1: checks done, 2: total checks. */
				esc_html( sprintf( __( '%1$s de %2$s', 'lachinata-core' ), number_format_i18n( $state['done'] ), number_format_i18n( $state['total'] ) ) ),
				esc_html( implode( ', ', $state['missing'] ) )
			);
		}
		echo '</tbody></table>';
	}

	/**
	 * Rows of a textarea: lines split by «|», trimmed, without empty lines.
	 *
	 * @param string $key POST field.
	 * @return array<int, string[]>
	 */
	private static function rows( string $key ): array {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Screen::check() in handle().
		$text  = isset( $_POST[ $key ] ) ? sanitize_textarea_field( wp_unslash( $_POST[ $key ] ) ) : '';
		$rows  = array();
		$lines = preg_split( '/\R/', $text );
		foreach ( false === $lines ? array() : $lines as $line ) {
			if ( '' === trim( $line ) ) {
				continue;
			}
			$rows[] = array_map( 'trim', explode( '|', $line ) );
		}
		return $rows;
	}

	/**
	 * Saves the settings.
	 */
	public static function handle(): void {
		Screen::check( self::SAVE );
		$module = BodegaModule::instance();
		if ( null === $module ) {
			Screen::redirect( self::TAB );
		}
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Screen::check().
		foreach ( array( 'category', 'accessories_category', 'featured_origin' ) as $key ) {
			Settings::set( $module, $key, isset( $_POST[ $key ] ) ? sanitize_title( wp_unslash( $_POST[ $key ] ) ) : '' );
		}
		foreach ( array( 'vintage_attribute', 'format_attribute' ) as $key ) {
			Settings::set( $module, $key, isset( $_POST[ $key ] ) ? sanitize_key( wp_unslash( $_POST[ $key ] ) ) : '' );
		}
		foreach ( array( 'case_same', 'case_mixed' ) as $key ) {
			Settings::set( $module, $key, isset( $_POST[ $key ] ) ? max( 0.0, min( 100.0, (float) str_replace( ',', '.', sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) ) ) ) : 0.0 );
		}
		foreach ( array( 'stack_sale', 'stack_coupons', 'suggest_pairing', 'carrier_note' ) as $key ) {
			Settings::set( $module, $key, ! empty( $_POST[ $key ] ) );
		}
		foreach ( array( 'critics', 'contests' ) as $key ) {
			Settings::set(
				$module,
				$key,
				array_map(
					static fn( array $row ): array => array(
						'name'  => $row[0],
						'short' => (string) ( $row[1] ?? '' ),
					),
					self::rows( $key )
				)
			);
		}
		Settings::set( $module, 'medals', array_map( static fn( array $row ): string => $row[0], self::rows( 'medals' ) ) );
		Settings::set( $module, 'min_points', isset( $_POST['min_points'] ) ? absint( wp_unslash( $_POST['min_points'] ) ) : 90 );
		Settings::set( $module, 'min_medal', isset( $_POST['min_medal'] ) ? sanitize_text_field( wp_unslash( $_POST['min_medal'] ) ) : '' );
		Settings::set( $module, 'landing_min', isset( $_POST['landing_min'] ) ? max( 1, absint( wp_unslash( $_POST['landing_min'] ) ) ) : 3 );
		$texts = isset( $_POST['texts'] ) && is_array( $_POST['texts'] ) ? map_deep( wp_unslash( $_POST['texts'] ), 'sanitize_textarea_field' ) : array();
		Settings::set(
			$module,
			'texts',
			array_map(
				static fn( $text ): string => sanitize_textarea_field( (string) $text ),
				array_intersect_key( $texts, array_flip( array( 'age', 'carrier_note', 'eyebrow', 'intro' ) ) )
			)
		);
		// phpcs:enable
		Settings::set(
			$module,
			'chips',
			array_map(
				static fn( array $row ): array => array(
					'label'    => $row[0],
					'types'    => array_values( array_filter( array_map( 'trim', explode( ',', (string) ( $row[1] ?? '' ) ) ) ) ),
					'category' => (string) ( $row[2] ?? '' ),
				),
				self::rows( 'chips' )
			)
		);
		Settings::set(
			$module,
			'entries',
			array_map(
				static fn( array $row ): array => array(
					'title'   => $row[0],
					'url'     => (string) ( $row[1] ?? '' ),
					'eyebrow' => (string) ( $row[2] ?? '' ),
					'text'    => (string) ( $row[3] ?? '' ),
					'cta'     => (string) ( $row[4] ?? '' ),
					'tint'    => (string) ( $row[5] ?? '' ),
				),
				self::rows( 'entries' )
			)
		);
		Screen::flash( 'success', array( __( 'Ajustes guardados.', 'lachinata-core' ) ) );
		Screen::redirect( self::TAB );
	}
}
