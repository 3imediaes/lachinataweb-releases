<?php
/**
 * Fields of each wine.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

use LaChinata\Core\Services;
use LaChinata\Core\Terms;

defined( 'ABSPATH' ) || exit;

/**
 * Registered meta of the product and its variations (no ACF), sanitised on the way in. What
 * belongs to the wine goes in the product once; what changes with the vintage (price, stock,
 * SKU) is the variation's, and a variation may change the strength and the ageing. Scores and
 * awards live in the product, each with its vintage, so they survive a vintage that is
 * hidden or deleted.
 */
final class Fields {

	public const GRADE       = '_lc_bodega_grado';
	public const AGEING      = '_lc_bodega_crianza';
	public const VITICULTURE = '_lc_bodega_viticultura';
	public const TEMPERATURE = '_lc_bodega_temperatura';
	public const TASTING     = '_lc_bodega_cata';
	public const PROFILE     = '_lc_bodega_perfil';
	public const GRAPES      = '_lc_bodega_uvas';
	public const SCORES      = '_lc_bodega_puntuaciones';
	public const PAIRING     = '_lc_bodega_maridaje';
	public const SUGGEST     = '_lc_bodega_sugerir';
	public const LABEL       = '_lc_bodega_etiqueta';
	public const CASE_FLAG   = '_lc_bodega_caja';
	public const ALCOHOL     = '_lc_bodega_alcohol';
	public const BEST        = '_lc_bodega_mejor';
	public const MIGRATED    = '_lc_bodega_migrado';

	/**
	 * Most pairing products.
	 */
	public const MAX_PAIRING = 3;

	/**
	 * Viticulture values (buttons; a wine may have more than one).
	 */
	public const VITICULTURES = array( 'convencional', 'ecologica', 'biodinamica', 'sostenible', 'tradicional', 'natural' );

	/**
	 * Profile scales of TastingNotes.
	 */
	public const PROFILE_KEYS = array( 'body', 'oak', 'sweet', 'acid' );

	/**
	 * Every product and variation key, for «Borrar datos».
	 *
	 * @return string[]
	 */
	public static function product_keys(): array {
		return array( self::GRADE, self::AGEING, self::VITICULTURE, self::TEMPERATURE, self::TASTING, self::PROFILE, self::GRAPES, self::SCORES, self::PAIRING, self::SUGGEST, self::LABEL, self::CASE_FLAG, self::ALCOHOL, self::BEST, self::MIGRATED );
	}

	/**
	 * Names of the viticulture values.
	 *
	 * @return array<string, string>
	 */
	public static function viticulture_labels(): array {
		return array(
			'convencional' => __( 'Convencional', 'lachinata-core' ),
			'ecologica'    => __( 'Ecológica', 'lachinata-core' ),
			'biodinamica'  => __( 'Biodinámica', 'lachinata-core' ),
			'sostenible'   => __( 'Sostenible', 'lachinata-core' ),
			'tradicional'  => __( 'Tradicional', 'lachinata-core' ),
			'natural'      => __( 'Natural', 'lachinata-core' ),
		);
	}

	/**
	 * Registers the meta of products (and of variations, which are `product_variation`).
	 */
	public static function register(): void {
		$specs = array(
			self::GRADE       => array( 'string', array( self::class, 'grade_meta' ) ),
			self::AGEING      => array( 'string', array( self::class, 'line' ) ),
			self::VITICULTURE => array( 'array', array( self::class, 'viticulture' ) ),
			self::TEMPERATURE => array( 'array', array( self::class, 'temperature' ) ),
			self::TASTING     => array( 'object', array( self::class, 'tasting' ) ),
			self::PROFILE     => array( 'object', array( self::class, 'profile' ) ),
			self::GRAPES      => array( 'array', array( self::class, 'grapes' ) ),
			self::SCORES      => array( 'array', array( self::class, 'scores' ) ),
			self::PAIRING     => array( 'array', array( self::class, 'pairing' ) ),
			self::SUGGEST     => array( 'string', array( self::class, 'flag' ) ),
			self::LABEL       => array( 'object', array( self::class, 'label' ) ),
			self::CASE_FLAG   => array( 'string', array( self::class, 'flag' ) ),
			self::ALCOHOL     => array( 'string', array( self::class, 'flag' ) ),
			self::BEST        => array( 'integer', 'absint' ),
		);
		foreach ( array( 'product', 'product_variation' ) as $post_type ) {
			foreach ( $specs as $key => $spec ) {
				register_post_meta(
					$post_type,
					$key,
					array(
						'type'              => $spec[0],
						'single'            => true,
						'show_in_rest'      => in_array( $spec[0], array( 'array', 'object' ), true ) ? false : true,
						'sanitize_callback' => $spec[1],
						'auth_callback'     => static fn(): bool => current_user_can( 'edit_products' ),
					)
				);
			}
		}
	}

	/**
	 * Strength in % vol., or 0.
	 *
	 * @param mixed $value Value («14,5 % vol.», 14.5).
	 */
	public static function grade( $value ): float {
		if ( is_string( $value ) && preg_match( '/(\d+(?:[.,]\d+)?)/', $value, $match ) ) {
			$value = str_replace( ',', '.', $match[1] );
		}
		$grade = is_numeric( $value ) ? round( (float) $value, 2 ) : 0.0;
		return $grade > 0 && $grade < 100 ? $grade : 0.0;
	}

	/**
	 * Strength as stored: text («14.5», empty when unknown). A float would loop with
	 * WooCommerce, which turns floats of unregistered meta into text and saves them again.
	 *
	 * @param mixed $value Value.
	 */
	public static function grade_meta( $value ): string {
		$grade = self::grade( $value );
		return $grade > 0 ? wc_float_to_string( $grade ) : '';
	}

	/**
	 * A line of text.
	 *
	 * @param mixed $value Value.
	 */
	public static function line( $value ): string {
		return trim( sanitize_text_field( is_scalar( $value ) ? (string) $value : '' ) );
	}

	/**
	 * A paragraph (line breaks kept).
	 *
	 * @param mixed $value Value.
	 */
	public static function text( $value ): string {
		return trim( sanitize_textarea_field( is_scalar( $value ) ? (string) $value : '' ) );
	}

	/**
	 * Viticulture values that exist.
	 *
	 * @param mixed $value Value.
	 * @return string[]
	 */
	public static function viticulture( $value ): array {
		$value = is_array( $value ) ? $value : array_filter( array( $value ) );
		return array_values( array_intersect( self::VITICULTURES, array_map( static fn( $item ): string => sanitize_key( (string) $item ), $value ) ) );
	}

	/**
	 * Serving temperature `[from, to]` in ºC (to ≥ from), or empty.
	 *
	 * @param mixed $value Value.
	 * @return int[]
	 */
	public static function temperature( $value ): array {
		$value = is_array( $value ) ? array_values( $value ) : array();
		$from  = isset( $value[0] ) && is_numeric( $value[0] ) ? (int) round( (float) $value[0] ) : 0;
		$to    = isset( $value[1] ) && is_numeric( $value[1] ) ? (int) round( (float) $value[1] ) : $from;
		if ( $from <= 0 || $from > 30 ) {
			return array();
		}
		return array( $from, max( $from, min( 30, $to ) ) );
	}

	/**
	 * Tasting notes: sight, nose and mouth.
	 *
	 * @param mixed $value Value.
	 * @return array{sight: string, nose: string, mouth: string}
	 */
	public static function tasting( $value ): array {
		$value = is_array( $value ) ? $value : array();
		return array(
			'sight' => self::text( $value['sight'] ?? '' ),
			'nose'  => self::text( $value['nose'] ?? '' ),
			'mouth' => self::text( $value['mouth'] ?? '' ),
		);
	}

	/**
	 * Profile: four scales from 1 to 5; the ones not filled are left out.
	 *
	 * @param mixed $value Value.
	 * @return array<string, int>
	 */
	public static function profile( $value ): array {
		$value   = is_array( $value ) ? $value : array();
		$profile = array();
		foreach ( self::PROFILE_KEYS as $key ) {
			$level = isset( $value[ $key ] ) && is_numeric( $value[ $key ] ) ? (int) $value[ $key ] : 0;
			if ( $level >= 1 && $level <= 5 ) {
				$profile[ $key ] = $level;
			}
		}
		return $profile;
	}

	/**
	 * Grapes with their % (null when it is not known), in order; a grape once.
	 *
	 * @param mixed $value Value.
	 * @return array<int, array{term: int, pct: int|null}>
	 */
	public static function grapes( $value ): array {
		$grapes = array();
		$seen   = array();
		foreach ( is_array( $value ) ? $value : array() as $row ) {
			$term = is_array( $row ) ? absint( $row['term'] ?? 0 ) : absint( $row );
			if ( ! $term || isset( $seen[ $term ] ) ) {
				continue;
			}
			$seen[ $term ] = true;
			$pct           = is_array( $row ) && isset( $row['pct'] ) && is_numeric( $row['pct'] ) ? (int) round( (float) $row['pct'] ) : null;
			$grapes[]      = array(
				'term' => $term,
				'pct'  => null !== $pct && $pct > 0 && $pct <= 100 ? $pct : null,
			);
		}
		return $grapes;
	}

	/**
	 * Scores and awards. A score has `source` (critic) and `points`; an award, `source`
	 * (contest), `medal` and the year of the contest. Both carry their `vintage` (the slug
	 * of the vintage term, or empty while it is not known) and whether they are published.
	 * A critic or contest appears once per vintage: a repeated one is left out.
	 *
	 * @param mixed $value Value.
	 * @return array<int, array{id: string, kind: string, source: string, points: int, medal: string, vintage: string, year: int, published: bool, note: string}>
	 */
	public static function scores( $value ): array {
		$scores  = array();
		$ids     = array();
		$sources = array();
		foreach ( is_array( $value ) ? $value : array() as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$kind   = 'award' === ( $row['kind'] ?? '' ) ? 'award' : 'score';
			$source = self::line( $row['source'] ?? '' );
			$points = isset( $row['points'] ) && is_numeric( $row['points'] ) ? (int) round( (float) $row['points'] ) : 0;
			$medal  = self::line( $row['medal'] ?? '' );
			if ( '' === $source || ( 'score' === $kind && ( $points < 1 || $points > 100 ) ) || ( 'award' === $kind && '' === $medal ) ) {
				continue;
			}
			// A critic or contest once per vintage (the first one stays).
			$vintage = sanitize_title( (string) ( $row['vintage'] ?? '' ) );
			$known   = Config::source( $source );
			$once    = $kind . '|' . Config::key( null !== $known ? $known['name'] : $source ) . '|' . $vintage;
			if ( '' !== $vintage && isset( $sources[ $once ] ) ) {
				continue;
			}
			$sources[ $once ] = true;
			$id               = sanitize_key( (string) ( $row['id'] ?? '' ) );
			if ( '' === $id || isset( $ids[ $id ] ) ) {
				$id = substr( md5( $kind . $source . $points . $medal . ( $row['vintage'] ?? '' ) . count( $scores ) ), 0, 10 );
			}
			$ids[ $id ] = true;
			$year       = isset( $row['year'] ) && is_numeric( $row['year'] ) ? (int) $row['year'] : 0;
			$scores[]   = array(
				'id'        => $id,
				'kind'      => $kind,
				'source'    => $source,
				'points'    => 'score' === $kind ? $points : 0,
				'medal'     => 'award' === $kind ? $medal : '',
				'vintage'   => $vintage,
				'year'      => $year >= 1900 && $year <= 2100 ? $year : 0,
				'published' => ! empty( $row['published'] ),
				'note'      => self::line( $row['note'] ?? '' ),
			);
		}
		return $scores;
	}

	/**
	 * Pairing products: ids, at most three, without repeating.
	 *
	 * @param mixed $value Value.
	 * @return int[]
	 */
	public static function pairing( $value ): array {
		$ids = array_values( array_unique( array_filter( array_map( 'absint', is_array( $value ) ? $value : array() ) ) ) );
		return array_slice( $ids, 0, self::MAX_PAIRING );
	}

	/**
	 * A yes/no flag that may be left at its default: `yes`, `no` or empty.
	 *
	 * @param mixed $value Value.
	 */
	public static function flag( $value ): string {
		if ( true === $value || 'yes' === $value || '1' === $value || 1 === $value ) {
			return 'yes';
		}
		if ( false === $value || 'no' === $value || '0' === $value || 0 === $value ) {
			return 'no';
		}
		return '';
	}

	/**
	 * Label information: ingredients and nutrition (text) or the address of the electronic
	 * label, sulfites and other allergens.
	 *
	 * @param mixed $value Value.
	 * @return array{ingredients: string, nutrition: string, url: string, sulfites: bool, allergens: string}
	 */
	public static function label( $value ): array {
		$value = is_array( $value ) ? $value : array();
		return array(
			'ingredients' => self::text( $value['ingredients'] ?? '' ),
			'nutrition'   => self::text( $value['nutrition'] ?? '' ),
			'url'         => esc_url_raw( (string) ( $value['url'] ?? '' ) ),
			'sulfites'    => ! empty( $value['sulfites'] ),
			'allergens'   => self::line( $value['allergens'] ?? '' ),
		);
	}

	/**
	 * Stored value of a field.
	 *
	 * @param int    $post_id Product or variation.
	 * @param string $key     Meta key.
	 * @return mixed
	 */
	public static function get( int $post_id, string $key ) {
		return get_post_meta( $post_id, $key, true );
	}

	/**
	 * Whether a product is a wine: it has a wine type.
	 *
	 * @param \WC_Product $product Product or variation.
	 */
	public static function is_wine( \WC_Product $product ): bool {
		return null !== self::type( $product );
	}

	/**
	 * The parent product of a variation, or the product itself.
	 *
	 * @param \WC_Product $product Product or variation.
	 */
	public static function parent( \WC_Product $product ): \WC_Product {
		if ( $product->is_type( 'variation' ) ) {
			$parent = wc_get_product( $product->get_parent_id() );
			if ( $parent instanceof \WC_Product ) {
				return $parent;
			}
		}
		return $product;
	}

	/**
	 * First term of a taxonomy of the wine.
	 *
	 * @param \WC_Product $product  Product or variation.
	 * @param string      $taxonomy Taxonomy.
	 */
	public static function term( \WC_Product $product, string $taxonomy ): ?\WP_Term {
		$terms = self::terms( $product, $taxonomy );
		return $terms[0] ?? null;
	}

	/**
	 * Terms of a taxonomy of the wine.
	 *
	 * @param \WC_Product $product  Product or variation.
	 * @param string      $taxonomy Taxonomy.
	 * @return \WP_Term[]
	 */
	public static function terms( \WC_Product $product, string $taxonomy ): array {
		if ( ! taxonomy_exists( $taxonomy ) ) {
			return array();
		}
		$terms = get_the_terms( self::parent( $product )->get_id(), $taxonomy );
		return is_array( $terms ) ? array_values( $terms ) : array();
	}

	/**
	 * The wine type.
	 *
	 * @param \WC_Product $product Product or variation.
	 */
	public static function type( \WC_Product $product ): ?\WP_Term {
		return self::term( $product, Taxonomies::TYPE );
	}

	/**
	 * Origin: the deepest term (the D.O.).
	 *
	 * @param \WC_Product $product Product or variation.
	 */
	public static function origin( \WC_Product $product ): ?\WP_Term {
		$deepest = null;
		$depth   = -1;
		foreach ( self::terms( $product, Taxonomies::ORIGIN ) as $term ) {
			$level = count( get_ancestors( $term->term_id, Taxonomies::ORIGIN, 'taxonomy' ) );
			if ( $level > $depth ) {
				$deepest = $term;
				$depth   = $level;
			}
		}
		return $deepest;
	}

	/**
	 * Strength: the variation's when it has its own, else the product's. 0 when unknown.
	 *
	 * @param \WC_Product $product Product or variation.
	 */
	public static function grade_of( \WC_Product $product ): float {
		$own = $product->is_type( 'variation' ) ? self::grade( self::get( $product->get_id(), self::GRADE ) ) : 0.0;
		return $own > 0 ? $own : self::grade( self::get( self::parent( $product )->get_id(), self::GRADE ) );
	}

	/**
	 * Ageing: the variation's when it has its own, else the product's.
	 *
	 * @param \WC_Product $product Product or variation.
	 */
	public static function ageing_of( \WC_Product $product ): string {
		$own = $product->is_type( 'variation' ) ? self::line( self::get( $product->get_id(), self::AGEING ) ) : '';
		return '' !== $own ? $own : self::line( self::get( self::parent( $product )->get_id(), self::AGEING ) );
	}

	/**
	 * Vintage of a variation (or of a product with a single vintage): `slug` and `name` of
	 * the term of the vintage attribute, or null.
	 *
	 * @param \WC_Product $product Product or variation.
	 * @return array{slug: string, name: string}|null
	 */
	public static function vintage_of( \WC_Product $product ): ?array {
		$taxonomy = Config::vintage_attribute();
		if ( '' === $taxonomy ) {
			return null;
		}
		if ( $product instanceof \WC_Product_Variation ) {
			$slug = (string) ( $product->get_variation_attributes()[ 'attribute_' . $taxonomy ] ?? '' );
			if ( '' === $slug ) {
				return null;
			}
			$term = get_term_by( 'slug', $slug, $taxonomy );
			return array(
				'slug' => $slug,
				'name' => $term instanceof \WP_Term ? Terms::name( $term ) : $slug,
			);
		}
		$vintages = self::vintages( $product );
		return 1 === count( $vintages ) ? $vintages[0] : null;
	}

	/**
	 * Vintages of a wine (the terms of the vintage attribute it uses), newest first.
	 *
	 * @param \WC_Product $product Product or variation.
	 * @return array<int, array{slug: string, name: string}>
	 */
	public static function vintages( \WC_Product $product ): array {
		$taxonomy = Config::vintage_attribute();
		if ( '' === $taxonomy ) {
			return array();
		}
		$terms    = wc_get_product_terms( self::parent( $product )->get_id(), $taxonomy, array( 'fields' => 'all' ) );
		$vintages = array();
		foreach ( $terms as $term ) {
			if ( $term instanceof \WP_Term ) {
				$vintages[] = array(
					'slug' => $term->slug,
					'name' => Terms::name( $term ),
				);
			}
		}
		usort( $vintages, static fn( array $a, array $b ): int => strcmp( $b['name'], $a['name'] ) );
		return $vintages;
	}

	/**
	 * Format of a variation: the name of its format term, or empty.
	 *
	 * @param \WC_Product $product Product or variation.
	 */
	public static function format_of( \WC_Product $product ): string {
		$taxonomy = Config::format_attribute();
		if ( '' === $taxonomy ) {
			return '';
		}
		if ( $product instanceof \WC_Product_Variation ) {
			$slug = (string) ( $product->get_variation_attributes()[ 'attribute_' . $taxonomy ] ?? '' );
			$term = '' !== $slug ? get_term_by( 'slug', $slug, $taxonomy ) : false;
			return $term instanceof \WP_Term ? Terms::name( $term ) : $slug;
		}
		$names = wc_get_product_terms( $product->get_id(), $taxonomy, array( 'fields' => 'names' ) );
		return 1 === count( $names ) ? (string) $names[0] : '';
	}

	/**
	 * Whether the product is in the Bodega category (or one of its subcategories).
	 *
	 * @param \WC_Product $product Product or variation.
	 */
	public static function in_bodega( \WC_Product $product ): bool {
		return self::in_category( $product, Config::category() );
	}

	/**
	 * Whether the product is in a category or below it.
	 *
	 * @param \WC_Product   $product  Product or variation.
	 * @param \WP_Term|null $category Category.
	 */
	public static function in_category( \WC_Product $product, ?\WP_Term $category ): bool {
		if ( null === $category ) {
			return false;
		}
		foreach ( self::parent( $product )->get_category_ids() as $id ) {
			if ( (int) $id === $category->term_id || in_array( $category->term_id, get_ancestors( (int) $id, 'product_cat', 'taxonomy' ), true ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Whether the product contains alcohol: its own answer or, by default, yes in the whole
	 * Bodega but the accessories, and in any wine.
	 *
	 * @param \WC_Product $product Product or variation.
	 */
	public static function has_alcohol( \WC_Product $product ): bool {
		$parent = self::parent( $product );
		$flag   = self::flag( self::get( $parent->get_id(), self::ALCOHOL ) );
		if ( '' !== $flag ) {
			return 'yes' === $flag;
		}
		if ( self::is_wine( $parent ) ) {
			return true;
		}
		return self::in_bodega( $parent ) && ! self::in_category( $parent, Config::accessories() );
	}

	/**
	 * Default of «Contiene alcohol» for a product, for the editor.
	 *
	 * @param \WC_Product $product Product.
	 */
	public static function default_alcohol( \WC_Product $product ): bool {
		return self::is_wine( $product ) || ( self::in_bodega( $product ) && ! self::in_category( $product, Config::accessories() ) );
	}

	/**
	 * Whether a bottle counts for the case: the variation's answer, the product's, or by
	 * default yes in wines of 75 cl (no in magnums, half bottles, accessories and what is
	 * not wine).
	 *
	 * @param \WC_Product $product Product or variation.
	 */
	public static function counts_for_case( \WC_Product $product ): bool {
		if ( $product->is_type( 'variation' ) ) {
			$own = self::flag( self::get( $product->get_id(), self::CASE_FLAG ) );
			if ( '' !== $own ) {
				return 'yes' === $own;
			}
		}
		$parent = self::parent( $product );
		if ( ! self::is_wine( $parent ) ) {
			return 'yes' === self::flag( self::get( $parent->get_id(), self::CASE_FLAG ) );
		}
		if ( 'no' === self::flag( self::get( $parent->get_id(), self::CASE_FLAG ) ) ) {
			return false;
		}
		return self::is_standard_bottle( $product );
	}

	/**
	 * Default of «Cuenta para la caja» for a product, for the editor.
	 *
	 * @param \WC_Product $product Product.
	 */
	public static function default_case( \WC_Product $product ): bool {
		return self::is_wine( $product ) && self::is_standard_bottle( $product );
	}

	/**
	 * Whether the bottle is of 75 cl: by its content (`catalog`) or, without it, by its
	 * format. Unknown counts as yes, the usual bottle.
	 *
	 * @param \WC_Product $product Product or variation.
	 */
	public static function is_standard_bottle( \WC_Product $product ): bool {
		$service = Services::product_content();
		$content = null !== $service ? $service->content( $product ) : null;
		if ( null !== $content ) {
			$ml = self::millilitres( $content['amount'], $content['unit'] );
			if ( null !== $ml ) {
				return abs( $ml - 750.0 ) < 1.0;
			}
		}
		$format = self::format_of( $product );
		if ( '' === $format ) {
			return true;
		}
		$ml = self::millilitres_of_text( $format );
		return null === $ml ? ! preg_match( '/m[aá]gnum|jeroboam|benjam[ií]n|media/iu', $format ) : abs( $ml - 750.0 ) < 1.0;
	}

	/**
	 * Millilitres of an amount, or null when the unit is not a volume.
	 *
	 * @param float  $amount Amount.
	 * @param string $unit   Unit.
	 */
	public static function millilitres( float $amount, string $unit ): ?float {
		switch ( strtolower( $unit ) ) {
			case 'ml':
				return $amount;
			case 'cl':
				return $amount * 10;
			case 'l':
				return $amount * 1000;
			default:
				return null;
		}
	}

	/**
	 * Millilitres written in a text («75 cl», «1,5 l», «750 ml»), or null.
	 *
	 * @param string $text Text.
	 */
	public static function millilitres_of_text( string $text ): ?float {
		if ( ! preg_match( '/(\d+(?:[.,]\d+)?)\s*(ml|cl|l)\b/i', $text, $match ) ) {
			return null;
		}
		return self::millilitres( (float) str_replace( ',', '.', $match[1] ), $match[2] );
	}

	/**
	 * Whether pairing products are suggested by dish for this wine (when it has none).
	 *
	 * @param \WC_Product $product Product.
	 */
	public static function suggests( \WC_Product $product ): bool {
		return Config::suggest_pairing() && 'no' !== self::flag( self::get( self::parent( $product )->get_id(), self::SUGGEST ) );
	}

	/**
	 * What a wine card is missing, by the editor's tab: the twelve checks of «Completa 9 de
	 * 12». The same criterion serves the product list and the module's health.
	 *
	 * @param \WC_Product $product Product.
	 * @return array{done: int, total: int, missing: array<string, string>}
	 */
	public static function completeness( \WC_Product $product ): array {
		$id      = $product->get_id();
		$tasting = self::tasting( self::get( $id, self::TASTING ) );
		$label   = self::label( self::get( $id, self::LABEL ) );
		$checks  = array(
			'winery'      => array( 'ficha', __( 'bodega', 'lachinata-core' ), null !== self::term( $product, Taxonomies::WINERY ) ),
			'origin'      => array( 'ficha', __( 'origen', 'lachinata-core' ), null !== self::origin( $product ) ),
			'type'        => array( 'ficha', __( 'tipo', 'lachinata-core' ), null !== self::type( $product ) ),
			'making'      => array( 'ficha', __( 'elaboración', 'lachinata-core' ), null !== self::term( $product, Taxonomies::MAKING ) ),
			'grapes'      => array( 'ficha', __( 'uvas', 'lachinata-core' ), (bool) self::grapes( self::get( $id, self::GRAPES ) ) ),
			'grade'       => array( 'ficha', __( 'grado', 'lachinata-core' ), self::grade( self::get( $id, self::GRADE ) ) > 0 ),
			'ageing'      => array( 'ficha', __( 'crianza', 'lachinata-core' ), '' !== self::line( self::get( $id, self::AGEING ) ) ),
			'temperature' => array( 'ficha', __( 'temperatura', 'lachinata-core' ), (bool) self::temperature( self::get( $id, self::TEMPERATURE ) ) ),
			'tasting'     => array( 'cata', __( 'cata', 'lachinata-core' ), '' !== $tasting['sight'] && '' !== $tasting['nose'] && '' !== $tasting['mouth'] ),
			'vintage'     => array( 'anadas', __( 'añada', 'lachinata-core' ), (bool) self::vintages( $product ) ),
			'pairing'     => array( 'maridaje', __( 'maridaje', 'lachinata-core' ), self::terms( $product, Taxonomies::DISH ) || self::pairing( self::get( $id, self::PAIRING ) ) ),
			'label'       => array( 'etiqueta', __( 'ingredientes', 'lachinata-core' ), '' !== $label['ingredients'] || '' !== $label['url'] ),
		);
		$missing = array();
		foreach ( $checks as $key => $check ) {
			if ( ! $check[2] ) {
				$missing[ $key ] = $check[1];
			}
		}
		return array(
			'done'    => count( $checks ) - count( $missing ),
			'total'   => count( $checks ),
			'missing' => $missing,
		);
	}

	/**
	 * Tab of the editor where each check of completeness() is filled.
	 *
	 * @return array<string, string>
	 */
	public static function check_tabs(): array {
		return array(
			'winery'      => 'ficha',
			'origin'      => 'ficha',
			'type'        => 'ficha',
			'making'      => 'ficha',
			'grapes'      => 'ficha',
			'grade'       => 'ficha',
			'ageing'      => 'ficha',
			'temperature' => 'ficha',
			'tasting'     => 'cata',
			'vintage'     => 'anadas',
			'pairing'     => 'maridaje',
			'label'       => 'etiqueta',
		);
	}

	/**
	 * Declares for `translate` the texts of the wine: tasting notes and ageing; the names
	 * of types, makings and dishes, and the texts of wineries and origins. The names of
	 * wines, wineries, D.O. and grapes are not translated (glossary «no traducir»).
	 *
	 * @param mixed $fields Fields of other modules.
	 * @return mixed
	 */
	public static function translatable( $fields ) {
		if ( ! is_array( $fields ) ) {
			return $fields;
		}
		$fields['post:product']['bodega_tasting'] = array(
			'label'  => __( 'Cata', 'lachinata-core' ),
			'source' => 'meta',
			'key'    => self::TASTING,
			'format' => 'json',
		);
		$fields['post:product']['bodega_ageing']  = array(
			'label'  => __( 'Crianza', 'lachinata-core' ),
			'source' => 'meta',
			'key'    => self::AGEING,
		);
		foreach ( array( Taxonomies::TYPE, Taxonomies::MAKING, Taxonomies::DISH ) as $taxonomy ) {
			$fields[ 'term:' . $taxonomy ] = array(
				'name' => array(
					'label'  => __( 'Nombre', 'lachinata-core' ),
					'source' => 'term',
					'key'    => 'name',
				),
			);
		}
		foreach ( array( Taxonomies::WINERY, Taxonomies::ORIGIN ) as $taxonomy ) {
			$fields[ 'term:' . $taxonomy ] = array(
				'description' => array(
					'label'  => __( 'Texto', 'lachinata-core' ),
					'source' => 'term',
					'key'    => 'description',
					'format' => 'html',
				),
			);
		}
		return $fields;
	}
}
