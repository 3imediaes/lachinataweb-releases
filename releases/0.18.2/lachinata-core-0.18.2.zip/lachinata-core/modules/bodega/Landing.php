<?php
/**
 * Type and origin pages of the Bodega.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

use LaChinata\Core\Hooks;
use LaChinata\Core\Terms;

defined( 'ABSPATH' ) || exit;

/**
 * The indexable pages of the Bodega hang from its category (decided by Alberto, 30/10):
 * «…/gourmet-bodega-vino/tintos/» (a type) and «…/gourmet-bodega-vino/extremadura/» (an
 * origin, with its children). They are the category listing filtered by that term, with
 * its own title and the origin's text. Indexable only with `landing_min` wines or more
 * (3 by default); the combinations of filters, never. A segment that is a subcategory of
 * the Bodega stays a subcategory.
 */
final class Landing {

	/**
	 * Query variable and option with the path the rules were written for.
	 */
	public const QUERY_VAR = 'lc_bodega_landing';
	public const OPTION    = 'lachinata_bodega_rewrite';

	/**
	 * Term of the current page, once resolved.
	 *
	 * @var \WP_Term|null|false False while not resolved.
	 */
	private static $current = false;

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'init', array( self::class, 'rules' ), 30 );
		Hooks::add_filter( 'query_vars', array( self::class, 'query_vars' ) );
		Hooks::add_filter( 'request', array( self::class, 'request' ) );
		Hooks::add_action( 'woocommerce_product_query', array( self::class, 'query' ), 5 );
		Hooks::add_filter( 'lachinata/robots/noindex', array( self::class, 'noindex' ) );
		Hooks::add_filter( 'rank_math/frontend/canonical', array( self::class, 'canonical' ) );
	}

	/**
	 * Path of the Bodega category from the site's root, without slashes, or empty.
	 */
	public static function path(): string {
		$category = Config::category();
		if ( null === $category ) {
			return '';
		}
		$link = get_term_link( $category );
		if ( ! is_string( $link ) ) {
			return '';
		}
		$home = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		$path = (string) wp_parse_url( $link, PHP_URL_PATH );
		if ( '' !== $home && '/' !== $home && str_starts_with( $path, $home ) ) {
			$path = substr( $path, strlen( $home ) );
		}
		return trim( $path, '/' );
	}

	/**
	 * Rewrite rules for «{category}/{term}/» and its pages; written again when the path
	 * changes.
	 */
	public static function rules(): void {
		$path     = self::path();
		$category = Config::category();
		if ( '' === $path || null === $category || str_contains( $path, '?' ) ) {
			return;
		}
		$base = '^' . preg_quote( $path, '#' ) . '/([^/]+)';
		add_rewrite_rule( $base . '/page/?([0-9]{1,})/?$', 'index.php?product_cat=' . $category->slug . '&' . self::QUERY_VAR . '=$matches[1]&paged=$matches[2]', 'top' );
		add_rewrite_rule( $base . '/?$', 'index.php?product_cat=' . $category->slug . '&' . self::QUERY_VAR . '=$matches[1]', 'top' );
		if ( get_option( self::OPTION ) !== $path ) {
			update_option( self::OPTION, $path, false );
			flush_rewrite_rules( false );
		}
	}

	/**
	 * The query variable.
	 *
	 * @param mixed $vars Public query variables.
	 * @return mixed
	 */
	public static function query_vars( $vars ) {
		if ( is_array( $vars ) ) {
			$vars[] = self::QUERY_VAR;
		}
		return $vars;
	}

	/**
	 * A segment that is a subcategory stays a subcategory; one that is neither a type nor an
	 * origin is the subcategory WooCommerce does not find (404).
	 *
	 * @param mixed $vars Query variables.
	 * @return mixed
	 */
	public static function request( $vars ) {
		if ( ! is_array( $vars ) || empty( $vars[ self::QUERY_VAR ] ) ) {
			return $vars;
		}
		$slug = sanitize_title( (string) $vars[ self::QUERY_VAR ] );
		if ( null !== self::term_by_slug( $slug ) ) {
			return $vars;
		}
		unset( $vars[ self::QUERY_VAR ] );
		$vars['product_cat'] = $slug;
		return $vars;
	}

	/**
	 * A type or origin term by its slug (the type first).
	 *
	 * @param string $slug Slug.
	 */
	public static function term_by_slug( string $slug ): ?\WP_Term {
		$category = Config::category();
		if ( '' === $slug || null === $category ) {
			return null;
		}
		$child = get_term_by( 'slug', $slug, 'product_cat' );
		if ( $child instanceof \WP_Term && term_is_ancestor_of( $category, $child, 'product_cat' ) ) {
			return null;
		}
		foreach ( array( Taxonomies::TYPE, Taxonomies::ORIGIN ) as $taxonomy ) {
			$term = get_term_by( 'slug', $slug, $taxonomy );
			if ( $term instanceof \WP_Term ) {
				return $term;
			}
		}
		return null;
	}

	/**
	 * The type or origin of the current page, or null.
	 */
	public static function current(): ?\WP_Term {
		if ( false === self::$current ) {
			$slug          = sanitize_title( (string) get_query_var( self::QUERY_VAR ) );
			self::$current = '' !== $slug ? self::term_by_slug( $slug ) : null;
		}
		return self::$current;
	}

	/**
	 * Forgets the resolved term (tests).
	 */
	public static function reset(): void {
		self::$current = false;
	}

	/**
	 * The listing of a landing: the category filtered by its term.
	 *
	 * @param mixed $query Query.
	 */
	public static function query( $query ): void {
		if ( ! $query instanceof \WP_Query || ! $query->is_main_query() ) {
			return;
		}
		$term = self::current();
		if ( null === $term ) {
			return;
		}
		$tax_query   = (array) $query->get( 'tax_query' );
		$tax_query[] = array(
			'taxonomy'         => $term->taxonomy,
			'terms'            => array( $term->term_id ),
			'include_children' => Taxonomies::ORIGIN === $term->taxonomy,
		);
		$query->set( 'tax_query', $tax_query ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
	}

	/**
	 * Address of the page of a type or origin.
	 *
	 * @param string $slug Slug of the term.
	 */
	public static function url_for( string $slug ): string {
		return trailingslashit( Listing::url() ) . rawurlencode( $slug ) . '/';
	}

	/**
	 * Title of a landing: «Vinos tintos», «Vinos de Extremadura».
	 *
	 * @param \WP_Term $term Type or origin.
	 */
	public static function title( \WP_Term $term ): string {
		if ( Taxonomies::TYPE === $term->taxonomy ) {
			$plural = Listing::plural( $term );
			/* translators: %s: wine type in plural and lowercase («tintos»). */
			return sprintf( __( 'Vinos %s', 'lachinata-core' ), function_exists( 'mb_strtolower' ) ? mb_strtolower( $plural ) : strtolower( $plural ) );
		}
		/* translators: %s: origin («Extremadura»). */
		return sprintf( __( 'Vinos de %s', 'lachinata-core' ), Terms::name( $term ) );
	}

	/**
	 * Published wines of the Bodega with a type or origin (with its children).
	 *
	 * @param \WP_Term $term Type or origin.
	 */
	public static function count( \WP_Term $term ): int {
		$category = Config::category();
		if ( null === $category ) {
			return 0;
		}
		$key   = 'lachinata_bodega_landing_' . $term->term_id . '_' . \WC_Cache_Helper::get_transient_version( 'product' );
		$count = get_transient( $key );
		if ( false === $count ) {
			$ids   = get_posts(
				array(
					'post_type'      => 'product',
					'post_status'    => 'publish',
					'posts_per_page' => -1,
					'fields'         => 'ids',
					'no_found_rows'  => true,
					'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
						array(
							'taxonomy' => 'product_cat',
							'terms'    => array( $category->term_id ),
						),
						array(
							'taxonomy'         => $term->taxonomy,
							'terms'            => array( $term->term_id ),
							'include_children' => Taxonomies::ORIGIN === $term->taxonomy,
						),
					),
				)
			);
			$count = count( $ids );
			set_transient( $key, $count, DAY_IN_SECONDS );
		}
		return (int) $count;
	}

	/**
	 * Whether the current page of the Bodega may be indexed: its main listing or a landing
	 * with enough wines, without filters.
	 */
	public static function indexable(): bool {
		if ( Listing::filtered() ) {
			return false;
		}
		$term = self::current();
		return null === $term || self::count( $term ) >= Config::landing_min();
	}

	/**
	 * «noindex» for filtered listings and thin landings.
	 *
	 * @param mixed $noindex Whether not to index.
	 * @return mixed
	 */
	public static function noindex( $noindex ) {
		if ( $noindex || ! Listing::in_context() ) {
			return $noindex;
		}
		return ! self::indexable();
	}

	/**
	 * The canonical of a landing is its own address.
	 *
	 * @param mixed $canonical Canonical.
	 * @return mixed
	 */
	public static function canonical( $canonical ) {
		$term = Listing::in_context() ? self::current() : null;
		if ( null === $term ) {
			return $canonical;
		}
		$page = max( 1, (int) get_query_var( 'paged' ) );
		$url  = self::url_for( $term->slug );
		return $page > 1 ? $url . 'page/' . $page . '/' : $url;
	}
}
