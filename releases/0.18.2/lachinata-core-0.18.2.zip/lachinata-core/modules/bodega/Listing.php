<?php
/**
 * The Bodega listing.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

use LaChinata\Core\Hooks;
use LaChinata\Core\Terms;

defined( 'ABSPATH' ) || exit;

/**
 * 10-bodega.md, «Listado de la Bodega»: in the Bodega category (and its type and origin
 * pages), the header with its text, the type chips and the entries; the filters type,
 * origin, grape, price (the theme's), 90 points or more, organic, «para maridar con» and
 * winery, only with the values that have wines; and the order «Mejor puntuados». The
 * filters are a GET form (the theme's) and work without JavaScript.
 */
final class Listing {

	/**
	 * Parameters of the filters.
	 */
	public const PARAMS = array(
		'vino_tipo'       => Taxonomies::TYPE,
		'vino_origen'     => Taxonomies::ORIGIN,
		'vino_uva'        => Taxonomies::GRAPE,
		'vino_maridaje'   => Taxonomies::DISH,
		'vino_bodega'     => Taxonomies::WINERY,
		'vino_puntuacion' => '',
		'vino_eco'        => '',
	);

	/**
	 * Sort option.
	 */
	public const ORDERBY = 'puntuacion';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/catalog/filters', array( self::class, 'filters' ) );
		Hooks::add_filter( 'lachinata/category/header', array( self::class, 'header' ), 10, 2 );
		Hooks::add_filter( 'woocommerce_catalog_orderby', array( self::class, 'orderby_options' ) );
		Hooks::add_filter( 'woocommerce_get_catalog_ordering_args', array( self::class, 'ordering_args' ), 10, 2 );
		Hooks::add_action( 'woocommerce_product_query', array( self::class, 'query' ) );
	}

	/**
	 * Address of the Bodega listing (the shop when the category is not chosen).
	 */
	public static function url(): string {
		$category = Config::category();
		$link     = $category ? get_term_link( $category ) : '';
		return is_string( $link ) && '' !== $link ? $link : (string) get_permalink( wc_get_page_id( 'shop' ) );
	}

	/**
	 * The listing filtered by one value: «?vino_bodega=artuke».
	 *
	 * @param string $param Parameter.
	 * @param string $value Value.
	 */
	public static function filter_url( string $param, string $value ): string {
		return add_query_arg( $param, rawurlencode( $value ), self::url() );
	}

	/**
	 * Whether the page is the Bodega listing or one of its subcategories or landings.
	 */
	public static function in_context(): bool {
		$category = Config::category();
		if ( null === $category || ! function_exists( 'is_product_category' ) || ! is_product_category() ) {
			return false;
		}
		$term = get_queried_object();
		return $term instanceof \WP_Term && ( $term->term_id === $category->term_id || term_is_ancestor_of( $category, $term, 'product_cat' ) );
	}

	/**
	 * Values asked for a parameter: `a,b` or `a[]`.
	 *
	 * @param string $param Parameter.
	 * @return string[]
	 */
	public static function chosen( string $param ): array {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Read-only catalog filters, each value sanitised below.
		$raw    = isset( $_GET[ $param ] ) ? wp_unslash( $_GET[ $param ] ) : array();
		$values = is_array( $raw ) ? $raw : explode( ',', (string) $raw );
		return array_values( array_unique( array_filter( array_map( static fn( $value ): string => sanitize_title( (string) $value ), $values ) ) ) );
	}

	/**
	 * Whether any filter of the module is applied.
	 */
	public static function filtered(): bool {
		foreach ( array_keys( self::PARAMS ) as $param ) {
			if ( self::chosen( $param ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * The module's filters in the Bodega, in the order of the specification, and without the
	 * vintage and format attributes.
	 *
	 * @param mixed $filters Filters of the theme (attributes).
	 * @return mixed
	 */
	public static function filters( $filters ) {
		if ( ! is_array( $filters ) || ! self::in_context() ) {
			return $filters;
		}
		$skip    = array_filter( array( Config::vintage_attribute(), Config::format_attribute() ) );
		$filters = array_values( array_filter( $filters, static fn( $filter ): bool => ! in_array( (string) ( $filter['taxonomy'] ?? '' ), $skip, true ) ) );
		$found   = self::terms_with_wines();
		$own     = array();
		$labels  = array(
			'vino_tipo'     => __( 'Tipo', 'lachinata-core' ),
			'vino_origen'   => __( 'Origen', 'lachinata-core' ),
			'vino_uva'      => __( 'Uva', 'lachinata-core' ),
			'vino_maridaje' => __( 'Para maridar con', 'lachinata-core' ),
			'vino_bodega'   => __( 'Bodega', 'lachinata-core' ),
		);
		foreach ( array( 'vino_tipo', 'vino_origen', 'vino_uva' ) as $param ) {
			$own[] = self::filter( $param, $labels[ $param ], $found[ self::PARAMS[ $param ] ] ?? array() );
		}
		if ( $found['score'] ) {
			$own[] = self::filter(
				'vino_puntuacion',
				__( 'Puntuación', 'lachinata-core' ),
				array(
					self::pseudo_term(
						(string) Config::min_points(),
						/* translators: %s: points («90»). */
						sprintf( __( '%s puntos o más', 'lachinata-core' ), number_format_i18n( Config::min_points() ) )
					),
				)
			);
		}
		if ( $found['eco'] ) {
			$own[] = self::filter( 'vino_eco', __( 'Viticultura', 'lachinata-core' ), array( self::pseudo_term( 'ecologica', __( 'Ecológica', 'lachinata-core' ) ) ) );
		}
		foreach ( array( 'vino_maridaje', 'vino_bodega' ) as $param ) {
			$own[] = self::filter( $param, $labels[ $param ], $found[ self::PARAMS[ $param ] ] ?? array() );
		}
		return array_merge( array_values( array_filter( $own, static fn( array $filter ): bool => (bool) $filter['terms'] ) ), $filters );
	}

	/**
	 * A filter in the theme's shape.
	 *
	 * @param string     $param Parameter.
	 * @param string     $label Label.
	 * @param \WP_Term[] $terms Terms.
	 * @return array{taxonomy: string, param: string, label: string, terms: \WP_Term[], chosen: string[]}
	 */
	private static function filter( string $param, string $label, array $terms ): array {
		return array(
			'taxonomy' => self::PARAMS[ $param ],
			'param'    => $param,
			'label'    => $label,
			'terms'    => $terms,
			'chosen'   => self::chosen( $param ),
		);
	}

	/**
	 * A value that is not a term (90 points, organic) in the shape of one.
	 *
	 * @param string $slug Value.
	 * @param string $name Name.
	 */
	private static function pseudo_term( string $slug, string $name ): \WP_Term {
		return new \WP_Term(
			(object) array(
				'term_id'  => 0,
				'slug'     => $slug,
				'name'     => $name,
				'taxonomy' => '',
			)
		);
	}

	/**
	 * Terms of each taxonomy that the Bodega's wines have, and whether any has a score or
	 * is organic. Cached until the products change.
	 *
	 * @return array<string, mixed>
	 */
	public static function terms_with_wines(): array {
		$category = Config::category();
		$key      = 'lachinata_bodega_filters_' . ( $category ? $category->term_id : 0 ) . '_' . \WC_Cache_Helper::get_transient_version( 'product' );
		$cached   = get_transient( $key );
		if ( is_array( $cached ) ) {
			return self::hydrate( $cached );
		}
		$ids   = $category ? wc_get_products(
			array(
				'status'   => 'publish',
				'limit'    => -1,
				'return'   => 'ids',
				'category' => array( $category->slug ),
			)
		) : array();
		$ids   = is_array( $ids ) ? array_map( 'intval', $ids ) : array();
		$found = array(
			'score' => false,
			'eco'   => false,
		);
		if ( $ids ) {
			foreach ( wp_get_object_terms( $ids, array( Taxonomies::TYPE, Taxonomies::ORIGIN, Taxonomies::GRAPE, Taxonomies::DISH, Taxonomies::WINERY ) ) as $term ) {
				if ( Taxonomies::ORIGIN === $term->taxonomy && 0 === (int) $term->parent && self::single_country() ) {
					continue;
				}
				$found[ $term->taxonomy ][ $term->term_id ] = $term->term_id;
			}
			foreach ( $ids as $id ) {
				if ( (int) get_post_meta( $id, Fields::BEST, true ) >= Config::min_points() ) {
					$found['score'] = true;
				}
				if ( in_array( 'ecologica', Fields::viticulture( get_post_meta( $id, Fields::VITICULTURE, true ) ), true ) ) {
					$found['eco'] = true;
				}
			}
		}
		set_transient( $key, $found, DAY_IN_SECONDS );
		return self::hydrate( $found );
	}

	/**
	 * Term ids to terms, sorted by name.
	 *
	 * @param array<string, mixed> $found Cached data.
	 * @return array<string, mixed>
	 */
	private static function hydrate( array $found ): array {
		foreach ( Taxonomies::all() as $taxonomy ) {
			if ( empty( $found[ $taxonomy ] ) || ! is_array( $found[ $taxonomy ] ) ) {
				continue;
			}
			$terms = get_terms(
				array(
					'taxonomy'   => $taxonomy,
					'include'    => array_map( 'intval', array_values( $found[ $taxonomy ] ) ),
					'hide_empty' => false,
					'orderby'    => Taxonomies::TYPE === $taxonomy ? 'term_order' : 'name',
				)
			);
			// The theme escapes the name: as text, not with the entities WordPress keeps.
			$found[ $taxonomy ] = array_map(
				static function ( \WP_Term $term ): \WP_Term {
					$copy       = clone $term;
					$copy->name = Terms::name( $term );
					return $copy;
				},
				is_array( $terms ) ? array_values( array_filter( $terms, static fn( $term ): bool => $term instanceof \WP_Term ) ) : array()
			);
		}
		return $found;
	}

	/**
	 * Whether every origin hangs from a single country (then the country is not a filter).
	 */
	private static function single_country(): bool {
		$roots = get_terms(
			array(
				'taxonomy'   => Taxonomies::ORIGIN,
				'parent'     => 0,
				'hide_empty' => true,
				'fields'     => 'ids',
			)
		);
		return is_array( $roots ) && count( $roots ) <= 1;
	}

	/**
	 * The query of a product listing with the module's filters.
	 *
	 * @param mixed $query Query.
	 */
	public static function query( $query ): void {
		if ( ! $query instanceof \WP_Query ) {
			return;
		}
		$tax_query  = (array) $query->get( 'tax_query' );
		$meta_query = (array) $query->get( 'meta_query' );
		foreach ( self::PARAMS as $param => $taxonomy ) {
			$values = self::chosen( $param );
			if ( ! $values || '' === $taxonomy ) {
				continue;
			}
			$tax_query[] = array(
				'taxonomy'         => $taxonomy,
				'field'            => 'slug',
				'terms'            => $values,
				'include_children' => Taxonomies::ORIGIN === $taxonomy,
			);
		}
		if ( self::chosen( 'vino_puntuacion' ) ) {
			$meta_query[] = array(
				'key'     => Fields::BEST,
				'value'   => max( 1, (int) self::chosen( 'vino_puntuacion' )[0] ),
				'compare' => '>=',
				'type'    => 'NUMERIC',
			);
		}
		if ( self::chosen( 'vino_eco' ) ) {
			$meta_query[] = array(
				'key'     => Fields::VITICULTURE,
				'value'   => '"ecologica"',
				'compare' => 'LIKE',
			);
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only catalog sort.
		$orderby = isset( $_GET['orderby'] ) ? sanitize_key( wp_unslash( $_GET['orderby'] ) ) : '';
		if ( self::ORDERBY === $orderby ) {
			$meta_query['lc_score'] = array(
				'relation'       => 'OR',
				'lc_score_value' => array(
					'key'  => Fields::BEST,
					'type' => 'NUMERIC',
				),
				array(
					'key'     => Fields::BEST,
					'compare' => 'NOT EXISTS',
				),
			);
			$query->set(
				'orderby',
				array(
					'lc_score_value' => 'DESC',
					'menu_order'     => 'ASC',
					'title'          => 'ASC',
				)
			);
		}
		$query->set( 'tax_query', $tax_query ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
		$query->set( 'meta_query', $meta_query ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
	}

	/**
	 * «Mejor puntuados» in the sort options of the Bodega.
	 *
	 * @param mixed $options Options.
	 * @return mixed
	 */
	public static function orderby_options( $options ) {
		if ( ! is_array( $options ) || ! self::in_context() ) {
			return $options;
		}
		$sorted = array();
		foreach ( $options as $key => $label ) {
			$sorted[ $key ] = $label;
			if ( 'popularity' === $key ) {
				$sorted[ self::ORDERBY ] = __( 'Mejor puntuados', 'lachinata-core' );
			}
		}
		if ( ! isset( $sorted[ self::ORDERBY ] ) ) {
			$sorted[ self::ORDERBY ] = __( 'Mejor puntuados', 'lachinata-core' );
		}
		return $sorted;
	}

	/**
	 * WooCommerce's ordering for «Mejor puntuados» (the query adds the score).
	 *
	 * @param mixed $args    Arguments.
	 * @param mixed $orderby Order asked.
	 * @return mixed
	 */
	public static function ordering_args( $args, $orderby ) {
		if ( self::ORDERBY !== $orderby || ! is_array( $args ) ) {
			return $args;
		}
		$args['orderby']  = 'menu_order title';
		$args['order']    = 'ASC';
		$args['meta_key'] = ''; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
		return $args;
	}

	/**
	 * Header of the Bodega listing (and of its type and origin pages): eyebrow, title, text,
	 * the type chips and the entries.
	 *
	 * @param mixed $header Header of other sources.
	 * @param mixed $term   Category.
	 * @return mixed
	 */
	public static function header( $header, $term ) {
		$category = Config::category();
		if ( null !== $header || ! $term instanceof \WP_Term || null === $category || ( $term->term_id !== $category->term_id && ! term_is_ancestor_of( $category, $term, 'product_cat' ) ) ) {
			return $header;
		}
		$landing = Landing::current();
		$base    = self::url();
		$chips   = array(
			array(
				'label'    => __( 'Todo', 'lachinata-core' ),
				'href'     => $base,
				'selected' => null === $landing && $term->term_id === $category->term_id && ! self::chosen( 'vino_tipo' ),
			),
		);
		foreach ( self::chips() as $chip ) {
			$chips[] = $chip;
		}
		$header = array(
			'eyebrow'     => Config::text( 'eyebrow' ),
			'title'       => null !== $landing ? Landing::title( $landing ) : Terms::name( $term ),
			'tint'        => 'bodega',
			'text'        => null === $landing ? Config::text( 'intro' ) : '',
			'chips'       => $chips,
			'entries'     => null === $landing && $term->term_id === $category->term_id && ! self::filtered() ? self::entries() : array(),
			'description' => null !== $landing ? (string) $landing->description : null,
		);
		return $header;
	}

	/**
	 * The type chips: those of the panel or, by default, one per type with wines, and the
	 * accessories when they are chosen.
	 *
	 * @return array<int, array{label: string, href: string, selected: bool}>
	 */
	public static function chips(): array {
		$landing = Landing::current();
		$chosen  = self::chosen( 'vino_tipo' );
		$current = $landing && Taxonomies::TYPE === $landing->taxonomy ? array( $landing->slug ) : $chosen;
		$queried = get_queried_object();
		$rows    = Config::chips();
		if ( ! $rows ) {
			foreach ( self::terms_with_wines()[ Taxonomies::TYPE ] ?? array() as $type ) {
				$rows[] = array(
					'label'    => self::plural( $type ),
					'types'    => array( $type->slug ),
					'category' => '',
				);
			}
			$accessories = Config::accessories();
			if ( $accessories && $accessories->count > 0 ) {
				$rows[] = array(
					'label'    => Terms::name( $accessories ),
					'types'    => array(),
					'category' => $accessories->slug,
				);
			}
		}
		$chips = array();
		foreach ( $rows as $row ) {
			if ( '' !== $row['category'] ) {
				$category = get_term_by( 'slug', $row['category'], 'product_cat' );
				if ( ! $category instanceof \WP_Term ) {
					continue;
				}
				$link    = get_term_link( $category );
				$chips[] = array(
					'label'    => $row['label'],
					'href'     => is_string( $link ) ? $link : '',
					'selected' => $queried instanceof \WP_Term && $queried->term_id === $category->term_id,
				);
				continue;
			}
			$chips[] = array(
				'label'    => $row['label'],
				'href'     => 1 === count( $row['types'] ) ? Landing::url_for( $row['types'][0] ) : add_query_arg( 'vino_tipo', implode( ',', $row['types'] ), self::url() ),
				'selected' => $row['types'] && ! array_diff( $row['types'], $current ) && ! array_diff( $current, $row['types'] ),
			);
		}
		return $chips;
	}

	/**
	 * Plural name of a type for its chip: from its slug («tintos» → «Tintos»).
	 *
	 * @param \WP_Term $type Type.
	 */
	public static function plural( \WP_Term $type ): string {
		$name = str_replace( '-', ' ', $type->slug );
		return function_exists( 'mb_convert_case' ) ? mb_strtoupper( mb_substr( $name, 0, 1 ) ) . mb_substr( $name, 1 ) : ucfirst( $name );
	}

	/**
	 * The entries before the grid (CategoryTile), each one only when it has wines: the
	 * featured origin («Vinos de Extremadura», a setting), «Mejor puntuados» (with published
	 * scores of 90 or more) and «Arma tu caja» (with a mixed discount); then the panel's.
	 *
	 * @return array<int, array{title: string, href: string, eyebrow: string, text: string, cta: string, tint: string, photo_id: int}>
	 */
	public static function entries(): array {
		$entries = array();
		$origin  = Config::featured_origin();
		$count   = null !== $origin ? Landing::count( $origin ) : 0;
		if ( null !== $origin && $count > 0 ) {
			$entries[] = array(
				'title'    => Landing::title( $origin ),
				'href'     => Landing::url_for( $origin->slug ),
				'eyebrow'  => __( 'Selección', 'lachinata-core' ),
				/* translators: %s: number of wines. */
				'text'     => sprintf( _n( '%s vino', '%s vinos', $count, 'lachinata-core' ), number_format_i18n( $count ) ),
				'cta'      => __( 'Descubrir', 'lachinata-core' ),
				'tint'     => 'bodega',
				'photo_id' => 0,
			);
		}
		if ( self::terms_with_wines()['score'] ) {
			$entries[] = array(
				'title'    => __( 'Mejor puntuados', 'lachinata-core' ),
				'href'     => add_query_arg( 'orderby', self::ORDERBY, add_query_arg( 'vino_puntuacion', (string) Config::min_points(), self::url() ) ),
				'eyebrow'  => __( 'Críticos', 'lachinata-core' ),
				/* translators: %s: points («90»). */
				'text'     => sprintf( __( '%s puntos o más', 'lachinata-core' ), number_format_i18n( Config::min_points() ) ),
				'cta'      => __( 'Ver vinos', 'lachinata-core' ),
				'tint'     => 'cream',
				'photo_id' => 0,
			);
		}
		if ( Config::mixed_discount() > 0 ) {
			$entries[] = array(
				'title'    => __( 'Arma tu caja', 'lachinata-core' ),
				'href'     => self::url(),
				/* translators: %s: discount («5»). */
				'eyebrow'  => sprintf( __( '−%s %%', 'lachinata-core' ), number_format_i18n( Config::mixed_discount() ) ),
				/* translators: %s: bottles in a case. */
				'text'     => sprintf( __( '%s vinos distintos', 'lachinata-core' ), number_format_i18n( Config::CASE_SIZE ) ),
				'cta'      => __( 'Empezar', 'lachinata-core' ),
				'tint'     => 'aceites',
				'photo_id' => 0,
			);
		}
		foreach ( Config::entries() as $entry ) {
			$entries[] = array(
				'title'    => $entry['title'],
				'href'     => $entry['url'],
				'eyebrow'  => $entry['eyebrow'],
				'text'     => $entry['text'],
				'cta'      => $entry['cta'],
				'tint'     => $entry['tint'],
				'photo_id' => $entry['image_id'],
			);
		}
		return $entries;
	}
}
