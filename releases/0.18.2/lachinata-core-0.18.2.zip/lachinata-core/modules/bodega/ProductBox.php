<?php
/**
 * The «Vino» box of the product editor.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

use LaChinata\Core\Hooks;
use LaChinata\Core\Terms;

defined( 'ABSPATH' ) || exit;

/**
 * 10-bodega.md, «Edición en el panel»: creating or changing a wine is filling an ordered
 * card, not going through a list of fields. One box «Vino» over WooCommerce's data, with
 * tabs (Ficha, Cata, Añadas y puntuaciones, Maridaje, Etiqueta), the state of the card on
 * top and, on wide screens, a preview of the header of the page. It is built with
 * WordPress's components (src/editor.js) and saves with the product: the script keeps the
 * whole state in one hidden field (JSON) that save() cleans with Fields. Each variation
 * may change the strength, the ageing and «Cuenta para la caja» in its own panel.
 *
 * The defaults by type (temperature, case, alcohol) fill, never block; the warnings never
 * stop the product from saving.
 */
final class ProductBox {

	/**
	 * Hidden field, nonce and script.
	 */
	public const FIELD  = 'lc_bodega_data';
	public const NONCE  = 'lc_bodega_nonce';
	public const SCRIPT = 'lachinata-bodega-editor';

	/**
	 * Fields of a variation.
	 */
	public const VARIATION_FIELD = 'lc_bodega_variation';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'add_meta_boxes_product', array( self::class, 'box' ) );
		Hooks::add_action( 'admin_enqueue_scripts', array( self::class, 'enqueue' ) );
		Hooks::add_action( 'woocommerce_admin_process_product_object', array( self::class, 'save' ) );
		Hooks::add_action( 'woocommerce_product_after_variable_attributes', array( self::class, 'variation_fields' ), 20, 3 );
		Hooks::add_action( 'woocommerce_admin_process_variation_object', array( self::class, 'save_variation' ), 10, 2 );
	}

	/**
	 * Adds the box on top, over the product data.
	 */
	public static function box(): void {
		add_meta_box( 'lc-bodega-wine', __( 'Vino', 'lachinata-core' ), array( self::class, 'render' ), 'product', 'normal', 'high' );
	}

	/**
	 * Prints the root of the box and the hidden field.
	 *
	 * @param \WP_Post $post Product.
	 */
	public static function render( \WP_Post $post ): void {
		wp_nonce_field( 'lc-bodega-wine', self::NONCE );
		$product = wc_get_product( $post->ID );
		$values  = $product instanceof \WC_Product ? self::values( $product ) : array();
		printf(
			'<input type="hidden" name="%1$s" id="lc-bodega-data" value="%2$s">',
			esc_attr( self::FIELD ),
			esc_attr( (string) wp_json_encode( $values ) )
		);
		echo '<div id="lc-bodega-box" class="lc-bodega-box"><p class="description">' . esc_html__( 'Cargando la ficha del vino…', 'lachinata-core' ) . '</p></div>';
		echo '<noscript><p>' . esc_html__( 'La ficha del vino necesita JavaScript. El resto del producto se puede guardar igual.', 'lachinata-core' ) . '</p></noscript>';
	}

	/**
	 * Loads the box on the product screen.
	 *
	 * @param mixed $hook Admin page.
	 */
	public static function enqueue( $hook ): void {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) || null === $screen || 'product' !== $screen->post_type ) {
			return;
		}
		$file  = LACHINATA_CORE_DIR . '/modules/bodega/build/editor.asset.php';
		$asset = is_readable( $file ) ? require $file : array(
			'dependencies' => array( 'wp-api-fetch', 'wp-components', 'wp-element', 'wp-i18n', 'jquery' ),
			'version'      => LACHINATA_CORE_VERSION,
		);
		$deps  = array_values( array_unique( array_merge( (array) $asset['dependencies'], array( 'jquery' ) ) ) );
		wp_enqueue_media();
		wp_enqueue_script( self::SCRIPT, plugins_url( 'modules/bodega/build/editor.js', LACHINATA_CORE_FILE ), $deps, (string) $asset['version'], true );
		wp_enqueue_style( 'wp-components' );
		if ( is_readable( LACHINATA_CORE_DIR . '/modules/bodega/build/editor.css' ) ) {
			wp_enqueue_style( self::SCRIPT, plugins_url( 'modules/bodega/build/editor.css', LACHINATA_CORE_FILE ), array( 'wp-components' ), (string) $asset['version'] );
		}
		wp_set_script_translations( self::SCRIPT, 'lachinata-core', LACHINATA_CORE_DIR . '/languages' );
		$post_id = isset( $GLOBALS['post'] ) && $GLOBALS['post'] instanceof \WP_Post ? (int) $GLOBALS['post']->ID : 0;
		$product = $post_id ? wc_get_product( $post_id ) : null;
		wp_add_inline_script(
			self::SCRIPT,
			'window.lcBodegaEditor = ' . wp_json_encode( self::settings( $product instanceof \WC_Product ? $product : null ) ) . ';',
			'before'
		);
	}

	/**
	 * Lists and context the script needs: the terms of each taxonomy, the critics and
	 * contests, the vintages of the product and the defaults.
	 *
	 * @param \WC_Product|null $product Product being edited.
	 * @return array<string, mixed>
	 */
	public static function settings( ?\WC_Product $product ): array {
		$types = array();
		foreach ( self::terms( Taxonomies::TYPE ) as $term ) {
			$temp    = Taxonomies::type_temperature( $term );
			$types[] = array(
				'id'    => $term->term_id,
				'name'  => Terms::name( $term ),
				'color' => Taxonomies::type_color( $term ),
				'temp'  => $temp ? array( $temp[0], $temp[1] ) : null,
			);
		}
		$wineries = array();
		foreach ( self::terms( Taxonomies::WINERY ) as $term ) {
			$wineries[] = array(
				'id'     => $term->term_id,
				'name'   => Terms::name( $term ),
				'origin' => (int) get_term_meta( $term->term_id, Taxonomies::WINERY_ORIGIN, true ),
			);
		}
		$viticulture = array();
		foreach ( Fields::viticulture_labels() as $key => $label ) {
			$viticulture[] = array(
				'key'  => $key,
				'name' => $label,
			);
		}
		return array(
			'productId'   => $product ? $product->get_id() : 0,
			'variable'    => $product ? $product->is_type( 'variable' ) : false,
			'name'        => $product ? $product->get_name() : '',
			'types'       => $types,
			'makings'     => self::simple_terms( Taxonomies::MAKING ),
			'dishes'      => self::simple_terms( Taxonomies::DISH ),
			'grapes'      => self::simple_terms( Taxonomies::GRAPE ),
			'wineries'    => $wineries,
			'origins'     => self::origins(),
			'viticulture' => $viticulture,
			'critics'     => Config::critics(),
			'contests'    => Config::contests(),
			'medals'      => Config::medals(),
			'minPoints'   => Config::min_points(),
			'minMedal'    => Config::min_medal(),
			'vintages'    => $product ? self::vintages( $product ) : array(),
			'attribute'   => '' !== Config::vintage_attribute(),
			'defaults'    => array(
				'alcohol' => $product ? Fields::default_alcohol( $product ) : false,
				'case'    => $product ? Fields::default_case( $product ) : false,
			),
			'suggest'     => Config::suggest_pairing(),
			'termsUrl'    => admin_url( 'edit-tags.php?post_type=product&taxonomy=' ),
		);
	}

	/**
	 * Terms of a taxonomy, by name.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @return \WP_Term[]
	 */
	private static function terms( string $taxonomy ): array {
		if ( ! taxonomy_exists( $taxonomy ) ) {
			return array();
		}
		$terms = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
				'orderby'    => Taxonomies::TYPE === $taxonomy ? 'term_id' : 'name',
			)
		);
		return is_array( $terms ) ? array_values( array_filter( $terms, static fn( $term ): bool => $term instanceof \WP_Term ) ) : array();
	}

	/**
	 * `{id, name}` of each term of a taxonomy.
	 *
	 * @param string $taxonomy Taxonomy.
	 * @return array<int, array{id: int, name: string}>
	 */
	private static function simple_terms( string $taxonomy ): array {
		return array_map(
			static fn( \WP_Term $term ): array => array(
				'id'   => $term->term_id,
				'name' => Terms::name( $term ),
			),
			self::terms( $taxonomy )
		);
	}

	/**
	 * Every origin with its chain («España › Extremadura › Ribera del Guadiana»).
	 *
	 * @return array<int, array{id: int, name: string, label: string, depth: int}>
	 */
	public static function origins(): array {
		$out = array();
		foreach ( self::terms( Taxonomies::ORIGIN ) as $term ) {
			$chain = Taxonomies::origin_chain( $term );
			$out[] = array(
				'id'    => $term->term_id,
				'name'  => Terms::name( $term ),
				'label' => implode( ' › ', array_map( static fn( \WP_Term $item ): string => Terms::name( $item ), $chain ) ),
				'depth' => count( $chain ) - 1,
			);
		}
		usort( $out, static fn( array $a, array $b ): int => strcmp( $a['label'], $b['label'] ) );
		return $out;
	}

	/**
	 * Vintages of the product, from its variations: slug, name and variation.
	 *
	 * @param \WC_Product $product Product.
	 * @return array<int, array{slug: string, name: string, variation: int}>
	 */
	public static function vintages( \WC_Product $product ): array {
		$names = array_column( Fields::vintages( $product ), 'name', 'slug' );
		$out   = array();
		if ( $product instanceof \WC_Product_Variable ) {
			foreach ( $product->get_children() as $child_id ) {
				$child = wc_get_product( $child_id );
				if ( ! $child instanceof \WC_Product_Variation ) {
					continue;
				}
				$vintage = Fields::vintage_of( $child );
				if ( null === $vintage || isset( $out[ $vintage['slug'] ] ) ) {
					continue;
				}
				$out[ $vintage['slug'] ] = array(
					'slug'      => $vintage['slug'],
					'name'      => $vintage['name'],
					'variation' => $child->get_id(),
				);
			}
		}
		foreach ( $names as $slug => $name ) {
			if ( ! isset( $out[ $slug ] ) ) {
				$out[ $slug ] = array(
					'slug'      => (string) $slug,
					'name'      => (string) $name,
					'variation' => 0,
				);
			}
		}
		$out = array_values( $out );
		usort( $out, static fn( array $a, array $b ): int => strcmp( $b['name'], $a['name'] ) );
		return $out;
	}

	/**
	 * The state of the box for a product.
	 *
	 * @param \WC_Product $product Product.
	 * @return array<string, mixed>
	 */
	public static function values( \WC_Product $product ): array {
		$id     = $product->get_id();
		$origin = Fields::origin( $product );
		$grapes = array();
		foreach ( Fields::grapes( Fields::get( $id, Fields::GRAPES ) ) as $row ) {
			$term = get_term( $row['term'], Taxonomies::GRAPE );
			if ( $term instanceof \WP_Term ) {
				$grapes[] = array(
					'term' => $term->term_id,
					'pct'  => $row['pct'],
				);
			}
		}
		if ( ! $grapes ) {
			foreach ( Fields::terms( $product, Taxonomies::GRAPE ) as $term ) {
				$grapes[] = array(
					'term' => $term->term_id,
					'pct'  => null,
				);
			}
		}
		$pairing = array();
		foreach ( Fields::pairing( Fields::get( $id, Fields::PAIRING ) ) as $pair_id ) {
			$item = wc_get_product( $pair_id );
			if ( $item instanceof \WC_Product ) {
				$pairing[] = self::product_summary( $item );
			}
		}
		$term_id = static fn( ?\WP_Term $term ): int => $term ? $term->term_id : 0;
		$profile = Fields::profile( Fields::get( $id, Fields::PROFILE ) );
		return array(
			'type'        => $term_id( Fields::type( $product ) ),
			'making'      => $term_id( Fields::term( $product, Taxonomies::MAKING ) ),
			'winery'      => $term_id( Fields::term( $product, Taxonomies::WINERY ) ),
			'origin'      => $term_id( $origin ),
			'viticulture' => Fields::viticulture( Fields::get( $id, Fields::VITICULTURE ) ),
			'grapes'      => $grapes,
			'grade'       => Fields::grade( Fields::get( $id, Fields::GRADE ) ),
			'ageing'      => Fields::line( Fields::get( $id, Fields::AGEING ) ),
			'temperature' => Fields::temperature( Fields::get( $id, Fields::TEMPERATURE ) ),
			'tasting'     => Fields::tasting( Fields::get( $id, Fields::TASTING ) ),
			'profile'     => (object) $profile,
			'scores'      => Fields::scores( Fields::get( $id, Fields::SCORES ) ),
			'dishes'      => array_map( static fn( \WP_Term $term ): int => $term->term_id, Fields::terms( $product, Taxonomies::DISH ) ),
			'pairing'     => $pairing,
			'suggest'     => Fields::flag( Fields::get( $id, Fields::SUGGEST ) ),
			'label'       => Fields::label( Fields::get( $id, Fields::LABEL ) ),
			'case'        => Fields::flag( Fields::get( $id, Fields::CASE_FLAG ) ),
			'alcohol'     => Fields::flag( Fields::get( $id, Fields::ALCOHOL ) ),
		);
	}

	/**
	 * A product for the pairing picker: id, name, SKU, price and photo.
	 *
	 * @param \WC_Product $product Product.
	 * @return array{id: int, name: string, sku: string, price: string, image: string}
	 */
	public static function product_summary( \WC_Product $product ): array {
		$image = (int) $product->get_image_id();
		return array(
			'id'    => $product->get_id(),
			'name'  => $product->get_name(),
			'sku'   => (string) $product->get_sku(),
			'price' => html_entity_decode( wp_strip_all_tags( wc_price( (float) wc_get_price_to_display( $product ) ) ), ENT_QUOTES ),
			'image' => $image ? (string) wp_get_attachment_image_url( $image, 'thumbnail' ) : '',
		);
	}

	/**
	 * Saves the box with the product.
	 *
	 * @param mixed $product Product.
	 */
	public static function save( $product ): void {
		if ( ! $product instanceof \WC_Product ) {
			return;
		}
		$nonce = isset( $_POST[ self::NONCE ] ) ? sanitize_key( wp_unslash( $_POST[ self::NONCE ] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'lc-bodega-wine' ) || ! isset( $_POST[ self::FIELD ] ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- JSON, cleaned field by field in apply().
		$data = json_decode( (string) wp_unslash( $_POST[ self::FIELD ] ), true );
		self::keep_vintages( $product );
		if ( ! is_array( $data ) ) {
			return;
		}
		self::apply( $product, $data );
	}

	/**
	 * Keeps in the vintage attribute every vintage its variations use. A vintage created
	 * with «Nueva añada» while the page was open is not in the attributes the form sends;
	 * without this, «Actualizar» would leave its variation without a vintage of the product.
	 *
	 * @param \WC_Product $product Product being saved.
	 */
	public static function keep_vintages( \WC_Product $product ): void {
		$taxonomy = Config::vintage_attribute();
		if ( '' === $taxonomy || ! $product instanceof \WC_Product_Variable ) {
			return;
		}
		$needed = array();
		foreach ( $product->get_children() as $child_id ) {
			$slug = (string) get_post_meta( (int) $child_id, 'attribute_' . $taxonomy, true );
			$term = '' !== $slug ? get_term_by( 'slug', $slug, $taxonomy ) : false;
			if ( $term instanceof \WP_Term ) {
				$needed[] = $term->term_id;
			}
		}
		if ( ! $needed ) {
			return;
		}
		$attributes = $product->get_attributes();
		$attribute  = $attributes[ $taxonomy ] ?? null;
		if ( ! $attribute instanceof \WC_Product_Attribute ) {
			$attribute = new \WC_Product_Attribute();
			$attribute->set_id( wc_attribute_taxonomy_id_by_name( $taxonomy ) );
			$attribute->set_name( $taxonomy );
			$attribute->set_options( array() );
			$attribute->set_position( count( $attributes ) );
			$attribute->set_visible( true );
			$attribute->set_variation( true );
		}
		$options = array_map( 'intval', $attribute->get_options() );
		$missing = array_diff( $needed, $options );
		if ( ! $missing ) {
			return;
		}
		$attribute->set_options( array_values( array_unique( array_merge( $options, $missing ) ) ) );
		$attribute->set_variation( true );
		$attributes[ $taxonomy ] = $attribute;
		$product->set_attributes( $attributes );
	}

	/**
	 * Writes a state of the box in a product: meta cleaned by Fields and the terms of each
	 * taxonomy (the origin, only the deepest term).
	 *
	 * @param \WC_Product          $product Product.
	 * @param array<string, mixed> $data    State of the box.
	 */
	public static function apply( \WC_Product $product, array $data ): void {
		$id     = $product->get_id();
		$terms  = array(
			Taxonomies::TYPE   => self::term_ids( array( $data['type'] ?? 0 ), Taxonomies::TYPE ),
			Taxonomies::MAKING => self::term_ids( array( $data['making'] ?? 0 ), Taxonomies::MAKING ),
			Taxonomies::WINERY => self::term_ids( array( $data['winery'] ?? 0 ), Taxonomies::WINERY ),
			Taxonomies::ORIGIN => self::term_ids( array( $data['origin'] ?? 0 ), Taxonomies::ORIGIN ),
			Taxonomies::DISH   => self::term_ids( (array) ( $data['dishes'] ?? array() ), Taxonomies::DISH ),
		);
		$grapes = array();
		foreach ( Fields::grapes( (array) ( $data['grapes'] ?? array() ) ) as $row ) {
			if ( self::term_ids( array( $row['term'] ), Taxonomies::GRAPE ) ) {
				$grapes[] = $row;
			}
		}
		$terms[ Taxonomies::GRAPE ] = array_column( $grapes, 'term' );
		foreach ( $terms as $taxonomy => $ids ) {
			if ( taxonomy_exists( $taxonomy ) ) {
				wp_set_object_terms( $id, $ids, $taxonomy );
			}
		}
		$meta    = array(
			Fields::GRADE       => Fields::grade_meta( $data['grade'] ?? 0 ),
			Fields::AGEING      => Fields::line( $data['ageing'] ?? '' ),
			Fields::VITICULTURE => Fields::viticulture( $data['viticulture'] ?? array() ),
			Fields::TEMPERATURE => Fields::temperature( $data['temperature'] ?? array() ),
			Fields::TASTING     => Fields::tasting( $data['tasting'] ?? array() ),
			Fields::PROFILE     => Fields::profile( $data['profile'] ?? array() ),
			Fields::GRAPES      => $grapes,
			Fields::SCORES      => Fields::scores( $data['scores'] ?? array() ),
			Fields::PAIRING     => Fields::pairing( array_map( static fn( $row ) => is_array( $row ) ? ( $row['id'] ?? 0 ) : $row, (array) ( $data['pairing'] ?? array() ) ) ),
			Fields::SUGGEST     => Fields::flag( $data['suggest'] ?? '' ),
			Fields::LABEL       => Fields::label( $data['label'] ?? array() ),
			Fields::CASE_FLAG   => Fields::flag( $data['case'] ?? '' ),
			Fields::ALCOHOL     => Fields::flag( $data['alcohol'] ?? '' ),
		);
		$tasting = $meta[ Fields::TASTING ];
		$label   = $meta[ Fields::LABEL ];
		foreach ( $meta as $key => $value ) {
			$empty = in_array( $value, array( '', 0, 0.0, array() ), true )
				|| ( Fields::TASTING === $key && '' === $tasting['sight'] . $tasting['nose'] . $tasting['mouth'] )
				|| ( Fields::LABEL === $key && '' === $label['ingredients'] . $label['nutrition'] . $label['url'] . $label['allergens'] && ! $label['sulfites'] );
			if ( $empty ) {
				$product->delete_meta_data( $key );
			} else {
				$product->update_meta_data( $key, $value );
			}
		}
	}

	/**
	 * Ids that are terms of a taxonomy.
	 *
	 * @param array<mixed> $ids      Ids.
	 * @param string       $taxonomy Taxonomy.
	 * @return int[]
	 */
	private static function term_ids( array $ids, string $taxonomy ): array {
		$valid = array();
		foreach ( array_unique( array_filter( array_map( 'absint', $ids ) ) ) as $term_id ) {
			$term = get_term( $term_id, $taxonomy );
			if ( $term instanceof \WP_Term ) {
				$valid[] = $term->term_id;
			}
		}
		return $valid;
	}

	/**
	 * Strength, ageing and «Cuenta para la caja» of a variation, in its panel.
	 *
	 * @param mixed $loop      Index of the variation.
	 * @param mixed $data      Variation data.
	 * @param mixed $variation Variation post.
	 */
	public static function variation_fields( $loop, $data, $variation ): void {
		unset( $data );
		if ( ! $variation instanceof \WP_Post ) {
			return;
		}
		$parent = wc_get_product( $variation->post_parent );
		if ( ! $parent instanceof \WC_Product || ( ! Fields::is_wine( $parent ) && ! Fields::in_bodega( $parent ) ) ) {
			return;
		}
		$index = (int) $loop;
		$name  = self::VARIATION_FIELD . '[' . $index . ']';
		$grade = Fields::grade( Fields::get( $variation->ID, Fields::GRADE ) );
		$flag  = Fields::flag( Fields::get( $variation->ID, Fields::CASE_FLAG ) );
		echo '<div class="lc-bodega-variation">';
		printf(
			'<p class="form-row form-row-first"><label for="lc-bodega-grade-%1$d">%2$s</label><input type="number" step="0.1" min="0" max="99" id="lc-bodega-grade-%1$d" name="%3$s[grade]" value="%4$s" placeholder="%5$s"></p>',
			(int) $index,
			esc_html__( 'Grado de esta añada (% vol.)', 'lachinata-core' ),
			esc_attr( $name ),
			esc_attr( $grade > 0 ? (string) $grade : '' ),
			esc_attr__( 'El del vino', 'lachinata-core' )
		);
		printf(
			'<p class="form-row form-row-last"><label for="lc-bodega-ageing-%1$d">%2$s</label><input type="text" id="lc-bodega-ageing-%1$d" name="%3$s[ageing]" value="%4$s" placeholder="%5$s"></p>',
			(int) $index,
			esc_html__( 'Crianza de esta añada', 'lachinata-core' ),
			esc_attr( $name ),
			esc_attr( Fields::line( Fields::get( $variation->ID, Fields::AGEING ) ) ),
			esc_attr__( 'La del vino', 'lachinata-core' )
		);
		$child = wc_get_product( $variation->ID );
		$auto  = $child instanceof \WC_Product && Fields::is_wine( $parent ) && Fields::is_standard_bottle( $child );
		printf( '<p class="form-row form-row-full"><label for="lc-bodega-case-%1$d">%2$s</label><select id="lc-bodega-case-%1$d" name="%3$s[case]">', (int) $index, esc_html__( 'Cuenta para la caja de 6', 'lachinata-core' ), esc_attr( $name ) );
		$options = array(
			/* translators: %s: «sí» or «no», what applies by default. */
			''    => sprintf( __( 'Según el formato (ahora: %s)', 'lachinata-core' ), $auto ? __( 'sí', 'lachinata-core' ) : __( 'no', 'lachinata-core' ) ),
			'yes' => __( 'Sí', 'lachinata-core' ),
			'no'  => __( 'No', 'lachinata-core' ),
		);
		foreach ( $options as $value => $label ) {
			printf( '<option value="%1$s"%2$s>%3$s</option>', esc_attr( $value ), selected( $flag, $value, false ), esc_html( $label ) );
		}
		echo '</select></p></div>';
	}

	/**
	 * Saves the fields of a variation.
	 *
	 * @param mixed $variation Variation.
	 * @param mixed $index     Index of the variation in the form.
	 */
	public static function save_variation( $variation, $index ): void {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- WooCommerce checks the nonce of the variations before this action.
		if ( ! $variation instanceof \WC_Product_Variation || ! isset( $_POST[ self::VARIATION_FIELD ][ (int) $index ] ) || ! current_user_can( 'edit_products' ) ) {
			return;
		}
		$row = wp_unslash( $_POST[ self::VARIATION_FIELD ][ (int) $index ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Cleaned by Fields below.
		// phpcs:enable
		if ( ! is_array( $row ) ) {
			return;
		}
		$values = array(
			Fields::GRADE     => Fields::grade_meta( $row['grade'] ?? '' ),
			Fields::AGEING    => Fields::line( $row['ageing'] ?? '' ),
			Fields::CASE_FLAG => Fields::flag( $row['case'] ?? '' ),
		);
		foreach ( $values as $key => $value ) {
			if ( '' === $value ) {
				$variation->delete_meta_data( $key );
			} else {
				$variation->update_meta_data( $key, $value );
			}
		}
	}
}
