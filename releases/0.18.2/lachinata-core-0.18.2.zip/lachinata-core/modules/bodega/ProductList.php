<?php
/**
 * The wines in the product list of the panel.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

use LaChinata\Core\Hooks;
use LaChinata\Core\Terms;

defined( 'ABSPATH' ) || exit;

/**
 * Filters by wine type and winery in Productos, and, when the list shows wines (filtered by
 * the Bodega category or one below it, or by type or winery), the columns Tipo, Añadas,
 * Mejor puntuación and Completa (the twelve checks of Fields::completeness()).
 */
final class ProductList {

	/**
	 * Columns of the module.
	 */
	public const COLUMNS = array( 'lc_bodega_type', 'lc_bodega_vintages', 'lc_bodega_best', 'lc_bodega_complete' );

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'restrict_manage_posts', array( self::class, 'filters' ), 20 );
		Hooks::add_filter( 'manage_edit-product_columns', array( self::class, 'columns' ), 20 );
		Hooks::add_action( 'manage_product_posts_custom_column', array( self::class, 'cell' ), 20, 2 );
	}

	/**
	 * Whether the list shows wines: filtered by the Bodega (or below it), by type or winery.
	 */
	public static function showing_wines(): bool {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only filters of the list.
		foreach ( array( Taxonomies::TYPE, Taxonomies::WINERY ) as $taxonomy ) {
			if ( ! empty( $_GET[ $taxonomy ] ) ) {
				return true;
			}
		}
		$slug = isset( $_GET['product_cat'] ) ? sanitize_title( wp_unslash( $_GET['product_cat'] ) ) : '';
		// phpcs:enable
		$category = Config::category();
		if ( '' === $slug || null === $category ) {
			return false;
		}
		$term = get_term_by( 'slug', $slug, 'product_cat' );
		return $term instanceof \WP_Term && ( $term->term_id === $category->term_id || term_is_ancestor_of( $category, $term, 'product_cat' ) );
	}

	/**
	 * Dropdowns of type and winery over the list.
	 *
	 * @param mixed $post_type Post type of the list.
	 */
	public static function filters( $post_type ): void {
		if ( 'product' !== $post_type ) {
			return;
		}
		$labels = array(
			Taxonomies::TYPE   => __( 'Cualquier tipo de vino', 'lachinata-core' ),
			Taxonomies::WINERY => __( 'Cualquier bodega', 'lachinata-core' ),
		);
		foreach ( $labels as $taxonomy => $all ) {
			$terms = get_terms(
				array(
					'taxonomy'   => $taxonomy,
					'hide_empty' => true,
					'orderby'    => 'name',
				)
			);
			if ( ! is_array( $terms ) || ! $terms ) {
				continue;
			}
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only filters of the list.
			$current = isset( $_GET[ $taxonomy ] ) ? sanitize_title( wp_unslash( $_GET[ $taxonomy ] ) ) : '';
			printf( '<label class="screen-reader-text" for="filter-%1$s">%2$s</label><select name="%1$s" id="filter-%1$s"><option value="">%2$s</option>', esc_attr( $taxonomy ), esc_html( $all ) );
			foreach ( $terms as $term ) {
				if ( $term instanceof \WP_Term ) {
					printf( '<option value="%1$s"%2$s>%3$s</option>', esc_attr( $term->slug ), selected( $current, $term->slug, false ), esc_html( Terms::name( $term ) ) );
				}
			}
			echo '</select>';
		}
	}

	/**
	 * The columns, after the name, when the list shows wines.
	 *
	 * @param mixed $columns Columns.
	 * @return mixed
	 */
	public static function columns( $columns ) {
		if ( ! is_array( $columns ) || ! self::showing_wines() ) {
			return $columns;
		}
		$own = array(
			'lc_bodega_type'     => __( 'Tipo', 'lachinata-core' ),
			'lc_bodega_vintages' => __( 'Añadas', 'lachinata-core' ),
			'lc_bodega_best'     => __( 'Mejor puntuación', 'lachinata-core' ),
			'lc_bodega_complete' => __( 'Completa', 'lachinata-core' ),
		);
		$out = array();
		foreach ( $columns as $key => $label ) {
			$out[ $key ] = $label;
			if ( 'name' === $key ) {
				$out += $own;
			}
		}
		return $out + $own;
	}

	/**
	 * A cell of the module's columns.
	 *
	 * @param mixed $column  Column.
	 * @param mixed $post_id Product.
	 */
	public static function cell( $column, $post_id ): void {
		if ( ! in_array( $column, self::COLUMNS, true ) ) {
			return;
		}
		$product = wc_get_product( (int) $post_id );
		if ( ! $product instanceof \WC_Product ) {
			return;
		}
		echo wp_kses_post( self::value( (string) $column, $product ) );
	}

	/**
	 * Content of a cell.
	 *
	 * @param string      $column  Column.
	 * @param \WC_Product $product Product.
	 */
	public static function value( string $column, \WC_Product $product ): string {
		if ( ! Fields::is_wine( $product ) && 'lc_bodega_type' !== $column ) {
			return '<span aria-hidden="true">—</span>';
		}
		switch ( $column ) {
			case 'lc_bodega_type':
				$type = Fields::type( $product );
				return $type ? esc_html( Terms::name( $type ) ) : '<span aria-hidden="true">—</span>';
			case 'lc_bodega_vintages':
				$names = array_column( Fields::vintages( $product ), 'name' );
				return $names ? esc_html( implode( ', ', $names ) ) : '<span aria-hidden="true">—</span>';
			case 'lc_bodega_best':
				$best = Scores::best( $product );
				return $best > 0 ? esc_html( number_format_i18n( $best ) ) : '<span aria-hidden="true">—</span>';
			default:
				$state = Fields::completeness( $product );
				if ( ! $state['missing'] ) {
					/* translators: %s: number of checks («12»). */
					return '<span style="color:#008a20">' . esc_html( sprintf( __( 'Sí (%s)', 'lachinata-core' ), number_format_i18n( $state['total'] ) ) ) . '</span>';
				}
				return sprintf(
					'<span title="%1$s">%2$s</span>',
					/* translators: %s: what is missing («temperatura, cata»). */
					esc_attr( sprintf( __( 'Faltan: %s', 'lachinata-core' ), implode( ', ', $state['missing'] ) ) ),
					/* translators: 1: checks done, 2: total. */
					esc_html( sprintf( __( '%1$s de %2$s', 'lachinata-core' ), number_format_i18n( $state['done'] ), number_format_i18n( $state['total'] ) ) )
				);
		}
	}
}
