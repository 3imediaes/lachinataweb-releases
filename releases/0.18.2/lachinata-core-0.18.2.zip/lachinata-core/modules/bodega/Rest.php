<?php
/**
 * Routes of the «Vino» box.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

use LaChinata\Core\Hooks;
use LaChinata\Core\Terms;

defined( 'ABSPATH' ) || exit;

/**
 * What the box does at once, without waiting for «Actualizar»: a new vintage (a variation
 * copied from the last one), «Crear a partir de este vino», the search of products for the
 * pairing (with photo) and of origins (with their chain), and the quick creation of a
 * winery or a grape. Only for people who edit products.
 */
final class Rest {

	/**
	 * Namespace of the routes.
	 */
	public const NAMESPACE = 'lachinata/v1';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'rest_api_init', array( self::class, 'routes' ) );
	}

	/**
	 * Whether the person may edit products.
	 */
	public static function can_edit(): bool {
		return current_user_can( 'edit_products' );
	}

	/**
	 * Registers the routes.
	 */
	public static function routes(): void {
		$permission = Hooks::wrap( array( self::class, 'can_edit' ), false );
		$id_arg     = array(
			'id' => array(
				'type'     => 'integer',
				'required' => true,
			),
		);
		register_rest_route(
			self::NAMESPACE,
			'/bodega/products/(?P<id>\d+)/vintages',
			array(
				'methods'             => 'POST',
				'callback'            => Hooks::rest( array( self::class, 'create_vintage' ) ),
				'permission_callback' => $permission,
				'args'                => $id_arg + array(
					'vintage' => array(
						'type'     => 'string',
						'required' => true,
					),
				),
			)
		);
		register_rest_route(
			self::NAMESPACE,
			'/bodega/products/(?P<id>\d+)/duplicate',
			array(
				'methods'             => 'POST',
				'callback'            => Hooks::rest( array( self::class, 'duplicate' ) ),
				'permission_callback' => $permission,
				'args'                => $id_arg,
			)
		);
		register_rest_route(
			self::NAMESPACE,
			'/bodega/products',
			array(
				'methods'             => 'GET',
				'callback'            => Hooks::rest( array( self::class, 'search_products' ) ),
				'permission_callback' => $permission,
				'args'                => array(
					'search'  => array(
						'type'    => 'string',
						'default' => '',
					),
					'exclude' => array(
						'type'    => 'integer',
						'default' => 0,
					),
				),
			)
		);
		register_rest_route(
			self::NAMESPACE,
			'/bodega/origins',
			array(
				'methods'             => 'GET',
				'callback'            => Hooks::rest( array( self::class, 'search_origins' ) ),
				'permission_callback' => $permission,
				'args'                => array(
					'search' => array(
						'type'    => 'string',
						'default' => '',
					),
				),
			)
		);
		register_rest_route(
			self::NAMESPACE,
			'/bodega/wineries',
			array(
				'methods'             => 'POST',
				'callback'            => Hooks::rest( array( self::class, 'create_winery' ) ),
				'permission_callback' => Hooks::wrap( static fn(): bool => current_user_can( 'manage_product_terms' ), false ),
				'args'                => array(
					'name'   => array(
						'type'     => 'string',
						'required' => true,
					),
					'origin' => array(
						'type'    => 'integer',
						'default' => 0,
					),
				),
			)
		);
		register_rest_route(
			self::NAMESPACE,
			'/bodega/grapes',
			array(
				'methods'             => 'POST',
				'callback'            => Hooks::rest( array( self::class, 'create_grape' ) ),
				'permission_callback' => Hooks::wrap( static fn(): bool => current_user_can( 'manage_product_terms' ), false ),
				'args'                => array(
					'name' => array(
						'type'     => 'string',
						'required' => true,
					),
				),
			)
		);
	}

	/**
	 * «Nueva añada»: a variation of the vintage, copying price, weight, measures, tax and
	 * shipping class and the other attributes (format) of the last variation, without SKU
	 * and with its scores empty. The product must already be variable.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function create_vintage( \WP_REST_Request $request ) {
		$product = wc_get_product( (int) $request['id'] );
		$name    = sanitize_text_field( (string) $request['vintage'] );
		if ( ! $product instanceof \WC_Product || ! current_user_can( 'edit_post', $product->get_id() ) ) {
			return new \WP_Error( 'lachinata_bodega_product', __( 'No existe ese producto.', 'lachinata-core' ), array( 'status' => 404 ) );
		}
		if ( ! $product instanceof \WC_Product_Variable ) {
			return new \WP_Error( 'lachinata_bodega_not_variable', __( 'Este vino no es un producto variable. Cambia el tipo de producto a «Producto variable», guárdalo y crea después la añada.', 'lachinata-core' ), array( 'status' => 400 ) );
		}
		$taxonomy = Config::vintage_attribute();
		if ( '' === $taxonomy || ! taxonomy_exists( $taxonomy ) ) {
			return new \WP_Error( 'lachinata_bodega_attribute', __( 'Falta el atributo de añada. Elígelo en WooCommerce → La Chinata → Bodega.', 'lachinata-core' ), array( 'status' => 400 ) );
		}
		if ( '' === $name || ( ! preg_match( '/^\d{4}$/', $name ) && 'sin añada' !== ( function_exists( 'mb_strtolower' ) ? mb_strtolower( $name ) : strtolower( $name ) ) ) ) {
			return new \WP_Error( 'lachinata_bodega_vintage', __( 'Escribe la añada con 4 cifras («2023») o «Sin añada».', 'lachinata-core' ), array( 'status' => 400 ) );
		}
		$term = get_term_by( 'name', $name, $taxonomy );
		if ( ! $term instanceof \WP_Term ) {
			$created = wp_insert_term( $name, $taxonomy );
			if ( is_wp_error( $created ) ) {
				return $created;
			}
			$term = get_term( (int) $created['term_id'], $taxonomy );
		}
		if ( ! $term instanceof \WP_Term ) {
			return new \WP_Error( 'lachinata_bodega_vintage', __( 'No se ha podido crear la añada.', 'lachinata-core' ), array( 'status' => 500 ) );
		}

		$template = null;
		foreach ( array_reverse( $product->get_children() ) as $child_id ) {
			$child = wc_get_product( $child_id );
			if ( ! $child instanceof \WC_Product_Variation ) {
				continue;
			}
			if ( (string) ( $child->get_variation_attributes()[ 'attribute_' . $taxonomy ] ?? '' ) === $term->slug ) {
				return new \WP_Error( 'lachinata_bodega_exists', __( 'Este vino ya tiene esa añada.', 'lachinata-core' ), array( 'status' => 409 ) );
			}
			$template = $template ?? $child;
		}

		$attributes = $product->get_attributes();
		$attribute  = $attributes[ $taxonomy ] ?? null;
		if ( ! $attribute instanceof \WC_Product_Attribute ) {
			$attribute = new \WC_Product_Attribute();
			$attribute->set_id( wc_attribute_taxonomy_id_by_name( $taxonomy ) );
			$attribute->set_name( $taxonomy );
			$attribute->set_options( array() );
			$attribute->set_position( count( $attributes ) );
		}
		$attribute->set_options( array_values( array_unique( array_merge( array_map( 'intval', $attribute->get_options() ), array( $term->term_id ) ) ) ) );
		$attribute->set_visible( true );
		$attribute->set_variation( true );
		$attributes[ $taxonomy ] = $attribute;
		$product->set_attributes( $attributes );
		$product->save();
		wp_set_object_terms( $product->get_id(), $term->term_id, $taxonomy, true );

		$variation = new \WC_Product_Variation();
		$variation->set_parent_id( $product->get_id() );
		$variation->set_status( 'publish' );
		$values = array( 'attribute_' . $taxonomy => $term->slug );
		if ( $template instanceof \WC_Product_Variation ) {
			$variation->set_regular_price( $template->get_regular_price() );
			$variation->set_weight( $template->get_weight() );
			$variation->set_length( $template->get_length() );
			$variation->set_width( $template->get_width() );
			$variation->set_height( $template->get_height() );
			$variation->set_tax_class( $template->get_tax_class( 'edit' ) );
			$variation->set_shipping_class_id( $template->get_shipping_class_id( 'edit' ) );
			$variation->set_manage_stock( $template->get_manage_stock( 'edit' ) );
			foreach ( $template->get_variation_attributes() as $key => $value ) {
				if ( 'attribute_' . $taxonomy !== $key ) {
					$values[ $key ] = $value;
				}
			}
		}
		$variation->set_attributes( array_combine( array_map( static fn( string $key ): string => substr( $key, 10 ), array_keys( $values ) ), array_values( $values ) ) );
		$variation->set_stock_status( $variation->get_manage_stock() ? 'outofstock' : 'instock' );
		$variation->save();
		\WC_Product_Variable::sync( $product->get_id() );

		return rest_ensure_response(
			array(
				'variation' => $variation->get_id(),
				'vintage'   => array(
					'slug'      => $term->slug,
					'name'      => Terms::name( $term ),
					'variation' => $variation->get_id(),
				),
			)
		);
	}

	/**
	 * «Crear a partir de este vino»: a draft with the card of this one (type, making,
	 * winery, origin, grapes, viticulture, strength, ageing, temperature, label flags and
	 * categories), without vintages, tasting, scores or pairing.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function duplicate( \WP_REST_Request $request ) {
		$source = wc_get_product( (int) $request['id'] );
		if ( ! $source instanceof \WC_Product || ! current_user_can( 'edit_post', $source->get_id() ) ) {
			return new \WP_Error( 'lachinata_bodega_product', __( 'No existe ese producto.', 'lachinata-core' ), array( 'status' => 404 ) );
		}
		$copy = $source instanceof \WC_Product_Variable ? new \WC_Product_Variable() : new \WC_Product_Simple();
		/* translators: %s: name of the wine it comes from. */
		$copy->set_name( sprintf( __( 'Nuevo vino de %s', 'lachinata-core' ), self::winery_name( $source ) ) );
		$copy->set_status( 'draft' );
		$copy->set_category_ids( $source->get_category_ids() );
		$copy->set_tax_class( $source->get_tax_class( 'edit' ) );
		$copy->set_shipping_class_id( $source->get_shipping_class_id( 'edit' ) );
		foreach ( array( Fields::GRADE, Fields::AGEING, Fields::VITICULTURE, Fields::TEMPERATURE, Fields::GRAPES, Fields::CASE_FLAG, Fields::ALCOHOL ) as $key ) {
			$value = Fields::get( $source->get_id(), $key );
			if ( '' !== $value && array() !== $value ) {
				$copy->update_meta_data( $key, $value );
			}
		}
		$label = Fields::label( Fields::get( $source->get_id(), Fields::LABEL ) );
		if ( $label['sulfites'] || '' !== $label['allergens'] ) {
			$copy->update_meta_data(
				Fields::LABEL,
				array(
					'ingredients' => '',
					'nutrition'   => '',
					'url'         => '',
					'sulfites'    => $label['sulfites'],
					'allergens'   => $label['allergens'],
				)
			);
		}
		$copy->save();
		foreach ( array( Taxonomies::TYPE, Taxonomies::MAKING, Taxonomies::WINERY, Taxonomies::ORIGIN, Taxonomies::GRAPE ) as $taxonomy ) {
			$ids = array_map( static fn( \WP_Term $term ): int => $term->term_id, Fields::terms( $source, $taxonomy ) );
			if ( $ids ) {
				wp_set_object_terms( $copy->get_id(), $ids, $taxonomy );
			}
		}
		return rest_ensure_response(
			array(
				'id'   => $copy->get_id(),
				'edit' => html_entity_decode( (string) get_edit_post_link( $copy->get_id(), 'raw' ), ENT_QUOTES ),
			)
		);
	}

	/**
	 * Name of the winery of a wine, or the wine's own name.
	 *
	 * @param \WC_Product $product Wine.
	 */
	private static function winery_name( \WC_Product $product ): string {
		$winery = Fields::term( $product, Taxonomies::WINERY );
		return $winery ? Terms::name( $winery ) : $product->get_name();
	}

	/**
	 * Products for the pairing, by name or SKU, with their photo (no variations).
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public static function search_products( \WP_REST_Request $request ) {
		$search = trim( sanitize_text_field( (string) $request['search'] ) );
		if ( strlen( $search ) < 2 ) {
			return rest_ensure_response( array() );
		}
		$by_name = get_posts(
			array(
				'post_type'      => 'product',
				'post_status'    => 'publish',
				's'              => $search,
				'posts_per_page' => 20,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);
		$by_sku  = wc_get_products(
			array(
				'status' => 'publish',
				'sku'    => $search,
				'limit'  => 10,
				'return' => 'ids',
			)
		);
		$ids     = array_unique( array_merge( is_array( $by_sku ) ? $by_sku : array(), $by_name ) );
		$out     = array();
		foreach ( array_filter( array_map( 'intval', $ids ) ) as $id ) {
			$product = wc_get_product( $id );
			if ( $product instanceof \WC_Product && 'publish' === $product->get_status() && (int) $request['exclude'] !== $id ) {
				$out[] = ProductBox::product_summary( $product );
			}
			if ( count( $out ) >= 10 ) {
				break;
			}
		}
		return rest_ensure_response( $out );
	}

	/**
	 * Origins whose name or chain holds the search («guadiana»), deepest first.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response
	 */
	public static function search_origins( \WP_REST_Request $request ) {
		$search = Config::key( sanitize_text_field( (string) $request['search'] ) );
		$out    = array();
		foreach ( ProductBox::origins() as $origin ) {
			if ( '' === $search || str_contains( Config::key( $origin['label'] ), $search ) ) {
				$out[] = $origin;
			}
		}
		usort( $out, static fn( array $a, array $b ): int => 0 !== ( $b['depth'] <=> $a['depth'] ) ? $b['depth'] <=> $a['depth'] : strcmp( $a['label'], $b['label'] ) );
		return rest_ensure_response( array_slice( $out, 0, 20 ) );
	}

	/**
	 * A winery with its origin (or the one that already has that name).
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function create_winery( \WP_REST_Request $request ) {
		$term = self::find_or_create( sanitize_text_field( (string) $request['name'] ), Taxonomies::WINERY );
		if ( is_wp_error( $term ) ) {
			return $term;
		}
		$origin = get_term( (int) $request['origin'], Taxonomies::ORIGIN );
		if ( $origin instanceof \WP_Term ) {
			update_term_meta( $term->term_id, Taxonomies::WINERY_ORIGIN, $origin->term_id );
		}
		return rest_ensure_response(
			array(
				'id'     => $term->term_id,
				'name'   => Terms::name( $term ),
				'origin' => (int) get_term_meta( $term->term_id, Taxonomies::WINERY_ORIGIN, true ),
			)
		);
	}

	/**
	 * A grape (or the one that already has that name).
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function create_grape( \WP_REST_Request $request ) {
		$term = self::find_or_create( sanitize_text_field( (string) $request['name'] ), Taxonomies::GRAPE );
		if ( is_wp_error( $term ) ) {
			return $term;
		}
		return rest_ensure_response(
			array(
				'id'   => $term->term_id,
				'name' => Terms::name( $term ),
			)
		);
	}

	/**
	 * The term with that name (case and accents do not matter), created when missing.
	 *
	 * @param string $name     Name.
	 * @param string $taxonomy Taxonomy.
	 * @return \WP_Term|\WP_Error
	 */
	private static function find_or_create( string $name, string $taxonomy ) {
		$name = trim( $name );
		if ( '' === $name ) {
			return new \WP_Error( 'lachinata_bodega_name', __( 'Escribe el nombre.', 'lachinata-core' ), array( 'status' => 400 ) );
		}
		$existing = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
				'search'     => $name,
			)
		);
		foreach ( is_array( $existing ) ? $existing : array() as $term ) {
			if ( $term instanceof \WP_Term && Config::key( Terms::name( $term ) ) === Config::key( $name ) ) {
				return $term;
			}
		}
		$created = wp_insert_term( $name, $taxonomy );
		if ( is_wp_error( $created ) ) {
			return $created;
		}
		$term = get_term( (int) $created['term_id'], $taxonomy );
		return $term instanceof \WP_Term ? $term : new \WP_Error( 'lachinata_bodega_term', __( 'No se ha podido crear.', 'lachinata-core' ), array( 'status' => 500 ) );
	}
}
