<?php
/**
 * SEO of the wines and of the Bodega's pages.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

use LaChinata\Core\Company;
use LaChinata\Core\Hooks;
use LaChinata\Core\Terms;

defined( 'ABSPATH' ) || exit;

/**
 * 10-bodega.md, «SEO»:
 * - `Product` with the winery as brand and `additionalProperty` (vintage, origin, grapes,
 *   strength, volume), in WooCommerce's data and in Rank Math's. The critics' scores are
 *   never `Review` nor `AggregateRating`: those are the customers'.
 * - Title «{Nombre} {Añada} · {Tipo} {D.O.}» and the description from the tasting, unless
 *   the product has its own in Rank Math.
 * - The type and origin pages take their title («Vinos tintos»).
 */
final class Seo {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'woocommerce_structured_data_product', array( self::class, 'woocommerce_schema' ), 20, 2 );
		Hooks::add_filter( 'rank_math/json_ld', array( self::class, 'rank_math_schema' ), 98 );
		Hooks::add_filter( 'document_title_parts', array( self::class, 'title_parts' ), 20 );
		Hooks::add_filter( 'rank_math/frontend/title', array( self::class, 'plugin_title' ), 20 );
		Hooks::add_filter( 'rank_math/frontend/description', array( self::class, 'plugin_description' ), 20 );
	}

	/**
	 * Properties of a wine for `additionalProperty`.
	 *
	 * @param \WC_Product $product Wine.
	 * @return array<int, array<string, string>>
	 */
	public static function properties( \WC_Product $product ): array {
		$rows = array();
		foreach ( Storefront::facts( $product, null ) as $row ) {
			if ( in_array( $row[2], array( 'vintage', 'origin', 'grapes', 'grade', 'volume', 'type' ), true ) ) {
				$rows[] = array(
					'@type' => 'PropertyValue',
					'name'  => $row[0],
					'value' => $row[1],
				);
			}
		}
		return $rows;
	}

	/**
	 * Adds brand and properties to a Product entity, and takes away any review or rating
	 * that is not a customer's.
	 *
	 * @param array<string, mixed> $entity  Entity.
	 * @param \WC_Product          $product Wine.
	 * @return array<string, mixed>
	 */
	public static function enrich( array $entity, \WC_Product $product ): array {
		$winery = Fields::term( $product, Taxonomies::WINERY );
		if ( $winery ) {
			$entity['brand'] = array(
				'@type' => 'Brand',
				'name'  => Terms::name( $winery ),
			);
		}
		$properties = self::properties( $product );
		if ( $properties ) {
			$entity['additionalProperty'] = $properties;
		}
		if ( ! $product->get_review_count() ) {
			unset( $entity['review'], $entity['aggregateRating'] );
		}
		return $entity;
	}

	/**
	 * WooCommerce's structured data of a wine.
	 *
	 * @param mixed $markup  Data.
	 * @param mixed $product Product.
	 * @return mixed
	 */
	public static function woocommerce_schema( $markup, $product ) {
		if ( ! is_array( $markup ) || ! $product instanceof \WC_Product || ! Fields::is_wine( $product ) ) {
			return $markup;
		}
		return self::enrich( $markup, $product );
	}

	/**
	 * Rank Math's Product entity of a wine.
	 *
	 * @param mixed $data Entities.
	 * @return mixed
	 */
	public static function rank_math_schema( $data ) {
		if ( ! is_array( $data ) || ! is_singular( 'product' ) ) {
			return $data;
		}
		$product = wc_get_product( (int) get_queried_object_id() );
		if ( ! $product instanceof \WC_Product || ! Fields::is_wine( $product ) ) {
			return $data;
		}
		foreach ( $data as $key => $entity ) {
			if ( is_array( $entity ) && 'Product' === ( $entity['@type'] ?? '' ) ) {
				$data[ $key ] = self::enrich( $entity, $product );
			}
		}
		return $data;
	}

	/**
	 * Our title of the page, or empty: a wine without its own SEO title, or a landing.
	 */
	public static function title(): string {
		if ( is_singular( 'product' ) ) {
			$id = (int) get_queried_object_id();
			if ( '' !== trim( (string) get_post_meta( $id, 'rank_math_title', true ) ) ) {
				return '';
			}
			$product = wc_get_product( $id );
			return $product instanceof \WC_Product && Fields::is_wine( $product ) ? self::wine_title( $product ) : '';
		}
		$landing = Listing::in_context() ? Landing::current() : null;
		return null !== $landing ? Landing::title( $landing ) : '';
	}

	/**
	 * «Pies Negros 2021 · Tinto crianza Rioja».
	 *
	 * @param \WC_Product $product Wine.
	 */
	public static function wine_title( \WC_Product $product ): string {
		$vintage = Fields::vintage_of( Storefront::default_child( $product ) ?? $product );
		$origin  = Fields::origin( $product );
		$name    = trim( $product->get_name() . ( $vintage && preg_match( '/^\d{4}$/', $vintage['name'] ) && ! str_contains( $product->get_name(), $vintage['name'] ) ? ' ' . $vintage['name'] : '' ) );
		$type    = trim( Storefront::type_line( $product ) . ( $origin ? ' ' . Terms::name( $origin ) : '' ) );
		/* translators: 1: wine and vintage, 2: type and D.O. */
		return '' !== $type ? sprintf( __( '%1$s · %2$s', 'lachinata-core' ), $name, $type ) : $name;
	}

	/**
	 * WordPress's title.
	 *
	 * @param mixed $parts Parts.
	 * @return mixed
	 */
	public static function title_parts( $parts ) {
		$title = self::title();
		if ( '' !== $title && is_array( $parts ) ) {
			$parts['title'] = $title;
		}
		return $parts;
	}

	/**
	 * Rank Math's title: ours with the site's name.
	 *
	 * @param mixed $title Theirs.
	 * @return mixed
	 */
	public static function plugin_title( $title ) {
		$ours = self::title();
		return '' === $ours ? $title : $ours . ' | ' . ( class_exists( Company::class ) ? Company::trade_name() : get_bloginfo( 'name' ) );
	}

	/**
	 * Rank Math's description of a wine without its own: the tasting notes.
	 *
	 * @param mixed $description Theirs.
	 * @return mixed
	 */
	public static function plugin_description( $description ) {
		if ( ! is_singular( 'product' ) ) {
			return $description;
		}
		$id = (int) get_queried_object_id();
		if ( '' !== trim( (string) get_post_meta( $id, 'rank_math_description', true ) ) ) {
			return $description;
		}
		$tasting = Fields::tasting( Fields::get( $id, Fields::TASTING ) );
		$text    = trim( implode( ' ', array_filter( array( $tasting['nose'], $tasting['mouth'] ) ) ) );
		return '' === $text ? $description : wp_html_excerpt( $text, 155, '…' );
	}
}
