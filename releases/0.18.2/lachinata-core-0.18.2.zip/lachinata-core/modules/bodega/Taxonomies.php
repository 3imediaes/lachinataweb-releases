<?php
/**
 * Taxonomies of the wines.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Bodega;

defined( 'ABSPATH' ) || exit;

/**
 * What serves to filter is a taxonomy (10-bodega.md, «Datos de cada vino»): type, making,
 * winery (with its page), origin (Country › Region › D.O.), grapes and pairing dishes. They
 * live under Productos in the panel; the wine box of the editor fills them. Their terms are
 * content of the site: turning the module off keeps them.
 */
final class Taxonomies {

	public const TYPE   = 'lc_tipo_vino';
	public const MAKING = 'lc_elaboracion';
	public const WINERY = 'lc_bodega';
	public const ORIGIN = 'lc_origen';
	public const GRAPE  = 'lc_uva';
	public const DISH   = 'lc_maridaje';
	public const SEEDED = 'lachinata_bodega_seeded';

	/**
	 * Term meta: the colour of a type (WineType of the system), its serving temperature by
	 * default; the region, web and logo of a winery; the store category a dish suggests.
	 */
	public const TYPE_COLOR    = '_lc_bodega_color';
	public const TYPE_TEMP     = '_lc_bodega_temp';
	public const WINERY_ORIGIN = '_lc_bodega_origin';
	public const WINERY_WEB    = '_lc_bodega_web';
	public const WINERY_LOGO   = '_lc_bodega_logo';
	public const DISH_CATEGORY = '_lc_bodega_category';

	/**
	 * Colours of the system (`lc-wdot--…`).
	 */
	public const COLORS = array( 'tinto', 'blanco', 'rosado', 'espumoso', 'generoso', 'dulce' );

	/**
	 * Every taxonomy of the module.
	 *
	 * @return string[]
	 */
	public static function all(): array {
		return array( self::TYPE, self::MAKING, self::WINERY, self::ORIGIN, self::GRAPE, self::DISH );
	}

	/**
	 * Term meta keys, for «Borrar datos».
	 *
	 * @return string[]
	 */
	public static function meta_keys(): array {
		return array( self::TYPE_COLOR, self::TYPE_TEMP, self::WINERY_ORIGIN, self::WINERY_WEB, self::WINERY_LOGO, self::DISH_CATEGORY );
	}

	/**
	 * Registers the taxonomies on products. Not public: the listing filters by them and the
	 * type and origin pages hang from the Bodega category (Landing).
	 */
	public static function register(): void {
		$names = array(
			self::TYPE   => array( __( 'Tipos de vino', 'lachinata-core' ), __( 'Tipo de vino', 'lachinata-core' ) ),
			self::MAKING => array( __( 'Elaboraciones', 'lachinata-core' ), __( 'Elaboración', 'lachinata-core' ) ),
			self::WINERY => array( __( 'Bodegas', 'lachinata-core' ), __( 'Bodega', 'lachinata-core' ) ),
			self::ORIGIN => array( __( 'Orígenes', 'lachinata-core' ), __( 'Origen', 'lachinata-core' ) ),
			self::GRAPE  => array( __( 'Uvas', 'lachinata-core' ), __( 'Uva', 'lachinata-core' ) ),
			self::DISH   => array( __( 'Maridajes', 'lachinata-core' ), __( 'Maridaje', 'lachinata-core' ) ),
		);
		foreach ( $names as $taxonomy => $label ) {
			register_taxonomy(
				$taxonomy,
				array( 'product' ),
				array(
					'labels'             => array(
						'name'          => $label[0],
						'singular_name' => $label[1],
						'menu_name'     => $label[0],
						/* translators: %s: name of the taxonomy in singular («Bodega»). */
						'add_new_item'  => sprintf( __( 'Añadir %s', 'lachinata-core' ), $label[1] ),
					),
					'public'             => false,
					'publicly_queryable' => false,
					'show_ui'            => true,
					'show_in_menu'       => true,
					'show_in_nav_menus'  => false,
					'show_in_rest'       => true,
					'show_tagcloud'      => false,
					'show_admin_column'  => false,
					'meta_box_cb'        => false,
					'hierarchical'       => self::ORIGIN === $taxonomy,
					'rewrite'            => false,
					'query_var'          => false,
					'capabilities'       => array(
						'manage_terms' => 'manage_product_terms',
						'edit_terms'   => 'edit_product_terms',
						'delete_terms' => 'delete_product_terms',
						'assign_terms' => 'assign_product_terms',
					),
				)
			);
		}
		$meta = array(
			self::TYPE   => array( self::TYPE_COLOR => array( 'string', array( self::class, 'color' ) ) ),
			self::WINERY => array(
				self::WINERY_ORIGIN => array( 'integer', 'absint' ),
				self::WINERY_WEB    => array( 'string', 'esc_url_raw' ),
				self::WINERY_LOGO   => array( 'integer', 'absint' ),
			),
			self::DISH   => array( self::DISH_CATEGORY => array( 'integer', 'absint' ) ),
		);
		foreach ( $meta as $taxonomy => $keys ) {
			foreach ( $keys as $key => $spec ) {
				register_term_meta(
					$taxonomy,
					$key,
					array(
						'type'              => $spec[0],
						'single'            => true,
						'show_in_rest'      => true,
						'sanitize_callback' => $spec[1],
					)
				);
			}
		}
	}

	/**
	 * A colour of the system, or empty.
	 *
	 * @param mixed $value Value.
	 */
	public static function color( $value ): string {
		$value = sanitize_key( (string) $value );
		return in_array( $value, self::COLORS, true ) ? $value : '';
	}

	/**
	 * Colour of a type term: its own or, by default, from its slug or name («Tintos» →
	 * tinto). Empty when it has none.
	 *
	 * @param \WP_Term $term Type term.
	 */
	public static function type_color( \WP_Term $term ): string {
		$color = self::color( get_term_meta( $term->term_id, self::TYPE_COLOR, true ) );
		if ( '' !== $color ) {
			return $color;
		}
		$haystack = sanitize_title( $term->slug . '-' . $term->name );
		foreach ( self::COLORS as $candidate ) {
			if ( str_contains( $haystack, $candidate ) ) {
				return $candidate;
			}
		}
		return '';
	}

	/**
	 * Serving temperature that a type proposes, or null.
	 *
	 * @param \WP_Term $term Type term.
	 * @return array{0: int, 1: int}|null
	 */
	public static function type_temperature( \WP_Term $term ): ?array {
		$stored = get_term_meta( $term->term_id, self::TYPE_TEMP, true );
		if ( is_array( $stored ) && isset( $stored[0], $stored[1] ) && (int) $stored[0] > 0 ) {
			return array( (int) $stored[0], (int) $stored[1] );
		}
		return self::default_temperatures()[ self::type_color( $term ) ] ?? null;
	}

	/**
	 * Usual serving temperature of each colour, in ºC.
	 *
	 * @return array<string, array{0: int, 1: int}>
	 */
	public static function default_temperatures(): array {
		return array(
			'tinto'    => array( 14, 17 ),
			'blanco'   => array( 8, 10 ),
			'rosado'   => array( 8, 10 ),
			'espumoso' => array( 6, 8 ),
			'generoso' => array( 7, 9 ),
			'dulce'    => array( 8, 10 ),
		);
	}

	/**
	 * Creates the default types, makings and dishes once, when their taxonomy is empty.
	 * Their names and slugs can be changed afterwards (the slug of a type is its page:
	 * «…/tintos/»).
	 */
	public static function seed(): void {
		if ( get_option( self::SEEDED ) ) {
			return;
		}
		$seeds = array(
			self::TYPE   => array(
				'tintos'    => __( 'Tinto', 'lachinata-core' ),
				'blancos'   => __( 'Blanco', 'lachinata-core' ),
				'rosados'   => __( 'Rosado', 'lachinata-core' ),
				'espumosos' => __( 'Espumoso', 'lachinata-core' ),
				'generosos' => __( 'Generoso', 'lachinata-core' ),
				'dulces'    => __( 'Dulce', 'lachinata-core' ),
			),
			self::MAKING => array(
				'joven'                 => __( 'Joven', 'lachinata-core' ),
				'roble'                 => __( 'Roble', 'lachinata-core' ),
				'crianza'               => __( 'Crianza', 'lachinata-core' ),
				'reserva'               => __( 'Reserva', 'lachinata-core' ),
				'gran-reserva'          => __( 'Gran reserva', 'lachinata-core' ),
				'fermentado-en-barrica' => __( 'Fermentado en barrica', 'lachinata-core' ),
				'sobre-lias'            => __( 'Sobre lías', 'lachinata-core' ),
				'brut-nature'           => __( 'Brut nature', 'lachinata-core' ),
			),
			self::DISH   => array(
				'carnes-rojas'   => __( 'Carnes rojas', 'lachinata-core' ),
				'carnes-blancas' => __( 'Carnes blancas', 'lachinata-core' ),
				'ibericos'       => __( 'Ibéricos', 'lachinata-core' ),
				'quesos-curados' => __( 'Quesos curados', 'lachinata-core' ),
				'quesos-suaves'  => __( 'Quesos suaves', 'lachinata-core' ),
				'pescados'       => __( 'Pescados', 'lachinata-core' ),
				'mariscos'       => __( 'Mariscos', 'lachinata-core' ),
				'arroces'        => __( 'Arroces', 'lachinata-core' ),
				'pasta'          => __( 'Pasta', 'lachinata-core' ),
				'verduras'       => __( 'Verduras', 'lachinata-core' ),
				'aperitivo'      => __( 'Aperitivo', 'lachinata-core' ),
				'postres'        => __( 'Postres', 'lachinata-core' ),
			),
		);
		foreach ( $seeds as $taxonomy => $terms ) {
			if ( ! taxonomy_exists( $taxonomy ) ) {
				return;
			}
			if ( (int) wp_count_terms(
				array(
					'taxonomy'   => $taxonomy,
					'hide_empty' => false,
				)
			) > 0 ) {
				continue;
			}
			foreach ( $terms as $slug => $name ) {
				$created = wp_insert_term( $name, $taxonomy, array( 'slug' => $slug ) );
				if ( self::TYPE === $taxonomy && is_array( $created ) ) {
					update_term_meta( (int) $created['term_id'], self::TYPE_COLOR, rtrim( (string) preg_replace( '/s$/', '', $slug ) ) );
				}
			}
		}
		update_option( self::SEEDED, 1, false );
	}

	/**
	 * Origin of a term as its chain from the country: «España › Extremadura › Ribera del
	 * Guadiana».
	 *
	 * @param \WP_Term $term Origin term.
	 * @return \WP_Term[] From the root to the term.
	 */
	public static function origin_chain( \WP_Term $term ): array {
		$chain = array( $term );
		foreach ( get_ancestors( $term->term_id, self::ORIGIN, 'taxonomy' ) as $ancestor ) {
			$parent = get_term( (int) $ancestor, self::ORIGIN );
			if ( $parent instanceof \WP_Term ) {
				array_unshift( $chain, $parent );
			}
		}
		return $chain;
	}
}
