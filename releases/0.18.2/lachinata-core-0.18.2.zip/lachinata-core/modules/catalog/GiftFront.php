<?php
/**
 * Composite gifts on the product page and the cards.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

use LaChinata\Core\Contact;
use LaChinata\Core\Hooks;
use LaChinata\Core\Terms;

defined( 'ABSPATH' ) || exit;

/**
 * Answers the theme's filters with the data of a gift: what it holds (GiftSummary and
 * GiftContents), «¿Es para tu empresa?» (BulkCta) and the format line of the cards. Prints
 * nothing itself. Without prices: the products of a gift are part of what is bought.
 */
final class GiftFront {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/product/gift', array( self::class, 'gift' ), 10, 2 );
		Hooks::add_filter( 'lachinata/product/bulk_cta', array( self::class, 'bulk_cta' ), 10, 2 );
		Hooks::add_filter( 'lachinata/product_card/meta', array( self::class, 'card_meta' ), 10, 2 );
	}

	/**
	 * What the gift holds, in its order. A product that no longer exists is left out (the
	 * catalog health warns); an unpublished one stays, without a link.
	 *
	 * @param array<string, mixed>|null|mixed $gift    Current data (null: not a gift).
	 * @param \WC_Product                     $product Product.
	 * @return array{count: int, presentation: string, items: array<int, array{name: string, meta: string, qty: int, image_id: int, tint: string, href: string, description: string, ingredients: string, allergens: string}>, allergens: string, traces: string}|null|mixed
	 */
	public static function gift( $gift, \WC_Product $product ) {
		$rows = Gifts::rows( $product->get_id() );
		if ( ! $rows ) {
			return $gift;
		}
		$items    = array();
		$contains = array();
		$traces   = array();
		foreach ( $rows as $row ) {
			$item = Gifts::product( $row );
			if ( ! $item ) {
				continue;
			}
			$allergens = self::allergens( $item );
			$contains  = array_merge( $contains, $allergens['contains'] );
			$traces    = array_merge( $traces, $allergens['traces'] );
			$content   = Fields::content( $item );
			$items[]   = array(
				'name'        => $item->get_name(),
				'meta'        => null === $content ? '' : $content->label(),
				'qty'         => $row['qty'],
				'image_id'    => (int) $item->get_image_id(),
				'tint'        => Storefront::product_tint( '', $item ),
				'href'        => 'publish' === $item->get_status() && $item->is_visible() ? (string) $item->get_permalink() : '',
				'description' => wp_strip_all_tags( $item->get_short_description() ),
				'ingredients' => self::ingredients( $item ),
				'allergens'   => self::sentence( $allergens['contains'] ),
			);
		}
		if ( ! $items ) {
			return $gift;
		}
		$contains     = self::unique( $contains );
		$presentation = Gifts::presentation( $product->get_id() );
		return array(
			'count'        => (int) array_sum( array_column( $items, 'qty' ) ),
			'presentation' => $presentation ? Terms::name( $presentation ) : '',
			'items'        => $items,
			'allergens'    => self::sentence( $contains ),
			'traces'       => self::sentence( array_udiff( self::unique( $traces ), $contains, 'strcasecmp' ) ),
		);
	}

	/**
	 * «¿Es para tu empresa?» on the products the shop marks (the composite gifts by default):
	 * texts, minimum quantity and the address with the product. Null with WhatsApp chosen and
	 * no number in «Atención al cliente».
	 *
	 * @param array<string, mixed>|null|mixed $cta     Current data (null: not shown).
	 * @param \WC_Product                     $product Product.
	 * @return array{href: string, title: string, text: string, cta: string, min: int, sku: string, channel: string}|null|mixed
	 */
	public static function bulk_cta( $cta, \WC_Product $product ) {
		$bulk = Config::bulk();
		if ( ! self::bulk_applies( $product, $bulk ) ) {
			return $cta;
		}
		$fill = static fn( string $text ): string => strtr(
			$text,
			array(
				'{nombre}' => $product->get_name(),
				'{sku}'    => $product->get_sku(),
				'{min}'    => number_format_i18n( $bulk['min'] ),
			)
		);
		if ( 'whatsapp' === $bulk['destination'] ) {
			$chat = Contact::fill( array() )['whatsapp_url'] ?? '';
			if ( '' === $chat ) {
				return $cta;
			}
			$message = '' !== $bulk['whatsapp_text']
				? $fill( $bulk['whatsapp_text'] )
				: sprintf(
					/* translators: 1: minimum quantity, 2: product name, 3: SKU. */
					__( 'Hola, quiero pedir presupuesto de %1$s o más unidades de %2$s (%3$s).', 'lachinata-core' ),
					number_format_i18n( $bulk['min'] ),
					$product->get_name(),
					$product->get_sku()
				);
			$href = add_query_arg( 'text', rawurlencode( $message ), $chat );
		} else {
			$url  = strtr(
				$bulk['url'],
				array(
					'{nombre}' => rawurlencode( $product->get_name() ),
					'{sku}'    => rawurlencode( $product->get_sku() ),
					'{min}'    => (string) $bulk['min'],
				)
			);
			$href = str_starts_with( $url, '/' ) ? home_url( $url ) : $url;
		}
		return array(
			'href'    => $href,
			'title'   => '' !== $bulk['title'] ? $fill( $bulk['title'] ) : __( '¿Es para tu empresa?', 'lachinata-core' ),
			'text'    => '' !== $bulk['text']
				? $fill( $bulk['text'] )
				/* translators: %s: minimum quantity. */
				: sprintf( __( 'Lo personalizamos con tu marca a partir de %s unidades.', 'lachinata-core' ), number_format_i18n( $bulk['min'] ) ),
			'cta'     => '' !== $bulk['cta'] ? $fill( $bulk['cta'] ) : __( 'Pide presupuesto', 'lachinata-core' ),
			'min'     => $bulk['min'],
			'sku'     => $product->get_sku(),
			'channel' => $bulk['destination'],
		);
	}

	/**
	 * «6 productos · Caja de regalo» in the format line of a gift's card. Counts the stored
	 * units without loading each product (a listing has many cards).
	 *
	 * @param string      $meta    Current line (the unit price).
	 * @param \WC_Product $product Product.
	 */
	public static function card_meta( string $meta, \WC_Product $product ): string {
		$units = Gifts::units( $product->get_id() );
		if ( ! $units ) {
			return $meta;
		}
		$presentation = Gifts::presentation( $product->get_id() );
		/* translators: %s: number of products in a gift. */
		$line = sprintf( _n( '%s producto', '%s productos', $units, 'lachinata-core' ), number_format_i18n( $units ) );
		return esc_html( $presentation ? $line . ' · ' . Terms::name( $presentation ) : $line );
	}

	/**
	 * Whether «¿Es para tu empresa?» goes on a product.
	 *
	 * @param \WC_Product                                        $product Product.
	 * @param array{gifts: bool, categories: string[], min: int} $bulk    Settings.
	 */
	public static function bulk_applies( \WC_Product $product, array $bulk ): bool {
		$id = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();
		if ( $bulk['gifts'] && Gifts::is_gift( $id ) ) {
			return true;
		}
		foreach ( $bulk['categories'] as $slug ) {
			$term = get_term_by( 'slug', $slug, 'product_cat' );
			if ( $term instanceof \WP_Term && ( has_term( $term->term_id, 'product_cat', $id ) || self::in_children( $term->term_id, $id ) ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Ingredients of a product in a gift, as HTML with the allergens underlined. None by
	 * default: they come from La Chinata's application. Never from `_lc_ingredientes`, which
	 * in many products mixes ingredients, nutrition in two languages and storage.
	 *
	 * @param \WC_Product $product Product.
	 */
	public static function ingredients( \WC_Product $product ): string {
		/**
		 * Ingredients of a product, for the summary sheet of the gifts that hold it.
		 *
		 * @since 0.16.0
		 *
		 * @param string      $ingredients HTML with the allergens underlined; '' by default.
		 * @param \WC_Product $product     Product.
		 */
		return wp_kses_post( (string) apply_filters( 'lachinata/catalog/gift_item_ingredients', '', $product ) );
	}

	/**
	 * Allergens of a product: what it contains and its traces. None by default: they come
	 * from La Chinata's application, like the ingredients; never from the ingredients text.
	 *
	 * @param \WC_Product $product Product.
	 * @return array{contains: string[], traces: string[]}
	 */
	public static function allergens( \WC_Product $product ): array {
		/**
		 * Allergens of a product, for the gifts that hold it (and whoever needs them).
		 *
		 * @since 0.16.0
		 *
		 * @param array{contains: string[], traces: string[]} $allergens What it contains and its traces; empty by default.
		 * @param \WC_Product                                 $product   Product.
		 */
		$found = (array) apply_filters(
			'lachinata/catalog/allergens',
			array(
				'contains' => array(),
				'traces'   => array(),
			),
			$product
		);
		$list  = static fn( $value ): array => array_values( array_filter( array_map( static fn( $one ): string => trim( sanitize_text_field( (string) $one ) ), is_array( $value ) ? $value : array() ) ) );
		return array(
			'contains' => $list( $found['contains'] ?? array() ),
			'traces'   => $list( $found['traces'] ?? array() ),
		);
	}

	/**
	 * Whether a product is in a child category of a term.
	 *
	 * @param int $term_id    Category.
	 * @param int $product_id Product.
	 */
	private static function in_children( int $term_id, int $product_id ): bool {
		$children = get_term_children( $term_id, 'product_cat' );
		return is_array( $children ) && $children && has_term( array_map( 'intval', $children ), 'product_cat', $product_id );
	}

	/**
	 * A list without repeats (ignoring case), in the order it came.
	 *
	 * @param string[] $values List.
	 * @return string[]
	 */
	private static function unique( array $values ): array {
		$seen = array();
		foreach ( $values as $one ) {
			$seen[ mb_strtolower( $one ) ] ??= $one;
		}
		return array_values( $seen );
	}

	/**
	 * «pescado, gluten y soja».
	 *
	 * @param string[] $values List.
	 */
	private static function sentence( array $values ): string {
		return $values ? wp_sprintf_l( '%l', array_values( $values ) ) : '';
	}
}
