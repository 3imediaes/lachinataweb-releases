<?php
/**
 * An article or a news item (`/slug/`): title, ArticleMeta (publication always, update only
 * after a real review), the notice of an old news item, «En pocas palabras», photo, the
 * contents from 1,200 words (folding on mobile, fixed column on desktop), the text, the
 * sources, the line of the brand, products of its section and «Sigue leyendo»
 * (Articulo.dc.html, ArticuloDesktop.dc.html).
 *
 * The theme can override it with `lachinata/content/single.php`.
 *
 * @package LaChinata\Core
 */

use LaChinata\Core\Modules\Content\Fields;
use LaChinata\Core\Modules\Content\Freshness;
use LaChinata\Core\Modules\Content\Html;
use LaChinata\Core\Modules\Content\Mentions;
use LaChinata\Core\Modules\Content\Model;
use LaChinata\Core\Modules\Content\Query;
use LaChinata\Core\Modules\Content\Text;
use LaChinata\Core\Modules\Content\Texts;
use LaChinata\Core\Terms;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- The pieces come escaped from Html; the content is the post's, filtered by WordPress.

get_header();
while ( have_posts() ) :
	the_post();
	$lachinata_post = get_post();
	if ( ! $lachinata_post instanceof WP_Post ) {
		continue;
	}
	/** This filter is documented in wp-includes/post-template.php */
	$lachinata_content = (string) apply_filters( 'the_content', get_the_content() ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound, WooCommerce.Commenting.CommentHooks.MissingSinceComment -- WordPress hook.
	$lachinata_words   = (int) get_post_meta( $lachinata_post->ID, Fields::WORDS, true );
	$lachinata_toc     = array();
	if ( $lachinata_words >= Text::TOC_FROM ) {
		$lachinata_anchors = Text::anchors( $lachinata_content );
		$lachinata_content = $lachinata_anchors['html'];
		$lachinata_toc     = count( $lachinata_anchors['items'] ) > 1 ? $lachinata_anchors['items'] : array();
	}
	$lachinata_sources  = get_post_meta( $lachinata_post->ID, Fields::SOURCES, true );
	$lachinata_sources  = is_array( $lachinata_sources ) ? $lachinata_sources : array();
	$lachinata_section  = Model::section_of( $lachinata_post );
	$lachinata_category = null === $lachinata_section ? '' : (string) get_term_meta( Model::root( $lachinata_section )->term_id, Fields::SECTION_PRODUCTS, true );
	$lachinata_category = '' === $lachinata_category ? false : get_term_by( 'slug', $lachinata_category, 'product_cat' );
	// The products the article mentions first; without them, those of its section.
	$lachinata_products  = array_slice(
		array_values(
			array_filter(
				array_map( 'wc_get_product', array_map( 'intval', (array) get_post_meta( $lachinata_post->ID, Fields::MENTIONS, false ) ) ),
				static fn( $item ): bool => $item instanceof WC_Product && 'publish' === $item->get_status() && $item->is_visible()
			)
		),
		0,
		2
	);
	$lachinata_mentioned = (bool) $lachinata_products;
	$lachinata_products  = $lachinata_products ? $lachinata_products : ( $lachinata_category instanceof WP_Term ? wc_get_products(
		array(
			'status'     => 'publish',
			'visibility' => 'catalog',
			'category'   => array( $lachinata_category->slug ),
			'limit'      => 2,
			'orderby'    => 'popularity',
		)
	) : array() );
	$lachinata_more      = Query::related( $lachinata_post, 3 );
	$lachinata_print     = static function () use ( $lachinata_products ): void {
		global $product;
		foreach ( $lachinata_products as $lachinata_product ) {
			$product = $lachinata_product; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound -- The card of WooCommerce reads the global product.
			wc_get_template_part( 'content', 'product' );
		}
	};
	?>
	<div class="lc-entry">
		<div class="lc-container lc-entry__crumbs"><?php get_template_part( 'template-parts/breadcrumb' ); ?></div>
		<div class="lc-container lc-entry__layout<?php echo $lachinata_toc ? ' lc-entry__layout--toc' : ''; ?>">
			<?php if ( $lachinata_toc ) : ?>
				<aside class="lc-entry__toc"><?php echo Html::toc( $lachinata_toc, 'side' ); ?></aside>
			<?php endif; ?>
			<article <?php post_class( 'lc-entry__article' ); ?>>
				<header class="lc-entry__head">
					<h1 class="editorial-h1 lc-entry__title"><?php the_title(); ?></h1>
					<?php echo Html::meta( $lachinata_post ); ?>
				</header>
				<?php
				// The notice of a closed store says enough: without the one of an old news item.
				$lachinata_closed = Mentions::notices( $lachinata_post );
				echo '' !== $lachinata_closed ? $lachinata_closed : Freshness::news_notice( $lachinata_post );
				?>
				<?php echo Html::summary( (string) get_post_meta( $lachinata_post->ID, Fields::SUMMARY, true ) ); ?>
				<?php if ( has_post_thumbnail() ) : ?>
					<figure class="lc-entry__media">
						<?php
						the_post_thumbnail(
							'large',
							array(
								'loading'       => 'eager',
								'fetchpriority' => 'high',
								'sizes'         => '(min-width: 1024px) 680px, 100vw',
							)
						);
						?>
					</figure>
				<?php endif; ?>
				<?php if ( $lachinata_toc ) : ?>
					<div class="lc-entry__toc-mobile"><?php echo Html::toc( $lachinata_toc ); ?></div>
				<?php endif; ?>
				<div class="lc-prose lc-blocks lc-entry__body body"><?php echo $lachinata_content; ?></div>
				<?php if ( $lachinata_sources ) : ?>
					<section class="lc-entry__sources" aria-labelledby="lc-entry-sources">
						<h2 class="h3" id="lc-entry-sources"><?php esc_html_e( 'Fuentes', 'lachinata-core' ); ?></h2>
						<ol class="body-sm">
							<?php foreach ( $lachinata_sources as $lachinata_source ) : ?>
								<li><a href="<?php echo esc_url( (string) ( $lachinata_source['url'] ?? '' ) ); ?>" rel="noopener" target="_blank"><?php echo esc_html( (string) ( $lachinata_source['title'] ?? '' ) ); ?></a></li>
							<?php endforeach; ?>
						</ol>
					</section>
				<?php endif; ?>
				<p class="lc-entry__sign body-sm"><?php echo esc_html( Texts::signature() ); ?></p>
			</article>
			<?php if ( $lachinata_products && ( $lachinata_mentioned || $lachinata_category instanceof WP_Term ) ) : ?>
				<aside class="lc-entry__products" aria-labelledby="lc-entry-products">
					<div class="lc-section">
						<div class="lc-section__titles"><h2 class="h3" id="lc-entry-products"><?php echo esc_html( $lachinata_mentioned || ! $lachinata_category instanceof WP_Term ? __( 'En este artículo', 'lachinata-core' ) : Terms::name( $lachinata_category ) ); ?></h2></div>
						<?php $lachinata_link = ! $lachinata_mentioned && $lachinata_category instanceof WP_Term ? get_term_link( $lachinata_category ) : ''; ?>
						<?php if ( is_string( $lachinata_link ) && '' !== $lachinata_link ) : ?>
							<a href="<?php echo esc_url( $lachinata_link ); ?>" class="lc-section__more label"><?php esc_html_e( 'Ver todo', 'lachinata-core' ); ?><?php echo Html::icon( 'arrow-right', true ); ?></a>
						<?php endif; ?>
					</div>
					<div class="lc-entry__product-grid"><?php $lachinata_print(); ?></div>
				</aside>
			<?php endif; ?>
		</div>
		<?php if ( $lachinata_more ) : ?>
			<section class="lc-container lc-entry__more" aria-labelledby="lc-entry-more">
				<h2 class="h2" id="lc-entry-more"><?php esc_html_e( 'Sigue leyendo', 'lachinata-core' ); ?></h2>
				<div class="lc-entry__more-grid">
					<?php foreach ( $lachinata_more as $lachinata_index => $lachinata_related ) : ?>
						<?php
						echo Html::card(
							$lachinata_related,
							'horizontal',
							array(
								'data-lc-entry' => $lachinata_related->ID,
								'data-lc-list'  => __( 'Sigue leyendo', 'lachinata-core' ),
								'data-lc-index' => $lachinata_index + 1,
							)
						);
						?>
					<?php endforeach; ?>
				</div>
			</section>
		<?php endif; ?>
	</div>
	<?php
endwhile;
get_footer();
