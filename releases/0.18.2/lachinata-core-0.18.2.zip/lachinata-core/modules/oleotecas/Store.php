<?php
/**
 * One store as the rest of the module reads it.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Oleotecas;

use LaChinata\Core\Terms;

defined( 'ABSPATH' ) || exit;

/**
 * The fields of a published store, read once and normalised: what the templates, the JSON,
 * the schema and the REST share.
 *
 * @phpstan-import-type Week from Schedule
 * @phpstan-import-type Special from Schedule
 * @phpstan-type StoreData array{id: int, slug: string, url: string, name: string, title: string, street: string, postcode: string, city: string, region: string, country: string, country_name: string, line: string, lat: float|null, lng: float|null, timezone: string, phone: string, phone_display: string, whatsapp: string, email: string, web: array{url: string, label: string}, social: list<array{network: string, url: string}>, hours: Week, specials: list<Special>, photos: list<int>, text: string, favorites: list<int>, services: list<array{slug: string, name: string}>, zones: list<int>, modified: string}
 */
final class Store {

	/**
	 * The store of a post.
	 *
	 * @param \WP_Post $post Post.
	 * @return StoreData
	 */
	public static function from_post( \WP_Post $post ): array {
		$id      = (int) $post->ID;
		$meta    = static fn( string $key ) => get_post_meta( $id, $key, true );
		$address = Fields::address( $meta( Fields::ADDRESS ) );
		$name    = Fields::text_line( $meta( Fields::NAME ) );
		$name    = '' === $name ? get_the_title( $post ) : $name;
		$phone   = Fields::phone( $meta( Fields::PHONE ) );
		$terms   = get_the_terms( $post, Model::SERVICE );
		$zones   = get_the_terms( $post, Model::ZONE );
		$hours   = $meta( Fields::HOURS );
		return array(
			'id'            => $id,
			'slug'          => $post->post_name,
			'url'           => (string) get_permalink( $post ),
			'name'          => $name,
			'title'         => Texts::store_title( $name ),
			'street'        => $address['street'],
			'postcode'      => $address['postcode'],
			'city'          => $address['city'],
			'region'        => $address['region'],
			'country'       => $address['country'],
			'country_name'  => self::country_name( $address['country'] ),
			'line'          => implode( ' · ', array_filter( array( $address['street'], $address['city'] ) ) ),
			'lat'           => Fields::latitude( $meta( Fields::LAT ) ),
			'lng'           => Fields::longitude( $meta( Fields::LNG ) ),
			'timezone'      => Fields::timezone( $meta( Fields::TIMEZONE ) ),
			'phone'         => $phone,
			'phone_display' => StorePhone::display( $phone, $address['country'] ),
			'whatsapp'      => Fields::phone( $meta( Fields::WHATSAPP ) ),
			'email'         => (string) sanitize_email( (string) $meta( Fields::EMAIL ) ),
			'web'           => Fields::web( $meta( Fields::WEB ) ),
			'social'        => Fields::social( $meta( Fields::SOCIAL ) ),
			'hours'         => Schedule::sanitize_week( $hours ),
			'specials'      => Schedule::sanitize_specials( $meta( Fields::SPECIAL ) ),
			'photos'        => array_values( array_filter( array_map( 'absint', (array) $meta( Fields::PHOTOS ) ) ) ),
			'text'          => trim( (string) $meta( Fields::TEXT ) ),
			'favorites'     => array_values( array_filter( array_map( 'absint', (array) $meta( Fields::FAVORITES ) ) ) ),
			'services'      => is_array( $terms ) ? array_values(
				array_map(
					static fn( \WP_Term $term ): array => array(
						'slug' => $term->slug,
						'name' => Terms::name( $term ),
					),
					$terms
				)
			) : array(),
			'zones'         => is_array( $zones ) ? array_values( array_map( static fn( \WP_Term $term ): int => (int) $term->term_id, $zones ) ) : array(),
			'modified'      => (string) $post->post_modified_gmt,
		);
	}

	/**
	 * Country name in the site's language («España»).
	 *
	 * @param string $code ISO code.
	 */
	public static function country_name( string $code ): string {
		if ( '' === $code || ! function_exists( 'WC' ) || ! WC()->countries ) {
			return $code;
		}
		$countries = WC()->countries->get_countries();
		return html_entity_decode( (string) ( $countries[ $code ] ?? $code ), ENT_QUOTES );
	}

	/**
	 * Whether the store has what a minimal page needs: name, address, coordinates, hours.
	 *
	 * @param array<string, mixed> $store Store.
	 * @phpstan-param StoreData $store
	 */
	public static function complete( array $store ): bool {
		return '' !== $store['street'] && null !== $store['lat'] && null !== $store['lng'] && Schedule::has_hours( $store['hours'] );
	}

	/**
	 * Distance in km between two points (haversine).
	 *
	 * @param float $lat1 Latitude 1.
	 * @param float $lng1 Longitude 1.
	 * @param float $lat2 Latitude 2.
	 * @param float $lng2 Longitude 2.
	 */
	public static function distance( float $lat1, float $lng1, float $lat2, float $lng2 ): float {
		$rad = M_PI / 180;
		$a   = sin( ( $lat2 - $lat1 ) * $rad / 2 ) ** 2 + cos( $lat1 * $rad ) * cos( $lat2 * $rad ) * sin( ( $lng2 - $lng1 ) * $rad / 2 ) ** 2;
		return 6371 * 2 * atan2( sqrt( $a ), sqrt( 1 - $a ) );
	}

	/**
	 * Directions: Google Maps (Apple Maps is chosen in the browser on Apple devices).
	 *
	 * @param array<string, mixed> $store Store.
	 * @phpstan-param StoreData $store
	 */
	public static function directions_url( array $store ): string {
		if ( null === $store['lat'] || null === $store['lng'] ) {
			return add_query_arg( 'query', rawurlencode( $store['title'] . ', ' . $store['line'] ), 'https://www.google.com/maps/search/?api=1' );
		}
		return 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode( $store['lat'] . ',' . $store['lng'] );
	}

	/**
	 * Apple Maps link, with the name.
	 *
	 * @param array<string, mixed> $store Store.
	 * @phpstan-param StoreData $store
	 */
	public static function apple_url( array $store ): string {
		$query = array( 'q' => $store['title'] );
		if ( null !== $store['lat'] && null !== $store['lng'] ) {
			$query['daddr'] = $store['lat'] . ',' . $store['lng'];
		} else {
			$query['daddr'] = $store['line'];
		}
		return 'https://maps.apple.com/?' . http_build_query( $query, '', '&', PHP_QUERY_RFC3986 );
	}

	/**
	 * WhatsApp chat with the opening text of the settings (`{site}` is the shop's domain).
	 *
	 * @param array<string, mixed> $store Store.
	 * @phpstan-param StoreData $store
	 */
	public static function whatsapp_url( array $store ): string {
		if ( '' === $store['whatsapp'] ) {
			return '';
		}
		$text = trim( (string) OleotecasModule::setting( 'whatsapp_text' ) );
		$text = Texts::fill(
			$text,
			array(
				'site' => (string) preg_replace( '/^www\./', '', (string) wp_parse_url( home_url(), PHP_URL_HOST ) ),
				'name' => $store['title'],
			)
		);
		$url  = 'https://wa.me/' . ltrim( $store['whatsapp'], '+' );
		return '' === $text ? $url : $url . '?text=' . rawurlencode( $text );
	}
}
