<?php
/**
 * Names of terms, as they are painted.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core;

defined( 'ABSPATH' ) || exit;

/**
 * WordPress keeps the «&» and the quotes of a term's name as HTML entities («Click &amp;
 * Collect»); whoever paints the name and escapes it shows «&amp;». The name is decoded
 * once and escaped once, for the context where it goes: `html` (text of a page), `attr`
 * (an attribute) or `text` (plain text: JSON-LD, JSON for a script, CSV, the console, or a
 * value that is escaped later). Every module paints term names with it (#48); the theme,
 * which never calls the plugin, has its twin `lachinata_term_name()`.
 */
final class Terms {

	/**
	 * The name of a term for a context.
	 *
	 * @param \WP_Term|string $term    Term, or a name as WordPress keeps it.
	 * @param string          $context `text` (default), `html` or `attr`.
	 */
	public static function name( \WP_Term|string $term, string $context = 'text' ): string {
		$name = html_entity_decode( $term instanceof \WP_Term ? (string) $term->name : $term, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		return match ( $context ) {
			'html'  => esc_html( $name ),
			'attr'  => esc_attr( $name ),
			default => $name,
		};
	}
}
