<?php
/**
 * Styles, scripts and font preloads.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Whether the current view uses the editorial typography (Recoleta).
 */
function lachinata_is_editorial_view(): bool {
	return is_front_page() || is_singular( 'post' ) || is_page_template( 'templates/editorial.php' ) || is_home() || is_category() || is_tag();
}

/**
 * Enqueues the theme styles and script.
 */
function lachinata_enqueue_assets(): void {
	$uri = get_template_directory_uri();

	wp_enqueue_style( 'lachinata-tokens', $uri . '/assets/css/tokens.css', array(), LACHINATA_THEME_VERSION );
	wp_enqueue_style( 'lachinata-components', $uri . '/assets/css/components.css', array( 'lachinata-tokens' ), LACHINATA_THEME_VERSION );
	wp_enqueue_style( 'lachinata-theme', $uri . '/assets/css/theme.css', array( 'lachinata-components' ), LACHINATA_THEME_VERSION );

	if ( function_exists( 'is_checkout' ) && ( is_checkout() || is_account_page() ) ) {
		wp_enqueue_style( 'lachinata-checkout', $uri . '/assets/css/checkout.css', array( 'lachinata-theme' ), LACHINATA_THEME_VERSION );
	}

	$asset_file = get_template_directory() . '/build/theme.asset.php';
	if ( is_readable( $asset_file ) ) {
		$asset = require $asset_file;
		wp_enqueue_script(
			'lachinata-theme',
			$uri . '/build/theme.js',
			$asset['dependencies'],
			$asset['version'],
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
		wp_set_script_translations( 'lachinata-theme', 'lachinata', get_template_directory() . '/languages' );
		// Core registers its packages in the head; on the front end ours are only needed by
		// this deferred script, so they move to the footer and stop blocking the first paint.
		foreach ( $asset['dependencies'] as $dependency ) {
			wp_scripts()->add_data( $dependency, 'group', 1 );
		}
		foreach ( array( 'wp-hooks' ) as $core_dependency ) {
			wp_scripts()->add_data( $core_dependency, 'group', 1 );
		}
		wp_add_inline_script( 'lachinata-theme', 'window.lachinata = ' . wp_json_encode( lachinata_script_data() ) . ';', 'before' );
	}
}
add_action( 'wp_enqueue_scripts', 'lachinata_enqueue_assets' );

/**
 * Data the front-end script needs.
 *
 * @return array<string, mixed>
 */
function lachinata_script_data(): array {
	return array(
		'storeApi'  => esc_url_raw( rest_url( 'wc/store/v1/' ) ),
		'cartUrl'   => function_exists( 'wc_get_cart_url' ) ? esc_url_raw( wc_get_cart_url() ) : '',
		'searchUrl' => esc_url_raw( home_url( '/' ) ),
		'currency'  => function_exists( 'get_woocommerce_currency' ) ? array(
			'decimal'  => wc_get_price_decimal_separator(),
			'thousand' => wc_get_price_thousand_separator(),
			'decimals' => wc_get_price_decimals(),
			'format'   => get_woocommerce_price_format(),
			'symbol'   => html_entity_decode( get_woocommerce_currency_symbol() ),
		) : null,
	);
}

/**
 * Removes what the system replaces: jQuery and WooCommerce's classic front-end
 * scripts and styles. The block checkout keeps its own scripts.
 */
function lachinata_dequeue_assets(): void {
	if ( is_admin() ) {
		return;
	}
	foreach ( array( 'wc-add-to-cart', 'wc-cart-fragments', 'woocommerce', 'wc-single-product', 'wc-add-to-cart-variation', 'wc-cart', 'sourcebuster-js', 'wc-order-attribution', 'zoom', 'flexslider', 'photoswipe', 'photoswipe-ui-default' ) as $handle ) {
		wp_dequeue_script( $handle );
	}
	foreach ( array( 'photoswipe', 'photoswipe-default-skin', 'woocommerce-inline' ) as $handle ) {
		wp_dequeue_style( $handle );
	}
	$needs_blocks = function_exists( 'is_checkout' ) && ( is_checkout() || has_block( 'woocommerce/checkout' ) );
	if ( ! $needs_blocks ) {
		wp_dequeue_style( 'wc-blocks-style' );
		wp_dequeue_style( 'wc-blocks-vendors-style' );
	}
	if ( ! is_singular() || ! comments_open() ) {
		wp_dequeue_script( 'comment-reply' );
	}
	wp_dequeue_style( 'classic-theme-styles' );
}
add_action( 'wp_enqueue_scripts', 'lachinata_dequeue_assets', 100 );

// The system draws every WooCommerce element; its stylesheets are not loaded.
add_filter( 'woocommerce_enqueue_styles', '__return_empty_array' );

/**
 * Whether the current view shows campaign typography (.campaign / .campaign-word), which
 * on the home and pages comes from the content (campaign pattern).
 */
function lachinata_view_has_campaign(): bool {
	$post = is_singular() || is_front_page() ? get_post( get_queried_object_id() ) : null;
	$has  = $post instanceof WP_Post && (bool) preg_match( '/class="[^"]*\bcampaign(-word)?\b/', $post->post_content );
	/**
	 * Whether the current view uses the campaign font (SantElia Script), to preload it.
	 *
	 * @since 0.2.1
	 *
	 * @param bool $has Whether the content has campaign pieces.
	 */
	return (bool) apply_filters( 'lachinata/fonts/campaign', $has );
}

/**
 * Preloads the fonts the first screen needs: DIN always, Recoleta on editorial views,
 * SantElia Script only where there is a campaign piece.
 */
function lachinata_preload_fonts(): void {
	$fonts = array( 'DINPro-Light', 'DINPro-Medium', 'DINPro-Black' );
	if ( lachinata_is_editorial_view() ) {
		$fonts[] = 'Recoleta-Black';
	}
	if ( lachinata_view_has_campaign() ) {
		$fonts[] = 'SantEliaScript-Bold';
	}
	foreach ( $fonts as $font ) {
		printf(
			'<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n",
			esc_url( get_template_directory_uri() . '/assets/fonts/' . $font . '.woff2' )
		);
	}
}
add_action( 'wp_head', 'lachinata_preload_fonts', 1 );

/**
 * Prints the icon sprite once, at the start of the body.
 */
function lachinata_icon_sprite(): void {
	$sprite = get_template_directory() . '/assets/icons/sprite.svg';
	if ( is_readable( $sprite ) ) {
		echo preg_replace( '/<!--.*?-->\s*/s', '', (string) file_get_contents( $sprite ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped, WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Generated file of the theme.
	}
}
add_action( 'wp_body_open', 'lachinata_icon_sprite', 1 );

/**
 * Marks the document as having JavaScript before the first paint (no flash of the
 * no-JS fallbacks such as the «Actualizar bolsa» button).
 */
function lachinata_js_class(): void {
	echo "<script>document.documentElement.classList.add('lc-js');</script>\n";
}
add_action( 'wp_head', 'lachinata_js_class', 0 );

// No emojis in the interface (system rule): WordPress' emoji detection script is not loaded.
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
