<?php
/**
 * Catalog data as the templates need it. Everything that changes between stores
 * (tints, unit price, tabs, seals, badges) comes through lachinata/… filters with a
 * neutral default, so the theme works with plain WooCommerce.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Tint of a product category ('' = no tint, surface-2 / surface-3 backgrounds).
 *
 * @param WP_Term $term Category.
 */
function lachinata_category_tint( WP_Term $term ): string {
	/**
	 * Tint of a product category: cosmetica, aceites, gourmet, regalos, hogar or ''.
	 *
	 * @since 0.2.0
	 *
	 * @param string  $tint Tint ('' by default).
	 * @param WP_Term $term Category.
	 */
	return (string) apply_filters( 'lachinata/category/tint', '', $term );
}

/**
 * Tint of a product.
 *
 * @param WC_Product $product Product.
 */
function lachinata_product_tint( WC_Product $product ): string {
	/**
	 * Tint of a product, used behind its photo and in the cart line.
	 *
	 * @since 0.2.0
	 *
	 * @param string     $tint    Tint ('' by default).
	 * @param WC_Product $product Product.
	 */
	return (string) apply_filters( 'lachinata/product/tint', '', $product );
}

/**
 * Unit price line: «500 ml | 9,33 € / 1 l».
 *
 * @param WC_Product $product Product or variation.
 * @return string HTML.
 */
function lachinata_unit_price( WC_Product $product ): string {
	/**
	 * Content and price per reference quantity of a product or variation.
	 *
	 * @since 0.2.0
	 *
	 * @param string     $html    HTML ('' by default: nothing is shown).
	 * @param WC_Product $product Product or variation.
	 */
	return (string) apply_filters( 'lachinata/product/unit_price', '', $product );
}

/**
 * Price shown for a product: the lowest variation price for variable products.
 *
 * @param WC_Product $product Product.
 * @return string HTML.
 */
function lachinata_display_price( WC_Product $product ): string {
	$price = $product instanceof WC_Product_Variable ? $product->get_variation_price( 'min', true ) : wc_get_price_to_display( $product );
	return wc_price( (float) $price );
}

/**
 * Tax note under prices: WooCommerce's «price display suffix» setting.
 */
function lachinata_price_note(): string {
	$suffix = (string) get_option( 'woocommerce_price_display_suffix', '' );
	return '' === $suffix ? '' : wp_kses_post( $suffix );
}

/**
 * Badges of a product: sale, then product tags (as on the current site), then what
 * modules add. Cards show the first one.
 *
 * @param WC_Product $product Product.
 * @return array<int, array{text: string, tone: string}>
 */
function lachinata_product_badges( WC_Product $product ): array {
	$badges = array();
	if ( $product->is_on_sale() ) {
		$regular  = (float) $product->get_regular_price();
		$sale     = (float) $product->get_sale_price();
		$badges[] = array(
			'text' => $regular > 0 && $sale > 0
				/* translators: %s: discount percentage. */
				? sprintf( __( '-%s %%', 'lachinata' ), number_format_i18n( round( ( 1 - $sale / $regular ) * 100 ) ) )
				: __( 'Oferta', 'lachinata' ),
			'tone' => 'promo',
		);
	}
	$tags = get_the_terms( $product->get_id(), 'product_tag' );
	foreach ( is_array( $tags ) ? $tags : array() as $tag ) {
		$badges[] = array(
			'text' => $tag->name,
			'tone' => '',
		);
	}
	/**
	 * Badges of a product card and product page.
	 *
	 * @since 0.2.0
	 *
	 * @param array<int, array{text: string, tone: string}> $badges  Badges (tone '' = neutral).
	 * @param WC_Product                                    $product Product.
	 */
	return (array) apply_filters( 'lachinata/product_card/badges', $badges, $product );
}

/**
 * Data a ProductCard needs.
 *
 * @param WC_Product $product Product.
 * @return array<string, mixed>
 */
function lachinata_card_data( WC_Product $product ): array {
	$badges = lachinata_product_badges( $product );
	$old    = '';
	if ( $product->is_on_sale() && ! $product->is_type( 'variable' ) ) {
		$old = wc_price( (float) wc_get_price_to_display( $product, array( 'price' => $product->get_regular_price() ) ) );
	}
	return array(
		'id'         => $product->get_id(),
		'name'       => $product->get_name(),
		'href'       => $product->get_permalink(),
		'image_id'   => (int) $product->get_image_id(),
		'tint'       => lachinata_product_tint( $product ),
		'badge'      => $badges[0] ?? null,
		'rating'     => wc_review_ratings_enabled() && $product->get_review_count() ? (float) $product->get_average_rating() : null,
		'reviews'    => (int) $product->get_review_count(),
		'meta'       => lachinata_unit_price( $product ),
		'price'      => lachinata_display_price( $product ),
		'price_from' => $product instanceof WC_Product_Variable && $product->get_variation_price( 'min' ) !== $product->get_variation_price( 'max' ),
		'old'        => $old,
		'sold_out'   => ! $product->is_in_stock(),
		'direct_add' => $product->is_type( 'simple' ) && $product->is_purchasable() && $product->is_in_stock() && ! $product->is_sold_individually(),
	);
}

/**
 * Top-level product categories with their children, in WooCommerce's order.
 * The default «Uncategorized» category is left out by id, not by slug.
 *
 * @return array<int, array{term: WP_Term, tint: string, children: WP_Term[]}>
 */
function lachinata_category_tree(): array {
	static $tree = null;
	if ( null !== $tree ) {
		return $tree;
	}
	$exclude = array( (int) get_option( 'default_product_cat', 0 ) );
	$parents = get_terms(
		array(
			'taxonomy'   => 'product_cat',
			'parent'     => 0,
			'hide_empty' => true,
			'exclude'    => $exclude,
			'orderby'    => 'menu_order',
		)
	);
	$tree    = array();
	foreach ( is_array( $parents ) ? $parents : array() as $parent ) {
		$children = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'parent'     => $parent->term_id,
				'hide_empty' => true,
				'orderby'    => 'menu_order',
			)
		);
		$tree[]   = array(
			'term'     => $parent,
			'tint'     => lachinata_category_tint( $parent ),
			'children' => is_array( $children ) ? $children : array(),
		);
	}
	return $tree;
}

/**
 * Link to a term, or '' on error.
 *
 * @param WP_Term $term Term.
 */
function lachinata_term_url( WP_Term $term ): string {
	$link = get_term_link( $term );
	return is_string( $link ) ? $link : '';
}

/**
 * Product photo as an <img> with width/height, or the category halo when there is none.
 *
 * @param int    $image_id   Attachment id.
 * @param string $size       Image size.
 * @param string $halo_class Halo class (lc-card__halo, lc-line__halo…).
 * @param bool   $eager      Load eagerly (first screen).
 * @param string $sizes      Sizes attribute (rendered width of the image).
 */
function lachinata_product_image( int $image_id, string $size, string $halo_class, bool $eager = false, string $sizes = '' ): string {
	if ( ! $image_id ) {
		return sprintf( '<span class="%s" aria-hidden="true"></span>', esc_attr( $halo_class ) );
	}
	return wp_get_attachment_image(
		$image_id,
		$size,
		false,
		array(
			'alt'           => '',
			'loading'       => $eager ? 'eager' : 'lazy',
			'fetchpriority' => $eager ? 'high' : null,
			'decoding'      => 'async',
			'sizes'         => '' !== $sizes ? $sizes : null,
		)
	);
}
