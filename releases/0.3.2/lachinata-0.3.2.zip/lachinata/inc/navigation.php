<?php
/**
 * Menus as plain data for the system components.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Items of a menu location as a tree.
 *
 * @param string $location Menu location.
 * @return array<int, array{title: string, url: string, text: string, icon: string, current: bool, children: array<int, array<string, mixed>>}>
 */
function lachinata_menu( string $location ): array {
	$locations = get_nav_menu_locations();
	if ( empty( $locations[ $location ] ) ) {
		return array();
	}
	$items = wp_get_nav_menu_items( $locations[ $location ] );
	if ( ! is_array( $items ) ) {
		return array();
	}
	_wp_menu_item_classes_by_context( $items );

	$by_id = array();
	foreach ( $items as $item ) {
		$classes            = array_filter( (array) $item->classes, static fn( $c ): bool => '' !== $c && ! str_starts_with( (string) $c, 'menu-item' ) && ! str_starts_with( (string) $c, 'current' ) );
		$by_id[ $item->ID ] = array(
			'title'    => (string) $item->title,
			'url'      => (string) $item->url,
			'text'     => (string) $item->description,
			'icon'     => $classes ? (string) reset( $classes ) : '',
			'current'  => in_array( 'current-menu-item', (array) $item->classes, true ),
			'parent'   => (int) $item->menu_item_parent,
			'children' => array(),
		);
	}
	$tree = array();
	foreach ( array_reverse( $by_id, true ) as $id => $item ) {
		if ( $item['parent'] && isset( $by_id[ $item['parent'] ] ) ) {
			array_unshift( $by_id[ $item['parent'] ]['children'], $by_id[ $id ] );
		}
	}
	foreach ( $by_id as $item ) {
		if ( ! $item['parent'] ) {
			$tree[] = $item;
		}
	}
	return $tree;
}

/**
 * Category of the current view (archive term or the main category of a product).
 */
function lachinata_current_category(): ?WP_Term {
	if ( is_tax( 'product_cat' ) ) {
		$term = get_queried_object();
		return $term instanceof WP_Term ? $term : null;
	}
	if ( is_singular( 'product' ) ) {
		$terms = get_the_terms( get_queried_object_id(), 'product_cat' );
		return is_array( $terms ) && $terms ? $terms[0] : null;
	}
	return null;
}

/**
 * Top-level ancestor of a category.
 *
 * @param WP_Term $term Category.
 */
function lachinata_root_category( WP_Term $term ): WP_Term {
	$ancestors = get_ancestors( $term->term_id, 'product_cat', 'taxonomy' );
	$root      = $ancestors ? get_term( (int) end( $ancestors ), 'product_cat' ) : $term;
	return $root instanceof WP_Term ? $root : $term;
}

/**
 * Whether the view is a secondary one (AppBar shows «Volver» instead of the menu).
 */
function lachinata_is_secondary_view(): bool {
	return is_singular( 'product' ) || ( function_exists( 'is_account_page' ) && is_account_page() && ! is_page( wc_get_page_id( 'myaccount' ) ) );
}

/**
 * Breadcrumb items: [label, url] with the last one current.
 *
 * @return array<int, array{0: string, 1: string}>
 */
function lachinata_breadcrumb_items(): array {
	$items = array( array( __( 'Inicio', 'lachinata' ), home_url( '/' ) ) );
	$term  = lachinata_current_category();

	if ( is_shop() ) {
		$items[] = array( __( 'Tienda', 'lachinata' ), '' );
		return $items;
	}
	if ( $term ) {
		$ancestors = array_reverse( get_ancestors( $term->term_id, 'product_cat', 'taxonomy' ) );
		foreach ( $ancestors as $ancestor_id ) {
			$ancestor = get_term( $ancestor_id, 'product_cat' );
			if ( $ancestor instanceof WP_Term ) {
				$items[] = array( $ancestor->name, lachinata_term_url( $ancestor ) );
			}
		}
		$items[] = array( $term->name, is_singular( 'product' ) ? lachinata_term_url( $term ) : '' );
	}
	if ( is_singular() && ! is_front_page() ) {
		$items[] = array( get_the_title(), '' );
	} elseif ( is_search() ) {
		$items[] = array( __( 'Búsqueda', 'lachinata' ), '' );
	} elseif ( is_tax() && ! $term ) {
		$items[] = array( single_term_title( '', false ), '' );
	}
	return $items;
}
