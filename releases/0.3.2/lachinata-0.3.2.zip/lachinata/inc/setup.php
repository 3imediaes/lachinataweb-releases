<?php
/**
 * Theme supports, menus and image sizes.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Registers translations and theme supports.
 */
function lachinata_setup(): void {
	load_theme_textdomain( 'lachinata', get_template_directory() . '/languages' );

	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ) );
	add_theme_support( 'editor-styles' );
	add_editor_style( array( 'assets/css/tokens.css', 'assets/css/components.css', 'assets/css/theme.css' ) );
	remove_theme_support( 'core-block-patterns' );

	add_theme_support(
		'woocommerce',
		array(
			'thumbnail_image_width'         => 400,
			'single_image_width'            => 900,
			'gallery_thumbnail_image_width' => 160,
			'product_grid'                  => array(
				'default_columns' => 4,
				'default_rows'    => 3,
			),
		)
	);

	// Per-site texts live in menus (content), not in the theme: title, URL, description
	// and CSS classes of each item cover what the components need.
	register_nav_menus(
		array(
			'promo'   => __( 'Barra de promoción (cada elemento es un mensaje; se alternan)', 'lachinata' ),
			'brand'   => __( 'Marca (cabecera de escritorio: Oleotecas, Blog…)', 'lachinata' ),
			'utility' => __( 'Utilidades del menú lateral (clase CSS = icono: pin, leaf, headset…)', 'lachinata' ),
			'usp'     => __( 'Ventajas (título, descripción = texto, clase CSS = icono: truck, leaf…)', 'lachinata' ),
			'help'    => __( 'Ayuda en la ficha (título = pregunta, descripción = respuesta)', 'lachinata' ),
			'footer'  => __( 'Pie (cada elemento de primer nivel es una columna con sus enlaces)', 'lachinata' ),
			'legal'   => __( 'Legal (pie)', 'lachinata' ),
		)
	);
}
add_action( 'after_setup_theme', 'lachinata_setup' );


/**
 * Product images: 1:1 in cards and gallery.
 */
function lachinata_image_sizes(): void {
	add_image_size( 'lachinata-tile', 800, 1000, true );
	add_image_size( 'lachinata-hero', 1600, 900, true );
}
add_action( 'after_setup_theme', 'lachinata_image_sizes' );

/**
 * Block patterns of the theme (home and brand pages).
 */
function lachinata_pattern_category(): void {
	register_block_pattern_category( 'lachinata', array( 'label' => __( 'La Chinata', 'lachinata' ) ) );
}
add_action( 'init', 'lachinata_pattern_category' );
