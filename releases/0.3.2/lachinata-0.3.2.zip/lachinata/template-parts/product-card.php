<?php
/**
 * ProductCard (compact; «wide» for short lists). Args: product (WC_Product), layout, eager.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_product = $args['product'] ?? null;
if ( ! $lachinata_product instanceof WC_Product ) {
	return;
}
$lachinata_card = lachinata_card_data( $lachinata_product );
$lachinata_wide = 'wide' === ( $args['layout'] ?? 'compact' );
$lachinata_add  = sprintf(
	/* translators: %s: product name. */
	__( 'Añadir %s a la bolsa', 'lachinata' ),
	$lachinata_card['name']
);
?>
<article class="<?php echo esc_attr( lachinata_cx( 'lc-card', $lachinata_wide ? 'lc-card--wide' : '' ) ); ?>">
	<a class="lc-card__media" href="<?php echo esc_url( $lachinata_card['href'] ); ?>" tabindex="-1" aria-hidden="true"<?php echo $lachinata_card['tint'] ? ' style="background: var(--tint-' . esc_attr( $lachinata_card['tint'] ) . ')"' : ''; ?>>
		<?php echo lachinata_product_image( $lachinata_card['image_id'], 'woocommerce_thumbnail', 'lc-card__halo', ! empty( $args['eager'] ), '(min-width: 1024px) 300px, (min-width: 480px) 33vw, 50vw' ); ?>
		<?php
		if ( $lachinata_card['badge'] ) {
			echo lachinata_badge( $lachinata_card['badge']['text'], $lachinata_card['badge']['tone'], 'lc-card__badge' );
		}
		?>
	</a>
	<div class="lc-card__body">
		<?php
		if ( null !== $lachinata_card['rating'] ) {
			echo lachinata_rating( $lachinata_card['rating'], $lachinata_card['reviews'] );
		}
		?>
		<a href="<?php echo esc_url( $lachinata_card['href'] ); ?>" class="lc-card__name h4"><?php echo esc_html( $lachinata_card['name'] ); ?></a>
		<?php if ( $lachinata_card['meta'] ) : ?>
			<span class="lc-card__meta body-sm" data-no-translation><?php echo wp_kses_post( $lachinata_card['meta'] ); ?></span>
		<?php endif; ?>
		<div class="lc-card__foot">
			<?php
			echo lachinata_price(
				array(
					'now' => $lachinata_card['price_from']
						/* translators: %s: lowest price. */
						? sprintf( __( 'Desde %s', 'lachinata' ), $lachinata_card['price'] )
						: $lachinata_card['price'],
					'old' => $lachinata_card['old'],
				)
			);
			if ( $lachinata_card['sold_out'] ) {
				echo lachinata_badge( __( 'Agotado', 'lachinata' ), 'soldout' );
			} elseif ( $lachinata_card['direct_add'] ) {
				// Plain add-to-cart link as no-JS fallback; the script adds through the Store API.
				$lachinata_href = add_query_arg( 'add-to-cart', $lachinata_card['id'], wc_get_cart_url() );
				if ( $lachinata_wide ) {
					echo lachinata_button(
						__( 'Añadir', 'lachinata' ),
						array(
							'variant'   => 'cart',
							'size'      => 'sm',
							'icon_left' => 'bag',
							'href'      => $lachinata_href,
							'class'     => 'lc-card__add',
							'attrs'     => array(
								'data-lc-add' => $lachinata_card['id'],
								'aria-label'  => $lachinata_add,
								'rel'         => 'nofollow',
							),
						)
					);
				} else {
					printf(
						'<a href="%1$s" class="lc-btn lc-btn--cart lc-card__add" aria-label="%2$s" data-lc-add="%3$d" rel="nofollow">%4$s</a>',
						esc_url( $lachinata_href ),
						esc_attr( $lachinata_add ),
						(int) $lachinata_card['id'],
						lachinata_icon( 'plus', array( 'size' => 'sm' ) )
					);
				}
			} else {
				// Variable products open the product page (format chips) instead of adding blindly.
				printf(
					'<a href="%1$s" class="lc-btn lc-btn--cart lc-card__add%5$s" aria-label="%2$s">%3$s%4$s</a>',
					esc_url( $lachinata_card['href'] ),
					/* translators: %s: product name. */
					esc_attr( sprintf( __( 'Elegir formato de %s', 'lachinata' ), $lachinata_card['name'] ) ),
					lachinata_icon( $lachinata_wide ? 'bag' : 'plus', array( 'size' => 'sm' ) ),
					$lachinata_wide ? esc_html__( 'Elegir', 'lachinata' ) : '',
					$lachinata_wide ? ' lc-btn--sm' : ''
				);
			}
			?>
		</div>
	</div>
</article>
