<?php
/**
 * PromoBar: one line; each item of the «promo» menu is a message and they take turns.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

$lachinata_messages = lachinata_menu( 'promo' );
/**
 * Messages of the PromoBar.
 *
 * @since 0.2.0
 *
 * @param array<int, array{title: string, url: string, icon: string}> $messages Items of the «promo» menu.
 */
$lachinata_messages = (array) apply_filters( 'lachinata/promo_bar/messages', $lachinata_messages );
if ( ! $lachinata_messages ) {
	return;
}
?>
<div class="lc-promo body-sm" role="status" data-lc-promo>
	<?php foreach ( $lachinata_messages as $lachinata_index => $lachinata_message ) : ?>
		<span class="lc-promo__msg"<?php echo $lachinata_index ? ' hidden' : ''; ?>>
			<?php echo lachinata_icon( '' !== $lachinata_message['icon'] ? $lachinata_message['icon'] : 'truck', array( 'size' => 'sm' ) ); ?>
			<?php if ( $lachinata_message['url'] && '#' !== $lachinata_message['url'] ) : ?>
				<a href="<?php echo esc_url( $lachinata_message['url'] ); ?>"><?php echo esc_html( $lachinata_message['title'] ); ?></a>
			<?php else : ?>
				<span><?php echo esc_html( $lachinata_message['title'] ); ?></span>
			<?php endif; ?>
		</span>
	<?php endforeach; ?>
</div>
