<?php
/**
 * Orders of the account as cards with a status Badge.
 *
 * @package LaChinata\Theme
 * @var WC_Customer|object $customer_orders Orders result (orders, max_num_pages).
 * @var bool               $has_orders      Whether there are orders.
 * @var int                $current_page    Current page.
 */

defined( 'ABSPATH' ) || exit;

$lachinata_tones = array(
	'completed'  => 'success',
	'processing' => 'info',
	'on-hold'    => 'new',
	'cancelled'  => 'soldout',
	'refunded'   => 'soldout',
	'failed'     => 'promo',
);
?>
<?php if ( $has_orders ) : ?>
	<ul class="lc-orders">
		<?php foreach ( $customer_orders->orders as $lachinata_order_id ) : ?>
			<?php
			$lachinata_order = wc_get_order( $lachinata_order_id );
			if ( ! $lachinata_order instanceof WC_Order ) {
				continue;
			}
			$lachinata_items = $lachinata_order->get_item_count();
			?>
			<li class="lc-order">
				<div class="lc-order__head">
					<a class="h4" href="<?php echo esc_url( $lachinata_order->get_view_order_url() ); ?>">
						<?php
						/* translators: %s: order number. */
						echo esc_html( sprintf( __( 'Pedido %s', 'lachinata' ), $lachinata_order->get_order_number() ) );
						?>
					</a>
					<?php echo lachinata_badge( wc_get_order_status_name( $lachinata_order->get_status() ), $lachinata_tones[ $lachinata_order->get_status() ] ?? '' ); ?>
				</div>
				<p class="body-sm lc-order__meta">
					<time datetime="<?php echo esc_attr( $lachinata_order->get_date_created() ? $lachinata_order->get_date_created()->date( 'c' ) : '' ); ?>"><?php echo esc_html( wc_format_datetime( $lachinata_order->get_date_created() ) ); ?></time>
					·
					<?php
					/* translators: %s: number of items. */
					echo esc_html( sprintf( _n( '%s artículo', '%s artículos', $lachinata_items, 'lachinata' ), number_format_i18n( $lachinata_items ) ) );
					?>
					·
					<span data-no-translation><?php echo wp_kses_post( $lachinata_order->get_formatted_order_total() ); ?></span>
				</p>
				<div class="lc-order__actions">
					<?php foreach ( wc_get_account_orders_actions( $lachinata_order ) as $lachinata_key => $lachinata_action ) : ?>
						<?php
						echo lachinata_button(
							$lachinata_action['name'],
							array(
								'variant' => 'view' === $lachinata_key ? 'secondary' : 'ghost',
								'size'    => 'sm',
								'href'    => $lachinata_action['url'],
							)
						); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped 
						?>
					<?php endforeach; ?>
				</div>
			</li>
		<?php endforeach; ?>
	</ul>
	<?php if ( 1 < $customer_orders->max_num_pages ) : ?>
		<div class="lc-orders__pages">
			<?php if ( 1 !== $current_page ) : ?>
				<?php
				echo lachinata_button(
					__( 'Anteriores', 'lachinata' ),
					array(
						'variant' => 'secondary',
						'href'    => wc_get_endpoint_url( 'orders', (string) ( $current_page - 1 ) ),
					)
				); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped 
				?>
			<?php endif; ?>
			<?php if ( (int) $customer_orders->max_num_pages !== $current_page ) : ?>
				<?php
				echo lachinata_button(
					__( 'Siguientes', 'lachinata' ),
					array(
						'variant' => 'secondary',
						'href'    => wc_get_endpoint_url( 'orders', (string) ( $current_page + 1 ) ),
					)
				); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped 
				?>
			<?php endif; ?>
		</div>
	<?php endif; ?>
<?php else : ?>
	<?php echo lachinata_notice( esc_html__( 'Aún no has hecho ningún pedido.', 'lachinata' ) ); ?>
	<?php
	echo lachinata_button(
		__( 'Ver la tienda', 'lachinata' ),
		array(
			'href' => wc_get_page_permalink( 'shop' ),
			'icon' => 'arrow-right',
		)
	); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped 
	?>
<?php endif; ?>
