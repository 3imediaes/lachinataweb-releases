<?php
/**
 * La Chinata → Actualizaciones.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Admin;

use LaChinata\Core\Plugin;
use LaChinata\Core\Updates\Manifest;
use LaChinata\Core\Updates\Updater;
use LaChinata\Core\VersionCheck;

defined( 'ABSPATH' ) || exit;

/**
 * Installed versions, the newest version of the manifest and «Comprobar ahora».
 */
final class UpdatesTab {

	/**
	 * Action of admin-post.php, also the nonce action.
	 */
	private const ACTION = 'lachinata_check_updates';

	/**
	 * Procedure to publish and update.
	 */
	public const DOCS = 'docs/actualizaciones.md';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_action( 'admin_post_' . self::ACTION, array( self::class, 'check_now' ) );
	}

	/**
	 * Prints the tab.
	 */
	public static function render(): void {
		$manifest = Plugin::instance()->manifest();
		$status   = VersionCheck::status();
		$packages = $manifest->packages();
		$checked  = Manifest::checked_at();
		$theme    = VersionCheck::theme_message( $status['theme'], $status['core_needs_theme'] );
		$core     = '' !== $status['theme_needs_core'] && version_compare( $status['core'], $status['theme_needs_core'], '<' );
		$latest   = is_array( $packages ) ? ( $packages[ Updater::PLUGIN_SLUG ] ?? null ) : null;
		$newer    = null !== $latest && (
			version_compare( $latest->version, $status['core'], '>' )
			|| ( '' !== $status['theme'] && isset( $packages[ Updater::THEME_SLUG ] ) && version_compare( $packages[ Updater::THEME_SLUG ]->version, $status['theme'], '>' ) )
		);
		?>
		<p><?php esc_html_e( 'Las actualizaciones son siempre manuales: cada versión se prueba antes en staging y después se instala aquí desde Escritorio → Actualizaciones.', 'lachinata-core' ); ?></p>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><?php esc_html_e( 'La Chinata Core', 'lachinata-core' ); ?></th>
				<td>
					<?php echo esc_html( $status['core'] ); ?>
					<?php if ( $core ) : ?>
						<?php /* translators: %s: plugin version. */ ?>
						<p class="lc-admin__missing"><?php echo esc_html( sprintf( __( 'El tema necesita La Chinata Core %s o superior.', 'lachinata-core' ), $status['theme_needs_core'] ) ); ?></p>
					<?php endif; ?>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Tema La Chinata', 'lachinata-core' ); ?></th>
				<td>
					<?php
					if ( '' === $status['theme'] ) {
						esc_html_e( 'No instalado', 'lachinata-core' );
					} else {
						echo esc_html( $status['theme'] );
						if ( ! $status['theme_active'] ) {
							echo ' ' . esc_html__( '(instalado, no activo)', 'lachinata-core' );
						}
					}
					?>
					<?php if ( null !== $theme ) : ?>
						<p class="lc-admin__missing"><?php echo esc_html( $theme ); ?></p>
					<?php endif; ?>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Última versión publicada', 'lachinata-core' ); ?></th>
				<td>
					<?php if ( is_wp_error( $packages ) ) : ?>
						<p class="lc-admin__missing"><?php echo esc_html( $packages->get_error_message() ); ?></p>
						<p class="description"><?php esc_html_e( 'Sin manifiesto accesible no se ofrecen actualizaciones, pero la web sigue funcionando igual. Suele deberse a que el servidor no puede salir a internet hacia github.io, a una caída de GitHub Pages o a que el repositorio de distribución se ha movido. Se vuelve a intentar sola en una hora; «Comprobar ahora» lo intenta en el momento.', 'lachinata-core' ); ?></p>
					<?php elseif ( null === $latest ) : ?>
						<p class="lc-admin__missing"><?php esc_html_e( 'El manifiesto no incluye La Chinata Core.', 'lachinata-core' ); ?></p>
					<?php else : ?>
						<?php
						echo esc_html(
							$latest->date
								/* translators: 1: version, 2: date. */
								? sprintf( __( '%1$s, publicada el %2$s', 'lachinata-core' ), $latest->version, wp_date( get_option( 'date_format' ), (int) strtotime( $latest->date . ' 12:00:00' ) ) )
								: $latest->version
						);
						?>
						<?php if ( $newer ) : ?>
							<p><a href="<?php echo esc_url( admin_url( 'update-core.php' ) ); ?>"><?php esc_html_e( 'Hay una versión nueva: instálala en Escritorio → Actualizaciones.', 'lachinata-core' ); ?></a></p>
						<?php else : ?>
							<p class="description"><?php esc_html_e( 'Tienes la última versión.', 'lachinata-core' ); ?></p>
						<?php endif; ?>
						<?php if ( '' !== $latest->notes ) : ?>
							<details class="lc-admin__notes">
								<summary><?php esc_html_e( 'Notas de la versión', 'lachinata-core' ); ?></summary>
								<pre><?php echo esc_html( $latest->notes ); ?></pre>
							</details>
						<?php endif; ?>
					<?php endif; ?>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Manifiesto', 'lachinata-core' ); ?></th>
				<td>
					<code><?php echo esc_html( $manifest->url() ); ?></code>
					<p class="description">
						<?php
						echo esc_html(
							$manifest->prereleases()
								? __( 'Incluye versiones previas (LACHINATA_UPDATE_PRERELEASES).', 'lachinata-core' )
								: __( 'Solo versiones estables.', 'lachinata-core' )
						);
						?>
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Última comprobación', 'lachinata-core' ); ?></th>
				<td><?php echo esc_html( $checked ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $checked ) : __( 'Nunca', 'lachinata-core' ) ); ?></td>
			</tr>
		</table>
		<?php /* translators: %s: path of the document in the repository. */ ?>
		<p class="description"><?php echo esc_html( sprintf( __( 'Procedimiento completo: %s en el repositorio.', 'lachinata-core' ), self::DOCS ) ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>">
			<?php wp_nonce_field( self::ACTION ); ?>
			<?php submit_button( __( 'Comprobar ahora', 'lachinata-core' ), 'secondary' ); ?>
		</form>
		<?php
	}

	/**
	 * Reads the manifest again and refreshes the update offers of WordPress.
	 */
	public static function check_now(): void {
		Screen::check( self::ACTION );
		if ( ! current_user_can( 'update_plugins' ) ) {
			wp_die( esc_html__( 'No tienes permiso para hacer esto.', 'lachinata-core' ), 403 );
		}
		$packages = Plugin::instance()->manifest()->packages( true );
		delete_site_transient( 'update_plugins' );
		delete_site_transient( 'update_themes' );
		wp_update_plugins();
		wp_update_themes();
		if ( is_wp_error( $packages ) ) {
			Screen::flash( 'error', array( $packages->get_error_message() ) );
		} elseif ( isset( $packages[ Updater::PLUGIN_SLUG ] ) ) {
			/* translators: %s: version. */
			Screen::flash( 'success', array( sprintf( __( 'Comprobado. Última versión publicada: %s.', 'lachinata-core' ), $packages[ Updater::PLUGIN_SLUG ]->version ) ) );
		}
		Screen::redirect( 'updates' );
	}
}
