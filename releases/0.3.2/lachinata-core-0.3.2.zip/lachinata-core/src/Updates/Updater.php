<?php
/**
 * Updates of the plugin and the theme from the public version manifest.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Updates;

use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * Offers each version in Dashboard → Updates like any plugin or theme from the directory.
 * Both packages declare `Update URI: https://3imediaes.github.io/lachinataweb-releases/`, so
 * WordPress asks the `update_*_3imediaes.github.io` filters instead of WordPress.org.
 * Downloads are checked against the SHA-256 of the manifest. Updates are always manual.
 */
final class Updater {

	/**
	 * Value of the `Update URI` header of the plugin and the theme.
	 */
	public const UPDATE_URI = Manifest::BASE_URL;

	/**
	 * Plugin slug, also the name of its zip.
	 */
	public const PLUGIN_SLUG = 'lachinata-core';

	/**
	 * Theme slug (directory), also the name of its zip.
	 */
	public const THEME_SLUG = 'lachinata';

	/**
	 * Builds the updater.
	 *
	 * @param Manifest $manifest Version manifest.
	 */
	public function __construct( private Manifest $manifest ) {}

	/**
	 * Registers the hooks.
	 */
	public function boot(): void {
		$host = (string) wp_parse_url( self::UPDATE_URI, PHP_URL_HOST );
		add_filter( 'update_plugins_' . $host, array( $this, 'plugin_update' ), 10, 3 );
		add_filter( 'update_themes_' . $host, array( $this, 'theme_update' ), 10, 3 );
		add_filter( 'upgrader_pre_download', array( $this, 'download' ), 10, 2 );
		add_filter( 'plugins_api', array( $this, 'plugin_information' ), 10, 3 );
		add_filter( 'auto_update_plugin', array( $this, 'no_auto_update_plugin' ), 100, 2 );
		add_filter( 'auto_update_theme', array( $this, 'no_auto_update_theme' ), 100, 2 );
	}

	/**
	 * Basename of this plugin (`lachinata-core/lachinata-core.php`).
	 */
	public static function plugin_file(): string {
		return plugin_basename( LACHINATA_CORE_FILE );
	}

	/**
	 * Update data for this plugin.
	 *
	 * @param array<string, mixed>|false $update      Update data from another filter, or false.
	 * @param array<string, string>      $plugin_data Plugin headers.
	 * @param string                     $plugin_file Plugin basename.
	 * @return array<string, mixed>|false
	 */
	public function plugin_update( $update, $plugin_data, $plugin_file ) {
		if ( self::plugin_file() !== $plugin_file || self::UPDATE_URI !== ( $plugin_data['UpdateURI'] ?? '' ) ) {
			return $update;
		}
		$package = $this->manifest->package( self::PLUGIN_SLUG );
		if ( null === $package ) {
			return $update;
		}
		return array(
			'slug'         => self::PLUGIN_SLUG,
			'version'      => $package->version,
			'url'          => admin_url( 'admin.php?page=lachinata&tab=updates' ),
			'package'      => $package->url,
			'requires_php' => $package->requires['php'] ?? '',
			'requires'     => $package->requires['wordpress'] ?? '',
		);
	}

	/**
	 * Update data for the theme.
	 *
	 * @param array<string, mixed>|false $update     Update data from another filter, or false.
	 * @param array<string, string>      $theme_data Theme headers.
	 * @param string                     $stylesheet Theme directory.
	 * @return array<string, mixed>|false
	 */
	public function theme_update( $update, $theme_data, $stylesheet ) {
		if ( self::THEME_SLUG !== $stylesheet || self::UPDATE_URI !== ( $theme_data['UpdateURI'] ?? '' ) ) {
			return $update;
		}
		$package = $this->manifest->package( self::THEME_SLUG );
		if ( null === $package ) {
			return $update;
		}
		return array(
			'theme'        => self::THEME_SLUG,
			'version'      => $package->version,
			'url'          => admin_url( 'admin.php?page=lachinata&tab=updates' ),
			'package'      => $package->url,
			'requires_php' => $package->requires['php'] ?? '',
			'requires'     => $package->requires['wordpress'] ?? '',
		);
	}

	/**
	 * Downloads zips of the distribution and checks their SHA-256; other packages go through untouched.
	 *
	 * @param mixed  $reply   Result of a previous filter (false to let WordPress download).
	 * @param string $package Package URL.
	 * @return mixed
	 */
	public function download( $reply, $package ) {
		if ( false !== $reply || ! is_string( $package ) || ! str_starts_with( $package, Manifest::base_url() ) ) {
			return $reply;
		}
		$packages = $this->manifest->packages();
		foreach ( is_array( $packages ) ? $packages : array() as $candidate ) {
			if ( $candidate->url === $package ) {
				return Manifest::download( $candidate );
			}
		}
		return new WP_Error( 'lachinata_not_in_manifest', __( 'Esta versión ya no está en el manifiesto de versiones. Pulsa «Comprobar ahora» en WooCommerce → La Chinata → Actualizaciones y vuelve a intentarlo.', 'lachinata-core' ) );
	}

	/**
	 * «View details» of the plugin: version, requirements and notes.
	 *
	 * @param mixed  $result Result of a previous filter.
	 * @param string $action plugins_api action.
	 * @param object $args   Request arguments.
	 * @return mixed
	 */
	public function plugin_information( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || self::PLUGIN_SLUG !== ( $args->slug ?? '' ) ) {
			return $result;
		}
		$package = $this->manifest->package( self::PLUGIN_SLUG );
		if ( null === $package ) {
			return $result;
		}
		$data = get_plugin_data( LACHINATA_CORE_FILE, false, false );
		return (object) array(
			'name'          => $data['Name'],
			'slug'          => self::PLUGIN_SLUG,
			'version'       => $package->version,
			'author'        => $data['Author'],
			'requires'      => $package->requires['wordpress'] ?? '',
			'requires_php'  => $package->requires['php'] ?? '',
			'last_updated'  => $package->date,
			'download_link' => $package->url,
			'sections'      => array(
				'changelog' => wpautop( esc_html( $package->notes ) ),
			),
		);
	}

	/**
	 * Never updates this plugin on its own: each version goes through staging first.
	 *
	 * @param bool|null $update Whether to update.
	 * @param object    $item   Update offer.
	 * @return bool|null
	 */
	public function no_auto_update_plugin( $update, $item ) {
		return self::plugin_file() === ( $item->plugin ?? '' ) ? false : $update;
	}

	/**
	 * Never updates the theme on its own.
	 *
	 * @param bool|null $update Whether to update.
	 * @param object    $item   Update offer.
	 * @return bool|null
	 */
	public function no_auto_update_theme( $update, $item ) {
		return self::THEME_SLUG === ( $item->theme ?? '' ) ? false : $update;
	}
}
