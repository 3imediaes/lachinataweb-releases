<?php
/**
 * Public functions of the plugin: the contract the theme relies on.
 *
 * @package LaChinata\Core
 */

defined( 'ABSPATH' ) || exit;

// Plugins load before the theme, so this is the definition in normal requests. The guard
// only matters when the plugin is activated in a request where the theme's fallback
// (always false) is already loaded.
if ( ! function_exists( 'lachinata_module' ) ) {
	/**
	 * Whether a module is enabled and running on this site.
	 *
	 * @param string $id Module id (catalog, shipping, eta…).
	 */
	function lachinata_module( string $id ): bool {
		return LaChinata\Core\Plugin::instance()->modules()->is_active( $id );
	}
}
