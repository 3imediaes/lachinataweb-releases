<?php
/**
 * Adapter over Octolize's DHL Express Live Rates plugin.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping\Live;

defined( 'ABSPATH' ) || exit;

/**
 * Reads the rate Octolize's own (global) method has already calculated for the package and
 * returns it as a service of the «Tarifa en vivo» instance; the original rate is removed.
 * Octolize keeps its account, packaging and customs settings and its surcharge at 0 %: the
 * surcharge and fallback are the instance's, so they survive the change to MyDHL API.
 *
 * Octolize's method id is configurable with `lachinata/shipping/octolize_method_ids`
 * because it has to be checked against the plugin installed on each site.
 */
final class OctolizeDhlProvider implements RateProvider {

	/**
	 * Provider id.
	 */
	public function id(): string {
		return 'octolize_dhl';
	}

	/**
	 * Provider name.
	 */
	public function label(): string {
		return __( 'DHL Express (plugin de Octolize)', 'lachinata-core' );
	}

	/**
	 * Packaging and customs are set in Octolize.
	 *
	 * @return string[]
	 */
	public function handles(): array {
		return array( 'packaging', 'customs' );
	}

	/**
	 * Reads Octolize's rates.
	 */
	public function reads_existing_rates(): bool {
		return true;
	}

	/**
	 * Method ids of Octolize's DHL Express rates.
	 *
	 * @return string[]
	 */
	public static function method_ids(): array {
		/**
		 * Method ids whose rates the Octolize adapter takes over.
		 *
		 * @since 0.4.0
		 *
		 * @param string[] $ids Method ids (WC_Shipping_Rate::get_method_id()).
		 */
		return (array) apply_filters( 'lachinata/shipping/octolize_method_ids', array( 'flexible_shipping_dhl_express' ) );
	}

	/**
	 * Octolize's rates as services; their ids are consumed.
	 *
	 * @param RateRequest $request Request.
	 */
	public function quote( RateRequest $request ): RateResponse {
		$ids      = self::method_ids();
		$services = array();
		$consumed = array();
		foreach ( $request->existing_rates as $rate_id => $rate ) {
			if ( ! in_array( $rate->get_method_id(), $ids, true ) ) {
				continue;
			}
			$consumed[] = (string) $rate_id;
			$code       = (string) ( $rate->get_meta_data()['service_type'] ?? substr( (string) $rate_id, strrpos( (string) $rate_id, ':' ) + 1 ) );
			$services[] = new Service( '' === $code ? 'dhl' : $code, (string) $rate->get_label(), (float) $rate->get_cost(), $request->currency );
		}
		return new RateResponse( $services, $consumed );
	}
}
