<?php
/**
 * Plugin Name: La Chinata Core
 * Plugin URI: https://lachinata.es
 * Description: Funcionalidad de La Chinata en módulos que se activan por sitio.
 * Version: 0.4.1
 * Requires at least: 6.8
 * Requires PHP: 8.2
 * Requires Plugins: woocommerce
 * WC requires at least: 10.0
 * Author: 3i Media
 * Author URI: https://3imedia.es
 * License: Proprietary
 * Text Domain: lachinata-core
 * Domain Path: /languages
 * Update URI: https://3imediaes.github.io/lachinataweb-releases/
 * LaChinata Theme Min: 0.4.1
 *
 * @package LaChinata\Core
 */

defined( 'ABSPATH' ) || exit;

define( 'LACHINATA_CORE_VERSION', '0.4.1' );
define( 'LACHINATA_CORE_FILE', __FILE__ );
define( 'LACHINATA_CORE_DIR', __DIR__ );

// PSR-4: LaChinata\Core\Foo → src/Foo.php; LaChinata\Core\Modules\Catalog\Foo → modules/catalog/Foo.php.
spl_autoload_register(
	static function ( string $class_name ): void {
		$prefix = 'LaChinata\\Core\\';
		if ( ! str_starts_with( $class_name, $prefix ) ) {
			return;
		}
		$parts = explode( '\\', substr( $class_name, strlen( $prefix ) ) );
		if ( 'Modules' === $parts[0] && count( $parts ) > 2 ) {
			$file = LACHINATA_CORE_DIR . '/modules/' . strtolower( $parts[1] ) . '/' . implode( '/', array_slice( $parts, 2 ) ) . '.php';
		} else {
			$file = LACHINATA_CORE_DIR . '/src/' . implode( '/', $parts ) . '.php';
		}
		if ( is_readable( $file ) ) {
			require $file;
		}
	}
);

require LACHINATA_CORE_DIR . '/includes/functions.php';

register_activation_hook( __FILE__, array( LaChinata\Core\Plugin::class, 'activate' ) );

LaChinata\Core\Plugin::instance()->boot();
