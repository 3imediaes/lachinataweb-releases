<?php
/**
 * Delivery estimates as text.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Eta;

defined( 'ABSPATH' ) || exit;

/**
 * Three forms: the range of a shipping option («Llega jue 24 – vie 25 oct»), the sentence
 * of the product page («Pídelo antes de las 16:00 y lo recibes el jueves 24») and the
 * line of the order («Llega entre el jueves 24 y el viernes 25 de octubre»). Dates with
 * wp_date() and translatable formats.
 */
final class Format {

	/**
	 * Range for a shipping option or the bag.
	 *
	 * @param Estimate $estimate Estimate.
	 */
	public static function range( Estimate $estimate ): string {
		/* translators: date format of a delivery day with month (PHP date()): «vie 25 oct». */
		$with_month = _x( 'D j M', 'delivery range end', 'lachinata-core' );
		if ( $estimate->min == $estimate->max ) { // phpcs:ignore Universal.Operators.StrictComparisons.LooseEqual -- Same date, different objects.
			/* translators: %s: delivery date. */
			return sprintf( __( 'Llega %s', 'lachinata-core' ), self::date( $estimate->min, $with_month ) );
		}
		$same_month = $estimate->min->format( 'Y-m' ) === $estimate->max->format( 'Y-m' );
		return sprintf(
			/* translators: 1: earliest delivery date, 2: latest delivery date. */
			__( 'Llega %1$s – %2$s', 'lachinata-core' ),
			/* translators: date format of a delivery day without month (PHP date()): «jue 24». */
			self::date( $estimate->min, $same_month ? _x( 'D j', 'delivery range start', 'lachinata-core' ) : $with_month ),
			self::date( $estimate->max, $with_month )
		);
	}

	/**
	 * Sentence of the product page, without countdown.
	 *
	 * @param Estimate $estimate Estimate.
	 */
	public static function product( Estimate $estimate ): string {
		$day = self::long_day( $estimate->min );
		if ( null !== $estimate->cutoff ) {
			/* translators: 1: cut-off time, 2: delivery day («jueves 24»). */
			return sprintf( __( 'Pídelo antes de las %1$s y lo recibes el %2$s.', 'lachinata-core' ), wp_date( (string) get_option( 'time_format' ), $estimate->cutoff->getTimestamp() ), $day );
		}
		/* translators: %s: delivery day («lunes 28»). */
		return sprintf( __( 'Pídelo hoy y lo recibes el %s.', 'lachinata-core' ), $day );
	}

	/**
	 * Line for the order confirmation and the emails.
	 *
	 * @param Estimate $estimate Estimate.
	 */
	public static function order( Estimate $estimate ): string {
		/* translators: date format of the order line (PHP date()): «jueves 24 de octubre». */
		$format = _x( 'l j \d\e F', 'order delivery date', 'lachinata-core' );
		if ( $estimate->min == $estimate->max ) { // phpcs:ignore Universal.Operators.StrictComparisons.LooseEqual -- Same date, different objects.
			/* translators: %s: delivery date. */
			return sprintf( __( 'Llega el %s.', 'lachinata-core' ), self::date( $estimate->min, $format ) );
		}
		/* translators: 1: earliest delivery date, 2: latest delivery date. */
		return sprintf( __( 'Llega entre el %1$s y el %2$s.', 'lachinata-core' ), self::date( $estimate->min, $format ), self::date( $estimate->max, $format ) );
	}

	/**
	 * «jueves 24».
	 *
	 * @param \DateTimeImmutable $day Day.
	 */
	public static function long_day( \DateTimeImmutable $day ): string {
		/* translators: date format of a delivery day on the product page (PHP date()): «jueves 24». */
		return self::date( $day, _x( 'l j', 'product delivery day', 'lachinata-core' ) );
	}

	/**
	 * Formats a date at noon (so no time zone shift can change the day).
	 *
	 * @param \DateTimeImmutable $day    Day.
	 * @param string             $format PHP date format.
	 */
	private static function date( \DateTimeImmutable $day, string $format ): string {
		return (string) wp_date( $format, $day->setTime( 12, 0 )->getTimestamp(), $day->getTimezone() );
	}
}
