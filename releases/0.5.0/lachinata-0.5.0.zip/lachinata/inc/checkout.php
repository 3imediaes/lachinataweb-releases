<?php
/**
 * Block checkout: the steps indicator in front of WooCommerce's checkout block.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

/**
 * The three sections of the checkout and the element each one starts at (ids rendered by
 * WooCommerce's checkout block: contact, shipping address, payment).
 *
 * @return array<int, array{label: string, target: string}>
 */
function lachinata_checkout_steps(): array {
	return array(
		array(
			'label'  => __( 'Contacto', 'lachinata' ),
			'target' => 'contact-fields',
		),
		array(
			'label'  => __( 'Envío', 'lachinata' ),
			'target' => 'shipping-fields',
		),
		array(
			'label'  => __( 'Pago', 'lachinata' ),
			'target' => 'payment-method',
		),
	);
}

/**
 * Prints CheckoutSteps in front of the checkout block.
 *
 * @param string               $content Block HTML.
 * @param array<string, mixed> $block   Parsed block.
 */
function lachinata_checkout_steps_block( string $content, array $block ): string {
	if ( 'woocommerce/checkout' !== ( $block['blockName'] ?? '' ) || ! lachinata_is_block_checkout() ) {
		return $content;
	}
	ob_start();
	lachinata_part( 'checkout-steps' );
	return (string) ob_get_clean() . $content;
}
add_filter( 'render_block', 'lachinata_checkout_steps_block', 10, 2 );
