<?php
/**
 * CheckoutSteps: Contacto · Envío · Pago. Not tabs: the three sections are on the page and
 * the indicator follows the scroll (theme/src/js/checkout-steps.js), with a way back to a
 * previous section and never forward. Without JavaScript it shows the first step.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

?>
<ol class="lc-steps caption lc-checkout__steps" data-lc-steps>
	<?php foreach ( lachinata_checkout_steps() as $lachinata_i => $lachinata_step ) : ?>
		<li class="<?php echo esc_attr( lachinata_cx( 'lc-steps__item', 0 === $lachinata_i ? 'lc-steps__item--cur' : '' ) ); ?>" data-lc-step="<?php echo esc_attr( $lachinata_step['target'] ); ?>"<?php echo 0 === $lachinata_i ? ' aria-current="step"' : ''; ?>>
			<span class="lc-steps__dot" aria-hidden="true"><?php echo esc_html( (string) ( $lachinata_i + 1 ) ); ?></span><span><?php echo esc_html( $lachinata_step['label'] ); ?></span>
		</li>
	<?php endforeach; ?>
</ol>
