<?php
/**
 * What the checkout page does not need to load.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Checkout;

use LaChinata\Core\GapLog;

defined( 'ABSPATH' ) || exit;

/**
 * Since WordPress 7.1, `wp-notices` depends on `wp-components` (266 KB gzipped) for its
 * InlineNotices and SnackbarNotices, which it only loads when they are rendered. The block
 * checkout uses the notices store and never renders them, so on the checkout the
 * dependency is dropped, unless another script in the queue needs `wp-components`: then
 * it stays and the gap log says which one. Checked against the queue of each request,
 * right before the footer scripts print (the checkout block enqueues its scripts while
 * the content renders).
 */
final class Assets {

	/**
	 * Package that is not loaded.
	 */
	public const HEAVY = 'wp-components';

	/**
	 * Package that pulls it.
	 */
	public const VIA = 'wp-notices';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_action( 'wp_print_footer_scripts', array( self::class, 'on_footer' ), 1 );
		add_filter( 'wp_resource_hints', array( self::class, 'prefetch' ), 12, 2 );
	}

	/**
	 * With items in the bag, WooCommerce prefetches the checkout's scripts on every page,
	 * `wp-components` included. While no checkout has needed it (nothing in the gap log),
	 * that prefetch goes too.
	 *
	 * @param array<int, string|array<string, string>> $urls          Hints.
	 * @param string                                   $relation_type Relation.
	 * @return array<int, string|array<string, string>>
	 */
	public static function prefetch( array $urls, string $relation_type ): array {
		if ( 'prefetch' !== $relation_type || self::heavy_needed() ) {
			return $urls;
		}
		return array_values(
			array_filter(
				$urls,
				static function ( $hint ): bool {
					$href = is_array( $hint ) ? (string) ( $hint['href'] ?? '' ) : (string) $hint;
					return ! preg_match( '#/wp-includes/js/dist/components(\.min)?\.js#', $href );
				}
			)
		);
	}

	/**
	 * Whether a checkout has needed `wp-components` (an entry in the gap log).
	 */
	public static function heavy_needed(): bool {
		foreach ( array_keys( self::gaps()->all() ) as $signature ) {
			if ( str_starts_with( (string) $signature, 'heavy:' ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Gap log of the module.
	 */
	public static function gaps(): GapLog {
		return new GapLog( 'lachinata_checkout_gaps', 'lachinata-checkout' );
	}

	/**
	 * Checkout form view (not the order-pay and order-received endpoints).
	 */
	public static function is_checkout_form(): bool {
		return function_exists( 'is_checkout' ) && is_checkout() && ! is_checkout_pay_page() && ! is_order_received_page();
	}

	/**
	 * Lightens the checkout before the footer scripts print.
	 */
	public static function on_footer(): void {
		if ( ! self::is_checkout_form() ) {
			return;
		}
		$users = self::lighten( wp_scripts() );
		if ( $users ) {
			self::gaps()->record(
				'heavy:' . implode( ',', $users ),
				sprintf(
					/* translators: 1: script handles, 2: package handle. */
					__( 'En el checkout, %1$s necesita %2$s, que se carga (266 KB). Revisa si ese script hace falta en el checkout.', 'lachinata-core' ),
					implode( ', ', $users ),
					self::HEAVY
				),
				array( 'scripts' => $users )
			);
		}
	}

	/**
	 * Drops `wp-components` from `wp-notices` when nothing else in the queue needs it.
	 *
	 * @param \WP_Scripts $scripts Scripts of the request.
	 * @return string[] Scripts that need `wp-components` (the dependency is kept); empty when it was dropped or there was nothing to do.
	 */
	public static function lighten( \WP_Scripts $scripts ): array {
		$notices = $scripts->query( self::VIA, 'registered' );
		if ( ! $notices instanceof \_WP_Dependency || ! in_array( self::HEAVY, $notices->deps, true ) || in_array( self::HEAVY, $scripts->done, true ) ) {
			return array();
		}
		$users = self::needed_by( $scripts );
		if ( ! $users ) {
			$notices->deps = array_values( array_diff( $notices->deps, array( self::HEAVY ) ) );
		}
		return $users;
	}

	/**
	 * Scripts of the queue (or their dependencies) that need `wp-components`, other than
	 * `wp-notices`. A script that enqueues `wp-components` itself shows as `wp-components`.
	 *
	 * @param \WP_Scripts $scripts Scripts of the request.
	 * @return string[]
	 */
	public static function needed_by( \WP_Scripts $scripts ): array {
		$users = array();
		$seen  = array();
		$stack = array_values( $scripts->queue );
		if ( in_array( self::HEAVY, $stack, true ) ) {
			$users[] = self::HEAVY;
		}
		while ( $stack ) {
			$handle = (string) array_pop( $stack );
			if ( isset( $seen[ $handle ] ) || self::HEAVY === $handle ) {
				continue;
			}
			$seen[ $handle ] = true;
			$dependency      = $scripts->query( $handle, 'registered' );
			if ( ! $dependency instanceof \_WP_Dependency ) {
				continue;
			}
			foreach ( $dependency->deps as $dep ) {
				if ( self::HEAVY === $dep ) {
					if ( self::VIA !== $handle ) {
						$users[] = $handle;
					}
					continue;
				}
				$stack[] = $dep;
			}
		}
		$users = array_values( array_unique( $users ) );
		sort( $users );
		return $users;
	}
}
