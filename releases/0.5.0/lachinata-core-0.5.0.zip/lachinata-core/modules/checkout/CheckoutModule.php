<?php
/**
 * Module `checkout`: the block checkout extended with the system.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Checkout;

use LaChinata\Core\Module;

defined( 'ABSPATH' ) || exit;

/**
 * Extends WooCommerce's block checkout (phase 1 of «Checkout» in 03-implementacion.md):
 * lighter page load, shipping step with our reasons and ways out, fields and texts in the
 * system's voice, saving the customer's details and the room for the gift module. The
 * engine (taxes, shipping, gateways, order) stays in WooCommerce.
 */
final class CheckoutModule extends Module {

	/**
	 * Module id.
	 */
	public function id(): string {
		return 'checkout';
	}

	/**
	 * Module name.
	 */
	public function label(): string {
		return __( 'Checkout', 'lachinata-core' );
	}

	/**
	 * Module description.
	 */
	public function description(): string {
		return __( 'Checkout de bloques de WooCommerce extendido con el sistema: carga más ligera, motivo y salidas cuando no hay envío, textos propios, guardar tus datos y el hueco del regalo.', 'lachinata-core' );
	}

	/**
	 * Version in which the module was added.
	 */
	public function since(): string {
		return '0.5.0';
	}

	/**
	 * Documentation.
	 */
	public function docs(): string {
		return 'plugin/modules/checkout/README.md';
	}

	/**
	 * Requirements.
	 *
	 * @return array{woocommerce: string}
	 */
	public function requires(): array {
		return array( 'woocommerce' => '10.0' );
	}

	/**
	 * Settings: the page of the «Contactar» way out (empty: the button is not shown).
	 *
	 * @return array<string, array{type: 'string', default: string, export: bool}>
	 */
	public function settings(): array {
		return array(
			'contact_url' => array(
				'type'    => 'string',
				'default' => '',
				'export'  => false,
			),
		);
	}

	/**
	 * Registers the hooks.
	 */
	public function boot(): void {
		Assets::boot();
		Address\Autocomplete::boot();
		Account::boot();
		Gateways::boot();
		add_action( 'init', array( self::class, 'register_blocks' ) );
		add_action(
			'woocommerce_blocks_checkout_block_registration',
			static function ( $registry ): void {
				$registry->register( new Integration() );
			}
		);

		if ( is_admin() ) {
			CheckoutTab::boot();
		}
		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::add_command( 'lachinata checkout', CheckoutCommand::class );
		}
	}

	/**
	 * Inner blocks of the checkout (the front end comes from the module's script).
	 */
	public static function register_blocks(): void {
		register_block_type( LACHINATA_CORE_DIR . '/modules/checkout/blocks/after-shipping' );
	}
}
