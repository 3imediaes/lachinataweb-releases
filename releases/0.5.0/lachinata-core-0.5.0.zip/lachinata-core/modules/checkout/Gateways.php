<?php
/**
 * What the gateways load, trimmed to what the checkout uses.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Checkout;

defined( 'ABSPATH' ) || exit;

/**
 * Stripe (WooCommerce Stripe Gateway) and PayPal (WooCommerce PayPal Payments), each with
 * its reason in README.md («Lo que se quita») and the smoke and payment tests that watch it:
 *
 * - Stripe's script for the classic checkout (`wc-stripe-upe-classic`) is also enqueued on
 *   the block checkout, where the block integration does the work; it brings back
 *   WooCommerce's classic checkout and jQuery. Out on the block checkout.
 * - Express checkout is only on the checkout: Stripe's scripts (stripe.js…) go from the
 *   product page and the bag, where Stripe loads them anyway.
 * - The block checkout connects to Stripe early (`preconnect`), as its express buttons are
 *   at the top.
 * - PayPal's block script (`ppcp-checkout-block`) uses jQuery without declaring it; the
 *   theme loads no jQuery, so the dependency is declared here (otherwise «jQuery is not
 *   defined» whenever nothing else on the page brings jQuery).
 * - A PayPal that is not available (not connected yet, or switched off) still loads its SDK
 *   on the checkout and the product page, which fails (no client token, no jQuery): its
 *   scripts go until it is available. That is how a freshly deployed site is before the
 *   gateways are connected, and how the CI runs.
 * - PayPal is a payment method in the payment section (not in the express row): with PayPal
 *   Payments 4.2 (SDK v6) that is WooCommerce's button, which takes the customer to PayPal,
 *   so PayPal's SDK is not loaded on the checkout at all; the button says «Pagar con PayPal»
 *   (PayPal's own filter for it).
 */
final class Gateways {

	/**
	 * Stripe's script for the classic checkout.
	 */
	public const STRIPE_CLASSIC = 'wc-stripe-upe-classic';

	/**
	 * PayPal's script for the block checkout.
	 */
	public const PAYPAL_BLOCK = 'ppcp-checkout-block';

	/**
	 * Origins the Stripe Elements of the checkout load from.
	 */
	public const STRIPE_ORIGINS = array( 'https://js.stripe.com', 'https://api.stripe.com' );

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_action( 'wp_enqueue_scripts', array( self::class, 'dequeue_unavailable' ), 200 );
		// Stripe enqueues its scripts in wp_footer (priority 10), before the footer scripts
		// print (priority 20).
		add_action( 'wp_footer', array( self::class, 'dequeue' ), 15 );
		add_filter( 'wp_resource_hints', array( self::class, 'preconnect' ), 10, 2 );
		add_filter( 'woocommerce_paypal_payments_blocks_payment_method_data', array( self::class, 'paypal_label' ) );
	}

	/**
	 * Stripe's classic checkout script out of the block checkout; Stripe out of the product
	 * page and the bag.
	 */
	public static function dequeue(): void {
		self::dequeue_unavailable();
		if ( Assets::is_checkout_form() ) {
			wp_dequeue_script( self::STRIPE_CLASSIC );
			wp_dequeue_style( self::STRIPE_CLASSIC );
			self::declare_jquery( wp_scripts() );
			return;
		}
		if ( ! self::is_product_or_bag() ) {
			return;
		}
		foreach ( self::stripe_handles( wp_scripts()->queue ) as $handle ) {
			wp_dequeue_script( $handle );
			wp_dequeue_style( $handle );
		}
	}

	/**
	 * PayPal's front-end scripts and styles out while PayPal is not an available gateway.
	 */
	public static function dequeue_unavailable(): void {
		if ( is_admin() || ! class_exists( '\\WooCommerce\\PayPalCommerce\\PPCP' ) || self::paypal_available() ) {
			return;
		}
		foreach ( array( wp_scripts(), wp_styles() ) as $assets ) {
			foreach ( self::paypal_handles( $assets->queue ) as $handle ) {
				$assets->dequeue( $handle );
			}
			// WooCommerce adds the payment methods' scripts as dependencies of its checkout
			// block script: out of the dependencies too.
			foreach ( $assets->registered as $dependency ) {
				$paypal = self::paypal_handles( $dependency->deps );
				if ( $paypal ) {
					$dependency->deps = array_values( array_diff( $dependency->deps, $paypal ) );
				}
			}
		}
	}

	/**
	 * Whether PayPal is an available gateway in this request (connected and on).
	 */
	public static function paypal_available(): bool {
		if ( ! function_exists( 'WC' ) || null === WC()->payment_gateways() ) {
			return false;
		}
		$gateways = WC()->payment_gateways()->payment_gateways();
		$paypal   = $gateways['ppcp-gateway'] ?? null;
		return $paypal instanceof \WC_Payment_Gateway && $paypal->is_available();
	}

	/**
	 * PayPal's handles among the given ones.
	 *
	 * @param string[] $handles Handles.
	 * @return string[]
	 */
	public static function paypal_handles( array $handles ): array {
		return array_values( array_filter( $handles, static fn( string $handle ): bool => (bool) preg_match( '/^(wc-)?ppcp[-_]/', $handle ) ) );
	}

	/**
	 * Adds jQuery to the dependencies of PayPal's block script, which uses it undeclared.
	 *
	 * @param \WP_Scripts $scripts Scripts of the request.
	 */
	public static function declare_jquery( \WP_Scripts $scripts ): void {
		$paypal = $scripts->query( self::PAYPAL_BLOCK, 'registered' );
		if ( $paypal instanceof \_WP_Dependency && ! in_array( 'jquery', $paypal->deps, true ) ) {
			$paypal->deps[] = 'jquery';
		}
	}

	/**
	 * Stripe's handles among the given ones.
	 *
	 * @param string[] $handles Script handles.
	 * @return string[]
	 */
	public static function stripe_handles( array $handles ): array {
		return array_values( array_filter( $handles, static fn( string $handle ): bool => 'stripe' === $handle || (bool) preg_match( '/^wc[-_]stripe/', $handle ) ) );
	}

	/**
	 * Product page or bag (the classic cart page, which is /bolsa/).
	 */
	private static function is_product_or_bag(): bool {
		return ( function_exists( 'is_product' ) && is_product() ) || ( function_exists( 'is_cart' ) && is_cart() );
	}

	/**
	 * `preconnect` to Stripe on the block checkout while Stripe is on.
	 *
	 * @param array<int, string|array<string, string>> $urls          Hints.
	 * @param string                                   $relation_type Relation.
	 * @return array<int, string|array<string, string>>
	 */
	public static function preconnect( array $urls, string $relation_type ): array {
		if ( 'preconnect' !== $relation_type || ! Assets::is_checkout_form() || ! self::stripe_enabled() ) {
			return $urls;
		}
		foreach ( self::STRIPE_ORIGINS as $origin ) {
			$urls[] = array(
				'href'        => $origin,
				'crossorigin' => 'anonymous',
			);
		}
		return $urls;
	}

	/**
	 * Whether Stripe's card gateway is enabled.
	 */
	public static function stripe_enabled(): bool {
		$settings = get_option( 'woocommerce_stripe_settings', array() );
		return is_array( $settings ) && 'yes' === ( $settings['enabled'] ?? 'no' );
	}

	/**
	 * «Pagar con PayPal» on WooCommerce's button when PayPal is chosen.
	 *
	 * @param array<string, mixed> $data Payment method data for the block checkout.
	 * @return array<string, mixed>
	 */
	public static function paypal_label( $data ): array {
		$data                          = is_array( $data ) ? $data : array();
		$data['placeOrderButtonLabel'] = __( 'Pagar con PayPal', 'lachinata-core' );
		return $data;
	}
}
