<?php
/**
 * Script of the module, loaded by WooCommerce's checkout block.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Checkout;

use Automattic\WooCommerce\Blocks\Integrations\IntegrationInterface;
use LaChinata\Core\Plugin;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Registered with `woocommerce_blocks_checkout_block_registration`: WooCommerce loads the
 * script as a dependency of the checkout block (so inner blocks, filters and texts are in
 * place before it renders) and passes get_script_data() as the `lachinata-checkout_data`
 * setting. Also fires `lachinata/checkout/after_shipping`, where other modules (gift)
 * register their fields and scripts; it never prints HTML (the checkout is React).
 */
final class Integration implements IntegrationInterface {

	/**
	 * Script handle.
	 */
	public const HANDLE = 'lachinata-checkout';

	/**
	 * Name of the integration (the setting is `<name>_data`).
	 */
	public function get_name(): string {
		return 'lachinata-checkout';
	}

	/**
	 * Registers the script.
	 */
	public function initialize(): void {
		$dir   = LACHINATA_CORE_DIR . '/modules/checkout/build';
		$asset = is_readable( $dir . '/checkout.asset.php' ) ? require $dir . '/checkout.asset.php' : array(
			'dependencies' => array(),
			'version'      => LACHINATA_CORE_VERSION,
		);
		wp_register_script(
			self::HANDLE,
			plugins_url( 'modules/checkout/build/checkout.js', LACHINATA_CORE_FILE ),
			array_merge( $asset['dependencies'], array( 'wc-blocks-checkout', 'wc-blocks-data-store', 'wc-settings', 'wc-price-format' ) ),
			$asset['version'],
			true
		);
		wp_set_script_translations( self::HANDLE, 'lachinata-core', LACHINATA_CORE_DIR . '/languages' );

		/**
		 * Fires when the block checkout loads the module's script: register here the
		 * checkout fields and scripts that fill the slots `lachinata/checkout/after-shipping`
		 * (after the shipping options) and `lachinata/checkout/summary` (order summary).
		 * Nothing printed here reaches the page: the block checkout is rendered by React.
		 *
		 * @since 0.5.0
		 */
		do_action( 'lachinata/checkout/after_shipping' );
	}

	/**
	 * Scripts for the checkout page.
	 *
	 * @return string[]
	 */
	public function get_script_handles(): array {
		return array( self::HANDLE );
	}

	/**
	 * No editor script: the page is composed by `wp lachinata checkout install-page`.
	 *
	 * @return string[]
	 */
	public function get_editor_script_handles(): array {
		return array();
	}

	/**
	 * Data for the script.
	 *
	 * @return array<string, mixed>
	 */
	public function get_script_data(): array {
		$module = Plugin::instance()->modules()->get( 'checkout' );
		return array(
			'contactUrl'       => null === $module ? '' : esc_url_raw( (string) Settings::get( $module, 'contact_url' ) ),
			'cartUrl'          => esc_url_raw( wc_get_cart_url() ),
			'provinces'        => Provinces::ES,
			'numericPostcodes' => self::numeric_postcodes(),
			'addressLookup'    => Address\Autocomplete::script_data(),
		);
	}

	/**
	 * Countries whose postcodes are only digits: the postcode field gets the numeric keyboard.
	 *
	 * @return string[]
	 */
	public static function numeric_postcodes(): array {
		/**
		 * Countries whose postcodes are only digits (numeric keyboard on mobile).
		 *
		 * @since 0.5.0
		 *
		 * @param string[] $countries ISO codes.
		 */
		return (array) apply_filters( 'lachinata/checkout/numeric_postcodes', array( 'ES', 'FR', 'DE', 'IT', 'AT', 'BE', 'CH', 'DK', 'FI', 'LU', 'NO', 'HR', 'SI', 'BG', 'HU', 'EE', 'LT', 'CY' ) );
	}
}
