<?php
/**
 * Composition of the checkout page.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Checkout;

defined( 'ABSPATH' ) || exit;

/**
 * The checkout page as the system wants it, on top of WooCommerce's default checkout
 * block: the after-shipping block and the order note (delivery instructions) right after
 * the shipping options, express buttons at 44 px with square corners, and one primary
 * button «Pagar 69,85 €» (style `with-price`). Every other inner block keeps its place
 * and attributes. Idempotent.
 */
final class Page {

	/**
	 * Fields area of the checkout.
	 */
	private const FIELDS = 'woocommerce/checkout-fields-block';

	/**
	 * Block after the shipping options (blocks/after-shipping).
	 */
	public const AFTER_SHIPPING = 'lachinata/checkout-after-shipping';

	/**
	 * Attributes the page fixes, by block.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public static function attributes(): array {
		return array(
			'woocommerce/checkout-express-payment-block' => array(
				'showButtonStyles'   => true,
				'buttonHeight'       => '44',
				'buttonBorderRadius' => '0',
			),
			'woocommerce/checkout-actions-block'         => array(
				'placeOrderButtonLabel' => __( 'Pagar', 'lachinata-core' ),
				'priceSeparator'        => ' ',
				'className'             => 'is-style-with-price',
			),
		);
	}

	/**
	 * The composed page.
	 *
	 * @param string $content Current content of the checkout page.
	 * @return string|null Composed content, or null when there is no checkout block.
	 */
	public static function compose( string $content ): ?string {
		$blocks = parse_blocks( $content );
		$found  = false;
		foreach ( $blocks as &$block ) {
			if ( 'woocommerce/checkout' !== $block['blockName'] ) {
				continue;
			}
			foreach ( $block['innerBlocks'] as &$inner ) {
				if ( self::FIELDS === $inner['blockName'] ) {
					$inner = self::fields( $inner );
					$found = true;
				}
			}
			unset( $inner );
		}
		unset( $block );
		return $found ? serialize_blocks( $blocks ) : null;
	}

	/**
	 * The fields area with our blocks in place and the attributes set.
	 *
	 * @param array<string, mixed> $fields Parsed fields block.
	 * @return array<string, mixed>
	 */
	private static function fields( array $fields ): array {
		$note     = null;
		$children = array();
		foreach ( $fields['innerBlocks'] as $child ) {
			if ( self::AFTER_SHIPPING === $child['blockName'] ) {
				continue;
			}
			if ( 'woocommerce/checkout-order-note-block' === $child['blockName'] ) {
				$note = $child;
				continue;
			}
			$children[] = self::with_attributes( $child );
		}

		$composed = array();
		foreach ( $children as $child ) {
			$composed[] = $child;
			if ( 'woocommerce/checkout-shipping-methods-block' === $child['blockName'] ) {
				$composed[] = self::empty_block( self::AFTER_SHIPPING );
				if ( null !== $note ) {
					$composed[] = $note;
					$note       = null;
				}
			}
		}
		if ( null !== $note ) {
			$composed[] = $note;
		}

		$open  = '<div class="wp-block-woocommerce-checkout-fields-block">';
		$inner = array( $open );
		foreach ( array_keys( $composed ) as $i ) {
			if ( $i > 0 ) {
				$inner[] = "\n\n";
			}
			$inner[] = null;
		}
		$inner[] = '</div>';

		$fields['innerBlocks']  = $composed;
		$fields['innerHTML']    = $open . '</div>';
		$fields['innerContent'] = $inner;
		return $fields;
	}

	/**
	 * A block with the page's attributes, its class kept in its HTML.
	 *
	 * @param array<string, mixed> $block Parsed block.
	 * @return array<string, mixed>
	 */
	private static function with_attributes( array $block ): array {
		$fixed = self::attributes()[ $block['blockName'] ] ?? null;
		if ( null === $fixed ) {
			return $block;
		}
		$block['attrs'] = array_merge( (array) $block['attrs'], $fixed );
		$class          = 'wp-block-' . str_replace( '/', '-', (string) $block['blockName'] );
		$class         .= isset( $fixed['className'] ) ? ' ' . $fixed['className'] : '';
		$html           = '<div class="' . esc_attr( $class ) . '"></div>';

		$block['innerHTML']    = $html;
		$block['innerContent'] = array( $html );
		return $block;
	}

	/**
	 * An inner block with no content (its front end is the module's script).
	 *
	 * @param string $name Block name.
	 * @return array<string, mixed>
	 */
	private static function empty_block( string $name ): array {
		$html = '<div class="wp-block-' . str_replace( '/', '-', $name ) . '"></div>';
		return array(
			'blockName'    => $name,
			'attrs'        => array(),
			'innerBlocks'  => array(),
			'innerHTML'    => $html,
			'innerContent' => array( $html ),
		);
	}
}
