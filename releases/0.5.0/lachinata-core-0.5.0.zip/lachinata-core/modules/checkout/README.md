# Módulo `checkout`

Extiende el checkout de bloques de WooCommerce con el sistema (fase 1 de «Checkout» en `design-system/sistema/03-implementacion.md`). El motor (impuestos, envíos, cupones, pasarelas, pedido) se queda en WooCommerce; el módulo no sustituye ningún bloque.

Las piezas nativas (campos, filas de envío y pago, resumen, botones exprés) llevan el HTML de WooCommerce vestido con tokens en `theme/assets/css/checkout.css`; lo propio (pasos, avisos, salidas, hueco de regalo, gracias) lleva el `.lc-*` exacto del sistema. Condición de esa fase 1: el test de humo que vigila las clases de WooCommerce (abajo).

Ajustes (página de «Contactar») y huecos: WooCommerce → La Chinata → Checkout.

## Qué hace

| Pieza | Cómo (API de WooCommerce) | Dónde |
| --- | --- | --- |
| Composición de la página: después de las opciones de envío, nuestro bloque y las instrucciones para el repartidor (la nota del pedido, `customer_note`); botones exprés a 44 px y radio 0; un primario «Pagar 69,85 €» (estilo `with-price` del bloque de acciones, separador espacio) | Atributos de los bloques internos guardados en la página | `Page.php`; `wp lachinata checkout install-page [--dry-run]` (idempotente; el seed lo ejecuta) |
| Bloque `lachinata/checkout-after-shipping`: aviso de la zona, aviso del envío gratis; sin envío, motivo (`Notice`), «Qué puedes hacer» (Dividir el pedido → `/bolsa/`, Cambiar dirección, Contactar; «Quitar de la bolsa» para lo que no viaja) y los envíos que el peso deja fuera, deshabilitados con su motivo (`ShippingOption` `disabled`) | Bloque interno (`registerCheckoutBlock`, `block.json` con padre `checkout-fields-block`); datos de `extensions['lachinata-shipping']` del módulo `shipping` (`StoreApi.php`, ExtendSchema) | `blocks/after-shipping/`, `src/after-shipping.js`, `src/components.js` |
| El motivo de «sin envío» una sola vez | El error de carrito `lachinata_shipping_<causa>` (lo sigue enviando `shipping`, que bloquea el pedido) se quita de los avisos de arriba; el tema oculta el aviso genérico de WooCommerce cuando hay `.lc-checkout-shipping--cause` | `src/notices.js`; `theme/assets/css/checkout.css` |
| Textos en la voz del sistema: títulos Contacto · Dirección de entrega · Envío · Pago, «bolsa» y no «carrito», errores como instrucción, «Pagar» | Filtro `i18n.gettext_woocommerce` de `@wordpress/hooks` sobre las cadenas de origen de WooCommerce | `src/texts.js` |
| Provincia rellenada desde el código postal en España (visible y editable: solo cambia cuando cambian los dos primeros dígitos) | `wc/store/cart` → `setShippingAddress`/`setBillingAddress` | `src/fields.js`, `Provinces.php` |
| Teclado numérico en el código postal (países con códigos solo de cifras, filtro `lachinata/checkout/numeric_postcodes`) y «Solo para la entrega.» bajo el teléfono | **Sin API**: atributo `inputmode` y un `span.lc-field__help` sobre el HTML que pinta WooCommerce | `src/fields.js` |
| «Guardar mis datos»: casilla propia al final (oculta con sesión iniciada); la cuenta se crea cuando el pedido queda pagado (en proceso, en espera o completado), con el correo de WooCommerce para poner la contraseña; los pedidos anteriores de ese correo pasan a la cuenta. La casilla nativa de WooCommerce (Contacto, con contraseña) se apaga. En gracias, a quien no la marcó y no tiene cuenta: «Crear mi cuenta» con un clic | Campo adicional `lachinata/save-details` en `order`; `woocommerce_order_status_*`; `wc_create_new_customer` con contraseña generada; la página de pedido recibido sigue visible una hora con la clave aunque el pedido ya sea de un cliente (`woocommerce_order_received_verify_known_shoppers`), porque el cliente aún no tiene contraseña | `Account.php` |
| Autocompletado de dirección: preparado sin proveedor. Con uno en `lachinata/checkout/address_lookup` (una clase que implemente `Address\AddressLookup`), pasa a ser el proveedor de WooCommerce y el navegador le pregunta a nuestras rutas `lachinata/v1/address/search` y `/select` (límite de 60 por minuto y visitante), nunca al servicio | `woocommerce_address_providers` y `wc.addressAutocomplete.registerAddressAutocompleteProvider` | `Address/`, `src/address.js` |
| Hueco del regalo (incremento 7) | *Slots* `lachinata/checkout/after-shipping` (dentro de nuestro bloque) y `lachinata/checkout/summary` (dentro de `ExperimentalOrderMeta`); acción PHP `lachinata/checkout/after_shipping`, solo para registrar campos y script | `src/after-shipping.js`, `src/summary.js`, `Integration.php` |
| Carga del script | `IntegrationInterface` en `woocommerce_blocks_checkout_block_registration`: WooCommerce lo carga antes de pintar el checkout y le pasa `lachinata-checkout_data` (`wcSettings`) | `Integration.php` |

Del tema (funciona sin el módulo): `CheckoutSteps` delante del bloque, cabecera reducida («Volver a la bolsa», logo, «Pago cifrado»), 7/12 + 5/12 con el resumen fijo y el aspecto de todas las piezas (`theme/assets/css/checkout.css`).

El bloque propio no tiene vista en el editor: la página no se edita a mano, se compone con el comando. Si alguien lo borra en el editor, WooCommerce lo vuelve a añadir al final del área de campos (está bloqueado para borrar); `install-page` lo devuelve a su sitio.

Rellenar un *slot* desde otro módulo:

```js
const { Fill } = wc.blocksCheckout.createSlotFill( 'lachinata/checkout/after-shipping' );
wp.plugins.registerPlugin( 'lachinata-gift', {
	scope: 'woocommerce-checkout',
	render: () => <Fill>{ ( { cart, extensions } ) => <GiftOption … /> }</Fill>,
} );
```

## Lo que se quita del checkout y del resto del sitio

Es la lista de lo que puede romper una actualización de WordPress, WooCommerce o una pasarela. Cada entrada dice por qué se quita y qué lo vigila. El test de humo es `tests/e2e/checkout.spec.mjs` (`npm run test:e2e`, job `e2e` de la CI, obligatorio para fusionar).

| Qué | Dónde | Por qué | Lo vigila |
| --- | --- | --- | --- |
| `wp-components` (266 KB comprimido) como dependencia de `wp-notices`, **solo en el checkout** | `Assets::lighten()`, en `wp_print_footer_scripts` | Desde WordPress 7.1, `wp-notices` depende de `wp-components` para sus `InlineNotices`/`SnackbarNotices`, que solo carga al pintarlos; el checkout de bloques usa el store de avisos y no los pinta. Se comprueba en cada petición sobre la cola: si otro script encolado (o una de sus dependencias) necesita `wp-components`, se queda y queda anotado en Huecos de configuración con el nombre del script. | Test de humo «el checkout se pinta…» (no se carga `components.min.js` y no hay errores en consola); `tests/AssetsTest.php` (la regla de la cola). |
| Precarga de `wp-components` en el resto de páginas | `Assets::prefetch()` | Con artículos en la bolsa, WooCommerce precarga los scripts del checkout en todas las páginas; `wp-components` ya no lo usa el checkout. Vuelve en cuanto un checkout lo haya necesitado (hay una entrada en Huecos de configuración). | Test de humo de la ficha; `tests/AssetsTest.php`. |
| Precargas del bloque de bolsa (`cart-frontend.js` y sus dependencias), **en todo el sitio** | Tema, `theme/inc/assets.php` (`lachinata_drop_cart_block_prefetch()`) | La página de bolsa de WooCommerce contiene el bloque de bolsa, así que WooCommerce lo precarga con la bolsa llena; pero la bolsa es `/bolsa/` (`templates/cart-page.php`) y nunca lo pinta. En el checkout eran 53 ficheros. Las precargas del checkout en el resto de páginas se mantienen. | Test de humo del checkout, de la bolsa y de la ficha (sin `prefetch` de `cart-frontend`). |
| Scripts del checkout clásico en el checkout de bloques (`wc-checkout` y, con él, jQuery, `woocommerce`, `wc-country-select`, `wc-address-i18n`, `wc-custom-place-order-button`, blockUI, js-cookie; `selectWoo`, `wc-address-autocomplete`, `wc-password-strength-meter`) | Tema, `theme/inc/assets.php` (`lachinata_dequeue_assets()`) | El bloque de checkout los quita desde su `render()` (`Checkout::dequeue_woocommerce_core_scripts`), que en un tema clásico se ejecuta después de `wp_enqueue_scripts`: nunca llega a quitarlos. Es la misma lista que usa el bloque. Solo en el formulario de checkout; pagar un pedido y pedido recibido usan las plantillas clásicas y los conservan. | Test de humo del checkout (ni `frontend/checkout.js` ni jQuery). |
| Visor del registro de depuración de Octolize (`wpdesk_wc_shipping_notices_*`) para clientes | Módulo `shipping`, `Live\OctolizeDhlProvider::dequeue_log_viewer()` | Octolize lo carga en la bolsa y el checkout para todos (y en todo el front para gestores), aunque solo los gestores ven el registro; usa jQuery sin declararlo y da un error en el checkout sin jQuery. Los gestores lo conservan. | Test de humo del checkout, la bolsa y la ficha (sin errores y sin su script), en local con Octolize instalado; la CI no instala Octolize. |
| Script de Stripe para el checkout clásico (`wc-stripe-upe-classic`), **en el checkout de bloques** | `Gateways::dequeue()`, en `wp_footer` (Stripe lo encola ahí, prioridad 10) | Stripe lo encola en cualquier checkout; en el de bloques trabaja su integración de bloques (`wc-stripe-blocks-integration`) y este script solo arrastra `wc-checkout` y jQuery. | Test de humo «el checkout se pinta…» (sin `upe-classic` ni `frontend/checkout.js`); `tests/e2e/payments.spec.mjs`: pedido con tarjeta, con 3D Secure y con PayPal (local, con pasarelas). |
| Scripts de Stripe (`stripe.js`, `wc-stripe-*`) **en la ficha y en la bolsa** | `Gateways::dequeue()` | El pago exprés va solo en el checkout (Alberto: ficha y bolsa, apagados; la bolsa queda como opción futura), pero Stripe carga `stripe.js` en las dos igualmente. | Test de humo de la bolsa y de la ficha (ni `js.stripe.com` ni el plugin de Stripe). |
| Scripts y estilos de PayPal (`ppcp-*`, `wc-ppcp-*`) **mientras PayPal no está disponible** (sin conectar o apagado), también como dependencias del script del checkout de bloques | `Gateways::dequeue_unavailable()` | Sin conectar, PayPal carga su SDK v6 en el checkout y la ficha, que falla (token, jQuery). Es el estado de un sitio recién desplegado y de la CI. | Job `e2e` de la CI (Stripe y PayPal activos sin claves): test de humo completo sin errores. |
| (Se añade) jQuery como dependencia de `ppcp-checkout-block` | `Gateways::declare_jquery()` | El script de bloques de PayPal usa jQuery sin declararlo; el tema no carga jQuery. | Test de humo: jQuery solo aparece con el script de PayPal; pedidos de prueba con PayPal. |
| (Se añade) `preconnect` a `js.stripe.com` y `api.stripe.com` en el checkout | `Gateways::preconnect()` | Los botones exprés de Stripe van arriba. | `tests/GatewaysTest.php`. |

Si una actualización hace saltar el test: mira primero qué entrada de la tabla toca. Una clase de `checkout.css` que WooCommerce ya no pinta se quita o se cambia en `checkout.css` (y la tabla de abajo no cambia); un script que vuelve a cargarse se investiga antes de tocar el test.

## Clases de WooCommerce que viste el tema

El test «existen las clases de WooCommerce que viste checkout.css» lee todas las clases `wc-block-*` y `wc-blocks-*` de `theme/assets/css/checkout.css` y exige que cada una aparezca en el DOM del checkout en alguno de sus estados (sin dirección, con errores de validación, con la nota del pedido abierta, con dirección y tarifas) o, si solo existe en otros estados, como literal en los scripts de WooCommerce que carga la página. WooCommerce declara privadas esas clases (`docs/theming/block-theme-development/css-styling.md`): pueden cambiar en cualquier versión.

Primera alarma, al crear el test con WooCommerce 11.2.1: `wc-block-components-combobox` y `wc-block-components-combobox-control` ya no existían (el país es un `select`); se quitaron de `checkout.css`.

## Lo que se toca por encima de WooCommerce sin API

Además de la tabla anterior, dos cosas se hacen sobre el HTML que pinta WooCommerce porque su API de campos no lo permite: `inputmode="numeric"` en el código postal y la ayuda bajo el teléfono (`src/fields.js`). Las vigila el test «provincia desde el código postal, teclado numérico…». Si WooCommerce cambia los ids `shipping-postcode`/`billing-postcode`/`*-phone`, dejan de aplicarse sin romper nada.

## Pasarelas

Configuración de prueba en local con `tools/seed-payments.php` (lee `LACHINATA_DEV_*` de `.wp-env.override.json`, nunca las imprime) y procedimiento en `docs/despliegue-checkout.md`:

- **Stripe:** tarjeta como `PaymentOption` (se monta al cargar: es el método por defecto) y, en la fila exprés, solo Apple Pay y Google Pay, solo en el checkout, a 44 px y con esquinas rectas. Sin Link ni Amazon Pay.
- **PayPal:** solo en la sección de Pago. Con PayPal Payments 4.2 (SDK v6), fuera de la fila exprés PayPal no pinta botón propio: el botón de WooCommerce lleva al cliente a PayPal, y dice «Pagar con PayPal» (`woocommerce_paypal_payments_blocks_payment_method_data`). Por eso su SDK no se carga en el checkout y no hay nada que diferir. Sin Paga Más Tarde ni sus mensajes, que eran lo que cargaba el SDK en ficha y bolsa.
- **Pendiente de decidir:** Stripe también encola en el checkout de bloques `wc_stripe_express_checkout` (su pago exprés para páginas clásicas, con jQuery y lodash); la fila exprés de bloques la registra su integración de bloques. Quitarlo no está aprobado ni se puede comprobar en local (Apple Pay y Google Pay no aparecen en un Chrome sin cartera).
- **Solo desarrollo:** el SDK v6 de PayPal no acepta `localhost` como dominio (`invalid_domain`): en local el sitio va en `http://127.0.0.1.nip.io:8888` y Chrome lo trata como seguro (`--unsafely-treat-insecure-origin-as-secure`, en `playwright.config.mjs` y `tools/lighthouse.mjs`). `WP_BASE_URL=http://127.0.0.1.nip.io:8888 npm run test:e2e`.

## Tests

- PHP: `tests/AssetsTest.php` (regla de `wp-components`), `tests/PageTest.php` (composición idempotente, provincias contra las de WooCommerce), `tests/AccountTest.php` (cuenta tras el pago, sin casilla o con correo existente no hay cuenta, plazo de gracia, casilla nativa apagada, autocompletado solo con proveedor y sus rutas), `tests/GatewaysTest.php` (scripts de Stripe y PayPal, jQuery de PayPal, «Pagar con PayPal», `preconnect`); en `shipping`, `LaChinataEsTest` cubre los datos de la Store API (peso, envíos no disponibles, peso por línea, productos que no viajan).
- Humo (`npm run test:e2e`, sobre el sitio del seed): el checkout se pinta sin errores ni lo que se quita, clases de `checkout.css`, bolsa y ficha, sin envío por peso (motivo una sola vez, salidas, envíos deshabilitados), producto que no viaja («Quitar de la bolsa»), provincia, teclado numérico, pasos, nombre accesible «Pagar 26,26 €», «Guardar mis datos» y gracias, y «Crear mi cuenta» en gracias.
- Pagos (`tests/e2e/payments.spec.mjs`, se saltan sin pasarelas configuradas, como en la CI): fila exprés sin PayPal ni Link y «Pagar con PayPal», tarjeta 4242, tarjeta con 3D Secure 3184 (completa cada reto) y PayPal con el comprador sandbox. Se pasan en local con las claves antes de cada release que toque el checkout o las pasarelas.
- La CI (`e2e`) instala Stripe y PayPal activos sin claves y pasa el test de humo en ese estado.

## Rendimiento

`npm run lighthouse` mide también el checkout con la bolsa llena y una dirección de Plasencia (job informativo `lighthouse` de la CI). Mide con la depuración apagada (`CLAUDE.md`).

| Medición (WooCommerce 11.2.1, WordPress 7.1.3, sin pasarelas) | Rendimiento | LCP | Peso |
| --- | --- | --- | --- |
| Checkout de serie | 67 | 14,2 s | 2.047 KB |
| Sin precargas del bloque de bolsa ni scripts del checkout clásico | 70–75 | 6,7 s | 839 KB |
| Además, sin `wp-components` (lo que hay hoy) | 79 (76–81) | 4,9 s | 529 KB |

Con las pasarelas (23/10/2026, después de las decisiones de Alberto y de lo que quita `Gateways.php`; origen `127.0.0.1.nip.io`, mediana de 5):

| Checkout | Rendimiento | LCP | JS |
| --- | --- | --- | --- |
| Sin pasarelas | 77 (73–78) | 5,3 s | 402 KB |
| Stripe: tarjeta y pago exprés | 67 (64–67) | 7,3 s | 2.507 KB |
| Stripe: tarjeta, sin pago exprés | 61 (55–66) | 7,3 s | 1.485 KB |
| Stripe y PayPal | 66 (64–71) | 7,9 s | 2.493 KB |

| Bolsa con artículos | Rendimiento |
| --- | --- |
| Sin pasarelas | 94 |
| Stripe y PayPal | 96 (antes de quitar Stripe y los mensajes de PayPal de la bolsa: 87) |

El pago exprés (Apple Pay y Google Pay) suma ~1 MB de JS de Stripe pero no mueve la puntuación ni el LCP de forma medible (la diferencia queda dentro de la dispersión). Lo que cuesta es el formulario de tarjeta de Stripe (Payment Element), que se monta al cargar por ser el método por defecto: con él, el checkout no pasa de ~67. PayPal ya no carga nada pesado en el checkout.

Las precargas de WooCommerce se guardan en el transitorio `woocommerce_block_asset_resource_hints`, cuya clave no tiene en cuenta `SCRIPT_DEBUG`: si se generó con la depuración encendida, apuntan a los ficheros sin minificar. Al medir en local tras apagar la depuración: `wp-env run cli wp transient delete woocommerce_block_asset_resource_hints`.
