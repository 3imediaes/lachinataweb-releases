/**
 * Module `checkout`: extensions of WooCommerce's block checkout. Loaded by the checkout
 * block itself (Integration.php), before it renders.
 */
import { initTexts } from './texts';
import { initFields } from './fields';
import { initAddress } from './address';
import { initNotices } from './notices';
import { registerAfterShipping } from './after-shipping';
import { registerSummary } from './summary';

initTexts();
initNotices();
initFields();
initAddress();
registerAfterShipping();
registerSummary();
