/**
 * WooCommerce's texts in the system's voice: «bolsa», not «carrito»; section titles of
 * the system (Contacto · Dirección de entrega · Envío · Pago); errors written as an
 * instruction (Field: «Introduce…», never a reproach). Keys are WooCommerce's source
 * strings; a key that WooCommerce changes simply stops matching.
 */
import { addFilter } from '@wordpress/hooks';
import { __ } from '@wordpress/i18n';

const texts = () => ({
	// Sections.
	'Contact information': __('Contacto', 'lachinata-core'),
	'Shipping address': __('Dirección de entrega', 'lachinata-core'),
	'Shipping options': __('Envío', 'lachinata-core'),
	'Payment options': __('Pago', 'lachinata-core'),
	'Billing address': __('Dirección de facturación', 'lachinata-core'),
	'Use same address for billing': __(
		'Usar la misma dirección para la factura',
		'lachinata-core'
	),
	'Log in': __('Iniciar sesión', 'lachinata-core'),
	'Place Order': __('Pagar', 'lachinata-core'),
	'Enter a shipping address to view shipping options.': __(
		'Escribe tu dirección y te enseñamos los envíos con su fecha de entrega.',
		'lachinata-core'
	),

	// Delivery instructions (the order note, moved to the shipping section).
	'Add a note to your order': __(
		'Añadir instrucciones para el repartidor',
		'lachinata-core'
	),
	'Notes about your order, e.g. special notes for delivery.': __(
		'Por ejemplo: dejar en portería',
		'lachinata-core'
	),
	'Notes about your order.': __(
		'Instrucciones para el repartidor',
		'lachinata-core'
	),

	// Bag.
	Cart: __('Bolsa', 'lachinata-core'),
	'Your cart': __('Tu bolsa', 'lachinata-core'),
	'Your Cart': __('Tu bolsa', 'lachinata-core'),
	'Return to Cart': __('Volver a la bolsa', 'lachinata-core'),
	'Edit your cart': __('Editar la bolsa', 'lachinata-core'),
	'Products in cart': __('Productos de la bolsa', 'lachinata-core'),
	'Loading products in cart…': __('Cargando la bolsa…', 'lachinata-core'),
	/* translators: %s: product name. */
	'Remove %s from cart': __('Quitar %s de la bolsa', 'lachinata-core'),
	/* translators: %s: product name. */
	'Quantity of %s in your cart.': __(
		'Cantidad de %s en tu bolsa.',
		'lachinata-core'
	),
	/* translators: %s: product name. */
	'%s has been removed from your cart.': __(
		'%s se ha quitado de tu bolsa.',
		'lachinata-core'
	),
	/* translators: %s: product name. */
	'"%s" was removed from your cart.': __(
		'«%s» se ha quitado de tu bolsa.',
		'lachinata-core'
	),
	/* translators: %s: coupon code. */
	'Coupon code "%s" has been applied to your cart.': __(
		'Se ha aplicado el código «%s».',
		'lachinata-core'
	),
	/* translators: %s: coupon code. */
	'Coupon code "%s" has been removed from your cart.': __(
		'Se ha quitado el código «%s».',
		'lachinata-core'
	),
	'There is a problem with your cart': __(
		'Hay un problema con tu bolsa',
		'lachinata-core'
	),
	'Please edit your cart and try again.': __(
		'Revisa tu bolsa y vuelve a intentarlo.',
		'lachinata-core'
	),
	"Checkout is not available whilst your cart is empty—please take a look through our store and come back when you're ready to place an order.":
		__(
			'Tu bolsa está vacía. Cuando elijas algo, aquí podrás pagarlo.',
			'lachinata-core'
		),

	// Errors next to the field, as an instruction.
	'Please enter a valid %s':
		/* translators: %s: field label in lower case. */
		__('Completa el campo «%s».', 'lachinata-core'),
	'%s is invalid':
		/* translators: %s: field label. */
		__('Revisa el campo «%s».', 'lachinata-core'),
	'Please enter a valid email address': __(
		'Introduce un correo electrónico válido, como nombre@ejemplo.es.',
		'lachinata-core'
	),
	'Please enter a valid postcode': __(
		'Introduce un código postal válido para el país elegido.',
		'lachinata-core'
	),
	'Please select your country': __('Elige tu país.', 'lachinata-core'),
	'Please select a valid option': __(
		'Elige una de las opciones.',
		'lachinata-core'
	),
	'Please read and accept the terms and conditions.': __(
		'Acepta las condiciones de compra para continuar.',
		'lachinata-core'
	),
});

export function initTexts() {
	let map = null;
	addFilter(
		'i18n.gettext_woocommerce',
		'lachinata/checkout/texts',
		(translation, text) => {
			map ??= texts();
			return map[text] ?? translation;
		}
	);
}
