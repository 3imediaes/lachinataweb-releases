<?php
/**
 * «Guardar mis datos»: an account from the order, never a password in the checkout.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Checkout;

defined( 'ABSPATH' ) || exit;

/**
 * Guest checkout by default. At the end of the checkout a box of ours (additional field in
 * the `order` location, hidden to customers who are logged in) asks to save the details;
 * WooCommerce's own box (in Contacto, with a password) is switched off. The account is
 * created when the order is paid (processing, on hold or completed), not when it is sent,
 * so a failed payment leaves no account; WooCommerce mails the link to set the password.
 * On the thank you page, a guest who did not tick it and has no account gets the offer
 * again (theme hook `lachinata/thankyou/account`).
 */
final class Account {

	/**
	 * Additional checkout field.
	 */
	public const FIELD = 'lachinata/save-details';

	/**
	 * Order meta: `created` once the account exists, `exists` when the email already had one.
	 */
	public const META = '_lc_account';

	/**
	 * Order meta: when the account was created (timestamp).
	 */
	public const META_AT = '_lc_account_at';

	/**
	 * Seconds the order received page stays visible with the order key alone after the
	 * account is created (WooCommerce asks registered customers to log in to see it).
	 */
	public const GRACE = HOUR_IN_SECONDS;

	/**
	 * Nonce action and form field of the offer on the thank you page.
	 */
	private const ACTION = 'lachinata_create_account';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_action( 'woocommerce_init', array( self::class, 'register_field' ) );
		add_filter( 'pre_option_woocommerce_enable_signup_and_login_from_checkout', static fn(): string => 'no' );
		foreach ( array( 'processing', 'on-hold', 'completed' ) as $status ) {
			add_action( 'woocommerce_order_status_' . $status, array( self::class, 'on_paid' ) );
		}
		add_action( 'lachinata/thankyou/account', array( self::class, 'thankyou' ) );
		add_action( 'template_redirect', array( self::class, 'handle_offer' ) );
		add_filter( 'woocommerce_order_received_verify_known_shoppers', array( self::class, 'verify_known_shopper' ) );
	}

	/**
	 * WooCommerce shows a registered customer's order received page only to that customer,
	 * logged in. An account we have just created from the order has no password yet, so for
	 * GRACE seconds the order key in the URL is enough, as for any guest order.
	 *
	 * @param bool $verify Whether to ask for the login.
	 */
	public static function verify_known_shopper( $verify ): bool {
		global $wp;
		$order_id = isset( $wp->query_vars['order-received'] ) ? absint( $wp->query_vars['order-received'] ) : 0;
		$order    = $order_id ? wc_get_order( $order_id ) : null;
		if ( $order instanceof \WC_Order && 'created' === $order->get_meta( self::META ) && time() - (int) $order->get_meta( self::META_AT ) < self::GRACE ) {
			return false;
		}
		return (bool) $verify;
	}

	/**
	 * The box at the end of the checkout.
	 */
	public static function register_field(): void {
		if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
			return;
		}
		woocommerce_register_additional_checkout_field(
			array(
				'id'            => self::FIELD,
				'label'         => __( 'Guardar mis datos para la próxima compra', 'lachinata-core' ),
				// A box is always optional: without «(opcional)».
				'optionalLabel' => __( 'Guardar mis datos para la próxima compra', 'lachinata-core' ),
				'location'      => 'order',
				'type'          => 'checkbox',
				// Hidden when there is a customer: id > 0.
				'hidden'        => array(
					'type'       => 'object',
					'properties' => array(
						'customer' => array(
							'type'       => 'object',
							'properties' => array(
								'id' => array(
									'type'             => 'integer',
									'exclusiveMinimum' => 0,
								),
							),
							'required'   => array( 'id' ),
						),
					),
					'required'   => array( 'customer' ),
				),
			)
		);
	}

	/**
	 * Whether the customer ticked the box in this order.
	 *
	 * @param \WC_Order $order Order.
	 */
	public static function wants_account( \WC_Order $order ): bool {
		return wc_string_to_bool( (string) $order->get_meta( '_wc_other/' . self::FIELD ) );
	}

	/**
	 * Paid order with the box ticked: the account.
	 *
	 * @param int $order_id Order id.
	 */
	public static function on_paid( int $order_id ): void {
		$order = wc_get_order( $order_id );
		if ( $order instanceof \WC_Order && self::wants_account( $order ) ) {
			self::create_for( $order );
		}
	}

	/**
	 * Creates the account of a guest order and links the order (and earlier guest orders
	 * with the same email) to it. Nothing when the order has a customer, the account was
	 * already created or the email has an account.
	 *
	 * @param \WC_Order $order Order.
	 * @return int|null New customer id.
	 */
	public static function create_for( \WC_Order $order ): ?int {
		$email = $order->get_billing_email();
		if ( $order->get_customer_id() || '' !== (string) $order->get_meta( self::META ) || ! is_email( $email ) ) {
			return null;
		}
		if ( email_exists( $email ) ) {
			$order->update_meta_data( self::META, 'exists' );
			$order->save();
			return null;
		}

		// Never a password typed in the checkout: WooCommerce generates it and mails the
		// link to set one, whatever its own setting says.
		$generate = static fn(): string => 'yes';
		add_filter( 'pre_option_woocommerce_registration_generate_password', $generate );
		add_filter( 'pre_option_woocommerce_registration_generate_username', $generate );
		$customer_id = wc_create_new_customer(
			$email,
			'',
			'',
			array(
				'first_name' => $order->get_billing_first_name(),
				'last_name'  => $order->get_billing_last_name(),
			)
		);
		remove_filter( 'pre_option_woocommerce_registration_generate_password', $generate );
		remove_filter( 'pre_option_woocommerce_registration_generate_username', $generate );
		if ( is_wp_error( $customer_id ) ) {
			wc_get_logger()->warning( 'No se pudo crear la cuenta del pedido ' . $order->get_id() . ': ' . $customer_id->get_error_code(), array( 'source' => 'lachinata-checkout' ) );
			return null;
		}

		$customer = new \WC_Customer( $customer_id );
		foreach ( array( 'billing', 'shipping' ) as $type ) {
			foreach ( array( 'first_name', 'last_name', 'company', 'address_1', 'address_2', 'city', 'state', 'postcode', 'country', 'phone' ) as $key ) {
				$getter = "get_{$type}_{$key}";
				$setter = "set_{$type}_{$key}";
				if ( is_callable( array( $order, $getter ) ) && is_callable( array( $customer, $setter ) ) ) {
					$customer->{$setter}( (string) $order->{$getter}() );
				}
			}
		}
		$customer->set_billing_email( $email );
		$customer->save();

		$order->set_customer_id( $customer_id );
		$order->update_meta_data( self::META, 'created' );
		$order->update_meta_data( self::META_AT, (string) time() );
		$order->save();
		wc_update_new_customer_past_orders( $customer_id );
		return $customer_id;
	}

	/**
	 * Thank you page: the account we created, or the offer with one click.
	 *
	 * @param \WC_Order $order Order.
	 */
	public static function thankyou( \WC_Order $order ): void {
		$state = (string) $order->get_meta( self::META );
		if ( 'created' === $state ) {
			printf(
				'<section class="lc-thanks__account lc-thanks__account--done">%s</section>',
				self::notice( __( 'Hemos creado tu cuenta. Te hemos enviado un correo para que pongas tu contraseña.', 'lachinata-core' ), 'success' ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- notice() escapes.
			);
			return;
		}
		if ( $order->get_customer_id() || 'exists' === $state || is_user_logged_in() || email_exists( $order->get_billing_email() ) || $order->has_status( array( 'failed', 'cancelled', 'pending' ) ) ) {
			return;
		}
		?>
		<section class="lc-thanks__account">
			<span class="h4"><?php esc_html_e( 'Guarda tus datos para la próxima vez', 'lachinata-core' ); ?></span>
			<span class="body-sm"><?php esc_html_e( 'Crea tu cuenta con un clic: direcciones guardadas, seguimiento de pedidos y favoritos. Te enviaremos un correo para que pongas tu contraseña.', 'lachinata-core' ); ?></span>
			<form method="post">
				<?php wp_nonce_field( self::ACTION . '_' . $order->get_id(), 'lc_account_nonce' ); ?>
				<input type="hidden" name="lc_account_order" value="<?php echo esc_attr( (string) $order->get_id() ); ?>">
				<button type="submit" class="lc-btn button lc-btn--block"><?php esc_html_e( 'Crear mi cuenta', 'lachinata-core' ); ?></button>
			</form>
		</section>
		<?php
	}

	/**
	 * «Crear mi cuenta» on the thank you page: the order key in the URL proves the visitor
	 * placed the order; the nonce, that the form is ours.
	 */
	public static function handle_offer(): void {
		// phpcs:disable WordPress.Security.NonceVerification -- Verified below.
		if ( ! isset( $_POST['lc_account_order'], $_POST['lc_account_nonce'], $_GET['key'] ) || ! function_exists( 'is_order_received_page' ) || ! is_order_received_page() ) {
			return;
		}
		$order = wc_get_order( absint( $_POST['lc_account_order'] ) );
		$key   = sanitize_text_field( wp_unslash( $_GET['key'] ) );
		// phpcs:enable
		if ( ! $order instanceof \WC_Order || ! hash_equals( $order->get_order_key(), $key ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['lc_account_nonce'] ) ), self::ACTION . '_' . $order->get_id() ) ) {
			return;
		}
		self::create_for( $order );
		wp_safe_redirect( $order->get_checkout_order_received_url() );
		exit;
	}

	/**
	 * Notice HTML: the theme's component when it is there, the same classes otherwise.
	 *
	 * @param string $text Plain text.
	 * @param string $tone Tone.
	 */
	private static function notice( string $text, string $tone ): string {
		if ( function_exists( 'lachinata_notice' ) ) {
			return lachinata_notice( esc_html( $text ), $tone );
		}
		return sprintf( '<div class="lc-notice body-sm lc-notice--%1$s" role="status"><span>%2$s</span></div>', esc_attr( $tone ), esc_html( $text ) );
	}
}
