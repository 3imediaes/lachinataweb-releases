/**
 * Block `lachinata/checkout-after-shipping`, right after the shipping options: the zone
 * notice, the free shipping notice, and when nothing ships, our reason (Notice), what the
 * customer can do (split the order, change the address, contact us; take out the
 * products that cannot travel) and the options the weight limit leaves out, disabled with
 * their reason (ShippingOption). Then the slot of the gift module. Data from the shipping
 * module (`extensions['lachinata-shipping']`, StoreApi.php).
 */
import { useSelect, dispatch } from '@wordpress/data';
import { __ } from '@wordpress/i18n';
import { settings, CART_STORE, CHECKOUT_STORE } from './settings';
import { Notice, Button, DisabledOption } from './components';
import metadata from '../blocks/after-shipping/block.json';

const { registerCheckoutBlock, createSlotFill } = window.wc.blocksCheckout;

/**
 * Slot of the gift module (and anything else that belongs after the shipping options).
 */
export const AfterShippingSlot = createSlotFill(
	'lachinata/checkout/after-shipping'
);

function changeAddress() {
	dispatch(CHECKOUT_STORE).setEditingShippingAddress(true);
	window.requestAnimationFrame(() => {
		const fields = document.getElementById('shipping-fields');
		fields?.scrollIntoView({ behavior: 'smooth', block: 'start' });
		fields?.querySelector('input, select')?.focus({ preventScroll: true });
	});
}

function Outlets({ cause, restricted }) {
	return (
		<div className="lc-checkout__outlets">
			<span className="label">
				{__('Qué puedes hacer', 'lachinata-core')}
			</span>
			{restricted.length > 0 && (
				<ul className="lc-checkout__restricted">
					{restricted.map((item) => (
						<li key={item.key}>
							<span className="body-sm">{item.name}</span>
							<Button
								variant="ghost"
								size="sm"
								onClick={() =>
									dispatch(CART_STORE).removeItemFromCart(
										item.key
									)
								}
							>
								{__('Quitar de la bolsa', 'lachinata-core')}
							</Button>
						</li>
					))}
				</ul>
			)}
			<div className="lc-checkout__actions">
				{cause === 'peso_max' && settings.cartUrl && (
					<Button
						variant="secondary"
						size="sm"
						href={settings.cartUrl}
					>
						{__('Dividir el pedido', 'lachinata-core')}
					</Button>
				)}
				<Button variant="secondary" size="sm" onClick={changeAddress}>
					{__('Cambiar dirección', 'lachinata-core')}
				</Button>
				{settings.contactUrl && (
					<Button
						variant="ghost"
						size="sm"
						iconLeft="headset"
						href={settings.contactUrl}
					>
						{__('Contactar', 'lachinata-core')}
					</Button>
				)}
			</div>
		</div>
	);
}

function AfterShipping() {
	const { data, extensions, cart } = useSelect((select) => {
		const store = select(CART_STORE);
		const cartData = store.getCartData();
		return {
			data: cartData.extensions?.['lachinata-shipping'] ?? null,
			extensions: cartData.extensions,
			cart: cartData,
		};
	}, []);
	const currency = useSelect(
		(select) => select(CART_STORE).getCartTotals(),
		[]
	);

	const shipping = data && (
		<>
			{data.notice && <Notice tone="info">{data.notice}</Notice>}
			{data.cause ? (
				<>
					<Notice
						tone={
							data.cause === 'producto_restringido'
								? 'warning'
								: 'error'
						}
					>
						{data.message}
					</Notice>
					<Outlets
						cause={data.cause}
						restricted={data.restricted || []}
					/>
					{data.unavailable?.length > 0 && (
						<div
							className="lc-checkout__unavailable"
							role="group"
							aria-label={__(
								'Envíos no disponibles',
								'lachinata-core'
							)}
						>
							{data.unavailable.map((rate, i) => (
								<DisabledOption
									key={i}
									id={`lc-unavailable-${i}`}
									title={rate.title}
									price={rate.price}
									currency={currency}
									note={rate.reason}
								/>
							))}
						</div>
					)}
				</>
			) : (
				data.free && (
					<Notice tone={data.free.tone}>{data.free.text}</Notice>
				)
			)}
		</>
	);

	return (
		<div
			className={
				data?.cause
					? 'lc-checkout-shipping lc-checkout-shipping--cause'
					: 'lc-checkout-shipping'
			}
		>
			{shipping}
			<AfterShippingSlot.Slot fillProps={{ cart, extensions }} />
		</div>
	);
}

export function registerAfterShipping() {
	registerCheckoutBlock({ metadata, component: AfterShipping });
}
