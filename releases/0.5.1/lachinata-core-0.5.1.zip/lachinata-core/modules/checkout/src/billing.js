/**
 * Block `lachinata/checkout-billing`, under the payment methods: «Dirección de facturación»
 * with «La misma que la de entrega» (default) and «Usar otra dirección», which shows
 * WooCommerce's billing address block right below. It works for any payment method.
 *
 * WooCommerce keeps that choice as a box inside the delivery address block, set with an
 * internal action of its checkout store (`__internalSetUseShippingAsBilling`). This block
 * uses the same action and hides the box (theme CSS). Known risk (README): if a WooCommerce
 * version removes or renames the action, the block renders nothing, the native box shows
 * again (option A: the billing form still appears under the payment methods) and the gap is
 * recorded in WooCommerce → La Chinata → Checkout → Huecos de configuración.
 */
import { useSelect, dispatch, select } from '@wordpress/data';
import { useEffect, useRef } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { settings, CART_STORE, CHECKOUT_STORE } from './settings';
import metadata from '../blocks/billing/block.json';

const { registerCheckoutBlock } = window.wc.blocksCheckout;

/**
 * Whether WooCommerce still has the internal action.
 */
export function hasBillingAction() {
	const actions = dispatch(CHECKOUT_STORE);
	return (
		!!actions &&
		typeof actions.__internalSetUseShippingAsBilling === 'function' &&
		typeof actions.setEditingBillingAddress === 'function'
	);
}

let reported = false;

function reportMissingAction() {
	if (reported || !settings.gapUrl) {
		return;
	}
	reported = true;
	window
		.fetch(settings.gapUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: {
				'Content-Type': 'application/json',
				'X-WP-Nonce': settings.restNonce,
			},
			body: JSON.stringify({ gap: 'billing_action' }),
		})
		.catch(() => {});
}

/**
 * «La misma que la de entrega»: billing = delivery address (what WooCommerce's box does).
 */
function chooseSame() {
	const { shippingAddress, billingAddress } =
		select(CART_STORE).getCustomerData();
	dispatch(CHECKOUT_STORE).__internalSetUseShippingAsBilling(true);
	const copy = { ...shippingAddress };
	const differs = Object.keys(copy).some(
		(key) => copy[key] !== billingAddress[key]
	);
	if (differs) {
		dispatch(CART_STORE).setBillingAddress(copy);
	}
}

/**
 * «Usar otra dirección»: the billing form opens; a guest starts it empty in the delivery
 * country (what WooCommerce's box does), with the delivery phone (hidden in billing).
 */
function chooseOther() {
	const { shippingAddress } = select(CART_STORE).getCustomerData();
	dispatch(CHECKOUT_STORE).__internalSetUseShippingAsBilling(false);
	dispatch(CHECKOUT_STORE).setEditingBillingAddress(true);
	if (!settings.loggedIn) {
		dispatch(CART_STORE).setBillingAddress({
			first_name: '',
			last_name: '',
			company: '',
			address_1: '',
			address_2: '',
			city: '',
			state: '',
			postcode: '',
			country: shippingAddress.country,
			phone: shippingAddress.phone,
		});
	}
}

function Billing() {
	const available = hasBillingAction();
	const same = useSelect(
		(s) => s(CHECKOUT_STORE).getUseShippingAsBilling(),
		[]
	);
	const once = useRef(false);
	useEffect(() => {
		if (!available && !once.current) {
			once.current = true;
			reportMissingAction();
		}
	}, [available]);

	if (!available) {
		return null;
	}
	const name = 'lc-billing-choice';
	return (
		<fieldset className="lc-billing">
			<legend className="h4 lc-billing__title">
				{__('Dirección de facturación', 'lachinata-core')}
			</legend>
			<label className="lc-billing__option" htmlFor={`${name}-same`}>
				<input
					type="radio"
					id={`${name}-same`}
					name={name}
					checked={same}
					onChange={chooseSame}
				/>
				<span className="body-sm">
					{__('La misma que la de entrega', 'lachinata-core')}
				</span>
			</label>
			<label className="lc-billing__option" htmlFor={`${name}-other`}>
				<input
					type="radio"
					id={`${name}-other`}
					name={name}
					checked={!same}
					onChange={chooseOther}
				/>
				<span className="body-sm">
					{__('Usar otra dirección', 'lachinata-core')}
				</span>
			</label>
		</fieldset>
	);
}

export function registerBilling() {
	registerCheckoutBlock({ metadata, component: Billing });
}
