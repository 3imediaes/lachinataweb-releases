/**
 * Address fields: the province follows the postcode in Spain (visible and editable),
 * the numeric keyboard for postcodes made only of digits, and the help under the phone.
 * WooCommerce's field API has no `inputMode` nor help text for core fields, so these two
 * are set on the rendered inputs (plugin/modules/checkout/README.md).
 */
import { dispatch, select, subscribe } from '@wordpress/data';
import { __ } from '@wordpress/i18n';
import { settings, CART_STORE } from './settings';

const TYPES = ['shipping', 'billing'];

/**
 * Province of a Spanish postcode (WooCommerce state code), from its first two digits.
 *
 * @param {string} postcode Postcode as typed.
 * @return {string|null} State code.
 */
export function provinceOf(postcode) {
	const digits = String(postcode).replace(/\D/g, '');
	return digits.length >= 2
		? (settings.provinces?.[digits.slice(0, 2)] ?? null)
		: null;
}

function address(type) {
	const customer = select(CART_STORE)?.getCustomerData?.();
	return customer?.[`${type}Address`] ?? null;
}

/**
 * Sets the province when the first two digits of a Spanish postcode change, so a
 * province the customer picks by hand stays until the postcode changes again.
 */
function followPostcode() {
	const last = {};
	subscribe(() => {
		for (const type of TYPES) {
			const current = address(type);
			if (!current || current.country !== 'ES') {
				last[type] = null;
				continue;
			}
			const prefix =
				String(current.postcode).replace(/\D/g, '').slice(0, 2) || null;
			if (prefix === last[type]) {
				continue;
			}
			last[type] = prefix;
			const state = provinceOf(current.postcode);
			if (state && state !== current.state) {
				const action =
					type === 'shipping'
						? 'setShippingAddress'
						: 'setBillingAddress';
				dispatch(CART_STORE)[action]({ state });
			}
		}
	}, CART_STORE);
}

/**
 * Numeric keyboard and phone help on the inputs WooCommerce renders.
 */
function decorate() {
	const help = __('Solo para la entrega.', 'lachinata-core');
	for (const type of TYPES) {
		const postcode = document.getElementById(`${type}-postcode`);
		if (postcode) {
			const numeric = (settings.numericPostcodes || []).includes(
				address(type)?.country
			);
			if (numeric && postcode.inputMode !== 'numeric') {
				postcode.inputMode = 'numeric';
			} else if (!numeric && postcode.hasAttribute('inputmode')) {
				postcode.removeAttribute('inputmode');
			}
		}

		const phone = document.getElementById(`${type}-phone`);
		const id = `lc-${type}-phone-help`;
		if (phone && !document.getElementById(id)) {
			const note = document.createElement('span');
			note.id = id;
			note.className = 'lc-field__help body-sm';
			note.textContent = help;
			phone.parentElement.appendChild(note);
			const described = phone.getAttribute('aria-describedby');
			phone.setAttribute(
				'aria-describedby',
				described ? `${described} ${id}` : id
			);
		}
	}
}

/**
 * The billing phone is hidden (theme CSS): it follows the delivery phone while the billing
 * address is another one (with the same address WooCommerce copies it all).
 */
function followPhone() {
	subscribe(() => {
		const checkout = select('wc/store/checkout');
		if (!checkout || checkout.getUseShippingAsBilling()) {
			return;
		}
		const shipping = address('shipping');
		const billing = address('billing');
		if (shipping && billing && shipping.phone !== billing.phone) {
			dispatch(CART_STORE).setBillingAddress({ phone: shipping.phone });
		}
	}, CART_STORE);
}

export function initFields() {
	followPostcode();
	followPhone();

	let frame = 0;
	const schedule = () => {
		if (!frame) {
			frame = window.requestAnimationFrame(() => {
				frame = 0;
				decorate();
			});
		}
	};
	const start = () => {
		const root = document.querySelector('.wp-block-woocommerce-checkout');
		if (!root) {
			return;
		}
		new window.MutationObserver(schedule).observe(root, {
			childList: true,
			subtree: true,
		});
		subscribe(schedule, CART_STORE);
		schedule();
	};
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', start);
	} else {
		start();
	}
}
