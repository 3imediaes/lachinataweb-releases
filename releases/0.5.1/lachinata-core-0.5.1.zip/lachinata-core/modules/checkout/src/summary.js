/**
 * Room in the order summary for the gift module (incremento 7): a slot inside
 * WooCommerce's ExperimentalOrderMeta fill, so modules fill ours and not WooCommerce's.
 */
import { registerPlugin } from '@wordpress/plugins';

const { ExperimentalOrderMeta, createSlotFill } = window.wc.blocksCheckout;

/**
 * Slot of the order summary.
 */
export const SummarySlot = createSlotFill('lachinata/checkout/summary');

export function registerSummary() {
	registerPlugin('lachinata-checkout-summary', {
		scope: 'woocommerce-checkout',
		render: () => (
			<ExperimentalOrderMeta>
				<SummarySlot.Slot />
			</ExperimentalOrderMeta>
		),
	});
}
