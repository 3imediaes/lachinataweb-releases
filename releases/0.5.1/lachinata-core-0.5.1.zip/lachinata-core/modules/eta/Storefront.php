<?php
/**
 * Delivery dates on the product page, the order confirmation and the emails.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Eta;

use LaChinata\Core\Modules\Shipping\Destination;

defined( 'ABSPATH' ) || exit;

/**
 * Product page: the server prints the date for the visitor's destination (no countdown,
 * the page may be cached) and a small script refreshes it from the REST endpoint, adding
 * the countdown to the cut-off once the answer arrives. If the request fails, the
 * server's date stays.
 */
final class Storefront {

	/**
	 * Script handle.
	 */
	public const SCRIPT = 'lachinata-eta';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_filter( 'lachinata/product/availability', array( self::class, 'availability' ), 10, 2 );
		add_filter( 'lachinata/thankyou/delivery', array( self::class, 'thankyou' ), 10, 2 );
		add_action( 'woocommerce_email_after_order_table', array( self::class, 'email' ), 5, 3 );
	}

	/**
	 * Adds the delivery sentence after the stock line.
	 *
	 * @param array{tone: string, text: string} $availability Tone and sentence.
	 * @param \WC_Product                       $product      Product.
	 * @return array{tone: string, text: string}
	 */
	public static function availability( array $availability, \WC_Product $product ): array {
		if ( ! $product->is_in_stock() || ! $product->is_purchasable() ) {
			return $availability;
		}
		$estimate = Estimator::for_product( $product, Destination::visitor() );
		if ( null === $estimate ) {
			return $availability;
		}
		$sentence             = Format::product( $estimate );
		$availability['text'] = rtrim( (string) $availability['text'], '. ' ) . '. ' . $sentence;
		self::enqueue( $product, $sentence );
		return $availability;
	}

	/**
	 * Loads the refresh script with what it needs.
	 *
	 * @param \WC_Product $product  Product.
	 * @param string      $sentence Sentence printed by the server.
	 */
	private static function enqueue( \WC_Product $product, string $sentence ): void {
		wp_enqueue_script(
			self::SCRIPT,
			plugins_url( 'assets/eta.js', __FILE__ ),
			array( 'wp-i18n' ),
			LACHINATA_CORE_VERSION,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
		wp_set_script_translations( self::SCRIPT, 'lachinata-core', LACHINATA_CORE_DIR . '/languages' );
		wp_add_inline_script(
			self::SCRIPT,
			'window.lachinataEta = ' . wp_json_encode(
				array(
					'endpoint' => rest_url( Rest::NAMESPACE . Rest::ROUTE ),
					'product'  => $product->get_id(),
					'sentence' => $sentence,
				)
			) . ';',
			'before'
		);
	}

	/**
	 * Headline of the delivery block on the order received page: «Llega jue 24 – vie 25 oct».
	 *
	 * @param string    $title Current headline (the shipping method).
	 * @param \WC_Order $order Order.
	 */
	public static function thankyou( string $title, \WC_Order $order ): string {
		$estimate = Rates::of_order( $order );
		return null === $estimate ? $title : Format::range( $estimate );
	}

	/**
	 * Line in the customer emails, after the order table.
	 *
	 * @param \WC_Order $order         Order.
	 * @param bool      $sent_to_admin Whether it goes to the store.
	 * @param bool      $plain_text    Plain text email.
	 */
	public static function email( \WC_Order $order, bool $sent_to_admin, bool $plain_text ): void {
		$estimate = Rates::of_order( $order );
		if ( $sent_to_admin || null === $estimate ) {
			return;
		}
		$text = Format::order( $estimate );
		if ( $plain_text ) {
			echo "\n" . esc_html( $text ) . "\n\n";
			return;
		}
		echo '<p style="margin:0 0 16px">' . esc_html( $text ) . '</p>';
	}
}
