<?php
/**
 * WooCommerce → La Chinata.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Admin;

defined( 'ABSPATH' ) || exit;

/**
 * The plugin screen under WooCommerce, with one tab per area (Módulos, Exportar/importar,
 * Actualizaciones; modules add theirs with `lachinata/core/admin_tabs`).
 */
final class Screen {

	/**
	 * Page slug.
	 */
	public const SLUG = 'lachinata';

	/**
	 * Capability to see and use the screen.
	 */
	public const CAPABILITY = 'manage_woocommerce';

	/**
	 * Hook suffix of the page, set when the menu is added.
	 *
	 * @var string
	 */
	private static string $hook = '';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_action( 'admin_menu', array( self::class, 'menu' ), 60 );
		add_action( 'admin_enqueue_scripts', array( self::class, 'enqueue' ) );
		add_filter( 'plugin_action_links_' . plugin_basename( LACHINATA_CORE_FILE ), array( self::class, 'action_links' ) );
		ModulesTab::boot();
		TransferTab::boot();
		UpdatesTab::boot();
	}

	/**
	 * Adds the page under WooCommerce.
	 */
	public static function menu(): void {
		self::$hook = (string) add_submenu_page(
			'woocommerce',
			__( 'La Chinata', 'lachinata-core' ),
			__( 'La Chinata', 'lachinata-core' ),
			self::CAPABILITY,
			self::SLUG,
			array( self::class, 'render' )
		);
	}

	/**
	 * «Ajustes» link in the plugin row of Plugins.
	 *
	 * @param string[] $links Action links.
	 * @return string[]
	 */
	public static function action_links( array $links ): array {
		if ( current_user_can( self::CAPABILITY ) ) {
			array_unshift( $links, sprintf( '<a href="%1$s">%2$s</a>', esc_url( self::url( 'modules' ) ), esc_html__( 'Ajustes', 'lachinata-core' ) ) );
		}
		return $links;
	}

	/**
	 * Loads the screen styles, only on this page.
	 *
	 * @param string $hook_suffix Current admin page.
	 */
	public static function enqueue( string $hook_suffix ): void {
		if ( '' === self::$hook || self::$hook !== $hook_suffix ) {
			return;
		}
		wp_enqueue_style( 'lachinata-core-admin', plugins_url( 'assets/admin.css', LACHINATA_CORE_FILE ), array(), LACHINATA_CORE_VERSION );
	}

	/**
	 * Tabs of the screen.
	 *
	 * @return array<string, array{label: string, render: callable}>
	 */
	public static function tabs(): array {
		$tabs = array(
			'modules'  => array(
				'label'  => __( 'Módulos', 'lachinata-core' ),
				'render' => array( ModulesTab::class, 'render' ),
			),
			'transfer' => array(
				'label'  => __( 'Exportar/importar', 'lachinata-core' ),
				'render' => array( TransferTab::class, 'render' ),
			),
			'updates'  => array(
				'label'  => __( 'Actualizaciones', 'lachinata-core' ),
				'render' => array( UpdatesTab::class, 'render' ),
			),
		);
		/**
		 * Tabs of WooCommerce → La Chinata. Modules add their screens here.
		 *
		 * @since 0.3.0
		 *
		 * @param array<string, array{label: string, render: callable}> $tabs Tabs keyed by id.
		 */
		return (array) apply_filters( 'lachinata/core/admin_tabs', $tabs );
	}

	/**
	 * URL of a tab.
	 *
	 * @param string               $tab  Tab id.
	 * @param array<string, mixed> $args Extra query arguments.
	 */
	public static function url( string $tab, array $args = array() ): string {
		return add_query_arg(
			array_merge(
				array(
					'page' => self::SLUG,
					'tab'  => $tab,
				),
				$args
			),
			admin_url( 'admin.php' )
		);
	}

	/**
	 * Stops unless the current user may use the screen and the nonce matches.
	 *
	 * @param string $action Nonce action.
	 */
	public static function check( string $action ): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die( esc_html__( 'No tienes permiso para hacer esto.', 'lachinata-core' ), 403 );
		}
		check_admin_referer( $action );
	}

	/**
	 * Keeps a message for the next page load of the current user.
	 *
	 * @param string   $type     success, error, warning or info.
	 * @param string[] $messages Messages.
	 */
	public static function flash( string $type, array $messages ): void {
		set_transient(
			'lachinata_core_notice_' . get_current_user_id(),
			array(
				'type'     => $type,
				'messages' => $messages,
			),
			MINUTE_IN_SECONDS * 5
		);
	}

	/**
	 * Goes back to a tab and stops.
	 *
	 * @param string               $tab  Tab id.
	 * @param array<string, mixed> $args Extra query arguments.
	 */
	public static function redirect( string $tab, array $args = array() ): never {
		wp_safe_redirect( self::url( $tab, $args ) );
		exit;
	}

	/**
	 * Prints the page.
	 */
	public static function render(): void {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		$tabs    = self::tabs();
		$current = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'modules'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Navigation only.
		if ( ! isset( $tabs[ $current ] ) ) {
			$current = 'modules';
		}
		echo '<div class="wrap lc-admin">';
		echo '<h1>' . esc_html__( 'La Chinata', 'lachinata-core' ) . '</h1>';
		echo '<nav class="nav-tab-wrapper" aria-label="' . esc_attr__( 'Secciones', 'lachinata-core' ) . '">';
		foreach ( $tabs as $id => $tab ) {
			printf(
				'<a href="%1$s" class="nav-tab%2$s"%3$s>%4$s</a>',
				esc_url( self::url( $id ) ),
				$id === $current ? ' nav-tab-active' : '',
				$id === $current ? ' aria-current="page"' : '',
				esc_html( $tab['label'] )
			);
		}
		echo '</nav>';
		self::print_notice();
		call_user_func( $tabs[ $current ]['render'] );
		echo '</div>';
	}

	/**
	 * Prints and forgets the message kept by flash().
	 */
	private static function print_notice(): void {
		$key    = 'lachinata_core_notice_' . get_current_user_id();
		$notice = get_transient( $key );
		if ( ! is_array( $notice ) || empty( $notice['messages'] ) ) {
			return;
		}
		delete_transient( $key );
		$type = in_array( $notice['type'] ?? '', array( 'success', 'error', 'warning', 'info' ), true ) ? $notice['type'] : 'info';
		printf( '<div class="notice notice-%s">', esc_attr( $type ) );
		foreach ( (array) $notice['messages'] as $message ) {
			echo '<p>' . esc_html( (string) $message ) . '</p>';
		}
		echo '</div>';
	}

	/**
	 * A value for people: Sí/No, «—» for nothing, JSON for lists.
	 *
	 * @param mixed $value Value.
	 */
	public static function format_value( $value ): string {
		if ( is_bool( $value ) ) {
			return $value ? __( 'Sí', 'lachinata-core' ) : __( 'No', 'lachinata-core' );
		}
		if ( null === $value || '' === $value ) {
			return '—';
		}
		if ( is_scalar( $value ) ) {
			return (string) $value;
		}
		return (string) wp_json_encode( $value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
	}
}
