<?php
/**
 * Order received page (Gracias.dc.html): data for woocommerce/checkout/thankyou.php.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Order received view (the checkout's endpoint, rendered with the classic template).
 */
function lachinata_is_order_received(): bool {
	return function_exists( 'is_order_received_page' ) && is_order_received_page();
}

/**
 * «Mientras llega»: cross-sells of what was bought and, without any, the best sellers of the
 * category of the first product (its top-level category when the subcategory has fewer than
 * two). Never what is in the order.
 *
 * @param WC_Order $order Order.
 * @param int      $limit Products.
 * @return WC_Product[]
 */
function lachinata_thankyou_products( WC_Order $order, int $limit = 4 ): array {
	$bought = array();
	$cross  = array();
	foreach ( $order->get_items() as $item ) {
		$product = $item instanceof WC_Order_Item_Product ? $item->get_product() : null;
		if ( ! $product instanceof WC_Product ) {
			continue;
		}
		$parent   = $product->get_parent_id() ? wc_get_product( $product->get_parent_id() ) : $product;
		$bought[] = $parent instanceof WC_Product ? $parent->get_id() : $product->get_id();
		$cross    = array_merge( $cross, $parent instanceof WC_Product ? $parent->get_cross_sell_ids() : array() );
	}
	$ids = array_values( array_diff( array_unique( array_map( 'intval', $cross ) ), $bought ) );

	if ( ! $ids && $bought ) {
		$terms = get_the_terms( $bought[0], 'product_cat' );
		if ( is_array( $terms ) && $terms ) {
			usort( $terms, static fn( WP_Term $a, WP_Term $b ): int => count( get_ancestors( $b->term_id, 'product_cat', 'taxonomy' ) ) <=> count( get_ancestors( $a->term_id, 'product_cat', 'taxonomy' ) ) );
			// The deepest category first; if it has too few, its top-level category.
			$ancestors = get_ancestors( $terms[0]->term_id, 'product_cat', 'taxonomy' );
			$root      = $ancestors ? get_term( (int) end( $ancestors ), 'product_cat' ) : null;
			foreach ( array_filter( array( $terms[0], $root ) ) as $term ) {
				$ids = wc_get_products(
					array(
						'status'   => 'publish',
						'limit'    => $limit,
						'category' => array( $term->slug ),
						'exclude'  => $bought,
						'orderby'  => 'popularity',
						'return'   => 'ids',
					)
				);
				if ( count( $ids ) >= 2 ) {
					break;
				}
			}
		}
	}

	/**
	 * Product ids of «Mientras llega» on the order received page.
	 *
	 * @since 0.5.0
	 *
	 * @param int[]    $ids   Cross-sells of the order, or best sellers of its first category.
	 * @param WC_Order $order Order.
	 */
	$ids      = (array) apply_filters( 'lachinata/thankyou/product_ids', array_map( 'intval', (array) $ids ), $order );
	$products = array_filter( array_map( 'wc_get_product', array_slice( $ids, 0, $limit ) ) );
	return array_values( array_filter( $products, static fn( $p ): bool => $p instanceof WC_Product && $p->is_visible() ) );
}

/**
 * Delivery block: the headline (the delivery date when a module knows it, the shipping
 * method otherwise) and the method with a short address.
 *
 * @param WC_Order $order Order.
 * @return array{title: string, text: string}|null Null for orders without shipping.
 */
function lachinata_thankyou_delivery( WC_Order $order ): ?array {
	if ( ! $order->get_items( 'shipping' ) ) {
		return null;
	}
	$method = (string) $order->get_shipping_method();
	/**
	 * Headline of the delivery block of the order received page.
	 *
	 * @since 0.5.0
	 *
	 * @param string   $title Shipping method name.
	 * @param WC_Order $order Order.
	 */
	$title = (string) apply_filters( 'lachinata/thankyou/delivery', $method, $order );
	$where = trim( implode( ', ', array_filter( array( $order->get_shipping_address_1(), trim( $order->get_shipping_postcode() . ' ' . $order->get_shipping_city() ) ) ) ) );
	return array(
		'title' => $title,
		'text'  => $title === $method ? $where : implode( ' · ', array_filter( array( $method, $where ) ) ),
	);
}

/**
 * Where «Seguir el pedido» goes until there is tracking: the order in the account, or the
 * order received page with its key for guests.
 *
 * @param WC_Order $order Order.
 */
function lachinata_thankyou_track_url( WC_Order $order ): string {
	return $order->get_customer_id() ? $order->get_view_order_url() : $order->get_checkout_order_received_url();
}
