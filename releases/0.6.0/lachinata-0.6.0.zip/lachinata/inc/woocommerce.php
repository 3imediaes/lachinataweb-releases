<?php
/**
 * WooCommerce integration: the theme prints its own markup, so the default wrappers,
 * sidebar and loop pieces are removed, and catalog queries follow the system.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Checkout (and order received) views: no PromoBar, BottomNav or layers.
 */
function lachinata_is_checkout_view(): bool {
	return function_exists( 'is_checkout' ) && is_checkout();
}

/**
 * UspBar under the order summary of the checkout, in one column (desktop only, checkout.css).
 * Same «usp» menu and `lachinata/usp/items` filter as the rest of the site; WooCommerce keeps
 * HTML that is not a block inside the totals column.
 *
 * @param string $content Rendered totals block.
 */
function lachinata_checkout_usp( string $content ): string {
	if ( ! lachinata_is_checkout_view() || ! str_ends_with( rtrim( $content ), '</div>' ) ) {
		return $content;
	}
	ob_start();
	get_template_part(
		'template-parts/usp-bar',
		null,
		array(
			'layout' => 'stack',
			'class'  => 'lc-checkout__usp',
		)
	);
	$usp = (string) ob_get_clean();
	if ( '' === trim( $usp ) ) {
		return $content;
	}
	$end = (int) strrpos( $content, '</div>' );
	return substr( $content, 0, $end ) . $usp . substr( $content, $end );
}
add_filter( 'render_block_woocommerce/checkout-totals-block', 'lachinata_checkout_usp' );

/**
 * Removes WooCommerce's default presentation hooks that the templates replace.
 */
function lachinata_woocommerce_hooks(): void {
	remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
	remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );
	remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
	remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );
	remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );
	remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );
	add_filter( 'woocommerce_show_page_title', '__return_false' );
	// The order received page prints its own OrderSummary (woocommerce/checkout/thankyou.php).
	remove_action( 'woocommerce_thankyou', 'woocommerce_order_details_table', 10 );
}
add_action( 'init', 'lachinata_woocommerce_hooks' );

/**
 * Twelve products per page, as in the category template («Cargar más» in batches of 12).
 */
add_filter( 'loop_shop_per_page', static fn(): int => 12 );

/**
 * Filter chips and checkboxes send arrays (filter_formato[]=a&filter_formato[]=b);
 * WooCommerce's layered navigation expects comma-separated values.
 */
function lachinata_normalize_filter_params(): void {
	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only catalog filters.
	foreach ( array_keys( $_GET ) as $key ) {
		if ( is_string( $key ) && str_starts_with( $key, 'filter_' ) && isset( $_GET[ $key ] ) && is_array( $_GET[ $key ] ) ) {
			$_GET[ $key ] = implode( ',', array_map( 'sanitize_title', wp_unslash( $_GET[ $key ] ) ) );
		}
	}
	// phpcs:enable
}
add_action( 'parse_request', 'lachinata_normalize_filter_params', 1 );

/**
 * Attribute filters available in the current catalog view.
 *
 * @return array<int, array{taxonomy: string, param: string, label: string, terms: WP_Term[], chosen: string[]}>
 */
function lachinata_catalog_filters(): array {
	$taxonomies = array();
	foreach ( wc_get_attribute_taxonomies() as $attribute ) {
		$taxonomies[ wc_attribute_taxonomy_name( $attribute->attribute_name ) ] = $attribute;
	}
	if ( ! $taxonomies ) {
		return array();
	}

	$term      = get_queried_object();
	$cache_key = 'lachinata_filters_' . ( $term instanceof WP_Term ? $term->term_id : 'shop' ) . '_' . WC_Cache_Helper::get_transient_version( 'product' );
	$by_tax    = get_transient( $cache_key );
	if ( ! is_array( $by_tax ) ) {
		$query = array(
			'status' => 'publish',
			'limit'  => -1,
			'return' => 'ids',
		);
		if ( $term instanceof WP_Term && 'product_cat' === $term->taxonomy ) {
			$query['category'] = array( $term->slug );
		}
		$ids    = wc_get_products( $query );
		$by_tax = array();
		if ( $ids ) {
			foreach ( wp_get_object_terms( $ids, array_keys( $taxonomies ) ) as $found ) {
				$by_tax[ $found->taxonomy ][ $found->term_id ] = $found;
			}
		}
		set_transient( $cache_key, $by_tax, DAY_IN_SECONDS );
	}

	$chosen  = WC_Query::get_layered_nav_chosen_attributes();
	$filters = array();
	foreach ( $by_tax as $taxonomy => $terms ) {
		$filters[] = array(
			'taxonomy' => $taxonomy,
			'param'    => 'filter_' . wc_attribute_taxonomy_slug( $taxonomy ),
			'label'    => $taxonomies[ $taxonomy ]->attribute_label,
			'terms'    => array_values( $terms ),
			'chosen'   => $chosen[ $taxonomy ]['terms'] ?? array(),
		);
	}
	return $filters;
}

/**
 * Applied filters as removable chips: [label, url without that filter].
 *
 * @return array<int, array{0: string, 1: string}>
 */
function lachinata_applied_filters(): array {
	$applied = array();
	foreach ( lachinata_catalog_filters() as $filter ) {
		foreach ( $filter['terms'] as $term ) {
			if ( in_array( $term->slug, $filter['chosen'], true ) ) {
				$rest      = array_diff( $filter['chosen'], array( $term->slug ) );
				$applied[] = array( $term->name, $rest ? add_query_arg( $filter['param'], implode( ',', $rest ) ) : remove_query_arg( $filter['param'] ) );
			}
		}
	}
	// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only catalog filters.
	foreach ( array( 'min_price', 'max_price' ) as $param ) {
		if ( isset( $_GET[ $param ] ) && '' !== $_GET[ $param ] ) {
			$value = wc_price( (float) wc_clean( wp_unslash( $_GET[ $param ] ) ) );
			$label = 'min_price' === $param
				/* translators: %s: price. */
				? sprintf( __( 'Desde %s', 'lachinata' ), wp_strip_all_tags( $value ) )
				/* translators: %s: price. */
				: sprintf( __( 'Hasta %s', 'lachinata' ), wp_strip_all_tags( $value ) );
			$applied[] = array( $label, remove_query_arg( $param ) );
		}
	}
	// phpcs:enable
	return $applied;
}

/**
 * Notices printed with the Notice component instead of WooCommerce's markup.
 *
 * @param string $template      Located template.
 * @param string $template_name Template name.
 */
function lachinata_notice_templates( string $template, string $template_name ): string {
	$map = array(
		'notices/success.php' => 'success',
		'notices/error.php'   => 'error',
		'notices/notice.php'  => 'info',
	);
	if ( isset( $map[ $template_name ] ) ) {
		set_query_var( 'lachinata_notice_tone', $map[ $template_name ] );
		return get_template_directory() . '/woocommerce/notices/lachinata-notice.php';
	}
	return $template;
}
add_filter( 'wc_get_template', 'lachinata_notice_templates', 10, 2 );

/**
 * Products for «Completa tu rutina»: cross-sells, or products of the same subcategory.
 *
 * @param WC_Product $product Product.
 * @param int        $limit   How many.
 * @return WC_Product[]
 */
function lachinata_routine_products( WC_Product $product, int $limit = 4 ): array {
	$ids = $product->get_cross_sell_ids();
	if ( ! $ids ) {
		$terms = get_the_terms( $product->get_id(), 'product_cat' );
		if ( is_array( $terms ) && $terms ) {
			usort( $terms, static fn( WP_Term $a, WP_Term $b ): int => count( get_ancestors( $b->term_id, 'product_cat', 'taxonomy' ) ) <=> count( get_ancestors( $a->term_id, 'product_cat', 'taxonomy' ) ) );
			$ids = wc_get_products(
				array(
					'status'   => 'publish',
					'limit'    => $limit + 1,
					'category' => array( $terms[0]->slug ),
					'exclude'  => array( $product->get_id() ),
					'orderby'  => 'popularity',
					'return'   => 'ids',
				)
			);
		}
	}
	/**
	 * Product ids of «Completa tu rutina».
	 *
	 * @since 0.2.0
	 *
	 * @param int[]      $ids     Cross-sells, or popular products of the same subcategory.
	 * @param WC_Product $product Product.
	 */
	$ids      = (array) apply_filters( 'lachinata/product/routine_ids', array_map( 'intval', (array) $ids ), $product );
	$products = array_filter( array_map( 'wc_get_product', array_slice( $ids, 0, $limit ) ) );
	return array_values( array_filter( $products, static fn( $p ): bool => $p instanceof WC_Product && $p->is_visible() ) );
}

/**
 * Tabs of the product page: Descripción · (modules) · Opiniones.
 *
 * @param WC_Product $product Product.
 * @return array<int, array{id: string, title: string, content: string}>
 */
function lachinata_product_tabs( WC_Product $product ): array {
	$tabs        = array();
	$description = (string) apply_filters( 'the_content', $product->get_description() ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- Core hook.
	if ( '' !== trim( wp_strip_all_tags( $description ) ) ) {
		$tabs[] = array(
			'id'      => 'description',
			'title'   => __( 'Descripción', 'lachinata' ),
			'content' => $description,
		);
	}
	/**
	 * Tabs of the product page. Reviews are added after this filter.
	 *
	 * @since 0.2.0
	 *
	 * @param array<int, array{id: string, title: string, content: string}> $tabs    Tabs (content is HTML).
	 * @param WC_Product                                                  $product Product.
	 */
	return (array) apply_filters( 'lachinata/product/tabs', $tabs, $product );
}

/**
 * Sort options with the system wording (WooCommerce's filter still applies).
 *
 * @return array<string, string>
 */
function lachinata_catalog_orderby_options(): array {
	$options = array(
		'menu_order' => __( 'Relevancia', 'lachinata' ),
		'popularity' => __( 'Más vendidos', 'lachinata' ),
		'rating'     => __( 'Mejor valorados', 'lachinata' ),
		'date'       => __( 'Novedades', 'lachinata' ),
		'price'      => __( 'Precio: de menor a mayor', 'lachinata' ),
		'price-desc' => __( 'Precio: de mayor a menor', 'lachinata' ),
	);
	if ( ! wc_review_ratings_enabled() ) {
		unset( $options['rating'] );
	}
	if ( is_search() ) {
		$options = array( 'relevance' => __( 'Relevancia', 'lachinata' ) ) + array_diff_key( $options, array( 'menu_order' => true ) );
	}
	return (array) apply_filters( 'woocommerce_catalog_orderby', $options ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook.
}

/**
 * Current sort option.
 */
function lachinata_catalog_current_orderby(): string {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only catalog sort.
	if ( isset( $_GET['orderby'] ) ) {
		return (string) wc_clean( wp_unslash( $_GET['orderby'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}
	return is_search() ? 'relevance' : (string) apply_filters( 'woocommerce_default_catalog_orderby', get_option( 'woocommerce_default_catalog_orderby', 'menu_order' ) ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook.
}
