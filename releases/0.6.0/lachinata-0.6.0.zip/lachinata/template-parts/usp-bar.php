<?php
/**
 * UspBar from the «usp» menu: title, description as text, CSS class as icon.
 * Args: layout (grid|row|stack: one column, under the checkout summary), class.
 *
 * @package LaChinata\Theme
 */

defined( 'ABSPATH' ) || exit;

/**
 * Items of the UspBar.
 *
 * @since 0.2.0
 *
 * @param array<int, array{title: string, text: string, icon: string}> $items Items of the «usp» menu.
 * @param string                                                       $layout grid, row or stack.
 */
$lachinata_items = (array) apply_filters( 'lachinata/usp/items', lachinata_menu( 'usp' ), $args['layout'] ?? 'grid' );
if ( ! $lachinata_items ) {
	return;
}
?>
<div class="<?php echo esc_attr( lachinata_cx( 'lc-usp', 'row' === ( $args['layout'] ?? 'grid' ) ? 'lc-usp--row' : '', $args['class'] ?? '' ) ); ?>">
	<?php foreach ( $lachinata_items as $lachinata_item ) : ?>
		<div class="lc-usp__item body-sm">
			<?php echo lachinata_icon( '' !== ( $lachinata_item['icon'] ?? '' ) ? $lachinata_item['icon'] : 'check' ); ?>
			<div><strong><?php echo esc_html( $lachinata_item['title'] ); ?></strong><span><?php echo esc_html( $lachinata_item['text'] ?? '' ); ?></span></div>
		</div>
	<?php endforeach; ?>
</div>
