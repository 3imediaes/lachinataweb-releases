<?php
/**
 * «Quiero recibir novedades y ofertas por correo» in Contacto.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Checkout;

defined( 'ABSPATH' ) || exit;

/**
 * A box in Contacto, unticked (explicit consent). When it is ticked, the order keeps when
 * the customer said yes (`_lc_newsletter_optin`, timestamp) and nothing else happens: the
 * newsletter module (incremento 5) reads it.
 */
final class Newsletter {

	/**
	 * Additional checkout field.
	 */
	public const FIELD = 'lachinata/newsletter';

	/**
	 * Order meta: when the customer agreed (timestamp).
	 */
	public const META = '_lc_newsletter_optin';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_action( 'woocommerce_init', array( self::class, 'register_field' ) );
		add_action( 'woocommerce_store_api_checkout_order_processed', array( self::class, 'from_checkout' ) );
	}

	/**
	 * The box under the email.
	 */
	public static function register_field(): void {
		if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
			return;
		}
		woocommerce_register_additional_checkout_field(
			array(
				'id'            => self::FIELD,
				'label'         => __( 'Quiero recibir novedades y ofertas por correo', 'lachinata-core' ),
				// A box is always optional: without «(opcional)».
				'optionalLabel' => __( 'Quiero recibir novedades y ofertas por correo', 'lachinata-core' ),
				'location'      => 'contact',
				'type'          => 'checkbox',
			)
		);
	}

	/**
	 * Keeps when the customer agreed, once per order.
	 *
	 * @param \WC_Order $order Order.
	 */
	public static function from_checkout( $order ): void {
		if ( ! $order instanceof \WC_Order || '' !== (string) $order->get_meta( self::META ) ) {
			return;
		}
		if ( wc_string_to_bool( (string) $order->get_meta( '_wc_other/' . self::FIELD ) ) ) {
			$order->update_meta_data( self::META, (string) time() );
			$order->save();
		}
	}
}
