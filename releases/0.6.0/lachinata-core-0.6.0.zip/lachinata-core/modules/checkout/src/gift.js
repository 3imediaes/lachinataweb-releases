/**
 * Block `lachinata/checkout-gift`, between Envío and Facturación: the slot of the gift module
 * (incremento 7). The fill draws the whole card, a folded CheckoutSection
 * (`lc-chk lc-chk--quiet`, icon `gift`, «¿Es un regalo?») with GiftOption inside. Without
 * the module the slot is empty and the theme takes it out of the page flow.
 */
import { useSelect } from '@wordpress/data';
import { CART_STORE } from './settings';
import metadata from '../blocks/gift/block.json';

const { registerCheckoutBlock, createSlotFill } = window.wc.blocksCheckout;

/**
 * Slot of the gift card.
 */
export const GiftSlot = createSlotFill('lachinata/checkout/gift');

function Gift() {
	const { cart, extensions } = useSelect((s) => {
		const data = s(CART_STORE).getCartData();
		return { cart: data, extensions: data.extensions };
	}, []);
	return <GiftSlot.Slot fillProps={{ cart, extensions }} />;
}

export function registerGift() {
	registerCheckoutBlock({ metadata, component: Gift });
}
