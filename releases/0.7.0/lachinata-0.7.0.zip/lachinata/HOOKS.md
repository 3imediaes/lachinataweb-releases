# Huecos del tema (contrato con lachinata-core)

El tema nunca llama al plugin: pregunta `lachinata_module( 'x' )` y deja estos huecos. Cada filtro tiene un valor por defecto neutro, de modo que con WooCommerce de serie el tema funciona (sin tintas, sin precio por unidad, sin pestañas extra). Lo que cambia entre tiendas no vive en el tema: entra por estos filtros o por los menús.

## Filtros

| Hook | Valor por defecto | Quién lo rellena |
| --- | --- | --- |
| `lachinata/category/tint` `( string $tint, WP_Term $term )` | `''` (sin tinta: `surface-2`/`surface-3`) | `catalog` (`_lc_tint`, heredado) |
| `lachinata/product/tint` `( string $tint, WC_Product $product )` | `''` | `catalog` (categoría más profunda) |
| `lachinata/product/unit_price` `( string $html, WC_Product $product )` | `''` | `catalog` («500 ml \| 9,33 € / 1 l»; producto o variación) |
| `lachinata/product_card/badges` `( array $badges, WC_Product $product )` | oferta + etiquetas de producto | `catalog` antepone la «etiqueta» (tono neutro) |
| `lachinata/product/tabs` `( array $tabs, WC_Product $product )` | Descripción | `catalog` añade Ingredientes e imagen de descripción. «Opiniones» la añade el tema después. |
| `lachinata/product/seals` `( array $seals, WC_Product $product )` | `[]` | `catalog` (taxonomía `tipo` con icono) |
| `lachinata/product/details` `( array $rows, WC_Product $product )` | `[]` | `catalog` (consumo preferente) |
| `lachinata/product/availability` `( array{tone,text} $availability, WC_Product $product )` | «Disponible», «Quedan N unidades», «Agotado por ahora.» | `eta`: «Disponible. Pídelo antes de las 16:00 y lo recibes el jueves 24.» (un script lo refresca y añade la cuenta atrás) |
| `lachinata/product/routine_ids` `( int[] $ids, WC_Product $product )` | ventas cruzadas o populares de la misma subcategoría (con menos de dos, la sección no se pinta) | — |
| `lachinata/cart/line_note` `( string $note, array $item )` | `''` | `shipping`: «No se envía a Alemania» (restricción de producto en el destino del cliente); con la causa `peso_max`, «Pesa 2,4 kg» en cada línea que se envía |
| `lachinata/cart/shipping_summary` `( string $html, WC_Cart $cart )` | «Se calcula con tu dirección» | `shipping`: «Envío estándar · 4,13 € · Llega jue 24 – vie 25 oct» (método elegido, precio y fecha de `eta`) |
| `lachinata/promo_bar/messages` `( array $messages )` | menú «promo» | `shipping`: antepone «Envío gratis desde 60 €» (umbral de la zona del visitante) o rellena `{envio_gratis}` si un mensaje lo usa |
| `lachinata/usp/items` `( array $items, string $layout )` | menú «usp» | `shipping`: rellena `{envio_gratis}` en título y texto; sin umbral, quita el elemento |
| `lachinata/home/category_sections` `( array $tree )` | todas las categorías padre | — |
| `lachinata/thankyou/delivery` `( string $title, WC_Order $order )` | nombre del método de envío | `eta`: «Llega jue 24 – vie 25 oct» (titular del bloque de entrega de gracias) |
| `lachinata/thankyou/product_ids` `( int[] $ids, WC_Order $order )` | ventas cruzadas de lo comprado o, sin ellas, los más vendidos de su categoría | — |
| `lachinata/footer/copyright` `( string $text )` | «© año Nombre del sitio» | — |

## Acciones

| Hook | Dónde | Quién |
| --- | --- | --- |
| `lachinata/nav_drawer/utilities` | final de las utilidades del menú lateral | `locale`: «España / Península · Español» |
| `lachinata/footer/legal` | principio de la línea legal del pie | `locale`: destino e idioma |
| `lachinata/footer/newsletter` | bloque de newsletter del pie (no se pinta si nadie engancha) | pendiente de proveedor |
| `lachinata/cart/notices` | encima del resumen de la bolsa (página y sheet) | `shipping`: aviso informativo de la zona, motivo cuando no hay envío y «Te faltan X € para el envío gratis» |
| `lachinata/thankyou/account` `( WC_Order $order )` | gracias, tras «Seguir el pedido» | `checkout`: «Hemos creado tu cuenta…» o «Guarda tus datos para la próxima vez» con «Crear mi cuenta» |
| `lachinata/thankyou/invoice` `( WC_Order $order )` | gracias, tras la cuenta | `checkout`: «¿Necesitas factura con NIF?» (Empresa y NIF después de pagar) o los datos de factura ya guardados |
| `lachinata/thankyou/gift` `( WC_Order $order )` | gracias, bajo la fecha de entrega (antes de «Seguir el pedido») | `gift`: «Es un regalo para María» y cómo se le avisará |

## Checkout de bloques

El checkout lo pinta React (bloque de WooCommerce), así que aquí los huecos no son hooks de PHP:

- Sin indicador de pasos (retirado el 23/10/2026: en una página el scroll ya orienta).
- **Después del envío** y **resumen**: *slots* JS `lachinata/checkout/after-shipping` y `lachinata/checkout/summary` del módulo `checkout` (bloque `lachinata/checkout-after-shipping` y *fill* en `ExperimentalOrderMeta`). Un módulo los rellena con `wc.blocksCheckout.createSlotFill( nombre ).Fill` y registra sus campos y su script en la acción PHP `lachinata/checkout/after_shipping`, que no imprime nada. Ver `plugin/modules/checkout/README.md`.
- **CSS que el tema da por hecho del módulo:** `.lc-billing` (bloque de facturación propio: con él se ocultan la casilla nativa y los títulos de facturación e «Información del pedido»), `.lc-checkout-shipping--cause` (hay motivo de «sin envío»: el tema oculta el aviso genérico de WooCommerce), `.lc-checkout__outlets`, `.lc-checkout__actions`, `.lc-checkout__restricted`, `.lc-checkout__unavailable`.

## Contenido por sitio (menús, no código)

| Ubicación | Uso |
| --- | --- |
| `promo` | Mensajes de la `PromoBar` (título, URL; clase CSS = icono). `{envio_gratis}` se sustituye por el umbral de la zona |
| `brand` | Enlaces de marca en la cabecera de escritorio |
| `utility` | Utilidades del menú lateral (clase CSS = icono: `pin`, `leaf`, `headset`…) |
| `usp` | `UspBar` (título, descripción = texto, clase CSS = icono). `{envio_gratis}` se sustituye por el umbral de la zona |
| `help` | Acordeón de ayuda de la ficha (título = pregunta, descripción = respuesta) |
| `footer` | Columnas del pie (elementos de primer nivel con sus enlaces) |
| `legal` | Enlaces legales del pie |

La nota de impuestos bajo los precios es el «sufijo de precio» de WooCommerce (Ajustes → Impuestos). El lema del pie es la descripción corta del sitio.

## Home

Los bloques editoriales son el contenido de la página de inicio (patrones del tema, categoría «La Chinata»). Lo que va antes del bloque «Más» se pinta arriba (hero, campaña) y lo que va después, al final (historia, oleotecas). Entre medias, el tema pinta tiles de categoría, `UspBar`, TOP 10 y una sección por categoría.
