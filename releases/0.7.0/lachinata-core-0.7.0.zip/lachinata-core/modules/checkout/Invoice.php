<?php
/**
 * Company invoice details of an order.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Checkout;

defined( 'ABSPATH' ) || exit;

/**
 * Company name and tax id of an order (`_lc_empresa`, `_lc_nif`): billing data, never
 * delivery data. Shown with the billing address in the order and in the emails, and exposed
 * to the REST API for Odoo as `lachinata.invoice` (docs/api-odoo.md; `lachinata_invoice`
 * stays as an alias of 0.5.1). A customer who paid without them (an
 * express payment brings no NIF) can add them after paying, on the thank you page and on
 * the order in their account; then `lachinata/checkout/invoice_details` fires (the Odoo
 * module listens to it) and the invoice is issued with them.
 */
final class Invoice {

	/**
	 * Order meta.
	 */
	public const COMPANY = '_lc_empresa';
	public const TAX_ID  = '_lc_nif';

	/**
	 * Nonce action of the form after paying.
	 */
	private const ACTION = 'lachinata_invoice_details';

	/**
	 * Errors of the last submit, by order id.
	 *
	 * @var array<int, array<string, string>>
	 */
	private static array $errors = array();

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_action( 'woocommerce_init', array( self::class, 'register_fields' ), 5 );
		add_action( 'woocommerce_validate_additional_field', array( self::class, 'validate_field' ), 10, 3 );
		add_action( 'woocommerce_store_api_checkout_order_processed', array( self::class, 'from_checkout' ) );
		add_action( 'woocommerce_admin_order_data_after_billing_address', array( self::class, 'admin' ) );
		add_filter( 'woocommerce_email_order_meta_fields', array( self::class, 'email_fields' ), 10, 3 );
		add_filter( 'lachinata/rest/order', array( self::class, 'rest_data' ), 10, 2 );
		add_filter( 'woocommerce_rest_prepare_shop_order_object', array( self::class, 'rest' ), 10, 2 );
		add_action( 'lachinata/thankyou/invoice', array( self::class, 'form' ) );
		add_action( 'woocommerce_view_order', array( self::class, 'view_order' ), 20 );
		add_action( 'template_redirect', array( self::class, 'handle' ) );
	}

	/**
	 * Checkout fields (location `order`, placed by Page.php inside the Facturación card,
	 * under the tabs): the box, set by the tab «Empresa / Autónomo» (src/billing-type.js) and
	 * hidden while that block can draw the tabs, and company and tax id, required and shown
	 * only when it is ticked.
	 */
	public const FIELD_WANTS   = 'lachinata/company-invoice';
	public const FIELD_COMPANY = 'lachinata/company';
	public const FIELD_TAX_ID  = 'lachinata/tax-id';

	/**
	 * Registers the checkout fields.
	 */
	public static function register_fields(): void {
		if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
			return;
		}
		$ticked = array(
			'type'       => 'object',
			'properties' => array(
				'checkout' => array(
					'type'       => 'object',
					'properties' => array(
						'additional_fields' => array(
							'type'       => 'object',
							'properties' => array( self::FIELD_WANTS => array( 'const' => true ) ),
							'required'   => array( self::FIELD_WANTS ),
						),
					),
					'required'   => array( 'additional_fields' ),
				),
			),
			'required'   => array( 'checkout' ),
		);
		woocommerce_register_additional_checkout_field(
			array(
				'id'            => self::FIELD_WANTS,
				'label'         => __( 'Necesito factura a nombre de una empresa', 'lachinata-core' ),
				// A box is always optional: without «(opcional)».
				'optionalLabel' => __( 'Necesito factura a nombre de una empresa', 'lachinata-core' ),
				'location'      => 'order',
				'type'          => 'checkbox',
			)
		);
		woocommerce_register_additional_checkout_field(
			array(
				'id'         => self::FIELD_COMPANY,
				'label'      => __( 'Empresa', 'lachinata-core' ),
				'location'   => 'order',
				'type'       => 'text',
				'required'   => $ticked,
				'hidden'     => array( 'not' => $ticked ),
				'attributes' => array( 'autocomplete' => 'organization' ),
			)
		);
		woocommerce_register_additional_checkout_field(
			array(
				'id'         => self::FIELD_TAX_ID,
				'label'      => __( 'NIF / CIF', 'lachinata-core' ),
				'location'   => 'order',
				'type'       => 'text',
				'required'   => $ticked,
				'hidden'     => array( 'not' => $ticked ),
				'attributes' => array(
					'autocomplete'   => 'off',
					'autocapitalize' => 'characters',
				),
			)
		);
	}

	/**
	 * The tax id against the billing country.
	 *
	 * @param \WP_Error $errors   Errors.
	 * @param string    $field_id Field id.
	 * @param mixed     $value    Value.
	 */
	public static function validate_field( $errors, $field_id, $value ): void {
		if ( self::FIELD_TAX_ID !== $field_id || ! $errors instanceof \WP_Error || '' === trim( (string) $value ) ) {
			return;
		}
		$country = WC()->customer ? (string) WC()->customer->get_billing_country() : '';
		$check   = TaxId::check( (string) $value, $country );
		if ( '' !== $check['error'] ) {
			$errors->add( 'lachinata_invalid_tax_id', $check['error'] );
		}
	}

	/**
	 * Copies the checkout fields to `_lc_empresa` and `_lc_nif` when the box is ticked.
	 *
	 * @param \WC_Order $order Order.
	 */
	public static function from_checkout( $order ): void {
		if ( ! $order instanceof \WC_Order || ! wc_string_to_bool( (string) $order->get_meta( '_wc_other/' . self::FIELD_WANTS ) ) ) {
			return;
		}
		$errors = self::save( $order, (string) $order->get_meta( '_wc_other/' . self::FIELD_COMPANY ), (string) $order->get_meta( '_wc_other/' . self::FIELD_TAX_ID ) );
		if ( ! $errors ) {
			self::added( $order );
		}
	}

	/**
	 * Company and tax id of an order (empty strings when the order is a private customer's).
	 *
	 * @param \WC_Order $order Order.
	 * @return array{company: string, tax_id: string}
	 */
	public static function of( \WC_Order $order ): array {
		return array(
			'company' => (string) $order->get_meta( self::COMPANY ),
			'tax_id'  => (string) $order->get_meta( self::TAX_ID ),
		);
	}

	/**
	 * Validates and saves the details; nothing is saved when there is an error.
	 *
	 * @param \WC_Order $order   Order.
	 * @param string    $company Company name.
	 * @param string    $tax_id  Tax id.
	 * @return string[] Errors by field (`company`, `tax_id`); empty when saved.
	 */
	public static function save( \WC_Order $order, string $company, string $tax_id ): array {
		$company = trim( $company );
		$check   = TaxId::check( $tax_id, $order->get_billing_country() );
		$errors  = array();
		if ( '' === $company ) {
			$errors['company'] = __( 'Escribe el nombre de la empresa.', 'lachinata-core' );
		}
		if ( '' !== $check['error'] ) {
			$errors['tax_id'] = $check['error'];
		}
		if ( $errors ) {
			return $errors;
		}
		$order->update_meta_data( self::COMPANY, $company );
		$order->update_meta_data( self::TAX_ID, $check['id'] );
		$order->save();
		return array();
	}

	/**
	 * Under the billing address in the order edit screen.
	 *
	 * @param \WC_Order $order Order.
	 */
	public static function admin( $order ): void {
		if ( ! $order instanceof \WC_Order ) {
			return;
		}
		$details = self::of( $order );
		if ( '' === $details['tax_id'] ) {
			return;
		}
		printf(
			'<p><strong>%1$s</strong><br>%2$s<br>%3$s</p>',
			esc_html__( 'Factura a nombre de empresa', 'lachinata-core' ),
			esc_html( $details['company'] ),
			esc_html( $details['tax_id'] )
		);
	}

	/**
	 * In the order emails (customer and store).
	 *
	 * @param array<string, array{label: string, value: string}> $fields        Fields.
	 * @param bool                                               $sent_to_admin Whether it goes to the store.
	 * @param mixed                                              $order         Order.
	 * @return array<string, array{label: string, value: string}>
	 */
	public static function email_fields( $fields, $sent_to_admin, $order ): array {
		$fields = is_array( $fields ) ? $fields : array();
		unset( $sent_to_admin );
		if ( ! $order instanceof \WC_Order ) {
			return $fields;
		}
		$details = self::of( $order );
		if ( '' !== $details['tax_id'] ) {
			$fields['lc_empresa'] = array(
				'label' => __( 'Empresa', 'lachinata-core' ),
				'value' => $details['company'],
			);
			$fields['lc_nif']     = array(
				'label' => __( 'NIF', 'lachinata-core' ),
				'value' => $details['tax_id'],
			);
		}
		return $fields;
	}

	/**
	 * `invoice` in the `lachinata` object of the REST API: company and tax id, or null for
	 * a private customer.
	 *
	 * @param array<string, mixed> $data  Object.
	 * @param \WC_Order            $order Order.
	 * @return array<string, mixed>
	 */
	public static function rest_data( array $data, \WC_Order $order ): array {
		$details         = self::of( $order );
		$data['invoice'] = '' === $details['company'] && '' === $details['tax_id'] ? null : array(
			'company' => $details['company'],
			'tax_id'  => $details['tax_id'],
		);
		return $data;
	}

	/**
	 * Alias of 0.5.1, `lachinata_invoice` (empresa, nif): the same data as
	 * `lachinata.invoice`. Kept while something reads it (docs/api-odoo.md).
	 *
	 * @param mixed $response Response.
	 * @param mixed $order    Order.
	 * @return mixed
	 */
	public static function rest( $response, $order ): mixed {
		if ( $response instanceof \WP_REST_Response && $order instanceof \WC_Order ) {
			$data                      = (array) $response->get_data();
			$details                   = self::of( $order );
			$data['lachinata_invoice'] = array(
				'empresa' => $details['company'],
				'nif'     => $details['tax_id'],
			);
			$response->set_data( $data );
		}
		return $response;
	}

	/**
	 * On the order in the customer's account.
	 *
	 * @param int $order_id Order id.
	 */
	public static function view_order( $order_id ): void {
		$order = wc_get_order( (int) $order_id );
		if ( $order instanceof \WC_Order ) {
			self::form( $order );
		}
	}

	/**
	 * «¿Necesitas factura con NIF?» while the order has none; the details once it has them.
	 *
	 * @param \WC_Order $order Order.
	 */
	public static function form( \WC_Order $order ): void {
		if ( $order->has_status( array( 'failed', 'cancelled', 'refunded' ) ) ) {
			return;
		}
		$details = self::of( $order );
		$errors  = self::$errors[ $order->get_id() ] ?? array();
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display only.
		$saved = isset( $_GET['lc-factura'] ) && '' !== $details['tax_id'];
		if ( '' !== $details['tax_id'] ) {
			?>
			<section class="lc-invoice lc-invoice--done" aria-labelledby="lc-invoice-title-<?php echo esc_attr( (string) $order->get_id() ); ?>">
				<span class="h4" id="lc-invoice-title-<?php echo esc_attr( (string) $order->get_id() ); ?>"><?php esc_html_e( 'Factura a nombre de empresa', 'lachinata-core' ); ?></span>
				<span class="body-sm" data-no-translation><?php echo esc_html( $details['company'] . ' · ' . $details['tax_id'] ); ?></span>
				<?php if ( $saved ) : ?>
					<span class="caption"><?php esc_html_e( 'Datos guardados: la factura se emitirá a este NIF.', 'lachinata-core' ); ?></span>
				<?php endif; ?>
			</section>
			<?php
			return;
		}
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Values echoed back after a failed submit, verified in handle().
		$company = isset( $_POST['lc_empresa'] ) ? sanitize_text_field( wp_unslash( $_POST['lc_empresa'] ) ) : '';
		$tax_id  = isset( $_POST['lc_nif'] ) ? sanitize_text_field( wp_unslash( $_POST['lc_nif'] ) ) : '';
		// phpcs:enable
		$id = 'lc-invoice-' . $order->get_id();
		?>
		<details class="lc-invoice"<?php echo $errors ? ' open' : ''; ?>>
			<summary class="lc-invoice__summary">
				<span class="h4"><?php esc_html_e( '¿Necesitas factura con NIF?', 'lachinata-core' ); ?></span>
				<span class="body-sm"><?php esc_html_e( 'Añade los datos de tu empresa.', 'lachinata-core' ); ?></span>
			</summary>
			<form method="post" class="lc-invoice__form" novalidate>
				<?php wp_nonce_field( self::ACTION . '_' . $order->get_id(), 'lc_invoice_nonce' ); ?>
				<input type="hidden" name="lc_invoice_order" value="<?php echo esc_attr( (string) $order->get_id() ); ?>">
				<?php
				self::field( $id . '-empresa', 'lc_empresa', __( 'Empresa', 'lachinata-core' ), $company, 'organization', $errors['company'] ?? '' );
				self::field( $id . '-nif', 'lc_nif', __( 'NIF / CIF', 'lachinata-core' ), $tax_id, 'off', $errors['tax_id'] ?? '', __( 'La factura se emite a este NIF.', 'lachinata-core' ) );
				?>
				<button type="submit" class="lc-btn button lc-btn--secondary lc-btn--block"><?php esc_html_e( 'Guardar datos de factura', 'lachinata-core' ); ?></button>
			</form>
		</details>
		<?php
	}

	/**
	 * A Field of the system.
	 *
	 * @param string $id           Input id.
	 * @param string $name         Input name.
	 * @param string $label        Label.
	 * @param string $value        Value.
	 * @param string $autocomplete Autocomplete.
	 * @param string $error        Error (replaces the help).
	 * @param string $help         Help.
	 */
	private static function field( string $id, string $name, string $label, string $value, string $autocomplete, string $error, string $help = '' ): void {
		$note = '' !== $error ? $error : $help;
		?>
		<div class="lc-field<?php echo '' !== $error ? ' lc-field--error' : ''; ?>">
			<label for="<?php echo esc_attr( $id ); ?>" class="label"><?php echo esc_html( $label ); ?></label>
			<div class="lc-field__box">
				<input type="text" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>" autocomplete="<?php echo esc_attr( $autocomplete ); ?>" required<?php echo '' !== $error ? ' aria-invalid="true"' : ''; ?><?php echo '' !== $note ? ' aria-describedby="' . esc_attr( $id ) . '-help"' : ''; ?>>
			</div>
			<?php if ( '' !== $note ) : ?>
				<span class="lc-field__help body-sm" id="<?php echo esc_attr( $id ); ?>-help"><?php echo esc_html( $note ); ?></span>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Saves the form: on the thank you page the order key in the URL proves the visitor placed
	 * the order; in the account, the order must be the customer's.
	 */
	public static function handle(): void {
		// phpcs:disable WordPress.Security.NonceVerification -- Verified below.
		if ( ! isset( $_POST['lc_invoice_order'], $_POST['lc_invoice_nonce'] ) ) {
			return;
		}
		$order = wc_get_order( absint( $_POST['lc_invoice_order'] ) );
		if ( ! $order instanceof \WC_Order || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['lc_invoice_nonce'] ) ), self::ACTION . '_' . $order->get_id() ) ) {
			return;
		}
		$key     = isset( $_GET['key'] ) ? sanitize_text_field( wp_unslash( $_GET['key'] ) ) : '';
		$allowed = ( '' !== $key && hash_equals( $order->get_order_key(), $key ) )
			|| ( is_user_logged_in() && (int) $order->get_customer_id() === get_current_user_id() );
		if ( ! $allowed || '' !== self::of( $order )['tax_id'] ) {
			return;
		}
		$errors = self::save(
			$order,
			isset( $_POST['lc_empresa'] ) ? sanitize_text_field( wp_unslash( $_POST['lc_empresa'] ) ) : '',
			isset( $_POST['lc_nif'] ) ? sanitize_text_field( wp_unslash( $_POST['lc_nif'] ) ) : ''
		);
		// phpcs:enable
		if ( $errors ) {
			self::$errors[ $order->get_id() ] = $errors;
			return;
		}
		$order->add_order_note( __( 'El cliente ha añadido los datos de empresa para la factura después de pagar.', 'lachinata-core' ) );
		self::added( $order );
		$url = '' !== $key ? $order->get_checkout_order_received_url() : $order->get_view_order_url();
		wp_safe_redirect( add_query_arg( 'lc-factura', '1', $url ) );
		exit;
	}

	/**
	 * Company details added to an order (in the checkout or after paying).
	 *
	 * @param \WC_Order $order Order.
	 */
	public static function added( \WC_Order $order ): void {
		/**
		 * Fires when an order gets its company invoice details (`_lc_empresa`, `_lc_nif`), in
		 * the checkout or after paying. The Odoo module listens to it to issue the invoice.
		 *
		 * @since 0.6.0
		 *
		 * @param \WC_Order $order Order.
		 */
		do_action( 'lachinata/checkout/invoice_details', $order );
	}
}
