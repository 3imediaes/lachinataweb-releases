<?php
/**
 * WooCommerce → La Chinata → Regalo.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Gift;

use LaChinata\Core\Admin\Screen;
use LaChinata\Core\Modules\Shipping\ShippingTab;
use LaChinata\Core\Plugin;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * When the notice leaves, how long the recipient's contact is kept, the privacy text, the
 * OVH credentials (with a test SMS) and the notices that could not be sent.
 */
final class GiftTab {

	/**
	 * Tab id.
	 */
	public const TAB = 'gift';

	/**
	 * Actions of admin-post.php, also nonce actions.
	 */
	private const SAVE       = 'lachinata_gift_settings';
	private const TEST_SMS   = 'lachinata_gift_test_sms';
	private const CLEAR_GAPS = 'lachinata_gift_clear_gaps';

	/**
	 * OVH credentials kept when their field is sent empty (they are never printed back).
	 */
	private const SECRETS = array( 'ovh_app_secret', 'ovh_consumer_key' );

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_filter( 'lachinata/core/admin_tabs', array( self::class, 'tab' ), 31 );
		foreach ( array( self::SAVE, self::TEST_SMS, self::CLEAR_GAPS ) as $action ) {
			add_action( 'admin_post_' . $action, array( self::class, 'handle' ) );
		}
	}

	/**
	 * Adds the tab after Checkout.
	 *
	 * @param array<string, array{label: string, render: callable}> $tabs Tabs.
	 * @return array<string, array{label: string, render: callable}>
	 */
	public static function tab( array $tabs ): array {
		$position = array_search( 'checkout', array_keys( $tabs ), true );
		$position = false === $position ? 1 : $position + 1;
		$tab      = array(
			self::TAB => array(
				'label'  => __( 'Regalo', 'lachinata-core' ),
				'render' => array( self::class, 'render' ),
			),
		);
		return array_slice( $tabs, 0, $position, true ) + $tab + $tabs;
	}

	/**
	 * Prints the tab.
	 */
	public static function render(): void {
		$sections = array(
			'settings' => __( 'Ajustes', 'lachinata-core' ),
			'gaps'     => __( 'Huecos de configuración', 'lachinata-core' ),
		);
		$current  = isset( $_GET['section'] ) ? sanitize_key( wp_unslash( $_GET['section'] ) ) : 'settings'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Navigation only.
		$current  = isset( $sections[ $current ] ) ? $current : 'settings';
		ShippingTab::section_links( self::TAB, $sections, $current );
		if ( 'gaps' === $current ) {
			self::render_gaps();
		} else {
			self::render_settings();
		}
	}

	/**
	 * Settings section.
	 */
	private static function render_settings(): void {
		$module = Plugin::instance()->modules()->get( 'gift' );
		if ( null === $module ) {
			return;
		}
		$values   = Settings::all( $module );
		$statuses = (array) $values['notify_statuses'];
		$provider = Notifier::sms_provider();
		$text     = (string) $values['privacy_text'];
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE ); ?>">
			<?php wp_nonce_field( self::SAVE ); ?>
			<h2><?php esc_html_e( 'Aviso a quien lo recibe', 'lachinata-core' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Se envía cuando el pedido pasa a', 'lachinata-core' ); ?></th>
					<td>
						<fieldset>
							<?php foreach ( wc_get_order_statuses() as $key => $label ) : ?>
								<?php $status = str_replace( 'wc-', '', $key ); ?>
								<?php if ( in_array( $status, array( 'pending', 'failed', 'cancelled', 'refunded', 'checkout-draft' ), true ) ) : ?>
									<?php continue; ?>
								<?php endif; ?>
								<label><input type="checkbox" name="notify_statuses[]" value="<?php echo esc_attr( $status ); ?>" <?php checked( in_array( $status, $statuses, true ) ); ?>> <?php echo esc_html( $label ); ?></label><br>
							<?php endforeach; ?>
						</fieldset>
						<p class="description"><?php esc_html_e( 'Por defecto, «Completado» (lo marca Odoo cuando sale el paquete). Un solo aviso por pedido: si hay seguimiento en ese momento, lleva el enlace; si no, solo la fecha.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="lc-gift-about"><?php esc_html_e( 'Enlace «¿Qué es La Chinata?»', 'lachinata-core' ); ?></label></th>
					<td>
						<input type="url" class="regular-text" id="lc-gift-about" name="about_url" value="<?php echo esc_attr( (string) $values['about_url'] ); ?>" placeholder="<?php echo esc_attr( home_url( '/' ) ); ?>">
						<p class="description"><?php esc_html_e( 'Pie del correo a quien lo recibe. Vacío: la portada.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
			</table>

			<h2><?php esc_html_e( 'Datos personales', 'lachinata-core' ); ?></h2>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="lc-gift-days"><?php esc_html_e( 'Borrar el contacto', 'lachinata-core' ); ?></label></th>
					<td>
						<?php
						printf(
							/* translators: %s: number field. */
							esc_html__( '%s días después de la entrega', 'lachinata-core' ),
							'<input type="number" min="1" max="365" step="1" class="small-text" id="lc-gift-days" name="erase_days" value="' . esc_attr( (string) $values['erase_days'] ) . '">' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts.
						);
						?>
						<p class="description"><?php esc_html_e( 'El correo o el móvil de quien recibe el regalo solo se guarda en el pedido y solo para el aviso: no crea cuenta ni entra en ninguna lista.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="lc-gift-privacy"><?php esc_html_e( 'Texto de privacidad', 'lachinata-core' ); ?></label></th>
					<td>
						<textarea class="large-text" rows="6" id="lc-gift-privacy" name="privacy_text" placeholder="<?php echo esc_attr( Privacy::DRAFT ); ?>"><?php echo esc_textarea( $text ); ?></textarea>
						<p class="description"><?php esc_html_e( 'Se ofrece en Ajustes → Privacidad → Guía de la política de privacidad. {dias} se cambia por los días de arriba. Vacío: el borrador provisional, pendiente de revisión.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
			</table>

			<h2><?php esc_html_e( 'SMS (OVH)', 'lachinata-core' ); ?></h2>
			<p>
				<?php
				echo esc_html(
					'ovh' === $provider->id()
						? __( 'Los SMS salen por OVH.', 'lachinata-core' )
						/* translators: %s: provider name. */
						: sprintf( __( 'Sin las credenciales de OVH, los SMS no se envían: quedan en el registro (%s), en WooCommerce → Estado → Registros (lachinata-gift).', 'lachinata-core' ), $provider->label() )
				);
				?>
			</p>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="lc-ovh-endpoint"><?php esc_html_e( 'API', 'lachinata-core' ); ?></label></th>
					<td>
						<select id="lc-ovh-endpoint" name="ovh_endpoint">
							<?php foreach ( array_keys( Sms\OvhProvider::ENDPOINTS ) as $endpoint ) : ?>
								<option value="<?php echo esc_attr( $endpoint ); ?>" <?php selected( $values['ovh_endpoint'], $endpoint ); ?>><?php echo esc_html( $endpoint ); ?></option>
							<?php endforeach; ?>
						</select>
					</td>
				</tr>
				<?php
				$fields = array(
					'ovh_app_key'      => __( 'Application key', 'lachinata-core' ),
					'ovh_app_secret'   => __( 'Application secret', 'lachinata-core' ),
					'ovh_consumer_key' => __( 'Consumer key', 'lachinata-core' ),
					'ovh_service'      => __( 'Servicio SMS', 'lachinata-core' ),
					'ovh_sender'       => __( 'Remitente', 'lachinata-core' ),
				);
				?>
				<?php foreach ( $fields as $key => $label ) : ?>
					<?php $is_secret = in_array( $key, self::SECRETS, true ); ?>
					<tr>
						<th scope="row"><label for="lc-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
						<td>
							<input type="<?php echo $is_secret ? 'password' : 'text'; ?>" class="regular-text" id="lc-<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $key ); ?>" value="<?php echo $is_secret ? '' : esc_attr( (string) $values[ $key ] ); ?>" autocomplete="off" placeholder="<?php echo $is_secret && '' !== (string) $values[ $key ] ? esc_attr__( 'Guardada (escribe otra para cambiarla)', 'lachinata-core' ) : ''; ?>">
							<?php if ( 'ovh_service' === $key ) : ?>
								<p class="description"><?php esc_html_e( 'Nombre de la cuenta SMS en OVH, como sms-ab12345-1.', 'lachinata-core' ); ?></p>
							<?php elseif ( 'ovh_sender' === $key ) : ?>
								<p class="description"><?php esc_html_e( 'Remitente dado de alta y validado en esa cuenta (hasta 11 letras y números).', 'lachinata-core' ); ?></p>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</table>
			<p class="description"><?php esc_html_e( 'Las credenciales se guardan solo en este sitio: no salen en la exportación de configuración.', 'lachinata-core' ); ?></p>
			<?php submit_button(); ?>
		</form>

		<h2><?php esc_html_e( 'Probar el SMS', 'lachinata-core' ); ?></h2>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::TEST_SMS ); ?>">
			<?php wp_nonce_field( self::TEST_SMS ); ?>
			<p>
				<label for="lc-gift-test"><?php esc_html_e( 'Móvil', 'lachinata-core' ); ?></label>
				<input type="tel" id="lc-gift-test" name="mobile" class="regular-text" placeholder="600 000 000" autocomplete="off">
				<?php submit_button( __( 'Enviar un SMS de prueba', 'lachinata-core' ), 'secondary', 'submit', false ); ?>
			</p>
		</form>
		<?php
	}

	/**
	 * Gaps section: notices that did not leave.
	 */
	private static function render_gaps(): void {
		$log = Notifier::gaps()->all();
		?>
		<h2><?php esc_html_e( 'Avisos que no salieron', 'lachinata-core' ); ?></h2>
		<p class="description"><?php esc_html_e( 'Un aviso que falla no bloquea el pedido: queda en su nota, aquí y en WooCommerce → Estado → Registros (lachinata-gift).', 'lachinata-core' ); ?></p>
		<?php if ( $log ) : ?>
			<table class="widefat striped">
				<thead><tr><th scope="col"><?php esc_html_e( 'Qué pasó', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Veces', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Última', 'lachinata-core' ); ?></th></tr></thead>
				<tbody>
					<?php foreach ( $log as $entry ) : ?>
						<tr>
							<td><?php echo esc_html( $entry['message'] ); ?></td>
							<td><?php echo esc_html( number_format_i18n( $entry['count'] ) ); ?></td>
							<td><?php echo esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $entry['last'] ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::CLEAR_GAPS ); ?>">
				<?php wp_nonce_field( self::CLEAR_GAPS ); ?>
				<?php submit_button( __( 'Vaciar la lista', 'lachinata-core' ), 'secondary' ); ?>
			</form>
		<?php else : ?>
			<p><?php esc_html_e( 'Ninguno registrado.', 'lachinata-core' ); ?></p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Saves the settings, sends the test SMS or empties the gap log.
	 */
	public static function handle(): void {
		$action = (string) preg_replace( '/^admin_post_/', '', current_action() );
		Screen::check( $action );
		$module = Plugin::instance()->modules()->get( 'gift' );
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Screen::check().
		if ( self::SAVE === $action && null !== $module ) {
			$statuses = isset( $_POST['notify_statuses'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['notify_statuses'] ) ) : array();
			Settings::set( $module, 'notify_statuses', $statuses ? array_values( $statuses ) : array( 'completed' ) );
			Settings::set( $module, 'erase_days', max( 1, min( 365, isset( $_POST['erase_days'] ) ? absint( $_POST['erase_days'] ) : 30 ) ) );
			Settings::set( $module, 'privacy_text', isset( $_POST['privacy_text'] ) ? sanitize_textarea_field( wp_unslash( $_POST['privacy_text'] ) ) : '' );
			Settings::set( $module, 'about_url', isset( $_POST['about_url'] ) ? esc_url_raw( wp_unslash( $_POST['about_url'] ) ) : '' );
			$endpoint = isset( $_POST['ovh_endpoint'] ) ? sanitize_key( wp_unslash( $_POST['ovh_endpoint'] ) ) : 'ovh-eu';
			Settings::set( $module, 'ovh_endpoint', isset( Sms\OvhProvider::ENDPOINTS[ $endpoint ] ) ? $endpoint : 'ovh-eu' );
			foreach ( array( 'ovh_app_key', 'ovh_app_secret', 'ovh_consumer_key', 'ovh_service', 'ovh_sender' ) as $key ) {
				$value = isset( $_POST[ $key ] ) ? trim( sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) ) : '';
				if ( '' === $value && in_array( $key, self::SECRETS, true ) ) {
					continue;
				}
				Settings::set( $module, $key, $value );
			}
			Screen::flash( 'success', array( __( 'Ajustes guardados.', 'lachinata-core' ) ) );
			Screen::redirect( self::TAB, array( 'section' => 'settings' ) );
		}
		if ( self::TEST_SMS === $action ) {
			$mobile = Sms\Phone::normalize( isset( $_POST['mobile'] ) ? sanitize_text_field( wp_unslash( $_POST['mobile'] ) ) : '', 'ES' );
			if ( null === $mobile ) {
				Screen::flash( 'error', array( __( 'Escribe un móvil válido, con el prefijo si no es de España.', 'lachinata-core' ) ) );
			} else {
				$provider = Notifier::sms_provider();
				try {
					/* translators: %s: shop name. */
					$provider->send( $mobile, sprintf( __( 'Prueba del aviso de regalo de %s. Si lo lees, los SMS funcionan.', 'lachinata-core' ), Notifier::brand() ) );
					/* translators: 1: provider name, 2: masked mobile. */
					Screen::flash( 'success', array( sprintf( __( 'SMS de prueba enviado por %1$s a %2$s.', 'lachinata-core' ), $provider->label(), Sms\LogProvider::mask( $mobile ) ) ) );
				} catch ( \Throwable $error ) {
					/* translators: %s: reason. */
					Screen::flash( 'error', array( sprintf( __( 'No se pudo enviar el SMS de prueba: %s', 'lachinata-core' ), $error->getMessage() ) ) );
				}
			}
			Screen::redirect( self::TAB, array( 'section' => 'settings' ) );
		}
		// phpcs:enable
		Notifier::gaps()->clear();
		Screen::flash( 'success', array( __( 'Lista vaciada.', 'lachinata-core' ) ) );
		Screen::redirect( self::TAB, array( 'section' => 'gaps' ) );
	}
}
