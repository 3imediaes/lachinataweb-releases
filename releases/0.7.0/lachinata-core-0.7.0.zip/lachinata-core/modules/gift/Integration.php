<?php
/**
 * Script of the gift card, loaded by WooCommerce's checkout block.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Gift;

use Automattic\WooCommerce\Blocks\Integrations\IntegrationInterface;

defined( 'ABSPATH' ) || exit;

/**
 * Loads src/index.js after the checkout module's script (which creates the slot) and passes
 * it the account name for «De parte de» and the customer's saved delivery address, so the
 * card can suggest the gift when the parcel goes somewhere else.
 */
final class Integration implements IntegrationInterface {

	/**
	 * Script handle.
	 */
	public const HANDLE = 'lachinata-gift';

	/**
	 * Name of the integration (the setting is `lachinata-gift_data`).
	 */
	public function get_name(): string {
		return 'lachinata-gift';
	}

	/**
	 * Registers the script.
	 */
	public function initialize(): void {
		$dir   = LACHINATA_CORE_DIR . '/modules/gift/build';
		$asset = is_readable( $dir . '/gift.asset.php' ) ? require $dir . '/gift.asset.php' : array(
			'dependencies' => array(),
			'version'      => LACHINATA_CORE_VERSION,
		);
		wp_register_script(
			self::HANDLE,
			plugins_url( 'modules/gift/build/gift.js', LACHINATA_CORE_FILE ),
			array_merge( $asset['dependencies'], array( 'lachinata-checkout', 'wc-blocks-checkout', 'wc-settings' ) ),
			$asset['version'],
			true
		);
		wp_set_script_translations( self::HANDLE, 'lachinata-core', LACHINATA_CORE_DIR . '/languages' );
	}

	/**
	 * Scripts for the checkout page.
	 *
	 * @return string[]
	 */
	public function get_script_handles(): array {
		return array( self::HANDLE );
	}

	/**
	 * No editor script.
	 *
	 * @return string[]
	 */
	public function get_editor_script_handles(): array {
		return array();
	}

	/**
	 * Data for the script.
	 *
	 * @return array<string, mixed>
	 */
	public function get_script_data(): array {
		$data = array(
			'messageMax'   => Gift::MESSAGE_MAX,
			'nameMax'      => Gift::NAME_MAX,
			'loggedIn'     => is_user_logged_in(),
			'accountName'  => '',
			'savedAddress' => null,
		);
		if ( ! is_user_logged_in() ) {
			return $data;
		}
		$customer            = new \WC_Customer( get_current_user_id() );
		$name                = trim( $customer->get_first_name() . ' ' . $customer->get_last_name() );
		$name                = '' !== $name ? $name : trim( $customer->get_billing_first_name() . ' ' . $customer->get_billing_last_name() );
		$data['accountName'] = '' !== $name ? $name : (string) wp_get_current_user()->display_name;
		if ( '' !== $customer->get_shipping_address_1() ) {
			$data['savedAddress'] = array(
				'address_1' => $customer->get_shipping_address_1(),
				'postcode'  => $customer->get_shipping_postcode(),
				'country'   => $customer->get_shipping_country(),
			);
		}
		return $data;
	}
}
