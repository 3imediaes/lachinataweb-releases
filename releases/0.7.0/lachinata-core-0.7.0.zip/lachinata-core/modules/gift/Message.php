<?php
/**
 * Texts of the gift notice.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Gift;

use LaChinata\Core\Modules\Eta\Estimate;
use LaChinata\Core\Modules\Eta\Format;

defined( 'ABSPATH' ) || exit;

/**
 * What the recipient reads (tablero Regalo, 5 and 6): who sends it, when it arrives and,
 * when there is tracking, where to follow it. Never what it is nor what it cost.
 *
 * The SMS keeps its accents (UCS-2) and fits in two segments, SMS_MAX characters. When the
 * full text does not fit it drops, in this order: the carrier, «No tienes que pagar nada.»
 * and the greeting; then it shortens «De parte de». The date and the link always stay.
 */
final class Message {

	/**
	 * Two UCS-2 segments of a concatenated SMS (67 characters each).
	 */
	public const SMS_MAX = 134;

	/**
	 * Builds the texts of one notice.
	 *
	 * @param string        $to       Recipient («María»).
	 * @param string        $from     «De parte de» («Alberto»).
	 * @param string        $brand    Sender name («La Chinata»).
	 * @param Estimate|null $estimate Delivery dates, or null.
	 * @param string|null   $carrier  Carrier name, or null.
	 * @param string        $address  Short delivery address («Calle Mayor 3, Plasencia»).
	 * @param string        $link     Tracking link, or empty.
	 */
	public function __construct(
		public readonly string $to,
		public readonly string $from,
		public readonly string $brand,
		public readonly ?Estimate $estimate,
		public readonly ?string $carrier,
		public readonly string $address,
		public readonly string $link,
	) {}

	/**
	 * «Alberto te envía un regalo de La Chinata».
	 */
	public function subject(): string {
		/* translators: 1: who sends the gift, 2: shop name. */
		return sprintf( __( '%1$s te envía un regalo de %2$s', 'lachinata-core' ), $this->from, $this->brand );
	}

	/**
	 * «Hola, María.»
	 */
	public function greeting(): string {
		/* translators: %s: recipient name. */
		return '' === $this->to ? __( 'Hola.', 'lachinata-core' ) : sprintf( __( 'Hola, %s.', 'lachinata-core' ), $this->to );
	}

	/**
	 * Paragraph of the email with who, when, with whom and where. `%1$s` (the sender) is
	 * where the email puts the name in bold.
	 *
	 * @param string $from Sender as it goes in the email (escaped, maybe in <strong>).
	 * @param string $when Dates as they go in the email (escaped, maybe in <strong>).
	 */
	public function lead( string $from, string $when ): string {
		$address = '' === $this->address ? '' : ' ' . $this->address;
		if ( null === $this->estimate && null !== $this->carrier ) {
			/* translators: 1: who sends the gift, 2: carrier. */
			return sprintf( __( '%1$s ha preparado un regalo para ti y ya está en camino con %2$s.', 'lachinata-core' ), $from, esc_html( $this->carrier ) );
		}
		if ( null === $this->estimate ) {
			/* translators: %s: who sends the gift. */
			return sprintf( __( '%s ha preparado un regalo para ti y ya está en camino.', 'lachinata-core' ), $from );
		}
		if ( null !== $this->carrier && '' !== $address ) {
			/* translators: 1: who sends the gift, 2: carrier, 3: delivery dates («entre el jueves 24 y el viernes 25 de octubre»), 4: delivery address. */
			return sprintf( __( '%1$s ha preparado un regalo para ti y ya está en camino. Llega con %2$s %3$s a %4$s.', 'lachinata-core' ), $from, esc_html( $this->carrier ), $when, esc_html( $this->address ) );
		}
		if ( null !== $this->carrier ) {
			/* translators: 1: who sends the gift, 2: carrier, 3: delivery dates. */
			return sprintf( __( '%1$s ha preparado un regalo para ti y ya está en camino. Llega con %2$s %3$s.', 'lachinata-core' ), $from, esc_html( $this->carrier ), $when );
		}
		if ( '' !== $address ) {
			/* translators: 1: who sends the gift, 2: delivery dates, 3: delivery address. */
			return sprintf( __( '%1$s ha preparado un regalo para ti y ya está en camino. Llega %2$s a %3$s.', 'lachinata-core' ), $from, $when, esc_html( $this->address ) );
		}
		/* translators: 1: who sends the gift, 2: delivery dates. */
		return sprintf( __( '%1$s ha preparado un regalo para ti y ya está en camino. Llega %2$s.', 'lachinata-core' ), $from, $when );
	}

	/**
	 * Dates inside the email sentence, or empty.
	 */
	public function when(): string {
		return null === $this->estimate ? '' : Format::between( $this->estimate );
	}

	/**
	 * «No tienes que pagar nada…»: changing the delivery only with tracking.
	 */
	public function reassurance(): string {
		return '' === $this->link
			? __( 'No tienes que pagar nada ni hacer nada: solo recogerlo.', 'lachinata-core' )
			: __( 'No tienes que pagar nada ni hacer nada: solo recogerlo. Si no vas a estar, puedes cambiar el día o el lugar de entrega.', 'lachinata-core' );
	}

	/**
	 * Why the recipient gets the email.
	 */
	public function why(): string {
		/* translators: %s: who sends the gift. */
		return sprintf( __( 'Te escribimos porque %s nos dio tu correo solo para este aviso. No lo usaremos para nada más.', 'lachinata-core' ), $this->from );
	}

	/**
	 * The SMS, at most SMS_MAX characters.
	 *
	 * @param string $link Short link (without scheme) or empty.
	 */
	public function sms( string $link ): string {
		$from = $this->from;
		for ( $cut = 0; $cut < 60; $cut++ ) {
			foreach ( array( 'full', 'no_carrier', 'no_pay', 'no_greeting' ) as $step ) {
				$text = $this->sms_variant( $step, $from, $link );
				if ( self::length( $text ) <= self::SMS_MAX ) {
					return $text;
				}
			}
			if ( mb_strlen( $from ) <= 8 ) {
				break;
			}
			$from = rtrim( mb_substr( $from, 0, mb_strlen( $from ) - 2 ) ) . '…';
		}
		return mb_substr( $this->sms_variant( 'no_greeting', $from, $link ), 0, self::SMS_MAX );
	}

	/**
	 * One version of the SMS.
	 *
	 * @param string $step Which parts are left out.
	 * @param string $from «De parte de», maybe shortened.
	 * @param string $link Short link or empty.
	 */
	private function sms_variant( string $step, string $from, string $link ): string {
		$parts = array();
		if ( 'no_greeting' !== $step ) {
			$parts[] = $this->greeting();
		}
		$carrier = 'full' === $step ? $this->carrier : null;
		if ( null === $this->estimate ) {
			/* translators: 1: who sends the gift, 2: shop name. */
			$parts[] = sprintf( __( '%1$s te envía un regalo de %2$s: ya está en camino.', 'lachinata-core' ), $from, $this->brand );
		} elseif ( null !== $carrier ) {
			/* translators: 1: who sends the gift, 2: shop name, 3: delivery dates («jue 24 – vie 25 oct»), 4: carrier. */
			$parts[] = sprintf( __( '%1$s te envía un regalo de %2$s: llega %3$s con %4$s.', 'lachinata-core' ), $from, $this->brand, Format::span( $this->estimate ), $carrier );
		} else {
			/* translators: 1: who sends the gift, 2: shop name, 3: delivery dates («jue 24 – vie 25 oct»). */
			$parts[] = sprintf( __( '%1$s te envía un regalo de %2$s: llega %3$s.', 'lachinata-core' ), $from, $this->brand, Format::span( $this->estimate ) );
		}
		if ( in_array( $step, array( 'full', 'no_carrier' ), true ) ) {
			$parts[] = __( 'No tienes que pagar nada.', 'lachinata-core' );
		}
		if ( '' !== $link ) {
			/* translators: %s: short tracking link. */
			$parts[] = sprintf( __( 'Sigue el paquete: %s', 'lachinata-core' ), $link );
		}
		return implode( ' ', $parts );
	}

	/**
	 * Length in UCS-2 code units (an emoji counts two).
	 *
	 * @param string $text Text.
	 */
	public static function length( string $text ): int {
		return (int) ( strlen( (string) mb_convert_encoding( $text, 'UTF-16BE', 'UTF-8' ) ) / 2 );
	}

	/**
	 * Whether the text fits GSM 03.38 (7 bits); otherwise it goes as UCS-2.
	 *
	 * @param string $text Text.
	 */
	public static function is_gsm( string $text ): bool {
		$basic = "@£\$¥èéùìòÇ\nØø\rÅåΔ_ΦΓΛΩΠΨΣΘΞÆæßÉ !\"#¤%&'()*+,-./0123456789:;<=>?¡ABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÑÜ§¿abcdefghijklmnopqrstuvwxyzäöñüà^{}\\[~]|€";
		foreach ( mb_str_split( $text ) as $char ) {
			if ( ! str_contains( $basic, $char ) ) {
				return false;
			}
		}
		return true;
	}
}
