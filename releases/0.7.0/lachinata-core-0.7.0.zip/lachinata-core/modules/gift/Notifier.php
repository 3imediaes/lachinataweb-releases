<?php
/**
 * The notice to the recipient when the order is shipped.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Gift;

use LaChinata\Core\GapLog;
use LaChinata\Core\Modules\Eta\Rates;
use LaChinata\Core\Plugin;
use LaChinata\Core\Rest\OrderData;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * When the order reaches one of the module's statuses («completado» by default: the one
 * Odoo sets when the parcel leaves), the recipient gets the notice by email or SMS, once
 * per order. With tracking at that moment (WooCommerce Shipment Tracking, written by Odoo)
 * the notice carries the link; without it, only the dates, counted from the real dispatch
 * day. If the notice fails it is recorded (order note, Huecos de configuración, log) and the
 * order goes on: nothing here may stop a status change.
 */
final class Notifier {

	/**
	 * Runs before WooCommerce's own emails of the same status (priority 10), so the shipping
	 * email to the buyer can say the recipient was notified.
	 */
	private const PRIORITY = 5;

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		foreach ( self::statuses() as $status ) {
			add_action( 'woocommerce_order_status_' . $status, array( self::class, 'on_status' ), self::PRIORITY, 2 );
		}
	}

	/**
	 * Statuses that send the notice (setting, without the `wc-` prefix).
	 *
	 * @return string[]
	 */
	public static function statuses(): array {
		$module   = Plugin::instance()->modules()->get( 'gift' );
		$statuses = null === $module ? array() : (array) Settings::get( $module, 'notify_statuses' );
		$statuses = array_values( array_filter( array_map( static fn( $status ): string => sanitize_key( str_replace( 'wc-', '', (string) $status ) ), $statuses ) ) );
		return $statuses ? $statuses : array( 'completed' );
	}

	/**
	 * Status hook.
	 *
	 * @param int   $order_id Order id.
	 * @param mixed $order    Order.
	 */
	public static function on_status( $order_id, $order = null ): void {
		$order = $order instanceof \WC_Order ? $order : wc_get_order( (int) $order_id );
		if ( $order instanceof \WC_Order ) {
			self::notify( $order );
		}
	}

	/**
	 * Sends the notice of an order if it is due.
	 *
	 * @param \WC_Order $order Order.
	 * @return array{at: int, via: string, ok: bool, error: string, link: bool}|null What was done, null when nothing was due.
	 */
	public static function notify( \WC_Order $order ): ?array {
		$gift = Gift::of( $order );
		if ( null === $gift || $gift['legacy'] || 'none' === $gift['via'] || '' === $gift['contact'] || null !== Gift::notified( $order ) ) {
			return null;
		}

		$result   = array(
			'at'    => time(),
			'via'   => $gift['via'],
			'ok'    => false,
			'error' => '',
			'link'  => false,
			'ref'   => '',
		);
		$estimate = null;
		try {
			$tracking       = self::tracking( $order );
			$link           = null !== $tracking ? $tracking['url'] : '';
			$result['link'] = '' !== $link;
			$estimate       = self::estimate( $order, $tracking );
			$message        = new Message( $gift['to'], $gift['from'], self::brand(), $estimate, OrderData::carrier( $order ), self::address( $order ), $link );

			if ( 'email' === $gift['via'] ) {
				$result['error'] = self::email( $order, $message, $gift['contact'] );
			} else {
				$text          = $message->sms( '' === $link ? '' : ShortLink::for_order( $order ) );
				$result['ref'] = self::sms_provider()->send( $gift['contact'], $text );
			}
			$result['ok'] = '' === $result['error'];
		} catch ( \Throwable $error ) {
			$result['error'] = $error->getMessage();
		}

		$order->update_meta_data( Gift::META_NOTIFIED, $result );
		$order->save_meta_data();
		self::note( $order, $gift, $result );
		Privacy::schedule_erase( $order, $estimate );
		return Gift::notified( $order );
	}

	/**
	 * Sends the notice by email.
	 *
	 * @param \WC_Order $order     Order.
	 * @param Message   $message   Texts.
	 * @param string    $recipient Recipient's email.
	 * @return string Why it did not leave, or empty.
	 */
	private static function email( \WC_Order $order, Message $message, string $recipient ): string {
		$email = WC()->mailer()->get_emails()[ RecipientEmail::ID ] ?? null;
		if ( ! $email instanceof RecipientEmail || ! $email->is_enabled() ) {
			return __( 'el correo «Aviso de regalo» está desactivado en WooCommerce → Ajustes → Correos', 'lachinata-core' );
		}
		return $email->trigger( $order, $message, $recipient ) ? '' : __( 'WordPress no pudo enviar el correo', 'lachinata-core' );
	}

	/**
	 * Latest tracking of the order from the registered sources, or null.
	 *
	 * @param \WC_Order $order Order.
	 * @return array{carrier: string, number: string, url: string, shipped: int|null}|null
	 */
	public static function tracking( \WC_Order $order ): ?array {
		/**
		 * Where the tracking of an order comes from. Odoo writes it with WooCommerce
		 * Shipment Tracking; the `tracking` module may add its own source.
		 *
		 * @since 0.7.0
		 *
		 * @param Tracking\TrackingSource[] $sources Sources, first answer wins.
		 */
		$sources = (array) apply_filters( 'lachinata/gift/tracking_sources', array( new Tracking\ShipmentTracking() ) );
		foreach ( $sources as $source ) {
			$found = $source instanceof Tracking\TrackingSource ? $source->find( $order ) : null;
			if ( null !== $found ) {
				return $found;
			}
		}
		return null;
	}

	/**
	 * SMS provider: OVH with its credentials, «registro» without them.
	 */
	public static function sms_provider(): Sms\SmsProvider {
		$module   = Plugin::instance()->modules()->get( 'gift' );
		$provider = new Sms\LogProvider();
		if ( null !== $module ) {
			$ovh      = new Sms\OvhProvider(
				(string) Settings::get( $module, 'ovh_app_key' ),
				(string) Settings::get( $module, 'ovh_app_secret' ),
				(string) Settings::get( $module, 'ovh_consumer_key' ),
				(string) Settings::get( $module, 'ovh_service' ),
				(string) Settings::get( $module, 'ovh_sender' ),
				(string) Settings::get( $module, 'ovh_endpoint' )
			);
			$provider = $ovh->configured() ? $ovh : $provider;
		}

		/**
		 * SMS provider of the gift notice (Twilio, Vonage, Odoo… instead of OVH).
		 *
		 * @since 0.7.0
		 *
		 * @param Sms\SmsProvider $provider OVH when configured, otherwise «registro».
		 */
		$filtered = apply_filters( 'lachinata/gift/sms_provider', $provider );
		return $filtered instanceof Sms\SmsProvider ? $filtered : $provider;
	}

	/**
	 * Configuration gaps of the module.
	 */
	public static function gaps(): GapLog {
		return new GapLog( 'lachinata_gift_gaps', 'lachinata-gift' );
	}

	/**
	 * Delivery dates counted from the real dispatch day (the tracking's, or today), with the
	 * eta module; null without it.
	 *
	 * @param \WC_Order                                                                   $order    Order.
	 * @param array{carrier: string, number: string, url: string, shipped: int|null}|null $tracking Tracking.
	 */
	private static function estimate( \WC_Order $order, ?array $tracking ): ?\LaChinata\Core\Modules\Eta\Estimate {
		if ( ! lachinata_module( 'eta' ) ) {
			return null;
		}
		$zone  = wp_timezone();
		$ships = null !== $tracking && null !== $tracking['shipped']
			? ( new \DateTimeImmutable( '@' . $tracking['shipped'] ) )->setTimezone( $zone )
			: new \DateTimeImmutable( 'now', $zone );
		return Rates::shipped( $order, $ships );
	}

	/**
	 * Sender name of the shop's emails («La Chinata»).
	 */
	public static function brand(): string {
		$name = trim( wp_specialchars_decode( (string) get_option( 'woocommerce_email_from_name' ), ENT_QUOTES ) );
		return '' !== $name ? $name : wp_specialchars_decode( (string) get_bloginfo( 'name' ), ENT_QUOTES );
	}

	/**
	 * «Calle Mayor 3, Plasencia».
	 *
	 * @param \WC_Order $order Order.
	 */
	private static function address( \WC_Order $order ): string {
		return implode( ', ', array_filter( array( trim( $order->get_shipping_address_1() ), trim( $order->get_shipping_city() ) ) ) );
	}

	/**
	 * Order note (private) and, on failure, a configuration gap.
	 *
	 * @param \WC_Order                                       $order  Order.
	 * @param array{to: string, via: string, contact: string} $gift   Gift.
	 * @param array{ok: bool, error: string, link: bool}      $result Result.
	 */
	private static function note( \WC_Order $order, array $gift, array $result ): void {
		$channel = 'sms' === $gift['via'] ? __( 'SMS', 'lachinata-core' ) : __( 'correo', 'lachinata-core' );
		$contact = 'sms' === $gift['via'] ? Sms\LogProvider::mask( $gift['contact'] ) : $gift['contact'];
		if ( $result['ok'] ) {
			$order->add_order_note(
				$result['link']
					/* translators: 1: recipient, 2: channel (correo, SMS), 3: email or masked mobile. */
					? sprintf( __( 'Regalo: aviso enviado a %1$s por %2$s (%3$s), con el enlace de seguimiento.', 'lachinata-core' ), $gift['to'], $channel, $contact )
					/* translators: 1: recipient, 2: channel (correo, SMS), 3: email or masked mobile. */
					: sprintf( __( 'Regalo: aviso enviado a %1$s por %2$s (%3$s), sin seguimiento: solo con la fecha.', 'lachinata-core' ), $gift['to'], $channel, $contact )
			);
			return;
		}
		/* translators: 1: recipient, 2: channel (correo, SMS), 3: reason. */
		$text = sprintf( __( 'Regalo: no se pudo avisar a %1$s por %2$s (%3$s). El pedido sigue su curso; no se volverá a intentar.', 'lachinata-core' ), $gift['to'], $channel, $result['error'] );
		$order->add_order_note( $text );
		self::gaps()->record(
			'notify|' . $gift['via'] . '|' . md5( $result['error'] ),
			/* translators: 1: channel, 2: reason. */
			sprintf( __( 'Un aviso de regalo por %1$s no salió: %2$s.', 'lachinata-core' ), $channel, $result['error'] ),
			array( 'order' => $order->get_id() )
		);
	}
}
