<?php
/**
 * Personal data of the gift recipient.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Gift;

use LaChinata\Core\Modules\Eta\Estimate;
use LaChinata\Core\Plugin;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * The recipient's email or mobile is kept only on the order, only for the notice: it
 * creates no account and goes to no newsletter. Some days after the delivery (setting,
 * 30 by default) it is erased with an Action Scheduler job; an order that is cancelled,
 * refunded or failed counts from that moment. The module adds its paragraph to the privacy
 * policy guide (Ajustes → Privacidad) and an eraser to WordPress's personal data tools, for
 * the buyer's email and for the recipient's.
 */
final class Privacy {

	/**
	 * Action Scheduler hook and group.
	 */
	public const ERASE_HOOK = 'lachinata/gift/erase_contact';
	private const GROUP     = 'lachinata-gift';

	/**
	 * Draft of the privacy text. Provisional until Alberto reviews it (decisiones.md,
	 * 24/10/2026); `{dias}` is replaced by the days of the setting.
	 */
	public const DRAFT = '[Borrador provisional, pendiente de revisión] Si marcas un pedido como regalo y eliges avisar a quien lo recibe, nos das su nombre y su correo electrónico o su móvil. Los usamos solo para avisarle de que le llega un paquete, cuándo llega y, si lo hay, el enlace de seguimiento del transportista. La base es el interés legítimo de quien compra en que el regalo llegue y no se rechace. No creamos ninguna cuenta con ese dato, no lo añadimos a ninguna lista de correo ni lo usamos para nada más. Lo guardamos en el pedido y lo borramos {dias} días después de la entrega.';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_action( self::ERASE_HOOK, array( self::class, 'erase_job' ) );
		foreach ( array( 'cancelled', 'refunded', 'failed' ) as $status ) {
			add_action( 'woocommerce_order_status_' . $status, array( self::class, 'on_closed' ), 20, 2 );
		}
		add_action( 'admin_init', array( self::class, 'policy' ) );
		add_filter( 'wp_privacy_personal_data_erasers', array( self::class, 'register_eraser' ) );
	}

	/**
	 * Days after the delivery before the contact is erased.
	 */
	public static function days(): int {
		$module = Plugin::instance()->modules()->get( 'gift' );
		return max( 1, null === $module ? 30 : (int) Settings::get( $module, 'erase_days' ) );
	}

	/**
	 * Privacy text with the days in it.
	 */
	public static function text(): string {
		$module = Plugin::instance()->modules()->get( 'gift' );
		$text   = null === $module ? '' : trim( (string) Settings::get( $module, 'privacy_text' ) );
		return str_replace( '{dias}', number_format_i18n( self::days() ), '' !== $text ? $text : self::DRAFT );
	}

	/**
	 * Schedules the erasure of the contact: N days after the latest delivery date (or now).
	 *
	 * @param \WC_Order     $order    Order.
	 * @param Estimate|null $estimate Delivery dates.
	 */
	public static function schedule_erase( \WC_Order $order, ?Estimate $estimate ): void {
		if ( '' === (string) $order->get_meta( Gift::META_CONTACT ) || ! function_exists( 'as_schedule_single_action' ) ) {
			return;
		}
		$args = array( 'order_id' => $order->get_id() );
		if ( function_exists( 'as_has_scheduled_action' ) && as_has_scheduled_action( self::ERASE_HOOK, $args, self::GROUP ) ) {
			return;
		}
		$delivered = null === $estimate ? time() : max( time(), $estimate->max->setTime( 23, 59 )->getTimestamp() );
		as_schedule_single_action( $delivered + self::days() * DAY_IN_SECONDS, self::ERASE_HOOK, $args, self::GROUP );
	}

	/**
	 * Cancelled, refunded or failed: the notice will never go, the contact is erased later.
	 *
	 * @param int   $order_id Order id.
	 * @param mixed $order    Order.
	 */
	public static function on_closed( $order_id, $order = null ): void {
		$order = $order instanceof \WC_Order ? $order : wc_get_order( (int) $order_id );
		if ( $order instanceof \WC_Order ) {
			self::schedule_erase( $order, null );
		}
	}

	/**
	 * Action Scheduler job of the erasure.
	 *
	 * @param int|array<string, int> $order_id Order id, or the job's args.
	 */
	public static function erase_job( $order_id ): void {
		self::erase( is_array( $order_id ) ? (int) ( $order_id['order_id'] ?? 0 ) : (int) $order_id );
	}

	/**
	 * Erases the recipient's contact of an order.
	 *
	 * @param int  $order_id Order id.
	 * @param bool $name     Also the recipient's name (erasure asked by the recipient).
	 */
	public static function erase( int $order_id, bool $name = false ): bool {
		$order = wc_get_order( $order_id );
		if ( ! $order instanceof \WC_Order || '' === (string) $order->get_meta( Gift::META_CONTACT ) ) {
			return false;
		}
		$order->update_meta_data( Gift::META_CONTACT, '' );
		if ( $name ) {
			$order->update_meta_data( Gift::META_TO, '' );
		}
		$order->update_meta_data( Gift::META_ERASED, (string) time() );
		$order->save();
		$order->add_order_note( __( 'Regalo: borrado el contacto de quien lo recibe (ya no hace falta para el aviso).', 'lachinata-core' ) );
		return true;
	}

	/**
	 * Paragraph of the privacy policy guide.
	 */
	public static function policy(): void {
		if ( function_exists( 'wp_add_privacy_policy_content' ) ) {
			wp_add_privacy_policy_content( __( 'La Chinata: regalos', 'lachinata-core' ), wp_kses_post( wpautop( self::text() ) ) );
		}
	}

	/**
	 * Eraser of WordPress's personal data tools.
	 *
	 * @param array<string, array<string, mixed>> $erasers Erasers.
	 * @return array<string, array<string, mixed>>
	 */
	public static function register_eraser( $erasers ): array {
		$erasers                   = is_array( $erasers ) ? $erasers : array();
		$erasers['lachinata-gift'] = array(
			'eraser_friendly_name' => __( 'Contacto de quien recibe un regalo', 'lachinata-core' ),
			'callback'             => array( self::class, 'erase_for_email' ),
		);
		return $erasers;
	}

	/**
	 * Erases the gift contacts of the orders of an email: the buyer's orders, and the orders
	 * where it is the recipient's contact (then also the recipient's name).
	 *
	 * @param string $email Email.
	 * @param int    $page  Page.
	 * @return array{items_removed: bool, items_retained: bool, messages: string[], done: bool}
	 */
	public static function erase_for_email( $email, $page = 1 ): array {
		$email   = sanitize_email( (string) $email );
		$removed = false;
		$limit   = 20;
		$more    = false;
		if ( '' !== $email ) {
			$as_buyer = wc_get_orders(
				array(
					'billing_email' => $email,
					'limit'         => $limit,
					'page'          => max( 1, (int) $page ),
					'type'          => 'shop_order',
				)
			);
			// Erased contacts stop matching: always the first page.
			$as_recipient = array_filter( array_map( 'wc_get_order', Gift::orders_with( Gift::META_CONTACT, $email, $limit ) ) );
			$as_buyer     = is_array( $as_buyer ) ? $as_buyer : array();
			$more         = count( $as_buyer ) >= $limit || count( $as_recipient ) >= $limit;
			foreach ( $as_buyer as $order ) {
				$removed = ( $order instanceof \WC_Order && self::erase( $order->get_id() ) ) || $removed;
			}
			foreach ( $as_recipient as $order ) {
				$removed = ( $order instanceof \WC_Order && self::erase( $order->get_id(), true ) ) || $removed;
			}
		}
		return array(
			'items_removed'  => $removed,
			'items_retained' => false,
			'messages'       => array(),
			'done'           => ! $more,
		);
	}
}
