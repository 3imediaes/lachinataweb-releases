# Módulo `gift`

«¿Es un regalo?» en el checkout: nombre de quien lo recibe, mensaje escrito a mano en una tarjeta y **aviso al destinatario** por correo o SMS cuando sale el paquete, para que nadie rechace un paquete que no ha pedido. Sin contenido ni precio.

Especificación: `design-system/sistema/04-envios-entrega.md` («Regalos»), componente `GiftOption`, tableros Regalo, Checkout y CheckoutDesktop. Decisiones del 24/10/2026 en `design-system/docs/decisiones.md` («Regalo y Odoo»): no hay albarán ni «sin precios» (ningún paquete lleva precios), «De parte de» vacío para invitados, un solo aviso por pedido, SMS por OVH.

Necesita el módulo `checkout` (pinta el hueco de la tarjeta). Ajustes: WooCommerce → La Chinata → Regalo. Paso a producción: `docs/despliegue-gift-odoo.md`.

## Qué hace

| Pieza | Cómo | Dónde |
| --- | --- | --- |
| Tarjeta «¿Es un regalo?» entre Envío y Facturación: `CheckoutSection` plegada (`lc-chk lc-chk--quiet`, borde discontinuo) con `GiftOption` dentro, el marcado `.lc-gift*` del bundle. Al marcar «Es un regalo» se abre y deja de ser `--quiet`. Sin una bolsa que se envíe, no se pinta | *Fill* del *slot* `lachinata/checkout/gift` del módulo `checkout` (`registerPlugin`, ámbito `woocommerce-checkout`). El `Fill` de WooCommerce clona su hijo con los props del hueco (`cart`, `extensions`) y lo envuelve en un `div`; el tema lo hace transparente (`display: contents`) | `src/index.js`, `Integration.php`; `theme/assets/css/checkout.css` |
| **Para** (precargado con el nombre de la dirección de entrega y lo sigue mientras no se toque), **Tu mensaje** (200 caracteres), **Avisar a quien lo recibe**: Por correo · Por SMS · No avisar (chips con `aria-pressed`), correo o móvil, **De parte de** (vacío con su placeholder; con sesión, el nombre de la cuenta) y «Solo usaremos este dato para el aviso del regalo.» | Datos de extensión de la Store API (`setExtensionData( 'lachinata-gift', … )`); errores en el store de validación de WooCommerce (`wc/store/validation`): bloquean «Pagar» y salen bajo cada campo | `src/index.js` |
| Validación en el servidor: Para obligatorio; correo válido; móvil en formato internacional (en España, solo móviles 6/7); De parte de obligatorio si se avisa; mensaje ≤ 200. «No avisar» + De parte de vacío = regalo anónimo | `woocommerce_store_api_checkout_update_order_from_request`; un campo mal para el pedido con `RouteException` y la misma frase de la tarjeta | `Checkout.php`, `Gift::validate()`, `Sms/Phone.php` |
| Sugerencia (`Notice` info, «¿Es un regalo? Podemos avisar a María…») mientras la casilla está sin marcar: con sesión, si la entrega no es la dirección guardada del cliente; sin sesión, si la facturación es «Usar otra dirección» distinta de la entrega | Direcciones del store de la bolsa y `getUseShippingAsBilling()` | `src/index.js` |
| Metadatos del pedido: `_lc_regalo` (`yes`), `_lc_regalo_para`, `_lc_regalo_mensaje`, `_lc_regalo_aviso` (`email`/`sms`/`none`), `_lc_regalo_contacto`, `_lc_regalo_de`; internos `_lc_regalo_avisado` (cuándo, vía, resultado, si llevaba enlace), `_lc_regalo_contacto_borrado` y `_lc_regalo_enlace` (enlace corto) | `Gift::store()` | `Gift.php` |
| Pedidos de la web actual: el campo ACF `nota_cliente` (grupo Pedido; no hay casilla de regalo) se lee como regalo sin aviso, con esa nota como mensaje (`legacy: true` en la API) | `Gift::of()` | `Gift.php` |
| API para Odoo: `lachinata.gift` (información del pedido; no pide ninguna acción) | Filtro `lachinata/rest/order` | `Gift::rest_data()`; contrato en `docs/api-odoo.md` |
| Marca «Regalo» en la lista de pedidos (HPOS y entradas) y, en el pedido, bajo la dirección de envío: Para, mensaje para la tarjeta y estado del aviso | `manage_woocommerce_page_wc-orders_*`, `manage_edit-shop_order_columns`, `woocommerce_admin_order_data_after_shipping_address` | `Orders.php` |
| Correos: a la tienda, bloque REGALO (Para, mensaje, aviso); al comprador, en la confirmación «Avisaremos a María por SMS cuando salga el paquete.» y en el de completado «Hemos avisado a María por SMS de que su regalo está en camino.» (solo si el aviso salió) | `woocommerce_email_order_details`, prioridad 5 | `Orders.php` |
| Gracias: «Es un regalo para María», «Con tu mensaje escrito a mano en una tarjeta.» y «Le avisaremos por correo cuando salga el paquete.», bajo la fecha de entrega (tablero Regalo, 7) | Hueco del tema `lachinata/thankyou/gift` (`theme/HOOKS.md`), clases `lc-thanks__when lc-thanks__gift` | `Orders::thankyou()`; tinta `tint-regalos` en `theme/assets/css/theme.css` |
| **Aviso al destinatario** al pasar el pedido a uno de los estados del ajuste (por defecto «Completado», el que pone Odoo). Uno por pedido; si falla, nota en el pedido, Huecos de configuración y registro `lachinata-gift`, y el pedido sigue | `woocommerce_order_status_<estado>`, prioridad 5 (antes de los correos de WooCommerce del mismo estado) | `Notifier.php` |
| Correo «{De parte de} te envía un regalo de {tienda}» (tablero Regalo, 5): saludo, quién, con quién, cuándo y dónde, «No tienes que pagar nada…», «Seguir el paquete» solo con seguimiento y por qué recibe el correo. Sale por la salida y el remitente de los correos de WooCommerce y se puede apagar o retitular en WooCommerce → Ajustes → Correos («Aviso de regalo») | `WC_Email` propio; plantillas reemplazables en el tema (`woocommerce/emails/lachinata-gift-recipient.php`) | `RecipientEmail.php`, `templates/emails/` |
| SMS con el mismo texto corto (tablero Regalo, 6), como mucho dos segmentos UCS-2 (≤ 134 caracteres) | `Message::sms()`: si no cabe, quita el transportista, luego «No tienes que pagar nada.», luego el saludo y por último acorta «De parte de»; nunca la fecha ni el enlace | `Message.php` |
| Fecha del aviso: el plazo del método desde el día real de salida (la fecha de salida del seguimiento o hoy), con los festivos y días sin reparto del motor; sin plan, la guardada en el pedido. Sin el módulo `eta`, sin fecha | `Eta\Rates::shipped()`, `Eta\Calculator::from_dispatch()` | `Notifier::estimate()` |
| Transportista del texto: el del mapa del módulo `odoo` | Filtro del núcleo `lachinata/order/carrier` (`OrderData::carrier()`) | — |
| Seguimiento: el de WooCommerce Shipment Tracking (lo escribe Odoo por su API REST), detrás de `Tracking\TrackingSource` | `_wc_shipment_tracking_items`, último elemento; el enlace que forma la extensión o, sin ella, la plantilla del proveedor propio rellenada igual (`%1$s` número, `%2$s` CP, `%3$s` país, `%4$s` pedido). Otras fuentes: `lachinata/gift/tracking_sources` | `Tracking/` |
| Enlace corto del SMS `lachinata.es/s/7Kq2xm`: redirige al seguimiento del transportista, nunca al pedido | Ficha aleatoria en el pedido; se lee en `parse_request`, sin reglas de reescritura | `ShortLink.php` |
| SMS por **OVH** (`POST /sms/{serviceName}/jobs`, petición firmada con la hora de OVH, `coding` `8bit` = UCS-2 con acentos, `noStopClause`). Sin las cinco credenciales, proveedor «registro»: el SMS va al registro `lachinata-gift` con el número enmascarado. «Enviar un SMS de prueba» en el panel. Otros proveedores: interfaz `Sms\SmsProvider` y filtro `lachinata/gift/sms_provider` | `wp_remote_request` | `Sms/` |
| Datos personales: el contacto del destinatario solo en el pedido (no crea cuenta, no va a ninguna lista). Se borra N días (ajuste, 30) después de la última fecha de entrega, o del cierre si el pedido se cancela, se reembolsa o falla. Texto para la guía de privacidad de WordPress (borrador provisional, `{dias}` se sustituye) y borrador de datos personales: por el correo del comprador borra los contactos de sus regalos; por el del destinatario, también su nombre | Action Scheduler (`lachinata/gift/erase_contact`), `wp_add_privacy_policy_content`, `wp_privacy_personal_data_erasers` | `Privacy.php` |

Casos límite: un regalo por pedido; entrega al propio comprador sin detección automática (lo cubre «No avisar»); un pedido que pasa de nuevo a «Completado» no repite el aviso.

## Ajustes

| Ajuste | Por defecto | En el JSON |
| --- | --- | --- |
| Estados que envían el aviso (`notify_statuses`) | `completed` | sí |
| Días hasta borrar el contacto (`erase_days`) | 30 | sí |
| Texto de privacidad (`privacy_text`) | vacío = borrador provisional (`Privacy::DRAFT`) | sí |
| Enlace «¿Qué es La Chinata?» del correo (`about_url`) | vacío = portada | no |
| API de OVH (`ovh_endpoint`) | `ovh-eu` | sí |
| Application key, application secret, consumer key, servicio SMS y remitente (`ovh_*`) | vacíos | **no** (solo en el panel de cada sitio) |

El secreto y la consumer key no se vuelven a mostrar; un campo vacío al guardar los conserva.

## Seguimiento que llega después del cambio de estado

WooCommerce Shipment Tracking 2.6.3 no dispara ninguna acción propia al añadir un seguimiento: su API REST llama a `add_tracking_item()`, que pasa el filtro `wc_shipment_tracking_before_add_tracking_items` y guarda el pedido (`woocommerce_update_order`). Según lo decidido, el aviso sale al cambiar de estado con lo que haya en ese momento: si Odoo escribe el seguimiento después de marcar «Completado», el aviso lleva solo la fecha. Para que lleve el enlace, Odoo debe escribir el seguimiento **antes** de cambiar el estado (`docs/despliegue-gift-odoo.md`). Si hiciera falta esperar al seguimiento, el punto de enganche sería `woocommerce_update_order`.

## Tests

- PHP: `tests/GiftTest.php` (validación, metadatos con sus nombres, API, `nota_cliente`, móviles, SMS en dos segmentos con la cascada, textos del correo, plantilla del enlace de seguimiento), `tests/NotifierTest.php` (aviso una sola vez al completar, correo con seguimiento y transportista, enlace corto, fallo que no bloquea, nada que enviar, correos a la tienda y al comprador, borrado diferido, borrador de datos personales), `tests/OvhProviderTest.php` (firma, cabeceras y cuerpo con el cliente HTTP simulado, UCS-2, errores, «registro» sin credenciales y credenciales fuera de la exportación); en `eta`, `CalculatorTest::test_from_dispatch_counts_only_transit`; en el núcleo, `OrderDataTest::test_object_with_gift_and_carrier`.
- e2e: `tests/e2e/gift.spec.mjs` (activar, validar, pagar y gracias; regalo anónimo; sugerencia) y la tarjeta en `tests/e2e/checkout-cards.spec.mjs` (orden, separación y radios a 390 y 1440).
