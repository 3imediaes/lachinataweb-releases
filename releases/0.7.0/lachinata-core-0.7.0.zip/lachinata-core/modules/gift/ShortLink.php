<?php
/**
 * Short link of the SMS: /s/<token>.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Gift;

defined( 'ABSPATH' ) || exit;

/**
 * The SMS has no room for a carrier's tracking URL, so it carries `lachinata.es/s/7Kq2xm`:
 * a random token kept on the order that redirects to the latest tracking link. It leads
 * only to the carrier, never to the order (the recipient must not see prices nor the buyer's
 * data). No rewrite rule: the path is read on `parse_request`, so nothing needs flushing.
 */
final class ShortLink {

	/**
	 * Order meta with the token.
	 */
	public const META = '_lc_regalo_enlace';

	/**
	 * Token length and alphabet (no look-alike characters).
	 */
	private const LENGTH   = 6;
	private const ALPHABET = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_action( 'parse_request', array( self::class, 'resolve' ), 1 );
	}

	/**
	 * Short link of an order (created the first time), without scheme: «lachinata.es/s/7Kq2xm».
	 *
	 * @param \WC_Order $order Order.
	 */
	public static function for_order( \WC_Order $order ): string {
		$token = (string) $order->get_meta( self::META );
		if ( ! preg_match( '/^[a-zA-Z0-9]{' . self::LENGTH . '}$/', $token ) ) {
			$token = '';
			for ( $i = 0; $i < self::LENGTH; $i++ ) {
				$token .= self::ALPHABET[ random_int( 0, strlen( self::ALPHABET ) - 1 ) ];
			}
			$order->update_meta_data( self::META, $token );
			$order->save_meta_data();
		}
		return (string) preg_replace( '#^https?://#', '', home_url( '/s/' . $token ) );
	}

	/**
	 * Order of a token, or null.
	 *
	 * @param string $token Token.
	 */
	public static function order( string $token ): ?\WC_Order {
		$ids   = Gift::orders_with( self::META, $token, 1 );
		$order = $ids ? wc_get_order( $ids[0] ) : false;
		return $order instanceof \WC_Order && hash_equals( (string) $order->get_meta( self::META ), $token ) ? $order : null;
	}

	/**
	 * Target of a path, or null when it is not a short link or leads nowhere.
	 *
	 * @param string $path Request path, relative to the site.
	 */
	public static function target( string $path ): ?string {
		if ( ! preg_match( '#^s/([a-zA-Z0-9]{' . self::LENGTH . '})$#', trim( $path, '/' ), $match ) ) {
			return null;
		}
		$order = self::order( $match[1] );
		if ( null === $order ) {
			return null;
		}
		$tracking = Notifier::tracking( $order );
		return null !== $tracking && '' !== $tracking['url'] ? $tracking['url'] : null;
	}

	/**
	 * Redirects a short link to the carrier.
	 *
	 * @param \WP $wp Request.
	 */
	public static function resolve( $wp ): void {
		if ( ! $wp instanceof \WP ) {
			return;
		}
		$target = self::target( (string) $wp->request );
		if ( null === $target ) {
			return;
		}
		// The carrier is another site: wp_safe_redirect() would refuse it.
		wp_redirect( $target, 302, 'La Chinata' ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- External carrier tracking page, stored by the shop.
		exit;
	}
}
