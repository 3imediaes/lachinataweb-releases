<?php
/**
 * «Registro»: the SMS is written to the log instead of being sent.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Gift\Sms;

defined( 'ABSPATH' ) || exit;

/**
 * The provider while there are no OVH credentials (local, staging, a site without SMS):
 * the message goes to WooCommerce → Estado → Registros (`lachinata-gift`) with the number
 * masked, and the notice counts as sent.
 */
final class LogProvider implements SmsProvider {

	/**
	 * Messages «sent» in this request (tests).
	 *
	 * @var array<int, array{to: string, message: string}>
	 */
	public static array $sent = array();

	/**
	 * Identifier.
	 */
	public function id(): string {
		return 'log';
	}

	/**
	 * Name.
	 */
	public function label(): string {
		return __( 'Registro (no se envía)', 'lachinata-core' );
	}

	/**
	 * Writes the message to the log.
	 *
	 * @param string $to      Mobile.
	 * @param string $message Text.
	 */
	public function send( string $to, string $message ): string {
		self::$sent[] = array(
			'to'      => $to,
			'message' => $message,
		);
		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->info(
				sprintf( 'SMS de regalo (registro) a %1$s: %2$s', self::mask( $to ), $message ),
				array( 'source' => 'lachinata-gift' )
			);
		}
		return 'log-' . count( self::$sent );
	}

	/**
	 * +34600000000 → +34600•••000.
	 *
	 * @param string $number Mobile.
	 */
	public static function mask( string $number ): string {
		return strlen( $number ) > 6 ? substr( $number, 0, -6 ) . '•••' . substr( $number, -3 ) : '•••';
	}
}
