<?php
/**
 * SMS through OVH.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Gift\Sms;

use LaChinata\Core\Modules\Gift\Message;

defined( 'ABSPATH' ) || exit;

/**
 * OVH's SMS API (`POST /sms/{serviceName}/jobs`). Every request is signed with the
 * application secret and the consumer key: `$1$` + SHA-1 of
 * `secret+consumer+METHOD+URL+BODY+TIMESTAMP`, with OVH's own time (`GET /auth/time`) so a
 * server clock out of step does not invalidate the signature. A message with characters
 * outside the GSM alphabet (accents like «í») goes as UCS-2 (`coding: 8bit` in OVH).
 *
 * The credentials are entered in WooCommerce → La Chinata → Regalo; never in the
 * repository nor in the exported JSON.
 */
final class OvhProvider implements SmsProvider {

	/**
	 * API endpoints.
	 */
	public const ENDPOINTS = array(
		'ovh-eu' => 'https://eu.api.ovh.com/1.0',
		'ovh-ca' => 'https://ca.api.ovh.com/1.0',
	);

	/**
	 * Builds the provider.
	 *
	 * @param string $app_key      Application key.
	 * @param string $app_secret   Application secret.
	 * @param string $consumer_key Consumer key.
	 * @param string $service      SMS account (`sms-ab12345-1`).
	 * @param string $sender       Sender registered in the account («LaChinata»).
	 * @param string $endpoint     Key of ENDPOINTS.
	 */
	public function __construct(
		private string $app_key,
		private string $app_secret,
		private string $consumer_key,
		private string $service,
		private string $sender,
		private string $endpoint = 'ovh-eu',
	) {}

	/**
	 * Identifier.
	 */
	public function id(): string {
		return 'ovh';
	}

	/**
	 * Name.
	 */
	public function label(): string {
		return 'OVH';
	}

	/**
	 * Whether every credential is there.
	 */
	public function configured(): bool {
		return '' !== $this->app_key && '' !== $this->app_secret && '' !== $this->consumer_key && '' !== $this->service && '' !== $this->sender;
	}

	/**
	 * Sends the message.
	 *
	 * @param string $to      Mobile.
	 * @param string $message Text.
	 * @return string OVH job id.
	 * @throws SmsException When OVH refuses it or cannot be reached.
	 */
	public function send( string $to, string $message ): string {
		if ( ! $this->configured() ) {
			throw new SmsException( 'Faltan credenciales de OVH.' );
		}
		$body     = (string) wp_json_encode(
			array(
				'message'           => $message,
				'receivers'         => array( $to ),
				'sender'            => $this->sender,
				'charset'           => 'UTF-8',
				'coding'            => Message::is_gsm( $message ) ? '7bit' : '8bit',
				'noStopClause'      => true,
				'priority'          => 'high',
				'senderForResponse' => false,
			)
		);
		$response = $this->request( 'POST', '/sms/' . rawurlencode( $this->service ) . '/jobs', $body );
		$ids      = $response['ids'] ?? array();
		if ( ! is_array( $ids ) || ! $ids ) {
			$invalid = isset( $response['invalidReceivers'] ) && is_array( $response['invalidReceivers'] ) ? implode( ', ', $response['invalidReceivers'] ) : '';
			throw new SmsException( esc_html( '' !== $invalid ? 'OVH rechaza el número ' . $invalid . '.' : 'OVH no devolvió ningún envío.' ) );
		}
		return (string) $ids[0];
	}

	/**
	 * Signature of a request.
	 *
	 * @param string $method    HTTP method.
	 * @param string $url       Full URL.
	 * @param string $body      Body.
	 * @param int    $timestamp OVH time.
	 */
	public function signature( string $method, string $url, string $body, int $timestamp ): string {
		return '$1$' . sha1( implode( '+', array( $this->app_secret, $this->consumer_key, $method, $url, $body, (string) $timestamp ) ) );
	}

	/**
	 * A signed request.
	 *
	 * @param string $method HTTP method.
	 * @param string $path   Path after the endpoint.
	 * @param string $body   JSON body.
	 * @return array<string, mixed>
	 * @throws SmsException When the request fails.
	 */
	private function request( string $method, string $path, string $body ): array {
		$url       = ( self::ENDPOINTS[ $this->endpoint ] ?? self::ENDPOINTS['ovh-eu'] ) . $path;
		$timestamp = $this->time();
		$response  = wp_remote_request(
			$url,
			array(
				'method'  => $method,
				'timeout' => 10,
				'headers' => array(
					'Content-Type'      => 'application/json; charset=utf-8',
					'X-Ovh-Application' => $this->app_key,
					'X-Ovh-Consumer'    => $this->consumer_key,
					'X-Ovh-Timestamp'   => (string) $timestamp,
					'X-Ovh-Signature'   => $this->signature( $method, $url, $body, $timestamp ),
				),
				'body'    => $body,
			)
		);
		if ( is_wp_error( $response ) ) {
			throw new SmsException( esc_html( 'No se pudo conectar con OVH: ' . $response->get_error_message() ) );
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		$data = is_array( $data ) ? $data : array();
		if ( $code < 200 || $code >= 300 ) {
			throw new SmsException( esc_html( sprintf( 'OVH respondió %1$d: %2$s', $code, (string) ( $data['message'] ?? '' ) ) ) );
		}
		return $data;
	}

	/**
	 * OVH's time, or the server's when it does not answer.
	 */
	private function time(): int {
		$response = wp_remote_get( ( self::ENDPOINTS[ $this->endpoint ] ?? self::ENDPOINTS['ovh-eu'] ) . '/auth/time', array( 'timeout' => 5 ) );
		$time     = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_body( $response );
		return $time > 0 ? $time : time();
	}
}
