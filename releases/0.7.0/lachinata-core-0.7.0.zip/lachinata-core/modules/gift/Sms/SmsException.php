<?php
/**
 * SMS that could not be sent.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Gift\Sms;

defined( 'ABSPATH' ) || exit;

/**
 * Thrown by a provider; the notice records it and the order goes on.
 */
final class SmsException extends \RuntimeException {}
