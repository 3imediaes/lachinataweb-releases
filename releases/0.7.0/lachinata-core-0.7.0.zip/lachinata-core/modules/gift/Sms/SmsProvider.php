<?php
/**
 * SMS provider of the gift notice.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Gift\Sms;

defined( 'ABSPATH' ) || exit;

/**
 * Sends one SMS. Register another provider with `lachinata/gift/sms_provider`.
 */
interface SmsProvider {

	/**
	 * Identifier (`log`, `ovh`…).
	 */
	public function id(): string;

	/**
	 * Name for the admin screen.
	 */
	public function label(): string;

	/**
	 * Sends a message.
	 *
	 * @param string $to      Mobile in international format (+34600000000).
	 * @param string $message Text (at most two segments: Message::SMS_MAX).
	 * @return string Provider reference of the message.
	 * @throws SmsException When it could not be sent.
	 */
	public function send( string $to, string $message ): string;
}
