<?php
/**
 * Tracking written by WooCommerce Shipment Tracking.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Gift\Tracking;

defined( 'ABSPATH' ) || exit;

/**
 * Odoo writes the tracking with the official WooCommerce Shipment Tracking extension
 * (its REST API), stored in the order meta `_wc_shipment_tracking_items`: a list of items
 * with `tracking_provider` (a provider the extension knows) or `custom_tracking_provider`
 * and `custom_tracking_link`, `tracking_number` and `date_shipped` (timestamp). The last
 * item is the one that counts. The link is the one the extension builds when it is active
 * (known providers and custom templates); without it, a custom template is filled the
 * same way.
 *
 * The extension (2.6.3) fires no action of its own when a tracking is added: its REST API
 * calls `add_tracking_item()`, which passes the filter
 * `wc_shipment_tracking_before_add_tracking_items` and saves the order
 * (`woocommerce_update_order`). The notice does not wait for it: it goes when the order
 * changes status, with the tracking that is there at that moment.
 */
final class ShipmentTracking implements TrackingSource {

	/**
	 * Order meta of the extension.
	 */
	public const META = '_wc_shipment_tracking_items';

	/**
	 * The latest tracking of the order.
	 *
	 * @param \WC_Order $order Order.
	 * @return array{carrier: string, number: string, url: string, shipped: int|null}|null
	 */
	public function find( \WC_Order $order ): ?array {
		$items = $order->get_meta( self::META );
		if ( ! is_array( $items ) || ! $items ) {
			return null;
		}
		$item = end( $items );
		if ( ! is_array( $item ) ) {
			return null;
		}
		$url     = '';
		$actions = is_callable( array( 'WC_Shipment_Tracking_Actions', 'get_instance' ) ) ? call_user_func( array( 'WC_Shipment_Tracking_Actions', 'get_instance' ) ) : null;
		if ( is_object( $actions ) && is_callable( array( $actions, 'get_formatted_tracking_item' ) ) ) {
			$formatted = call_user_func( array( $actions, 'get_formatted_tracking_item' ), $order->get_id(), $item );
			$url       = is_array( $formatted ) ? esc_url_raw( (string) ( $formatted['formatted_tracking_link'] ?? '' ) ) : '';
		}
		if ( '' === $url ) {
			$url = esc_url_raw( self::link( (string) ( $item['custom_tracking_link'] ?? '' ), $item, $order ) );
		}
		$carrier = (string) ( $item['custom_tracking_provider'] ?? '' );
		$carrier = '' !== $carrier ? $carrier : (string) ( $item['tracking_provider'] ?? '' );
		$shipped = (int) ( $item['date_shipped'] ?? 0 );
		return array(
			'carrier' => $carrier,
			'number'  => (string) ( $item['tracking_number'] ?? '' ),
			'url'     => $url,
			'shipped' => $shipped > 0 ? $shipped : null,
		);
	}

	/**
	 * A custom provider's link is a sprintf() template, as the extension fills it
	 * (`get_formatted_tracking_link()`, 2.6.3): tracking number, postcode, country, order id.
	 *
	 * @param string               $format Link or template.
	 * @param array<string, mixed> $item   Tracking item.
	 * @param \WC_Order            $order  Order.
	 */
	public static function link( string $format, array $item, \WC_Order $order ): string {
		if ( '' === $format || ! str_contains( $format, '%' ) ) {
			return $format;
		}
		$postcode = $order->get_shipping_postcode() ? $order->get_shipping_postcode() : $order->get_billing_postcode();
		try {
			return sprintf( $format, (string) ( $item['tracking_number'] ?? '' ), rawurlencode( wc_normalize_postcode( $postcode ) ), $order->get_shipping_country(), $order->get_id() );
		} catch ( \ValueError | \ArgumentCountError $error ) {
			return '';
		}
	}
}
