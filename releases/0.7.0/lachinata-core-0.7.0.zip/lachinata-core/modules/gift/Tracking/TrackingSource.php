<?php
/**
 * Where the tracking of an order comes from.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Gift\Tracking;

defined( 'ABSPATH' ) || exit;

/**
 * Tracking of a shipped order. Register another source with `lachinata/gift/tracking_sources`
 * (the `tracking` module, when it exists).
 */
interface TrackingSource {

	/**
	 * The latest tracking of an order, or null.
	 *
	 * @param \WC_Order $order Order.
	 * @return array{carrier: string, number: string, url: string, shipped: int|null}|null
	 */
	public function find( \WC_Order $order ): ?array;
}
