/**
 * Module `gift`: the card «¿Es un regalo?» of the checkout, between Envío and Facturación.
 * It fills the slot `lachinata/checkout/gift` of the checkout module with the whole card:
 * CheckoutSection folded (`lc-chk lc-chk--quiet`) with GiftOption inside, the markup and
 * classes of design-system/sistema/components/bundle.js. Ticking the box opens the panel and
 * the card stops being quiet.
 *
 * What the buyer writes travels as extension data of the Store API (`lachinata-gift`) and
 * is checked again on the server (Checkout.php). Missing or wrong fields are validation
 * errors of WooCommerce's validation store: they block «Pagar» and show under each field.
 */
import { useSelect, dispatch, select } from '@wordpress/data';
import { useEffect, useRef } from '@wordpress/element';
import { registerPlugin } from '@wordpress/plugins';
import { __, sprintf } from '@wordpress/i18n';
import { Icon, Notice } from '../../checkout/src/components';

const { createSlotFill } = window.wc.blocksCheckout;
const { Fill } = createSlotFill('lachinata/checkout/gift');

const CHECKOUT_STORE = 'wc/store/checkout';
const VALIDATION_STORE = 'wc/store/validation';
const NAMESPACE = 'lachinata-gift';

const settings =
	window.wc?.wcSettings?.getSetting('lachinata-gift_data', {}) || {};
const MESSAGE_MAX = settings.messageMax || 200;
const NAME_MAX = settings.nameMax || 60;

const cx = (...names) => names.filter(Boolean).join(' ');

const same = (a, b) =>
	String(a || '')
		.trim()
		.toLowerCase() ===
	String(b || '')
		.trim()
		.toLowerCase();

const sameAddress = (a, b) =>
	!!a &&
	!!b &&
	same(a.address_1, b.address_1) &&
	same(a.postcode, b.postcode) &&
	same(a.country, b.country);

const fullName = (address) =>
	[address?.first_name, address?.last_name]
		.map((part) => String(part || '').trim())
		.filter(Boolean)
		.join(' ');

/**
 * Field errors as the buyer would read them.
 *
 * @param {Object} gift Gift data.
 * @return {Object} Message by field.
 */
function check(gift) {
	const errors = {};
	if (!gift.to.trim()) {
		errors.to = __(
			'Escribe el nombre de quien recibe el regalo.',
			'lachinata-core'
		);
	}
	if (gift.via === 'email' && !/^\S+@\S+\.\S+$/.test(gift.contact.trim())) {
		errors.contact = __(
			'Escribe el correo de quien recibe el regalo, como nombre@correo.es.',
			'lachinata-core'
		);
	}
	if (
		gift.via === 'sms' &&
		gift.contact.replace(/[\s.\-()\/+]/g, '').length < 9
	) {
		errors.contact = __(
			'Escribe el móvil de quien recibe el regalo, con el prefijo si no es de España.',
			'lachinata-core'
		);
	}
	if (gift.via !== 'none' && !gift.from.trim()) {
		errors.from = __(
			'Escribe tu nombre tal y como lo verá: le diremos de parte de quién es.',
			'lachinata-core'
		);
	}
	return errors;
}

const errorId = (field) => `lachinata-gift-${field}`;
const FIELDS = ['to', 'contact', 'from'];

/**
 * Field of the system (Field in bundle.js) bound to the validation store.
 *
 * @param {Object}                  props
 * @param {string}                  props.field        Key of the gift data.
 * @param {string}                  props.label        Label.
 * @param {string}                  props.value        Value.
 * @param {(value: string) => void} props.onChange     New value.
 * @param {string}                  props.type         Input type or `textarea`.
 * @param {string}                  props.placeholder  Placeholder.
 * @param {string}                  props.inputMode    Input mode.
 * @param {number}                  props.maxLength    Maximum length.
 * @param {string}                  props.help         Help under the field.
 * @param {string}                  props.autoComplete Autocomplete.
 */
function Field({
	field,
	label,
	value,
	onChange,
	type = 'text',
	placeholder,
	inputMode,
	maxLength,
	help,
	autoComplete = 'off',
}) {
	const id = `lc-gift-${field}`;
	const error = useSelect(
		(s) => {
			const found = s(VALIDATION_STORE).getValidationError(
				errorId(field)
			);
			return found && !found.hidden ? found.message : '';
		},
		[field]
	);
	const note = error || help;
	const common = {
		id,
		value,
		placeholder,
		maxLength,
		autoComplete,
		'aria-invalid': error ? 'true' : undefined,
		'aria-describedby': note ? `${id}-help` : undefined,
		onChange: (event) => onChange(event.target.value),
		onBlur: () =>
			dispatch(VALIDATION_STORE).showValidationError(errorId(field)),
	};
	return (
		<div className={cx('lc-field', error && 'lc-field--error')}>
			<label htmlFor={id} className="label">
				{label}
			</label>
			<div className="lc-field__box">
				{type === 'textarea' ? (
					<textarea {...common} rows={3} />
				) : (
					<input {...common} type={type} inputMode={inputMode} />
				)}
			</div>
			{note && (
				<span id={`${id}-help`} className="lc-field__help body-sm">
					{note}
				</span>
			)}
		</div>
	);
}

function GiftCard({ cart }) {
	const { gift, useShippingAsBilling } = useSelect((s) => {
		const store = s(CHECKOUT_STORE);
		return {
			gift: store.getExtensionData()?.[NAMESPACE] || {},
			useShippingAsBilling: store.getUseShippingAsBilling(),
		};
	}, []);
	const shipping = cart?.shippingAddress || {};
	const billing = cart?.billingAddress || {};
	const toTouched = useRef(false);

	const data = {
		open: !!gift.open,
		to: gift.to ?? fullName(shipping),
		message: gift.message ?? '',
		via: gift.via ?? 'email',
		contact: gift.contact ?? '',
		from: gift.from ?? settings.accountName ?? '',
	};

	const set = (changes) =>
		dispatch(CHECKOUT_STORE).setExtensionData(
			NAMESPACE,
			{ ...data, ...changes },
			true
		);

	// «Para» follows the delivery name until the buyer changes it.
	const deliveryName = fullName(shipping);
	useEffect(() => {
		if (!toTouched.current && deliveryName && deliveryName !== data.to) {
			set({ to: deliveryName });
		}
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [deliveryName]);

	// Errors live in WooCommerce's validation store: they block «Pagar».
	const errors = data.open ? check(data) : {};
	const errorKey = JSON.stringify(errors);
	useEffect(() => {
		const validation = dispatch(VALIDATION_STORE);
		const current = select(VALIDATION_STORE);
		FIELDS.forEach((field) => {
			const id = errorId(field);
			if (errors[field]) {
				const previous = current.getValidationError(id);
				validation.setValidationErrors({
					[id]: {
						message: errors[field],
						hidden: previous ? previous.hidden : true,
					},
				});
			} else {
				validation.clearValidationError(id);
			}
		});
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, [errorKey]);
	useEffect(
		() => () =>
			dispatch(VALIDATION_STORE).clearValidationErrors(
				FIELDS.map(errorId)
			),
		[]
	);

	if (cart && cart.needsShipping === false) {
		return null;
	}

	// «¿Es un regalo?» when the parcel goes somewhere else than the buyer's own address.
	const elsewhere = settings.loggedIn
		? !!settings.savedAddress?.address_1 &&
			!!shipping.address_1 &&
			!sameAddress(shipping, settings.savedAddress)
		: !useShippingAsBilling &&
			!!billing.address_1 &&
			!!shipping.address_1 &&
			!sameAddress(shipping, billing);
	const firstName = String(shipping.first_name || '').trim();

	const vias = [
		{ id: 'email', label: __('Por correo', 'lachinata-core') },
		{ id: 'sms', label: __('Por SMS', 'lachinata-core') },
		{ id: 'none', label: __('No avisar', 'lachinata-core') },
	];

	return (
		<section
			className={cx('lc-chk', !data.open && 'lc-chk--quiet')}
			aria-labelledby="lc-gift-title"
		>
			<header className="lc-chk__head">
				<span className="lc-chk__icon" aria-hidden="true">
					<Icon name="gift" size="sm" />
				</span>
				<h2 className="h4 lc-chk__title" id="lc-gift-title">
					{__('¿Es un regalo?', 'lachinata-core')}
				</h2>
			</header>
			<p className="lc-chk__text body-sm">
				{__(
					'Con tu mensaje escrito a mano y aviso a quien lo recibe.',
					'lachinata-core'
				)}
			</p>
			<div className="lc-chk__body">
				{!data.open && elsewhere && (
					<Notice tone="info">
						{firstName
							? sprintf(
									/* translators: %s: first name of the delivery address. */
									__(
										'¿Es un regalo? Podemos avisar a %s de que le llega un paquete tuyo, sin desvelar qué es ni cuánto cuesta.',
										'lachinata-core'
									),
									firstName
								)
							: __(
									'¿Es un regalo? Podemos avisar a quien lo recibe de que le llega un paquete tuyo, sin desvelar qué es ni cuánto cuesta.',
									'lachinata-core'
								)}
					</Notice>
				)}
				<div className={cx('lc-gift', data.open && 'lc-gift--open')}>
					<label className="lc-gift__toggle" htmlFor="lc-gift-open">
						<input
							type="checkbox"
							id="lc-gift-open"
							checked={data.open}
							onChange={() => set({ open: !data.open })}
						/>
						<span className="lc-gift__box" aria-hidden="true">
							{data.open && <Icon name="check" size="sm" />}
						</span>
						<span className="lc-gift__text">
							<span className="label">
								<Icon name="gift" size="sm" />
								{__('Es un regalo', 'lachinata-core')}
							</span>
							<span className="lc-gift__hint body-sm">
								{__(
									'Con tu mensaje escrito a mano en una tarjeta.',
									'lachinata-core'
								)}
							</span>
						</span>
					</label>
					{data.open && (
						<div className="lc-gift__panel">
							<Field
								field="to"
								label={__('Para', 'lachinata-core')}
								placeholder={__(
									'Nombre de quien lo recibe',
									'lachinata-core'
								)}
								value={data.to}
								maxLength={NAME_MAX}
								onChange={(to) => {
									toTouched.current = true;
									set({ to });
								}}
							/>
							<Field
								field="message"
								type="textarea"
								label={__('Tu mensaje', 'lachinata-core')}
								placeholder={sprintf(
									/* translators: %d: maximum number of characters. */
									__(
										'Lo escribiremos a mano en la tarjeta (hasta %d caracteres)',
										'lachinata-core'
									),
									MESSAGE_MAX
								)}
								value={data.message}
								maxLength={MESSAGE_MAX}
								onChange={(message) => set({ message })}
							/>
							<div className="lc-gift__notify">
								<span className="label" id="lc-gift-notify">
									{__(
										'Avisar a quien lo recibe',
										'lachinata-core'
									)}
								</span>
								<span className="lc-gift__hint body-sm">
									{__(
										'Le diremos que va a recibir un paquete de La Chinata y que es un regalo tuyo, sin desvelar qué es ni cuánto cuesta. Así nadie lo rechaza por sorpresa.',
										'lachinata-core'
									)}
								</span>
								<div
									className="lc-gift__via"
									role="group"
									aria-labelledby="lc-gift-notify"
								>
									{vias.map((via) => (
										<button
											key={via.id}
											type="button"
											className={cx(
												'lc-chip',
												'label',
												data.via === via.id &&
													'lc-chip--on'
											)}
											aria-pressed={
												data.via === via.id
													? 'true'
													: 'false'
											}
											onClick={() =>
												set({
													via: via.id,
													contact:
														via.id === data.via
															? data.contact
															: '',
												})
											}
										>
											{via.label}
										</button>
									))}
								</div>
								{data.via === 'email' && (
									<Field
										field="contact"
										type="email"
										inputMode="email"
										label={__(
											'Correo de quien lo recibe',
											'lachinata-core'
										)}
										placeholder="nombre@correo.es"
										value={data.contact}
										onChange={(contact) => set({ contact })}
									/>
								)}
								{data.via === 'sms' && (
									<Field
										field="contact"
										type="tel"
										inputMode="tel"
										label={__(
											'Móvil de quien lo recibe',
											'lachinata-core'
										)}
										placeholder="600 000 000"
										value={data.contact}
										onChange={(contact) => set({ contact })}
									/>
								)}
								{data.via !== 'none' && (
									<Field
										field="from"
										label={__(
											'De parte de',
											'lachinata-core'
										)}
										placeholder={__(
											'Tu nombre, tal y como lo verá',
											'lachinata-core'
										)}
										value={data.from}
										maxLength={NAME_MAX}
										onChange={(from) => set({ from })}
									/>
								)}
								{data.via !== 'none' && (
									<span className="lc-gift__hint caption">
										{__(
											'Solo usaremos este dato para el aviso del regalo.',
											'lachinata-core'
										)}
									</span>
								)}
							</div>
						</div>
					)}
				</div>
			</div>
		</section>
	);
}

registerPlugin('lachinata-gift', {
	scope: 'woocommerce-checkout',
	// WooCommerce's Fill clones its child with the slot's props (`cart`, `extensions`).
	render: () => (
		<Fill>
			<GiftCard />
		</Fill>
	),
});
