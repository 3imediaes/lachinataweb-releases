<?php
/**
 * Email to the recipient of a gift (tablero Regalo, 5). Override it in the theme:
 * `woocommerce/emails/lachinata-gift-recipient.php`.
 *
 * @package LaChinata\Core
 *
 * @var \LaChinata\Core\Modules\Gift\Message $message       Texts.
 * @var string                               $email_heading Heading.
 * @var string                               $about_url     «¿Qué es La Chinata?».
 * @var \WC_Email                            $email         Email.
 */

defined( 'ABSPATH' ) || exit;

$lachinata_strong = array( 'strong' => array() );
$lachinata_when   = $message->when();

/**
 * WooCommerce: email header.
 *
 * @since 0.7.0
 */
do_action( 'woocommerce_email_header', $email_heading, $email ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.HookCommentWrongStyle, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook.
?>
<p style="margin:0 0 16px"><?php echo esc_html( $message->greeting() ); ?></p>
<p style="margin:0 0 16px"><?php echo wp_kses( $message->lead( '<strong>' . esc_html( $message->from ) . '</strong>', '' === $lachinata_when ? '' : '<strong>' . esc_html( $lachinata_when ) . '</strong>' ), $lachinata_strong ); ?></p>
<p style="margin:0 0 24px"><?php echo esc_html( $message->reassurance() ); ?></p>
<?php if ( '' !== $message->link ) : ?>
	<p style="margin:0 0 24px">
		<a href="<?php echo esc_url( $message->link ); ?>" style="display:block;box-sizing:border-box;width:100%;padding:12px 16px;border:1px solid #231f20;color:#231f20;font-weight:500;text-align:center;text-decoration:none"><?php esc_html_e( 'Seguir el paquete', 'lachinata-core' ); ?> &rarr;</a>
	</p>
<?php endif; ?>
<p style="margin:0 0 24px;font-size:13px;line-height:18px;color:#747474"><?php echo esc_html( $message->why() ); ?></p>
<?php if ( '' !== $about_url ) : ?>
	<p style="margin:0;padding-top:12px;border-top:1px solid #e8ebed;font-size:13px;line-height:18px;text-align:right">
		<a href="<?php echo esc_url( $about_url ); ?>" style="color:#747474">
			<?php
			/* translators: %s: shop name. */
			echo esc_html( sprintf( __( '¿Qué es %s?', 'lachinata-core' ), $message->brand ) );
			?>
		</a>
	</p>
<?php endif; ?>
<?php
/**
 * WooCommerce: email footer.
 *
 * @since 0.7.0
 */
do_action( 'woocommerce_email_footer', $email ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.HookCommentWrongStyle, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook.
