<?php
/**
 * Payment page of an order (order-pay): the link a phone order or a failed payment sends
 * (06-correos.md, «Pagar {total}»). The checkout's look (CheckoutSection cards on
 * surface-2, the order summary and the payment methods as PaymentOption), with WooCommerce's
 * own markup inside #payment, which the gateways' scripts (Stripe, PayPal) and
 * WooCommerce's checkout.js need: ids, classes, actions and nonce stay as in the template.
 *
 * @see https://woocommerce.com/document/template-structure/
 * @package LaChinata\Theme
 * @version 10.9.0
 *
 * @var WC_Order             $order              Order.
 * @var WC_Payment_Gateway[] $available_gateways Gateways.
 * @var string               $order_button_text  WooCommerce's button text.
 */

defined( 'ABSPATH' ) || exit;

$lachinata_total = html_entity_decode( wp_strip_all_tags( wc_price( (float) $order->get_total(), array( 'currency' => $order->get_currency() ) ) ), ENT_QUOTES, 'UTF-8' );
/* translators: %s: order total («69,85 €»). */
$lachinata_button = sprintf( __( 'Pagar %s', 'lachinata' ), $lachinata_total );
?>
<form id="order_review" method="post" class="lc-pay">
	<header class="lc-pay__head">
		<p class="eyebrow">
			<?php
			/* translators: %s: order number. */
			echo esc_html( sprintf( __( 'Pedido %s', 'lachinata' ), $order->get_order_number() ) );
			?>
		</p>
		<h1 class="h2 lc-pay__title"><?php esc_html_e( 'Paga tu pedido', 'lachinata' ); ?></h1>
		<p class="body-sm lc-pay__lead"><?php esc_html_e( 'Elige cómo pagar: con tarjeta, Apple Pay, Google Pay o PayPal. En cuanto lo pagues, lo preparamos.', 'lachinata' ); ?></p>
	</header>

	<div class="lc-pay__summary">
		<section class="lc-chk" aria-labelledby="lc-pay-summary-t">
			<header class="lc-chk__head">
				<span class="lc-chk__icon" aria-hidden="true"><?php echo lachinata_icon( 'receipt', array( 'size' => 'sm' ) ); ?></span>
				<h2 class="h4 lc-chk__title" id="lc-pay-summary-t"><?php esc_html_e( 'Tu pedido', 'lachinata' ); ?></h2>
			</header>
			<div class="lc-chk__body">
				<?php lachinata_part( 'order-summary', array( 'order' => $order ) ); ?>
			</div>
		</section>
	</div>

	<div class="lc-pay__main">
		<?php
		/**
		 * WooCommerce: before the payment section of the payment page.
		 *
		 * @since 8.2.0
		 */
		do_action( 'woocommerce_pay_order_before_payment' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook.
		?>
		<section class="lc-chk" aria-labelledby="lc-pay-payment-t">
			<header class="lc-chk__head">
				<span class="lc-chk__icon" aria-hidden="true"><?php echo lachinata_icon( 'card', array( 'size' => 'sm' ) ); ?></span>
				<h2 class="h4 lc-chk__title" id="lc-pay-payment-t"><?php esc_html_e( 'Pago', 'lachinata' ); ?></h2>
				<span class="lc-chk__aside body-sm"><?php esc_html_e( 'Pago cifrado', 'lachinata' ); ?></span>
			</header>
			<div class="lc-chk__body">
				<div id="payment">
					<?php if ( $order->needs_payment() ) : ?>
						<ul class="wc_payment_methods payment_methods methods" aria-label="<?php esc_attr_e( 'Formas de pago', 'lachinata' ); ?>">
							<?php
							if ( ! empty( $available_gateways ) ) {
								foreach ( $available_gateways as $lachinata_gateway ) {
									wc_get_template( 'checkout/payment-method.php', array( 'gateway' => $lachinata_gateway ) );
								}
							} else {
								echo '<li>' . lachinata_notice( esc_html__( 'Ahora mismo no hay ninguna forma de pago disponible. Escríbenos y lo resolvemos.', 'lachinata' ), 'warning' ) . '</li>';
							}
							?>
						</ul>
					<?php endif; ?>
					<div class="form-row lc-pay__submit">
						<input type="hidden" name="woocommerce_pay" value="1" />

						<?php wc_get_template( 'checkout/terms.php' ); ?>

						<?php
						/**
						 * WooCommerce: before the button of the payment page.
						 *
						 * @since 2.5.0
						 */
						do_action( 'woocommerce_pay_order_before_submit' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook.

						/**
						 * WooCommerce: the button of the payment page (gateways change it).
						 *
						 * @since 2.5.0
						 *
						 * @param string $html Button.
						 */
						echo apply_filters( 'woocommerce_pay_order_button_html', '<button type="submit" class="lc-btn button lc-btn--block alt" id="place_order" value="' . esc_attr( $lachinata_button ) . '" data-value="' . esc_attr( $lachinata_button ) . '">' . esc_html( $lachinata_button ) . '</button>' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook; built from escaped parts.

						/**
						 * WooCommerce: after the button of the payment page.
						 *
						 * @since 2.5.0
						 */
						do_action( 'woocommerce_pay_order_after_submit' ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook.
						?>

						<?php wp_nonce_field( 'woocommerce-pay', 'woocommerce-pay-nonce' ); ?>
					</div>
				</div>
			</div>
		</section>
	</div>
</form>
