<?php
/**
 * Public functions of the plugin: the contract the theme relies on.
 *
 * @package LaChinata\Core
 */

defined( 'ABSPATH' ) || exit;

// Plugins load before the theme, so this is the definition in normal requests. The guard
// only matters when the plugin is activated in a request where the theme's fallback
// (always false) is already loaded.
if ( ! function_exists( 'lachinata_module' ) ) {
	/**
	 * Whether a module is enabled and running on this site.
	 *
	 * @param string $id Module id (catalog, shipping, eta…).
	 */
	function lachinata_module( string $id ): bool {
		return LaChinata\Core\Plugin::instance()->modules()->is_active( $id );
	}
}

/**
 * Whether a product can ship to a destination, with the shipping module's restrictions,
 * zones and weight limits. The `locale` module filters the catalog with it.
 *
 * @param WC_Product                                                       $producto Product or variation.
 * @param string|array{country: string, state?: string, postcode?: string} $destino  «DE», «ES:PM» or an address.
 * @return true|string True, or the reason: `producto_restringido`, `zona_no_cubierta` or `peso_max`.
 */
function lachinata_producto_enviable( WC_Product $producto, string|array $destino ): true|string {
	if ( ! lachinata_module( 'shipping' ) ) {
		return true;
	}
	$destination = is_string( $destino ) ? LaChinata\Core\Modules\Shipping\Destination::parse( $destino ) : $destino;
	if ( null === $destination || empty( $destination['country'] ) ) {
		return true;
	}
	return LaChinata\Core\Modules\Shipping\Shippable::check( $producto, $destination );
}
