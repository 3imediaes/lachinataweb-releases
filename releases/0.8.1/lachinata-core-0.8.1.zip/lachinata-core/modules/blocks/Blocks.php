<?php
/**
 * Registration of the editorial blocks.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Blocks;

defined( 'ABSPATH' ) || exit;

/**
 * Each block is a folder with its `block.json` under blocks/, rendered on the server
 * (Render). The editor script (src/index.js) gives each one its sidebar and a live preview.
 */
final class Blocks {

	/**
	 * Editor script handle (block.json `editorScript`).
	 */
	public const EDITOR = 'lachinata-blocks-editor';

	/**
	 * Block folder → render callback.
	 */
	public const BLOCKS = array(
		'hero'           => 'hero',
		'category-tiles' => 'category_tiles',
		'promo'          => 'promo',
		'usp'            => 'usp',
		'history'        => 'history',
		'quote'          => 'quote',
	);

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_action( 'init', array( self::class, 'register' ) );
		add_filter( 'block_categories_all', array( self::class, 'category' ) );
	}

	/**
	 * Registers the editor script and the blocks.
	 */
	public static function register(): void {
		$asset_file = LACHINATA_CORE_DIR . '/modules/blocks/build/blocks.asset.php';
		$asset      = is_readable( $asset_file ) ? require $asset_file : array(
			'dependencies' => array( 'wp-blocks', 'wp-block-editor', 'wp-components', 'wp-element', 'wp-i18n', 'wp-server-side-render' ),
			'version'      => LACHINATA_CORE_VERSION,
		);
		wp_register_script( self::EDITOR, plugins_url( 'modules/blocks/build/blocks.js', LACHINATA_CORE_FILE ), (array) $asset['dependencies'], (string) $asset['version'], true );
		wp_set_script_translations( self::EDITOR, 'lachinata-core', LACHINATA_CORE_DIR . '/languages' );
		foreach ( self::BLOCKS as $folder => $method ) {
			register_block_type(
				LACHINATA_CORE_DIR . '/modules/blocks/blocks/' . $folder,
				array(
					'render_callback' => static fn( $attributes ): string => Render::$method( is_array( $attributes ) ? $attributes : array() ),
				)
			);
		}
	}

	/**
	 * «La Chinata» in the inserter.
	 *
	 * @param mixed $categories Categories.
	 * @return array<int, array<string, mixed>>
	 */
	public static function category( $categories ): array {
		$categories = is_array( $categories ) ? $categories : array();
		if ( ! in_array( 'lachinata', array_column( $categories, 'slug' ), true ) ) {
			array_unshift(
				$categories,
				array(
					'slug'  => 'lachinata',
					'title' => __( 'La Chinata', 'lachinata-core' ),
					'icon'  => null,
				)
			);
		}
		return $categories;
	}
}
