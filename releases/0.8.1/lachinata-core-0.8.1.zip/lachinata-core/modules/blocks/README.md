# Módulo `blocks`

Bloques editoriales de Gutenberg, uno por pieza editorial del sistema («Sin Elementor: bloques propios», `design-system/sistema/03-implementacion.md`), y patrones para componer la Home y Acerca de eligiendo, no diseñando (`02-plantillas.md`, tableros Main, HomeDesktop, Marca y MarcaDesktop). El contenido son los atributos del bloque: sobrevive a un cambio de tema. El tema aporta el CSS (las mismas clases que sus patrones y que `bundle.css`).

## Bloques (categoría «La Chinata»)

Todos dinámicos: `block.json` en `blocks/<nombre>/`, render en PHP (`Render.php`) y, en el editor, panel lateral con los atributos y vista previa del render del servidor (`src/index.js`, `ServerSideRender`).

| Bloque | Pieza del sistema | HTML | Atributos |
| --- | --- | --- | --- |
| `lachinata/hero` | Hero de la Home: `CategoryTile` fotográfico con eyebrow, titular `editorial-display` (o cifra `campaign` en SantElia), entradilla y botón | `lc-hero-block lc-tile--<tinta>`, `lc-btn` | antetítulo, titular, entradilla, botón y enlace, tinta (crema, cosmética, aceites, gourmet, regalos, hogar), tamaño (display / h1), titular como cifra de campaña, foto |
| `lachinata/category-tiles` | `CategoryTile` en su tinta o con su foto; el primero grande | `lc-tiles` (`--list`: una bajo otra) + `lc-tile` | categorías (slugs en orden; vacío, las principales), texto del enlace, disposición |
| `lachinata/promo` | Banner de campaña: cifra en `campaign`, 1–2 palabras en `campaign-word`, explicación y enlace | `lc-campaign` (`--ink`, `--coral`) | cifra, palabras, explicación, enlace, fondo (acento, tinta o coral `campaign-coral` con texto `ink`, solo Black Friday) |
| `lachinata/usp` | `UspBar` | `lc-usp` (`--row`) | ventajas (icono · título · texto), disposición |
| `lachinata/history` | Historia sobre `surface-cream`: eyebrow, `editorial-h2`, `editorial-lead`, botón secundario | `lc-history`, `lc-btn lc-btn--secondary` | antetítulo, titular, entradilla, botón y enlace |
| `lachinata/quote` | Cita en `editorial-quote` y `olive-deep` | `lc-quote-block` | cita, autor |

**Pendientes del sistema de diseño** (decisiones.md, incremento 6, punto 8): revista, oleotecas con mapa, cifras y formulario de franquicias no tienen componente; se harán cuando el equipo de diseño los formalice, sin clases provisionales. El formulario de franquicias usará `Contracts\Newsletter` (módulo `newsletter`) con la etiqueta «franquicia» y el correo a la dirección del panel.

## Patrones

| Patrón | Para | Contenido |
| --- | --- | --- |
| `lachinata/home` | La página de inicio | hero y banner de campaña antes del bloque «Más»; historia después. Entre medias, el tema pinta categorías, ventajas, TOP 10 y una sección por categoría (`front-page.php`) |
| `lachinata/about` | Acerca de, con la plantilla Editorial (el título y el extracto de la página son la cabecera) | texto, cita, «Tres mundos, un ingrediente» y los tres mundos en lista |

Los patrones del tema (`home-hero`, `home-campaign`, `home-history`, `editorial-quote`) siguen registrados para un sitio sin el módulo y se ocultan del insertador con él encendido (`theme/inc/setup.php`). `home-brand-tiles` (Oleotecas y Regalos de empresa) se mantiene hasta que exista su componente. El seed monta la Home y Acerca de con los patrones nuevos.

`theme.json` ya bloquea lo que está fuera del sistema: sin colores, degradados ni duotonos propios, sin tamaños de letra ni espaciados libres, solo las tres familias del sistema.

## Tests

- `tests/BlocksTest.php`: registro (dinámicos, categoría, script del editor), HTML de cada bloque (clases, escapado, solo tintas del sistema, vacío sin contenido), tiles en orden y en lista, patrones hechos de bloques registrados, patrones del tema fuera del insertador.
