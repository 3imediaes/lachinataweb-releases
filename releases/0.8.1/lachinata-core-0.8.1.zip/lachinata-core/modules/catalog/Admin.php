<?php
/**
 * Admin helpers shared by the catalog screens.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

defined( 'ABSPATH' ) || exit;

/**
 * Media picker and the admin script that drives it.
 */
final class Admin {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_action( 'admin_enqueue_scripts', array( self::class, 'enqueue' ) );
	}

	/**
	 * Loads the media picker on product and term screens.
	 */
	public static function enqueue(): void {
		$screen = get_current_screen();
		if ( null === $screen || ! in_array( $screen->id, array( 'product', 'edit-' . TipoTaxonomy::TAXONOMY ), true ) ) {
			return;
		}
		wp_enqueue_media();
		wp_enqueue_script(
			'lachinata-catalog-admin',
			plugins_url( 'assets/admin.js', __FILE__ ),
			array( 'wp-i18n' ),
			LACHINATA_CORE_VERSION,
			array( 'in_footer' => true )
		);
		wp_set_script_translations( 'lachinata-catalog-admin', 'lachinata-core', LACHINATA_CORE_DIR . '/languages' );
	}

	/**
	 * Hidden attachment id + preview + choose/remove buttons.
	 *
	 * @param string $name          Field name and id.
	 * @param int    $attachment_id Current attachment id.
	 */
	public static function image_picker( string $name, int $attachment_id ): void {
		printf(
			'<div class="lc-image-picker" data-lc-image-picker><input type="hidden" name="%1$s" id="%1$s" value="%2$s"><div data-lc-preview>%3$s</div><p><button type="button" class="button" data-lc-choose>%4$s</button> <button type="button" class="button-link button-link-delete" data-lc-remove%5$s>%6$s</button></p></div>',
			esc_attr( $name ),
			esc_attr( (string) $attachment_id ),
			$attachment_id ? wp_get_attachment_image( $attachment_id, 'thumbnail' ) : '',
			esc_html__( 'Elegir imagen', 'lachinata-core' ),
			$attachment_id ? '' : ' hidden',
			esc_html__( 'Quitar', 'lachinata-core' )
		);
	}
}
