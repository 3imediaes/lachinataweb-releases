<?php
/**
 * Module `catalog`: catalog data that used to live in ACF.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

use LaChinata\Core\Module;

defined( 'ABSPATH' ) || exit;

/**
 * Content and unit price, ingredients, label, description image, best-before date,
 * international exclusion, category tint and seals (`tipo`) with icon.
 */
final class CatalogModule extends Module {

	/**
	 * Module id.
	 */
	public function id(): string {
		return 'catalog';
	}

	/**
	 * Module name.
	 */
	public function label(): string {
		return __( 'Catálogo', 'lachinata-core' );
	}

	/**
	 * Module description.
	 */
	public function description(): string {
		return __( 'Contenido y precio por unidad, ingredientes, etiqueta, sellos y tinta de categoría. Sustituye a ACF.', 'lachinata-core' );
	}

	/**
	 * Version in which the module was added.
	 */
	public function since(): string {
		return '0.2.0';
	}

	/**
	 * Documentation.
	 */
	public function docs(): string {
		return 'design-system/sistema/03-implementacion.md';
	}

	/**
	 * Requirements.
	 *
	 * @return array{woocommerce: string}
	 */
	public function requires(): array {
		return array( 'woocommerce' => '10.0' );
	}

	/**
	 * Registers the hooks.
	 */
	public function boot(): void {
		add_action( 'init', array( TipoTaxonomy::class, 'register' ), 5 );
		add_action( 'init', array( Fields::class, 'register' ) );
		Storefront::boot();

		if ( is_admin() ) {
			Admin::boot();
			ProductAdmin::boot();
			TermFields::boot();
		}

		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::add_command( 'lachinata catalog', NormalizeCommand::class );
		}
	}
}
