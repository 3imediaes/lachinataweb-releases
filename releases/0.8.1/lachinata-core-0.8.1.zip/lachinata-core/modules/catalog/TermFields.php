<?php
/**
 * Fields on the category (tint) and seal (icon) screens.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

defined( 'ABSPATH' ) || exit;

/**
 * Adds and saves the catalog term fields.
 */
final class TermFields {

	private const NONCE = 'lachinata_catalog_term';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_action( 'product_cat_add_form_fields', array( self::class, 'tint_add' ) );
		add_action( 'product_cat_edit_form_fields', array( self::class, 'tint_edit' ) );
		add_action( 'created_product_cat', array( self::class, 'save_tint' ) );
		add_action( 'edited_product_cat', array( self::class, 'save_tint' ) );

		add_action( TipoTaxonomy::TAXONOMY . '_add_form_fields', array( self::class, 'icon_add' ) );
		add_action( TipoTaxonomy::TAXONOMY . '_edit_form_fields', array( self::class, 'icon_edit' ) );
		add_action( 'created_' . TipoTaxonomy::TAXONOMY, array( self::class, 'save_icon' ) );
		add_action( 'edited_' . TipoTaxonomy::TAXONOMY, array( self::class, 'save_icon' ) );
	}

	/**
	 * Tint names for the select.
	 *
	 * @return array<string, string>
	 */
	private static function tint_options(): array {
		return array(
			''          => __( 'Sin tinta (hereda de la categoría superior)', 'lachinata-core' ),
			'cosmetica' => __( 'Cosmética', 'lachinata-core' ),
			'aceites'   => __( 'Aceites', 'lachinata-core' ),
			'gourmet'   => __( 'Gourmet', 'lachinata-core' ),
			'regalos'   => __( 'Regalos', 'lachinata-core' ),
			'hogar'     => __( 'Hogar', 'lachinata-core' ),
		);
	}

	/**
	 * Tint select.
	 *
	 * @param string $current Current value.
	 */
	private static function tint_select( string $current ): void {
		wp_nonce_field( self::NONCE, self::NONCE . '_nonce' );
		echo '<select name="lc_tint" id="lc_tint">';
		foreach ( self::tint_options() as $value => $label ) {
			printf( '<option value="%1$s"%2$s>%3$s</option>', esc_attr( $value ), selected( $current, $value, false ), esc_html( $label ) );
		}
		echo '</select>';
		echo '<p class="description">' . esc_html__( 'Color de la categoría en tiles, tarjetas y menú. Las subcategorías sin tinta usan la de su categoría superior.', 'lachinata-core' ) . '</p>';
	}

	/**
	 * Tint field on the «add category» form.
	 */
	public static function tint_add(): void {
		echo '<div class="form-field"><label for="lc_tint">' . esc_html__( 'Tinta', 'lachinata-core' ) . '</label>';
		self::tint_select( '' );
		echo '</div>';
	}

	/**
	 * Tint field on the «edit category» form.
	 *
	 * @param \WP_Term $term Term.
	 */
	public static function tint_edit( \WP_Term $term ): void {
		echo '<tr class="form-field"><th scope="row"><label for="lc_tint">' . esc_html__( 'Tinta', 'lachinata-core' ) . '</label></th><td>';
		self::tint_select( (string) get_term_meta( $term->term_id, Fields::TINT, true ) );
		echo '</td></tr>';
	}

	/**
	 * Saves the tint.
	 *
	 * @param int $term_id Term id.
	 */
	public static function save_tint( int $term_id ): void {
		$nonce = isset( $_POST[ self::NONCE . '_nonce' ] ) ? sanitize_key( wp_unslash( $_POST[ self::NONCE . '_nonce' ] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, self::NONCE ) || ! current_user_can( 'manage_product_terms' ) || ! isset( $_POST['lc_tint'] ) ) {
			return;
		}
		$tint = Fields::sanitize_tint( sanitize_key( wp_unslash( $_POST['lc_tint'] ) ) );
		if ( '' === $tint ) {
			delete_term_meta( $term_id, Fields::TINT );
		} else {
			update_term_meta( $term_id, Fields::TINT, $tint );
		}
	}

	/**
	 * Icon picker.
	 *
	 * @param int $attachment_id Current attachment id.
	 */
	private static function icon_picker( int $attachment_id ): void {
		wp_nonce_field( self::NONCE, self::NONCE . '_nonce' );
		Admin::image_picker( 'lc_icono', $attachment_id );
		echo '<p class="description">' . esc_html__( 'Imagen del sello que se muestra en la ficha de producto.', 'lachinata-core' ) . '</p>';
	}

	/**
	 * Icon field on the «add seal» form.
	 */
	public static function icon_add(): void {
		echo '<div class="form-field"><label for="lc_icono">' . esc_html__( 'Icono', 'lachinata-core' ) . '</label>';
		self::icon_picker( 0 );
		echo '</div>';
	}

	/**
	 * Icon field on the «edit seal» form.
	 *
	 * @param \WP_Term $term Term.
	 */
	public static function icon_edit( \WP_Term $term ): void {
		echo '<tr class="form-field"><th scope="row"><label for="lc_icono">' . esc_html__( 'Icono', 'lachinata-core' ) . '</label></th><td>';
		self::icon_picker( Fields::icon( $term->term_id ) );
		echo '</td></tr>';
	}

	/**
	 * Saves the icon.
	 *
	 * @param int $term_id Term id.
	 */
	public static function save_icon( int $term_id ): void {
		$nonce = isset( $_POST[ self::NONCE . '_nonce' ] ) ? sanitize_key( wp_unslash( $_POST[ self::NONCE . '_nonce' ] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, self::NONCE ) || ! current_user_can( 'manage_product_terms' ) || ! isset( $_POST['lc_icono'] ) ) {
			return;
		}
		update_term_meta( $term_id, Fields::ICON, absint( $_POST['lc_icono'] ) );
	}
}
