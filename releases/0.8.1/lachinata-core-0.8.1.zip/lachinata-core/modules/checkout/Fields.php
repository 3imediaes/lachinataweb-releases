<?php
/**
 * Order of the address fields.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Checkout;

defined( 'ABSPATH' ) || exit;

/**
 * The delivery address in the order of the system: País, Teléfono, Nombre, Apellidos,
 * Dirección, Piso/puerta, Código postal, Ciudad, Provincia. Through WooCommerce's country
 * locale (`priority`, which the block checkout reads as `index`); the province is only shown
 * where the country has one (WooCommerce decides per country). Countries whose locale sets
 * its own position for these fields keep it.
 */
final class Fields {

	/**
	 * Position of each field (WooCommerce's: country 1, first name 10, last name 20,
	 * company 30, address 40, apartment 50, city 70, province 80, postcode 90, phone 100).
	 */
	public const PRIORITIES = array(
		'phone'    => 5,
		'postcode' => 65,
		'city'     => 70,
		'state'    => 80,
	);

	/**
	 * Countries where the province is hidden although WooCommerce has states for them: they
	 * are not part of the postal address (Germany's Länder). WooCommerce already hides it
	 * where the country has none (France, Portugal…). Filter `lachinata/checkout/no_state_countries`.
	 */
	public const NO_STATE = array( 'DE' );

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		// Phone required in the delivery address (express wallets are asked for it too).
		add_filter( 'pre_option_woocommerce_checkout_phone_field', static fn(): string => 'required' );
		add_filter( 'woocommerce_get_country_locale_default', array( self::class, 'default_locale' ) );
		add_filter( 'woocommerce_get_country_locale', array( self::class, 'country_locales' ) );
	}

	/**
	 * Positions in each country's locale: the block checkout builds its default fields from
	 * its core fields and only applies the countries' locales. The phone always goes after
	 * the country; postcode, city and province only where the country has no order of its own.
	 *
	 * @param array<string, array<string, array<string, mixed>>> $locales Locales by country.
	 * @return array<string, array<string, array<string, mixed>>>
	 */
	public static function country_locales( $locales ): array {
		$locales = is_array( $locales ) ? $locales : array();
		foreach ( array_keys( WC()->countries->get_countries() ) as $country ) {
			$locale = (array) ( $locales[ $country ] ?? array() );
			foreach ( self::PRIORITIES as $field => $priority ) {
				$own = isset( $locale[ $field ]['priority'] ) && 'phone' !== $field;
				if ( ! $own ) {
					$locale[ $field ]             = (array) ( $locale[ $field ] ?? array() );
					$locale[ $field ]['priority'] = $priority;
				}
			}
			$locales[ $country ] = $locale;
		}
		/**
		 * Countries where the checkout hides the province although WooCommerce has states.
		 *
		 * @since 0.5.1
		 *
		 * @param string[] $countries ISO codes.
		 */
		foreach ( (array) apply_filters( 'lachinata/checkout/no_state_countries', self::NO_STATE ) as $country ) {
			$locales[ $country ]['state'] = array_merge(
				(array) ( $locales[ $country ]['state'] ?? array() ),
				array(
					'required' => false,
					'hidden'   => true,
				)
			);
		}
		return $locales;
	}

	/**
	 * Positions in the default locale.
	 *
	 * @param array<string, array<string, mixed>> $locale Default locale.
	 * @return array<string, array<string, mixed>>
	 */
	public static function default_locale( $locale ): array {
		$locale = is_array( $locale ) ? $locale : array();
		foreach ( self::PRIORITIES as $field => $priority ) {
			$locale[ $field ]             = (array) ( $locale[ $field ] ?? array() );
			$locale[ $field ]['priority'] = $priority;
		}
		return $locale;
	}
}
