<?php
/**
 * Stripe on the payment page of an order (order-pay).
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Checkout;

defined( 'ABSPATH' ) || exit;

/**
 * The payment page of an order (the link of a phone order) is WooCommerce's classic form,
 * dressed by the theme (`checkout/form-pay.php`). Stripe works there as on the checkout:
 *
 * - Apple Pay and Google Pay in one row above the payment methods, at 44 px with square
 *   corners. Stripe prints its express element there (`woocommerce_pay_order_before_payment`)
 *   when express checkout is on for the checkout; it only shows when the device has a wallet.
 *   When it shows, the theme's «o» separator appears and the texts marked `data-lc-wallets`
 *   take the wording that names Apple Pay and Google Pay. Without it (no wallet, no
 *   JavaScript) they name only the card and PayPal.
 * - The card form with the checkout's look: the appearance is built in the browser from the
 *   theme's tokens (CSS custom properties), so it follows the tokens and dark mode, and the
 *   shop's own stylesheets may give Stripe the DIN font (`wc_stripe_upe_permitted_font_domains`;
 *   in production the fonts need CORS for js.stripe.com, see docs/despliegue-checkout.md).
 * - Whether the shop offers wallets at all goes to the theme by `lachinata/checkout/wallets`
 *   (the page's lead and the email of a phone order).
 */
final class PayForOrder {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_filter( 'lachinata/checkout/wallets', array( self::class, 'wallets' ) );
		add_filter( 'wc_stripe_express_checkout_params', array( self::class, 'express_params' ) );
		add_filter( 'wc_stripe_upe_permitted_font_domains', array( self::class, 'font_domains' ) );
		add_action( 'wp_enqueue_scripts', array( self::class, 'scripts' ), 100 );
		add_action( 'wp_footer', array( self::class, 'scripts' ), 16 );
	}

	/**
	 * Whether the page is the payment page of an order.
	 */
	public static function is_pay_page(): bool {
		return function_exists( 'is_checkout_pay_page' ) && is_checkout_pay_page();
	}

	/**
	 * Whether Stripe offers Apple Pay and Google Pay on the checkout (and so on order-pay).
	 *
	 * @param mixed $wallets Value so far.
	 */
	public static function wallets( $wallets = false ): bool {
		$settings = get_option( 'woocommerce_stripe_settings', array() );
		if ( ! is_array( $settings ) || ! Gateways::stripe_enabled() || 'yes' !== ( $settings['express_checkout'] ?? 'no' ) ) {
			return (bool) $wallets;
		}
		$locations = $settings['express_checkout_button_locations'] ?? array( 'product', 'cart' );
		return in_array( 'checkout', (array) $locations, true );
	}

	/**
	 * Express buttons at 44 px with square corners, as on the checkout (Page.php sets them
	 * on the block; the classic element takes them from these params).
	 *
	 * @param mixed $params Stripe's params.
	 * @return mixed
	 */
	public static function express_params( $params ) {
		if ( ! is_array( $params ) || ! self::is_pay_page() ) {
			return $params;
		}
		$params['button']           = is_array( $params['button'] ?? null ) ? $params['button'] : array();
		$params['button']['height'] = '44';
		$params['button']['radius'] = '0';
		return $params;
	}

	/**
	 * The shop's own domain, so Stripe passes its stylesheets (DIN's @font-face) to the card
	 * form on order-pay.
	 *
	 * @param mixed $domains Permitted domains.
	 * @return mixed
	 */
	public static function font_domains( $domains ) {
		if ( ! is_array( $domains ) || ! self::is_pay_page() ) {
			return $domains;
		}
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		if ( is_string( $host ) && '' !== $host ) {
			$domains[] = $host;
		}
		return $domains;
	}

	/**
	 * The appearance of the card form, before Stripe's script, and the wallets' row.
	 * Stripe enqueues on wp_enqueue_scripts and, for express, in the footer: both are tried.
	 */
	public static function scripts(): void {
		if ( ! self::is_pay_page() ) {
			return;
		}
		static $appearance = false;
		static $express    = false;
		if ( ! $appearance && wp_script_is( Gateways::STRIPE_CLASSIC, 'enqueued' ) ) {
			wp_add_inline_script( Gateways::STRIPE_CLASSIC, self::appearance_script(), 'before' );
			$appearance = true;
		}
		if ( ! $express && wp_script_is( 'wc_stripe_express_checkout', 'enqueued' ) ) {
			wp_add_inline_script( 'wc_stripe_express_checkout', self::wallets_script() );
			$express = true;
		}
	}

	/**
	 * Fills `wc_stripe_upe_params.appearance` (Stripe uses it instead of reading the page)
	 * from the theme's tokens: inputs at control-md, line-strong border, no radius, DIN, the
	 * system's focus ring; labels as the checkout's.
	 */
	public static function appearance_script(): string {
		return <<<'JS'
(() => {
	if (typeof wc_stripe_upe_params !== 'object') return;
	const css = getComputedStyle(document.documentElement);
	const v = (name, fallback) => css.getPropertyValue(name).trim() || fallback;
	const ink = v('--ink', '#231f20');
	const focus = v('--focus', ink);
	const height = parseInt(v('--control-md', '44px'), 10) || 44;
	wc_stripe_upe_params.appearance = {
		theme: 'stripe',
		labels: 'above',
		variables: {
			fontFamily: v('--font-sans', 'Arial, sans-serif'),
			fontSizeBase: '16px',
			fontWeightNormal: '300',
			fontWeightMedium: '500',
			fontLineHeight: '24px',
			colorPrimary: ink,
			colorText: ink,
			colorTextSecondary: v('--ink-soft', ink),
			colorTextPlaceholder: v('--ink-muted', ink),
			colorBackground: v('--surface', '#ffffff'),
			colorDanger: v('--danger-text', '#d4001f'),
			borderRadius: '0px',
			spacingUnit: '4px',
			gridRowSpacing: '16px',
			gridColumnSpacing: '12px',
		},
		rules: {
			'.Input': {
				padding: `${(height - 26) / 2}px 12px`,
				lineHeight: '24px',
				border: `1px solid ${v('--line-strong', '#d1d1d1')}`,
				boxShadow: 'none',
				fontWeight: '300',
			},
			'.Input:hover': { borderColor: ink },
			'.Input:focus': {
				borderColor: ink,
				boxShadow: 'none',
				outline: `2px solid ${focus}`,
				outlineOffset: '1px',
			},
			'.Input--invalid': { borderColor: v('--danger', '#ff0528'), boxShadow: 'none' },
			'.Label': { fontSize: '14px', lineHeight: '20px', fontWeight: '500', color: ink, marginBottom: '4px' },
			'.Error': { fontSize: '14px', lineHeight: '20px', color: v('--danger-text', '#d4001f') },
		},
	};
})();
JS;
	}

	/**
	 * When Stripe shows the wallets' row (the device has Apple Pay or Google Pay), the
	 * theme's «o» separator appears and the texts that offer the wallets take their wording.
	 */
	public static function wallets_script(): string {
		return <<<'JS'
(() => {
	const row = document.getElementById('wc-stripe-express-checkout-element');
	if (!row) return;
	const shown = () => {
		if (row.style.display === 'none' || !row.childElementCount) return false;
		document.querySelectorAll('[data-lc-wallets]').forEach((node) => {
			node.textContent = node.dataset.lcWallets;
		});
		document.querySelectorAll('.lc-pay__or').forEach((node) => {
			node.hidden = false;
		});
		return true;
	};
	if (shown()) return;
	const observer = new MutationObserver(() => shown() && observer.disconnect());
	observer.observe(row, { attributes: true, attributeFilter: ['style'], childList: true });
})();
JS;
	}
}
