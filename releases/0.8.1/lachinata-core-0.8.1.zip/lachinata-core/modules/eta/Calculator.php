<?php
/**
 * Delivery estimate engine.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Eta;

defined( 'ABSPATH' ) || exit;

/**
 * Pure logic, without WordPress («Cómo calcula» in 04-envios-entrega.md):
 *
 * 1. Dispatch: a working day has a cut-off time and is not a warehouse holiday. The order
 *    is taken today if today is a working day and it is before the cut-off (the earliest
 *    cut-off of the package's classes, when they have one); otherwise the next working
 *    day. Preparation days (the store's plus the classes' extra days) are added counting
 *    working days. If the classes restrict the dispatch weekdays (cold goods leave Monday
 *    to Wednesday), dispatch moves to the next allowed working day.
 * 2. Transit: the minimum and maximum days of the method in the zone are counted on
 *    delivery days, skipping the carrier's and the instance's no-delivery weekdays and
 *    the holidays of the destination country. If the classes restrict the delivery
 *    weekdays (fresh goods only on Fridays), each date moves to the next allowed one.
 * 3. Without a plan for the zone and method, or with no possible day, there is no
 *    estimate: the engine never makes a date up.
 */
final class Calculator {

	/**
	 * Days looked ahead before giving up (a configuration with no possible day).
	 */
	private const HORIZON = 120;

	/**
	 * Estimate for a method in a zone.
	 *
	 * @param EtaConfig          $config  Store configuration.
	 * @param Plan               $plan    Transit plan of the instance.
	 * @param string[]           $classes Shipping class slugs of the package.
	 * @param string             $country Destination country.
	 * @param \DateTimeImmutable $now     Current time, in the store's time zone.
	 */
	public static function estimate( EtaConfig $config, Plan $plan, array $classes, string $country, \DateTimeImmutable $now ): ?Estimate {
		$rules = $config->rules_for( $classes );
		if ( null === $rules ) {
			return null;
		}
		$today = $now->setTime( 0, 0 );

		$working = static fn( \DateTimeImmutable $day ): bool => null !== ( $config->cutoffs[ (int) $day->format( 'N' ) ] ?? null )
			&& ! isset( $config->warehouse_holidays[ $day->format( 'Y-m-d' ) ] );

		$cutoff = null;
		if ( $working( $today ) ) {
			list( $hour, $minute ) = array_map( 'intval', explode( ':', (string) ( $rules['cutoff'] ?? $config->cutoffs[ (int) $today->format( 'N' ) ] ) ) );
			$candidate             = $today->setTime( $hour, $minute );
			if ( $now < $candidate ) {
				$cutoff = $candidate;
			}
		}

		$start = null === $cutoff ? self::next( $today, $working ) : $today;
		$ships = null === $start ? null : self::dispatch( $start, $config->prep_days + $rules['extra_days'], $rules['ship_days'], $working );
		if ( null === $ships ) {
			return null;
		}

		// The cut-off only matters if ordering after it would dispatch later.
		if ( null !== $cutoff ) {
			$later = self::next( $today, $working );
			$alt   = null === $later ? null : self::dispatch( $later, $config->prep_days + $rules['extra_days'], $rules['ship_days'], $working );
			if ( null !== $alt && $alt == $ships ) { // phpcs:ignore Universal.Operators.StrictComparisons.LooseEqual -- Same date, different objects.
				$cutoff = null;
			}
		}

		$transit = self::transit( $config, $plan, $rules, $country, $ships );
		return null === $transit ? null : new Estimate( $ships, $transit->min, $transit->max, $cutoff );
	}

	/**
	 * Estimate for a package that has already left the warehouse on a given day: only the
	 * transit (step 2). The gift notice uses it when the order is shipped.
	 *
	 * @param EtaConfig          $config  Store configuration.
	 * @param Plan               $plan    Transit plan of the instance.
	 * @param string[]           $classes Shipping class slugs of the package.
	 * @param string             $country Destination country.
	 * @param \DateTimeImmutable $ships   Dispatch day, in the store's time zone.
	 */
	public static function from_dispatch( EtaConfig $config, Plan $plan, array $classes, string $country, \DateTimeImmutable $ships ): ?Estimate {
		$rules = $config->rules_for( $classes );
		return null === $rules ? null : self::transit( $config, $plan, $rules, $country, $ships->setTime( 0, 0 ) );
	}

	/**
	 * Delivery dates after the dispatch day.
	 *
	 * @param EtaConfig            $config  Store configuration.
	 * @param Plan                 $plan    Transit plan of the instance.
	 * @param array<string, mixed> $rules   Rules of the package's classes.
	 * @param string               $country Destination country.
	 * @param \DateTimeImmutable   $ships   Dispatch day (midnight).
	 */
	private static function transit( EtaConfig $config, Plan $plan, array $rules, string $country, \DateTimeImmutable $ships ): ?Estimate {
		$no_delivery = array_merge( $plan->no_delivery, $config->carriers[ $plan->carrier ]['no_delivery'] ?? array() );
		$holidays    = $config->country_holidays[ strtoupper( $country ) ] ?? array();
		$delivers    = static fn( \DateTimeImmutable $day ): bool => ! in_array( (int) $day->format( 'N' ), $no_delivery, true )
			&& ! isset( $holidays[ $day->format( 'Y-m-d' ) ] );

		$min = self::arrival( $ships, $plan->min_days, $delivers, $rules['delivery_days'] );
		$max = self::arrival( $ships, $plan->max_days, $delivers, $rules['delivery_days'] );
		if ( null === $min || null === $max ) {
			return null;
		}
		return new Estimate( $ships, $min, max( $min, $max ) );
	}

	/**
	 * Dispatch date from the day the order is taken.
	 *
	 * @param \DateTimeImmutable $start     Day the order is taken.
	 * @param int                $prep_days Preparation working days.
	 * @param int[]|null         $ship_days Allowed dispatch weekdays.
	 * @param callable           $working   Whether a day is a working day.
	 */
	private static function dispatch( \DateTimeImmutable $start, int $prep_days, ?array $ship_days, callable $working ): ?\DateTimeImmutable {
		$day = $start;
		for ( $i = 0; $i < $prep_days && null !== $day; $i++ ) {
			$day = self::next( $day, $working );
		}
		if ( null === $day || null === $ship_days || in_array( (int) $day->format( 'N' ), $ship_days, true ) ) {
			return $day;
		}
		return self::next( $day, static fn( \DateTimeImmutable $d ): bool => $working( $d ) && in_array( (int) $d->format( 'N' ), $ship_days, true ) );
	}

	/**
	 * Delivery date after some transit days.
	 *
	 * @param \DateTimeImmutable $ships         Dispatch date.
	 * @param int                $days          Transit days.
	 * @param callable           $delivers      Whether the carrier delivers on a day.
	 * @param int[]|null         $delivery_days Weekdays the classes allow delivery.
	 */
	private static function arrival( \DateTimeImmutable $ships, int $days, callable $delivers, ?array $delivery_days ): ?\DateTimeImmutable {
		$day = $ships;
		for ( $i = 0; $i < $days && null !== $day; $i++ ) {
			$day = self::next( $day, $delivers );
		}
		$allowed = static fn( \DateTimeImmutable $d ): bool => $delivers( $d ) && ( null === $delivery_days || in_array( (int) $d->format( 'N' ), $delivery_days, true ) );
		if ( null === $day || $allowed( $day ) ) {
			return $day;
		}
		return self::next( $day, $allowed );
	}

	/**
	 * Next day after the given one that meets a test, or null within the horizon.
	 *
	 * @param \DateTimeImmutable $day  Day.
	 * @param callable           $test Test.
	 */
	private static function next( \DateTimeImmutable $day, callable $test ): ?\DateTimeImmutable {
		for ( $i = 0; $i < self::HORIZON; $i++ ) {
			$day = $day->modify( '+1 day' );
			if ( $test( $day ) ) {
				return $day;
			}
		}
		return null;
	}
}
