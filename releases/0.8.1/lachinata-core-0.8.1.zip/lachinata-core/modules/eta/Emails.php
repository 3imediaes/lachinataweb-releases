<?php
/**
 * Delivery dates in the emails of the theme's frame.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Eta;

defined( 'ABSPATH' ) || exit;

/**
 * 06-correos.md: `eta` puts the estimated delivery in the key facts («Entrega estimada ·
 * jue 24 – vie 25 oct · Envío estándar · gratis»), next to the shipping line of the totals
 * and in the preheader of the confirmation; in the internal email, as «ETA» under the
 * shipping method. The shipped email («Llega») takes the dates saved with the order; the
 * shipment module recalculates them from the real dispatch day. Plain text emails keep the
 * sentence after the order table (Storefront::email()).
 */
final class Emails {

	/**
	 * Emails whose «Envío» fact becomes «Entrega estimada».
	 */
	private const BUYER = array( 'customer_processing_order', 'customer_on_hold_order', 'customer_invoice' );

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_filter( 'lachinata/email/facts', array( self::class, 'facts' ), 10, 3 );
		add_filter( 'lachinata/email/shipping_label', array( self::class, 'shipping_label' ), 10, 3 );
		add_filter( 'lachinata/email/intro', array( self::class, 'intro' ), 10, 2 );
		add_filter( 'lachinata/delivery/from_dispatch', array( self::class, 'from_dispatch' ), 10, 3 );
		add_filter( 'lachinata/email/pay_today', array( self::class, 'pay_today' ), 10, 2 );
	}

	/**
	 * An order still to pay (made by phone): when it arrives if it is paid now, with the
	 * method's plan, cut-off included («Si lo pagas hoy, llega jue 24 – vie 25 oct.»).
	 *
	 * @param mixed $text  Empty.
	 * @param mixed $order Order.
	 */
	public static function pay_today( $text, $order = null ): string {
		$line = $order instanceof \WC_Order ? current( $order->get_items( 'shipping' ) ) : false;
		if ( ! $order instanceof \WC_Order || ! $line instanceof \WC_Order_Item_Shipping ) {
			return (string) $text;
		}
		$country = $order->get_shipping_country() ? $order->get_shipping_country() : $order->get_billing_country();
		$zone    = \WC_Shipping_Zones::get_zone_matching_package(
			array(
				'destination' => array(
					'country'  => $country,
					'state'    => $order->get_shipping_state() ? $order->get_shipping_state() : $order->get_billing_state(),
					'postcode' => $order->get_shipping_postcode() ? $order->get_shipping_postcode() : $order->get_billing_postcode(),
				),
			)
		);
		$classes = array();
		foreach ( $order->get_items() as $item ) {
			$product = $item instanceof \WC_Order_Item_Product ? $item->get_product() : null;
			if ( $product instanceof \WC_Product && '' !== $product->get_shipping_class() ) {
				$classes[] = $product->get_shipping_class();
			}
		}
		$estimate = Estimator::for_instance( $zone, (int) $line->get_instance_id(), array_values( array_unique( $classes ) ), $country );
		/* translators: %s: delivery dates («jue 24 – vie 25 oct»). */
		return null === $estimate ? (string) $text : sprintf( __( 'Si lo pagas hoy, llega %s.', 'lachinata-core' ), Format::span( $estimate ) );
	}

	/**
	 * Delivery dates of an order that left on a given day (the tracking's date), as text,
	 * for modules that must not use this module's classes (shipment).
	 *
	 * @param mixed $dates   Null.
	 * @param mixed $order   Order.
	 * @param mixed $shipped Dispatch time (timestamp), null for today.
	 * @return array{span: string, between: string}|null «jue 24 – vie 25 oct» and «entre el jueves 24 y el viernes 25 de octubre».
	 */
	public static function from_dispatch( $dates, $order = null, $shipped = null ): ?array {
		if ( ! $order instanceof \WC_Order ) {
			return is_array( $dates ) ? $dates : null;
		}
		$zone     = wp_timezone();
		$ships    = is_numeric( $shipped ) && (int) $shipped > 0
			? ( new \DateTimeImmutable( '@' . (int) $shipped ) )->setTimezone( $zone )
			: new \DateTimeImmutable( 'now', $zone );
		$estimate = Rates::shipped( $order, $ships );
		return null === $estimate ? null : array(
			'span'    => Format::span( $estimate ),
			'between' => Format::between( $estimate ),
		);
	}

	/**
	 * Estimate of the order of an email, or null.
	 *
	 * @param mixed $order Order.
	 */
	private static function estimate( $order ): ?Estimate {
		return $order instanceof \WC_Order ? Rates::of_order( $order ) : null;
	}

	/**
	 * Key facts with the delivery dates.
	 *
	 * @param mixed $facts Facts.
	 * @param mixed $order Order.
	 * @param mixed $email Email.
	 * @return array<string, mixed>
	 */
	public static function facts( $facts, $order = null, $email = null ): array {
		$facts    = is_array( $facts ) ? $facts : array();
		$estimate = self::estimate( $order );
		if ( null === $estimate || ! $email instanceof \WC_Email ) {
			return $facts;
		}
		$span = Format::span( $estimate );
		if ( in_array( $email->id, self::BUYER, true ) && isset( $facts['delivery'] ) && is_array( $facts['delivery'] ) ) {
			$facts['delivery'] = array(
				'label' => __( 'Entrega estimada', 'lachinata-core' ),
				'value' => $span,
				/* translators: 1: shipping method, 2: shipping cost («gratis», «4,13 €»). */
				'note'  => sprintf( __( '%1$s · %2$s', 'lachinata-core' ), (string) $facts['delivery']['value'], self::lower_first( (string) ( $facts['delivery']['note'] ?? '' ) ) ),
			);
		} elseif ( 'customer_completed_order' === $email->id && ! isset( $facts['delivery'] ) ) {
			$facts = array(
				'delivery' => array(
					'label' => __( 'Llega', 'lachinata-core' ),
					'value' => $span,
					'note'  => '',
				),
			) + $facts;
		} elseif ( in_array( $email->id, array( 'new_order', 'cancelled_order', 'failed_order' ), true ) && isset( $facts['shipping'] ) && is_array( $facts['shipping'] ) ) {
			/* translators: %s: delivery dates («jue 24 – vie 25 oct»). */
			$facts['shipping']['note'] = sprintf( __( 'ETA %s', 'lachinata-core' ), $span );
		}
		return $facts;
	}

	/**
	 * «Envío estándar · jue 24 – vie 25 oct» in the totals.
	 *
	 * @param mixed $label Method name.
	 * @param mixed $line  Shipping line.
	 * @param mixed $order Order.
	 */
	public static function shipping_label( $label, $line = null, $order = null ): string {
		$label    = (string) $label;
		$estimate = self::estimate( $order );
		/* translators: 1: shipping method, 2: delivery dates. */
		return null === $estimate ? $label : sprintf( __( '%1$s · %2$s', 'lachinata-core' ), $label, Format::span( $estimate ) );
	}

	/**
	 * «Pedido 48213 confirmado · llega jue 24 – vie 25 oct» as the preheader.
	 *
	 * @param mixed $intro Intro.
	 * @param mixed $email Email.
	 * @return array<string, mixed>
	 */
	public static function intro( $intro, $email = null ): array {
		$intro = is_array( $intro ) ? $intro : array();
		if ( ! $email instanceof \WC_Email || 'customer_processing_order' !== $email->id || '' === (string) ( $intro['preheader'] ?? '' ) ) {
			return $intro;
		}
		$estimate = self::estimate( $email->object );
		if ( null !== $estimate ) {
			/* translators: 1: preheader («Pedido 48213 confirmado»), 2: delivery dates. */
			$intro['preheader'] = sprintf( __( '%1$s · llega %2$s', 'lachinata-core' ), (string) $intro['preheader'], Format::span( $estimate ) );
		}
		return $intro;
	}

	/**
	 * «Gratis» → «gratis» inside a note; prices stay as they are.
	 *
	 * @param string $text Text.
	 */
	private static function lower_first( string $text ): string {
		return '' === $text ? '' : mb_strtolower( mb_substr( $text, 0, 1 ) ) . mb_substr( $text, 1 );
	}
}
