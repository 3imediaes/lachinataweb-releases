<?php
/**
 * A delivery estimate.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Eta;

defined( 'ABSPATH' ) || exit;

/**
 * Dispatch date, earliest and latest delivery dates and, when ordering before a time
 * today changes the result, that cut-off.
 */
final class Estimate {

	/**
	 * Builds the estimate.
	 *
	 * @param \DateTimeImmutable      $ships  Dispatch date (midnight).
	 * @param \DateTimeImmutable      $min    Earliest delivery date (midnight).
	 * @param \DateTimeImmutable      $max    Latest delivery date (midnight).
	 * @param \DateTimeImmutable|null $cutoff Today's cut-off, when it matters.
	 */
	public function __construct(
		public readonly \DateTimeImmutable $ships,
		public readonly \DateTimeImmutable $min,
		public readonly \DateTimeImmutable $max,
		public readonly ?\DateTimeImmutable $cutoff = null,
	) {}

	/**
	 * Dates as stored on rates and orders: `{sale, llega_min, llega_max}` in Y-m-d.
	 *
	 * @return array{sale: string, llega_min: string, llega_max: string}
	 */
	public function to_meta(): array {
		return array(
			'sale'      => $this->ships->format( 'Y-m-d' ),
			'llega_min' => $this->min->format( 'Y-m-d' ),
			'llega_max' => $this->max->format( 'Y-m-d' ),
		);
	}

	/**
	 * Estimate from stored dates, or null.
	 *
	 * @param mixed         $meta Stored dates.
	 * @param \DateTimeZone $zone Time zone of the site.
	 */
	public static function from_meta( mixed $meta, \DateTimeZone $zone ): ?self {
		if ( ! is_array( $meta ) ) {
			return null;
		}
		$dates = array();
		foreach ( array( 'sale', 'llega_min', 'llega_max' ) as $key ) {
			$date = \DateTimeImmutable::createFromFormat( '!Y-m-d', (string) ( $meta[ $key ] ?? '' ), $zone );
			if ( false === $date ) {
				return null;
			}
			$dates[] = $date;
		}
		return new self( $dates[0], $dates[1], $dates[2] );
	}
}
