<?php
/**
 * Module `eta`: estimated delivery dates.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Eta;

use LaChinata\Core\Module;
use LaChinata\Core\Modules\Shipping\Config;

defined( 'ABSPATH' ) || exit;

/**
 * Replaces the Estimated Delivery Date plugin and keeps everything it could configure,
 * calculated per zone and method: cut-off per weekday, preparation, transit days per
 * instance, carriers with no-delivery days, warehouse and destination holidays and
 * conditions per shipping class. Without data for a zone and method it shows no date.
 */
final class EtaModule extends Module {

	/**
	 * Module id.
	 */
	public function id(): string {
		return 'eta';
	}

	/**
	 * Module name.
	 */
	public function label(): string {
		return __( 'Entrega estimada', 'lachinata-core' );
	}

	/**
	 * Module description.
	 */
	public function description(): string {
		return __( 'Fecha de entrega por zona y método en las opciones de envío, la ficha, la bolsa, la confirmación y los correos. Sustituye al plugin Estimated Delivery Date.', 'lachinata-core' );
	}

	/**
	 * Version in which the module was added.
	 */
	public function since(): string {
		return '0.4.0';
	}

	/**
	 * Documentation.
	 */
	public function docs(): string {
		return 'design-system/sistema/04-envios-entrega.md';
	}

	/**
	 * Requirements: zones, destinations and restrictions come from `shipping`.
	 *
	 * @return array{modules: string[], woocommerce: string}
	 */
	public function requires(): array {
		return array(
			'modules'     => array( 'shipping' ),
			'woocommerce' => '10.0',
		);
	}

	/**
	 * Registers the hooks.
	 */
	public function boot(): void {
		Rates::boot();
		Storefront::boot();
		Emails::boot();
		Rest::boot();
		add_filter( 'lachinata/shipping/simulation_eta', array( self::class, 'simulation' ), 10, 4 );

		if ( is_admin() ) {
			InstanceFields::boot();
			EtaTab::boot();
		}
	}

	/**
	 * Estimate in the shipping simulator.
	 *
	 * @param string                                   $text        Current text.
	 * @param int                                      $instance_id Instance id.
	 * @param \LaChinata\Core\Modules\Shipping\Package $package     Simulated package.
	 * @param \WC_Shipping_Zone                        $zone        Zone.
	 */
	public static function simulation( string $text, int $instance_id, \LaChinata\Core\Modules\Shipping\Package $package, \WC_Shipping_Zone $zone ): string {
		$estimate = Estimator::for_instance( $zone, $instance_id, $package->classes(), $package->country );
		return null === $estimate ? __( 'Sin plazo configurado', 'lachinata-core' ) : Format::range( $estimate );
	}

	/**
	 * Store configuration and the plan of each instance (by id).
	 *
	 * @return array<string, mixed>
	 */
	public function export_data(): array {
		$instances = array();
		foreach ( Config::instances() as $id => $instance ) {
			$settings = array_intersect_key( Config::instance_settings( $instance['method'] ), array_flip( Plan::KEYS ) );
			if ( $settings ) {
				$instances[ (string) $id ] = array(
					'method'   => $instance['method']->id,
					'settings' => $settings,
				);
			}
		}
		return array(
			'config'    => Estimator::config()->to_array(),
			'instances' => $instances,
		);
	}

	/**
	 * Checks an imported section: instances and reference methods must exist here.
	 *
	 * @param array<string, mixed> $data Section.
	 * @return string[]
	 */
	public function validate_data( array $data ): array {
		if ( isset( $data['config'] ) && ! is_array( $data['config'] ) ) {
			return array( __( 'Entrega estimada: «config» debe ser una lista.', 'lachinata-core' ) );
		}
		$errors    = array();
		$instances = Config::instances();
		foreach ( (array) ( $data['instances'] ?? array() ) as $id => $instance ) {
			$here = $instances[ (int) $id ]['method'] ?? null;
			if ( null === $here || ! is_array( $instance ) || ( $instance['method'] ?? '' ) !== $here->id ) {
				/* translators: %d: instance id. */
				$errors[] = sprintf( __( 'Entrega estimada: el método con ID %d no existe en este sitio o es de otro tipo.', 'lachinata-core' ), (int) $id );
			}
		}
		foreach ( (array) ( $data['config']['reference'] ?? array() ) as $zone_id => $instance_id ) {
			if ( ! isset( $instances[ (int) $instance_id ] ) || (int) $instances[ (int) $instance_id ]['zone']->get_id() !== (int) $zone_id ) {
				/* translators: 1: instance id, 2: zone id. */
				$errors[] = sprintf( __( 'Entrega estimada: el método de referencia %1$d no está en la zona %2$d de este sitio.', 'lachinata-core' ), (int) $instance_id, (int) $zone_id );
			}
		}
		return $errors;
	}

	/**
	 * Writes an imported section.
	 *
	 * @param array<string, mixed> $data Section that passed validate_data().
	 */
	public function import_data( array $data ): void {
		if ( isset( $data['config'] ) ) {
			Estimator::save( EtaConfig::from_array( (array) $data['config'] ) );
		}
		$instances = Config::instances();
		foreach ( (array) ( $data['instances'] ?? array() ) as $id => $instance ) {
			$method = $instances[ (int) $id ]['method'] ?? null;
			if ( null !== $method ) {
				$values = array_intersect_key( (array) ( $instance['settings'] ?? array() ), array_flip( Plan::KEYS ) );
				update_option( $method->get_instance_option_key(), array_merge( Config::instance_settings( $method ), $values ) );
			}
		}
		Estimator::reset();
		Config::changed();
	}
}
