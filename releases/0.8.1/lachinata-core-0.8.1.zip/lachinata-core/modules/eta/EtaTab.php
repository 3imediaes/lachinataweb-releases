<?php
/**
 * WooCommerce → La Chinata → Entrega estimada.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Eta;

use LaChinata\Core\Admin\Screen;
use LaChinata\Core\Modules\Shipping\Config;
use LaChinata\Core\Modules\Shipping\InstanceFields as ShippingFields;

defined( 'ABSPATH' ) || exit;

/**
 * Three sections: times (cut-off per weekday, preparation, carriers, conditions per
 * shipping class, reference method per zone), holidays (warehouse and per destination
 * country, by hand, from Nager.Date or from CSV) and gaps. The transit days of each
 * method are set in the method itself.
 */
final class EtaTab {

	/**
	 * Tab id.
	 */
	public const TAB = 'eta';

	/**
	 * Calendar id of the warehouse holidays.
	 */
	private const WAREHOUSE = 'warehouse';

	/**
	 * Actions of admin-post.php, also nonce actions.
	 */
	private const SAVE_TIMES    = 'lachinata_eta_times';
	private const SAVE_HOLIDAYS = 'lachinata_eta_holidays';
	private const NAGER_PREVIEW = 'lachinata_eta_nager_preview';
	private const NAGER_SAVE    = 'lachinata_eta_nager_save';
	private const CSV_IMPORT    = 'lachinata_eta_csv';
	private const CLEAR_GAPS    = 'lachinata_eta_clear_gaps';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_filter( 'lachinata/core/admin_tabs', array( self::class, 'tab' ), 20 );
		foreach ( array( self::SAVE_TIMES, self::SAVE_HOLIDAYS, self::NAGER_PREVIEW, self::NAGER_SAVE, self::CSV_IMPORT, self::CLEAR_GAPS ) as $action ) {
			add_action( 'admin_post_' . $action, array( self::class, 'handle' ) );
		}
	}

	/**
	 * Adds the tab after Envíos.
	 *
	 * @param array<string, array{label: string, render: callable}> $tabs Tabs.
	 * @return array<string, array{label: string, render: callable}>
	 */
	public static function tab( array $tabs ): array {
		$position = array_search( 'shipping', array_keys( $tabs ), true );
		$position = false === $position ? 1 : $position + 1;
		$tab      = array(
			self::TAB => array(
				'label'  => __( 'Entrega estimada', 'lachinata-core' ),
				'render' => array( self::class, 'render' ),
			),
		);
		return array_slice( $tabs, 0, $position, true ) + $tab + $tabs;
	}

	/**
	 * Prints the tab.
	 */
	public static function render(): void {
		$sections = array(
			'times'    => __( 'Cortes y plazos', 'lachinata-core' ),
			'holidays' => __( 'Festivos', 'lachinata-core' ),
			'gaps'     => __( 'Huecos de configuración', 'lachinata-core' ),
		);
		$current  = isset( $_GET['section'] ) ? sanitize_key( wp_unslash( $_GET['section'] ) ) : 'times'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Navigation only.
		$current  = isset( $sections[ $current ] ) ? $current : 'times';
		Screen::section_links( self::TAB, $sections, $current );

		match ( $current ) {
			'holidays' => self::render_holidays(),
			'gaps'     => self::render_gaps(),
			default    => self::render_times(),
		};
	}

	/**
	 * Weekday checkboxes.
	 *
	 * @param string $name    Field name (without []).
	 * @param int[]  $checked Checked weekdays.
	 * @param string $label   Accessible group label.
	 */
	private static function weekday_boxes( string $name, array $checked, string $label ): void {
		echo '<fieldset><legend class="screen-reader-text">' . esc_html( $label ) . '</legend>';
		foreach ( InstanceFields::weekdays() as $day => $day_name ) {
			printf(
				'<label class="lc-admin__check"><input type="checkbox" name="%1$s[]" value="%2$d"%3$s> %4$s</label>',
				esc_attr( $name ),
				(int) $day,
				checked( in_array( $day, $checked, true ), true, false ),
				esc_html( $day_name )
			);
		}
		echo '</fieldset>';
	}

	/**
	 * Times section.
	 */
	private static function render_times(): void {
		$config  = Estimator::config();
		$classes = ShippingFields::class_options();
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_TIMES ); ?>">
			<?php wp_nonce_field( self::SAVE_TIMES ); ?>

			<div class="lc-admin__card">
				<h2><?php esc_html_e( 'Salida del almacén', 'lachinata-core' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Un pedido que entra antes del corte se prepara ese día; después, el siguiente día con corte. Los días sin hora no hay salida.', 'lachinata-core' ); ?></p>
				<table class="form-table" role="presentation">
					<?php foreach ( InstanceFields::weekdays() as $day => $day_name ) : ?>
						<tr>
							<th scope="row"><label for="lc-cutoff-<?php echo esc_attr( (string) $day ); ?>"><?php echo esc_html( $day_name ); ?></label></th>
							<td><input type="time" id="lc-cutoff-<?php echo esc_attr( (string) $day ); ?>" name="cutoffs[<?php echo esc_attr( (string) $day ); ?>]" value="<?php echo esc_attr( (string) ( $config->cutoffs[ $day ] ?? '' ) ); ?>"> <span class="description"><?php esc_html_e( 'Hora de corte', 'lachinata-core' ); ?></span></td>
						</tr>
					<?php endforeach; ?>
					<tr>
						<th scope="row"><label for="lc-prep"><?php esc_html_e( 'Días de preparación', 'lachinata-core' ); ?></label></th>
						<td><input type="number" min="0" step="1" class="small-text" id="lc-prep" name="prep_days" value="<?php echo esc_attr( (string) $config->prep_days ); ?>"> <span class="description"><?php esc_html_e( 'Días con salida entre que se acepta el pedido y sale. 0: sale el mismo día del corte.', 'lachinata-core' ); ?></span></td>
					</tr>
				</table>
			</div>

			<div class="lc-admin__card">
				<h2><?php esc_html_e( 'Transportistas', 'lachinata-core' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Cada método elige su transportista en WooCommerce → Ajustes → Envío y hereda sus días sin entrega.', 'lachinata-core' ); ?></p>
				<table class="widefat striped">
					<thead><tr><th scope="col"><?php esc_html_e( 'Nombre', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Días sin entrega', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Quitar', 'lachinata-core' ); ?></th></tr></thead>
					<tbody>
						<?php foreach ( array_merge( $config->carriers, array( '' => null ) ) as $key => $carrier ) : ?>
							<?php $row = 'carriers[' . ( '' === $key ? '__new' : $key ) . ']'; ?>
							<tr>
								<td><input type="text" name="<?php echo esc_attr( $row ); ?>[name]" value="<?php echo esc_attr( null === $carrier ? '' : $carrier['name'] ); ?>" placeholder="<?php esc_attr_e( 'Añadir un transportista…', 'lachinata-core' ); ?>" aria-label="<?php esc_attr_e( 'Nombre', 'lachinata-core' ); ?>"></td>
								<td><?php self::weekday_boxes( $row . '[no_delivery]', null === $carrier ? array( 6, 7 ) : $carrier['no_delivery'], __( 'Días sin entrega', 'lachinata-core' ) ); ?></td>
								<td>
								<?php
								if ( null !== $carrier ) :
									?>
									<input type="checkbox" name="<?php echo esc_attr( $row ); ?>[delete]" value="1" aria-label="<?php esc_attr_e( 'Quitar', 'lachinata-core' ); ?>"><?php endif; ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>

			<div class="lc-admin__card">
				<h2><?php esc_html_e( 'Condiciones por clase de envío', 'lachinata-core' ); ?></h2>
				<p class="description"><?php esc_html_e( 'La clase añade días de preparación o restringe los días de salida o de entrega; nunca cambia el método. Con varias clases en el pedido, se suman las restricciones: más días extra, el corte más temprano y solo los días que permiten todas. Sin días marcados: todos.', 'lachinata-core' ); ?></p>
				<table class="widefat striped">
					<thead>
						<tr>
							<th scope="col"><?php esc_html_e( 'Clase', 'lachinata-core' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Días extra', 'lachinata-core' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Corte propio', 'lachinata-core' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Sale solo', 'lachinata-core' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Se entrega solo', 'lachinata-core' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Quitar', 'lachinata-core' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php $index = 0; ?>
						<?php foreach ( array_merge( $config->classes, array( '' => null ) ) as $slug => $rule ) : ?>
							<?php $row = 'classes[' . ( $index++ ) . ']'; ?>
							<tr>
								<td>
									<select name="<?php echo esc_attr( $row ); ?>[class]" aria-label="<?php esc_attr_e( 'Clase', 'lachinata-core' ); ?>">
										<option value=""><?php echo esc_html( null === $rule ? __( 'Añadir una clase…', 'lachinata-core' ) : '—' ); ?></option>
										<?php foreach ( $classes + ( '' === $slug || isset( $classes[ $slug ] ) ? array() : array( $slug => $slug ) ) as $value => $name ) : ?>
											<option value="<?php echo esc_attr( (string) $value ); ?>"<?php selected( (string) $slug, (string) $value ); ?>><?php echo esc_html( $name ); ?></option>
										<?php endforeach; ?>
									</select>
								</td>
								<td><input type="number" min="0" step="1" class="small-text" name="<?php echo esc_attr( $row ); ?>[extra_days]" value="<?php echo esc_attr( null === $rule ? '' : (string) $rule['extra_days'] ); ?>" aria-label="<?php esc_attr_e( 'Días extra', 'lachinata-core' ); ?>"></td>
								<td><input type="time" name="<?php echo esc_attr( $row ); ?>[cutoff]" value="<?php echo esc_attr( (string) ( $rule['cutoff'] ?? '' ) ); ?>" aria-label="<?php esc_attr_e( 'Corte propio', 'lachinata-core' ); ?>"></td>
								<td><?php self::weekday_boxes( $row . '[ship_days]', $rule['ship_days'] ?? array(), __( 'Sale solo', 'lachinata-core' ) ); ?></td>
								<td><?php self::weekday_boxes( $row . '[delivery_days]', $rule['delivery_days'] ?? array(), __( 'Se entrega solo', 'lachinata-core' ) ); ?></td>
								<td>
								<?php
								if ( null !== $rule ) :
									?>
									<input type="checkbox" name="<?php echo esc_attr( $row ); ?>[delete]" value="1" aria-label="<?php esc_attr_e( 'Quitar', 'lachinata-core' ); ?>"><?php endif; ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>

			<div class="lc-admin__card">
				<h2><?php esc_html_e( 'Método de referencia por zona', 'lachinata-core' ); ?></h2>
				<p class="description"><?php esc_html_e( 'El que da la fecha de la ficha de producto («Pídelo antes de las 16:00 y lo recibes el jueves 24»). Normalmente, el estándar de la zona.', 'lachinata-core' ); ?></p>
				<table class="form-table" role="presentation">
					<?php foreach ( Config::zones() as $zone_id => $zone ) : ?>
						<?php
						$methods = $zone->get_shipping_methods();
						if ( ! $methods ) {
							continue;
						}
						?>
						<tr>
							<th scope="row"><label for="lc-reference-<?php echo esc_attr( (string) $zone_id ); ?>"><?php echo esc_html( (string) $zone->get_zone_name() ); ?></label></th>
							<td>
								<select id="lc-reference-<?php echo esc_attr( (string) $zone_id ); ?>" name="reference[<?php echo esc_attr( (string) $zone_id ); ?>]">
									<option value=""><?php esc_html_e( 'Sin fecha en la ficha', 'lachinata-core' ); ?></option>
									<?php foreach ( $methods as $instance_id => $method ) : ?>
										<option value="<?php echo esc_attr( (string) $instance_id ); ?>"<?php selected( $config->reference[ $zone_id ] ?? 0, (int) $instance_id ); ?>>
											<?php
											/* translators: 1: method title, 2: instance id. */
											echo esc_html( sprintf( __( '%1$s (ID %2$d)', 'lachinata-core' ), $method->get_title(), $instance_id ) );
											?>
										</option>
									<?php endforeach; ?>
								</select>
							</td>
						</tr>
					<?php endforeach; ?>
				</table>
			</div>
			<?php submit_button( __( 'Guardar cortes y plazos', 'lachinata-core' ) ); ?>
		</form>
		<?php
	}

	/**
	 * Holidays section.
	 */
	private static function render_holidays(): void {
		$config   = Estimator::config();
		$calendar = isset( $_GET['calendar'] ) ? strtoupper( sanitize_key( wp_unslash( $_GET['calendar'] ) ) ) : strtoupper( self::WAREHOUSE ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Navigation only.
		$calendar = strtoupper( self::WAREHOUSE ) === $calendar || 1 !== preg_match( '/^[A-Z]{2}$/', $calendar ) ? self::WAREHOUSE : $calendar;
		$dates    = self::WAREHOUSE === $calendar ? $config->warehouse_holidays : ( $config->country_holidays[ $calendar ] ?? array() );
		$country  = self::WAREHOUSE === $calendar ? (string) wc_get_base_location()['country'] : $calendar;
		$names    = WC()->countries->get_countries();
		$preview  = get_transient( self::preview_key() );
		$year     = (int) wp_date( 'Y' );
		?>
		<p><?php esc_html_e( 'Festivos del almacén: no se prepara ni sale nada. Festivos de un país de destino: no se entrega allí. Los importados se editan y se borran como los demás.', 'lachinata-core' ); ?></p>
		<ul class="subsubsub">
			<li><a href="<?php echo esc_url( self::calendar_url( self::WAREHOUSE ) ); ?>"<?php echo self::WAREHOUSE === $calendar ? ' class="current" aria-current="page"' : ''; ?>><?php esc_html_e( 'Almacén', 'lachinata-core' ); ?></a></li>
			<?php foreach ( array_keys( $config->country_holidays ) as $code ) : ?>
				<li> | <a href="<?php echo esc_url( self::calendar_url( $code ) ); ?>"<?php echo $code === $calendar ? ' class="current" aria-current="page"' : ''; ?>><?php echo esc_html( html_entity_decode( (string) ( $names[ $code ] ?? $code ) ) ); ?></a></li>
			<?php endforeach; ?>
		</ul>
		<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="alignright">
			<input type="hidden" name="page" value="<?php echo esc_attr( Screen::SLUG ); ?>">
			<input type="hidden" name="tab" value="<?php echo esc_attr( self::TAB ); ?>">
			<input type="hidden" name="section" value="holidays">
			<label for="lc-calendar"><?php esc_html_e( 'Festivos de entrega en', 'lachinata-core' ); ?></label>
			<select id="lc-calendar" name="calendar" class="wc-enhanced-select" style="min-width:14em">
				<?php foreach ( WC()->countries->get_shipping_countries() as $code => $name ) : ?>
					<option value="<?php echo esc_attr( strtolower( (string) $code ) ); ?>"<?php selected( $calendar, $code ); ?>><?php echo esc_html( html_entity_decode( (string) $name ) ); ?></option>
				<?php endforeach; ?>
			</select>
			<?php submit_button( __( 'Abrir', 'lachinata-core' ), 'secondary', '', false ); ?>
		</form>
		<br class="clear">

		<h2>
			<?php
			echo esc_html(
				self::WAREHOUSE === $calendar
					? __( 'Festivos del almacén', 'lachinata-core' )
					/* translators: %s: country name. */
					: sprintf( __( 'Festivos de entrega en %s', 'lachinata-core' ), html_entity_decode( (string) ( $names[ $calendar ] ?? $calendar ) ) )
			);
			?>
		</h2>

		<?php if ( is_array( $preview ) && ( $preview['calendar'] ?? '' ) === $calendar ) : ?>
			<?php self::render_preview( $preview ); ?>
		<?php endif; ?>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE_HOLIDAYS ); ?>">
			<input type="hidden" name="calendar" value="<?php echo esc_attr( $calendar ); ?>">
			<?php wp_nonce_field( self::SAVE_HOLIDAYS ); ?>
			<table class="widefat striped lc-admin__holidays">
				<thead><tr><th scope="col"><?php esc_html_e( 'Fecha', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Nombre', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Quitar', 'lachinata-core' ); ?></th></tr></thead>
				<tbody>
					<?php foreach ( $dates as $date => $name ) : ?>
						<tr>
							<td><?php echo esc_html( wp_date( (string) get_option( 'date_format' ), (int) strtotime( $date . ' 12:00:00' ) ) ); ?> <code><?php echo esc_html( $date ); ?></code></td>
							<td><input type="text" class="regular-text" name="names[<?php echo esc_attr( $date ); ?>]" value="<?php echo esc_attr( $name ); ?>" aria-label="<?php esc_attr_e( 'Nombre', 'lachinata-core' ); ?>"></td>
							<td><input type="checkbox" name="delete[]" value="<?php echo esc_attr( $date ); ?>" aria-label="<?php esc_attr_e( 'Quitar', 'lachinata-core' ); ?>"></td>
						</tr>
					<?php endforeach; ?>
					<tr>
						<td><input type="date" name="new_date" aria-label="<?php esc_attr_e( 'Fecha nueva', 'lachinata-core' ); ?>"></td>
						<td><input type="text" class="regular-text" name="new_name" placeholder="<?php esc_attr_e( 'Añadir un festivo…', 'lachinata-core' ); ?>" aria-label="<?php esc_attr_e( 'Nombre del festivo nuevo', 'lachinata-core' ); ?>"></td>
						<td></td>
					</tr>
				</tbody>
			</table>
			<?php submit_button( __( 'Guardar festivos', 'lachinata-core' ) ); ?>
		</form>

		<div class="lc-admin__card">
			<h3>
				<?php
				/* translators: %s: country name. */
				echo esc_html( sprintf( __( 'Importar festivos nacionales de %s', 'lachinata-core' ), html_entity_decode( (string) ( $names[ $country ] ?? $country ) ) ) );
				?>
			</h3>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::NAGER_PREVIEW ); ?>">
				<input type="hidden" name="calendar" value="<?php echo esc_attr( $calendar ); ?>">
				<?php wp_nonce_field( self::NAGER_PREVIEW ); ?>
				<label for="lc-nager-year"><?php esc_html_e( 'Año', 'lachinata-core' ); ?></label>
				<input type="number" id="lc-nager-year" name="year" class="small-text" min="2020" max="2100" value="<?php echo esc_attr( (string) $year ); ?>">
				<?php submit_button( __( 'Ver festivos', 'lachinata-core' ), 'secondary', '', false ); ?>
				<p class="description"><?php esc_html_e( 'Se consultan en Nager.Date (date.nager.at) y se muestran antes de guardar. Los regionales salen sin marcar.', 'lachinata-core' ); ?></p>
			</form>
		</div>

		<div class="lc-admin__card">
			<h3><?php esc_html_e( 'Importar festivos locales (CSV)', 'lachinata-core' ); ?></h3>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::CSV_IMPORT ); ?>">
				<input type="hidden" name="calendar" value="<?php echo esc_attr( $calendar ); ?>">
				<?php wp_nonce_field( self::CSV_IMPORT ); ?>
				<label for="lc-csv" class="screen-reader-text"><?php esc_html_e( 'Festivos en CSV', 'lachinata-core' ); ?></label>
				<textarea id="lc-csv" name="csv" rows="5" class="large-text code" placeholder="2026-09-08;Día de Extremadura&#10;15/05/2026;San Isidro"></textarea>
				<p class="description"><?php esc_html_e( 'Una línea por festivo: fecha;nombre. Fechas 2026-09-08 o 08/09/2026.', 'lachinata-core' ); ?></p>
				<?php submit_button( __( 'Importar', 'lachinata-core' ), 'secondary', '', false ); ?>
			</form>
		</div>
		<?php
	}

	/**
	 * Preview of a Nager.Date import.
	 *
	 * @param array{calendar: string, country: string, year: int, list: array<int, array{date: string, name: string, regions: string[]}>} $preview Preview.
	 */
	private static function render_preview( array $preview ): void {
		?>
		<div class="lc-admin__card lc-admin__preview">
			<h3>
				<?php
				/* translators: 1: country code, 2: year. */
				echo esc_html( sprintf( __( 'Festivos de %1$s en %2$d (Nager.Date): elige cuáles guardar', 'lachinata-core' ), $preview['country'], $preview['year'] ) );
				?>
			</h3>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::NAGER_SAVE ); ?>">
				<input type="hidden" name="calendar" value="<?php echo esc_attr( $preview['calendar'] ); ?>">
				<?php wp_nonce_field( self::NAGER_SAVE ); ?>
				<table class="widefat striped">
					<thead><tr><th scope="col"><?php esc_html_e( 'Guardar', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Fecha', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Nombre', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Ámbito', 'lachinata-core' ); ?></th></tr></thead>
					<tbody>
						<?php foreach ( $preview['list'] as $index => $holiday ) : ?>
							<tr>
								<td><input type="checkbox" name="pick[]" value="<?php echo esc_attr( (string) $index ); ?>"<?php checked( ! $holiday['regions'] ); ?> aria-label="<?php echo esc_attr( $holiday['name'] ); ?>"></td>
								<td><code><?php echo esc_html( $holiday['date'] ); ?></code></td>
								<td><?php echo esc_html( $holiday['name'] ); ?></td>
								<td><?php echo esc_html( $holiday['regions'] ? implode( ', ', $holiday['regions'] ) : __( 'Nacional', 'lachinata-core' ) ); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<p>
					<?php submit_button( __( 'Guardar los marcados', 'lachinata-core' ), 'primary', 'save', false ); ?>
					<?php submit_button( __( 'Descartar', 'lachinata-core' ), 'secondary', 'discard', false ); ?>
				</p>
			</form>
		</div>
		<?php
	}

	/**
	 * Gaps section.
	 */
	private static function render_gaps(): void {
		$lines = self::static_gaps();
		$log   = Estimator::gaps()->all();
		?>
		<h2><?php esc_html_e( 'Revisión de la configuración', 'lachinata-core' ); ?></h2>
		<?php if ( $lines ) : ?>
			<ul class="ul-disc">
				<?php foreach ( $lines as $line ) : ?>
					<li><?php echo esc_html( $line ); ?></li>
				<?php endforeach; ?>
			</ul>
		<?php else : ?>
			<p><?php esc_html_e( 'Todos los métodos activos tienen plazo y cada zona su método de referencia.', 'lachinata-core' ); ?></p>
		<?php endif; ?>

		<h2><?php esc_html_e( 'Fechas que no se pudieron calcular', 'lachinata-core' ); ?></h2>
		<p class="description"><?php esc_html_e( 'Cuando falta un dato, no se muestra fecha (nunca se inventa) y queda anotado aquí y en WooCommerce → Estado → Registros (lachinata-eta).', 'lachinata-core' ); ?></p>
		<?php if ( $log ) : ?>
			<table class="widefat striped">
				<thead><tr><th scope="col"><?php esc_html_e( 'Qué pasó', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Veces', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Última', 'lachinata-core' ); ?></th></tr></thead>
				<tbody>
					<?php foreach ( $log as $entry ) : ?>
						<tr>
							<td><?php echo esc_html( $entry['message'] ); ?></td>
							<td><?php echo esc_html( number_format_i18n( $entry['count'] ) ); ?></td>
							<td><?php echo esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $entry['last'] ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::CLEAR_GAPS ); ?>">
				<?php wp_nonce_field( self::CLEAR_GAPS ); ?>
				<?php submit_button( __( 'Vaciar la lista', 'lachinata-core' ), 'secondary' ); ?>
			</form>
		<?php else : ?>
			<p><?php esc_html_e( 'Ninguna registrada.', 'lachinata-core' ); ?></p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Problems visible from the configuration alone.
	 *
	 * @return string[]
	 */
	public static function static_gaps(): array {
		$config = Estimator::config();
		$lines  = array();
		if ( ! array_filter( $config->cutoffs ) ) {
			$lines[] = __( 'Ningún día tiene hora de corte: no hay salidas y no se calcula ninguna fecha.', 'lachinata-core' );
		}
		foreach ( Config::zones() as $zone_id => $zone ) {
			$methods = $zone->get_shipping_methods( true );
			if ( $methods && empty( $config->reference[ $zone_id ] ) ) {
				/* translators: %s: zone name. */
				$lines[] = sprintf( __( 'La zona «%s» no tiene método de referencia: la ficha no muestra fecha para ella.', 'lachinata-core' ), $zone->get_zone_name() );
			}
			foreach ( $methods as $instance_id => $method ) {
				$plan = Estimator::plan( $method );
				if ( null === $plan ) {
					/* translators: 1: method title, 2: instance id, 3: zone name. */
					$lines[] = sprintf( __( '%1$s (ID %2$d) no tiene plazo en la zona «%3$s».', 'lachinata-core' ), $method->get_title(), $instance_id, $zone->get_zone_name() );
				} elseif ( '' !== $plan->carrier && ! isset( $config->carriers[ $plan->carrier ] ) ) {
					/* translators: 1: method title, 2: instance id. */
					$lines[] = sprintf( __( '%1$s (ID %2$d) usa un transportista que ya no existe.', 'lachinata-core' ), $method->get_title(), $instance_id );
				}
			}
		}
		return $lines;
	}

	/**
	 * Handles every form of the tab.
	 */
	public static function handle(): void {
		$action = isset( $_POST['action'] ) ? sanitize_key( wp_unslash( $_POST['action'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Checked right below.
		Screen::check( $action );
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Screen::check().
		$calendar = isset( $_POST['calendar'] ) ? sanitize_key( wp_unslash( $_POST['calendar'] ) ) : self::WAREHOUSE;
		$calendar = self::WAREHOUSE === $calendar ? $calendar : strtoupper( substr( $calendar, 0, 2 ) );
		$config   = Estimator::config();
		$section  = 'holidays';

		switch ( $action ) {
			case self::SAVE_TIMES:
				Estimator::save( self::posted_times( $config ) );
				Screen::flash( 'success', array( __( 'Cortes y plazos guardados.', 'lachinata-core' ) ) );
				$section = 'times';
				break;

			case self::SAVE_HOLIDAYS:
				$dates = self::calendar( $config, $calendar );
				$names = isset( $_POST['names'] ) && is_array( $_POST['names'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['names'] ) ) : array();
				foreach ( $names as $date => $name ) {
					if ( isset( $dates[ $date ] ) ) {
						$dates[ $date ] = $name;
					}
				}
				foreach ( isset( $_POST['delete'] ) ? array_map( 'sanitize_text_field', (array) wp_unslash( $_POST['delete'] ) ) : array() as $date ) {
					unset( $dates[ $date ] );
				}
				$new = Holidays::date( isset( $_POST['new_date'] ) ? sanitize_text_field( wp_unslash( $_POST['new_date'] ) ) : '' );
				if ( null !== $new ) {
					$dates[ $new ] = isset( $_POST['new_name'] ) ? sanitize_text_field( wp_unslash( $_POST['new_name'] ) ) : '';
				}
				Estimator::save( self::with_calendar( $config, $calendar, $dates ) );
				Screen::flash( 'success', array( __( 'Festivos guardados.', 'lachinata-core' ) ) );
				break;

			case self::NAGER_PREVIEW:
				$year    = isset( $_POST['year'] ) ? absint( $_POST['year'] ) : (int) wp_date( 'Y' );
				$country = self::WAREHOUSE === $calendar ? (string) wc_get_base_location()['country'] : $calendar;
				$list    = Holidays::fetch( $country, $year );
				if ( is_wp_error( $list ) ) {
					Screen::flash( 'error', array( $list->get_error_message() ) );
					break;
				}
				set_transient(
					self::preview_key(),
					array(
						'calendar' => $calendar,
						'country'  => $country,
						'year'     => $year,
						'list'     => $list,
					),
					HOUR_IN_SECONDS
				);
				break;

			case self::NAGER_SAVE:
				$preview = get_transient( self::preview_key() );
				delete_transient( self::preview_key() );
				if ( ! isset( $_POST['save'] ) || ! is_array( $preview ) || ( $preview['calendar'] ?? '' ) !== $calendar ) {
					break;
				}
				$dates = self::calendar( $config, $calendar );
				$count = 0;
				foreach ( isset( $_POST['pick'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['pick'] ) ) : array() as $index ) {
					$holiday = $preview['list'][ $index ] ?? null;
					if ( is_array( $holiday ) ) {
						$dates[ $holiday['date'] ] = $holiday['name'];
						++$count;
					}
				}
				Estimator::save( self::with_calendar( $config, $calendar, $dates ) );
				/* translators: %d: number of holidays. */
				Screen::flash( 'success', array( sprintf( _n( '%d festivo guardado.', '%d festivos guardados.', $count, 'lachinata-core' ), $count ) ) );
				break;

			case self::CSV_IMPORT:
				$parsed = Holidays::parse_csv( isset( $_POST['csv'] ) ? sanitize_textarea_field( wp_unslash( $_POST['csv'] ) ) : '' );
				Estimator::save( self::with_calendar( $config, $calendar, array_merge( self::calendar( $config, $calendar ), $parsed['dates'] ) ) );
				/* translators: %d: number of holidays. */
				$messages = array( sprintf( _n( '%d festivo importado.', '%d festivos importados.', count( $parsed['dates'] ), 'lachinata-core' ), count( $parsed['dates'] ) ) );
				if ( $parsed['errors'] ) {
					/* translators: %s: line numbers. */
					$messages[] = sprintf( __( 'Líneas que no se entienden: %s.', 'lachinata-core' ), implode( ', ', $parsed['errors'] ) );
				}
				Screen::flash( $parsed['errors'] ? 'warning' : 'success', $messages );
				break;

			case self::CLEAR_GAPS:
				Estimator::gaps()->clear();
				Screen::flash( 'success', array( __( 'Lista vaciada.', 'lachinata-core' ) ) );
				$section = 'gaps';
				break;
		}
		// phpcs:enable
		Screen::redirect(
			self::TAB,
			array(
				'section'  => $section,
				'calendar' => strtolower( $calendar ),
			)
		);
	}

	/**
	 * Times section from the posted form.
	 *
	 * @param EtaConfig $config Current configuration.
	 */
	private static function posted_times( EtaConfig $config ): EtaConfig {
		// phpcs:disable WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Screen::check() in handle(); values sanitised by EtaConfig.
		$cutoffs = isset( $_POST['cutoffs'] ) && is_array( $_POST['cutoffs'] ) ? array_map( 'sanitize_text_field', wp_unslash( $_POST['cutoffs'] ) ) : array();

		$carriers = array();
		foreach ( isset( $_POST['carriers'] ) && is_array( $_POST['carriers'] ) ? wp_unslash( $_POST['carriers'] ) : array() as $key => $carrier ) {
			$name = sanitize_text_field( (string) ( $carrier['name'] ?? '' ) );
			if ( ! empty( $carrier['delete'] ) || '' === $name ) {
				continue;
			}
			$key              = '__new' === $key ? self::unique_key( sanitize_title( $name ), $carriers + $config->carriers ) : sanitize_key( (string) $key );
			$carriers[ $key ] = array(
				'name'        => $name,
				'no_delivery' => EtaConfig::days( $carrier['no_delivery'] ?? array() ),
			);
		}

		$classes = array();
		foreach ( isset( $_POST['classes'] ) && is_array( $_POST['classes'] ) ? wp_unslash( $_POST['classes'] ) : array() as $row ) {
			$slug = sanitize_title( (string) ( $row['class'] ?? '' ) );
			if ( '' === $slug || ! empty( $row['delete'] ) ) {
				continue;
			}
			$classes[ $slug ] = array(
				'extra_days'    => absint( $row['extra_days'] ?? 0 ),
				'cutoff'        => EtaConfig::time( sanitize_text_field( (string) ( $row['cutoff'] ?? '' ) ) ),
				'ship_days'     => EtaConfig::days( $row['ship_days'] ?? array() ),
				'delivery_days' => EtaConfig::days( $row['delivery_days'] ?? array() ),
			);
		}

		$reference = array_map( 'absint', isset( $_POST['reference'] ) && is_array( $_POST['reference'] ) ? wp_unslash( $_POST['reference'] ) : array() );
		$prep      = isset( $_POST['prep_days'] ) ? absint( $_POST['prep_days'] ) : 0;
		// phpcs:enable

		$stored = EtaConfig::from_array(
			array(
				'cutoffs'   => $cutoffs,
				'prep_days' => $prep,
				'classes'   => $classes,
				'carriers'  => $carriers,
				'reference' => $reference,
			)
		);
		return $config->with(
			array(
				'cutoffs'   => $stored->cutoffs,
				'prep_days' => $stored->prep_days,
				'classes'   => $stored->classes,
				'carriers'  => $stored->carriers,
				'reference' => $stored->reference,
			)
		);
	}

	/**
	 * Key not used yet («dhl», «dhl-2»…).
	 *
	 * @param string               $base  Wanted key.
	 * @param array<string, mixed> $taken Keys in use.
	 */
	private static function unique_key( string $base, array $taken ): string {
		$base = '' === $base ? 'transportista' : $base;
		$key  = $base;
		for ( $i = 2; isset( $taken[ $key ] ); $i++ ) {
			$key = $base . '-' . $i;
		}
		return $key;
	}

	/**
	 * Dates of a calendar.
	 *
	 * @param EtaConfig $config   Configuration.
	 * @param string    $calendar Calendar id.
	 * @return array<string, string>
	 */
	private static function calendar( EtaConfig $config, string $calendar ): array {
		return self::WAREHOUSE === $calendar ? $config->warehouse_holidays : ( $config->country_holidays[ $calendar ] ?? array() );
	}

	/**
	 * Configuration with a calendar replaced (an empty country calendar is removed).
	 *
	 * @param EtaConfig             $config   Configuration.
	 * @param string                $calendar Calendar id.
	 * @param array<string, string> $dates    Dates.
	 */
	private static function with_calendar( EtaConfig $config, string $calendar, array $dates ): EtaConfig {
		ksort( $dates );
		if ( self::WAREHOUSE === $calendar ) {
			return $config->with( array( 'warehouse_holidays' => $dates ) );
		}
		$countries = $config->country_holidays;
		if ( $dates ) {
			$countries[ $calendar ] = $dates;
		} else {
			unset( $countries[ $calendar ] );
		}
		ksort( $countries );
		return $config->with( array( 'country_holidays' => $countries ) );
	}

	/**
	 * URL of a calendar.
	 *
	 * @param string $calendar Calendar id.
	 */
	private static function calendar_url( string $calendar ): string {
		return Screen::url(
			self::TAB,
			array(
				'section'  => 'holidays',
				'calendar' => strtolower( $calendar ),
			)
		);
	}

	/**
	 * Transient with the current user's import preview.
	 */
	private static function preview_key(): string {
		return 'lachinata_eta_preview_' . get_current_user_id();
	}
}
