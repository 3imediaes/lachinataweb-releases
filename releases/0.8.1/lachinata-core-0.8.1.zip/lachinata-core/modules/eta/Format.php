<?php
/**
 * Delivery estimates as text.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Eta;

defined( 'ABSPATH' ) || exit;

/**
 * Three forms: the range of a shipping option («Llega jue 24 – vie 25 oct»), the sentence
 * of the product page («Pídelo antes de las 16:00 y lo recibes el jueves 24») and the
 * line of the order («Llega entre el jueves 24 y el viernes 25 de octubre»). Dates with
 * wp_date() and translatable formats.
 *
 * Day and month abbreviations are the module's own translatable strings, lowercase in the
 * source language as the design system writes them («jue», «oct»), instead of the
 * WordPress locale's («Jue», «Oct» in es_ES): each language decides its own case.
 */
final class Format {

	/**
	 * Range for a shipping option or the bag.
	 *
	 * @param Estimate $estimate Estimate.
	 */
	public static function range( Estimate $estimate ): string {
		/* translators: date format of a delivery day with month (PHP date()): «vie 25 oct». */
		$with_month = _x( 'D j M', 'delivery range end', 'lachinata-core' );
		if ( $estimate->min == $estimate->max ) { // phpcs:ignore Universal.Operators.StrictComparisons.LooseEqual -- Same date, different objects.
			/* translators: %s: delivery date. */
			return sprintf( __( 'Llega %s', 'lachinata-core' ), self::date( $estimate->min, $with_month ) );
		}
		$same_month = $estimate->min->format( 'Y-m' ) === $estimate->max->format( 'Y-m' );
		return sprintf(
			/* translators: 1: earliest delivery date, 2: latest delivery date. */
			__( 'Llega %1$s – %2$s', 'lachinata-core' ),
			/* translators: date format of a delivery day without month (PHP date()): «jue 24». */
			self::date( $estimate->min, $same_month ? _x( 'D j', 'delivery range start', 'lachinata-core' ) : $with_month ),
			self::date( $estimate->max, $with_month )
		);
	}

	/**
	 * Short range without the verb, for an SMS: «jue 24 – vie 25 oct», «vie 30 oct – lun 2 nov»
	 * or «jue 24 oct».
	 *
	 * @param Estimate $estimate Estimate.
	 */
	public static function span( Estimate $estimate ): string {
		/* translators: date format of a delivery day with month (PHP date()): «vie 25 oct». */
		$with_month = _x( 'D j M', 'delivery range end', 'lachinata-core' );
		if ( $estimate->min == $estimate->max ) { // phpcs:ignore Universal.Operators.StrictComparisons.LooseEqual -- Same date, different objects.
			return self::date( $estimate->min, $with_month );
		}
		$same_month = $estimate->min->format( 'Y-m' ) === $estimate->max->format( 'Y-m' );
		return sprintf(
			/* translators: 1: earliest delivery date, 2: latest delivery date. */
			__( '%1$s – %2$s', 'lachinata-core' ),
			self::date( $estimate->min, $same_month ? _x( 'D j', 'delivery range start', 'lachinata-core' ) : $with_month ),
			self::date( $estimate->max, $with_month )
		);
	}

	/**
	 * Range inside a sentence: «entre el jueves 24 y el viernes 25 de octubre», or «el jueves 24
	 * de octubre» when both days are the same.
	 *
	 * @param Estimate $estimate Estimate.
	 */
	public static function between( Estimate $estimate ): string {
		/* translators: date format of the order line (PHP date()): «jueves 24 de octubre». */
		$long = _x( 'l j \d\e F', 'order delivery date', 'lachinata-core' );
		if ( $estimate->min == $estimate->max ) { // phpcs:ignore Universal.Operators.StrictComparisons.LooseEqual -- Same date, different objects.
			/* translators: %s: delivery date («jueves 24 de octubre»). */
			return sprintf( __( 'el %s', 'lachinata-core' ), self::date( $estimate->min, $long ) );
		}
		$same_month = $estimate->min->format( 'Y-m' ) === $estimate->max->format( 'Y-m' );
		return sprintf(
			/* translators: 1: earliest delivery date («jueves 24»), 2: latest delivery date («viernes 25 de octubre»). */
			__( 'entre el %1$s y el %2$s', 'lachinata-core' ),
			/* translators: date format of the first day of a delivery range in the same month (PHP date()): «jueves 24». */
			self::date( $estimate->min, $same_month ? _x( 'l j', 'delivery range start in a sentence', 'lachinata-core' ) : $long ),
			self::date( $estimate->max, $long )
		);
	}

	/**
	 * Sentence of the product page, without countdown. «Hoy» only makes sense before the
	 * cut-off, and then the cut-off itself is the sentence; past it, «ahora».
	 *
	 * @param Estimate $estimate Estimate.
	 */
	public static function product( Estimate $estimate ): string {
		$day = self::long_day( $estimate->min );
		if ( null !== $estimate->cutoff ) {
			/* translators: 1: cut-off time today, 2: delivery day («jueves 24»). */
			return sprintf( __( 'Pídelo antes de las %1$s y lo recibes el %2$s.', 'lachinata-core' ), wp_date( (string) get_option( 'time_format' ), $estimate->cutoff->getTimestamp() ), $day );
		}
		/* translators: %s: delivery day («lunes 28»). */
		return sprintf( __( 'Pídelo ahora y lo recibes el %s.', 'lachinata-core' ), $day );
	}

	/**
	 * Line for the order confirmation and the emails.
	 *
	 * @param Estimate $estimate Estimate.
	 */
	public static function order( Estimate $estimate ): string {
		/* translators: date format of the order line (PHP date()): «jueves 24 de octubre». */
		$format = _x( 'l j \d\e F', 'order delivery date', 'lachinata-core' );
		if ( $estimate->min == $estimate->max ) { // phpcs:ignore Universal.Operators.StrictComparisons.LooseEqual -- Same date, different objects.
			/* translators: %s: delivery date. */
			return sprintf( __( 'Llega el %s.', 'lachinata-core' ), self::date( $estimate->min, $format ) );
		}
		/* translators: 1: earliest delivery date, 2: latest delivery date. */
		return sprintf( __( 'Llega entre el %1$s y el %2$s.', 'lachinata-core' ), self::date( $estimate->min, $format ), self::date( $estimate->max, $format ) );
	}

	/**
	 * «jueves 24».
	 *
	 * @param \DateTimeImmutable $day Day.
	 */
	public static function long_day( \DateTimeImmutable $day ): string {
		/* translators: date format of a delivery day on the product page (PHP date()): «jueves 24». */
		return self::date( $day, _x( 'l j', 'product delivery day', 'lachinata-core' ) );
	}

	/**
	 * Formats a date at noon (so no time zone shift can change the day), with the
	 * module's own day (D) and month (M) abbreviations.
	 *
	 * @param \DateTimeImmutable $day    Day.
	 * @param string             $format PHP date format.
	 */
	private static function date( \DateTimeImmutable $day, string $format ): string {
		$noon   = $day->setTime( 12, 0 );
		$format = self::with_abbreviations( $format, $noon );
		return (string) wp_date( $format, $noon->getTimestamp(), $day->getTimezone() );
	}

	/**
	 * The format with each unescaped D and M replaced by the abbreviation as escaped literal text.
	 *
	 * @param string             $format PHP date format.
	 * @param \DateTimeImmutable $day    Day.
	 */
	private static function with_abbreviations( string $format, \DateTimeImmutable $day ): string {
		$days   = self::day_abbreviations();
		$months = self::month_abbreviations();
		$out    = '';
		$chars  = mb_str_split( $format );
		$count  = count( $chars );
		for ( $i = 0; $i < $count; $i++ ) {
			$char = $chars[ $i ];
			if ( '\\' === $char && $i + 1 < $count ) {
				$out .= $char . $chars[ ++$i ];
			} elseif ( 'D' === $char ) {
				$out .= self::literal( $days[ (int) $day->format( 'N' ) ] );
			} elseif ( 'M' === $char ) {
				$out .= self::literal( $months[ (int) $day->format( 'n' ) ] );
			} else {
				$out .= $char;
			}
		}
		return $out;
	}

	/**
	 * Text escaped for a date format.
	 *
	 * @param string $text Text.
	 */
	private static function literal( string $text ): string {
		return implode( '', array_map( static fn( string $char ): string => '\\' . $char, mb_str_split( $text ) ) );
	}

	/**
	 * Weekday abbreviations by ISO number.
	 *
	 * @return array<int, string>
	 */
	public static function day_abbreviations(): array {
		return array(
			1 => _x( 'lun', 'Monday abbreviation', 'lachinata-core' ),
			2 => _x( 'mar', 'Tuesday abbreviation', 'lachinata-core' ),
			3 => _x( 'mié', 'Wednesday abbreviation', 'lachinata-core' ),
			4 => _x( 'jue', 'Thursday abbreviation', 'lachinata-core' ),
			5 => _x( 'vie', 'Friday abbreviation', 'lachinata-core' ),
			6 => _x( 'sáb', 'Saturday abbreviation', 'lachinata-core' ),
			7 => _x( 'dom', 'Sunday abbreviation', 'lachinata-core' ),
		);
	}

	/**
	 * Month abbreviations by number.
	 *
	 * @return array<int, string>
	 */
	public static function month_abbreviations(): array {
		return array(
			1  => _x( 'ene', 'January abbreviation', 'lachinata-core' ),
			2  => _x( 'feb', 'February abbreviation', 'lachinata-core' ),
			3  => _x( 'mar', 'March abbreviation', 'lachinata-core' ),
			4  => _x( 'abr', 'April abbreviation', 'lachinata-core' ),
			5  => _x( 'may', 'May abbreviation', 'lachinata-core' ),
			6  => _x( 'jun', 'June abbreviation', 'lachinata-core' ),
			7  => _x( 'jul', 'July abbreviation', 'lachinata-core' ),
			8  => _x( 'ago', 'August abbreviation', 'lachinata-core' ),
			9  => _x( 'sept', 'September abbreviation', 'lachinata-core' ),
			10 => _x( 'oct', 'October abbreviation', 'lachinata-core' ),
			11 => _x( 'nov', 'November abbreviation', 'lachinata-core' ),
			12 => _x( 'dic', 'December abbreviation', 'lachinata-core' ),
		);
	}
}
