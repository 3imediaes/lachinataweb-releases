<?php
/**
 * Transit plan in the settings of every shipping method instance.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Eta;

defined( 'ABSPATH' ) || exit;

/**
 * Days in transit (minimum and maximum), carrier and no-delivery weekdays in the same
 * panel as the shipping conditions. The instance belongs to one zone, so the plan is per
 * zone and method.
 */
final class InstanceFields {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_action( 'woocommerce_init', array( self::class, 'register' ), 20 );
	}

	/**
	 * Hooks the form of each method type.
	 */
	public static function register(): void {
		foreach ( array_keys( WC()->shipping()->get_shipping_method_class_names() ) as $method_id ) {
			add_filter( 'woocommerce_shipping_instance_form_fields_' . $method_id, array( self::class, 'fields' ), 30 );
		}
	}

	/**
	 * Weekday names by ISO number.
	 *
	 * @return array<int, string>
	 */
	public static function weekdays(): array {
		global $wp_locale;
		$days = array();
		for ( $day = 1; $day <= 7; $day++ ) {
			$days[ $day ] = (string) $wp_locale->get_weekday( $day % 7 );
		}
		return $days;
	}

	/**
	 * Appends the plan fields.
	 *
	 * @param array<string, array<string, mixed>> $fields Instance fields.
	 * @return array<string, array<string, mixed>>
	 */
	public static function fields( array $fields ): array {
		$carriers = array( '' => __( 'Sin transportista', 'lachinata-core' ) );
		foreach ( Estimator::config()->carriers as $key => $carrier ) {
			$carriers[ $key ] = $carrier['name'];
		}
		$days = array(
			'type'              => 'number',
			'default'           => '',
			'placeholder'       => '—',
			'desc_tip'          => true,
			'custom_attributes' => array(
				'min'  => '0',
				'step' => '1',
			),
		);

		return $fields + array(
			'lc_eta'             => array(
				'title'       => __( 'Plazo de entrega (La Chinata)', 'lachinata-core' ),
				'type'        => 'title',
				'description' => __( 'Días de tránsito desde que sale del almacén, en esta zona. Sin plazo, este método no muestra fecha. Cortes, preparación y festivos: WooCommerce → La Chinata → Entrega estimada.', 'lachinata-core' ),
			),
			'lc_eta_min'         => array(
				'title'       => __( 'Días de tránsito, mínimo', 'lachinata-core' ),
				'description' => __( '1 = llega al día siguiente de salir.', 'lachinata-core' ),
			) + $days,
			'lc_eta_max'         => array(
				'title'       => __( 'Días de tránsito, máximo', 'lachinata-core' ),
				'description' => __( 'Vacío: igual que el mínimo.', 'lachinata-core' ),
			) + $days,
			'lc_eta_carrier'     => array(
				'title'       => __( 'Transportista', 'lachinata-core' ),
				'type'        => 'select',
				'default'     => '',
				'options'     => $carriers,
				'description' => __( 'Sus días sin entrega se aplican a este método.', 'lachinata-core' ),
				'desc_tip'    => true,
			),
			'lc_eta_no_delivery' => array(
				'title'       => __( 'Días sin entrega', 'lachinata-core' ),
				'type'        => 'multiselect',
				'class'       => 'wc-enhanced-select',
				'default'     => array(),
				'options'     => self::weekdays(),
				'description' => __( 'Además de los del transportista.', 'lachinata-core' ),
				'desc_tip'    => true,
			),
		);
	}
}
