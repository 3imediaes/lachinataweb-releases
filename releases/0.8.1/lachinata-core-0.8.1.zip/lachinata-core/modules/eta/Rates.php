<?php
/**
 * Delivery dates on shipping rates and orders.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Eta;

use LaChinata\Core\Modules\Shipping\Package;

defined( 'ABSPATH' ) || exit;

/**
 * Each rate gets its range as `delivery_time` (the block checkout shows it next to the
 * price) and the dates as `lc_eta` meta for the checkout module. The order keeps them as
 * `_lc_eta` on its shipping line. Packages carry a stamp that changes each day and at
 * each cut-off, so WooCommerce's cached rates never show yesterday's dates.
 */
final class Rates {

	/**
	 * Meta key on rates (visible to the Store API): the dates as JSON.
	 */
	public const RATE_META = 'lc_eta';

	/**
	 * Meta key on the order's shipping line.
	 */
	public const ORDER_META = '_lc_eta';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_filter( 'woocommerce_cart_shipping_packages', array( self::class, 'stamp_packages' ) );
		add_filter( 'woocommerce_package_rates', array( self::class, 'add_dates' ), 30, 2 );
		add_action( 'woocommerce_checkout_create_order_shipping_item', array( self::class, 'order_item' ) );
		add_filter( 'woocommerce_hidden_order_itemmeta', array( self::class, 'hidden_meta' ) );
		add_filter( 'woocommerce_order_item_get_formatted_meta_data', array( self::class, 'formatted_meta' ) );
		add_filter( 'lachinata/rest/order', array( self::class, 'rest_data' ), 10, 2 );
	}

	/**
	 * `delivery` in the `lachinata` object of the REST API: the dates the customer saw when
	 * ordering (leaves the warehouse, arrives between), from the shipping line. Null without
	 * them (no shipping, or an order from before the module).
	 *
	 * @param array<string, mixed> $data  Object.
	 * @param \WC_Order            $order Order.
	 * @return array<string, mixed>
	 */
	public static function rest_data( array $data, \WC_Order $order ): array {
		$estimate = self::of_order( $order );
		if ( null !== $estimate ) {
			$data['delivery'] = array(
				'ships'    => $estimate->ships->format( 'Y-m-d' ),
				'earliest' => $estimate->min->format( 'Y-m-d' ),
				'latest'   => $estimate->max->format( 'Y-m-d' ),
			);
		}
		return $data;
	}

	/**
	 * Adds the stamp to each package (it is part of WooCommerce's rate cache key).
	 *
	 * @param array<int, array<string, mixed>> $packages Packages.
	 * @return array<int, array<string, mixed>>
	 */
	public static function stamp_packages( array $packages ): array {
		$stamp = Estimator::stamp( Estimator::now() );
		foreach ( $packages as $index => $package ) {
			$packages[ $index ]['lc_eta'] = $stamp;
		}
		return $packages;
	}

	/**
	 * Dates for each rate.
	 *
	 * @param array<string, \WC_Shipping_Rate> $rates   Rates.
	 * @param array<string, mixed>             $package WooCommerce package.
	 * @return array<string, \WC_Shipping_Rate>
	 */
	public static function add_dates( array $rates, array $package ): array {
		if ( ! $rates ) {
			return $rates;
		}
		$zone      = \WC_Shipping_Zones::get_zone_matching_package( $package );
		$evaluated = Package::from_wc( $package );
		foreach ( $rates as $rate ) {
			$live     = $rate->get_meta_data()['_lc_live'] ?? array();
			$estimate = Estimator::for_instance(
				$zone,
				(int) $rate->get_instance_id(),
				$evaluated->classes(),
				$evaluated->country,
				is_array( $live ) && isset( $live['days_min'] ) ? $live : array()
			);
			if ( null === $estimate ) {
				continue;
			}
			$rate->set_delivery_time( Format::range( $estimate ) );
			$rate->add_meta_data( self::RATE_META, (string) wp_json_encode( $estimate->to_meta() ) );
		}
		return $rates;
	}

	/**
	 * Moves the rate's dates to the hidden order meta.
	 *
	 * @param \WC_Order_Item_Shipping $item Shipping line being created.
	 */
	public static function order_item( \WC_Order_Item_Shipping $item ): void {
		$dates = json_decode( (string) $item->get_meta( self::RATE_META ), true );
		if ( is_array( $dates ) && $dates ) {
			$item->update_meta_data( self::ORDER_META, $dates );
		}
		$item->delete_meta_data( self::RATE_META );
	}

	/**
	 * Hides the dates in the order screen's item meta.
	 *
	 * @param string[] $keys Hidden keys.
	 * @return string[]
	 */
	public static function hidden_meta( array $keys ): array {
		return array_merge( $keys, array( self::RATE_META, self::ORDER_META, '_lc_live' ) );
	}

	/**
	 * Keeps the dates out of the meta shown in emails and on the account pages.
	 *
	 * @param array<int|string, object> $meta Formatted meta.
	 * @return array<int|string, object>
	 */
	public static function formatted_meta( array $meta ): array {
		return array_filter( $meta, static fn( object $entry ): bool => ! in_array( $entry->key ?? '', array( self::RATE_META, self::ORDER_META ), true ) );
	}

	/**
	 * Estimate of an order that leaves the warehouse on a given day: the transit of its
	 * shipping instance from that day (the gift notice, when the order is shipped). Falls
	 * back to the estimate stored on the order when the instance has no plan any more.
	 *
	 * @param \WC_Order          $order Order.
	 * @param \DateTimeImmutable $ships Dispatch day.
	 */
	public static function shipped( \WC_Order $order, \DateTimeImmutable $ships ): ?Estimate {
		$line = current( $order->get_items( 'shipping' ) );
		if ( ! $line instanceof \WC_Order_Item_Shipping ) {
			return null;
		}
		$country = $order->get_shipping_country() ? $order->get_shipping_country() : $order->get_billing_country();
		$zone    = \WC_Shipping_Zones::get_zone_matching_package(
			array(
				'destination' => array(
					'country'  => $country,
					'state'    => $order->get_shipping_state() ? $order->get_shipping_state() : $order->get_billing_state(),
					'postcode' => $order->get_shipping_postcode() ? $order->get_shipping_postcode() : $order->get_billing_postcode(),
				),
			)
		);
		$method  = $zone->get_shipping_methods()[ (int) $line->get_instance_id() ] ?? null;
		$plan    = $method instanceof \WC_Shipping_Method ? Estimator::plan( $method ) : null;
		$classes = array();
		foreach ( $order->get_items() as $item ) {
			$product = $item instanceof \WC_Order_Item_Product ? $item->get_product() : null;
			if ( $product instanceof \WC_Product && '' !== $product->get_shipping_class() ) {
				$classes[] = $product->get_shipping_class();
			}
		}
		$estimate = null === $plan ? null : Calculator::from_dispatch( Estimator::config(), $plan, array_values( array_unique( $classes ) ), $country, $ships );
		return $estimate ?? self::of_order( $order );
	}

	/**
	 * Estimate stored on an order, or null.
	 *
	 * @param \WC_Order $order Order.
	 */
	public static function of_order( \WC_Order $order ): ?Estimate {
		foreach ( $order->get_items( 'shipping' ) as $item ) {
			$estimate = Estimate::from_meta( $item->get_meta( self::ORDER_META ), wp_timezone() );
			if ( null !== $estimate ) {
				return $estimate;
			}
		}
		return null;
	}
}
