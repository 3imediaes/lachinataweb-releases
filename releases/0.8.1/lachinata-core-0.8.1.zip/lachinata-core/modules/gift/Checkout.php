<?php
/**
 * The gift card of the block checkout.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Gift;

use Automattic\WooCommerce\StoreApi\Exceptions\RouteException;

defined( 'ABSPATH' ) || exit;

/**
 * The card (src/index.js) fills the slot `lachinata/checkout/gift` of the checkout module and
 * sends what the buyer wrote as extension data of the Store API (`lachinata-gift`). Here it
 * is checked again and saved on the order (Gift::store()); a wrong field stops the order
 * with the same sentence the card shows.
 */
final class Checkout {

	/**
	 * Namespace of the extension data.
	 */
	public const NAMESPACE = 'lachinata-gift';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		// Modules boot after WooCommerce's blocks are loaded on a normal request.
		if ( did_action( 'woocommerce_blocks_loaded' ) ) {
			self::register_data();
		} else {
			add_action( 'woocommerce_blocks_loaded', array( self::class, 'register_data' ) );
		}
		add_action( 'woocommerce_store_api_checkout_update_order_from_request', array( self::class, 'from_request' ), 10, 2 );
		add_action(
			'woocommerce_blocks_checkout_block_registration',
			static function ( $registry ): void {
				$registry->register( new Integration() );
			}
		);
	}

	/**
	 * Schema of the extension data.
	 */
	public static function register_data(): void {
		if ( ! function_exists( 'woocommerce_store_api_register_endpoint_data' ) ) {
			return;
		}
		$text = array(
			'type'     => array( 'string', 'null' ),
			'context'  => array(),
			'optional' => true,
		);
		woocommerce_store_api_register_endpoint_data(
			array(
				'endpoint'        => 'checkout', // CheckoutSchema::IDENTIFIER.
				'namespace'       => self::NAMESPACE,
				'schema_callback' => static fn(): array => array(
					'open'    => array(
						'description' => __( 'Si el pedido es un regalo.', 'lachinata-core' ),
						'type'        => array( 'boolean', 'null' ),
						'context'     => array(),
						'optional'    => true,
					),
					'to'      => $text,
					'message' => $text,
					'via'     => array(
						'type'     => array( 'string', 'null' ),
						'enum'     => array_merge( Gift::VIAS, array( null ) ),
						'context'  => array(),
						'optional' => true,
					),
					'contact' => $text,
					'from'    => $text,
				),
				'schema_type'     => ARRAY_A,
			)
		);
	}

	/**
	 * Saves the gift on the order, or stops the order with the first wrong field.
	 *
	 * @param \WC_Order        $order   Order.
	 * @param \WP_REST_Request $request Checkout request.
	 * @throws RouteException When a field is missing or wrong.
	 */
	public static function from_request( $order, $request ): void {
		if ( ! $order instanceof \WC_Order || ! $request instanceof \WP_REST_Request ) {
			return;
		}
		$extensions = (array) $request->get_param( 'extensions' );
		$input      = isset( $extensions[ self::NAMESPACE ] ) && is_array( $extensions[ self::NAMESPACE ] ) ? $extensions[ self::NAMESPACE ] : array();
		if ( empty( $input['open'] ) || ! $order->needs_shipping_address() ) {
			Gift::clear( $order );
			return;
		}
		$country = $order->get_shipping_country() ? $order->get_shipping_country() : $order->get_billing_country();
		$checked = Gift::validate( $input, $country );
		if ( $checked['errors'] ) {
			throw new RouteException( 'lachinata_gift_invalid', esc_html( (string) reset( $checked['errors'] ) ), 400 );
		}
		Gift::store( $order, $checked['data'] );
	}
}
