<?php
/**
 * Module `gift`: gift with a handwritten note and a notice to the recipient.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Gift;

use LaChinata\Core\Module;
use LaChinata\Core\Plugin;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * «¿Es un regalo?» in the checkout (04-envios-entrega.md, «Regalos»; GiftOption): recipient,
 * handwritten message and a notice to the recipient by email, WhatsApp or SMS when the order ships,
 * so nobody refuses a parcel they did not order. The gift travels with the order (meta
 * `_lc_regalo*`, REST `lachinata.gift`), shows in the order screen and the emails, and the
 * recipient's contact is erased some days after the delivery.
 */
final class GiftModule extends Module {

	/**
	 * Module id.
	 */
	public function id(): string {
		return 'gift';
	}

	/**
	 * Module name.
	 */
	public function label(): string {
		return __( 'Regalo', 'lachinata-core' );
	}

	/**
	 * Module description.
	 */
	public function description(): string {
		return __( '«¿Es un regalo?» en el checkout: mensaje escrito a mano y aviso a quien lo recibe por correo, WhatsApp o SMS cuando sale el paquete, sin contenido ni precio.', 'lachinata-core' );
	}

	/**
	 * Version in which the module was added.
	 */
	public function since(): string {
		return '0.7.0';
	}

	/**
	 * Documentation.
	 */
	public function docs(): string {
		return 'plugin/modules/gift/README.md';
	}

	/**
	 * Requirements: the checkout module draws the slot of the card; notify sends the
	 * WhatsApp and the SMS and says which channels are on.
	 *
	 * @return array{modules: string[], woocommerce: string}
	 */
	public function requires(): array {
		return array(
			'modules'     => array( 'checkout', 'notify' ),
			'woocommerce' => '10.0',
		);
	}

	/**
	 * Settings. The «¿Qué es La Chinata?» page belongs to each site and stays out of the
	 * JSON. The channels and their credentials are the `notify` module's.
	 *
	 * @return array<string, array{type: 'bool'|'int'|'float'|'string'|'array', default: mixed, export?: bool}>
	 */
	public function settings(): array {
		$secret = array(
			'type'    => 'string',
			'default' => '',
			'export'  => false,
		);
		return array(
			'notify_statuses' => array(
				'type'    => 'array',
				'default' => array( 'completed' ),
				'export'  => true,
			),
			'erase_days'      => array(
				'type'    => 'int',
				'default' => 30,
				'export'  => true,
			),
			'privacy_text'    => array(
				'type'    => 'string',
				'default' => '',
				'export'  => true,
			),
			'about_url'       => $secret,
		);
	}

	/**
	 * «¿Qué es La Chinata?» at the foot of the recipient's email: the setting, or the home page.
	 */
	public static function about_url(): string {
		$module = Plugin::instance()->modules()->get( 'gift' );
		$url    = null === $module ? '' : (string) Settings::get( $module, 'about_url' );
		return esc_url_raw( '' !== $url ? $url : home_url( '/' ) );
	}

	/**
	 * Registers the hooks.
	 */
	public function boot(): void {
		Checkout::boot();
		Emails::boot();
		Notifier::boot();
		Orders::boot();
		Privacy::boot();
		add_filter( 'lachinata/rest/order', array( Gift::class, 'rest_data' ), 10, 2 );
		add_filter(
			'woocommerce_email_classes',
			static function ( $emails ) {
				$emails                       = is_array( $emails ) ? $emails : array();
				$emails[ RecipientEmail::ID ] = new RecipientEmail();
				return $emails;
			}
		);
		if ( is_admin() ) {
			GiftTab::boot();
		}
	}
}
