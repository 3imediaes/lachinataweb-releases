<?php
/**
 * Module `newsletter`: consent to the newsletter.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Newsletter;

use LaChinata\Core\GapLog;
use LaChinata\Core\Module;
use LaChinata\Core\Plugin;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * The checkout box «Quiero recibir novedades y ofertas por correo» (module `checkout`,
 * `_lc_newsletter_optin`) and the footer form, behind an interchangeable provider
 * (Mailchimp today; Brevo or another with its adapter, `lachinata/newsletter/provider`).
 * It only handles the consent and the form: products, orders and carts are still synced
 * by the provider's own plugin (Mailchimp for WooCommerce), which lives alongside. In the
 * block checkout, our box tells Mailchimp for WooCommerce what it would have read from its
 * own box, which is hidden, so there is only one; its double opt-in setting applies. The
 * footer form always asks to confirm. Serves Contracts\Newsletter to other modules.
 */
final class NewsletterModule extends Module {

	/**
	 * Module id.
	 */
	public function id(): string {
		return 'newsletter';
	}

	/**
	 * Module name.
	 */
	public function label(): string {
		return __( 'Newsletter', 'lachinata-core' );
	}

	/**
	 * Module description.
	 */
	public function description(): string {
		return __( 'La casilla de novedades del checkout y el formulario del pie, con doble confirmación, detrás de un proveedor intercambiable (Mailchimp hoy). La sincronización de la tienda sigue en el plugin del proveedor.', 'lachinata-core' );
	}

	/**
	 * Version in which the module was added.
	 */
	public function since(): string {
		return '0.8.0';
	}

	/**
	 * Documentation.
	 */
	public function docs(): string {
		return 'plugin/modules/newsletter/README.md';
	}

	/**
	 * Requirements: the checkout module keeps the box.
	 *
	 * @return array{modules: string[], woocommerce: string}
	 */
	public function requires(): array {
		return array(
			'modules'     => array( 'checkout' ),
			'woocommerce' => '10.0',
		);
	}

	/**
	 * Settings. Without Mailchimp for WooCommerce, the key and audience go here, per site.
	 *
	 * @return array<string, array{type: 'bool'|'int'|'float'|'string'|'array', default: mixed, export?: bool}>
	 */
	public function settings(): array {
		$secret = array(
			'type'    => 'string',
			'default' => '',
			'export'  => false,
		);
		return array(
			'footer_form'       => array(
				'type'    => 'bool',
				'default' => true,
				'export'  => true,
			),
			'footer_title'      => array(
				'type'    => 'string',
				'default' => '',
				'export'  => true,
			),
			'footer_text'       => array(
				'type'    => 'string',
				'default' => '',
				'export'  => true,
			),
			'mailchimp_api_key' => $secret,
			'mailchimp_list'    => $secret,
		);
	}

	/**
	 * A setting of the module.
	 *
	 * @param string $key Setting key.
	 * @return mixed
	 */
	public static function setting( string $key ) {
		$module = Plugin::instance()->modules()->get( 'newsletter' );
		return null === $module ? null : Settings::get( $module, $key );
	}

	/**
	 * Configuration gaps of the module.
	 */
	public static function gaps(): GapLog {
		return new GapLog( 'lachinata_newsletter_gaps', 'lachinata-newsletter' );
	}

	/**
	 * Registers the hooks.
	 */
	public function boot(): void {
		$service = new Service();
		add_filter( 'lachinata/newsletter/service', static fn() => $service );
		Checkout::boot( $service );
		FooterForm::boot( $service );
		if ( is_admin() ) {
			NewsletterTab::boot();
		}
	}
}
