# Módulo `odoo`

Contrato de la API de pedidos con Odoo. Odoo lee la API REST de WooCommerce con su clave («Odoo») y asocia el transportista por el **ID de instancia** del método de envío; eso no cambia y no depende de este módulo. Todo lo que La Chinata añade a un pedido va en un único objeto `lachinata` (núcleo, `plugin/src/Rest/OrderData.php`), nunca en campos sueltos en la raíz.

Contrato completo con ejemplos: `docs/api-odoo.md`. Paso a producción: `docs/despliegue-gift-odoo.md`. Panel: WooCommerce → La Chinata → Odoo.

## Qué hace

| Pieza | Cómo | Dónde |
| --- | --- | --- |
| Mapa instancia de envío → transportista, con todas las instancias de todas las zonas (también «Lugares no cubiertos»), activas o no | Opción `lachinata_odoo_carriers`; exportable en el JSON de configuración (`data.carriers`) | `Carriers.php`, `OdooTab.php` |
| Nombre del transportista en `lachinata.shipping.carrier` (informativo), en el aviso de regalo y en «Tu pedido ya está en camino» (correo y WhatsApp: «llega … con Correos Express») | Filtro del núcleo `lachinata/order/carrier` | `Carriers::carrier()` |
| IDs retirados en Odoo (ajuste `retired_ids`, configuración de cada sitio; el seed pone los de lachinata.es: 18, 24, 26, 31, 32, 38, 39). Avisos: un ID retirado que sigue activo en WooCommerce o en el mapa, un ID del mapa que ya no existe, una instancia activa sin transportista y, desde la 0.8.0, una instancia con la que ya salió un aviso como «nuestro transportista» (acción `lachinata/order/carrier_unknown`, opción `lachinata_odoo_carriers_missing`) | `Carriers::warnings()`, `Carriers::unknown()` | panel |
| Regiones de España con zona propia (Baleares ES:PM, Canarias, Ceuta y Melilla) con sus IDs: son país ES + provincia, sin países ficticios | Zonas de WooCommerce | panel |
| «Objeto de un pedido»: el `lachinata` de cualquier pedido tal como lo recibe Odoo | `OrderData::of()` | panel |

Nada de lachinata.es en el código: el mapa y los IDs retirados son configuración.

## Tests

`tests/CarriersTest.php`: mapa y transportista del pedido (el `instance_id` sigue ahí), avisos, exportación e importación. El objeto completo, en `plugin/tests/OrderDataTest.php`.
