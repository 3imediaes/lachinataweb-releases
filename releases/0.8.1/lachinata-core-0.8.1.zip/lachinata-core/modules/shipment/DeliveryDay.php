<?php
/**
 * The day of the delivery (prepared, off).
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipment;

defined( 'ABSPATH' ) || exit;

/**
 * The gift's second notice «llega hoy» (04-envios-entrega.md, «Regalos», 4) needs the
 * carrier to say the parcel is out for delivery, which WooCommerce Shipment Tracking does
 * not carry today. The way is ready: a source registered with
 * `lachinata/shipment/delivery_events` answers, for an order, whether it is out for delivery
 * today; with the setting `delivery_day` on (off, not in the panel), the hourly job fires
 * `lachinata/shipment/out_for_delivery` once per order, and the gift module (or another)
 * sends its notice. No source exists yet, so nothing runs.
 */
final class DeliveryDay {

	/**
	 * Hourly job.
	 */
	public const HOOK = 'lachinata/shipment/delivery_day_check';

	/**
	 * Order meta: when the order was found out for delivery.
	 */
	public const META = '_lc_shipment_out_for_delivery';

	/**
	 * Registers the job only while the setting is on and some source exists.
	 */
	public static function boot(): void {
		if ( ! ShipmentModule::setting( 'delivery_day' ) || ! self::sources() ) {
			return;
		}
		add_action( self::HOOK, array( self::class, 'check' ) );
		if ( function_exists( 'as_has_scheduled_action' ) && function_exists( 'as_schedule_recurring_action' ) && ! as_has_scheduled_action( self::HOOK, array(), 'lachinata-shipment' ) ) {
			as_schedule_recurring_action( time() + HOUR_IN_SECONDS, HOUR_IN_SECONDS, self::HOOK, array(), 'lachinata-shipment' );
		}
	}

	/**
	 * Sources of delivery events: callables that answer whether an order is out for
	 * delivery today.
	 *
	 * @return array<int, callable(\WC_Order): bool>
	 */
	public static function sources(): array {
		/**
		 * Where the day of the delivery comes from (a carrier's API). None today.
		 *
		 * @since 0.8.0
		 *
		 * @param array<int, callable> $sources Callables that take an order and say whether it is out for delivery today.
		 */
		return array_values( array_filter( (array) apply_filters( 'lachinata/shipment/delivery_events', array() ), 'is_callable' ) );
	}

	/**
	 * Looks at the orders on their way, once per order.
	 */
	public static function check(): void {
		$orders = wc_get_orders(
			array(
				'limit'        => 100,
				'status'       => Notifier::statuses(),
				'date_created' => '>' . ( time() - 15 * DAY_IN_SECONDS ),
			)
		);
		foreach ( $orders as $order ) {
			if ( ! $order instanceof \WC_Order || (int) $order->get_meta( self::META ) > 0 ) {
				continue;
			}
			foreach ( self::sources() as $source ) {
				if ( true === $source( $order ) ) {
					$order->update_meta_data( self::META, (string) time() );
					$order->save_meta_data();
					/**
					 * An order is out for delivery today.
					 *
					 * @since 0.8.0
					 *
					 * @param \WC_Order $order Order.
					 */
					do_action( 'lachinata/shipment/out_for_delivery', $order );
					break;
				}
			}
		}
	}
}
