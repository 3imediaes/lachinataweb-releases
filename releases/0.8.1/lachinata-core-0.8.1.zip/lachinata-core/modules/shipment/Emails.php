<?php
/**
 * «Tu pedido ya está en camino» in the theme's frame.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipment;

defined( 'ABSPATH' ) || exit;

/**
 * The shipped email (tablero «Correos transaccionales», 2): the lead with the carrier and,
 * with tracking, how to change the delivery; the facts «Llega» (from the real dispatch
 * day), «Transportista» (with the number) and the theme's «Entrega en»; the button «Seguir
 * el paquete». The theme's frame draws them; WooCommerce Shipment Tracking's own table
 * leaves the email (it would say the same twice).
 */
final class Emails {

	/**
	 * Email of WooCommerce it fills.
	 */
	private const EMAIL = 'customer_completed_order';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_filter( 'lachinata/email/intro', array( self::class, 'intro' ), 20, 2 );
		add_filter( 'lachinata/email/facts', array( self::class, 'facts' ), 20, 3 );
		add_filter( 'lachinata/email/button', array( self::class, 'button' ), 20, 2 );
		add_action( 'init', array( self::class, 'without_extension_table' ), 20 );
	}

	/**
	 * Details of the order of a shipped email, or null.
	 *
	 * @param mixed $email Email.
	 * @return array{dates: string, between: string, carrier: string, number: string, url: string}|null
	 */
	private static function details( $email ): ?array {
		if ( ! $email instanceof \WC_Email || self::EMAIL !== $email->id || ! $email->object instanceof \WC_Order ) {
			return null;
		}
		return Notifier::details( $email->object );
	}

	/**
	 * Lead and preheader with the carrier and the dates.
	 *
	 * @param mixed $intro Intro.
	 * @param mixed $email Email.
	 * @return array<string, mixed>
	 */
	public static function intro( $intro, $email = null ): array {
		$intro   = is_array( $intro ) ? $intro : array();
		$details = self::details( $email );
		if ( null === $details || ! $email instanceof \WC_Email || ! $email->object instanceof \WC_Order ) {
			return $intro;
		}
		if ( '' !== $details['carrier'] ) {
			$intro['lead'] = '' !== $details['url']
				/* translators: %s: carrier. */
				? sprintf( __( 'Ha salido hoy de nuestro almacén con %s. Si no vas a estar, podrás cambiar el día o el lugar de entrega desde el seguimiento.', 'lachinata-core' ), $details['carrier'] )
				/* translators: %s: carrier. */
				: sprintf( __( 'Ha salido hoy de nuestro almacén con %s.', 'lachinata-core' ), $details['carrier'] );
		}
		if ( '' !== $details['dates'] ) {
			/* translators: 1: order number, 2: delivery dates. */
			$intro['preheader'] = sprintf( __( 'Tu pedido %1$s ha salido · llega %2$s', 'lachinata-core' ), $email->object->get_order_number(), $details['dates'] );
		}
		return $intro;
	}

	/**
	 * «Llega» from the real dispatch day and «Transportista», before the address.
	 *
	 * @param mixed $facts Facts.
	 * @param mixed $order Order.
	 * @param mixed $email Email.
	 * @return array<string, mixed>
	 */
	public static function facts( $facts, $order = null, $email = null ): array {
		$facts   = is_array( $facts ) ? $facts : array();
		$details = self::details( $email );
		if ( null === $details ) {
			return $facts;
		}
		unset( $order );
		$out = array();
		if ( '' !== $details['dates'] ) {
			$out['delivery'] = array(
				'label' => __( 'Llega', 'lachinata-core' ),
				'value' => $details['dates'],
				'note'  => '',
			);
		} elseif ( isset( $facts['delivery'] ) ) {
			$out['delivery'] = $facts['delivery'];
		}
		if ( '' !== $details['carrier'] ) {
			$out['carrier'] = array(
				'label' => __( 'Transportista', 'lachinata-core' ),
				'value' => $details['carrier'],
				'note'  => $details['number'],
			);
		}
		unset( $facts['delivery'], $facts['carrier'] );
		return $out + $facts;
	}

	/**
	 * «Seguir el paquete» to the carrier's page, when there is tracking.
	 *
	 * @param mixed $button Button.
	 * @param mixed $email  Email.
	 * @return array<string, string>|null
	 */
	public static function button( $button, $email = null ): ?array {
		$details = self::details( $email );
		if ( null === $details || '' === $details['url'] ) {
			return is_array( $button ) ? $button : null;
		}
		return array(
			'label'   => __( 'Seguir el paquete', 'lachinata-core' ),
			'url'     => $details['url'],
			'variant' => 'primary',
		);
	}

	/**
	 * With the theme's frame, the table of WooCommerce Shipment Tracking leaves the emails:
	 * the frame already says carrier, number and link.
	 */
	public static function without_extension_table(): void {
		/**
		 * Whether the theme draws the frame of the emails (documented in gift's Emails).
		 *
		 * @since 0.8.0
		 */
		if ( ! apply_filters( 'lachinata/email/frame', false ) || ! is_callable( array( 'WC_Shipment_Tracking_Actions', 'get_instance' ) ) ) {
			return;
		}
		$actions = call_user_func( array( 'WC_Shipment_Tracking_Actions', 'get_instance' ) );
		if ( ! is_object( $actions ) ) {
			return;
		}
		$callback = array( $actions, 'email_display' );
		$priority = has_action( 'woocommerce_email_before_order_table', $callback );
		if ( false !== $priority ) {
			remove_action( 'woocommerce_email_before_order_table', $callback, (int) $priority );
		}
	}
}
