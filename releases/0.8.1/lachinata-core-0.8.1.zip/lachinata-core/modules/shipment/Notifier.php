<?php
/**
 * «Tu pedido ya está en camino», once.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipment;

use LaChinata\Core\Contracts\Notice;
use LaChinata\Core\Contracts\Notifier as Notifications;
use LaChinata\Core\Phone;
use LaChinata\Core\Rest\OrderData;
use LaChinata\Core\Services;
use LaChinata\Core\Sms;
use LaChinata\Core\Tracking\Tracking;

defined( 'ABSPATH' ) || exit;

/**
 * When the order reaches one of the module's statuses («Completado» by default: Odoo sets
 * it when the parcel leaves), the buyer is told once. The email is WooCommerce's «Pedido
 * completado» in the theme's frame (Emails); if the order goes through «Completado» again,
 * that email does not go a second time. The WhatsApp goes to the delivery phone when the
 * buyer asked for it in the checkout and the order is not a gift; if WhatsApp cannot
 * deliver it, `notify` sends it by SMS. Nothing here stops a status change.
 */
final class Notifier {

	/**
	 * Order meta with what was done: when, whether the email went and the WhatsApp result.
	 */
	public const META = '_lc_shipment_notified';

	/**
	 * Before WooCommerce's emails of the same status (10).
	 */
	private const PRIORITY = 5;

	/**
	 * Orders told already whose status came back to «Completado» in this request.
	 *
	 * @var array<int, true>
	 */
	private static array $repeated = array();

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		foreach ( self::statuses() as $status ) {
			add_action( 'woocommerce_order_status_' . $status, array( self::class, 'on_status' ), self::PRIORITY, 2 );
		}
		add_action( 'lachinata/notify/fallback', array( self::class, 'on_fallback' ), 10, 3 );
	}

	/**
	 * Statuses that tell the buyer (setting, without `wc-`).
	 *
	 * @return string[]
	 */
	public static function statuses(): array {
		$statuses = array_values( array_filter( array_map( static fn( $status ): string => sanitize_key( str_replace( 'wc-', '', (string) $status ) ), (array) ShipmentModule::setting( 'notify_statuses' ) ) ) );
		return $statuses ? $statuses : array( 'completed' );
	}

	/**
	 * What was done for an order, or null.
	 *
	 * @param \WC_Order $order Order.
	 * @return array{at: int, whatsapp: array{ok: bool, channel: string, error: string, link: bool}|null}|null
	 */
	public static function notified( \WC_Order $order ): ?array {
		$sent = $order->get_meta( self::META );
		if ( ! is_array( $sent ) || empty( $sent['at'] ) ) {
			return null;
		}
		$whatsapp = is_array( $sent['whatsapp'] ?? null ) ? $sent['whatsapp'] : null;
		return array(
			'at'       => (int) $sent['at'],
			'whatsapp' => null === $whatsapp ? null : array(
				'ok'      => ! empty( $whatsapp['ok'] ),
				'channel' => (string) ( $whatsapp['channel'] ?? '' ),
				'error'   => (string) ( $whatsapp['error'] ?? '' ),
				'link'    => ! empty( $whatsapp['link'] ),
			),
		);
	}

	/**
	 * Status hook.
	 *
	 * @param int   $order_id Order id.
	 * @param mixed $order    Order.
	 */
	public static function on_status( $order_id, $order = null ): void {
		$order = $order instanceof \WC_Order ? $order : wc_get_order( (int) $order_id );
		if ( ! $order instanceof \WC_Order ) {
			return;
		}
		if ( null !== self::notified( $order ) ) {
			// Once: WooCommerce's «Pedido completado» would go again.
			self::$repeated[ $order->get_id() ] = true;
			add_filter( 'woocommerce_email_enabled_customer_completed_order', array( self::class, 'skip_email' ), 99, 2 );
			return;
		}
		self::notify( $order );
	}

	/**
	 * Switches the «Pedido completado» email off for the order already told.
	 *
	 * @param mixed $enabled Enabled.
	 * @param mixed $order   Order.
	 */
	public static function skip_email( $enabled, $order = null ): bool {
		return $order instanceof \WC_Order && isset( self::$repeated[ $order->get_id() ] ) ? false : (bool) $enabled;
	}

	/**
	 * Tells the buyer.
	 *
	 * @param \WC_Order $order Order.
	 * @return array{at: int, whatsapp: array{ok: bool, channel: string, error: string, link: bool}|null}|null
	 */
	public static function notify( \WC_Order $order ): ?array {
		$record = array(
			'at'       => time(),
			'whatsapp' => null,
		);
		if ( Optin::wants( $order ) ) {
			try {
				$record['whatsapp'] = self::whatsapp( $order );
			} catch ( \Throwable $error ) {
				$record['whatsapp'] = array(
					'ok'      => false,
					'channel' => Notifications::WHATSAPP,
					'error'   => $error->getMessage(),
					'link'    => false,
				);
			}
			self::note( $order, $record['whatsapp'] );
		}
		// The email of this status goes right after (WooCommerce, priority 10).
		$order->update_meta_data( self::META, $record );
		$order->save_meta_data();
		return self::notified( $order );
	}

	/**
	 * The WhatsApp `lc_pedido_enviado`: «Hola, {{1}}. Tu pedido {{2}} de La Chinata ya está en
	 * camino: llega {{3}} con {{4}}.», with the short link as its button.
	 *
	 * @param \WC_Order $order Order.
	 * @return array{ok: bool, channel: string, error: string, link: bool}
	 */
	private static function whatsapp( \WC_Order $order ): array {
		$notifier = Services::notifier();
		$country  = $order->get_shipping_country() ? $order->get_shipping_country() : $order->get_billing_country();
		$phone    = Phone::normalize( $order->get_shipping_phone() ? $order->get_shipping_phone() : $order->get_billing_phone(), $country );
		if ( null === $notifier ) {
			return self::failed( __( 'el módulo Avisos está apagado', 'lachinata-core' ) );
		}
		if ( null === $phone ) {
			return self::failed( __( 'el teléfono de entrega no es un móvil', 'lachinata-core' ) );
		}
		$details = self::details( $order );
		$link    = '' !== $details['url'];
		$params  = array(
			self::first_name( $order ),
			$order->get_order_number(),
			'' !== $details['dates'] ? $details['dates'] : __( 'en los próximos días', 'lachinata-core' ),
			'' !== $details['carrier'] ? $details['carrier'] : __( 'nuestro transportista', 'lachinata-core' ),
		);
		$short   = $link ? $notifier->short_link( $order ) : '';
		$result  = $notifier->send( Notifications::WHATSAPP, new Notice( Notice::SHIPPED, $order, $phone, $params, $link, self::sms( $params, $short ), 'shipment' ) );
		if ( $result->ok && '' === $details['carrier'] ) {
			$line = current( $order->get_items( 'shipping' ) );
			/**
			 * A notice left without the carrier's name (documented in gift's Notifier).
			 *
			 * @since 0.8.0
			 */
			do_action( 'lachinata/order/carrier_unknown', $line instanceof \WC_Order_Item_Shipping ? (int) $line->get_instance_id() : 0, $order );
		}
		return array(
			'ok'      => $result->ok,
			'channel' => $result->channel,
			'error'   => $result->error,
			'link'    => $link,
		);
	}

	/**
	 * A WhatsApp that did not leave.
	 *
	 * @param string $why Reason.
	 * @return array{ok: bool, channel: string, error: string, link: bool}
	 */
	private static function failed( string $why ): array {
		return array(
			'ok'      => false,
			'channel' => Notifications::WHATSAPP,
			'error'   => $why,
			'link'    => false,
		);
	}

	/**
	 * First name of the buyer («Alberto»).
	 *
	 * @param \WC_Order $order Order.
	 */
	public static function first_name( \WC_Order $order ): string {
		$name  = trim( $order->get_billing_first_name() );
		$name  = '' !== $name ? $name : trim( $order->get_shipping_first_name() );
		$parts = preg_split( '/\s+/', $name );
		return is_array( $parts ) && '' !== $parts[0] ? $parts[0] : __( 'hola', 'lachinata-core' );
	}

	/**
	 * Dates from the real dispatch day, carrier and tracking of a shipped order.
	 *
	 * @param \WC_Order $order Order.
	 * @return array{dates: string, between: string, carrier: string, number: string, url: string}
	 */
	public static function details( \WC_Order $order ): array {
		$tracking = Tracking::of( $order );
		/**
		 * Delivery dates of an order that left on a given day (module eta).
		 *
		 * @since 0.8.0
		 *
		 * @param array{span: string, between: string}|null $dates   Null without eta.
		 * @param \WC_Order                                 $order   Order.
		 * @param int|null                                  $shipped Dispatch time; null for today.
		 */
		$dates   = apply_filters( 'lachinata/delivery/from_dispatch', null, $order, null === $tracking ? null : $tracking['shipped'] );
		$carrier = OrderData::carrier( $order );
		$carrier = null !== $carrier ? $carrier : self::provider_name( null === $tracking ? '' : $tracking['carrier'] );
		return array(
			'dates'   => is_array( $dates ) ? (string) ( $dates['span'] ?? '' ) : '',
			'between' => is_array( $dates ) ? (string) ( $dates['between'] ?? '' ) : '',
			'carrier' => $carrier,
			'number'  => null === $tracking ? '' : $tracking['number'],
			'url'     => null === $tracking ? '' : $tracking['url'],
		);
	}

	/**
	 * The tracking's provider as people read it: a custom one is already a name («Correos
	 * Express»); a slug of the extension («correos-express») is not used.
	 *
	 * @param string $provider Provider.
	 */
	private static function provider_name( string $provider ): string {
		return preg_match( '/^[a-z0-9-]+$/', $provider ) ? '' : trim( $provider );
	}

	/**
	 * The SMS of the fallback, at most two segments: without the carrier if it does not fit;
	 * the dates and the link always.
	 *
	 * @param string[] $params Variables of the template.
	 * @param string   $link   Short link or ''.
	 */
	public static function sms( array $params, string $link ): string {
		$end = '' === $link
			? ''
			/* translators: %s: short tracking link. */
			: ' ' . sprintf( __( 'Sigue el paquete: %s', 'lachinata-core' ), $link );
		return Sms::first_fitting(
			array(
				/* translators: 1: buyer's first name, 2: order number, 3: delivery dates, 4: carrier. */
				sprintf( __( 'Hola, %1$s. Tu pedido %2$s de La Chinata ya está en camino: llega %3$s con %4$s.', 'lachinata-core' ), $params[0], $params[1], $params[2], $params[3] ) . $end,
				/* translators: 1: buyer's first name, 2: order number, 3: delivery dates. */
				sprintf( __( 'Hola, %1$s. Tu pedido %2$s de La Chinata ya está en camino: llega %3$s.', 'lachinata-core' ), $params[0], $params[1], $params[2] ) . $end,
				/* translators: 1: order number, 2: delivery dates. */
				sprintf( __( 'Tu pedido %1$s de La Chinata llega %2$s.', 'lachinata-core' ), $params[1], $params[2] ) . $end,
			)
		);
	}

	/**
	 * Note of the order.
	 *
	 * @param \WC_Order                                                        $order  Order.
	 * @param array{ok: bool, channel: string, error: string, link: bool}|null $result Result.
	 */
	private static function note( \WC_Order $order, ?array $result ): void {
		if ( null === $result ) {
			return;
		}
		$channel = Notifications::SMS === $result['channel'] ? __( 'SMS', 'lachinata-core' ) : __( 'WhatsApp', 'lachinata-core' );
		if ( $result['ok'] ) {
			$order->add_order_note(
				$result['link']
					/* translators: %s: channel. */
					? sprintf( __( 'Envío: aviso al comprador por %s, con el enlace de seguimiento.', 'lachinata-core' ), $channel )
					/* translators: %s: channel. */
					: sprintf( __( 'Envío: aviso al comprador por %s, sin seguimiento: solo con la fecha.', 'lachinata-core' ), $channel )
			);
			return;
		}
		/* translators: %s: reason. */
		$order->add_order_note( sprintf( __( 'Envío: no se pudo avisar al comprador por WhatsApp (%s). El correo sale igual.', 'lachinata-core' ), $result['error'] ) );
		ShipmentModule::gaps()->record(
			'whatsapp|' . md5( $result['error'] ),
			/* translators: %s: reason. */
			sprintf( __( 'Un aviso de envío por WhatsApp no salió: %s.', 'lachinata-core' ), $result['error'] ),
			array( 'order' => $order->get_id() )
		);
	}

	/**
	 * WhatsApp could not deliver the buyer's notice and it went by SMS.
	 *
	 * @param mixed $order  Order.
	 * @param mixed $kind   Notice kind.
	 * @param mixed $result Result of the SMS.
	 */
	public static function on_fallback( $order, $kind = '', $result = null ): void {
		if ( ! $order instanceof \WC_Order || Notice::SHIPPED !== $kind || ! $result instanceof \LaChinata\Core\Contracts\NoticeResult ) {
			return;
		}
		$order->add_order_note(
			$result->ok
				? __( 'Envío: el WhatsApp al comprador no se pudo entregar; el aviso ha salido por SMS.', 'lachinata-core' )
				/* translators: %s: reason. */
				: sprintf( __( 'Envío: el WhatsApp al comprador no se pudo entregar y el SMS tampoco salió (%s).', 'lachinata-core' ), $result->error )
		);
	}
}
