<?php
/**
 * «Avísame por WhatsApp cuando salga mi pedido».
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipment;

use LaChinata\Core\Contracts\Notifier as Notifications;
use LaChinata\Core\Services;

defined( 'ABSPATH' ) || exit;

/**
 * A box in Contacto, under the newsletter one and with the same piece (an additional
 * checkout field of WooCommerce), off by default and only while WhatsApp is on in Avisos.
 * Ticking «Es un regalo» hides and unticks it (src/index.js and the theme's checkout.css,
 * `.lc-gift-open`): a gift's delivery phone is the
 * recipient's. The consent is kept on the order with its time (`_lc_shipment_whatsapp`).
 */
final class Optin {

	/**
	 * Id of the checkout field.
	 */
	public const FIELD = 'lachinata/shipment-whatsapp';

	/**
	 * Order meta with the time of the consent.
	 */
	public const META = '_lc_shipment_whatsapp';

	/**
	 * Script handle.
	 */
	public const SCRIPT = 'lachinata-shipment';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_action( 'woocommerce_init', array( self::class, 'register_field' ), 20 );
		add_action( 'woocommerce_store_api_checkout_order_processed', array( self::class, 'from_checkout' ) );
		add_action( 'woocommerce_blocks_enqueue_checkout_block_scripts_after', array( self::class, 'enqueue' ) );
		add_filter( 'lachinata/rest/order', array( self::class, 'rest_data' ), 10, 2 );
	}

	/**
	 * Whether the box is offered: the setting and WhatsApp on and ready.
	 */
	public static function offered(): bool {
		$notifier = Services::notifier();
		return (bool) ShipmentModule::setting( 'whatsapp_optin' ) && null !== $notifier && $notifier->available( Notifications::WHATSAPP );
	}

	/**
	 * Registers the box (after the checkout module's newsletter box, so it goes under it).
	 */
	public static function register_field(): void {
		if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) || ! self::offered() ) {
			return;
		}
		woocommerce_register_additional_checkout_field(
			array(
				'id'                         => self::FIELD,
				'label'                      => __( 'Avísame por WhatsApp cuando salga mi pedido', 'lachinata-core' ),
				// A box is always optional: without «(opcional)».
				'optionalLabel'              => __( 'Avísame por WhatsApp cuando salga mi pedido', 'lachinata-core' ),
				'location'                   => 'contact',
				'type'                       => 'checkbox',
				'show_in_order_confirmation' => false,
			)
		);
	}

	/**
	 * Hides the box while «Es un regalo» is ticked.
	 */
	public static function enqueue(): void {
		if ( ! self::offered() ) {
			return;
		}
		$asset = file_exists( LACHINATA_CORE_DIR . '/modules/shipment/build/shipment.asset.php' )
			? require LACHINATA_CORE_DIR . '/modules/shipment/build/shipment.asset.php'
			: array(
				'dependencies' => array(),
				'version'      => LACHINATA_CORE_VERSION,
			);
		wp_enqueue_script(
			self::SCRIPT,
			plugins_url( 'modules/shipment/build/shipment.js', LACHINATA_CORE_FILE ),
			array_merge( (array) $asset['dependencies'], array( 'wc-blocks-checkout' ) ),
			(string) $asset['version'],
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
	}

	/**
	 * Keeps the consent, never for a gift.
	 *
	 * @param mixed $order Order.
	 */
	public static function from_checkout( $order ): void {
		if ( ! $order instanceof \WC_Order || '' !== (string) $order->get_meta( self::META ) ) {
			return;
		}
		if ( wc_string_to_bool( (string) $order->get_meta( '_wc_other/' . self::FIELD ) ) && ! self::is_gift( $order ) ) {
			$order->update_meta_data( self::META, (string) time() );
			$order->save();
		}
	}

	/**
	 * Whether the order is a gift (meta `_lc_regalo` of the gift module, documented in
	 * docs/api-odoo.md).
	 *
	 * @param \WC_Order $order Order.
	 */
	public static function is_gift( \WC_Order $order ): bool {
		return wc_string_to_bool( (string) $order->get_meta( '_lc_regalo' ) );
	}

	/**
	 * Whether the buyer asked for the WhatsApp notice.
	 *
	 * @param \WC_Order $order Order.
	 */
	public static function wants( \WC_Order $order ): bool {
		return (int) $order->get_meta( self::META ) > 0 && ! self::is_gift( $order );
	}

	/**
	 * `shipment` in the `lachinata` object of the REST API: the consent and the notice.
	 *
	 * @param array<string, mixed> $data  Object.
	 * @param \WC_Order            $order Order.
	 * @return array<string, mixed>
	 */
	public static function rest_data( array $data, \WC_Order $order ): array {
		$at               = (int) $order->get_meta( self::META );
		$sent             = Notifier::notified( $order );
		$data['shipment'] = array(
			'whatsapp_opt_in' => $at > 0,
			'opt_in_at'       => $at > 0 ? gmdate( 'Y-m-d\TH:i:s\Z', $at ) : null,
			'notified_at'     => null === $sent ? null : gmdate( 'Y-m-d\TH:i:s\Z', $sent['at'] ),
		);
		return $data;
	}
}
