<?php
/**
 * WooCommerce → La Chinata → Envío y seguimiento.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipment;

use LaChinata\Core\Admin\Screen;
use LaChinata\Core\Plugin;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Which status tells the buyer, whether the checkout offers the WhatsApp notice, and the
 * notices that did not leave.
 */
final class ShipmentTab {

	/**
	 * Tab id.
	 */
	public const TAB = 'shipment';

	/**
	 * Actions of admin-post.php, also nonce actions.
	 */
	private const SAVE       = 'lachinata_shipment_settings';
	private const CLEAR_GAPS = 'lachinata_shipment_clear_gaps';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_filter( 'lachinata/core/admin_tabs', array( self::class, 'tab' ), 32 );
		foreach ( array( self::SAVE, self::CLEAR_GAPS ) as $action ) {
			add_action( 'admin_post_' . $action, array( self::class, 'handle' ) );
		}
	}

	/**
	 * Adds the tab after Avisos.
	 *
	 * @param array<string, array{label: string, render: callable}> $tabs Tabs.
	 * @return array<string, array{label: string, render: callable}>
	 */
	public static function tab( array $tabs ): array {
		$position = array_search( 'notify', array_keys( $tabs ), true );
		$position = false === $position ? count( $tabs ) : $position + 1;
		$tab      = array(
			self::TAB => array(
				'label'  => __( 'Seguimiento', 'lachinata-core' ),
				'render' => array( self::class, 'render' ),
			),
		);
		return array_slice( $tabs, 0, $position, true ) + $tab + $tabs;
	}

	/**
	 * Prints the tab.
	 */
	public static function render(): void {
		$module = Plugin::instance()->modules()->get( 'shipment' );
		if ( null === $module ) {
			return;
		}
		$statuses = Notifier::statuses();
		$log      = ShipmentModule::gaps()->all();
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE ); ?>">
			<?php wp_nonce_field( self::SAVE ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( '«Tu pedido ya está en camino» sale cuando el pedido pasa a', 'lachinata-core' ); ?></th>
					<td>
						<fieldset>
							<?php foreach ( wc_get_order_statuses() as $key => $label ) : ?>
								<?php $status = str_replace( 'wc-', '', $key ); ?>
								<?php if ( in_array( $status, array( 'pending', 'failed', 'cancelled', 'refunded', 'checkout-draft' ), true ) ) : ?>
									<?php continue; ?>
								<?php endif; ?>
								<label><input type="checkbox" name="notify_statuses[]" value="<?php echo esc_attr( $status ); ?>" <?php checked( in_array( $status, $statuses, true ) ); ?>> <?php echo esc_html( $label ); ?></label><br>
							<?php endforeach; ?>
						</fieldset>
						<p class="description"><?php esc_html_e( 'Por defecto, «Completado» (lo marca Odoo cuando sale el paquete). Una sola vez por pedido: con el seguimiento que haya en ese momento (Odoo debe escribirlo antes de cambiar el estado).', 'lachinata-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Aviso por WhatsApp', 'lachinata-core' ); ?></th>
					<td>
						<label><input type="checkbox" name="whatsapp_optin" value="1" <?php checked( (bool) Settings::get( $module, 'whatsapp_optin' ) ); ?>> <?php esc_html_e( 'Ofrecer «Avísame por WhatsApp cuando salga mi pedido» en el checkout', 'lachinata-core' ); ?></label>
						<p class="description">
							<?php esc_html_e( 'Solo se ofrece si WhatsApp está activo en Avisos, apagada por defecto y nunca en un regalo. Va al teléfono de entrega con la plantilla lc_pedido_enviado.', 'lachinata-core' ); ?>
							<?php echo Optin::offered() ? '' : ' <strong>' . esc_html__( 'Ahora no se ofrece: WhatsApp no está activo en Avisos.', 'lachinata-core' ) . '</strong>'; ?>
						</p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>

		<h2><?php esc_html_e( 'Avisos que no salieron', 'lachinata-core' ); ?></h2>
		<?php if ( $log ) : ?>
			<table class="widefat striped">
				<thead><tr><th scope="col"><?php esc_html_e( 'Qué pasó', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Veces', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Última', 'lachinata-core' ); ?></th></tr></thead>
				<tbody>
					<?php foreach ( $log as $entry ) : ?>
						<tr>
							<td><?php echo esc_html( $entry['message'] ); ?></td>
							<td><?php echo esc_html( number_format_i18n( $entry['count'] ) ); ?></td>
							<td><?php echo esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $entry['last'] ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::CLEAR_GAPS ); ?>">
				<?php wp_nonce_field( self::CLEAR_GAPS ); ?>
				<?php submit_button( __( 'Vaciar la lista', 'lachinata-core' ), 'secondary' ); ?>
			</form>
		<?php else : ?>
			<p><?php esc_html_e( 'Ninguno registrado.', 'lachinata-core' ); ?></p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Saves the settings or empties the gap log.
	 */
	public static function handle(): void {
		$action = (string) preg_replace( '/^admin_post_/', '', current_action() );
		Screen::check( $action );
		$module = Plugin::instance()->modules()->get( 'shipment' );
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Screen::check().
		if ( self::SAVE === $action && null !== $module ) {
			$statuses = isset( $_POST['notify_statuses'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['notify_statuses'] ) ) : array();
			Settings::set( $module, 'notify_statuses', $statuses ? array_values( $statuses ) : array( 'completed' ) );
			Settings::set( $module, 'whatsapp_optin', ! empty( $_POST['whatsapp_optin'] ) );
			Screen::flash( 'success', array( __( 'Ajustes guardados.', 'lachinata-core' ) ) );
			Screen::redirect( self::TAB );
		}
		// phpcs:enable
		ShipmentModule::gaps()->clear();
		Screen::flash( 'success', array( __( 'Lista vaciada.', 'lachinata-core' ) ) );
		Screen::redirect( self::TAB );
	}
}
