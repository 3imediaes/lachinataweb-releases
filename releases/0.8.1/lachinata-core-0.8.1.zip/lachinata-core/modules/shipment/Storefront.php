<?php
/**
 * The parcel on the order received page and in the account.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipment;

defined( 'ABSPATH' ) || exit;

/**
 * Fills the theme's `lachinata/order/tracking` («Seguir el paquete», carrier and number) and
 * `lachinata/order/status` («En camino» once the order has left: Odoo marks it «Completado»
 * when the parcel leaves, and the carriers do not tell us yet when it arrives).
 */
final class Storefront {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_filter( 'lachinata/order/tracking', array( self::class, 'tracking' ), 10, 2 );
		add_filter( 'lachinata/order/status', array( self::class, 'status' ), 10, 2 );
	}

	/**
	 * Tracking of the order.
	 *
	 * @param mixed $tracking Null.
	 * @param mixed $order    Order.
	 * @return array{url: string, carrier: string, number: string}|null
	 */
	public static function tracking( $tracking, $order = null ): ?array {
		if ( ! $order instanceof \WC_Order ) {
			return is_array( $tracking ) ? $tracking : null;
		}
		$details = Notifier::details( $order );
		return '' === $details['url'] ? null : array(
			'url'     => $details['url'],
			'carrier' => $details['carrier'],
			'number'  => $details['number'],
		);
	}

	/**
	 * «En camino» for a shipped order.
	 *
	 * @param mixed $status Status.
	 * @param mixed $order  Order.
	 * @return array<string, mixed>
	 */
	public static function status( $status, $order = null ): array {
		$status = is_array( $status ) ? $status : array();
		if ( $order instanceof \WC_Order && in_array( $order->get_status(), Notifier::statuses(), true ) ) {
			$status = array(
				'label' => __( 'En camino', 'lachinata-core' ),
				'tone'  => 'info',
			);
		}
		return $status;
	}
}
