<?php
/**
 * Where the visitor receives the order.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping;

defined( 'ABSPATH' ) || exit;

/**
 * Two sources: the customer's shipping address in the WooCommerce session (bag, checkout)
 * and, for cached pages (PromoBar, product page), a destination that does not depend on
 * the session: the `lachinata/shipping/destination` filter (the `locale` module fills it
 * from the `lc_destino` cookie) or the first place of the default zone.
 */
final class Destination {

	/**
	 * Destination for pages that are cached for every visitor.
	 *
	 * @return array{country: string, state: string, postcode: string}
	 */
	public static function visitor(): array {
		/**
		 * Destination of the visitor for cached pages, or null when not known.
		 *
		 * @since 0.4.0
		 *
		 * @param array{country: string, state?: string, postcode?: string}|null $destination Destination.
		 */
		$destination = apply_filters( 'lachinata/shipping/destination', null );
		if ( is_array( $destination ) && ! empty( $destination['country'] ) ) {
			return self::normalize( $destination );
		}
		return self::of_zone( new \WC_Shipping_Zone( Config::default_zone_id() ) );
	}

	/**
	 * Shipping address of the customer in the session, or null when there is no country.
	 *
	 * @return array{country: string, state: string, postcode: string}|null
	 */
	public static function customer(): ?array {
		$customer = function_exists( 'WC' ) ? WC()->customer : null;
		if ( ! $customer instanceof \WC_Customer || '' === $customer->get_shipping_country() ) {
			return null;
		}
		return self::normalize(
			array(
				'country'  => $customer->get_shipping_country(),
				'state'    => $customer->get_shipping_state(),
				'postcode' => $customer->get_shipping_postcode(),
			)
		);
	}

	/**
	 * Destination from a code: «ES», «ES:PM» (WooCommerce) or «ES-PM» (ISO 3166-2).
	 *
	 * @param string $code Code.
	 * @return array{country: string, state: string, postcode: string}|null
	 */
	public static function parse( string $code ): ?array {
		if ( 1 !== preg_match( '/^([A-Za-z]{2})(?:[:-]([A-Za-z0-9]{1,10}))?$/', trim( $code ), $parts ) ) {
			return null;
		}
		return self::normalize(
			array(
				'country' => $parts[1],
				'state'   => $parts[2] ?? '',
			)
		);
	}

	/**
	 * First place of a zone (a country or a country and state), or the store's base location.
	 *
	 * @param \WC_Shipping_Zone $zone Zone.
	 * @return array{country: string, state: string, postcode: string}
	 */
	public static function of_zone( \WC_Shipping_Zone $zone ): array {
		foreach ( $zone->get_zone_locations() as $location ) {
			if ( 'country' === $location->type || 'state' === $location->type ) {
				$parts = explode( ':', (string) $location->code );
				return self::normalize(
					array(
						'country' => $parts[0],
						'state'   => $parts[1] ?? '',
					)
				);
			}
		}
		$base = wc_get_base_location();
		return self::normalize(
			array(
				'country' => (string) $base['country'],
				'state'   => (string) $base['state'],
			)
		);
	}

	/**
	 * Name of the place for messages: the state when the zone names the state, otherwise the country.
	 *
	 * @param string                 $country Country code.
	 * @param string                 $state   State code.
	 * @param \WC_Shipping_Zone|null $zone    Zone of the destination.
	 */
	public static function name( string $country, string $state = '', ?\WC_Shipping_Zone $zone = null ): string {
		$countries = WC()->countries;
		if ( '' !== $state && null !== $zone ) {
			foreach ( $zone->get_zone_locations() as $location ) {
				if ( 'state' === $location->type && $country . ':' . $state === $location->code ) {
					$states = $countries->get_states( $country );
					if ( is_array( $states ) && isset( $states[ $state ] ) ) {
						return html_entity_decode( (string) $states[ $state ] );
					}
				}
			}
		}
		$names = $countries->get_countries();
		return html_entity_decode( (string) ( $names[ $country ] ?? $country ) );
	}

	/**
	 * Uppercase codes and every key present.
	 *
	 * @param array<string, mixed> $destination Destination.
	 * @return array{country: string, state: string, postcode: string}
	 */
	private static function normalize( array $destination ): array {
		return array(
			'country'  => strtoupper( (string) ( $destination['country'] ?? '' ) ),
			'state'    => strtoupper( (string) ( $destination['state'] ?? '' ) ),
			'postcode' => (string) ( $destination['postcode'] ?? '' ),
		);
	}
}
