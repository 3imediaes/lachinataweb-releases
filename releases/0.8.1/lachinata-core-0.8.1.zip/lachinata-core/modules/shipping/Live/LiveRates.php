<?php
/**
 * Live rates: provider registry and the rates of «Tarifa en vivo» instances.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping\Live;

use LaChinata\Core\Modules\Shipping\Config;
use LaChinata\Core\Modules\Shipping\Package;
use LaChinata\Core\Modules\Shipping\Rates;

defined( 'ABSPATH' ) || exit;

/**
 * Registers the method type, keeps the providers and turns a provider's answer into
 * WooCommerce rates with the instance's surcharge and fallback. Providers that read
 * existing rates (an adapter over a plugin's own global method) are asked in
 * `woocommerce_package_rates`, before the shipping conditions run; the rates they take
 * over are removed from every package, so the plugin's method only reaches the customer
 * through the instance.
 */
final class LiveRates {

	/**
	 * Providers of this request.
	 *
	 * @var array<string, RateProvider>|null
	 */
	private static ?array $providers = null;

	/**
	 * Instances whose provider reads existing rates, found in this request.
	 *
	 * @var array<int, array{zone: int, method: \WC_Shipping_Method, provider: RateProvider}>|null
	 */
	private static ?array $reading = null;

	/**
	 * Forgets what this request found (after a configuration change, and in tests).
	 */
	public static function reset(): void {
		self::$providers = null;
		self::$reading   = null;
	}

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_filter( 'woocommerce_shipping_methods', array( self::class, 'register_method' ) );
		add_filter( 'woocommerce_package_rates', array( self::class, 'from_existing_rates' ), 5, 2 );
		add_action( 'wp_enqueue_scripts', array( OctolizeDhlProvider::class, 'dequeue_log_viewer' ), 100 );
		add_filter( 'lachinata/rest/order', array( self::class, 'rest_data' ), 10, 2 );
	}

	/**
	 * `shipping.live` in the `lachinata` object of the REST API, when the order ships with a
	 * live rate: the provider, the carrier service and whether it was the fallback price.
	 *
	 * @param array<string, mixed> $data  Object.
	 * @param \WC_Order            $order Order.
	 * @return array<string, mixed>
	 */
	public static function rest_data( array $data, \WC_Order $order ): array {
		$line = current( $order->get_items( 'shipping' ) );
		$live = $line instanceof \WC_Order_Item_Shipping ? $line->get_meta( '_lc_live' ) : null;
		if ( is_array( $data['shipping'] ?? null ) && is_array( $live ) && $live ) {
			$data['shipping']['live'] = array(
				'provider' => (string) ( $live['provider'] ?? '' ),
				'service'  => (string) ( $live['service'] ?? '' ),
				'fallback' => ! empty( $live['fallback'] ),
			);
		}
		return $data;
	}

	/**
	 * Adds the method type.
	 *
	 * @param array<string, string|object> $methods Method classes by id.
	 * @return array<string, string|object>
	 */
	public static function register_method( array $methods ): array {
		$methods[ LiveRateMethod::ID ] = LiveRateMethod::class;
		return $methods;
	}

	/**
	 * Registered providers by id.
	 *
	 * @return array<string, RateProvider>
	 */
	public static function providers(): array {
		if ( null === self::$providers ) {
			$octolize = new OctolizeDhlProvider();
			$defaults = array( $octolize->id() => $octolize );
			/**
			 * Live rate providers. A new carrier connector (MyDHL API…) registers here and
			 * becomes selectable in every «Tarifa en vivo» instance.
			 *
			 * @since 0.4.0
			 *
			 * @param array<string, RateProvider> $providers Providers by id.
			 */
			$providers       = (array) apply_filters( 'lachinata/shipping/rate_providers', $defaults );
			self::$providers = array_filter( $providers, static fn( $provider ): bool => $provider instanceof RateProvider );
		}
		return self::$providers;
	}

	/**
	 * Provider by id.
	 *
	 * @param string $id Provider id.
	 */
	public static function provider( string $id ): ?RateProvider {
		return self::providers()[ $id ] ?? null;
	}

	/**
	 * Request for a package.
	 *
	 * @param array<string, mixed>             $package  WooCommerce package.
	 * @param LiveOptions                      $options  Instance options.
	 * @param array<string, \WC_Shipping_Rate> $existing Rates other methods calculated.
	 */
	public static function request( array $package, LiveOptions $options, array $existing ): RateRequest {
		$evaluated   = Package::from_wc( $package );
		$destination = (array) ( $package['destination'] ?? array() );
		$countries   = WC()->countries;
		return new RateRequest(
			array(
				'country'  => (string) $countries->get_base_country(),
				'state'    => (string) $countries->get_base_state(),
				'postcode' => (string) $countries->get_base_postcode(),
				'city'     => (string) $countries->get_base_city(),
			),
			array(
				'country'  => (string) ( $destination['country'] ?? '' ),
				'state'    => (string) ( $destination['state'] ?? '' ),
				'postcode' => (string) ( $destination['postcode'] ?? '' ),
				'city'     => (string) ( $destination['city'] ?? '' ),
			),
			$evaluated->weight,
			$options->parcels( $evaluated->weight ),
			(float) ( $package['contents_cost'] ?? $evaluated->amount ),
			get_woocommerce_currency(),
			$options->dutiable,
			$existing
		);
	}

	/**
	 * Rate arguments of an instance for a package (as WC_Shipping_Method::add_rate() takes
	 * them) and the existing rates the answer replaces.
	 *
	 * @param \WC_Shipping_Method              $method   Instance.
	 * @param RateProvider                     $provider Provider.
	 * @param LiveOptions                      $options  Options.
	 * @param array<string, mixed>             $package  WooCommerce package.
	 * @param array<string, \WC_Shipping_Rate> $existing Rates other methods calculated.
	 * @return array{rates: array<int, array{id: string, label: string, cost: float, meta_data: array<string, mixed>}>, consumed: string[]}
	 */
	public static function rates_for( \WC_Shipping_Method $method, RateProvider $provider, LiveOptions $options, array $package, array $existing ): array {
		$response = null;
		try {
			$response = $provider->quote( self::request( $package, $options, $existing ) );
		} catch ( RateException $e ) {
			wc_get_logger()->warning(
				$e->getMessage(),
				array(
					'source'   => 'lachinata-shipping',
					'provider' => $provider->id(),
					'instance' => $method->get_instance_id(),
				)
			);
		}

		$services = array_values( array_filter( $response->services ?? array(), array( $options, 'shows' ) ) );
		$reserve  = array_filter( $services, static fn( Service $service ): bool => null !== $service->fallback_reason );
		if ( $reserve ) {
			// The carrier did not answer and the provider priced the shipment itself. The
			// instance's own reserve price wins: it survives a change of provider.
			Rates::gaps()->record(
				'reserve|' . $method->get_instance_id(),
				sprintf(
					/* translators: 1: provider name, 2: method title, 3: instance id, 4: reason from the carrier. */
					__( '%1$s no obtuvo tarifa del transportista para %2$s (ID %3$d): %4$s', 'lachinata-core' ),
					$provider->label(),
					$method->get_title(),
					$method->get_instance_id(),
					(string) reset( $reserve )->fallback_reason
				)
			);
			if ( null !== $options->fallback ) {
				$services = array_values( array_diff_key( $services, $reserve ) );
			}
		}
		$rates = array();
		$title = (string) $method->get_title();
		foreach ( $services as $service ) {
			if ( strtoupper( $service->currency ) !== get_woocommerce_currency() ) {
				wc_get_logger()->warning(
					sprintf( 'Servicio %1$s en %2$s: la tienda cobra en %3$s.', $service->code, $service->currency, get_woocommerce_currency() ),
					array( 'source' => 'lachinata-shipping' )
				);
				continue;
			}
			$rates[] = array(
				'id'        => LiveRateMethod::ID . ':' . $method->get_instance_id() . ':' . sanitize_key( $service->code ),
				/* translators: 1: method name, 2: carrier service name. */
				'label'     => count( $services ) > 1 ? sprintf( __( '%1$s · %2$s', 'lachinata-core' ), $title, $service->name ) : $title,
				'cost'      => $options->price( $service, wc_get_price_decimals() ),
				'meta_data' => array(
					'_lc_live' => array(
						'provider' => $provider->id(),
						'service'  => $service->code,
						'days_min' => $service->days_min,
						'days_max' => $service->days_max,
					),
				),
			);
		}

		if ( ! $rates && null !== $options->fallback ) {
			$rates[] = array(
				'id'        => LiveRateMethod::ID . ':' . $method->get_instance_id() . ':fallback',
				'label'     => $title,
				'cost'      => $options->fallback,
				'meta_data' => array(
					'_lc_live' => array(
						'provider' => $provider->id(),
						'service'  => '',
						'fallback' => true,
					),
				),
			);
		}

		return array(
			'rates'    => $rates,
			'consumed' => $response->consumed ?? array(),
		);
	}

	/**
	 * Answers the providers that read existing rates: removes the rates they take over
	 * and adds the instance's rates when the package's zone has one.
	 *
	 * @param array<string, \WC_Shipping_Rate> $rates   Rates by id.
	 * @param array<string, mixed>             $package WooCommerce package.
	 * @return array<string, \WC_Shipping_Rate>
	 */
	public static function from_existing_rates( array $rates, array $package ): array {
		$in_use = self::instances_reading_rates();
		if ( ! $in_use ) {
			return $rates;
		}

		$zone_id = (int) \WC_Shipping_Zones::get_zone_matching_package( $package )->get_id();
		$added   = array();
		$remove  = array();
		foreach ( $in_use as $entry ) {
			$options = LiveOptions::from_settings( $entry['method']->instance_settings );
			$result  = self::rates_for( $entry['method'], $entry['provider'], $options, $package, $rates );
			$remove  = array_merge( $remove, $result['consumed'] );
			if ( $entry['zone'] !== $zone_id || ! $entry['method']->is_enabled() ) {
				continue;
			}
			if ( ! $result['consumed'] ) {
				self::record_missing( $entry['method'], $entry['provider'], $rates );
			}
			foreach ( $result['rates'] as $args ) {
				$added[ $args['id'] ] = self::rate( $entry['method'], $args );
			}
		}
		return array_diff_key( $rates, array_flip( $remove ) ) + $added;
	}

	/**
	 * Logs a provider that found none of its rates in the package, with the rate ids that
	 * were there (for checking the Octolize method id on each site).
	 *
	 * @param \WC_Shipping_Method              $method   Instance.
	 * @param RateProvider                     $provider Provider.
	 * @param array<string, \WC_Shipping_Rate> $rates    Rates in the package.
	 */
	private static function record_missing( \WC_Shipping_Method $method, RateProvider $provider, array $rates ): void {
		$present  = array_map( 'strval', array_keys( $rates ) );
		$expected = $provider instanceof OctolizeDhlProvider ? OctolizeDhlProvider::method_ids() : array();
		sort( $present );
		Rates::gaps()->record(
			'live|' . $method->get_instance_id() . '|' . implode( ',', $present ),
			sprintf(
				/* translators: 1: provider name, 2: method title, 3: instance id, 4: expected method ids, 5: rate ids present. */
				__( '%1$s no encontró su tarifa para %2$s (ID %3$d). Métodos buscados: %4$s. Tarifas presentes en el paquete: %5$s.', 'lachinata-core' ),
				$provider->label(),
				$method->get_title(),
				$method->get_instance_id(),
				$expected ? implode( ', ', $expected ) : '—',
				$present ? implode( ', ', $present ) : __( 'ninguna', 'lachinata-core' )
			),
			array(
				'buscados'  => $expected,
				'presentes' => $present,
			)
		);
	}

	/**
	 * «Tarifa en vivo» instances whose provider reads existing rates, in every zone.
	 *
	 * @return array<int, array{zone: int, method: \WC_Shipping_Method, provider: RateProvider}>
	 */
	private static function instances_reading_rates(): array {
		if ( null !== self::$reading ) {
			return self::$reading;
		}
		$found = array();
		foreach ( Config::instances() as $instance ) {
			$method = $instance['method'];
			if ( LiveRateMethod::ID !== $method->id ) {
				continue;
			}
			$provider = self::provider( LiveOptions::from_settings( $method->instance_settings )->provider );
			if ( null !== $provider && $provider->reads_existing_rates() ) {
				$found[] = array(
					'zone'     => (int) $instance['zone']->get_id(),
					'method'   => $method,
					'provider' => $provider,
				);
			}
		}
		self::$reading = $found;
		return $found;
	}

	/**
	 * Rate object with taxes, as WC_Shipping_Method::add_rate() would build it.
	 *
	 * @param \WC_Shipping_Method                                                            $method Instance.
	 * @param array{id: string, label: string, cost: float, meta_data: array<string, mixed>} $args   Rate arguments.
	 */
	private static function rate( \WC_Shipping_Method $method, array $args ): \WC_Shipping_Rate {
		$taxes = $method->is_taxable() ? \WC_Tax::calc_shipping_tax( $args['cost'], \WC_Tax::get_shipping_tax_rates() ) : array();
		$rate  = new \WC_Shipping_Rate( $args['id'], $args['label'], 0, $taxes, LiveRateMethod::ID, (int) $method->get_instance_id() );
		$rate->set_cost( wc_format_decimal( $args['cost'], wc_get_price_decimals() ) );
		foreach ( $args['meta_data'] as $key => $value ) {
			$rate->add_meta_data( $key, $value );
		}
		return $rate;
	}
}
