<?php
/**
 * What the shipping rules look at in a package.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping;

use LaChinata\Core\Modules\Catalog\Fields;

defined( 'ABSPATH' ) || exit;

/**
 * Destination, weight in kg, amount and the products with their shipping classes and the
 * international exclusion flag. Built from a WooCommerce package or from the simulator.
 */
final class Package {

	/**
	 * Builds the package.
	 *
	 * @param string                                                                        $country                 Destination country (ISO 3166-1 alpha-2).
	 * @param string                                                                        $state                   WooCommerce state code (PM, GC…), or ''.
	 * @param string                                                                        $postcode                Postcode, or ''.
	 * @param float                                                                         $weight                  Total weight in kg.
	 * @param float                                                                         $amount                  Product subtotal after discounts, as WooCommerce's free shipping counts it.
	 * @param float                                                                         $amount_before_discounts Product subtotal before discounts.
	 * @param array<int, array{name: string, classes: string[], flag: bool, weight: float}> $products              Products keyed by id.
	 */
	public function __construct(
		public readonly string $country,
		public readonly string $state,
		public readonly string $postcode,
		public readonly float $weight,
		public readonly float $amount,
		public readonly float $amount_before_discounts,
		public readonly array $products,
	) {}

	/**
	 * Shipping class slugs present in the package.
	 *
	 * @return string[]
	 */
	public function classes(): array {
		$classes = array();
		foreach ( $this->products as $product ) {
			$classes = array_merge( $classes, $product['classes'] );
		}
		return array_values( array_unique( $classes ) );
	}

	/**
	 * Amount compared with the conditions.
	 *
	 * @param bool $ignore_discounts Compare the amount before discounts (WooCommerce's «ignore discounts»).
	 */
	public function amount( bool $ignore_discounts ): float {
		return $ignore_discounts ? $this->amount_before_discounts : $this->amount;
	}

	/**
	 * Location code of the destination: «ES:PM», or «DE» without state.
	 */
	public function location(): string {
		return '' === $this->state ? $this->country : $this->country . ':' . $this->state;
	}

	/**
	 * Package from a WooCommerce shipping package. The amount follows the free shipping
	 * method: displayed subtotal (with tax when prices are shown with tax), minus discounts.
	 *
	 * @param array<string, mixed> $package WooCommerce package.
	 */
	public static function from_wc( array $package ): self {
		$destination = is_array( $package['destination'] ?? null ) ? $package['destination'] : array();
		$with_tax    = self::displays_tax();
		$weight      = 0.0;
		$before      = 0.0;
		$after       = 0.0;
		$products    = array();

		foreach ( (array) ( $package['contents'] ?? array() ) as $item ) {
			$product = $item['data'] ?? null;
			if ( ! $product instanceof \WC_Product || ! $product->needs_shipping() ) {
				continue;
			}
			$quantity = (float) ( $item['quantity'] ?? 1 );
			$item_kg  = (float) wc_get_weight( (float) $product->get_weight(), 'kg' ) * $quantity;
			$weight  += $item_kg;
			$before  += (float) ( $item['line_subtotal'] ?? 0 ) + ( $with_tax ? (float) ( $item['line_subtotal_tax'] ?? 0 ) : 0.0 );
			$after   += (float) ( $item['line_total'] ?? 0 ) + ( $with_tax ? (float) ( $item['line_tax'] ?? 0 ) : 0.0 );

			$id = $product->get_id();
			if ( isset( $products[ $id ] ) ) {
				$products[ $id ]['weight'] += $item_kg;
				continue;
			}
			$products[ $id ] = self::product_entry( $product, $item_kg );
		}

		$decimals = wc_get_price_decimals();
		return new self(
			strtoupper( (string) ( $destination['country'] ?? '' ) ),
			strtoupper( (string) ( $destination['state'] ?? '' ) ),
			(string) ( $destination['postcode'] ?? '' ),
			$weight,
			round( $after, $decimals ),
			round( $before, $decimals ),
			$products
		);
	}

	/**
	 * What the rules need from a product.
	 *
	 * @param \WC_Product $product Product or variation.
	 * @param float       $weight  Weight of the line in kg.
	 * @return array{name: string, classes: string[], flag: bool, weight: float}
	 */
	public static function product_entry( \WC_Product $product, float $weight = 0.0 ): array {
		$class     = $product->get_shipping_class();
		$parent_id = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();
		return array(
			'name'    => $product->get_name(),
			'classes' => '' === $class ? array() : array( $class ),
			'flag'    => (bool) Fields::get( $parent_id, Fields::NO_SHIP_ABROAD ),
			'weight'  => $weight,
		);
	}

	/**
	 * Whether the cart shows prices with tax, as the free shipping method checks it.
	 */
	private static function displays_tax(): bool {
		if ( function_exists( 'WC' ) && WC()->cart ) {
			return WC()->cart->display_prices_including_tax();
		}
		return wc_tax_enabled() && 'incl' === get_option( 'woocommerce_tax_display_cart' );
	}
}
