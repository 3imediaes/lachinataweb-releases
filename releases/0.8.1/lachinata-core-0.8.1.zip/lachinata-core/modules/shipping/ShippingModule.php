<?php
/**
 * Module `shipping`: conditions, limits and messages on top of WooCommerce's zones and methods.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping;

use LaChinata\Core\Module;
use LaChinata\Core\Modules\Shipping\Live\LiveOptions;
use LaChinata\Core\Modules\Shipping\Live\LiveRates;

defined( 'ABSPATH' ) || exit;

/**
 * Does not replace WooCommerce's zones and methods: each store creates them in
 * WooCommerce with their instance ids (the ones Odoo reads). The module adds positive
 * conditions per instance, limits and messages per zone, product restrictions per
 * destination and live rates behind a provider interface.
 */
final class ShippingModule extends Module {

	/**
	 * Module id.
	 */
	public function id(): string {
		return 'shipping';
	}

	/**
	 * Module name.
	 */
	public function label(): string {
		return __( 'Envíos', 'lachinata-core' );
	}

	/**
	 * Module description.
	 */
	public function description(): string {
		return __( 'Condiciones por método, límites y mensajes por zona, restricciones de producto por destino y tarifas en vivo, sobre las zonas y métodos de WooCommerce.', 'lachinata-core' );
	}

	/**
	 * Version in which the module was added.
	 */
	public function since(): string {
		return '0.4.0';
	}

	/**
	 * Documentation.
	 */
	public function docs(): string {
		return 'plugin/modules/shipping/README.md';
	}

	/**
	 * Requirements.
	 *
	 * @return array{woocommerce: string}
	 */
	public function requires(): array {
		return array( 'woocommerce' => '10.0' );
	}

	/**
	 * Settings.
	 *
	 * @return array<string, array{type: 'bool'|'int'|'float'|'string'|'array', default: mixed, export?: bool}>
	 */
	public function settings(): array {
		return array(
			'default_zone' => array(
				'type'    => 'int',
				'default' => 0,
			),
		);
	}

	/**
	 * Registers the hooks.
	 */
	public function boot(): void {
		LiveRates::boot();
		Rates::boot();
		Storefront::boot();
		StoreApi::boot();

		if ( is_admin() ) {
			InstanceFields::boot();
			ShippingTab::boot();
			ConflictNotice::boot();
		}

		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::add_command( 'lachinata shipping', SimulateCommand::class );
		}
	}

	/**
	 * Zone rules, restrictions and the conditions and live options of each instance (by id).
	 *
	 * @return array<string, mixed>
	 */
	public function export_data(): array {
		$instances = array();
		foreach ( Config::instances() as $id => $instance ) {
			$settings = array_intersect_key( Config::instance_settings( $instance['method'] ), array_flip( self::instance_keys() ) );
			if ( $settings ) {
				$instances[ (string) $id ] = array(
					'method'   => $instance['method']->id,
					'settings' => $settings,
				);
			}
		}
		$zones = get_option( Config::ZONES, array() );
		return array(
			'zones'        => is_array( $zones ) ? $zones : array(),
			'restrictions' => array_map( static fn( Restriction $r ): array => $r->to_array(), Config::restrictions() ),
			'instances'    => $instances,
		);
	}

	/**
	 * Checks an imported section: instances must exist here with the same method type.
	 *
	 * @param array<string, mixed> $data Section.
	 * @return string[]
	 */
	public function validate_data( array $data ): array {
		$errors = array();
		foreach ( array( 'zones', 'restrictions', 'instances' ) as $key ) {
			if ( isset( $data[ $key ] ) && ! is_array( $data[ $key ] ) ) {
				/* translators: %s: key of the section. */
				$errors[] = sprintf( __( 'Envíos: «%s» debe ser una lista.', 'lachinata-core' ), $key );
			}
		}
		if ( $errors ) {
			return $errors;
		}

		$zone_ids = array_map( 'intval', array_keys( Config::zones() ) );
		foreach ( array_keys( (array) ( $data['zones'] ?? array() ) ) as $zone_id ) {
			if ( ! in_array( (int) $zone_id, $zone_ids, true ) ) {
				/* translators: %d: zone id. */
				$errors[] = sprintf( __( 'Envíos: la zona %d no existe en este sitio.', 'lachinata-core' ), (int) $zone_id );
			}
		}
		foreach ( (array) ( $data['restrictions'] ?? array() ) as $index => $restriction ) {
			if ( ! is_array( $restriction ) || null === Restriction::from_array( $restriction ) ) {
				/* translators: %d: position in the list, from 1. */
				$errors[] = sprintf( __( 'Envíos: la restricción %d no es válida.', 'lachinata-core' ), (int) $index + 1 );
			}
		}
		$instances = Config::instances();
		foreach ( (array) ( $data['instances'] ?? array() ) as $id => $instance ) {
			$here = $instances[ (int) $id ]['method'] ?? null;
			if ( null === $here ) {
				/* translators: %d: instance id. */
				$errors[] = sprintf( __( 'Envíos: el método con ID %d no existe en este sitio.', 'lachinata-core' ), (int) $id );
			} elseif ( ! is_array( $instance ) || ( $instance['method'] ?? '' ) !== $here->id ) {
				/* translators: 1: instance id, 2: method type here. */
				$errors[] = sprintf( __( 'Envíos: el método con ID %1$d es de otro tipo en este sitio (%2$s).', 'lachinata-core' ), (int) $id, $here->id );
			}
		}
		return $errors;
	}

	/**
	 * Writes an imported section.
	 *
	 * @param array<string, mixed> $data Section that passed validate_data().
	 */
	public function import_data( array $data ): void {
		if ( isset( $data['zones'] ) ) {
			$rules = array();
			foreach ( (array) $data['zones'] as $zone_id => $zone ) {
				$rules[] = ZoneRules::from_array( (int) $zone_id, (array) $zone );
			}
			Config::save_zone_rules( $rules );
		}
		if ( isset( $data['restrictions'] ) ) {
			Config::save_restrictions( array_filter( array_map( static fn( $r ): ?Restriction => Restriction::from_array( (array) $r ), (array) $data['restrictions'] ) ) );
		}
		$instances = Config::instances();
		foreach ( (array) ( $data['instances'] ?? array() ) as $id => $instance ) {
			$method = $instances[ (int) $id ]['method'] ?? null;
			if ( null === $method ) {
				continue;
			}
			$values = array_intersect_key( (array) ( $instance['settings'] ?? array() ), array_flip( self::instance_keys() ) );
			update_option( $method->get_instance_option_key(), array_merge( Config::instance_settings( $method ), $values ) );
		}
		Config::changed();
	}

	/**
	 * Instance setting keys owned by this module.
	 *
	 * @return string[]
	 */
	public static function instance_keys(): array {
		return array_merge( Conditions::KEYS, array( InstanceFields::NOTE ), LiveOptions::KEYS );
	}
}
