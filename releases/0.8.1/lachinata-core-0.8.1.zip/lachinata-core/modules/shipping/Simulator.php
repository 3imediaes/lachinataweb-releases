<?php
/**
 * Shipping simulator: what a package would get, without placing an order.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping;

defined( 'ABSPATH' ) || exit;

/**
 * Builds a package from a destination, weight, amount and classes and runs the same
 * evaluator as the cart. Used by the «Probador» of the admin screen and by WP-CLI.
 */
final class Simulator {

	/**
	 * Runs a simulation.
	 *
	 * @param array{country: string, state?: string, postcode?: string, weight: float, amount: float, classes?: string[], flag?: bool} $input Input.
	 * @return array{package: Package, zone: \WC_Shipping_Zone, rules: ZoneRules, decision: Decision, candidates: Candidate[], message: string, eta: array<int, string>}
	 */
	public static function run( array $input ): array {
		$classes  = array_values( array_filter( (array) ( $input['classes'] ?? array() ) ) );
		$products = array();
		foreach ( $classes as $index => $class ) {
			$products[ $index + 1 ] = array(
				/* translators: %s: shipping class slug. */
				'name'    => sprintf( __( 'Producto de la clase %s', 'lachinata-core' ), $class ),
				'classes' => array( $class ),
				'flag'    => false,
				'weight'  => 0.0,
			);
		}
		if ( ! empty( $input['flag'] ) ) {
			$products[ count( $products ) + 1 ] = array(
				'name'    => __( 'Producto con exclusión internacional', 'lachinata-core' ),
				'classes' => array(),
				'flag'    => true,
				'weight'  => 0.0,
			);
		}
		if ( ! $products ) {
			$products[1] = array(
				'name'    => __( 'Producto', 'lachinata-core' ),
				'classes' => array(),
				'flag'    => false,
				'weight'  => 0.0,
			);
		}

		$package = new Package(
			strtoupper( $input['country'] ),
			strtoupper( (string) ( $input['state'] ?? '' ) ),
			(string) ( $input['postcode'] ?? '' ),
			max( 0.0, $input['weight'] ),
			max( 0.0, $input['amount'] ),
			max( 0.0, $input['amount'] ),
			$products
		);

		list( $decision, $zone, $rules ) = Config::evaluate( $package );

		$eta = array();
		foreach ( $decision->offered as $instance_id ) {
			/**
			 * Delivery estimate of an offered instance in the simulator (the eta module answers).
			 *
			 * @since 0.4.0
			 *
			 * @param string            $text        Estimate as text; '' when there is none.
			 * @param int               $instance_id Instance id.
			 * @param Package           $package     Simulated package.
			 * @param \WC_Shipping_Zone $zone        Zone.
			 */
			$eta[ $instance_id ] = (string) apply_filters( 'lachinata/shipping/simulation_eta', '', $instance_id, $package, $zone );
		}

		return array(
			'package'    => $package,
			'zone'       => $zone,
			'rules'      => $rules,
			'decision'   => $decision,
			'candidates' => Config::candidates( $zone ),
			'message'    => Messages::for_decision( $decision, $package, $rules, $zone ),
			'eta'        => $eta,
		);
	}

	/**
	 * A rejection reason for people.
	 *
	 * @param string $reason Reason from Decision::$rejected.
	 */
	public static function reason_label( string $reason ): string {
		if ( str_starts_with( $reason, 'hidden:' ) ) {
			/* translators: %d: instance id. */
			return sprintf( __( 'oculto por el ID %d', 'lachinata-core' ), (int) substr( $reason, 7 ) );
		}
		$labels = array(
			'weight'    => __( 'peso', 'lachinata-core' ),
			'amount'    => __( 'importe', 'lachinata-core' ),
			'classes'   => __( 'clases de envío', 'lachinata-core' ),
			'threshold' => __( 'la zona no tiene umbral de envío gratis', 'lachinata-core' ),
		);
		return $labels[ $reason ] ?? $reason;
	}
}
