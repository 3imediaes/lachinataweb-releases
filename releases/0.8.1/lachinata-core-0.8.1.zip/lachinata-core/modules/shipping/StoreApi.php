<?php
/**
 * The shipping state of the bag in the Store API.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping;

defined( 'ABSPATH' ) || exit;

/**
 * Adds `extensions['lachinata-shipping']` to the cart of the Store API: what the bag
 * shows as notices (Storefront::state()), the cart items that cannot travel and the
 * rates a weight limit leaves out. The block checkout reads it (module `checkout`);
 * texts come ready, prices as numbers in minor units like the rest of the Store API.
 */
final class StoreApi {

	/**
	 * Namespace of the data.
	 */
	public const NAMESPACE = 'lachinata-shipping';

	/**
	 * Registers the data once WooCommerce's blocks are loaded.
	 */
	public static function boot(): void {
		if ( did_action( 'woocommerce_blocks_loaded' ) ) {
			self::register();
			return;
		}
		add_action( 'woocommerce_blocks_loaded', array( self::class, 'register' ) );
	}

	/**
	 * Registers the cart data.
	 */
	public static function register(): void {
		if ( ! function_exists( 'woocommerce_store_api_register_endpoint_data' ) ) {
			return;
		}
		woocommerce_store_api_register_endpoint_data(
			array(
				'endpoint'        => 'cart', // CartSchema::IDENTIFIER.
				'namespace'       => self::NAMESPACE,
				'data_callback'   => array( self::class, 'data' ),
				'schema_callback' => array( self::class, 'schema' ),
				'schema_type'     => ARRAY_A,
			)
		);
	}

	/**
	 * The data.
	 *
	 * @return array{notice: string, cause: string|null, message: string, free: array{tone: string, text: string}|null, restricted: array<int, array{key: string, name: string}>, unavailable: array<int, array{title: string, price: int, reason: string}>}
	 */
	public static function data(): array {
		$state = Storefront::state();
		return array(
			'notice'      => $state['notice'],
			'cause'       => $state['cause'],
			'message'     => $state['message'],
			'free'        => $state['free'],
			'restricted'  => self::restricted_items( $state['restricted'] ),
			'unavailable' => array_map(
				static fn( array $rate ): array => array(
					'title'  => $rate['title'],
					'price'  => (int) round( $rate['cost'] * ( 10 ** wc_get_price_decimals() ) ),
					'reason' => $rate['reason'],
				),
				Rates::unavailable()
			),
		);
	}

	/**
	 * Cart items of the products that cannot ship to the destination.
	 *
	 * @param array<int, string> $products Product id → name.
	 * @return array<int, array{key: string, name: string}>
	 */
	private static function restricted_items( array $products ): array {
		$cart = WC()->cart;
		if ( ! $products || ! $cart instanceof \WC_Cart ) {
			return array();
		}
		$items = array();
		foreach ( $cart->get_cart() as $key => $item ) {
			$product = $item['data'] ?? null;
			if ( ! $product instanceof \WC_Product ) {
				continue;
			}
			$ids = array( (int) $product->get_id(), (int) $product->get_parent_id() );
			foreach ( $ids as $id ) {
				if ( isset( $products[ $id ] ) ) {
					$items[] = array(
						'key'  => (string) $key,
						'name' => (string) $product->get_name(),
					);
					break;
				}
			}
		}
		return $items;
	}

	/**
	 * Schema of the data.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public static function schema(): array {
		$text = array(
			'type'     => 'string',
			'context'  => array( 'view', 'edit' ),
			'readonly' => true,
		);
		return array(
			'notice'      => array_merge( $text, array( 'description' => __( 'Aviso informativo de la zona de destino.', 'lachinata-core' ) ) ),
			'cause'       => array_merge(
				$text,
				array(
					'type'        => array( 'string', 'null' ),
					'description' => __( 'Causa cuando no hay envío (zona_no_cubierta, producto_restringido, peso_max, importe, sin_metodo).', 'lachinata-core' ),
				)
			),
			'message'     => array_merge( $text, array( 'description' => __( 'Motivo para el cliente cuando no hay envío.', 'lachinata-core' ) ) ),
			'free'        => array(
				'description' => __( 'Aviso del umbral de envío gratis (tono y texto).', 'lachinata-core' ),
				'type'        => array( 'object', 'null' ),
				'context'     => array( 'view', 'edit' ),
				'readonly'    => true,
			),
			'restricted'  => array(
				'description' => __( 'Líneas de la bolsa que no se pueden enviar al destino.', 'lachinata-core' ),
				'type'        => 'array',
				'context'     => array( 'view', 'edit' ),
				'readonly'    => true,
			),
			'unavailable' => array(
				'description' => __( 'Envíos que no se ofrecen por el límite de peso, con precio (unidades menores) y motivo.', 'lachinata-core' ),
				'type'        => 'array',
				'context'     => array( 'view', 'edit' ),
				'readonly'    => true,
			),
		);
	}
}
