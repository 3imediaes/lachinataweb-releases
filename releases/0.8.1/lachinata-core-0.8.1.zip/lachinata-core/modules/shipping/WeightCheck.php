<?php
/**
 * Products that ship without a weight.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping;

defined( 'ABSPATH' ) || exit;

/**
 * A product without weight counts as 0 kg in the conditions. The «Huecos» section lists
 * how many there are, with a link to the product list filtered by them.
 */
final class WeightCheck {

	/**
	 * Query argument of the filtered product list.
	 */
	public const QUERY_VAR = 'lc_sin_peso';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_action( 'pre_get_posts', array( self::class, 'filter_list' ) );
	}

	/**
	 * Ids of the products to fix: shippable products without weight and variable products
	 * with a variation that has no weight of its own nor from its parent.
	 *
	 * @return int[]
	 */
	public static function missing_ids(): array {
		$no_weight = array(
			'relation' => 'OR',
			array(
				'key'     => '_weight',
				'compare' => 'NOT EXISTS',
			),
			array(
				'key'   => '_weight',
				'value' => '',
			),
		);
		$shipping  = array(
			'key'     => '_virtual',
			'value'   => 'yes',
			'compare' => '!=',
		);

		$products = get_posts(
			array(
				'post_type'      => 'product',
				'post_status'    => array( 'publish', 'private', 'draft', 'pending' ),
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_query'     => array( $no_weight, $shipping ), // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Admin report.
				'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- Admin report.
					array(
						'taxonomy' => 'product_type',
						'field'    => 'slug',
						'terms'    => array( 'variable', 'grouped', 'external' ),
						'operator' => 'NOT IN',
					),
				),
			)
		);

		$variable_parents = get_posts(
			array(
				'post_type'      => 'product',
				'post_status'    => array( 'publish', 'private', 'draft', 'pending' ),
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'meta_query'     => array( $no_weight ), // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Admin report.
				'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- Admin report.
					array(
						'taxonomy' => 'product_type',
						'field'    => 'slug',
						'terms'    => array( 'variable' ),
					),
				),
			)
		);
		$variations       = $variable_parents ? get_posts(
			array(
				'post_type'       => 'product_variation',
				'post_status'     => array( 'publish', 'private' ),
				'posts_per_page'  => -1,
				'post_parent__in' => $variable_parents,
				'fields'          => 'ids',
				'meta_query'      => array( $no_weight, $shipping ), // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Admin report.
			)
		) : array();

		$parents = array_map( static fn( $id ): int => (int) wp_get_post_parent_id( (int) $id ), $variations );
		$ids     = array_unique( array_merge( array_map( 'intval', $products ), array_filter( $parents ) ) );
		sort( $ids );
		return $ids;
	}

	/**
	 * Admin URL of the product list with only those products.
	 */
	public static function list_url(): string {
		return add_query_arg(
			array(
				'post_type'     => 'product',
				self::QUERY_VAR => '1',
			),
			admin_url( 'edit.php' )
		);
	}

	/**
	 * Restricts the admin product list when the query argument is present.
	 *
	 * @param \WP_Query $query Query.
	 */
	public static function filter_list( \WP_Query $query ): void {
		if ( ! is_admin() || ! $query->is_main_query() || 'product' !== $query->get( 'post_type' ) || empty( $_GET[ self::QUERY_VAR ] ) || ! current_user_can( 'edit_products' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- List filter.
			return;
		}
		$ids = self::missing_ids();
		$query->set( 'post__in', $ids ? $ids : array( 0 ) );
	}
}
