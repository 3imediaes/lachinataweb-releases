<?php
/**
 * La Chinata → Módulos.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Admin;

use LaChinata\Core\Plugin;

defined( 'ABSPATH' ) || exit;

/**
 * Switches modules on and off, with the version that added each one and where it is documented.
 */
final class ModulesTab {

	/**
	 * Action of admin-post.php, also the nonce action.
	 */
	private const ACTION = 'lachinata_save_modules';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_action( 'admin_post_' . self::ACTION, array( self::class, 'save' ) );
	}

	/**
	 * Prints the tab.
	 */
	public static function render(): void {
		$registry = Plugin::instance()->modules();
		$enabled  = $registry->enabled();
		?>
		<p><?php esc_html_e( 'Un módulo apagado no ejecuta nada. Los cambios se aplican al guardar.', 'lachinata-core' ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>">
			<?php wp_nonce_field( self::ACTION ); ?>
			<table class="widefat striped lc-admin__modules">
				<thead>
					<tr>
						<th scope="col"><?php esc_html_e( 'Módulo', 'lachinata-core' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Activo', 'lachinata-core' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Añadido en', 'lachinata-core' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Documentación', 'lachinata-core' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $registry->all() as $id => $module ) : ?>
						<?php
						$is_on   = in_array( $id, $enabled, true );
						$missing = $registry->missing_requirements( $module );
						?>
						<tr>
							<th scope="row">
								<label for="lc-module-<?php echo esc_attr( $id ); ?>"><strong><?php echo esc_html( $module->label() ); ?></strong> <code><?php echo esc_html( $id ); ?></code></label>
								<?php if ( $module->description() ) : ?>
									<p class="description"><?php echo esc_html( $module->description() ); ?></p>
								<?php endif; ?>
								<?php if ( $missing ) : ?>
									<p class="lc-admin__missing">
										<?php
										echo esc_html(
											$is_on
												/* translators: %s: unmet requirements. */
												? sprintf( __( 'Activado, pero no se ejecuta: %s', 'lachinata-core' ), implode( ' ', $missing ) )
												: implode( ' ', $missing )
										);
										?>
									</p>
								<?php endif; ?>
							</th>
							<td><input type="checkbox" id="lc-module-<?php echo esc_attr( $id ); ?>" name="modules[]" value="<?php echo esc_attr( $id ); ?>"<?php checked( $is_on ); ?>></td>
							<td><?php echo esc_html( $module->since() ); ?></td>
							<td><code><?php echo esc_html( $module->docs() ); ?></code></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<?php submit_button( __( 'Guardar cambios', 'lachinata-core' ) ); ?>
		</form>
		<?php
	}

	/**
	 * Saves the enabled modules. Ids of modules this installation does not know are kept.
	 */
	public static function save(): void {
		Screen::check( self::ACTION );
		$registry = Plugin::instance()->modules();
		$checked  = isset( $_POST['modules'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['modules'] ) ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Screen::check().
		foreach ( $registry->all() as $id => $module ) {
			if ( in_array( $id, $checked, true ) ) {
				$registry->enable( $id );
			} else {
				$registry->disable( $id );
			}
		}
		Screen::flash( 'success', array( __( 'Módulos guardados.', 'lachinata-core' ) ) );
		Screen::redirect( 'modules' );
	}
}
