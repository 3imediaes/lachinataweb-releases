<?php
/**
 * WP-CLI: wp lachinata module.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Cli;

use LaChinata\Core\Plugin;
use WP_CLI;

defined( 'ABSPATH' ) || exit;

/**
 * Lists, enables and disables modules (same as WooCommerce → La Chinata → Módulos).
 */
final class ModuleCommand {

	/**
	 * Lists the modules and their state.
	 *
	 * ## OPTIONS
	 *
	 * [--format=<format>]
	 * : table, json or csv.
	 * ---
	 * default: table
	 * ---
	 *
	 * @param string[]              $args       Positional arguments.
	 * @param array<string, string> $assoc_args Named arguments.
	 */
	public function list( array $args, array $assoc_args ): void {
		$modules = Plugin::instance()->modules();
		$rows    = array();
		foreach ( $modules->all() as $id => $module ) {
			$rows[] = array(
				'id'      => $id,
				'label'   => $module->label(),
				'enabled' => in_array( $id, $modules->enabled(), true ) ? 'yes' : 'no',
				'active'  => $modules->is_active( $id ) ? 'yes' : 'no',
				'missing' => implode( ' ', $modules->missing_requirements( $module ) ),
			);
		}
		WP_CLI\Utils\format_items( $assoc_args['format'] ?? 'table', $rows, array( 'id', 'label', 'enabled', 'active', 'missing' ) );
	}

	/**
	 * Enables a module.
	 *
	 * ## OPTIONS
	 *
	 * <id>
	 * : Module id.
	 *
	 * @param string[] $args Positional arguments.
	 */
	public function enable( array $args ): void {
		$this->assert_exists( $args[0] );
		Plugin::instance()->modules()->enable( $args[0] );
		WP_CLI::success( sprintf( 'Módulo %s activado.', $args[0] ) );
	}

	/**
	 * Disables a module.
	 *
	 * ## OPTIONS
	 *
	 * <id>
	 * : Module id.
	 *
	 * @param string[] $args Positional arguments.
	 */
	public function disable( array $args ): void {
		$this->assert_exists( $args[0] );
		Plugin::instance()->modules()->disable( $args[0] );
		WP_CLI::success( sprintf( 'Módulo %s desactivado.', $args[0] ) );
	}

	/**
	 * Stops with an error when the module does not exist.
	 *
	 * @param string $id Module id.
	 */
	private function assert_exists( string $id ): void {
		if ( null === Plugin::instance()->modules()->get( $id ) ) {
			WP_CLI::error( sprintf( 'No existe el módulo %s.', $id ) );
		}
	}
}
