<?php
/**
 * Base class for every module.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core;

defined( 'ABSPATH' ) || exit;

/**
 * A feature that each site can switch on or off. Nothing in a module runs until boot().
 */
abstract class Module {

	/**
	 * Unique identifier, also used in hooks and options (`lachinata_<id>_*`).
	 */
	abstract public function id(): string;

	/**
	 * Human readable name for the admin screen.
	 */
	abstract public function label(): string;

	/**
	 * Short description for the admin screen.
	 */
	public function description(): string {
		return '';
	}

	/**
	 * Requirements: other module ids and the minimum WooCommerce version.
	 *
	 * @return array{modules?: string[], woocommerce?: string}
	 */
	public function requires(): array {
		return array();
	}

	/**
	 * Plugin version in which the module was added.
	 */
	abstract public function since(): string;

	/**
	 * Where the module is documented, as a path relative to the repository root.
	 */
	abstract public function docs(): string;

	/**
	 * Settings of the module, stored in `lachinata_<id>_<key>` options.
	 * `export => false` keeps a setting out of the JSON (site-specific values).
	 *
	 * @return array<string, array{type: 'bool'|'int'|'float'|'string'|'array', default: mixed, export?: bool}>
	 */
	public function settings(): array {
		return array();
	}

	/**
	 * Extra configuration of the module for the JSON export (beyond its settings).
	 *
	 * @return array<string, mixed>
	 */
	public function export_data(): array {
		return array();
	}

	/**
	 * Problems with an imported `data` section, as readable messages. Nothing is written
	 * when this returns messages.
	 *
	 * @param array<string, mixed> $data Section exported by export_data() on another site.
	 * @return string[]
	 */
	public function validate_data( array $data ): array {
		return $data ? array( __( 'Este módulo no importa datos propios.', 'lachinata-core' ) ) : array();
	}

	/**
	 * Writes an imported `data` section that passed validate_data().
	 *
	 * @param array<string, mixed> $data Section exported by export_data() on another site.
	 */
	public function import_data( array $data ): void {
		unset( $data );
	}

	/**
	 * Registers the module hooks. Called once, on `plugins_loaded`, only when enabled.
	 */
	abstract public function boot(): void;
}
