<?php
/**
 * Module registry.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Keeps the known modules, which ones are enabled on this site and which ones booted.
 */
final class ModuleRegistry {

	/**
	 * Option that stores the enabled module ids.
	 */
	public const OPTION = 'lachinata_core_modules';

	/**
	 * Modules enabled when the plugin is activated for the first time.
	 */
	public const DEFAULTS = array( 'catalog' );

	/**
	 * Registered modules, keyed by id.
	 *
	 * @var array<string, Module>
	 */
	private array $modules = array();

	/**
	 * Ids of the modules that booted in this request.
	 *
	 * @var array<string, true>
	 */
	private array $booted = array();

	/**
	 * Adds a module to the registry.
	 *
	 * @param Module $module Module instance.
	 */
	public function register( Module $module ): void {
		$this->modules[ $module->id() ] = $module;
	}

	/**
	 * All registered modules.
	 *
	 * @return array<string, Module>
	 */
	public function all(): array {
		return $this->modules;
	}

	/**
	 * Module by id.
	 *
	 * @param string $id Module id.
	 */
	public function get( string $id ): ?Module {
		return $this->modules[ $id ] ?? null;
	}

	/**
	 * Ids enabled on this site.
	 *
	 * @return string[]
	 */
	public function enabled(): array {
		$enabled = get_option( self::OPTION, array() );
		return is_array( $enabled ) ? array_values( array_filter( $enabled, 'is_string' ) ) : array();
	}

	/**
	 * Whether a module booted in this request (enabled and with its requirements met).
	 *
	 * @param string $id Module id.
	 */
	public function is_active( string $id ): bool {
		return isset( $this->booted[ $id ] );
	}

	/**
	 * Enables a module.
	 *
	 * @param string $id Module id.
	 */
	public function enable( string $id ): void {
		update_option( self::OPTION, array_values( array_unique( array_merge( $this->enabled(), array( $id ) ) ) ) );
	}

	/**
	 * Disables a module.
	 *
	 * @param string $id Module id.
	 */
	public function disable( string $id ): void {
		update_option( self::OPTION, array_values( array_diff( $this->enabled(), array( $id ) ) ) );
	}

	/**
	 * Unmet requirements of a module, as readable messages.
	 *
	 * @param Module $module Module.
	 * @return string[]
	 */
	public function missing_requirements( Module $module ): array {
		$missing  = array();
		$requires = $module->requires();
		$enabled  = $this->enabled();

		foreach ( $requires['modules'] ?? array() as $dependency ) {
			if ( ! in_array( $dependency, $enabled, true ) ) {
				/* translators: %s: module id. */
				$missing[] = sprintf( __( 'Necesita el módulo %s.', 'lachinata-core' ), $dependency );
			}
		}

		if ( isset( $requires['woocommerce'] ) && ( ! defined( 'WC_VERSION' ) || version_compare( WC_VERSION, $requires['woocommerce'], '<' ) ) ) {
			/* translators: %s: WooCommerce version. */
			$missing[] = sprintf( __( 'Necesita WooCommerce %s o superior.', 'lachinata-core' ), $requires['woocommerce'] );
		}

		return $missing;
	}

	/**
	 * Boots every enabled module whose requirements are met.
	 */
	public function boot_enabled(): void {
		foreach ( $this->enabled() as $id ) {
			$module = $this->get( $id );
			if ( null === $module || isset( $this->booted[ $id ] ) || $this->missing_requirements( $module ) ) {
				continue;
			}
			$module->boot();
			$this->booted[ $id ] = true;
		}
	}
}
