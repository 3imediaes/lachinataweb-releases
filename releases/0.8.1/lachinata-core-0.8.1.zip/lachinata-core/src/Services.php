<?php
/**
 * Shared services that modules offer each other.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core;

defined( 'ABSPATH' ) || exit;

/**
 * A module never builds another module's classes: it asks here for the interface in
 * Contracts/, which the serving module fills with a filter while it is on, and checks it
 * is there.
 */
final class Services {

	/**
	 * Short notices by WhatsApp or SMS (module `notify`), or null when it is off.
	 */
	public static function notifier(): ?Contracts\Notifier {
		/**
		 * The notifier of the site (module `notify`).
		 *
		 * @since 0.8.0
		 *
		 * @param Contracts\Notifier|null $notifier Null while no module serves it.
		 */
		$notifier = apply_filters( 'lachinata/notify/service', null );
		return $notifier instanceof Contracts\Notifier ? $notifier : null;
	}

	/**
	 * The newsletter provider (module `newsletter`), or null when it is off.
	 */
	public static function newsletter(): ?Contracts\Newsletter {
		/**
		 * The newsletter service of the site (module `newsletter`).
		 *
		 * @since 0.8.0
		 *
		 * @param Contracts\Newsletter|null $newsletter Null while no module serves it.
		 */
		$newsletter = apply_filters( 'lachinata/newsletter/service', null );
		return $newsletter instanceof Contracts\Newsletter ? $newsletter : null;
	}
}
