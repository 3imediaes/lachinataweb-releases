# Huecos del tema (contrato con lachinata-core)

El tema nunca llama al plugin: pregunta `lachinata_module( 'x' )` y deja estos huecos. La API del plugin (servicios entre módulos, hooks del núcleo y de los módulos, REST y metadatos) está en [`plugin/HOOKS.md`](../plugin/HOOKS.md). «Desde» y «Obsoleto desde» siguen las reglas de ese documento: lo obsoleto se mantiene como alias al menos una versión menor. Cada filtro tiene un valor por defecto neutro, de modo que con WooCommerce de serie el tema funciona (sin tintas, sin precio por unidad, sin pestañas extra). Lo que cambia entre tiendas no vive en el tema: entra por estos filtros o por los menús.

## Filtros

| Hook | Valor por defecto | Quién lo rellena | Desde | Obsoleto desde |
| --- | --- | --- | --- | --- |
| `lachinata/category/tint` `( string $tint, WP_Term $term )` | `''` (sin tinta: `surface-2`/`surface-3`) | `catalog` (`_lc_tint`, heredado) | 0.2.0 | — |
| `lachinata/product/tint` `( string $tint, WC_Product $product )` | `''` | `catalog` (categoría más profunda) | 0.2.0 | — |
| `lachinata/product/unit_price` `( string $html, WC_Product $product )` | `''` | `catalog` («500 ml \| 9,33 € / 1 l»; producto o variación) | 0.2.0 | — |
| `lachinata/product_card/badges` `( array $badges, WC_Product $product )` | oferta + etiquetas de producto | `catalog` antepone la «etiqueta» (tono neutro) | 0.2.0 | — |
| `lachinata/product/tabs` `( array $tabs, WC_Product $product )` | Descripción | `catalog` añade Ingredientes e imagen de descripción. «Opiniones» la añade el tema después. | 0.2.0 | — |
| `lachinata/product/seals` `( array $seals, WC_Product $product )` | `[]` | `catalog` (taxonomía `tipo` con icono) | 0.2.0 | — |
| `lachinata/product/details` `( array $rows, WC_Product $product )` | `[]` | `catalog` (consumo preferente) | 0.2.0 | — |
| `lachinata/product/availability` `( array{tone,text} $availability, WC_Product $product )` | «Disponible», «Quedan N unidades», «Agotado por ahora.» | `eta`: «Disponible. Pídelo antes de las 16:00 y lo recibes el jueves 24.» (un script lo refresca y añade la cuenta atrás) | 0.2.0 | — |
| `lachinata/product/routine_ids` `( int[] $ids, WC_Product $product )` | ventas cruzadas o populares de la misma subcategoría (con menos de dos, la sección no se pinta) | — | 0.2.0 | — |
| `lachinata/cart/line_note` `( string $note, array $item )` | `''` | `shipping`: «No se envía a Alemania» (restricción de producto en el destino del cliente); con la causa `peso_max`, «Pesa 2,4 kg» en cada línea que se envía | 0.2.0 | — |
| `lachinata/cart/shipping_summary` `( string $html, WC_Cart $cart )` | «Se calcula con tu dirección» | `shipping`: «Envío estándar · 4,13 € · Llega jue 24 – vie 25 oct» (método elegido, precio y fecha de `eta`) | 0.4.0 | — |
| `lachinata/promo_bar/messages` `( array $messages )` | menú «promo» | `shipping`: antepone «Envío gratis desde 60 €» (umbral de la zona del visitante) o rellena `{envio_gratis}` si un mensaje lo usa | 0.2.0 | — |
| `lachinata/usp/items` `( array $items, string $layout )` | menú «usp» | `shipping`: rellena `{envio_gratis}` en título y texto; sin umbral, quita el elemento | 0.2.0 | — |
| `lachinata/home/category_sections` `( array $tree )` | todas las categorías padre | — | 0.2.0 | — |
| `lachinata/thankyou/delivery` `( string $title, WC_Order $order )` | nombre del método de envío | `eta`: «Llega jue 24 – vie 25 oct» (titular del bloque de entrega de gracias) | 0.5.0 | — |
| `lachinata/order/tracking` `( ?array $tracking, WC_Order $order )` | `null` (`url`, `carrier`, `number`) | `shipment`: «Seguir el paquete» en gracias y en Mi cuenta → Pedidos | 0.8.0 | — |
| `lachinata/order/status` `( array $status, WC_Order $order )` | nombre de estado de WooCommerce y tono del `Badge` | `shipment`: «En camino» (`info`) una vez enviado | 0.8.0 | — |
| `lachinata/thankyou/product_ids` `( int[] $ids, WC_Order $order )` | ventas cruzadas de lo comprado o, sin ellas, los más vendidos de su categoría | — | 0.5.0 | — |
| `lachinata/footer/copyright` `( string $text )` | «© año Nombre del sitio» | — | 0.2.0 | — |
| `lachinata/contact` `( array $contact )` | vacío (`phone`, `whatsapp`, `email`, `hours`, `phone_url`, `whatsapp_url`) | núcleo del plugin: «Atención al cliente» (WooCommerce → La Chinata). Lo leen los correos; los menús `usp` y `promo` admiten `{telefono}`, `{whatsapp}`, `{correo}` y `{horario}` | 0.8.0 | — |
| `lachinata/product/content` `( string $content, WC_Product $product )` | `''` | `catalog` («500 ml»): segunda línea de los productos en los correos | 0.8.0 | — |
| `lachinata/checkout/wallets` `( bool $wallets )` | `false`: la página de pago de un pedido y el correo del pedido telefónico dicen «con tarjeta o PayPal» | `checkout`: `true` con el pago exprés de Stripe activo en el checkout. El correo nombra Apple Pay y Google Pay; la página, solo cuando su fila aparece (dispositivo con cartera) | 0.8.1 | — |

## Acciones

| Hook | Dónde | Quién | Desde | Obsoleto desde |
| --- | --- | --- | --- | --- |
| `lachinata/nav_drawer/utilities` | final de las utilidades del menú lateral | `locale`: «España / Península · Español» | 0.2.0 | — |
| `lachinata/footer/legal` | principio de la línea legal del pie | `locale`: destino e idioma | 0.2.0 | — |
| `lachinata/footer/newsletter` | bloque de newsletter del pie (no se pinta si nadie engancha) | `newsletter`: título, texto, formulario (sin JS) y consentimiento | 0.2.0 | — |
| `lachinata/cart/notices` | encima del resumen de la bolsa (página y sheet) | `shipping`: aviso informativo de la zona, motivo cuando no hay envío y «Te faltan X € para el envío gratis» | 0.2.0 | — |
| `lachinata/thankyou/account` `( WC_Order $order )` | gracias, tras «Seguir el pedido» | `checkout`: «Hemos creado tu cuenta…» o «Guarda tus datos para la próxima vez» con «Crear mi cuenta» | 0.5.0 | — |
| `lachinata/thankyou/invoice` `( WC_Order $order )` | gracias, tras la cuenta | `checkout`: «¿Necesitas factura con NIF?» (Empresa y NIF después de pagar) o los datos de factura ya guardados | 0.6.0 | — |
| `lachinata/thankyou/gift` `( WC_Order $order )` | gracias, bajo la fecha de entrega (antes de «Seguir el pedido») | `gift`: «Es un regalo para María» y cómo se le avisará | 0.7.0 | — |

## Correos

Todos los correos salen del marco del tema (`theme/inc/emails.php`, `woocommerce/emails/*.php`; `design-system/sistema/06-correos.md`). El tema lo declara con `lachinata/email/frame` (`true`); un módulo que pinta piezas lo comprueba y, sin marco (otro tema), escribe su contenido donde lo dejan las plantillas de WooCommerce.

| Hook | Tipo | Valor por defecto | Quién lo rellena | Desde | Obsoleto desde |
| --- | --- | --- | --- | --- | --- |
| `lachinata/email/frame` `( bool $frame )` | filtro | `false`; el tema, `true` | tema | 0.8.0 | — |
| `lachinata/email/intro` `( array $intro, ?WC_Email $email )` | filtro | `eyebrow`, `title`, `lead`, `preheader` del inventario | `eta` (preheader con la fecha), `gift` (aviso al destinatario), `shipment` (transportista en la entradilla) | 0.8.0 | — |
| `lachinata/email/facts` `( array $facts, ?WC_Order $order, ?WC_Email $email )` | filtro | por correo: `delivery`, `address`, `payment`… (`label`, `value`, `note`; 3 como máximo, los vacíos no dejan hueco) | `eta` (entrega estimada, «ETA»), `gift`, `shipment` (llega, transportista y número) | 0.8.0 | — |
| `lachinata/email/button` `( ?array $button, ?WC_Email $email )` | filtro | «Ver mi pedido», «Pagar {total}», «Volver a la tienda», «Abrir en WooCommerce»… (`label`, `url`, `variant`) | `gift` (secundario), `shipment` («Seguir el paquete») | 0.8.0 | — |
| `lachinata/email/layout` `( array $layout, ?WC_Email $email )` | filtro | `lines` (`full`, `compact`, `none`), `totals`, `addresses`, `help`, `instructions` | `gift` (aviso al destinatario: nada del pedido) | 0.8.0 | — |
| `lachinata/email/subject` `( string $subject, WC_Email $email )` | filtro | asunto del inventario (si la tienda no ha escrito el suyo) | `gift` («· regalo» en el interno) | 0.8.0 | — |
| `lachinata/email/shipping_label` `( string $label, WC_Order_Item_Shipping $line, WC_Order $order )` | filtro | nombre del método | `eta` («Envío estándar · jue 24 – vie 25 oct») | 0.8.0 | — |
| `lachinata/email/footer_note` `( string $html, ?WC_Email $email )` | filtro | por qué recibe el correo | `gift` (aviso al destinatario: nada) | 0.8.0 | — |
| `lachinata/email/footer_line` `( string $html, ?WC_Email $email )` | filtro | «La Chinata · {ciudad}, {provincia} · desde 1932» (HTML: solo enlaces) | `gift` («· ¿Qué es La Chinata?» en el aviso al destinatario) | 0.8.0 | — |
| `lachinata/email/footer_links` `( ?array $links, ?WC_Email $email )` | filtro | `null`: el menú «Pie de correos» o «Mi cuenta»; los internos, ninguno | `gift` (ninguno en el aviso al destinatario) | 0.8.0 | — |
| `lachinata/email/pay_today` `( string $html, WC_Order $order )` | filtro | `''` (la nota del pedido telefónico dice solo «La fecha de entrega empieza a contar cuando pagues») | `eta` («Si lo pagas hoy, llega …») | 0.8.0 | — |
| `lachinata/order/payment_label` `( string $label, WC_Order $order )` | filtro | título de la pasarela sin lo que va entre paréntesis (cuenta o correo) | `checkout` («Tarjeta ···· 4242», «Apple Pay», «Google Pay») | 0.8.0 | — |
| `lachinata/email/after_title` `( ?WC_Order $order, ?WC_Email $email )` | acción | — | `gift` (etiqueta «Regalo» en el interno) | 0.8.0 | — |
| `lachinata/email/before_lines` `( WC_Order $order, ?WC_Email $email )` | acción | — | `gift` (nota del regalo) | 0.8.0 | — |

Las acciones imprimen HTML con las clases del marco, que el tema viste y WooCommerce pasa a estilos en línea: `lc-mail-note` (`__cell`, `__title`, `__text`), `lc-mail-badges` + `lc-mail-badge`, `lc-mail-text`, `lc-mail-caption`. Los correos en texto plano siguen con las plantillas de WooCommerce (con los asuntos del marco). El «Contenido adicional» de cada correo no se imprime.

## Checkout de bloques

El checkout lo pinta React (bloque de WooCommerce), así que aquí los huecos no son hooks de PHP:

- Sin indicador de pasos (retirado el 23/10/2026: en una página el scroll ya orienta).
- **Después del envío** y **resumen**: *slots* JS `lachinata/checkout/after-shipping` y `lachinata/checkout/summary` del módulo `checkout` (bloque `lachinata/checkout-after-shipping` y *fill* en `ExperimentalOrderMeta`). Un módulo los rellena con `wc.blocksCheckout.createSlotFill( nombre ).Fill` y registra sus campos y su script en la acción PHP `lachinata/checkout/after_shipping`, que no imprime nada. Ver `plugin/modules/checkout/README.md`.
- **Casilla del aviso de envío por WhatsApp (`shipment`):** el script del módulo pone `lc-gift-open` en `<body>` mientras «Es un regalo» está marcado; `checkout.css` oculta entonces `.wc-block-components-address-form__lachinata-shipment-whatsapp`.
- **CSS que el tema da por hecho del módulo:** `.lc-billing` (bloque de facturación propio: con él se ocultan la casilla nativa y los títulos de facturación e «Información del pedido»), `.lc-checkout-shipping--cause` (hay motivo de «sin envío»: el tema oculta el aviso genérico de WooCommerce), `.lc-checkout__outlets`, `.lc-checkout__actions`, `.lc-checkout__restricted`, `.lc-checkout__unavailable`.

## Contenido por sitio (menús, no código)

| Ubicación | Uso |
| --- | --- |
| `promo` | Mensajes de la `PromoBar` (título, URL; clase CSS = icono). `{envio_gratis}` se sustituye por el umbral de la zona |
| `brand` | Enlaces de marca en la cabecera de escritorio |
| `utility` | Utilidades del menú lateral (clase CSS = icono: `pin`, `leaf`, `headset`…) |
| `usp` | `UspBar` (título, descripción = texto, clase CSS = icono). `{envio_gratis}` se sustituye por el umbral de la zona |
| `help` | Acordeón de ayuda de la ficha (título = pregunta, descripción = respuesta) |
| `footer` | Columnas del pie (elementos de primer nivel con sus enlaces) |
| `legal` | Enlaces legales del pie |
| `email-footer` | Enlaces del pie de los correos (Mi cuenta · Envíos y devoluciones · Privacidad). Sin menú: Mi cuenta y la página de privacidad |

La nota de impuestos bajo los precios es el «sufijo de precio» de WooCommerce (Ajustes → Impuestos). El lema del pie es la descripción corta del sitio.

## Home

Los bloques editoriales son el contenido de la página de inicio (patrones del tema, categoría «La Chinata»). Lo que va antes del bloque «Más» se pinta arriba (hero, campaña) y lo que va después, al final (historia, oleotecas). Entre medias, el tema pinta tiles de categoría, `UspBar`, TOP 10 y una sección por categoría.
