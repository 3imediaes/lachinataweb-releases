<?php
/**
 * Module `blocks`: editorial blocks.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Blocks;

use LaChinata\Core\Module;

defined( 'ABSPATH' ) || exit;

/**
 * «Sin Elementor: bloques propios» (03-implementacion.md): the brand pages and campaigns are
 * built with Gutenberg blocks of this module, one per editorial piece of the system, so the
 * content survives a change of theme; the theme brings their CSS. Patterns compose the Home
 * and Acerca de of 02-plantillas.md. 0.8.0 brings the pieces the system already has: hero,
 * category tiles, campaign banner, advantages, history and quote. Magazine, shops (with
 * map), figures and the franchise form wait for their component in the system.
 */
final class BlocksModule extends Module {

	/**
	 * Module id.
	 */
	public function id(): string {
		return 'blocks';
	}

	/**
	 * Module name.
	 */
	public function label(): string {
		return __( 'Bloques editoriales', 'lachinata-core' );
	}

	/**
	 * Module description.
	 */
	public function description(): string {
		return __( 'Bloques de Gutenberg del sistema (hero, tiles de categoría, banner de campaña, ventajas, historia y cita) y patrones para la Home y Acerca de.', 'lachinata-core' );
	}

	/**
	 * Version in which the module was added.
	 */
	public function since(): string {
		return '0.8.0';
	}

	/**
	 * Documentation.
	 */
	public function docs(): string {
		return 'plugin/modules/blocks/README.md';
	}

	/**
	 * Requirements.
	 *
	 * @return array{modules: string[], woocommerce: string}
	 */
	public function requires(): array {
		return array(
			'modules'     => array(),
			'woocommerce' => '10.0',
		);
	}

	/**
	 * No settings.
	 *
	 * @return array<string, array{type: 'bool'|'int'|'float'|'string'|'array', default: mixed, export?: bool}>
	 */
	public function settings(): array {
		return array();
	}

	/**
	 * Registers the hooks.
	 */
	public function boot(): void {
		Blocks::boot();
		Patterns::boot();
	}
}
