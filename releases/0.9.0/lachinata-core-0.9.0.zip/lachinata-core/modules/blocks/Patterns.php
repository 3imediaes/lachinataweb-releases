<?php
/**
 * Patterns of the brand pages.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Blocks;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * A new Home or Acerca de is composed by choosing patterns, not by designing
 * (03-implementacion.md). «Home» (02-plantillas.md, tableros Main y HomeDesktop): hero and
 * campaign banner before the «Más» block (the theme draws the category tiles, the
 * advantages, the TOP 10 and one section per category between them) and history after.
 * «Acerca de» (tableros Marca y MarcaDesktop): editorial header, quote and the three worlds
 * as category tiles; magazine, shops and figures arrive with their components. The theme's
 * own patterns stay for a site without this module and leave the inserter while it is on.
 */
final class Patterns {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'init', array( self::class, 'register' ), 20 );
	}

	/**
	 * A block of this module as block markup.
	 *
	 * @param string               $name       Block name without prefix.
	 * @param array<string, mixed> $attributes Attributes.
	 */
	public static function block( string $name, array $attributes ): string {
		return '<!-- wp:lachinata/' . $name . ' ' . wp_json_encode( $attributes, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . ' /-->';
	}

	/**
	 * Registers the patterns.
	 */
	public static function register(): void {
		if ( ! function_exists( 'register_block_pattern' ) ) {
			return;
		}
		if ( ! \WP_Block_Pattern_Categories_Registry::get_instance()->is_registered( 'lachinata' ) ) {
			register_block_pattern_category( 'lachinata', array( 'label' => __( 'La Chinata', 'lachinata-core' ) ) );
		}
		register_block_pattern(
			'lachinata/home',
			array(
				'title'       => __( 'Home', 'lachinata-core' ),
				'description' => __( 'Hero y banner de campaña arriba; historia al final. Entre medias, el tema pinta categorías, ventajas, TOP 10 y una sección por categoría.', 'lachinata-core' ),
				'categories'  => array( 'lachinata' ),
				'keywords'    => array( 'home', 'portada' ),
				'content'     => implode( "\n", self::home() ),
			)
		);
		register_block_pattern(
			'lachinata/about',
			array(
				'title'       => __( 'Acerca de', 'lachinata-core' ),
				'description' => __( 'Para la plantilla Editorial: texto, cita y los tres mundos de La Chinata. El título y el extracto de la página son la cabecera.', 'lachinata-core' ),
				'categories'  => array( 'lachinata' ),
				'keywords'    => array( 'marca', 'historia', 'acerca de' ),
				'content'     => implode( "\n", self::about() ),
			)
		);
	}

	/**
	 * Blocks of the Home.
	 *
	 * @return string[]
	 */
	public static function home(): array {
		return array(
			self::block(
				'hero',
				array(
					'eyebrow' => __( 'Nueva generación', 'lachinata-core' ),
					'title'   => __( 'Olivita, cosmética saludable', 'lachinata-core' ),
					'lead'    => __( 'Belleza natural con aceite de oliva virgen extra.', 'lachinata-core' ),
					'ctaText' => __( 'Descubre la línea', 'lachinata-core' ),
					'ctaUrl'  => '#',
					'tint'    => 'cosmetica',
				)
			),
			self::block(
				'promo',
				array(
					'figure'   => '-30%',
					'word'     => __( 'Desperdicio cero', 'lachinata-core' ),
					'text'     => __( 'Productos con descuento por fecha próxima. Mismo sabor, menos desperdicio.', 'lachinata-core' ),
					'linkText' => __( 'Ver ofertas', 'lachinata-core' ),
					'linkUrl'  => '#',
				)
			),
			'<!-- wp:more --><!--more--><!-- /wp:more -->',
			self::block(
				'history',
				array(
					'eyebrow' => __( 'Desde 1932', 'lachinata-core' ),
					'title'   => __( 'Maestros oleícolas desde hace tres generaciones', 'lachinata-core' ),
					'lead'    => __( 'Llevamos produciendo aceite de oliva virgen extra desde 1932. Hoy es el ingrediente de todo lo que hacemos.', 'lachinata-core' ),
					'ctaText' => __( 'Descubre nuestra historia', 'lachinata-core' ),
					'ctaUrl'  => '#',
				)
			),
		);
	}

	/**
	 * Blocks of Acerca de.
	 *
	 * @return string[]
	 */
	public static function about(): array {
		$paragraph = static fn( string $style, string $text ): string => '<!-- wp:paragraph {"className":"' . $style . '"} --><p class="' . $style . '">' . esc_html( $text ) . '</p><!-- /wp:paragraph -->';
		return array(
			$paragraph( 'body-lg', __( 'En 1932 nuestra familia empezó a producir aceite de oliva virgen extra en el norte de Extremadura. Con el tiempo, ese aceite pasó a ser el ingrediente fundamental de una gama gourmet y de una cosmética natural.', 'lachinata-core' ) ),
			$paragraph( 'body', __( 'Seguimos eligiendo la aceituna en el campo, prensando en frío y controlando cada lote, porque un buen aceite no admite atajos.', 'lachinata-core' ) ),
			self::block(
				'quote',
				array(
					'text' => __( '«El aceite se hace en el campo, no en la almazara.»', 'lachinata-core' ),
				)
			),
			'<!-- wp:heading {"className":"h3"} --><h2 class="wp-block-heading h3">' . esc_html__( 'Tres mundos, un ingrediente', 'lachinata-core' ) . '</h2><!-- /wp:heading -->',
			self::block(
				'category-tiles',
				array(
					'categories' => 'aceites,gourmet,cosmetica',
					'layout'     => 'list',
				)
			),
		);
	}
}
