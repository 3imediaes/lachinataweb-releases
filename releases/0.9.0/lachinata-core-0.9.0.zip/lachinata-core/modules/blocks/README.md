# Módulo `blocks`

Bloques editoriales de Gutenberg, uno por pieza editorial del sistema («Sin Elementor: bloques propios», `design-system/sistema/03-implementacion.md`), y patrones para componer la Home y Acerca de eligiendo, no diseñando (`02-plantillas.md`, tableros Main, HomeDesktop, Marca y MarcaDesktop). El contenido son los atributos del bloque: sobrevive a un cambio de tema. El tema aporta el CSS (las mismas clases que sus patrones y que `bundle.css`).

## Qué hace

Bloques dinámicos de la categoría «La Chinata» y patrones de Home y Acerca de: detalle en las dos secciones siguientes. El HTML es el del sistema (`.lc-*`) y el tema lo viste.

## Bloques (categoría «La Chinata»)
Todos dinámicos: `block.json` en `blocks/<nombre>/`, render en PHP (`Render.php`) y, en el editor, panel lateral con los atributos y vista previa del render del servidor (`src/index.js`, `ServerSideRender`).

| Bloque | Pieza del sistema | HTML | Atributos |
| --- | --- | --- | --- |
| `lachinata/hero` | Hero de la Home: `CategoryTile` fotográfico con eyebrow, titular `editorial-display` (o cifra `campaign` en SantElia), entradilla y botón | `lc-hero-block lc-tile--<tinta>`, `lc-btn` | antetítulo, titular, entradilla, botón y enlace, tinta (crema, cosmética, aceites, gourmet, regalos, hogar), tamaño (display / h1), titular como cifra de campaña, foto |
| `lachinata/category-tiles` | `CategoryTile` en su tinta o con su foto; el primero grande | `lc-tiles` (`--list`: una bajo otra) + `lc-tile` | categorías (slugs en orden; vacío, las principales), texto del enlace, disposición |
| `lachinata/promo` | Banner de campaña: cifra en `campaign`, 1–2 palabras en `campaign-word`, explicación y enlace | `lc-campaign` (`--ink`, `--coral`) | cifra, palabras, explicación, enlace, fondo (acento, tinta o coral `campaign-coral` con texto `ink`, solo Black Friday) |
| `lachinata/usp` | `UspBar` | `lc-usp` (`--row`) | ventajas (icono · título · texto), disposición |
| `lachinata/history` | Historia sobre `surface-cream`: eyebrow, `editorial-h2`, `editorial-lead`, botón secundario | `lc-history`, `lc-btn lc-btn--secondary` | antetítulo, titular, entradilla, botón y enlace |
| `lachinata/quote` | Cita en `editorial-quote` y `olive-deep` | `lc-quote-block` | cita, autor |

**Pendientes del sistema de diseño** (decisiones.md, incremento 6, punto 8): revista, oleotecas con mapa, cifras y formulario de franquicias no tienen componente; se harán cuando el equipo de diseño los formalice, sin clases provisionales. El formulario de franquicias usará `Contracts\Newsletter` (módulo `newsletter`) con la etiqueta «franquicia» y el correo a la dirección del panel.

## Patrones
| Patrón | Para | Contenido |
| --- | --- | --- |
| `lachinata/home` | La página de inicio | hero y banner de campaña antes del bloque «Más»; historia después. Entre medias, el tema pinta categorías, ventajas, TOP 10 y una sección por categoría (`front-page.php`) |
| `lachinata/about` | Acerca de, con la plantilla Editorial (el título y el extracto de la página son la cabecera) | texto, cita, «Tres mundos, un ingrediente» y los tres mundos en lista |

Los patrones del tema (`home-hero`, `home-campaign`, `home-history`, `editorial-quote`) siguen registrados para un sitio sin el módulo y se ocultan del insertador con él encendido (`theme/inc/setup.php`). `home-brand-tiles` (Oleotecas y Regalos de empresa) se mantiene hasta que exista su componente. El seed monta la Home y Acerca de con los patrones nuevos.

`theme.json` ya bloquea lo que está fuera del sistema: sin colores, degradados ni duotonos propios, sin tamaños de letra ni espaciados libres, solo las tres familias del sistema.

## Depende de

Ningún módulo. WooCommerce 10 (los tiles leen categorías de producto). Las tintas de categoría, si está `catalog`, por el filtro `lachinata/category/tint`.

## Hooks que escucha

`init` (registra bloques y patrones) y `block_categories_all` (categoría «La Chinata»).

## Hooks que emite

`lachinata/category/tint` `( string $tint, WP_Term $term )` en los tiles, el mismo filtro del tema (lo rellena `catalog`). Catálogo: `theme/HOOKS.md`.

## Datos que guarda

Nada propio: el contenido son los atributos de los bloques, dentro de las páginas. Sin opciones ni metadatos.

## REST y API para Odoo

Nada. El editor usa la ruta de WordPress `block-renderer` para la vista previa.

## Ajustes y exportación

Sin ajustes ni datos en el JSON exportado.

## Qué pasa al apagarlo

Las páginas que usan los bloques muestran el aviso de WordPress de bloque no disponible en el editor y nada en la web; el contenido (atributos) se queda en la página y vuelve al encenderlo. Los patrones del tema reaparecen en el insertador como alternativa sin plugin.

## Pruebas
- `tests/BlocksTest.php`: registro (dinámicos, categoría, script del editor), HTML de cada bloque (clases, escapado, solo tintas del sistema, vacío sin contenido), tiles en orden y en lista, patrones hechos de bloques registrados, patrones del tema fuera del insertador.
- Arranque, exportación e importación en cada perfil (`tests/profiles/ProfileBootTest.php`) y el módulo solo (`tools/tests/modules-isolated.sh`).

## Huecos conocidos

Revista, oleotecas con mapa, cifras y formulario de franquicias esperan su componente en el sistema de diseño (incrementos 6c–6f).
