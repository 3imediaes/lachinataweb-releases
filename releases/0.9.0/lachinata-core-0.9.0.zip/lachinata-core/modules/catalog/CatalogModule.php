<?php
/**
 * Module `catalog`: catalog data that used to live in ACF.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

use LaChinata\Core\Hooks;
use LaChinata\Core\Module;

defined( 'ABSPATH' ) || exit;

/**
 * Content and unit price, ingredients, label, description image, best-before date,
 * international exclusion, category tint and seals (`tipo`) with icon.
 */
final class CatalogModule extends Module {

	/**
	 * Module id.
	 */
	public function id(): string {
		return 'catalog';
	}

	/**
	 * Module name.
	 */
	public function label(): string {
		return __( 'Catálogo', 'lachinata-core' );
	}

	/**
	 * Module description.
	 */
	public function description(): string {
		return __( 'Contenido y precio por unidad, ingredientes, etiqueta, sellos y tinta de categoría. Sustituye a ACF.', 'lachinata-core' );
	}

	/**
	 * Version in which the module was added.
	 */
	public function since(): string {
		return '0.2.0';
	}

	/**
	 * Documentation.
	 */
	public function docs(): string {
		return 'plugin/modules/catalog/README.md';
	}

	/**
	 * Requirements.
	 *
	 * @return array{woocommerce: string}
	 */
	public function requires(): array {
		return array( 'woocommerce' => '10.0' );
	}

	/**
	 * Product and term fields («Borrar datos» removes them; the old ACF values stay).
	 *
	 * @return array{product_meta: string[], term_meta: string[]}
	 */
	public function owned_data(): array {
		return array(
			'product_meta' => array( Fields::CONTENT, Fields::REFERENCE, Fields::INGREDIENTS, Fields::LABEL, Fields::IMAGE, Fields::BEST_BEFORE, Fields::NO_SHIP_ABROAD ),
			'term_meta'    => array( Fields::TINT, Fields::ICON ),
		);
	}

	/**
	 * Registers the hooks.
	 */
	public function boot(): void {
		Hooks::add_action( 'init', array( TipoTaxonomy::class, 'register' ), 5 );
		Hooks::add_action( 'init', array( Fields::class, 'register' ) );
		Hooks::add_filter( 'lachinata/catalog/no_ship_abroad', static fn( $excluded, $product_id ): bool => (bool) $excluded || (bool) Fields::get( (int) $product_id, Fields::NO_SHIP_ABROAD ), 10, 2 );
		Storefront::boot();

		if ( is_admin() ) {
			Admin::boot();
			ProductAdmin::boot();
			TermFields::boot();
		}

		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::add_command( 'lachinata catalog', NormalizeCommand::class );
		}
	}
}
