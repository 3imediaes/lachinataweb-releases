<?php
/**
 * Catalog fields: meta keys, registration and reads with ACF fallback.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

defined( 'ABSPATH' ) || exit;

/**
 * Single access point to the catalog data. Reads `_lc_*` and, while a product has not
 * been normalised yet, falls back to the key ACF used on the current site.
 */
final class Fields {

	public const CONTENT        = '_lc_contenido';
	public const REFERENCE      = '_lc_referencia';
	public const INGREDIENTS    = '_lc_ingredientes';
	public const LABEL          = '_lc_etiqueta';
	public const IMAGE          = '_lc_imagen_descripcion';
	public const BEST_BEFORE    = '_lc_consumo_preferente';
	public const NO_SHIP_ABROAD = '_lc_excluir_internacional';
	public const TINT           = '_lc_tint';
	public const ICON           = '_lc_icono';

	/**
	 * Product meta and the ACF key it replaces.
	 */
	public const LEGACY = array(
		self::CONTENT        => 'cantidad_unidad_medida',
		self::REFERENCE      => 'cantidad_referencia_medida',
		self::INGREDIENTS    => 'ingredientes',
		self::LABEL          => 'etiqueta',
		self::IMAGE          => 'imagen_descripcion',
		self::BEST_BEFORE    => 'consumo_preferente',
		self::NO_SHIP_ABROAD => 'excluir_producto_',
	);

	/**
	 * Term meta of the `tipo` taxonomy and the ACF key it replaces.
	 */
	public const LEGACY_TERM = array(
		self::ICON => 'icono',
	);

	/**
	 * The five category tints of the design system.
	 */
	public const TINTS = array( 'cosmetica', 'aceites', 'gourmet', 'regalos', 'hogar' );

	/**
	 * Registers the meta with REST schemas.
	 */
	public static function register(): void {
		$quantity_schema = array(
			'type'       => 'object',
			'properties' => array(
				'cantidad' => array( 'type' => 'number' ),
				'unidad'   => array(
					'type' => 'string',
					'enum' => array_keys( Quantity::UNITS ),
				),
			),
		);
		$auth            = static fn(): bool => current_user_can( 'edit_products' );

		foreach ( array( 'product', 'product_variation' ) as $post_type ) {
			register_post_meta(
				$post_type,
				self::CONTENT,
				array(
					'type'          => 'object',
					'single'        => true,
					'show_in_rest'  => array( 'schema' => $quantity_schema ),
					'auth_callback' => $auth,
				)
			);
		}

		register_post_meta(
			'product',
			self::REFERENCE,
			array(
				'type'          => 'object',
				'single'        => true,
				'show_in_rest'  => array( 'schema' => $quantity_schema ),
				'auth_callback' => $auth,
			)
		);

		$simple = array(
			self::INGREDIENTS    => array( 'string', 'wp_kses_post' ),
			self::LABEL          => array( 'string', 'sanitize_text_field' ),
			self::IMAGE          => array( 'integer', 'absint' ),
			self::BEST_BEFORE    => array( 'string', array( self::class, 'sanitize_date' ) ),
			self::NO_SHIP_ABROAD => array( 'boolean', 'rest_sanitize_boolean' ),
		);
		foreach ( $simple as $key => [ $type, $sanitize ] ) {
			register_post_meta(
				'product',
				$key,
				array(
					'type'              => $type,
					'single'            => true,
					'show_in_rest'      => true,
					'sanitize_callback' => $sanitize,
					'auth_callback'     => $auth,
				)
			);
		}

		register_term_meta(
			'product_cat',
			self::TINT,
			array(
				'type'              => 'string',
				'single'            => true,
				'show_in_rest'      => array( 'schema' => array( 'enum' => array_merge( array( '' ), self::TINTS ) ) ),
				'sanitize_callback' => array( self::class, 'sanitize_tint' ),
				'auth_callback'     => static fn(): bool => current_user_can( 'manage_product_terms' ),
			)
		);

		register_term_meta(
			TipoTaxonomy::TAXONOMY,
			self::ICON,
			array(
				'type'              => 'integer',
				'single'            => true,
				'show_in_rest'      => true,
				'sanitize_callback' => 'absint',
				'auth_callback'     => static fn(): bool => current_user_can( 'manage_product_terms' ),
			)
		);
	}

	/**
	 * Content of a product or variation. Variations inherit the parent's.
	 *
	 * @param \WC_Product $product Product or variation.
	 */
	public static function content( \WC_Product $product ): ?Quantity {
		$own = self::quantity( $product->get_id(), self::CONTENT );
		if ( null !== $own || ! $product->is_type( 'variation' ) ) {
			return $own;
		}
		return self::quantity( $product->get_parent_id(), self::CONTENT );
	}

	/**
	 * Reference quantity of a product (variations use the parent's).
	 *
	 * @param \WC_Product $product Product or variation.
	 */
	public static function reference( \WC_Product $product ): ?Quantity {
		$id = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();
		return self::quantity( $id, self::REFERENCE );
	}

	/**
	 * Stored or legacy quantity.
	 *
	 * @param int    $post_id Post id.
	 * @param string $key     CONTENT or REFERENCE.
	 */
	public static function quantity( int $post_id, string $key ): ?Quantity {
		if ( metadata_exists( 'post', $post_id, $key ) ) {
			return Quantity::from_array( get_post_meta( $post_id, $key, true ) );
		}
		$legacy = self::legacy_raw( $post_id, $key );
		return is_string( $legacy ) ? Quantity::parse( $legacy ) : null;
	}

	/**
	 * Rich text, text, image id, date or flag of a product, normalised.
	 *
	 * @param int    $product_id Product id.
	 * @param string $key        One of the simple keys.
	 * @return string|int|bool
	 */
	public static function get( int $product_id, string $key ): string|int|bool {
		$raw = metadata_exists( 'post', $product_id, $key )
			? get_post_meta( $product_id, $key, true )
			: self::from_legacy( $key, self::legacy_raw( $product_id, $key ) );

		return match ( $key ) {
			self::IMAGE          => absint( $raw ),
			self::NO_SHIP_ABROAD => (bool) $raw,
			default              => is_scalar( $raw ) ? (string) $raw : '',
		};
	}

	/**
	 * Converts an ACF value to the format of the new meta.
	 *
	 * @param string $key   New meta key.
	 * @param mixed  $value ACF stored value.
	 * @return mixed
	 */
	public static function from_legacy( string $key, mixed $value ): mixed {
		if ( null === $value || '' === $value ) {
			return '';
		}
		return match ( $key ) {
			self::CONTENT, self::REFERENCE => is_string( $value ) ? Quantity::parse( $value )?->to_array() : null,
			self::NO_SHIP_ABROAD           => 'si' === strtolower( remove_accents( (string) $value ) ),
			self::BEST_BEFORE              => self::sanitize_date( (string) $value ),
			self::IMAGE                    => absint( is_array( $value ) ? ( $value['ID'] ?? $value['id'] ?? 0 ) : $value ),
			default                        => $value,
		};
	}

	/**
	 * ACF value of a product, or null when there is none.
	 *
	 * @param int    $post_id Post id.
	 * @param string $key     New meta key.
	 */
	private static function legacy_raw( int $post_id, string $key ): mixed {
		$legacy = self::LEGACY[ $key ] ?? null;
		if ( null === $legacy || ! metadata_exists( 'post', $post_id, $legacy ) ) {
			return null;
		}
		return get_post_meta( $post_id, $legacy, true );
	}

	/**
	 * Icon (attachment id) of a `tipo` term, with fallback to ACF `icono`.
	 *
	 * @param int $term_id Term id.
	 */
	public static function icon( int $term_id ): int {
		if ( metadata_exists( 'term', $term_id, self::ICON ) ) {
			return absint( get_term_meta( $term_id, self::ICON, true ) );
		}
		$legacy = get_term_meta( $term_id, self::LEGACY_TERM[ self::ICON ], true );
		return absint( is_array( $legacy ) ? ( $legacy['ID'] ?? $legacy['id'] ?? 0 ) : $legacy );
	}

	/**
	 * Tint of a category, inherited from the closest ancestor that has one.
	 *
	 * @param int $term_id Category id.
	 */
	public static function tint( int $term_id ): string {
		foreach ( array_merge( array( $term_id ), get_ancestors( $term_id, 'product_cat', 'taxonomy' ) ) as $id ) {
			$tint = (string) get_term_meta( $id, self::TINT, true );
			if ( in_array( $tint, self::TINTS, true ) ) {
				return $tint;
			}
		}
		return '';
	}

	/**
	 * Keeps only the system tints.
	 *
	 * @param mixed $value Raw value.
	 */
	public static function sanitize_tint( mixed $value ): string {
		return in_array( $value, self::TINTS, true ) ? $value : '';
	}

	/**
	 * Normalises a date to Y-m-d. Accepts Y-m-d, Ymd (ACF storage) and d/m/Y (ACF display).
	 *
	 * @param mixed $value Raw value.
	 */
	public static function sanitize_date( mixed $value ): string {
		$value = trim( (string) $value );
		foreach ( array( 'Y-m-d', 'Ymd', 'd/m/Y' ) as $format ) {
			$date = \DateTimeImmutable::createFromFormat( '!' . $format, $value );
			if ( $date && $date->format( $format ) === $value ) {
				return $date->format( 'Y-m-d' );
			}
		}
		return '';
	}
}
