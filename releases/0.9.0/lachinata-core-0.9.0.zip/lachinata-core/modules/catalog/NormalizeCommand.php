<?php
/**
 * WP-CLI: wp lachinata catalog normalize.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

use WP_CLI;

defined( 'ABSPATH' ) || exit;

/**
 * One-off copy of the ACF values to the `_lc_*` meta.
 */
final class NormalizeCommand {

	/**
	 * Copies the ACF values to the new meta. Idempotent: never overwrites an `_lc_*` value.
	 *
	 * Also reports (without writing) the products whose ACF `ean` differs from the
	 * WooCommerce GTIN, and values that cannot be read («500 mililitros»).
	 *
	 * ## OPTIONS
	 *
	 * [--dry-run]
	 * : Report only.
	 *
	 * [--from-shipping-class=<slug>]
	 * : Also marks the international exclusion (`_lc_excluir_internacional`) on the
	 * products of this shipping class (for example the class «Ocultar internacional»).
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata catalog normalize --dry-run
	 *     wp lachinata catalog normalize --from-shipping-class=ocultar-internacional
	 *
	 * @param string[]             $args       Positional arguments.
	 * @param array<string, mixed> $assoc_args Named arguments.
	 */
	public function normalize( array $args, array $assoc_args ): void {
		$dry_run = (bool) WP_CLI\Utils\get_flag_value( $assoc_args, 'dry-run', false );
		$class   = sanitize_title( (string) ( $assoc_args['from-shipping-class'] ?? '' ) );
		if ( '' !== $class && ! get_term_by( 'slug', $class, 'product_shipping_class' ) ) {
			WP_CLI::error( sprintf( 'No existe la clase de envío «%s».', $class ) );
		}
		$report = self::run( $dry_run, $class );

		foreach ( $report['problems'] as $line ) {
			WP_CLI::warning( $line );
		}
		WP_CLI::success(
			sprintf(
				'%1$s: %2$d valores de producto y %3$d iconos de sello; %4$d avisos.',
				$dry_run ? 'Simulación' : 'Normalizado',
				$report['product_values'],
				$report['term_values'],
				count( $report['problems'] )
			)
		);
		if ( '' !== $class ) {
			WP_CLI::success( sprintf( 'Exclusión internacional desde la clase «%1$s»: %2$d productos.', $class, $report['flag_values'] ) );
		}
	}

	/**
	 * Does the work; separated from the command for tests.
	 *
	 * @param bool   $dry_run        Report only.
	 * @param string $shipping_class Shipping class slug whose products get the international exclusion; '' to skip.
	 * @return array{product_values: int, term_values: int, flag_values: int, problems: string[]}
	 */
	public static function run( bool $dry_run, string $shipping_class = '' ): array {
		$report = array(
			'product_values' => 0,
			'term_values'    => 0,
			'flag_values'    => 0,
			'problems'       => array(),
		);

		$ids = get_posts(
			array(
				'post_type'      => 'product',
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
			)
		);

		foreach ( $ids as $id ) {
			$id = (int) $id;
			foreach ( Fields::LEGACY as $key => $legacy ) {
				if ( metadata_exists( 'post', $id, $key ) || ! metadata_exists( 'post', $id, $legacy ) ) {
					continue;
				}
				$raw   = get_post_meta( $id, $legacy, true );
				$value = Fields::from_legacy( $key, $raw );
				if ( null === $value || ( '' === $value && '' !== $raw ) ) {
					$report['problems'][] = sprintf( '#%1$d %2$s: no se entiende «%3$s».', $id, $legacy, is_scalar( $raw ) ? (string) $raw : wp_json_encode( $raw ) );
					continue;
				}
				if ( '' === $value ) {
					continue;
				}
				++$report['product_values'];
				if ( ! $dry_run ) {
					update_post_meta( $id, $key, $value );
				}
			}

			$ean = trim( (string) get_post_meta( $id, 'ean', true ) );
			if ( '' !== $ean ) {
				$product = wc_get_product( $id );
				$gtin    = $product ? (string) $product->get_global_unique_id() : '';
				if ( $gtin !== $ean ) {
					$report['problems'][] = sprintf( '#%1$d EAN «%2$s» ≠ GTIN «%3$s» (no se cambia).', $id, $ean, $gtin );
				}
			}
		}

		$terms = get_terms(
			array(
				'taxonomy'   => TipoTaxonomy::TAXONOMY,
				'hide_empty' => false,
				'fields'     => 'ids',
			)
		);
		foreach ( is_array( $terms ) ? $terms : array() as $term_id ) {
			$term_id = (int) $term_id;
			if ( metadata_exists( 'term', $term_id, Fields::ICON ) ) {
				continue;
			}
			$icon = Fields::icon( $term_id );
			if ( $icon ) {
				++$report['term_values'];
				if ( ! $dry_run ) {
					update_term_meta( $term_id, Fields::ICON, $icon );
				}
			}
		}

		if ( '' !== $shipping_class ) {
			$report['flag_values'] = self::flag_class( $shipping_class, $dry_run );
		}

		return $report;
	}

	/**
	 * Marks the international exclusion on the products of a shipping class (a variation
	 * of the class marks its parent). Products already marked are not counted.
	 *
	 * @param string $slug    Shipping class slug.
	 * @param bool   $dry_run Report only.
	 * @return int Products marked.
	 */
	private static function flag_class( string $slug, bool $dry_run ): int {
		$ids      = get_posts(
			array(
				'post_type'      => array( 'product', 'product_variation' ),
				'post_status'    => 'any',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'tax_query'      => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- One-off command.
					array(
						'taxonomy' => 'product_shipping_class',
						'field'    => 'slug',
						'terms'    => $slug,
					),
				),
			)
		);
		$products = array();
		foreach ( $ids as $id ) {
			$parent     = wp_get_post_parent_id( (int) $id );
			$products[] = $parent ? $parent : (int) $id;
		}

		$count = 0;
		foreach ( array_unique( $products ) as $id ) {
			if ( Fields::get( $id, Fields::NO_SHIP_ABROAD ) ) {
				continue;
			}
			++$count;
			if ( ! $dry_run ) {
				update_post_meta( $id, Fields::NO_SHIP_ABROAD, '1' );
			}
		}
		return $count;
	}
}
