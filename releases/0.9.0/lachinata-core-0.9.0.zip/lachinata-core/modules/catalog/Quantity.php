<?php
/**
 * Amount + unit («500 ml»).
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

defined( 'ABSPATH' ) || exit;

/**
 * Immutable amount with one of the catalog units.
 */
final class Quantity {

	/**
	 * Allowed units and their base unit and factor to it.
	 */
	public const UNITS = array(
		'g'  => array( 'g', 1 ),
		'kg' => array( 'g', 1000 ),
		'ml' => array( 'ml', 1 ),
		'l'  => array( 'ml', 1000 ),
		'ud' => array( 'ud', 1 ),
	);

	/**
	 * Reference quantities offered for the unit price.
	 */
	public const REFERENCES = array( '1 kg', '1 l', '100 g', '100 ml', '1 ud' );

	/**
	 * Builds a quantity. Use from_array() or parse() for untrusted input.
	 *
	 * @param float  $amount Positive amount.
	 * @param string $unit   One of UNITS.
	 */
	public function __construct( public readonly float $amount, public readonly string $unit ) {}

	/**
	 * Parses free text written by people: «500 ml», «1,5 l», «500ml», «1 L», «2 Kg».
	 *
	 * @param string $text Text.
	 */
	public static function parse( string $text ): ?self {
		$text = strtolower( trim( str_replace( "\u{00a0}", ' ', $text ) ) );
		if ( ! preg_match( '/^(\d+(?:[.,]\d+)?)\s*(kg|g|ml|l|ud|uds|unidad|unidades)\.?$/', $text, $match ) ) {
			return null;
		}
		$unit   = in_array( $match[2], array( 'uds', 'unidad', 'unidades' ), true ) ? 'ud' : $match[2];
		$amount = (float) str_replace( ',', '.', $match[1] );
		return $amount > 0 ? new self( $amount, $unit ) : null;
	}

	/**
	 * Builds a quantity from stored meta (`{cantidad, unidad}`).
	 *
	 * @param mixed $value Stored value.
	 */
	public static function from_array( mixed $value ): ?self {
		if ( ! is_array( $value ) || ! isset( $value['cantidad'], $value['unidad'] ) ) {
			return null;
		}
		$amount = (float) $value['cantidad'];
		$unit   = (string) $value['unidad'];
		return $amount > 0 && isset( self::UNITS[ $unit ] ) ? new self( $amount, $unit ) : null;
	}

	/**
	 * Value to store in meta.
	 *
	 * @return array{cantidad: float, unidad: string}
	 */
	public function to_array(): array {
		return array(
			'cantidad' => $this->amount,
			'unidad'   => $this->unit,
		);
	}

	/**
	 * Amount expressed in the base unit (g, ml or ud).
	 */
	public function in_base_unit(): float {
		return $this->amount * self::UNITS[ $this->unit ][1];
	}

	/**
	 * Whether both quantities can be compared (same base unit).
	 *
	 * @param Quantity $other Other quantity.
	 */
	public function is_compatible( Quantity $other ): bool {
		$base = self::UNITS[ $this->unit ][0];
		return self::UNITS[ $other->unit ][0] === $base;
	}

	/**
	 * Localised label: «500 ml», «1,5 l».
	 */
	public function label(): string {
		$whole    = fmod( $this->amount, 1.0 ) < PHP_FLOAT_EPSILON;
		$decimals = $whole ? 0 : 2;
		$number   = number_format_i18n( $this->amount, $decimals );
		if ( $decimals ) {
			$number = rtrim( rtrim( $number, '0' ), ',.' );
		}
		/* translators: 1: amount, 2: unit symbol (g, kg, ml, l, ud). */
		return sprintf( _x( '%1$s %2$s', 'quantity', 'lachinata-core' ), $number, $this->unit );
	}
}
