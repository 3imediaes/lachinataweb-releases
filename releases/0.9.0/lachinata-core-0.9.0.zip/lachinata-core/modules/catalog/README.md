# Módulo `catalog`

Datos propios del catálogo que en la web actual están en ACF, con campos nativos de WordPress y WooCommerce: contenido y referencia para el precio por unidad (también por variación), ingredientes, etiqueta, imagen de descripción, consumo preferente y exclusión internacional del producto; tinta de cada categoría; taxonomía `tipo` (sellos) con su icono. Sustituye a ACF sin migración de datos: lee las claves de ACF hasta que se normalizan.

Especificación: `design-system/sistema/03-implementacion.md` («ACF se retira» y tabla de módulos). Huecos del tema que rellena: `theme/HOOKS.md`. Se enciende por defecto al activar el plugin.

## Qué hace

| Pieza | Cómo | Dónde |
| --- | --- | --- |
| Campos del producto en la pestaña «La Chinata» de la ficha del panel (y por variación, contenido y referencia) | `woocommerce_product_data_tabs`, `woocommerce_product_data_panels`, `woocommerce_product_after_variable_attributes`, `woocommerce_admin_process_product_object` y `_variation_object` | `ProductAdmin.php` |
| Metadatos nativos con `show_in_rest` (editor y Store API): `_lc_contenido`, `_lc_referencia` (cantidad y unidad por separado), `_lc_ingredientes`, `_lc_etiqueta`, `_lc_imagen_descripcion`, `_lc_consumo_preferente`, `_lc_excluir_internacional`. Si un producto aún no está normalizado, se lee la clave de ACF (`cantidad_unidad_medida`…) | `register_post_meta`, `register_term_meta` | `Fields.php`, `Quantity.php` |
| Tinta de la categoría (`_lc_tint`, la heredan las subcategorías) e icono del tipo (`_lc_icono`), con selector de medios | Campos de término (`product_cat_*_form_fields`, `created_`/`edited_`) | `TermFields.php`, `Admin.php` |
| Taxonomía `tipo` (sellos del producto) | `register_taxonomy` en `init` | `TipoTaxonomy.php` |
| Lo que ve el cliente, por los huecos del tema: precio por unidad («500 ml \| 9,33 € / 1 l»), tinta de categoría y de producto, etiqueta antes de las insignias, pestañas Ingredientes e imagen de descripción, sellos, consumo preferente y la segunda línea de los productos en los correos | Filtros `lachinata/product/*`, `lachinata/category/tint`, `lachinata/product_card/badges` | `Storefront.php`, `UnitPrice.php` |
| Normalización de ACF a los campos nativos (una vez por sitio): cantidad y unidad por separado; el EAN no se migra (manda el GTIN de WooCommerce y solo se avisa de los que no coinciden) | `wp lachinata catalog normalize [--dry-run] [--from-shipping-class=<slug>]` | `NormalizeCommand.php` |
| La marca de exclusión internacional para `shipping` | Filtro `lachinata/catalog/no_ship_abroad` (0.9.0) | `CatalogModule.php` |

## Depende de

Ningún módulo. WooCommerce 10. No necesita ACF: si está, conviven y el módulo lee sus valores hasta normalizarlos.

## Hooks que escucha

- `init` (taxonomía y metadatos), la ficha de producto y las variaciones en el panel, los formularios de `product_cat` y `tipo`, `admin_enqueue_scripts` y `admin_notices` (selector de medios y avisos de la normalización).
- Del tema: `lachinata/product/unit_price`, `lachinata/product/tint`, `lachinata/category/tint`, `lachinata/product_card/badges`, `lachinata/product/tabs`, `lachinata/product/seals`, `lachinata/product/details`, `lachinata/product/content`.
- Del núcleo: `lachinata/catalog/no_ship_abroad`.

## Hooks que emite

Ninguno propio: todo lo que da sale por los huecos del tema (`theme/HOOKS.md`) y por `lachinata/catalog/no_ship_abroad` (`plugin/HOOKS.md`).

## Datos que guarda

- Metadatos de producto y variación: `_lc_contenido`, `_lc_referencia`, `_lc_ingredientes`, `_lc_etiqueta`, `_lc_imagen_descripcion`, `_lc_consumo_preferente`, `_lc_excluir_internacional`.
- Metadatos de término: `_lc_tint` (`product_cat`), `_lc_icono` (`tipo`). Los términos de `tipo` son contenido del sitio.
- Son anteriores a la regla `_lc_<módulo>_*` y se quedan con su nombre (excepción catalogada en `plugin/HOOKS.md`). Las claves de ACF no se tocan nunca.

## REST y API para Odoo

Los metadatos de producto van en la API REST y en la Store API (`show_in_rest`). Nada en el objeto `lachinata` de los pedidos.

## Ajustes y exportación

Sin ajustes ni `export_data()`: los datos del catálogo son contenido de cada producto y categoría, no configuración, y no viajan en el JSON.

## Qué pasa al apagarlo

El tema vuelve a sus valores neutros: sin tintas, sin precio por unidad, sin etiqueta, pestañas ni sellos propios; la taxonomía `tipo` deja de registrarse (sus términos siguen en la base de datos) y `shipping` deja de ver la exclusión internacional del producto (solo cuentan las clases de envío). Los datos se quedan. «Borrar datos» borra los metadatos de producto y término de arriba (nunca las claves de ACF ni los pedidos), después de descargar el JSON del módulo.

## Pruebas

- `tests/FieldsTest.php` (registro, lectura con la clave de ACF de respaldo), `tests/QuantityTest.php` (cantidad y unidad), `tests/UnitPriceTest.php` (precio por unidad, también por variación), `tests/StorefrontTest.php` (lo que llega al tema por cada hueco), `tests/NormalizeCommandTest.php` (normalización, `--dry-run`, GTIN y `--from-shipping-class`).
- En cada perfil: `tests/profiles/ProfileBootTest.php`. El módulo solo: `tools/tests/modules-isolated.sh`.

## Huecos conocidos

- Exclusión internacional duplicada (clase «Ocultar internacional» y campo): pendiente de decidir cuál manda; `normalize --from-shipping-class` pasa de la clase al campo.
- `rutina`, `destacamos`, `modo_empleo` y `email_collect` de ACF no se migran (decidido).
- El grupo «Oleoteca» de ACF llegará con su módulo.
