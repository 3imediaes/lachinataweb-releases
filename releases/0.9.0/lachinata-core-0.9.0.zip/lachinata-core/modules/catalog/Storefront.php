<?php
/**
 * Fills the theme hooks with the catalog data.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * Front-end side of the module. Prints nothing itself: answers the theme's filters.
 */
final class Storefront {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/category/tint', array( self::class, 'category_tint' ), 10, 2 );
		Hooks::add_filter( 'lachinata/product/tint', array( self::class, 'product_tint' ), 10, 2 );
		Hooks::add_filter( 'lachinata/product/unit_price', array( self::class, 'unit_price' ), 10, 2 );
		Hooks::add_filter( 'lachinata/product/content', array( self::class, 'content' ), 10, 2 );
		Hooks::add_filter( 'lachinata/product/tabs', array( self::class, 'tabs' ), 10, 2 );
		Hooks::add_filter( 'lachinata/product/seals', array( self::class, 'seals' ), 10, 2 );
		Hooks::add_filter( 'lachinata/product/details', array( self::class, 'details' ), 10, 2 );
		Hooks::add_filter( 'lachinata/product_card/badges', array( self::class, 'badges' ), 10, 2 );
	}

	/**
	 * Tint of a category.
	 *
	 * @param string   $tint Current tint.
	 * @param \WP_Term $term Category.
	 */
	public static function category_tint( string $tint, \WP_Term $term ): string {
		if ( 'product_cat' !== $term->taxonomy ) {
			return $tint;
		}
		$found = Fields::tint( $term->term_id );
		return '' === $found ? $tint : $found;
	}

	/**
	 * Tint of a product: the one of its deepest category that has (or inherits) one.
	 *
	 * @param string      $tint    Current tint.
	 * @param \WC_Product $product Product.
	 */
	public static function product_tint( string $tint, \WC_Product $product ): string {
		$id    = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();
		$terms = get_the_terms( $id, 'product_cat' );
		if ( ! is_array( $terms ) ) {
			return $tint;
		}
		usort( $terms, static fn( \WP_Term $a, \WP_Term $b ): int => count( get_ancestors( $b->term_id, 'product_cat', 'taxonomy' ) ) <=> count( get_ancestors( $a->term_id, 'product_cat', 'taxonomy' ) ) );
		foreach ( $terms as $term ) {
			$found = Fields::tint( $term->term_id );
			if ( '' !== $found ) {
				return $found;
			}
		}
		return $tint;
	}

	/**
	 * «500 ml | 9,33 € / 1 l». Variable products use their cheapest variation, so the
	 * unit price always matches a real price and content.
	 *
	 * @param string      $html    Current HTML.
	 * @param \WC_Product $product Product or variation.
	 */
	public static function unit_price( string $html, \WC_Product $product ): string {
		if ( $product instanceof \WC_Product_Variable ) {
			$prices = $product->get_variation_prices( true );
			$id     = array_key_first( $prices['price'] ?? array() );
			$cheap  = null === $id ? null : wc_get_product( $id );
			if ( ! $cheap instanceof \WC_Product ) {
				return $html;
			}
			$product = $cheap;
		}
		$formatted = UnitPrice::format( (float) wc_get_price_to_display( $product ), Fields::content( $product ), Fields::reference( $product ) );
		return '' === $formatted ? $html : $formatted;
	}

	/**
	 * Content of the product or variation («500 ml»).
	 *
	 * @param string      $content Content.
	 * @param \WC_Product $product Product.
	 */
	public static function content( string $content, \WC_Product $product ): string {
		$found = Fields::content( $product );
		return null === $found ? $content : $found->label();
	}

	/**
	 * Adds «Ingredientes» after the description and the description image.
	 *
	 * @param array<int, array{id: string, title: string, content: string}> $tabs    Tabs.
	 * @param \WC_Product                                                   $product Product.
	 * @return array<int, array{id: string, title: string, content: string}>
	 */
	public static function tabs( array $tabs, \WC_Product $product ): array {
		$id    = $product->get_id();
		$image = (int) Fields::get( $id, Fields::IMAGE );

		foreach ( $tabs as $index => $tab ) {
			if ( 'description' === $tab['id'] && $image ) {
				$tabs[ $index ]['content'] .= wp_get_attachment_image( $image, 'large', false, array( 'class' => 'lc-desc-image' ) );
			}
		}

		$ingredients = (string) Fields::get( $id, Fields::INGREDIENTS );
		if ( '' !== trim( wp_strip_all_tags( $ingredients ) ) ) {
			$position = (int) array_search( 'description', array_column( $tabs, 'id' ), true ) + 1;
			array_splice(
				$tabs,
				$position,
				0,
				array(
					array(
						'id'      => 'ingredients',
						'title'   => __( 'Ingredientes', 'lachinata-core' ),
						'content' => wpautop( wp_kses_post( $ingredients ) ),
					),
				)
			);
		}
		return $tabs;
	}

	/**
	 * Seals (`tipo` terms) with their icon.
	 *
	 * @param array<int, array{name: string, url: string, image_id: int}> $seals   Seals.
	 * @param \WC_Product                                                 $product Product.
	 * @return array<int, array{name: string, url: string, image_id: int}>
	 */
	public static function seals( array $seals, \WC_Product $product ): array {
		$terms = get_the_terms( $product->get_id(), TipoTaxonomy::TAXONOMY );
		foreach ( is_array( $terms ) ? $terms : array() as $term ) {
			$link    = get_term_link( $term );
			$seals[] = array(
				'name'     => $term->name,
				'url'      => is_string( $link ) ? $link : '',
				'image_id' => Fields::icon( $term->term_id ),
			);
		}
		return $seals;
	}

	/**
	 * Best-before date in the product details.
	 *
	 * @param array<int, array{label: string, value: string}> $rows    Rows.
	 * @param \WC_Product                                     $product Product.
	 * @return array<int, array{label: string, value: string}>
	 */
	public static function details( array $rows, \WC_Product $product ): array {
		$date = (string) Fields::get( $product->get_id(), Fields::BEST_BEFORE );
		if ( '' !== $date ) {
			$rows[] = array(
				'label' => __( 'Consumo preferente', 'lachinata-core' ),
				'value' => wp_date( get_option( 'date_format' ), (int) strtotime( $date . ' 12:00:00' ) ),
			);
		}
		return $rows;
	}

	/**
	 * The product «etiqueta» as a neutral badge, before the theme's tag badges.
	 *
	 * @param array<int, array{text: string, tone: string}> $badges  Badges.
	 * @param \WC_Product                                   $product Product.
	 * @return array<int, array{text: string, tone: string}>
	 */
	public static function badges( array $badges, \WC_Product $product ): array {
		$label = (string) Fields::get( $product->get_id(), Fields::LABEL );
		if ( '' !== $label ) {
			array_unshift(
				$badges,
				array(
					'text' => $label,
					'tone' => '',
				)
			);
		}
		return $badges;
	}
}
