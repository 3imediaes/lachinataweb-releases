<?php
/**
 * Taxonomy `tipo`: product seals (100% Vegetal, Cruelty free…) with an icon.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

defined( 'ABSPATH' ) || exit;

/**
 * Registers the taxonomy that the current site gets from a plugin that does not travel.
 */
final class TipoTaxonomy {

	public const TAXONOMY = 'tipo';

	/**
	 * Registers the taxonomy.
	 */
	public static function register(): void {
		register_taxonomy(
			self::TAXONOMY,
			array( 'product' ),
			array(
				'labels'            => array(
					'name'          => _x( 'Sellos', 'taxonomy general name', 'lachinata-core' ),
					'singular_name' => _x( 'Sello', 'taxonomy singular name', 'lachinata-core' ),
					'search_items'  => __( 'Buscar sellos', 'lachinata-core' ),
					'all_items'     => __( 'Todos los sellos', 'lachinata-core' ),
					'edit_item'     => __( 'Editar sello', 'lachinata-core' ),
					'update_item'   => __( 'Actualizar sello', 'lachinata-core' ),
					'add_new_item'  => __( 'Añadir sello', 'lachinata-core' ),
					'new_item_name' => __( 'Nombre del sello', 'lachinata-core' ),
					'menu_name'     => __( 'Sellos', 'lachinata-core' ),
					'not_found'     => __( 'No hay sellos.', 'lachinata-core' ),
				),
				'public'            => true,
				'hierarchical'      => false,
				'show_admin_column' => true,
				'show_in_rest'      => true,
				'rewrite'           => array( 'slug' => self::TAXONOMY ),
			)
		);
	}
}
