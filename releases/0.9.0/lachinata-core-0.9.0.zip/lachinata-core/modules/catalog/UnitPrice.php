<?php
/**
 * Price per reference quantity.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Catalog;

defined( 'ABSPATH' ) || exit;

/**
 * Price ÷ content × reference, converting g↔kg and ml↔l.
 */
final class UnitPrice {

	/**
	 * Price for the reference quantity, or null when it cannot be calculated.
	 *
	 * @param float    $price     Product price.
	 * @param Quantity $content   Product content.
	 * @param Quantity $reference Reference quantity.
	 */
	public static function calculate( float $price, Quantity $content, Quantity $reference ): ?float {
		if ( $price <= 0 || ! $content->is_compatible( $reference ) ) {
			return null;
		}
		return $price / $content->in_base_unit() * $reference->in_base_unit();
	}

	/**
	 * Text for product cards and the product page: «500 ml | 9,33 € / 1 l».
	 * Without a reference (or with incompatible units) only the content: «500 ml».
	 *
	 * @param float         $price     Product price.
	 * @param Quantity|null $content   Product content.
	 * @param Quantity|null $reference Reference quantity.
	 * @return string HTML (prices go through wc_price()).
	 */
	public static function format( float $price, ?Quantity $content, ?Quantity $reference ): string {
		if ( null === $content ) {
			return '';
		}
		$per_reference = null === $reference ? null : self::calculate( $price, $content, $reference );
		if ( null === $per_reference ) {
			return esc_html( $content->label() );
		}
		return sprintf(
			/* translators: 1: content («500 ml»), 2: price, 3: reference quantity («1 l»). */
			esc_html__( '%1$s | %2$s / %3$s', 'lachinata-core' ),
			esc_html( $content->label() ),
			wc_price( $per_reference ),
			esc_html( $reference->label() )
		);
	}
}
