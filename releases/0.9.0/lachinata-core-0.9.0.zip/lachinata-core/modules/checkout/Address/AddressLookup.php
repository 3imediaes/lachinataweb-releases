<?php
/**
 * An address search service, asked from our server.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Checkout\Address;

defined( 'ABSPATH' ) || exit;

/**
 * What a provider of address autocomplete implements (Google Places, Geoapify, HERE…).
 * It runs on our server: its key never reaches the browser and the checkout loads no
 * third-party script. Register it with the filter `lachinata/checkout/address_lookup`.
 */
interface AddressLookup {

	/**
	 * Provider id (letters, digits and hyphens).
	 */
	public function id(): string;

	/**
	 * Name for the admin screen and the branding line under the suggestions.
	 */
	public function name(): string;

	/**
	 * Countries it can search (ISO codes); empty means all.
	 *
	 * @return string[]
	 */
	public function countries(): array;

	/**
	 * Suggestions for what the customer typed.
	 *
	 * @param string $query   Text typed in «Dirección».
	 * @param string $country ISO code of the chosen country.
	 * @return array<int, array{id: string, label: string, matches?: array<int, array{offset: int, length: int}>}>
	 */
	public function search( string $query, string $country ): array;

	/**
	 * The address of a suggestion, in WooCommerce's keys.
	 *
	 * @param string $id Suggestion id.
	 * @return array{address_1: string, address_2?: string, city: string, state?: string, postcode: string, country: string}|null
	 */
	public function select( string $id ): ?array;
}
