<?php
/**
 * Address autocomplete of the checkout.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Checkout\Address;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * Ready for a provider asked from our server; there is none yet (Alberto chooses it and its
 * cost). Without a lookup in `lachinata/checkout/address_lookup` nothing is registered and
 * the checkout keeps the browser's autofill and the province from the postcode. With one,
 * it becomes WooCommerce's address provider (its suggestion list in «Dirección») through
 * our REST routes.
 */
final class Autocomplete {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'woocommerce_address_providers', array( self::class, 'providers' ) );
		Hooks::add_filter( 'pre_option_woocommerce_address_autocomplete_enabled', array( self::class, 'enabled' ) );
		Hooks::add_action( 'rest_api_init', array( self::class, 'routes' ) );
	}

	/**
	 * The lookup in use, or null.
	 */
	public static function lookup(): ?AddressLookup {
		/**
		 * Address search service for the checkout, asked from our server.
		 *
		 * @since 0.5.0
		 *
		 * @param AddressLookup|null $lookup Lookup; null for none (browser autofill only).
		 */
		$lookup = apply_filters( 'lachinata/checkout/address_lookup', null );
		return $lookup instanceof AddressLookup ? $lookup : null;
	}

	/**
	 * Adds our provider for WooCommerce.
	 *
	 * @param array<int, mixed> $providers Providers.
	 * @return array<int, mixed>
	 */
	public static function providers( $providers ): array {
		$providers = is_array( $providers ) ? $providers : array();
		$lookup    = self::lookup();
		if ( null !== $lookup ) {
			$providers[] = new ServerProvider( $lookup );
		}
		return $providers;
	}

	/**
	 * WooCommerce's autocomplete is on while there is a lookup (its setting otherwise).
	 *
	 * @param mixed $value Pre-option value.
	 * @return mixed
	 */
	public static function enabled( $value ) {
		return null === self::lookup() ? $value : 'yes';
	}

	/**
	 * REST routes, only with a lookup.
	 */
	public static function routes(): void {
		$lookup = self::lookup();
		if ( null !== $lookup ) {
			Rest::register( $lookup );
		}
	}

	/**
	 * Data for the checkout script, or null without a lookup.
	 *
	 * @return array{id: string, countries: string[], url: string}|null
	 */
	public static function script_data(): ?array {
		$lookup = self::lookup();
		if ( null === $lookup ) {
			return null;
		}
		return array(
			'id'        => ( new ServerProvider( $lookup ) )->id,
			'countries' => array_values( $lookup->countries() ),
			'url'       => esc_url_raw( rest_url( 'lachinata/v1/address/' ) ),
		);
	}
}
