<?php
/**
 * REST routes of the address autocomplete.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Checkout\Address;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * GET lachinata/v1/address/search?q=&country= and lachinata/v1/address/select?id=. Public
 * (the checkout is for guests too) with a limit per visitor, so nobody spends the
 * provider's quota from outside the checkout.
 */
final class Rest {

	/**
	 * Requests per visitor and minute.
	 */
	public const LIMIT = 60;

	/**
	 * Registers the routes.
	 *
	 * @param AddressLookup $lookup Lookup.
	 */
	public static function register( AddressLookup $lookup ): void {
		register_rest_route(
			'lachinata/v1',
			'/address/search',
			array(
				'methods'             => 'GET',
				'permission_callback' => Hooks::wrap( array( self::class, 'allowed' ), false ),
				'args'                => array(
					'q'       => array(
						'type'     => 'string',
						'required' => true,
					),
					'country' => array(
						'type'     => 'string',
						'required' => true,
					),
				),
				'callback'            => Hooks::rest(
					static function ( \WP_REST_Request $request ) use ( $lookup ) {
						$query   = sanitize_text_field( (string) $request['q'] );
						$country = strtoupper( sanitize_key( (string) $request['country'] ) );
						if ( mb_strlen( $query ) < 3 || ( $lookup->countries() && ! in_array( $country, $lookup->countries(), true ) ) ) {
							return rest_ensure_response( array() );
						}
						$found = array();
						foreach ( $lookup->search( $query, $country ) as $item ) {
							$found[] = array(
								'id'                => (string) $item['id'],
								'label'             => (string) $item['label'],
								'matchedSubstrings' => array_values( (array) ( $item['matches'] ?? array() ) ),
							);
						}
						return rest_ensure_response( $found );
					}
				),
			)
		);
		register_rest_route(
			'lachinata/v1',
			'/address/select',
			array(
				'methods'             => 'GET',
				'permission_callback' => Hooks::wrap( array( self::class, 'allowed' ), false ),
				'args'                => array(
					'id' => array(
						'type'     => 'string',
						'required' => true,
					),
				),
				'callback'            => Hooks::rest(
					static function ( \WP_REST_Request $request ) use ( $lookup ) {
						$address = $lookup->select( sanitize_text_field( (string) $request['id'] ) );
						return null === $address
						? new \WP_Error( 'lachinata_address_not_found', __( 'No encontramos esa dirección.', 'lachinata-core' ), array( 'status' => 404 ) )
						: rest_ensure_response( $address );
					}
				),
			)
		);
	}

	/**
	 * Limit per visitor: LIMIT requests a minute.
	 */
	public static function allowed(): bool {
		$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		$key = 'lachinata_address_' . md5( $ip );
		$n   = (int) get_transient( $key );
		if ( $n >= self::LIMIT ) {
			return false;
		}
		set_transient( $key, $n + 1, MINUTE_IN_SECONDS );
		return true;
	}
}
