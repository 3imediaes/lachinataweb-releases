<?php
/**
 * The address lookup as a WooCommerce address provider.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Checkout\Address;

defined( 'ABSPATH' ) || exit;

/**
 * WooCommerce's address autocomplete (`woocommerce_address_providers`) with our lookup
 * behind: the browser asks our REST routes (Rest.php), never the provider.
 */
final class ServerProvider extends \WC_Address_Provider {

	/**
	 * Wraps the lookup.
	 *
	 * @param AddressLookup $lookup Lookup.
	 */
	public function __construct( AddressLookup $lookup ) {
		$this->id   = 'lachinata-' . sanitize_key( $lookup->id() );
		$this->name = $lookup->name();
	}
}
