<?php
/**
 * The card an order was paid with.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Checkout;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * The emails say how an order was paid with the method and, with a card, its last four
 * digits («Tarjeta ···· 4242»; 06-correos.md, «Reglas de contenido de las piezas»). Stripe
 * keeps only the payment method's id on the order (`_stripe_source_id`, `pm_…`), so the card
 * is read once from Stripe when the payment completes (before the emails of that status)
 * and kept as `_lc_tarjeta` (last four digits and wallet). A wallet shows its name («Apple
 * Pay»). If Stripe cannot answer, the method's title is enough and it is not asked again.
 */
final class CardDetails {

	/**
	 * Order meta: `last4` and `wallet` (apple_pay, google_pay…), both possibly empty.
	 */
	public const META = '_lc_tarjeta';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'woocommerce_pre_payment_complete', array( self::class, 'on_payment' ) );
		Hooks::add_filter( 'lachinata/order/payment_label', array( self::class, 'label' ), 10, 2 );
	}

	/**
	 * Reads the card when the payment completes.
	 *
	 * @param mixed $order_id Order id.
	 */
	public static function on_payment( $order_id ): void {
		$order = wc_get_order( (int) $order_id );
		if ( $order instanceof \WC_Order ) {
			self::of( $order );
		}
	}

	/**
	 * The card of a Stripe order, read once.
	 *
	 * @param \WC_Order $order Order.
	 * @return array{last4: string, wallet: string}|null Null for other methods.
	 */
	public static function of( \WC_Order $order ): ?array {
		if ( ! str_starts_with( (string) $order->get_payment_method(), 'stripe' ) ) {
			return null;
		}
		$saved = $order->get_meta( self::META );
		if ( is_array( $saved ) ) {
			return array(
				'last4'  => (string) ( $saved['last4'] ?? '' ),
				'wallet' => (string) ( $saved['wallet'] ?? '' ),
			);
		}
		$card = array(
			'last4'  => '',
			'wallet' => '',
		);
		$id   = (string) $order->get_meta( '_stripe_source_id' );
		if ( '' === $id ) {
			// Not paid yet: nothing to keep, it is read when the payment completes.
			return $card;
		}
		if ( is_callable( array( 'WC_Stripe_API', 'get_payment_method' ) ) ) {
			try {
				$method = call_user_func( array( 'WC_Stripe_API', 'get_payment_method' ), $id );
				if ( is_object( $method ) && isset( $method->card ) && is_object( $method->card ) ) {
					$card['last4']  = preg_match( '/^\d{4}$/', (string) ( $method->card->last4 ?? '' ) ) ? (string) $method->card->last4 : '';
					$card['wallet'] = isset( $method->card->wallet ) && is_object( $method->card->wallet ) ? sanitize_key( (string) ( $method->card->wallet->type ?? '' ) ) : '';
				}
			} catch ( \Throwable $error ) {
				unset( $error ); // The title of the method is shown instead.
			}
		}
		$order->update_meta_data( self::META, $card );
		$order->save_meta_data();
		return $card;
	}

	/**
	 * «Tarjeta ···· 4242», «Apple Pay» or «Google Pay» for a Stripe order.
	 *
	 * @param mixed $label Method title.
	 * @param mixed $order Order.
	 */
	public static function label( $label, $order = null ): string {
		$label = (string) $label;
		$card  = $order instanceof \WC_Order ? self::of( $order ) : null;
		if ( null === $card ) {
			return $label;
		}
		$wallets = array(
			'apple_pay'  => 'Apple Pay',
			'google_pay' => 'Google Pay',
		);
		if ( isset( $wallets[ $card['wallet'] ] ) ) {
			return $wallets[ $card['wallet'] ];
		}
		/* translators: %s: last four digits of the card. */
		return '' !== $card['last4'] ? sprintf( __( 'Tarjeta ···· %s', 'lachinata-core' ), $card['last4'] ) : $label;
	}
}
