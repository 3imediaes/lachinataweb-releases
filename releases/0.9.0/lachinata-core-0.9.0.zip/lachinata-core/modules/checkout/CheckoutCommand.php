<?php
/**
 * WP-CLI: wp lachinata checkout.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Checkout;

defined( 'ABSPATH' ) || exit;

/**
 * Composes the checkout page.
 */
final class CheckoutCommand {

	/**
	 * Composes the checkout page as the system wants it (Page.php): our block and the
	 * delivery instructions after the shipping options, express buttons at 44 px and
	 * «Pagar» with the total. Running it again changes nothing.
	 *
	 * ## OPTIONS
	 *
	 * [--dry-run]
	 * : Prints the composed content without saving it.
	 *
	 * ## EXAMPLES
	 *
	 *     wp lachinata checkout install-page
	 *
	 * @subcommand install-page
	 *
	 * @param string[]              $args       Positional arguments.
	 * @param array<string, string> $assoc_args Options.
	 */
	public function install_page( array $args, array $assoc_args ): void {
		unset( $args );
		$page_id = (int) wc_get_page_id( 'checkout' );
		$content = $page_id > 0 ? (string) get_post_field( 'post_content', $page_id ) : '';
		if ( '' === $content ) {
			\WP_CLI::error( __( 'No hay página de checkout (WooCommerce → Ajustes → Avanzado → Configuración de la página).', 'lachinata-core' ) );
		}
		$composed = Page::compose( $content );
		if ( null === $composed ) {
			\WP_CLI::error( __( 'La página de checkout no tiene el bloque de checkout de WooCommerce.', 'lachinata-core' ) );
		}
		if ( isset( $assoc_args['dry-run'] ) ) {
			\WP_CLI::line( $composed );
			return;
		}
		if ( $composed === $content ) {
			\WP_CLI::success( __( 'La página de checkout ya estaba compuesta.', 'lachinata-core' ) );
			return;
		}
		$result = wp_update_post(
			array(
				'ID'           => $page_id,
				'post_content' => wp_slash( $composed ),
			),
			true
		);
		if ( is_wp_error( $result ) ) {
			\WP_CLI::error( $result->get_error_message() );
		}
		/* translators: %d: page id. */
		\WP_CLI::success( sprintf( __( 'Página de checkout compuesta (ID %d).', 'lachinata-core' ), $page_id ) );
	}
}
