<?php
/**
 * WooCommerce → La Chinata → Checkout.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Checkout;

use LaChinata\Core\Admin\Screen;
use LaChinata\Core\Hooks;
use LaChinata\Core\Plugin;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Settings of the checkout (the page of the «Contactar» way out, the delivery instructions)
 * and the gaps found while
 * serving it (a script that needs a package the checkout leaves out…).
 */
final class CheckoutTab {

	/**
	 * Tab id.
	 */
	public const TAB = 'checkout';

	/**
	 * Actions of admin-post.php, also nonce actions.
	 */
	private const SAVE       = 'lachinata_checkout_settings';
	private const CLEAR_GAPS = 'lachinata_checkout_clear_gaps';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/core/admin_tabs', array( self::class, 'tab' ), 30 );
		Hooks::add_action( 'admin_post_' . self::SAVE, array( self::class, 'handle' ) );
		Hooks::add_action( 'admin_post_' . self::CLEAR_GAPS, array( self::class, 'handle' ) );
	}

	/**
	 * Adds the tab before the core tabs (Módulos, Exportar e importar, Actualizaciones).
	 *
	 * @param array<string, array{label: string, render: callable}> $tabs Tabs.
	 * @return array<string, array{label: string, render: callable}>
	 */
	public static function tab( array $tabs ): array {
		$position = array_search( 'eta', array_keys( $tabs ), true );
		$position = false === $position ? array_search( 'shipping', array_keys( $tabs ), true ) : $position;
		$position = false === $position ? 1 : $position + 1;
		$tab      = array(
			self::TAB => array(
				'label'  => __( 'Checkout', 'lachinata-core' ),
				'render' => array( self::class, 'render' ),
			),
		);
		return array_slice( $tabs, 0, $position, true ) + $tab + $tabs;
	}

	/**
	 * Prints the tab.
	 */
	public static function render(): void {
		$sections = array(
			'settings' => __( 'Ajustes', 'lachinata-core' ),
			'gaps'     => __( 'Huecos de configuración', 'lachinata-core' ),
		);
		$current  = isset( $_GET['section'] ) ? sanitize_key( wp_unslash( $_GET['section'] ) ) : 'settings'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Navigation only.
		$current  = isset( $sections[ $current ] ) ? $current : 'settings';
		Screen::section_links( self::TAB, $sections, $current );

		if ( 'gaps' === $current ) {
			self::render_gaps();
		} else {
			self::render_settings();
		}
	}

	/**
	 * Settings section.
	 */
	private static function render_settings(): void {
		$module = Plugin::instance()->modules()->get( 'checkout' );
		$url    = null === $module ? '' : (string) Settings::get( $module, 'contact_url' );
		$notes  = CheckoutModule::delivery_notes();
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE ); ?>">
			<?php wp_nonce_field( self::SAVE ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="lc-contact-url"><?php esc_html_e( 'Página de contacto', 'lachinata-core' ); ?></label></th>
					<td>
						<input type="url" class="regular-text" id="lc-contact-url" name="contact_url" value="<?php echo esc_attr( $url ); ?>" placeholder="https://">
						<p class="description"><?php esc_html_e( 'Destino del botón «Contactar» cuando no hay envío para el pedido. Vacío: el botón no se muestra.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Instrucciones para el repartidor', 'lachinata-core' ); ?></th>
					<td>
						<label for="lc-delivery-notes"><input type="checkbox" id="lc-delivery-notes" name="delivery_notes" value="1" <?php checked( $notes ); ?>> <?php esc_html_e( 'Pedir instrucciones para el repartidor en la tarjeta de envío', 'lachinata-core' ); ?></label>
						<p class="description"><?php esc_html_e( 'Apagado, el checkout no las pide. Se guardan como la nota del pedido de WooCommerce.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
		<?php
	}

	/**
	 * Gaps section.
	 */
	private static function render_gaps(): void {
		$log    = Assets::gaps()->all();
		$module = Plugin::instance()->modules()->get( 'checkout' );
		?>
		<?php if ( null !== $module && '' === (string) Settings::get( $module, 'contact_url' ) ) : ?>
			<ul class="ul-disc"><li><?php esc_html_e( 'Sin página de contacto: cuando no hay envío, el checkout no ofrece «Contactar» (Ajustes).', 'lachinata-core' ); ?></li></ul>
		<?php endif; ?>
		<h2><?php esc_html_e( 'Lo que el checkout no pudo aligerar', 'lachinata-core' ); ?></h2>
		<p class="description"><?php esc_html_e( 'El checkout deja fuera paquetes que no usa. Si un plugin o una pasarela los necesita, se cargan igualmente y queda anotado aquí y en WooCommerce → Estado → Registros (lachinata-checkout).', 'lachinata-core' ); ?></p>
		<?php if ( $log ) : ?>
			<table class="widefat striped">
				<thead><tr><th scope="col"><?php esc_html_e( 'Qué pasó', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Veces', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Última', 'lachinata-core' ); ?></th></tr></thead>
				<tbody>
					<?php foreach ( $log as $entry ) : ?>
						<tr>
							<td><?php echo esc_html( $entry['message'] ); ?></td>
							<td><?php echo esc_html( number_format_i18n( $entry['count'] ) ); ?></td>
							<td><?php echo esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $entry['last'] ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::CLEAR_GAPS ); ?>">
				<?php wp_nonce_field( self::CLEAR_GAPS ); ?>
				<?php submit_button( __( 'Vaciar la lista', 'lachinata-core' ), 'secondary' ); ?>
			</form>
		<?php else : ?>
			<p><?php esc_html_e( 'Ninguno registrado.', 'lachinata-core' ); ?></p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Saves the settings or empties the gap log.
	 */
	public static function handle(): void {
		$action = current_action() === 'admin_post_' . self::SAVE ? self::SAVE : self::CLEAR_GAPS;
		Screen::check( $action );
		if ( self::SAVE === $action ) {
			$module = Plugin::instance()->modules()->get( 'checkout' );
			if ( null !== $module ) {
				Settings::set( $module, 'contact_url', isset( $_POST['contact_url'] ) ? esc_url_raw( wp_unslash( $_POST['contact_url'] ) ) : '' ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Screen::check().
				Settings::set( $module, 'delivery_notes', ! empty( $_POST['delivery_notes'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Screen::check().
			}
			Screen::flash( 'success', array( __( 'Ajustes guardados.', 'lachinata-core' ) ) );
			Screen::redirect( self::TAB, array( 'section' => 'settings' ) );
		}
		Assets::gaps()->clear();
		Screen::flash( 'success', array( __( 'Lista vaciada.', 'lachinata-core' ) ) );
		Screen::redirect( self::TAB, array( 'section' => 'gaps' ) );
	}
}
