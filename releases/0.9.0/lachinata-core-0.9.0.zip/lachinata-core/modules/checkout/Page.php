<?php
/**
 * Composition of the checkout page.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Checkout;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * The checkout page as the system wants it (CheckoutSection cards in a fixed order), on top
 * of WooCommerce's default checkout block:
 *
 * Contacto · Envío (delivery address, shipping options, our after-shipping block and the
 * delivery instructions, shown only with the module's setting) · ¿Es un regalo? (slot of the
 * gift module) · Facturación (our tabs, WooCommerce's order fields with Empresa and NIF, our
 * billing choice, WooCommerce's billing address) · Pago · legal line and one primary button
 * «Pagar 69,85 €».
 *
 * Express buttons at 44 px with square corners, «Pago cifrado» as the note of the payment
 * step and no product descriptions in the order summary. Inner blocks the page does not know
 * (another plugin's) keep their order, before the legal line. Idempotent.
 */
final class Page {

	/**
	 * Fields area of the checkout.
	 */
	private const FIELDS = 'woocommerce/checkout-fields-block';

	/**
	 * Block after the shipping options (blocks/after-shipping).
	 */
	public const AFTER_SHIPPING = 'lachinata/checkout-after-shipping';

	/**
	 * Slot of the gift module, between Envío and Facturación (blocks/gift).
	 */
	public const GIFT = 'lachinata/checkout-gift';

	/**
	 * Head of the Facturación card with the tabs Particular | Empresa / Autónomo
	 * (blocks/billing-type).
	 */
	public const BILLING_TYPE = 'lachinata/checkout-billing-type';

	/**
	 * Billing address choice (blocks/billing).
	 */
	public const BILLING = 'lachinata/checkout-billing';

	/**
	 * WooCommerce's order note: the delivery instructions.
	 */
	public const ORDER_NOTE = 'woocommerce/checkout-order-note-block';

	/**
	 * Inner blocks of the fields area, in the order of the page. The pickup blocks render
	 * nothing while local pickup is off.
	 */
	private const ORDER = array(
		'woocommerce/checkout-express-payment-block',
		'woocommerce/checkout-contact-information-block',
		'woocommerce/checkout-shipping-method-block',
		'woocommerce/checkout-pickup-options-block',
		'woocommerce/checkout-shipping-address-block',
		'woocommerce/checkout-shipping-methods-block',
		self::AFTER_SHIPPING,
		self::ORDER_NOTE,
		self::GIFT,
		self::BILLING_TYPE,
		'woocommerce/checkout-additional-information-block',
		self::BILLING,
		'woocommerce/checkout-billing-address-block',
		'woocommerce/checkout-payment-block',
		'woocommerce/checkout-terms-block',
		'woocommerce/checkout-actions-block',
	);

	/**
	 * Our blocks: the page adds them when they are missing.
	 */
	private const OURS = array( self::AFTER_SHIPPING, self::GIFT, self::BILLING_TYPE, self::BILLING );

	/**
	 * Attributes the page fixes, by block (also inside the order summary).
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public static function attributes(): array {
		return array(
			'woocommerce/checkout-express-payment-block' => array(
				'showButtonStyles'   => true,
				'buttonHeight'       => '44',
				'buttonBorderRadius' => '0',
			),
			'woocommerce/checkout-payment-block'         => array(
				'description' => __( 'Pago cifrado', 'lachinata-core' ),
			),
			'woocommerce/checkout-actions-block'         => array(
				'placeOrderButtonLabel' => __( 'Pagar', 'lachinata-core' ),
				'priceSeparator'        => ' ',
				'className'             => 'is-style-with-price',
			),
			'woocommerce/checkout-order-summary-cart-items-block' => array(
				'disableProductDescriptions' => true,
			),
		);
	}

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'render_block_data', array( self::class, 'render_data' ) );
	}

	/**
	 * Without the module's setting, the page is served without the delivery instructions
	 * (the block stays in the content, in its place, for when the setting is on).
	 *
	 * @param array<string, mixed> $block Parsed block about to render.
	 * @return array<string, mixed>
	 */
	public static function render_data( array $block ): array {
		if ( self::FIELDS !== ( $block['blockName'] ?? '' ) || CheckoutModule::delivery_notes() ) {
			return $block;
		}
		return self::without( $block, self::ORDER_NOTE );
	}

	/**
	 * The composed page.
	 *
	 * @param string $content Current content of the checkout page.
	 * @return string|null Composed content, or null when there is no checkout block.
	 */
	public static function compose( string $content ): ?string {
		$blocks = parse_blocks( $content );
		$found  = false;
		foreach ( $blocks as &$block ) {
			if ( 'woocommerce/checkout' !== $block['blockName'] ) {
				continue;
			}
			foreach ( $block['innerBlocks'] as &$inner ) {
				if ( self::FIELDS === $inner['blockName'] ) {
					$inner = self::fields( $inner );
					$found = true;
				} else {
					$inner = self::with_nested_attributes( $inner );
				}
			}
			unset( $inner );
		}
		unset( $block );
		return $found ? serialize_blocks( $blocks ) : null;
	}

	/**
	 * The fields area in the order of the page, with our blocks and the attributes set.
	 *
	 * @param array<string, mixed> $fields Parsed fields block.
	 * @return array<string, mixed>
	 */
	private static function fields( array $fields ): array {
		$known   = array();
		$unknown = array();
		foreach ( $fields['innerBlocks'] as $child ) {
			$name = (string) $child['blockName'];
			if ( in_array( $name, self::ORDER, true ) ) {
				$known[ $name ] = self::with_attributes( $child );
			} else {
				$unknown[] = $child;
			}
		}
		foreach ( self::OURS as $name ) {
			$known[ $name ] ??= self::empty_block( $name );
		}

		$composed = array();
		foreach ( self::ORDER as $name ) {
			if ( 'woocommerce/checkout-terms-block' === $name ) {
				array_push( $composed, ...$unknown );
			}
			if ( isset( $known[ $name ] ) ) {
				$composed[] = $known[ $name ];
			}
		}
		if ( ! isset( $known['woocommerce/checkout-terms-block'] ) ) {
			// No legal line: the unknown blocks go before the button, at the end.
			$actions = array_pop( $composed );
			array_push( $composed, ...$unknown );
			$composed[] = $actions;
		}

		return self::with_children( $fields, array_values( array_filter( $composed ) ) );
	}

	/**
	 * A block without one of its inner blocks.
	 *
	 * @param array<string, mixed> $block Parsed block.
	 * @param string               $name  Inner block to leave out.
	 * @return array<string, mixed>
	 */
	public static function without( array $block, string $name ): array {
		$children = array_values(
			array_filter(
				(array) $block['innerBlocks'],
				static fn( array $child ): bool => $name !== $child['blockName']
			)
		);
		return count( $children ) === count( (array) $block['innerBlocks'] ) ? $block : self::with_children( $block, $children );
	}

	/**
	 * A wrapper block with new inner blocks, one per line, inside its own HTML.
	 *
	 * @param array<string, mixed>        $block    Parsed block.
	 * @param array<array<string, mixed>> $children Inner blocks.
	 * @return array<string, mixed>
	 */
	private static function with_children( array $block, array $children ): array {
		$open  = '<div class="' . esc_attr( 'wp-block-' . str_replace( '/', '-', (string) $block['blockName'] ) ) . '">';
		$inner = array( $open );
		foreach ( array_keys( $children ) as $i ) {
			if ( $i > 0 ) {
				$inner[] = "\n\n";
			}
			$inner[] = null;
		}
		$inner[] = '</div>';

		$block['innerBlocks']  = $children;
		$block['innerHTML']    = $open . '</div>';
		$block['innerContent'] = $inner;
		return $block;
	}

	/**
	 * A block and its inner blocks with the page's attributes.
	 *
	 * @param array<string, mixed> $block Parsed block.
	 * @return array<string, mixed>
	 */
	private static function with_nested_attributes( array $block ): array {
		foreach ( $block['innerBlocks'] as &$inner ) {
			$inner = self::with_nested_attributes( $inner );
		}
		unset( $inner );
		return array() === $block['innerBlocks'] ? self::with_attributes( $block ) : $block;
	}

	/**
	 * A block with the page's attributes, its class kept in its HTML.
	 *
	 * @param array<string, mixed> $block Parsed block.
	 * @return array<string, mixed>
	 */
	private static function with_attributes( array $block ): array {
		$fixed = self::attributes()[ $block['blockName'] ] ?? null;
		if ( null === $fixed ) {
			return $block;
		}
		$block['attrs'] = array_merge( (array) $block['attrs'], $fixed );
		$class          = 'wp-block-' . str_replace( '/', '-', (string) $block['blockName'] );
		$class         .= isset( $fixed['className'] ) ? ' ' . $fixed['className'] : '';
		$html           = '<div class="' . esc_attr( $class ) . '"></div>';

		$block['innerHTML']    = $html;
		$block['innerContent'] = array( $html );
		return $block;
	}

	/**
	 * An inner block with no content (its front end is the module's script).
	 *
	 * @param string $name Block name.
	 * @return array<string, mixed>
	 */
	private static function empty_block( string $name ): array {
		$html = '<div class="wp-block-' . str_replace( '/', '-', $name ) . '"></div>';
		return array(
			'blockName'    => $name,
			'attrs'        => array(),
			'innerBlocks'  => array(),
			'innerHTML'    => $html,
			'innerContent' => array( $html ),
		);
	}
}
