<?php
/**
 * Spanish provinces by postcode.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Checkout;

defined( 'ABSPATH' ) || exit;

/**
 * In Spain the first two digits of the postcode are the province (07 Illes Balears,
 * 35 Las Palmas and 38 Santa Cruz de Tenerife, 51 Ceuta, 52 Melilla). The checkout fills
 * the province from the postcode (visible and editable): the shipping zones depend on it.
 */
final class Provinces {

	/**
	 * Postcode prefix → WooCommerce state code (WC()->countries->get_states( 'ES' )).
	 */
	public const ES = array(
		'01' => 'VI',
		'02' => 'AB',
		'03' => 'A',
		'04' => 'AL',
		'05' => 'AV',
		'06' => 'BA',
		'07' => 'PM',
		'08' => 'B',
		'09' => 'BU',
		'10' => 'CC',
		'11' => 'CA',
		'12' => 'CS',
		'13' => 'CR',
		'14' => 'CO',
		'15' => 'C',
		'16' => 'CU',
		'17' => 'GI',
		'18' => 'GR',
		'19' => 'GU',
		'20' => 'SS',
		'21' => 'H',
		'22' => 'HU',
		'23' => 'J',
		'24' => 'LE',
		'25' => 'L',
		'26' => 'LO',
		'27' => 'LU',
		'28' => 'M',
		'29' => 'MA',
		'30' => 'MU',
		'31' => 'NA',
		'32' => 'OR',
		'33' => 'O',
		'34' => 'P',
		'35' => 'GC',
		'36' => 'PO',
		'37' => 'SA',
		'38' => 'TF',
		'39' => 'S',
		'40' => 'SG',
		'41' => 'SE',
		'42' => 'SO',
		'43' => 'T',
		'44' => 'TE',
		'45' => 'TO',
		'46' => 'V',
		'47' => 'VA',
		'48' => 'BI',
		'49' => 'ZA',
		'50' => 'Z',
		'51' => 'CE',
		'52' => 'ML',
	);

	/**
	 * Province of a Spanish postcode, or null.
	 *
	 * @param string $postcode Postcode as typed.
	 */
	public static function of( string $postcode ): ?string {
		$digits = (string) preg_replace( '/\D/', '', $postcode );
		return strlen( $digits ) >= 2 ? ( self::ES[ substr( $digits, 0, 2 ) ] ?? null ) : null;
	}
}
