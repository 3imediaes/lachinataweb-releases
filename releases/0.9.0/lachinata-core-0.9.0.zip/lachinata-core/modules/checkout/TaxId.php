<?php
/**
 * Tax ids for company invoices.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Checkout;

defined( 'ABSPATH' ) || exit;

/**
 * Checks the tax id of a company invoice against the billing country: in Spain a NIF (DNI),
 * NIE or CIF with its control character; in the rest of the EU a VAT number with its country
 * prefix (format only; VIES is not asked); elsewhere, any id. Returns the id normalised
 * (upper case, no spaces, dots or hyphens) or the error written as an instruction.
 */
final class TaxId {

	/**
	 * Letters of the DNI/NIE control character (position = number mod 23).
	 */
	private const DNI_LETTERS = 'TRWAGMYFPDXBNJZSQVHLCKE';

	/**
	 * VAT number format after the prefix, per EU country (VAT prefix => pattern).
	 */
	private const EU_VAT = array(
		'AT' => 'U\d{8}',
		'BE' => '[01]\d{9}',
		'BG' => '\d{9,10}',
		'CY' => '\d{8}[A-Z]',
		'CZ' => '\d{8,10}',
		'DE' => '\d{9}',
		'DK' => '\d{8}',
		'EE' => '\d{9}',
		'EL' => '\d{9}',
		'ES' => '[A-Z0-9]\d{7}[A-Z0-9]',
		'FI' => '\d{8}',
		'FR' => '[A-HJ-NP-Z0-9]{2}\d{9}',
		'HR' => '\d{11}',
		'HU' => '\d{8}',
		'IE' => '\d{7}[A-W][A-I]?|\d[A-Z+*]\d{5}[A-W]',
		'IT' => '\d{11}',
		'LT' => '\d{9}|\d{12}',
		'LU' => '\d{8}',
		'LV' => '\d{11}',
		'MT' => '\d{8}',
		'NL' => '\d{9}B\d{2}',
		'PL' => '\d{10}',
		'PT' => '\d{9}',
		'RO' => '\d{2,10}',
		'SE' => '\d{12}',
		'SI' => '\d{8}',
		'SK' => '\d{10}',
	);

	/**
	 * Normalised id, or the error for the customer.
	 *
	 * @param string $id      Tax id as typed.
	 * @param string $country Billing country (ISO code).
	 * @return array{id: string, error: string} `error` empty when valid.
	 */
	public static function check( string $id, string $country ): array {
		$normal  = strtoupper( (string) preg_replace( '/[\s.\-\/]/', '', $id ) );
		$country = strtoupper( $country );
		if ( '' === $normal ) {
			return array(
				'id'    => '',
				'error' => __( 'Escribe el NIF de la empresa.', 'lachinata-core' ),
			);
		}

		if ( 'ES' === $country ) {
			$spanish = (string) preg_replace( '/^ES/', '', $normal );
			return self::spanish( $spanish )
				? array(
					'id'    => $spanish,
					'error' => '',
				)
				: array(
					'id'    => $normal,
					'error' => 9 === strlen( $spanish )
						? __( 'Revisa el NIF/CIF: la letra o el último número no corresponden.', 'lachinata-core' )
						: __( 'Revisa el NIF/CIF: tiene 9 caracteres, como 12345678Z o B12345674.', 'lachinata-core' ),
				);
		}

		$prefix = 'GR' === $country ? 'EL' : $country;
		if ( isset( self::EU_VAT[ $prefix ] ) ) {
			$vat = str_starts_with( $normal, $prefix ) ? $normal : $prefix . $normal;
			$ok  = (bool) preg_match( '/^' . $prefix . '(' . self::EU_VAT[ $prefix ] . ')$/', $vat );
			return $ok
				? array(
					'id'    => $vat,
					'error' => '',
				)
				: array(
					'id'    => $normal,
					/* translators: %1$s: VAT prefix of the country («DE», «FR»). */
					'error' => sprintf( __( 'Escribe el NIF-IVA de la empresa con su prefijo %1$s, por ejemplo %1$s123456789.', 'lachinata-core' ), $prefix ),
				);
		}

		return strlen( $normal ) >= 3
			? array(
				'id'    => $normal,
				'error' => '',
			)
			: array(
				'id'    => $normal,
				'error' => __( 'Escribe el número de identificación fiscal de la empresa.', 'lachinata-core' ),
			);
	}

	/**
	 * Spanish NIF (DNI), NIE or CIF with a valid control character.
	 *
	 * @param string $id Normalised id without prefix.
	 */
	public static function spanish( string $id ): bool {
		if ( preg_match( '/^(\d{8})([A-Z])$/', $id, $m ) ) {
			return self::DNI_LETTERS[ (int) $m[1] % 23 ] === $m[2];
		}
		if ( preg_match( '/^([XYZ])(\d{7})([A-Z])$/', $id, $m ) ) {
			$number = (int) ( strpos( 'XYZ', $m[1] ) . $m[2] );
			return self::DNI_LETTERS[ $number % 23 ] === $m[3];
		}
		if ( preg_match( '/^([ABCDEFGHJNPQRSUVW])(\d{7})([0-9A-J])$/', $id, $m ) ) {
			$sum = 0;
			foreach ( str_split( $m[2] ) as $i => $digit ) {
				$n    = (int) $digit;
				$sum += 0 === $i % 2 ? array_sum( str_split( (string) ( $n * 2 ) ) ) : $n;
			}
			$control = ( 10 - $sum % 10 ) % 10;
			$letter  = 'JABCDEFGHI'[ $control ];
			if ( in_array( $m[1], array( 'P', 'Q', 'R', 'S', 'N', 'W' ), true ) ) {
				return $m[3] === $letter;
			}
			if ( in_array( $m[1], array( 'A', 'B', 'E', 'H' ), true ) ) {
				return $m[3] === (string) $control;
			}
			return $m[3] === (string) $control || $m[3] === $letter;
		}
		return false;
	}
}
