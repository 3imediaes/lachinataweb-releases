/**
 * Address autocomplete through our server (Address/Autocomplete.php): registers the
 * provider in WooCommerce's autocomplete, which draws the suggestion list under
 * «Dirección». Without a provider configured there is nothing to register.
 */
import { settings } from './settings';

async function get(path, params) {
	const url = new URL(path, settings.addressLookup.url);
	Object.entries(params).forEach(([key, value]) =>
		url.searchParams.set(key, value)
	);
	const response = await window.fetch(url, { credentials: 'same-origin' });
	if (!response.ok) {
		throw new Error(`address ${path}: ${response.status}`);
	}
	return response.json();
}

export function initAddress() {
	const lookup = settings.addressLookup;
	const register =
		window.wc?.addressAutocomplete?.registerAddressAutocompleteProvider;
	if (!lookup || !register) {
		return;
	}
	register({
		id: lookup.id,
		canSearch: (country) =>
			!lookup.countries.length || lookup.countries.includes(country),
		search: (query, country) =>
			get('search', { q: query, country }).catch(() => []),
		select: (id) => get('select', { id }),
	});
}
