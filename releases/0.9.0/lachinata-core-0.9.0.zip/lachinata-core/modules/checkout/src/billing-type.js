/**
 * Block `lachinata/checkout-billing-type`: head of the Facturación card (CheckoutSection,
 * icon `receipt`) and the tabs Particular | Empresa / Autónomo (Tabs). The rest of the card
 * are its siblings, joined by the theme: WooCommerce's order fields (Empresa and NIF / CIF),
 * our billing choice and WooCommerce's billing address.
 *
 * The tab sets the box «Necesito factura a nombre de una empresa» (`lachinata/company-invoice`,
 * Invoice.php) through WooCommerce's public action `setAdditionalFields`: same rules as the
 * box (Empresa and NIF / CIF shown and required only when it is set), another interface. The
 * theme hides the box while there are tabs; without that action the block draws only the
 * head and the box stays (plugin/modules/checkout/README.md).
 */
import { useSelect, dispatch, select } from '@wordpress/data';
import { useRef } from '@wordpress/element';
import { __ } from '@wordpress/i18n';
import { CHECKOUT_STORE } from './settings';
import metadata from '../blocks/billing-type/block.json';

const { registerCheckoutBlock } = window.wc.blocksCheckout;

/**
 * Field that the tab «Empresa / Autónomo» sets (Invoice::FIELD_WANTS).
 */
export const COMPANY_FIELD = 'lachinata/company-invoice';

/**
 * Whether WooCommerce has the actions the tabs use.
 */
export function hasFieldsAction() {
	const actions = dispatch(CHECKOUT_STORE);
	const selectors = select(CHECKOUT_STORE);
	return (
		typeof actions?.setAdditionalFields === 'function' &&
		typeof selectors?.getAdditionalFields === 'function'
	);
}

function choose(company) {
	const fields = select(CHECKOUT_STORE).getAdditionalFields();
	if (!!fields[COMPANY_FIELD] !== company) {
		dispatch(CHECKOUT_STORE).setAdditionalFields({
			...fields,
			[COMPANY_FIELD]: company,
		});
	}
}

/**
 * Icon of the sprite the theme prints in the page.
 *
 * @param {Object} props
 * @param {string} props.name Icon name.
 */
export function Icon({ name }) {
	return (
		<svg
			className="lc-icon lc-icon--sm"
			viewBox="0 0 24 24"
			fill="none"
			stroke="currentColor"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
			aria-hidden="true"
			focusable="false"
		>
			<use href={`#lc-icon-${name}`} />
		</svg>
	);
}

function Tabs() {
	const company = useSelect(
		(s) => !!s(CHECKOUT_STORE).getAdditionalFields()?.[COMPANY_FIELD],
		[]
	);
	const refs = [useRef(), useRef()];
	const tabs = [
		{ id: 'lc-billing-private', label: __('Particular', 'lachinata-core') },
		{
			id: 'lc-billing-company',
			label: __('Empresa / Autónomo', 'lachinata-core'),
		},
	];
	const current = company ? 1 : 0;

	// Arrows, Home and End move between the tabs and select them (automatic activation).
	const onKeyDown = (event) => {
		const keys = {
			ArrowRight: current + 1,
			ArrowLeft: current - 1,
			Home: 0,
			End: tabs.length - 1,
		};
		if (!(event.key in keys)) {
			return;
		}
		event.preventDefault();
		const next = (keys[event.key] + tabs.length) % tabs.length;
		choose(next === 1);
		refs[next].current?.focus();
	};

	return (
		<div
			className="lc-tabs label"
			role="tablist"
			aria-label={__('Tipo de factura', 'lachinata-core')}
		>
			{tabs.map((tab, i) => (
				<button
					key={tab.id}
					ref={refs[i]}
					id={tab.id}
					type="button"
					role="tab"
					aria-selected={i === current ? 'true' : 'false'}
					aria-controls="order-fields"
					tabIndex={i === current ? 0 : -1}
					onClick={() => choose(i === 1)}
					onKeyDown={onKeyDown}
				>
					{tab.label}
				</button>
			))}
		</div>
	);
}

function BillingType() {
	return (
		<section
			className="lc-chk lc-chk--billing"
			aria-labelledby="lc-billing-title"
		>
			<header className="lc-chk__head">
				<span className="lc-chk__icon" aria-hidden="true">
					<Icon name="receipt" />
				</span>
				<h2 className="h4 lc-chk__title" id="lc-billing-title">
					{__('Facturación', 'lachinata-core')}
				</h2>
			</header>
			{hasFieldsAction() && (
				<div className="lc-chk__body">
					<Tabs />
				</div>
			)}
		</section>
	);
}

export function registerBillingType() {
	registerCheckoutBlock({ metadata, component: BillingType });
}
