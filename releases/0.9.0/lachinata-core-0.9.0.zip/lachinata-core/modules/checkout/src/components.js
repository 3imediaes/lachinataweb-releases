/**
 * The system's components the module prints, with the markup and classes of
 * design-system/sistema/components/bundle.js (the theme dresses them). Icons come from the
 * theme's sprite (#lc-icon-*).
 */
import { __ } from '@wordpress/i18n';

const cx = (...names) => names.filter(Boolean).join(' ');

export function Icon({ name, size }) {
	return (
		<svg
			className={cx('lc-icon', size === 'sm' && 'lc-icon--sm')}
			viewBox="0 0 24 24"
			fill="none"
			stroke="currentColor"
			strokeWidth="1.5"
			strokeLinecap="round"
			strokeLinejoin="round"
			aria-hidden="true"
			focusable="false"
		>
			<use href={`#lc-icon-${name}`} />
		</svg>
	);
}

const NOTICE_ICONS = {
	success: 'check',
	info: 'info',
	warning: 'alert',
	error: 'alert',
	neutral: 'info',
};

export function Notice({ tone = 'neutral', children }) {
	return (
		<div
			className={cx('lc-notice', 'body-sm', `lc-notice--${tone}`)}
			role={tone === 'error' ? 'alert' : 'status'}
		>
			<Icon name={NOTICE_ICONS[tone] || 'info'} size="sm" />
			<span>{children}</span>
		</div>
	);
}

export function Button({
	variant = 'primary',
	size = 'md',
	href,
	onClick,
	iconLeft,
	children,
}) {
	const className = cx(
		'lc-btn',
		'button',
		variant !== 'primary' && `lc-btn--${variant}`,
		size !== 'md' && `lc-btn--${size}`
	);
	const content = (
		<>
			{iconLeft && <Icon name={iconLeft} />}
			{children}
		</>
	);
	return href ? (
		<a className={className} href={href}>
			{content}
		</a>
	) : (
		<button type="button" className={className} onClick={onClick}>
			{content}
		</button>
	);
}

/**
 * Price in minor units with the cart's currency.
 *
 * @param {number} price    Price in minor units.
 * @param {Object} currency Cart totals (currency_* keys).
 * @return {string} Formatted price.
 */
function money(price, currency) {
	const format = window.wc?.priceFormat;
	if (!format) {
		return String(price);
	}
	return format.formatPrice(
		price,
		format.getCurrencyFromPriceResponse(currency)
	);
}

/**
 * ShippingOption with `disabled`: an option the customer cannot choose, with the reason
 * in its note.
 *
 * @param {Object} props
 * @param {string} props.id       Input id.
 * @param {string} props.title    Method name.
 * @param {number} props.price    Price in minor units (0 = Gratis).
 * @param {Object} props.currency Cart totals (currency_* keys).
 * @param {string} props.note     Why it is not available.
 */
export function DisabledOption({ id, title, price, currency, note }) {
	return (
		<label className="lc-opt lc-opt--off" htmlFor={id}>
			<input type="radio" id={id} name="lc-unavailable" disabled />
			<span className="lc-opt__radio" aria-hidden="true" />
			<span className="lc-opt__body">
				<span className="lc-opt__row">
					<span className="label">{title}</span>
					<span
						className={cx(
							'lc-opt__price',
							'label',
							price === 0 && 'lc-opt__price--free'
						)}
						data-no-translation
					>
						{price === 0
							? __('Gratis', 'lachinata-core')
							: money(price, currency)}
					</span>
				</span>
				{note && (
					<span className={cx('lc-opt__note', 'caption')}>
						{note}
					</span>
				)}
			</span>
		</label>
	);
}
