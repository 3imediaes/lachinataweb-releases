/**
 * Address fields: the province follows the postcode in Spain (visible and editable),
 * the numeric keyboard for postcodes made only of digits, the help under the phone («Solo
 * para la entrega.») and, in Spain, under the province («Se rellena con el código postal.»).
 * WooCommerce's field API has no `inputMode` nor help text for core fields, so these are
 * set on the rendered inputs (plugin/modules/checkout/README.md). Progressive: if
 * WooCommerce changes that HTML they stop showing, and the checkout works the same.
 */
import { dispatch, select, subscribe } from '@wordpress/data';
import { __ } from '@wordpress/i18n';
import { settings, CART_STORE } from './settings';

const TYPES = ['shipping', 'billing'];

/**
 * Province of a Spanish postcode (WooCommerce state code), from its first two digits.
 *
 * @param {string} postcode Postcode as typed.
 * @return {string|null} State code.
 */
export function provinceOf(postcode) {
	const digits = String(postcode).replace(/\D/g, '');
	return digits.length >= 2
		? (settings.provinces?.[digits.slice(0, 2)] ?? null)
		: null;
}

function address(type) {
	const customer = select(CART_STORE)?.getCustomerData?.();
	return customer?.[`${type}Address`] ?? null;
}

/**
 * Sets the province when the first two digits of a Spanish postcode change, so a
 * province the customer picks by hand stays until the postcode changes again.
 */
function followPostcode() {
	const last = {};
	subscribe(() => {
		for (const type of TYPES) {
			const current = address(type);
			if (!current || current.country !== 'ES') {
				last[type] = null;
				continue;
			}
			const prefix =
				String(current.postcode).replace(/\D/g, '').slice(0, 2) || null;
			if (prefix === last[type]) {
				continue;
			}
			last[type] = prefix;
			const state = provinceOf(current.postcode);
			if (state && state !== current.state) {
				const action =
					type === 'shipping'
						? 'setShippingAddress'
						: 'setBillingAddress';
				dispatch(CART_STORE)[action]({ state });
			}
		}
	}, CART_STORE);
}

/**
 * Puts (or takes away) a help line inside a field rendered by WooCommerce, described by it.
 *
 * @param {HTMLElement|null} input Input or select.
 * @param {HTMLElement|null} box   Element that holds the field.
 * @param {string}           id    Id of the help.
 * @param {string}           text  Help, empty to take it away.
 */
function help(input, box, id, text) {
	const current = document.getElementById(id);
	if (!input || !box || !text) {
		current?.remove();
		return;
	}
	if (current) {
		return;
	}
	const note = document.createElement('span');
	note.id = id;
	note.className = 'lc-field__help body-sm';
	note.textContent = text;
	box.appendChild(note);
	const described = input.getAttribute('aria-describedby');
	input.setAttribute(
		'aria-describedby',
		described ? `${described} ${id}` : id
	);
}

/**
 * Numeric keyboard and helps on the inputs WooCommerce renders.
 */
function decorate() {
	for (const type of TYPES) {
		const country = address(type)?.country;
		const postcode = document.getElementById(`${type}-postcode`);
		if (postcode) {
			const numeric = (settings.numericPostcodes || []).includes(country);
			if (numeric && postcode.inputMode !== 'numeric') {
				postcode.inputMode = 'numeric';
			} else if (!numeric && postcode.hasAttribute('inputmode')) {
				postcode.removeAttribute('inputmode');
			}
		}

		const phone = document.getElementById(`${type}-phone`);
		help(
			phone,
			phone?.parentElement,
			`lc-${type}-phone-help`,
			__('Solo para la entrega.', 'lachinata-core')
		);

		const state = document.getElementById(`${type}-state`);
		help(
			state,
			state?.closest('.wc-blocks-components-select__container'),
			`lc-${type}-state-help`,
			country === 'ES'
				? __('Se rellena con el código postal.', 'lachinata-core')
				: ''
		);
	}
}

/**
 * decorate() never breaks the checkout: what it cannot find is left as WooCommerce drew it.
 */
function safely() {
	try {
		decorate();
	} catch {
		// WooCommerce changed its HTML: the fields work without the helps.
	}
}

/**
 * The billing phone is hidden (theme CSS): it follows the delivery phone while the billing
 * address is another one (with the same address WooCommerce copies it all).
 */
function followPhone() {
	subscribe(() => {
		const checkout = select('wc/store/checkout');
		if (!checkout || checkout.getUseShippingAsBilling()) {
			return;
		}
		const shipping = address('shipping');
		const billing = address('billing');
		if (shipping && billing && shipping.phone !== billing.phone) {
			dispatch(CART_STORE).setBillingAddress({ phone: shipping.phone });
		}
	}, CART_STORE);
}

export function initFields() {
	followPostcode();
	followPhone();

	let frame = 0;
	const schedule = () => {
		if (!frame) {
			frame = window.requestAnimationFrame(() => {
				frame = 0;
				safely();
			});
		}
	};
	const start = () => {
		const root = document.querySelector('.wp-block-woocommerce-checkout');
		if (!root) {
			return;
		}
		new window.MutationObserver(schedule).observe(root, {
			childList: true,
			subtree: true,
		});
		subscribe(schedule, CART_STORE);
		schedule();
	};
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', start);
	} else {
		start();
	}
}
