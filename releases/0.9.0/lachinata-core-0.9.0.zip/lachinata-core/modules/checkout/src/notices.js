/**
 * The shipping module sends the reason for «no shipping» as a cart error, which the block
 * checkout shows at the top of the page. The after-shipping block shows it next to the
 * shipping options, with the ways out, so the top copy goes.
 */
import { dispatch, select, subscribe } from '@wordpress/data';
import { SHIPPING_ERROR } from './settings';

const CONTEXTS = ['wc/cart', 'wc/checkout'];

export function initNotices() {
	let busy = false;
	subscribe(() => {
		if (busy) {
			return;
		}
		const store = select('core/notices');
		if (!store) {
			return;
		}
		busy = true;
		for (const context of CONTEXTS) {
			for (const notice of store.getNotices(context)) {
				if (String(notice.id).startsWith(SHIPPING_ERROR)) {
					dispatch('core/notices').removeNotice(notice.id, context);
				}
			}
		}
		busy = false;
	}, 'core/notices');
}
