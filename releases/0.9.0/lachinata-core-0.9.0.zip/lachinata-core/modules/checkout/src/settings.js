/**
 * Data from Integration::get_script_data() and the WooCommerce stores.
 */
export const settings = window.wc?.wcSettings?.getSetting(
	'lachinata-checkout_data',
	{}
) || {
	contactUrl: '',
	cartUrl: '',
	provinces: {},
	numericPostcodes: [],
};

export const CART_STORE = 'wc/store/cart';
export const CHECKOUT_STORE = 'wc/store/checkout';

/**
 * Prefix of the cart errors of the shipping module (Rates::cart_errors()).
 */
export const SHIPPING_ERROR = 'lachinata_shipping_';
