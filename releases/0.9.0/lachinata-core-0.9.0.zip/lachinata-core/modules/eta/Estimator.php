<?php
/**
 * Estimates for WooCommerce instances, packages and products.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Eta;

use LaChinata\Core\GapLog;
use LaChinata\Core\Shipping\Zones;
use LaChinata\Core\Services;
use LaChinata\Core\Delivery\Estimate;

defined( 'ABSPATH' ) || exit;

/**
 * Reads the configuration and the plan of each instance and runs the calculator in the
 * store's time zone. A method without plan in its zone gets no date and is logged.
 */
final class Estimator {

	/**
	 * Option with the store configuration.
	 */
	public const OPTION = 'lachinata_eta_config';

	/**
	 * Configuration of this request.
	 *
	 * @var EtaConfig|null
	 */
	private static ?EtaConfig $config = null;

	/**
	 * Fixed time for tests; null for the real clock.
	 *
	 * @var \DateTimeImmutable|null
	 */
	private static ?\DateTimeImmutable $now = null;

	/**
	 * Estimates of this request.
	 *
	 * @var array<string, Estimate|null>
	 */
	private static array $memo = array();

	/**
	 * Store configuration.
	 */
	public static function config(): EtaConfig {
		if ( null === self::$config ) {
			$stored       = get_option( self::OPTION, array() );
			self::$config = EtaConfig::from_array( is_array( $stored ) ? $stored : array() );
		}
		return self::$config;
	}

	/**
	 * Saves the configuration and drops WooCommerce's cached rates (their dates change).
	 *
	 * @param EtaConfig $config Configuration.
	 */
	public static function save( EtaConfig $config ): void {
		update_option( self::OPTION, $config->to_array() );
		self::$config = null;
		self::$memo   = array();
		Zones::changed();
	}

	/**
	 * Current time in the store's time zone.
	 */
	public static function now(): \DateTimeImmutable {
		return self::$now ?? current_datetime();
	}

	/**
	 * Forgets what this request read and calculated (after a configuration change).
	 */
	public static function reset(): void {
		self::$config = null;
		self::$memo   = array();
	}

	/**
	 * Fixes the clock (tests) or gives it back (null).
	 *
	 * @param \DateTimeImmutable|null $now Time.
	 */
	public static function set_now( ?\DateTimeImmutable $now ): void {
		self::$now    = $now;
		self::$config = null;
		self::$memo   = array();
	}

	/**
	 * Gap log of the module.
	 */
	public static function gaps(): GapLog {
		return new GapLog( 'lachinata_eta_gaps', 'lachinata-eta' );
	}

	/**
	 * Plan of an instance.
	 *
	 * @param \WC_Shipping_Method $method Instance.
	 */
	public static function plan( \WC_Shipping_Method $method ): ?Plan {
		return Plan::from_settings( Zones::instance_settings( $method ) );
	}

	/**
	 * Estimate for an instance of a zone.
	 *
	 * @param \WC_Shipping_Zone                               $zone        Zone.
	 * @param int                                             $instance_id Instance id.
	 * @param string[]                                        $classes     Shipping class slugs of the package.
	 * @param string                                          $country     Destination country.
	 * @param array{days_min?: int|null, days_max?: int|null} $live        Transit days a carrier gave, if any.
	 */
	public static function for_instance( \WC_Shipping_Zone $zone, int $instance_id, array $classes, string $country, array $live = array() ): ?Estimate {
		sort( $classes );
		$key = implode( '|', array( $zone->get_id(), $instance_id, implode( ',', $classes ), $country, $live['days_min'] ?? '', $live['days_max'] ?? '' ) );
		if ( array_key_exists( $key, self::$memo ) ) {
			return self::$memo[ $key ];
		}

		$method = $zone->get_shipping_methods()[ $instance_id ] ?? null;
		$plan   = $method instanceof \WC_Shipping_Method ? self::plan( $method ) : null;
		if ( isset( $live['days_min'] ) ) {
			$plan = ( $plan ?? new Plan( 0, 0 ) )->with_days( (int) $live['days_min'], (int) ( $live['days_max'] ?? $live['days_min'] ) );
		}
		if ( null === $plan ) {
			if ( $method instanceof \WC_Shipping_Method ) {
				self::gaps()->record(
					'plan|' . $zone->get_id() . '|' . $instance_id,
					/* translators: 1: method title, 2: instance id, 3: zone name. */
					sprintf( __( '%1$s (ID %2$d) no tiene plazo en la zona «%3$s»: no se muestra fecha.', 'lachinata-core' ), $method->get_title(), $instance_id, $zone->get_zone_name() )
				);
			}
			self::$memo[ $key ] = null;
			return null;
		}

		$estimate = Calculator::estimate( self::config(), $plan, $classes, $country, self::now() );
		if ( null === $estimate ) {
			self::gaps()->record(
				'days|' . $zone->get_id() . '|' . $instance_id . '|' . implode( ',', $classes ),
				/* translators: 1: instance id, 2: shipping classes. */
				sprintf( __( 'El método con ID %1$d no tiene ningún día posible de salida o de entrega con las clases %2$s.', 'lachinata-core' ), $instance_id, implode( ', ', $classes ) )
			);
		}
		self::$memo[ $key ] = $estimate;
		return $estimate;
	}

	/**
	 * Estimate for a product with the zone's reference method, or null when it cannot ship there.
	 *
	 * @param \WC_Product                                               $product     Product.
	 * @param array{country: string, state?: string, postcode?: string} $destination Destination.
	 */
	public static function for_product( \WC_Product $product, array $destination ): ?Estimate {
		$rules = Services::shipping_rules();
		if ( ! $product->needs_shipping() || ( null !== $rules && true !== $rules->shippable( $product, $destination ) ) ) {
			return null;
		}
		$zone     = Zones::for_destination( $destination );
		$instance = self::config()->reference[ (int) $zone->get_id() ] ?? 0;
		if ( ! $instance ) {
			return null;
		}
		$class = $product->get_shipping_class();
		return self::for_instance( $zone, $instance, '' === $class ? array() : array( $class ), $destination['country'] );
	}

	/**
	 * Key that changes when estimates change: each day and at each cut-off time.
	 *
	 * @param \DateTimeImmutable $now Time.
	 */
	public static function stamp( \DateTimeImmutable $now ): string {
		$passed = count( array_filter( self::config()->cutoff_times(), static fn( string $time ): bool => $now->format( 'H:i' ) >= $time ) );
		return $now->format( 'Y-m-d' ) . '#' . $passed;
	}

	/**
	 * Seconds until the next cut-off time or midnight.
	 *
	 * @param \DateTimeImmutable $now Time.
	 */
	public static function seconds_to_change( \DateTimeImmutable $now ): int {
		$next = $now->setTime( 0, 0 )->modify( '+1 day' );
		foreach ( self::config()->cutoff_times() as $time ) {
			list( $hour, $minute ) = array_map( 'intval', explode( ':', $time ) );
			$at                    = $now->setTime( $hour, $minute );
			if ( $at > $now && $at < $next ) {
				$next = $at;
			}
		}
		return max( 60, $next->getTimestamp() - $now->getTimestamp() );
	}
}
