<?php
/**
 * Delivery estimate configuration of the store.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Eta;

defined( 'ABSPATH' ) || exit;

/**
 * Cut-off time per weekday (no time = no dispatch that day), preparation days, conditions
 * per shipping class, carriers with their no-delivery weekdays, warehouse holidays,
 * delivery holidays per destination country and the reference method of each zone.
 * Weekdays are ISO numbers: 1 Monday … 7 Sunday. Pure: no WordPress calls.
 */
final class EtaConfig {

	/**
	 * Builds the configuration.
	 *
	 * @param array<int, string|null>                                                                                      $cutoffs            Weekday → «HH:MM», null for no dispatch.
	 * @param int                                                                                                          $prep_days          Working days between taking the order and dispatching it.
	 * @param array<string, array{extra_days: int, cutoff: string|null, ship_days: int[]|null, delivery_days: int[]|null}> $classes Rules by shipping class slug.
	 * @param array<string, array{name: string, no_delivery: int[]}>                                                       $carriers           Carriers by key.
	 * @param array<string, string>                                                                                        $warehouse_holidays Date (Y-m-d) → name. No preparation, no dispatch.
	 * @param array<string, array<string, string>>                                                                         $country_holidays   Country → date → name. No delivery there.
	 * @param array<int, int>                                                                                              $reference          Zone id → instance id used on the product page and the bag.
	 */
	public function __construct(
		public readonly array $cutoffs = array(),
		public readonly int $prep_days = 0,
		public readonly array $classes = array(),
		public readonly array $carriers = array(),
		public readonly array $warehouse_holidays = array(),
		public readonly array $country_holidays = array(),
		public readonly array $reference = array(),
	) {}

	/**
	 * Configuration from its stored form; anything malformed is dropped.
	 *
	 * @param array<string, mixed> $data Stored configuration.
	 */
	public static function from_array( array $data ): self {
		$cutoffs = array();
		for ( $day = 1; $day <= 7; $day++ ) {
			$cutoffs[ $day ] = self::time( $data['cutoffs'][ $day ] ?? ( $data['cutoffs'][ (string) $day ] ?? null ) );
		}

		$classes = array();
		foreach ( (array) ( $data['classes'] ?? array() ) as $slug => $rule ) {
			if ( ! is_array( $rule ) || '' === (string) $slug ) {
				continue;
			}
			$classes[ (string) $slug ] = array(
				'extra_days'    => max( 0, (int) ( $rule['extra_days'] ?? 0 ) ),
				'cutoff'        => self::time( $rule['cutoff'] ?? null ),
				'ship_days'     => self::days_or_null( $rule['ship_days'] ?? null ),
				'delivery_days' => self::days_or_null( $rule['delivery_days'] ?? null ),
			);
		}

		$carriers = array();
		foreach ( (array) ( $data['carriers'] ?? array() ) as $key => $carrier ) {
			if ( is_array( $carrier ) && '' !== (string) $key ) {
				$carriers[ (string) $key ] = array(
					'name'        => (string) ( $carrier['name'] ?? $key ),
					'no_delivery' => self::days( $carrier['no_delivery'] ?? array() ),
				);
			}
		}

		$holidays  = (array) ( $data['holidays'] ?? array() );
		$countries = array();
		foreach ( (array) ( $holidays['countries'] ?? array() ) as $country => $dates ) {
			$country = strtoupper( (string) $country );
			if ( 1 === preg_match( '/^[A-Z]{2}$/', $country ) ) {
				$countries[ $country ] = self::dates( $dates );
			}
		}

		$reference = array();
		foreach ( (array) ( $data['reference'] ?? array() ) as $zone_id => $instance_id ) {
			if ( (int) $instance_id > 0 ) {
				$reference[ (int) $zone_id ] = (int) $instance_id;
			}
		}

		return new self(
			$cutoffs,
			max( 0, (int) ( $data['prep_days'] ?? 0 ) ),
			$classes,
			$carriers,
			self::dates( $holidays['warehouse'] ?? array() ),
			$countries,
			$reference
		);
	}

	/**
	 * Stored form (the inverse of from_array()).
	 *
	 * @return array<string, mixed>
	 */
	public function to_array(): array {
		return array(
			'cutoffs'   => $this->cutoffs,
			'prep_days' => $this->prep_days,
			'classes'   => $this->classes,
			'carriers'  => $this->carriers,
			'holidays'  => array(
				'warehouse' => $this->warehouse_holidays,
				'countries' => $this->country_holidays,
			),
			'reference' => $this->reference,
		);
	}

	/**
	 * Copy with some parts replaced (keys as in the constructor).
	 *
	 * @param array<string, mixed> $changes Parts to replace.
	 */
	public function with( array $changes ): self {
		$data = array(
			'cutoffs'            => $this->cutoffs,
			'prep_days'          => $this->prep_days,
			'classes'            => $this->classes,
			'carriers'           => $this->carriers,
			'warehouse_holidays' => $this->warehouse_holidays,
			'country_holidays'   => $this->country_holidays,
			'reference'          => $this->reference,
		);
		$data = array_merge( $data, array_intersect_key( $changes, $data ) );
		return new self( $data['cutoffs'], $data['prep_days'], $data['classes'], $data['carriers'], $data['warehouse_holidays'], $data['country_holidays'], $data['reference'] );
	}

	/**
	 * Rules of the classes in a package combined: the most extra days, the earliest
	 * cut-off and only the weekdays every class allows. Null when no weekday is left.
	 *
	 * @param string[] $classes Shipping class slugs.
	 * @return array{extra_days: int, cutoff: string|null, ship_days: int[]|null, delivery_days: int[]|null}|null
	 */
	public function rules_for( array $classes ): ?array {
		$combined = array(
			'extra_days'    => 0,
			'cutoff'        => null,
			'ship_days'     => null,
			'delivery_days' => null,
		);
		foreach ( $classes as $slug ) {
			$rule = $this->classes[ $slug ] ?? null;
			if ( null === $rule ) {
				continue;
			}
			$combined['extra_days'] = max( $combined['extra_days'], $rule['extra_days'] );
			if ( null !== $rule['cutoff'] && ( null === $combined['cutoff'] || $rule['cutoff'] < $combined['cutoff'] ) ) {
				$combined['cutoff'] = $rule['cutoff'];
			}
			foreach ( array( 'ship_days', 'delivery_days' ) as $key ) {
				if ( null !== $rule[ $key ] ) {
					$combined[ $key ] = null === $combined[ $key ] ? $rule[ $key ] : array_values( array_intersect( $combined[ $key ], $rule[ $key ] ) );
					if ( ! $combined[ $key ] ) {
						return null;
					}
				}
			}
		}
		return $combined;
	}

	/**
	 * Every cut-off time in use, sorted (for knowing when estimates change during a day).
	 *
	 * @return string[]
	 */
	public function cutoff_times(): array {
		$times = array_filter( $this->cutoffs );
		foreach ( $this->classes as $rule ) {
			if ( null !== $rule['cutoff'] ) {
				$times[] = $rule['cutoff'];
			}
		}
		$times = array_values( array_unique( $times ) );
		sort( $times );
		return $times;
	}

	/**
	 * «HH:MM» or null.
	 *
	 * @param mixed $value Raw value.
	 */
	public static function time( mixed $value ): ?string {
		$value = trim( (string) ( is_scalar( $value ) ? $value : '' ) );
		if ( 1 !== preg_match( '/^([01]?\d|2[0-3]):([0-5]\d)$/', $value, $parts ) ) {
			return null;
		}
		return sprintf( '%02d:%s', (int) $parts[1], $parts[2] );
	}

	/**
	 * List of weekdays 1–7.
	 *
	 * @param mixed $value Raw value.
	 * @return int[]
	 */
	public static function days( mixed $value ): array {
		$days = array_values( array_unique( array_filter( array_map( 'intval', (array) $value ), static fn( int $day ): bool => $day >= 1 && $day <= 7 ) ) );
		sort( $days );
		return $days;
	}

	/**
	 * Weekdays, or null for «no restriction» (null or an empty list).
	 *
	 * @param mixed $value Raw value.
	 * @return int[]|null
	 */
	private static function days_or_null( mixed $value ): ?array {
		if ( null === $value ) {
			return null;
		}
		$days = self::days( $value );
		return $days ? $days : null;
	}

	/**
	 * Date → name list with valid dates only, sorted.
	 *
	 * @param mixed $value Raw value.
	 * @return array<string, string>
	 */
	private static function dates( mixed $value ): array {
		$dates = array();
		foreach ( (array) $value as $date => $name ) {
			$date = (string) $date;
			if ( 1 === preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) && checkdate( (int) substr( $date, 5, 2 ), (int) substr( $date, 8, 2 ), (int) substr( $date, 0, 4 ) ) ) {
				$dates[ $date ] = is_array( $name ) ? (string) ( $name['name'] ?? '' ) : (string) $name;
			}
		}
		ksort( $dates );
		return $dates;
	}
}
