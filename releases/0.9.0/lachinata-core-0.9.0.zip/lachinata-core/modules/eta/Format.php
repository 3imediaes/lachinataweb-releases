<?php
/**
 * Deprecated location of LaChinata\Core\Delivery\Format.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Eta;

defined( 'ABSPATH' ) || exit;

// @deprecated 0.9.0 Moved to the core as LaChinata\Core\Delivery\Format; this alias goes in 0.10.0.
class_alias( \LaChinata\Core\Delivery\Format::class, __NAMESPACE__ . '\\Format' );
