<?php
/**
 * Holiday imports: Nager.Date and CSV.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Eta;

defined( 'ABSPATH' ) || exit;

/**
 * Public holidays come from Nager.Date (date.nager.at) only when an admin asks for them,
 * with a preview before saving; never while serving customers. Local holidays come from
 * a CSV with `fecha;nombre` lines. Once saved, imported dates are plain entries of the
 * calendar: they are edited and deleted like the ones added by hand.
 */
final class Holidays {

	/**
	 * Nager.Date endpoint: year and country.
	 */
	private const NAGER_URL = 'https://date.nager.at/api/v3/PublicHolidays/%1$d/%2$s';

	/**
	 * Fetches the public holidays of a country and year.
	 *
	 * @param string $country Country code.
	 * @param int    $year    Year.
	 * @return array<int, array{date: string, name: string, regions: string[]}>|\WP_Error
	 */
	public static function fetch( string $country, int $year ): array|\WP_Error {
		$response = wp_remote_get(
			sprintf( self::NAGER_URL, $year, rawurlencode( strtoupper( $country ) ) ),
			array( 'timeout' => 10 )
		);
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			/* translators: 1: country code, 2: HTTP status. */
			return new \WP_Error( 'lachinata_nager', sprintf( __( 'Nager.Date no tiene festivos para %1$s (respuesta %2$d).', 'lachinata-core' ), $country, $code ) );
		}
		return self::parse_nager( (string) wp_remote_retrieve_body( $response ) );
	}

	/**
	 * Holidays from a Nager.Date answer. National ones have no regions.
	 *
	 * @param string $json Body.
	 * @return array<int, array{date: string, name: string, regions: string[]}>
	 */
	public static function parse_nager( string $json ): array {
		$data = json_decode( $json, true );
		$list = array();
		foreach ( is_array( $data ) ? $data : array() as $entry ) {
			if ( ! is_array( $entry ) || 1 !== preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) ( $entry['date'] ?? '' ) ) ) {
				continue;
			}
			$list[] = array(
				'date'    => (string) $entry['date'],
				'name'    => (string) ( $entry['localName'] ?? $entry['name'] ?? '' ),
				'regions' => ! empty( $entry['global'] ) ? array() : array_map( 'strval', (array) ( $entry['counties'] ?? array() ) ),
			);
		}
		return $list;
	}

	/**
	 * Dates from `fecha;nombre` lines. Dates as 2026-12-08 or 08/12/2026; commas also
	 * separate. Blank lines and a «fecha;nombre» header are skipped.
	 *
	 * @param string $csv Text.
	 * @return array{dates: array<string, string>, errors: int[]} Dates and the numbers of the lines not understood.
	 */
	public static function parse_csv( string $csv ): array {
		$dates  = array();
		$errors = array();
		$lines  = preg_split( '/\R/', $csv );
		foreach ( false === $lines ? array() : $lines as $index => $line ) {
			$line = trim( $line );
			if ( '' === $line || 0 === stripos( $line, 'fecha' ) ) {
				continue;
			}
			$parts = preg_split( '/[;,\t]/', $line, 2 );
			$parts = array_map( 'trim', false === $parts ? array() : $parts );
			$date  = self::date( $parts[0] ?? '' );
			if ( null === $date ) {
				$errors[] = $index + 1;
				continue;
			}
			$dates[ $date ] = $parts[1] ?? '';
		}
		ksort( $dates );
		return array(
			'dates'  => $dates,
			'errors' => $errors,
		);
	}

	/**
	 * Y-m-d from 2026-12-08 or 08/12/2026, or null.
	 *
	 * @param string $value Date.
	 */
	public static function date( string $value ): ?string {
		if ( 1 === preg_match( '/^(\d{4})-(\d{1,2})-(\d{1,2})$/', $value, $m ) ) {
			list( , $year, $month, $day ) = $m;
		} elseif ( 1 === preg_match( '#^(\d{1,2})/(\d{1,2})/(\d{4})$#', $value, $m ) ) {
			list( , $day, $month, $year ) = $m;
		} else {
			return null;
		}
		return checkdate( (int) $month, (int) $day, (int) $year ) ? sprintf( '%04d-%02d-%02d', $year, $month, $day ) : null;
	}
}
