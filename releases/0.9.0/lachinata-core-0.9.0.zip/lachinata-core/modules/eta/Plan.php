<?php
/**
 * Transit plan of a shipping method instance in its zone.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Eta;

defined( 'ABSPATH' ) || exit;

/**
 * Minimum and maximum transit days, carrier and the instance's own no-delivery weekdays.
 */
final class Plan {

	/**
	 * Keys of the instance settings.
	 */
	public const KEYS = array( 'lc_eta_min', 'lc_eta_max', 'lc_eta_carrier', 'lc_eta_no_delivery' );

	/**
	 * Builds the plan.
	 *
	 * @param int    $min_days    Minimum transit days.
	 * @param int    $max_days    Maximum transit days.
	 * @param string $carrier     Carrier key ('' for none).
	 * @param int[]  $no_delivery Weekdays without delivery, besides the carrier's.
	 */
	public function __construct(
		public readonly int $min_days,
		public readonly int $max_days,
		public readonly string $carrier = '',
		public readonly array $no_delivery = array(),
	) {}

	/**
	 * Plan from the instance settings, or null when the days are not set.
	 *
	 * @param array<string, mixed> $settings Instance settings.
	 */
	public static function from_settings( array $settings ): ?self {
		$min = trim( (string) ( $settings['lc_eta_min'] ?? '' ) );
		$max = trim( (string) ( $settings['lc_eta_max'] ?? '' ) );
		if ( ! is_numeric( $min ) ) {
			return null;
		}
		$min = max( 0, (int) $min );
		return new self(
			$min,
			is_numeric( $max ) ? max( $min, (int) $max ) : $min,
			(string) ( $settings['lc_eta_carrier'] ?? '' ),
			EtaConfig::days( $settings['lc_eta_no_delivery'] ?? array() )
		);
	}

	/**
	 * Same plan with the transit days a carrier gave for the shipment.
	 *
	 * @param int $min_days Minimum.
	 * @param int $max_days Maximum.
	 */
	public function with_days( int $min_days, int $max_days ): self {
		return new self( max( 0, $min_days ), max( $min_days, $max_days ), $this->carrier, $this->no_delivery );
	}
}
