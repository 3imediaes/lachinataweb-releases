<?php
/**
 * REST endpoint with the product page's delivery date.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Eta;

use LaChinata\Core\Shipping\Destination;
use LaChinata\Core\Delivery\Format;
use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * `GET /wp-json/lachinata/v1/eta?product=123[&destino=ES:PM]`. Public and cacheable until
 * the next cut-off or midnight (at most an hour). The answer depends only on the URL:
 * the destination goes in `destino` (the script sends the `lc_destino` cookie when the
 * `locale` module sets it), never in the session, so a CDN can cache it.
 */
final class Rest {

	/**
	 * Route namespace.
	 */
	public const NAMESPACE = 'lachinata/v1';

	/**
	 * Route.
	 */
	public const ROUTE = '/eta';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'rest_api_init', array( self::class, 'register' ) );
	}

	/**
	 * Registers the route.
	 */
	public static function register(): void {
		register_rest_route(
			self::NAMESPACE,
			self::ROUTE,
			array(
				'methods'             => \WP_REST_Server::READABLE,
				'callback'            => Hooks::rest( array( self::class, 'respond' ) ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'product' => array(
						'type'     => 'integer',
						'required' => true,
						'minimum'  => 1,
					),
					'destino' => array(
						'type'    => 'string',
						'default' => '',
					),
				),
			)
		);
	}

	/**
	 * The date for a product.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @phpstan-param \WP_REST_Request<array<string, mixed>> $request
	 */
	public static function respond( \WP_REST_Request $request ): \WP_REST_Response {
		$product = wc_get_product( (int) $request->get_param( 'product' ) );
		if ( ! $product instanceof \WC_Product || 'publish' !== $product->get_status() ) {
			return new \WP_REST_Response( array( 'message' => __( 'Producto no encontrado.', 'lachinata-core' ) ), 404 );
		}

		$code        = (string) $request->get_param( 'destino' );
		$destination = '' === $code ? null : Destination::parse( $code );
		/**
		 * Destination of the endpoint from its `destino` parameter. The `locale` module maps
		 * the `lc_destino` cookie format (ISO 3166-2: «ES-IB») to WooCommerce's here.
		 *
		 * @since 0.4.0
		 *
		 * @param array{country: string, state: string, postcode: string}|null $destination Parsed destination, or null.
		 * @param string                                                        $code        Raw parameter.
		 */
		$destination = apply_filters( 'lachinata/eta/rest_destination', $destination, $code );
		$destination = is_array( $destination ) ? $destination : Destination::visitor();

		$now      = Estimator::now();
		$estimate = Estimator::for_product( $product, $destination );
		$response = new \WP_REST_Response(
			null === $estimate ? array(
				'sentence' => '',
				'cutoff'   => null,
				'date'     => '',
			) : array(
				'sentence' => Format::product( $estimate ),
				'cutoff'   => $estimate->cutoff?->format( DATE_ATOM ),
				'date'     => Format::long_day( $estimate->min ),
			)
		);
		$response->header( 'Cache-Control', 'public, max-age=' . min( HOUR_IN_SECONDS, Estimator::seconds_to_change( $now ) ) );
		return $response;
	}
}
