<?php
/**
 * Delivery dates as a service for other modules.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Eta;

use LaChinata\Core\Contracts\DeliveryEstimator;
use LaChinata\Core\Delivery\Estimate;

defined( 'ABSPATH' ) || exit;

/**
 * Serves Contracts\DeliveryEstimator through `lachinata/eta/service` while the module is on.
 */
final class Service implements DeliveryEstimator {

	/**
	 * Delivery dates of an order that leaves on a given day.
	 *
	 * @param \WC_Order          $order Order.
	 * @param \DateTimeImmutable $ships Dispatch day.
	 */
	public function shipped( \WC_Order $order, \DateTimeImmutable $ships ): ?Estimate {
		return Rates::shipped( $order, $ships );
	}
}
