/**
 * Product page: refreshes the delivery sentence printed by the server (the page may be
 * cached) and, when the answer has a cut-off, counts down to it. If the request fails,
 * the server's sentence stays.
 */
(() => {
	const data = window.lachinataEta;
	const target = document.querySelector('.lc-buy__stock span');
	if (!data || !target || !target.textContent.includes(data.sentence)) {
		return;
	}
	const { __, _n, sprintf } = window.wp.i18n;

	const url = new URL(data.endpoint);
	url.searchParams.set('product', data.product);
	const cookie = document.cookie.match(/(?:^|; )lc_destino=([^;]+)/);
	if (cookie) {
		url.searchParams.set('destino', decodeURIComponent(cookie[1]));
	}

	let current = data.sentence;
	let timer = 0;
	let loadedAt = 0;

	const replace = (sentence) => {
		if (sentence && sentence !== current) {
			target.textContent = target.textContent.replace(current, sentence);
			current = sentence;
		}
	};

	const left = (minutes) => {
		const hours = Math.floor(minutes / 60);
		const rest = minutes % 60;
		if (hours) {
			return sprintf(
				/* translators: 1: hours, 2: minutes. */
				__('%1$d h %2$d min', 'lachinata-core'),
				hours,
				rest
			);
		}
		return sprintf(
			/* translators: %d: minutes. */
			_n('%d minuto', '%d minutos', rest, 'lachinata-core'),
			rest
		);
	};

	const render = (eta) => {
		if (!eta.cutoff) {
			replace(eta.sentence);
			return;
		}
		const minutes = Math.floor(
			(Date.parse(eta.cutoff) - Date.now()) / 60000
		);
		if (minutes < 1) {
			load();
			return;
		}
		replace(
			sprintf(
				/* translators: 1: time left («2 h 14 min»), 2: delivery day («jueves 24»). */
				__('Pídelo en %1$s y lo recibes el %2$s.', 'lachinata-core'),
				left(minutes),
				eta.date
			)
		);
	};

	const load = () => {
		if (Date.now() - loadedAt < 60000) {
			return;
		}
		loadedAt = Date.now();
		window.clearInterval(timer);
		window
			.fetch(url, { credentials: 'omit' })
			.then((response) =>
				response.ok ? response.json() : Promise.reject(response)
			)
			.then((eta) => {
				render(eta);
				if (eta.cutoff) {
					timer = window.setInterval(() => render(eta), 30000);
				}
			})
			.catch(() => {});
	};

	load();
})();
