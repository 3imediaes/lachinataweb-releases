<?php
/**
 * The gift in the emails of the theme's frame.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Gift;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * 06-correos.md: the gift adds a `note` to the buyer's emails («Es un regalo para María» in
 * the confirmation, «Hemos avisado a María» in the shipped one), the «Regalo» badge, the
 * note with the card's message and «· regalo» in the subject of the internal email, and
 * fills the notice to the recipient (tablero «Correos transaccionales», 3): eyebrow, title,
 * lead, facts «Llega» and «A», the secondary button «Seguir el paquete» only with tracking,
 * no order and no «¿Alguna duda?». The HTML uses the frame's `lc-mail-*` classes, which
 * the theme styles.
 */
final class Emails {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'lachinata/email/before_lines', array( self::class, 'note' ), 10, 2 );
		Hooks::add_action( 'lachinata/email/after_title', array( self::class, 'badge' ), 10, 2 );
		Hooks::add_filter( 'lachinata/email/subject', array( self::class, 'subject' ), 10, 2 );
		Hooks::add_filter( 'lachinata/email/intro', array( self::class, 'intro' ), 10, 2 );
		Hooks::add_filter( 'lachinata/email/facts', array( self::class, 'facts' ), 20, 3 );
		Hooks::add_filter( 'lachinata/email/button', array( self::class, 'button' ), 10, 2 );
		Hooks::add_filter( 'lachinata/email/layout', array( self::class, 'layout' ), 10, 2 );
		Hooks::add_filter( 'lachinata/email/footer_note', array( self::class, 'footer_note' ), 10, 2 );
		Hooks::add_filter( 'lachinata/email/footer_line', array( self::class, 'footer_line' ), 10, 2 );
		Hooks::add_filter( 'lachinata/email/footer_links', array( self::class, 'footer_links' ), 10, 2 );
		Hooks::add_action( 'woocommerce_email_order_details', array( self::class, 'without_frame' ), 5, 4 );
	}

	/**
	 * Whether the active theme draws the emails' frame (the lachinata theme says so with
	 * `lachinata/email/frame`). Without it, the gift writes its pieces where WooCommerce's
	 * own templates leave room.
	 */
	public static function frame(): bool {
		/**
		 * Whether the theme draws the frame of the emails and fills its hooks.
		 *
		 * @since 0.8.0
		 *
		 * @param bool $frame False unless the theme says so.
		 */
		return (bool) apply_filters( 'lachinata/email/frame', false );
	}

	/**
	 * Without the theme's frame: the gift's note at the top of WooCommerce's order details.
	 *
	 * @param mixed $order         Order.
	 * @param mixed $sent_to_admin Internal email.
	 * @param mixed $plain_text    Plain text.
	 * @param mixed $email         Email.
	 */
	public static function without_frame( $order, $sent_to_admin = false, $plain_text = false, $email = null ): void {
		unset( $sent_to_admin );
		if ( self::frame() ) {
			return;
		}
		if ( $plain_text ) {
			ob_start();
			self::note( $order, $email );
			$text = trim( wp_strip_all_tags( str_replace( '</p>', "\n", (string) ob_get_clean() ) ) );
			echo '' === $text ? '' : "\n" . esc_html( $text ) . "\n\n";
			return;
		}
		self::note( $order, $email );
	}

	/**
	 * «Por WhatsApp», «por correo», «por SMS».
	 *
	 * @param string $via Channel.
	 */
	public static function channel( string $via ): string {
		return Orders::channel( $via );
	}

	/**
	 * Gift of an order, unless it is a legacy one without a recipient.
	 *
	 * @param mixed $order Order.
	 * @return array{to: string, message: string, via: string, contact: string, from: string, legacy: bool}|null
	 */
	private static function gift( $order ): ?array {
		$gift = $order instanceof \WC_Order ? Gift::of( $order ) : null;
		return null === $gift || $gift['legacy'] || '' === $gift['to'] ? null : $gift;
	}

	/**
	 * Whether an email is the notice to the recipient.
	 *
	 * @param mixed $email Email.
	 */
	private static function is_recipient( $email ): bool {
		return $email instanceof RecipientEmail;
	}

	/**
	 * Note of the gift before the product lines.
	 *
	 * @param mixed $order Order.
	 * @param mixed $email Email.
	 */
	public static function note( $order, $email = null ): void {
		if ( ! $order instanceof \WC_Order || ! $email instanceof \WC_Email || self::is_recipient( $email ) ) {
			return;
		}
		$any = Gift::of( $order );
		if ( null === $any ) {
			return;
		}
		$title = '';
		$text  = '';
		if ( ! $email->is_customer_email() ) {
			if ( $any['legacy'] ) {
				$title = __( 'Regalo (web anterior)', 'lachinata-core' );
			} elseif ( 'none' === $any['via'] ) {
				/* translators: %s: recipient. */
				$title = sprintf( __( 'Regalo para %s · sin aviso', 'lachinata-core' ), $any['to'] );
			} else {
				/* translators: 1: recipient, 2: channel («por WhatsApp»). */
				$title = sprintf( __( 'Regalo para %1$s · aviso %2$s', 'lachinata-core' ), $any['to'], self::channel( $any['via'] ) );
			}
			$parts = array();
			if ( '' !== $any['message'] ) {
				/* translators: %s: message for the handwritten card. */
				$parts[] = sprintf( __( '«%s»', 'lachinata-core' ), $any['message'] );
			}
			if ( '' !== $any['from'] && 'none' !== $any['via'] ) {
				/* translators: %s: «De parte de». */
				$parts[] = sprintf( __( 'De parte de %s', 'lachinata-core' ), $any['from'] );
			}
			$text = implode( ' · ', $parts );
		} else {
			$gift = self::gift( $order );
			if ( null === $gift ) {
				return;
			}
			if ( in_array( $email->id, array( 'customer_processing_order', 'customer_on_hold_order', 'customer_invoice' ), true ) ) {
				/* translators: %s: recipient. */
				$title = sprintf( __( 'Es un regalo para %s', 'lachinata-core' ), $gift['to'] );
				$text  = 'none' === $gift['via']
					? __( 'Llevará tu mensaje escrito a mano.', 'lachinata-core' )
					/* translators: 1: recipient, 2: channel («por WhatsApp»). */
					: sprintf( __( 'Llevará tu mensaje escrito a mano. Avisaremos a %1$s %2$s cuando salga el paquete.', 'lachinata-core' ), self::first_name( $gift['to'] ), self::channel( $gift['via'] ) );
			} elseif ( 'customer_completed_order' === $email->id ) {
				$sent = Gift::notified( $order );
				if ( null === $sent || ! $sent['ok'] ) {
					return;
				}
				/* translators: %s: recipient. */
				$title = sprintf( __( 'Hemos avisado a %s', 'lachinata-core' ), $gift['to'] );
				$text  = $sent['link']
					/* translators: %s: channel («por WhatsApp»). */
					? sprintf( __( 'Le hemos escrito %s con la fecha de entrega y el seguimiento, sin desvelar qué contiene ni cuánto cuesta.', 'lachinata-core' ), self::channel( (string) $sent['via'] ) )
					/* translators: %s: channel («por WhatsApp»). */
					: sprintf( __( 'Le hemos escrito %s con la fecha de entrega, sin desvelar qué contiene ni cuánto cuesta.', 'lachinata-core' ), self::channel( (string) $sent['via'] ) );
			} else {
				return;
			}
		}
		printf(
			'<table role="presentation" width="100%%" cellpadding="0" cellspacing="0" class="lc-mail-note"><tr><td class="lc-mail-note__cell"><p class="lc-mail-note__title" data-no-translation>%1$s</p>%2$s</td></tr></table>',
			esc_html( $title ),
			'' !== $text ? '<p class="lc-mail-note__text" data-no-translation>' . esc_html( $text ) . '</p>' : ''
		);
	}

	/**
	 * «María López» → «María».
	 *
	 * @param string $name Name.
	 */
	private static function first_name( string $name ): string {
		$parts = preg_split( '/\s+/', trim( $name ) );
		return is_array( $parts ) && '' !== $parts[0] ? $parts[0] : $name;
	}

	/**
	 * «Regalo» badge under the title of the internal email.
	 *
	 * @param mixed $order Order.
	 * @param mixed $email Email.
	 */
	public static function badge( $order, $email = null ): void {
		if ( ! $order instanceof \WC_Order || ! $email instanceof \WC_Email || $email->is_customer_email() || null === Gift::of( $order ) ) {
			return;
		}
		echo '<p class="lc-mail-badges"><span class="lc-mail-badge">' . esc_html__( 'Regalo', 'lachinata-core' ) . '</span></p>';
	}

	/**
	 * «Nuevo pedido 48213 · 69,85 € · regalo».
	 *
	 * @param mixed $subject Subject.
	 * @param mixed $email   Email.
	 */
	public static function subject( $subject, $email = null ): string {
		$subject = (string) $subject;
		if ( ! $email instanceof \WC_Email || 'new_order' !== $email->id || ! $email->object instanceof \WC_Order || null === Gift::of( $email->object ) ) {
			return $subject;
		}
		/* translators: %s: subject of the internal new order email. */
		return sprintf( __( '%s · regalo', 'lachinata-core' ), $subject );
	}

	/**
	 * Eyebrow, title and lead of the notice to the recipient.
	 *
	 * @param mixed $intro Intro.
	 * @param mixed $email Email.
	 * @return array<string, mixed>
	 */
	public static function intro( $intro, $email = null ): array {
		$intro = is_array( $intro ) ? $intro : array();
		if ( ! $email instanceof RecipientEmail || null === $email->message ) {
			return $intro;
		}
		$message = $email->message;
		$when    = $message->span();
		return array(
			'eyebrow'   => __( 'Un regalo para ti', 'lachinata-core' ),
			'title'     => $message->subject(),
			'lead'      => $message->greeting() . ' ' . $message->email_lead(),
			'preheader' => '' === $when
				/* translators: %s: who sends the gift. */
				? sprintf( __( '%s te envía un regalo', 'lachinata-core' ), $message->from )
				/* translators: 1: who sends the gift, 2: delivery dates («jue 24 – vie 25 oct»). */
				: sprintf( __( '%1$s te envía un regalo · llega %2$s', 'lachinata-core' ), $message->from, $when ),
		);
	}

	/**
	 * «Llega» and «A» in the notice to the recipient.
	 *
	 * @param mixed $facts Facts.
	 * @param mixed $order Order.
	 * @param mixed $email Email.
	 * @return array<string, mixed>
	 */
	public static function facts( $facts, $order = null, $email = null ): array {
		$facts = is_array( $facts ) ? $facts : array();
		if ( ! $email instanceof RecipientEmail || null === $email->message || ! $order instanceof \WC_Order ) {
			return $facts;
		}
		$message = $email->message;
		$out     = array();
		$when    = $message->span();
		if ( '' !== $when || null !== $message->carrier ) {
			$out['delivery'] = array(
				'label' => __( 'Llega', 'lachinata-core' ),
				'value' => '' !== $when ? $when : __( 'En los próximos días', 'lachinata-core' ),
				/* translators: %s: carrier. */
				'note'  => null !== $message->carrier ? sprintf( __( 'Con %s', 'lachinata-core' ), $message->carrier ) : '',
			);
		}
		$out['address'] = array(
			/* translators: label of the delivery address in the gift notice («A Calle Mayor 3»). */
			'label' => _x( 'A', 'gift delivery address', 'lachinata-core' ),
			'value' => trim( $order->get_shipping_address_1() ),
			'note'  => trim( $order->get_shipping_postcode() . ' ' . $order->get_shipping_city() ),
		);
		return $out;
	}

	/**
	 * «Seguir el paquete», secondary and only with tracking, in the notice to the recipient.
	 *
	 * @param mixed $button Button.
	 * @param mixed $email  Email.
	 * @return array<string, string>|null
	 */
	public static function button( $button, $email = null ): ?array {
		if ( ! $email instanceof RecipientEmail ) {
			return is_array( $button ) ? $button : null;
		}
		if ( null === $email->message || '' === $email->message->link ) {
			return null;
		}
		return array(
			'label'   => __( 'Seguir el paquete', 'lachinata-core' ),
			'url'     => $email->message->link,
			'variant' => 'secondary',
		);
	}

	/**
	 * The notice to the recipient shows nothing of the order and no «¿Alguna duda?».
	 *
	 * @param mixed $layout Layout.
	 * @param mixed $email  Email.
	 * @return array<string, mixed>
	 */
	public static function layout( $layout, $email = null ): array {
		$layout = is_array( $layout ) ? $layout : array();
		if ( ! $email instanceof RecipientEmail ) {
			return $layout;
		}
		return array(
			'lines'        => 'none',
			'totals'       => false,
			'addresses'    => false,
			'help'         => false,
			'instructions' => false,
		);
	}

	/**
	 * Foot of the notice (06-correos.md, «Pie según destinatario»): only the line of the shop
	 * with «¿Qué es La Chinata?»; no reason line, no menu, no tagline.
	 *
	 * @param mixed $html  Line.
	 * @param mixed $email Email.
	 */
	public static function footer_note( $html, $email = null ): string {
		return $email instanceof RecipientEmail ? '' : (string) $html;
	}

	/**
	 * «La Chinata · Plasencia, Cáceres · desde 1932 · ¿Qué es La Chinata?».
	 *
	 * @param mixed $html  Line, escaped.
	 * @param mixed $email Email.
	 */
	public static function footer_line( $html, $email = null ): string {
		if ( ! $email instanceof RecipientEmail ) {
			return (string) $html;
		}
		/* translators: %s: shop name. */
		return (string) $html . ' · ' . sprintf( '<a href="%1$s">%2$s</a>', esc_url( GiftModule::about_url() ), esc_html( sprintf( __( '¿Qué es %s?', 'lachinata-core' ), Notifier::brand() ) ) );
	}

	/**
	 * No links in the recipient's footer: they have no account with the shop.
	 *
	 * @param mixed $links Links.
	 * @param mixed $email Email.
	 * @return array<int, array{title: string, url: string}>|null
	 */
	public static function footer_links( $links, $email = null ): ?array {
		return $email instanceof RecipientEmail ? array() : ( is_array( $links ) ? $links : null );
	}
}
