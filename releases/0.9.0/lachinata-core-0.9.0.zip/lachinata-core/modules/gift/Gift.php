<?php
/**
 * The gift of an order.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Gift;

defined( 'ABSPATH' ) || exit;

/**
 * What the buyer said in «¿Es un regalo?» (04-envios-entrega.md, «Regalos»), kept in the
 * order meta: recipient, handwritten message, how to notify the recipient (email, SMS or
 * not at all), the recipient's contact (only for that notice, erased some days after) and
 * «De parte de». One gift per order.
 *
 * Orders of the current site have no box: the gift was told by the ACF field
 * `nota_cliente` (Pedido group). Such an order reads as a gift with that message and no
 * notice.
 */
final class Gift {

	/**
	 * Order meta.
	 */
	public const META         = '_lc_regalo';
	public const META_TO      = '_lc_regalo_para';
	public const META_MESSAGE = '_lc_regalo_mensaje';
	public const META_VIA     = '_lc_regalo_aviso';
	public const META_CONTACT = '_lc_regalo_contacto';
	public const META_FROM    = '_lc_regalo_de';

	/**
	 * Internal meta: the notice sent (`at`, `via`, `ok`, `error`) and when the contact was erased.
	 */
	public const META_NOTIFIED = '_lc_regalo_avisado';
	public const META_ERASED   = '_lc_regalo_contacto_borrado';

	/**
	 * When the recipient's contact is due to be erased (timestamp; 0.9.0).
	 */
	public const META_ERASE_AT = '_lc_gift_erase_at';

	/**
	 * Gift note of the current site (ACF, Pedido group).
	 */
	public const LEGACY_NOTE = 'nota_cliente';

	/**
	 * Notice channels.
	 */
	public const VIAS = array( 'email', 'whatsapp', 'sms', 'none' );

	/**
	 * Consent of the notice: the channel the buyer chose for the recipient, when, and the
	 * channels the checkout offered (06-correos.md: the choice is the record).
	 */
	public const META_CONSENT = '_lc_regalo_consentimiento';

	/**
	 * Longest message: it is handwritten on a card.
	 */
	public const MESSAGE_MAX = 200;

	/**
	 * Longest name (recipient, «De parte de»).
	 */
	public const NAME_MAX = 60;

	/**
	 * The gift of an order, or null when it is not one.
	 *
	 * @param \WC_Order $order Order.
	 * @return array{to: string, message: string, via: string, contact: string, from: string, legacy: bool}|null
	 */
	public static function of( \WC_Order $order ): ?array {
		if ( wc_string_to_bool( (string) $order->get_meta( self::META ) ) ) {
			$via = (string) $order->get_meta( self::META_VIA );
			return array(
				'to'      => (string) $order->get_meta( self::META_TO ),
				'message' => (string) $order->get_meta( self::META_MESSAGE ),
				'via'     => in_array( $via, self::VIAS, true ) ? $via : 'none',
				'contact' => (string) $order->get_meta( self::META_CONTACT ),
				'from'    => (string) $order->get_meta( self::META_FROM ),
				'legacy'  => false,
			);
		}
		$note = trim( (string) $order->get_meta( self::LEGACY_NOTE ) );
		if ( '' === $note ) {
			return null;
		}
		return array(
			'to'      => '',
			'message' => $note,
			'via'     => 'none',
			'contact' => '',
			'from'    => '',
			'legacy'  => true,
		);
	}

	/**
	 * Checks and normalises what the checkout sent.
	 *
	 * @param array<string, mixed> $input    `to`, `message`, `via`, `contact`, `from`.
	 * @param string               $country  Country of the delivery address (for the mobile).
	 * @param string[]|null        $channels Channels offered (null: Gift::channels()).
	 * @return array{data: array{to: string, message: string, via: string, contact: string, from: string}, errors: array<string, string>}
	 */
	public static function validate( array $input, string $country, ?array $channels = null ): array {
		$text   = static fn( string $key ): string => trim( sanitize_text_field( (string) ( $input[ $key ] ?? '' ) ) );
		$data   = array(
			'to'      => $text( 'to' ),
			'message' => trim( sanitize_textarea_field( (string) ( $input['message'] ?? '' ) ) ),
			'via'     => in_array( $input['via'] ?? '', self::VIAS, true ) ? (string) $input['via'] : 'none',
			'contact' => $text( 'contact' ),
			'from'    => $text( 'from' ),
		);
		$errors = array();

		if ( '' === $data['to'] ) {
			$errors['to'] = __( 'Escribe el nombre de quien recibe el regalo.', 'lachinata-core' );
		} elseif ( mb_strlen( $data['to'] ) > self::NAME_MAX ) {
			/* translators: %d: maximum number of characters. */
			$errors['to'] = sprintf( __( 'Acorta el nombre de quien lo recibe a %d caracteres.', 'lachinata-core' ), self::NAME_MAX );
		}
		if ( mb_strlen( $data['message'] ) > self::MESSAGE_MAX ) {
			/* translators: %d: maximum number of characters. */
			$errors['message'] = sprintf( __( 'Acorta el mensaje a %d caracteres: lo escribimos a mano en la tarjeta.', 'lachinata-core' ), self::MESSAGE_MAX );
		}

		$channels = $channels ?? self::channels();
		if ( 'none' !== $data['via'] && ! in_array( $data['via'], $channels, true ) ) {
			$errors['via'] = $channels
				? __( 'Elige otra forma de avisar a quien lo recibe.', 'lachinata-core' )
				: __( 'Ahora no podemos avisar a quien lo recibe: elige «No avisar».', 'lachinata-core' );
		}

		if ( 'none' === $data['via'] ) {
			$data['contact'] = '';
		} elseif ( 'email' === $data['via'] ) {
			$data['contact'] = (string) sanitize_email( $data['contact'] );
			if ( '' === $data['contact'] || ! is_email( $data['contact'] ) ) {
				$errors['contact'] = __( 'Escribe el correo de quien recibe el regalo, como nombre@correo.es.', 'lachinata-core' );
			}
		} else {
			$mobile = \LaChinata\Core\Phone::normalize( $data['contact'], $country );
			if ( null === $mobile ) {
				$errors['contact'] = __( 'Escribe el móvil de quien recibe el regalo, con el prefijo si no es de España.', 'lachinata-core' );
			} else {
				$data['contact'] = $mobile;
			}
		}

		if ( 'none' !== $data['via'] && '' === $data['from'] ) {
			$errors['from'] = __( 'Escribe tu nombre tal y como lo verá: le diremos de parte de quién es.', 'lachinata-core' );
		} elseif ( mb_strlen( $data['from'] ) > self::NAME_MAX ) {
			/* translators: %d: maximum number of characters. */
			$errors['from'] = sprintf( __( 'Acorta «De parte de» a %d caracteres.', 'lachinata-core' ), self::NAME_MAX );
		}

		return array(
			'data'   => $data,
			'errors' => $errors,
		);
	}

	/**
	 * Saves a checked gift on the order (does not save the order).
	 *
	 * @param \WC_Order                                                                      $order    Order.
	 * @param array{to: string, message: string, via: string, contact: string, from: string} $data     Gift.
	 * @param string[]|null                                                                  $channels Channels offered.
	 */
	public static function store( \WC_Order $order, array $data, ?array $channels = null ): void {
		$order->update_meta_data( self::META, 'yes' );
		$order->update_meta_data(
			self::META_CONSENT,
			array(
				'channel' => $data['via'],
				'at'      => time(),
				'offered' => array_values( $channels ?? self::channels() ),
			)
		);
		$order->update_meta_data( self::META_TO, $data['to'] );
		$order->update_meta_data( self::META_MESSAGE, $data['message'] );
		$order->update_meta_data( self::META_VIA, $data['via'] );
		$order->update_meta_data( self::META_CONTACT, $data['contact'] );
		$order->update_meta_data( self::META_FROM, $data['from'] );
	}

	/**
	 * Removes the gift from an order (does not save the order): the buyer unticked the box
	 * after a failed payment.
	 *
	 * @param \WC_Order $order Order.
	 */
	public static function clear( \WC_Order $order ): void {
		foreach ( array( self::META, self::META_TO, self::META_MESSAGE, self::META_VIA, self::META_CONTACT, self::META_FROM, self::META_CONSENT ) as $key ) {
			$order->delete_meta_data( $key );
		}
	}

	/**
	 * Channels the checkout offers for the notice: the active and configured ones of the
	 * `notify` module, in its order (email, WhatsApp, SMS).
	 *
	 * @return string[]
	 */
	public static function channels(): array {
		$notifier = \LaChinata\Core\Services::notifier();
		return null === $notifier ? array() : array_values( array_intersect( $notifier->channels(), self::VIAS ) );
	}

	/**
	 * The notice already sent, or null.
	 *
	 * @param \WC_Order $order Order.
	 * @return array{at: int, via: string, ok: bool, error: string, link: bool}|null
	 */
	public static function notified( \WC_Order $order ): ?array {
		$sent = $order->get_meta( self::META_NOTIFIED );
		if ( ! is_array( $sent ) || ! isset( $sent['at'] ) ) {
			return null;
		}
		return array(
			'at'    => (int) $sent['at'],
			'via'   => (string) ( $sent['via'] ?? '' ),
			'ok'    => ! empty( $sent['ok'] ),
			'error' => (string) ( $sent['error'] ?? '' ),
			'link'  => ! empty( $sent['link'] ),
		);
	}

	/**
	 * `gift` in the `lachinata` object of the REST API (docs/api-odoo.md): null when the
	 * order is not a gift. Information only: it asks Odoo for no action.
	 *
	 * @param array<string, mixed> $data  Object.
	 * @param \WC_Order            $order Order.
	 * @return array<string, mixed>
	 */
	public static function rest_data( array $data, \WC_Order $order ): array {
		$gift = self::of( $order );
		if ( null === $gift ) {
			return $data;
		}
		$sent         = self::notified( $order );
		$erased       = (int) $order->get_meta( self::META_ERASED );
		$data['gift'] = array(
			'to'      => '' === $gift['to'] ? null : $gift['to'],
			'message' => '' === $gift['message'] ? null : $gift['message'],
			'from'    => '' === $gift['from'] ? null : $gift['from'],
			'notify'  => array(
				'via'       => $gift['via'],
				'contact'   => '' === $gift['contact'] ? null : $gift['contact'],
				'sent_at'   => null !== $sent && $sent['ok'] ? gmdate( 'Y-m-d\TH:i:s\Z', $sent['at'] ) : null,
				'erased_at' => $erased > 0 ? gmdate( 'Y-m-d\TH:i:s\Z', $erased ) : null,
			),
			'legacy'  => $gift['legacy'],
		);
		return $data;
	}

	/**
	 * Ids of the orders with a meta value.
	 *
	 * @param string $key   Meta key.
	 * @param string $value Meta value.
	 * @param int    $limit Most orders.
	 * @return int[]
	 */
	public static function orders_with( string $key, string $value, int $limit ): array {
		return \LaChinata\Core\Orders::with_meta( $key, $value, $limit );
	}
}
