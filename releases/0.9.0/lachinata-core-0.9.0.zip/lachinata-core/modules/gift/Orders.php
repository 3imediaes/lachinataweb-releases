<?php
/**
 * The gift wherever the order is shown.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Gift;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * «Regalo» in the order screen and the order list (HPOS and posts), in the emails to the
 * shop (recipient, message, notice) and to the buyer (confirmation: «Avisaremos a María
 * cuando salga el paquete»; shipped: «Hemos avisado a María por correo»), and the gift
 * block of the order received page (tablero Regalo, 7).
 */
final class Orders {

	/**
	 * Column of the order list.
	 */
	private const COLUMN = 'lachinata_gift';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'woocommerce_admin_order_data_after_shipping_address', array( self::class, 'admin' ) );
		Hooks::add_filter( 'manage_woocommerce_page_wc-orders_columns', array( self::class, 'columns' ) );
		Hooks::add_action( 'manage_woocommerce_page_wc-orders_custom_column', array( self::class, 'column' ), 10, 2 );
		Hooks::add_filter( 'manage_edit-shop_order_columns', array( self::class, 'columns' ) );
		Hooks::add_action( 'manage_shop_order_posts_custom_column', array( self::class, 'column' ), 10, 2 );
		Hooks::add_action( 'lachinata/thankyou/gift', array( self::class, 'thankyou' ) );
	}

	/**
	 * «por correo», «por SMS».
	 *
	 * @param string $via Channel.
	 */
	public static function channel( string $via ): string {
		return match ( $via ) {
			'sms'      => __( 'por SMS', 'lachinata-core' ),
			'whatsapp' => __( 'por WhatsApp', 'lachinata-core' ),
			default    => __( 'por correo', 'lachinata-core' ),
		};
	}

	/**
	 * Under the shipping address in the order screen.
	 *
	 * @param mixed $order Order.
	 */
	public static function admin( $order ): void {
		$gift = $order instanceof \WC_Order ? Gift::of( $order ) : null;
		if ( null === $gift ) {
			return;
		}
		$sent = Gift::notified( $order );
		?>
		<div class="lc-admin-gift">
			<p><mark class="order-status status-processing"><span><?php esc_html_e( 'Regalo', 'lachinata-core' ); ?></span></mark></p>
			<?php if ( '' !== $gift['to'] ) : ?>
				<p><strong><?php esc_html_e( 'Para', 'lachinata-core' ); ?></strong><br><span data-no-translation><?php echo esc_html( $gift['to'] ); ?></span></p>
			<?php endif; ?>
			<?php if ( '' !== $gift['message'] ) : ?>
				<p><strong><?php esc_html_e( 'Mensaje para la tarjeta', 'lachinata-core' ); ?></strong><br><span data-no-translation><?php echo nl2br( esc_html( $gift['message'] ) ); ?></span></p>
			<?php endif; ?>
			<p><strong><?php esc_html_e( 'Aviso a quien lo recibe', 'lachinata-core' ); ?></strong><br>
				<?php echo esc_html( self::notice_status( $order, $gift, $sent ) ); ?>
			</p>
			<?php if ( $gift['legacy'] ) : ?>
				<p class="description"><?php esc_html_e( 'Pedido de la web anterior: la nota del cliente se lee como mensaje de regalo.', 'lachinata-core' ); ?></p>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * The notice as one line for the shop.
	 *
	 * @param \WC_Order                                                             $order Order.
	 * @param array{to: string, via: string, contact: string, from: string}         $gift  Gift.
	 * @param array{at: int, via: string, ok: bool, error: string, link: bool}|null $sent  Notice sent.
	 */
	private static function notice_status( \WC_Order $order, array $gift, ?array $sent ): string {
		if ( 'none' === $gift['via'] ) {
			return '' === $gift['from']
				? __( 'No avisar (regalo anónimo).', 'lachinata-core' )
				: __( 'No avisar.', 'lachinata-core' );
		}
		$contact = '' !== $gift['contact'] ? $gift['contact'] : __( 'contacto borrado', 'lachinata-core' );
		if ( (int) $order->get_meta( Gift::META_ERASED ) > 0 ) {
			$contact = __( 'contacto borrado', 'lachinata-core' );
		}
		if ( null === $sent ) {
			/* translators: 1: channel («por correo»), 2: email or mobile, 3: «De parte de». */
			return sprintf( __( '%1$s (%2$s), de parte de %3$s. Se enviará cuando el pedido salga.', 'lachinata-core' ), ucfirst( self::channel( $gift['via'] ) ), $contact, $gift['from'] );
		}
		$when = wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $sent['at'] );
		return $sent['ok']
			/* translators: 1: channel, 2: email or mobile, 3: date and time. */
			? sprintf( __( 'Enviado %1$s (%2$s) el %3$s.', 'lachinata-core' ), self::channel( $gift['via'] ), $contact, $when )
			/* translators: 1: channel, 2: email or mobile, 3: reason. */
			: sprintf( __( 'No se pudo enviar %1$s (%2$s): %3$s.', 'lachinata-core' ), self::channel( $gift['via'] ), $contact, $sent['error'] );
	}

	/**
	 * Adds «Regalo» after the order number.
	 *
	 * @param array<string, string> $columns Columns.
	 * @return array<string, string>
	 */
	public static function columns( $columns ): array {
		$columns  = is_array( $columns ) ? $columns : array();
		$position = array_search( 'order_number', array_keys( $columns ), true );
		$position = false === $position ? count( $columns ) : $position + 1;
		return array_slice( $columns, 0, $position, true ) + array( self::COLUMN => __( 'Regalo', 'lachinata-core' ) ) + array_slice( $columns, $position, null, true );
	}

	/**
	 * The mark in the order list.
	 *
	 * @param string    $column Column.
	 * @param int|mixed $order  Order (HPOS) or post id.
	 */
	public static function column( $column, $order ): void {
		if ( self::COLUMN !== $column ) {
			return;
		}
		$order = $order instanceof \WC_Order ? $order : wc_get_order( (int) $order );
		if ( $order instanceof \WC_Order && null !== Gift::of( $order ) ) {
			echo '<mark class="order-status status-processing"><span>' . esc_html__( 'Regalo', 'lachinata-core' ) . '</span></mark>';
		}
	}

	/**
	 * Gift block of the order received page (tablero Regalo, 7), next to the delivery date.
	 *
	 * @param \WC_Order $order Order.
	 */
	public static function thankyou( $order ): void {
		$gift = $order instanceof \WC_Order ? Gift::of( $order ) : null;
		if ( null === $gift || $gift['legacy'] || '' === $gift['to'] ) {
			return;
		}
		?>
		<div class="lc-thanks__when lc-thanks__gift">
			<span class="lc-thanks__icon" aria-hidden="true"><svg class="lc-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" focusable="false"><use href="#lc-icon-gift"></use></svg></span>
			<div class="lc-thanks__when-text">
				<span class="h4">
					<?php
					/* translators: %s: recipient. */
					echo esc_html( sprintf( __( 'Es un regalo para %s', 'lachinata-core' ), $gift['to'] ) );
					?>
				</span>
				<span class="body-sm"><?php esc_html_e( 'Con tu mensaje escrito a mano en la tarjeta.', 'lachinata-core' ); ?></span>
				<?php if ( 'none' !== $gift['via'] ) : ?>
					<span class="caption">
						<?php
						/* translators: %s: channel («por correo»). */
						echo esc_html( sprintf( __( 'Le avisaremos %s cuando salga el paquete.', 'lachinata-core' ), self::channel( $gift['via'] ) ) );
						?>
					</span>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}
}
