<?php
/**
 * Email to the recipient of a gift.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Gift;

defined( 'ABSPATH' ) || exit;

/**
 * «Alberto te envía un regalo de La Chinata» (tablero Regalo, 5): who sends it, when it
 * arrives and, with tracking, «Seguir el paquete». No content, no price, no shop link in
 * the main part. A WooCommerce email, so it leaves through the shop's own email output
 * (Mandrill on lachinata.es) and sender, and it can be switched off or retitled in
 * WooCommerce → Ajustes → Correos. Its templates can be overridden by the theme in
 * `woocommerce/emails/lachinata-gift-recipient.php`.
 */
final class RecipientEmail extends \WC_Email {

	/**
	 * Email id (also its key in the mailer).
	 */
	public const ID = 'lachinata_gift_recipient';

	/**
	 * Texts of the notice being sent.
	 *
	 * @var Message|null
	 */
	public ?Message $message = null;

	/**
	 * Sets the email up.
	 */
	public function __construct() {
		$this->id             = self::ID;
		$this->customer_email = true;
		$this->title          = __( 'Aviso de regalo', 'lachinata-core' );
		$this->description    = __( 'Se envía a quien recibe un regalo cuando el pedido sale, si el comprador eligió avisar por correo. Sin contenido ni precio.', 'lachinata-core' );
		$this->template_html  = 'emails/lachinata-gift-recipient.php';
		$this->template_plain = 'emails/plain/lachinata-gift-recipient.php';
		$this->template_base  = LACHINATA_CORE_DIR . '/modules/gift/templates/';
		$this->placeholders   = array(
			'{from}'  => '',
			'{to}'    => '',
			'{brand}' => '',
		);
		parent::__construct();
	}

	/**
	 * Default subject.
	 */
	public function get_default_subject() {
		return __( '{from} te envía un regalo de {brand}', 'lachinata-core' );
	}

	/**
	 * Default heading.
	 */
	public function get_default_heading() {
		return __( '{from} te envía un regalo', 'lachinata-core' );
	}

	/**
	 * Sends the notice.
	 *
	 * @param \WC_Order $order     Order.
	 * @param Message   $message   Texts.
	 * @param string    $recipient Recipient's email.
	 */
	public function trigger( $order, $message = null, $recipient = '' ): bool {
		if ( ! $order instanceof \WC_Order || ! $message instanceof Message || ! is_email( $recipient ) ) {
			return false;
		}
		$this->setup_locale();
		$this->object                  = $order;
		$this->message                 = $message;
		$this->recipient               = $recipient;
		$this->placeholders['{from}']  = $message->from;
		$this->placeholders['{to}']    = $message->to;
		$this->placeholders['{brand}'] = $message->brand;
		$sent                          = $this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
		$this->restore_locale();
		return (bool) $sent;
	}

	/**
	 * HTML content.
	 */
	public function get_content_html() {
		return wc_get_template_html(
			$this->template_html,
			array(
				'message'       => $this->message,
				'email_heading' => $this->get_heading(),
				'about_url'     => GiftModule::about_url(),
				'email'         => $this,
			),
			'',
			$this->template_base
		);
	}

	/**
	 * Plain text content.
	 */
	public function get_content_plain() {
		return wc_get_template_html(
			$this->template_plain,
			array(
				'message'       => $this->message,
				'email_heading' => $this->get_heading(),
				'about_url'     => GiftModule::about_url(),
				'email'         => $this,
			),
			'',
			$this->template_base
		);
	}
}
