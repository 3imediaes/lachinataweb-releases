<?php
/**
 * Email to the recipient of a gift (tablero «Correos transaccionales», 3). The theme's
 * frame prints the eyebrow, title, lead, the facts «Llega» and «A» and the secondary
 * button (Emails); this adds «Si no vas a estar…» and why we write, with the frame's
 * `lc-mail-*` classes.
 *
 * @package LaChinata\Core
 *
 * @var \LaChinata\Core\Modules\Gift\Message $message       Texts.
 * @var string                               $email_heading Heading.
 * @var string                               $about_url     «¿Qué es La Chinata?».
 * @var \WC_Email                            $email         Email.
 */

defined( 'ABSPATH' ) || exit;

/**
 * WooCommerce: email header.
 *
 * @since 0.7.0
 */
do_action( 'woocommerce_email_header', $email_heading, $email ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.HookCommentWrongStyle, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook.
?>
<?php if ( ! \LaChinata\Core\Modules\Gift\Emails::frame() ) : ?>
	<?php
	// Another theme: the whole notice in sentences (who, when, with whom, where, the link).
	$lachinata_when = $message->when();
	?>
	<p><?php echo esc_html( $message->greeting() ); ?></p>
	<p><?php echo wp_kses( $message->lead( '<strong>' . esc_html( $message->from ) . '</strong>', '' === $lachinata_when ? '' : '<strong>' . esc_html( $lachinata_when ) . '</strong>' ), array( 'strong' => array() ) ); ?></p>
	<p><?php echo esc_html( $message->reassurance() ); ?></p>
	<?php if ( '' !== $message->link ) : ?>
		<p><a href="<?php echo esc_url( $message->link ); ?>"><?php esc_html_e( 'Seguir el paquete', 'lachinata-core' ); ?> &rarr;</a></p>
	<?php endif; ?>
	<p><small><?php echo esc_html( $message->why() ); ?></small></p>
	<?php if ( '' !== $about_url ) : ?>
		<p><small><a href="<?php echo esc_url( $about_url ); ?>">
			<?php
			/* translators: %s: shop name. */
			echo esc_html( sprintf( __( '¿Qué es %s?', 'lachinata-core' ), $message->brand ) );
			?>
		</a></small></p>
	<?php endif; ?>
<?php else : ?>
	<?php if ( '' !== $message->change_delivery() ) : ?>
		<p class="lc-mail-text"><?php echo esc_html( $message->change_delivery() ); ?></p>
	<?php endif; ?>
	<p class="lc-mail-caption" data-no-translation><?php echo esc_html( $message->why() ); ?></p>
<?php endif; ?>
<?php
/**
 * WooCommerce: email footer.
 *
 * @since 0.7.0
 */
do_action( 'woocommerce_email_footer', $email ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.HookCommentWrongStyle, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce hook.
