<?php
/**
 * Email to the recipient of a gift, plain text.
 *
 * @package LaChinata\Core
 *
 * @var \LaChinata\Core\Modules\Gift\Message $message       Texts.
 * @var string                               $email_heading Heading.
 * @var string                               $about_url     «¿Qué es La Chinata?».
 * @var \WC_Email                            $email         Email.
 */

defined( 'ABSPATH' ) || exit;

echo esc_html( wp_strip_all_tags( $email_heading ) ) . "\n\n";
echo esc_html( $message->greeting() ) . "\n\n";
echo esc_html( wp_specialchars_decode( $message->lead( $message->from, $message->when() ), ENT_QUOTES ) ) . "\n\n";
echo esc_html( $message->reassurance() ) . "\n\n";
if ( '' !== $message->link ) {
	/* translators: %s: tracking link. */
	echo esc_html( sprintf( __( 'Seguir el paquete: %s', 'lachinata-core' ), $message->link ) ) . "\n\n";
}
echo esc_html( $message->why() ) . "\n\n";
if ( '' !== $about_url ) {
	/* translators: 1: shop name, 2: link. */
	echo esc_html( sprintf( __( '¿Qué es %1$s? %2$s', 'lachinata-core' ), $message->brand, $about_url ) ) . "\n\n";
}
echo esc_html( wp_strip_all_tags( wptexturize( (string) apply_filters( 'woocommerce_email_footer_text', get_option( 'woocommerce_email_footer_text' ) ) ) ) ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment, WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce filter.
