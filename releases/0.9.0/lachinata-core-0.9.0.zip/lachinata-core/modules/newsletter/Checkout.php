<?php
/**
 * The checkout box, with Mailchimp for WooCommerce.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Newsletter;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * One box only: «Quiero recibir novedades y ofertas por correo» (Optin). With
 * Mailchimp for WooCommerce, its own box in the block checkout is hidden (its setting
 * «hide», forced while this module is on) and our box's value is given to it as if it were
 * its own (extension data `mailchimp-newsletter.optin`), before it reads it: it keeps doing
 * the rest (order, customer, its double opt-in). Without that plugin, the contact is added
 * with the module's provider, asking to confirm.
 */
final class Checkout {

	/**
	 * The box (Optin) and the consent it keeps.
	 */
	public const FIELD = Optin::FIELD;
	public const META  = Optin::META;

	/**
	 * Option of Mailchimp for WooCommerce.
	 */
	public const MC_OPTION = 'mailchimp-woocommerce';

	/**
	 * The service.
	 *
	 * @var Service|null
	 */
	private static ?Service $service = null;

	/**
	 * Registers the hooks.
	 *
	 * @param Service $service Service.
	 */
	public static function boot( Service $service ): void {
		self::$service = $service;
		Hooks::add_filter( 'option_' . self::MC_OPTION, array( self::class, 'hide_mailchimp_box' ) );
		Hooks::add_action( 'woocommerce_store_api_checkout_update_order_from_request', array( self::class, 'to_mailchimp' ), 5, 2 );
		Hooks::add_action( 'woocommerce_store_api_checkout_order_processed', array( self::class, 'without_mailchimp' ), 20 );
	}

	/**
	 * Whether Mailchimp for WooCommerce is there.
	 */
	public static function mailchimp_plugin(): bool {
		/**
		 * Whether Mailchimp for WooCommerce takes the checkout's consent.
		 *
		 * @since 0.8.0
		 *
		 * @param bool $active Whether the plugin is loaded.
		 */
		return (bool) apply_filters( 'lachinata/newsletter/mailchimp_plugin', function_exists( 'mailchimp_is_configured' ) );
	}

	/**
	 * Its checkout box, hidden.
	 *
	 * @param mixed $options Options of Mailchimp for WooCommerce.
	 * @return mixed
	 */
	public static function hide_mailchimp_box( $options ) {
		if ( is_array( $options ) ) {
			$options['mailchimp_checkbox_defaults'] = 'hide';
		}
		return $options;
	}

	/**
	 * Our box's value, as Mailchimp for WooCommerce reads it.
	 *
	 * @param mixed $order   Order.
	 * @param mixed $request Checkout request.
	 */
	public static function to_mailchimp( $order, $request ): void {
		if ( ! $request instanceof \WP_REST_Request || ! self::mailchimp_plugin() ) {
			return;
		}
		$fields     = (array) $request->get_param( 'additional_fields' );
		$extensions = (array) $request->get_param( 'extensions' );
		$mailchimp  = isset( $extensions['mailchimp-newsletter'] ) && is_array( $extensions['mailchimp-newsletter'] ) ? $extensions['mailchimp-newsletter'] : array();

		$mailchimp['optin']                 = ! empty( $fields[ self::FIELD ] );
		$extensions['mailchimp-newsletter'] = $mailchimp;
		$request->set_param( 'extensions', $extensions );
		unset( $order );
	}

	/**
	 * Without Mailchimp for WooCommerce: the provider adds the buyer who said yes.
	 *
	 * @param mixed $order Order.
	 */
	public static function without_mailchimp( $order ): void {
		if ( ! $order instanceof \WC_Order || self::mailchimp_plugin() || null === self::$service || (int) $order->get_meta( self::META ) <= 0 ) {
			return;
		}
		self::$service->add(
			$order->get_billing_email(),
			array(
				'name'         => $order->get_billing_first_name(),
				'double_optin' => true,
				'source'       => __( 'checkout', 'lachinata-core' ),
			)
		);
	}
}
