<?php
/**
 * The newsletter form of the footer.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Newsletter;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * Fills the theme's `lachinata/footer/newsletter` with the Footer component's block
 * (bundle.js: title, text, email field and arrow button) and the consent line with the
 * privacy link (Footer/README.md). It works without JavaScript: the form posts to
 * admin-post.php and comes back to the same page with the result. Pages are cached, so
 * there is no nonce: a hidden field catches robots and the provider asks every address to
 * confirm (double opt-in), so nobody is subscribed by someone else.
 */
final class FooterForm {

	/**
	 * Action of admin-post.php.
	 */
	public const ACTION = 'lachinata_newsletter';

	/**
	 * Query argument with the result on the way back.
	 */
	public const RESULT = 'lc-news';

	/**
	 * The service.
	 *
	 * @var Service|null
	 */
	private static ?Service $service = null;

	/**
	 * Registers the hooks.
	 *
	 * @param Service $service Service.
	 */
	public static function boot( Service $service ): void {
		self::$service = $service;
		if ( ! NewsletterModule::setting( 'footer_form' ) ) {
			return;
		}
		Hooks::add_action( 'lachinata/footer/newsletter', array( self::class, 'render' ) );
		Hooks::add_action( 'admin_post_nopriv_' . self::ACTION, array( self::class, 'handle' ) );
		Hooks::add_action( 'admin_post_' . self::ACTION, array( self::class, 'handle' ) );
	}

	/**
	 * Title of the block.
	 */
	public static function title(): string {
		$title = trim( (string) NewsletterModule::setting( 'footer_title' ) );
		return '' !== $title ? $title : __( 'Suscríbete a la newsletter', 'lachinata-core' );
	}

	/**
	 * Text under the title.
	 */
	public static function text(): string {
		$text = trim( (string) NewsletterModule::setting( 'footer_text' ) );
		return '' !== $text ? $text : __( 'Novedades, recetas y consejos de belleza con aceite de oliva.', 'lachinata-core' );
	}

	/**
	 * Prints the block.
	 */
	public static function render(): void {
		if ( null === self::$service || ! self::$service->available() ) {
			return;
		}
		$result  = isset( $_GET[ self::RESULT ] ) ? sanitize_key( wp_unslash( $_GET[ self::RESULT ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only a message.
		$privacy = get_privacy_policy_url();
		$back    = home_url( '/' . ( isset( $GLOBALS['wp'] ) && $GLOBALS['wp'] instanceof \WP ? (string) $GLOBALS['wp']->request : '' ) );
		?>
		<div>
			<h2 class="h3"><?php echo esc_html( self::title() ); ?></h2>
			<p class="body-sm lc-footer__news-text"><?php echo esc_html( self::text() ); ?></p>
		</div>
		<form class="lc-footer__news-form" id="lc-news" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>">
			<input type="hidden" name="back" value="<?php echo esc_attr( $back ); ?>">
			<p class="screen-reader-text" aria-hidden="true"><label>Web <input type="text" name="lc_web" value="" tabindex="-1" autocomplete="off"></label></p>
			<div class="lc-field body">
				<label for="lc-news-email" class="screen-reader-text"><?php esc_html_e( 'Tu correo electrónico', 'lachinata-core' ); ?></label>
				<div class="lc-field__box"><input id="lc-news-email" type="email" name="email" required inputmode="email" autocomplete="email" placeholder="<?php esc_attr_e( 'Tu correo electrónico', 'lachinata-core' ); ?>"></div>
			</div>
			<button type="submit" class="lc-btn button" aria-label="<?php esc_attr_e( 'Suscribirme', 'lachinata-core' ); ?>"><svg class="lc-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><use href="#lc-icon-arrow-right"></use></svg></button>
		</form>
		<p class="caption lc-footer__news-legal">
			<?php
			echo wp_kses(
				'' !== $privacy
					/* translators: %s: privacy policy URL. */
					? sprintf( __( 'Te pediremos que lo confirmes por correo. Puedes darte de baja cuando quieras. <a href="%s">Privacidad</a>.', 'lachinata-core' ), esc_url( $privacy ) )
					: __( 'Te pediremos que lo confirmes por correo. Puedes darte de baja cuando quieras.', 'lachinata-core' ),
				array( 'a' => array( 'href' => array() ) )
			);
			?>
		</p>
		<?php if ( 'ok' === $result || 'error' === $result ) : ?>
			<p class="body-sm lc-footer__news-result" role="status">
				<?php
				echo esc_html(
					'ok' === $result
						? __( 'Gracias. Te hemos enviado un correo: confírmalo para empezar a recibir la newsletter.', 'lachinata-core' )
						: __( 'No hemos podido apuntarte. Revisa el correo o inténtalo dentro de un rato.', 'lachinata-core' )
				);
				?>
			</p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Adds the address, asking to confirm, and goes back.
	 */
	public static function handle(): void {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Cached pages: no nonce; honeypot and double opt-in instead.
		$post = array(
			'email'  => isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '',
			'lc_web' => isset( $_POST['lc_web'] ) ? sanitize_text_field( wp_unslash( $_POST['lc_web'] ) ) : '',
			'back'   => isset( $_POST['back'] ) ? esc_url_raw( wp_unslash( $_POST['back'] ) ) : '',
		);
		// phpcs:enable
		$back = wp_validate_redirect( $post['back'], home_url( '/' ) );
		wp_safe_redirect( add_query_arg( self::RESULT, self::submit( $post ) ? 'ok' : 'error', $back ) . '#lc-news', 303 );
		exit;
	}

	/**
	 * What the form does with a submission: a robot (the hidden field filled) is told «ok»
	 * and nothing is done; a person is added asking to confirm.
	 *
	 * @param array{email: string, lc_web: string, back?: string} $post Submission.
	 */
	public static function submit( array $post ): bool {
		if ( '' !== $post['lc_web'] ) {
			return true;
		}
		return null !== self::$service && '' === self::$service->add(
			$post['email'],
			array(
				'double_optin' => true,
				'source'       => __( 'pie', 'lachinata-core' ),
			)
		);
	}
}
