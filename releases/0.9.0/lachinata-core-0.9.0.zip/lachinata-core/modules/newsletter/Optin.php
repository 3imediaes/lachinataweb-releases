<?php
/**
 * «Quiero recibir novedades y ofertas por correo» in Contacto.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Newsletter;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * A box in Contacto, unticked (explicit consent), only while this module is on: a consent
 * without a provider is no use. When it is ticked, the order keeps when the customer said
 * yes (`_lc_newsletter_optin`, timestamp; written by the `checkout` module until 0.8): the
 * provider adds the contact (Checkout) and Odoo reads it in `lachinata.newsletter` of the
 * REST API (docs/api-odoo.md).
 */
final class Optin {

	/**
	 * Additional checkout field.
	 */
	public const FIELD = 'lachinata/newsletter';

	/**
	 * Order meta: when the customer agreed (timestamp).
	 */
	public const META = '_lc_newsletter_optin';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'woocommerce_init', array( self::class, 'register_field' ) );
		Hooks::add_action( 'woocommerce_store_api_checkout_order_processed', array( self::class, 'from_checkout' ) );
		Hooks::add_filter( 'lachinata/rest/order', array( self::class, 'rest_data' ), 10, 2 );
	}

	/**
	 * `newsletter` in the `lachinata` object of the REST API: whether the customer agreed in
	 * this order and when (ISO 8601, UTC).
	 *
	 * @param array<string, mixed> $data  Object.
	 * @param \WC_Order            $order Order.
	 * @return array<string, mixed>
	 */
	public static function rest_data( array $data, \WC_Order $order ): array {
		$at                 = (int) $order->get_meta( self::META );
		$data['newsletter'] = array(
			'opt_in' => $at > 0,
			'at'     => $at > 0 ? gmdate( 'Y-m-d\TH:i:s\Z', $at ) : null,
		);
		return $data;
	}

	/**
	 * The box under the email.
	 */
	public static function register_field(): void {
		if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
			return;
		}
		woocommerce_register_additional_checkout_field(
			array(
				'id'                         => self::FIELD,
				'label'                      => __( 'Quiero recibir novedades y ofertas por correo', 'lachinata-core' ),
				// A box is always optional: without «(opcional)».
				'optionalLabel'              => __( 'Quiero recibir novedades y ofertas por correo', 'lachinata-core' ),
				'location'                   => 'contact',
				'type'                       => 'checkbox',
				// A consent or a switch, not order data: «No» in the emails and the thank-you page is noise.
				'show_in_order_confirmation' => false,
			)
		);
	}

	/**
	 * Keeps when the customer agreed, once per order.
	 *
	 * @param \WC_Order $order Order.
	 */
	public static function from_checkout( $order ): void {
		if ( ! $order instanceof \WC_Order || '' !== (string) $order->get_meta( self::META ) ) {
			return;
		}
		if ( wc_string_to_bool( (string) $order->get_meta( '_wc_other/' . self::FIELD ) ) ) {
			$order->update_meta_data( self::META, (string) time() );
			$order->save();
		}
	}
}
