<?php
/**
 * Mailchimp.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Newsletter\Providers;

defined( 'ABSPATH' ) || exit;

/**
 * Marketing API 3.0: `PUT /lists/{audience}/members/{md5(email)}` (adds or updates) with
 * `status_if_new` («pending» asks to confirm; «subscribed»; «transactional» keeps a contact
 * that receives no campaign) and `POST …/tags`. The key and the audience are the ones of
 * Mailchimp for WooCommerce, which keeps syncing products, orders and carts; the module's
 * settings can give others when that plugin is not there.
 */
final class MailchimpProvider implements Provider {

	/**
	 * Builds the provider.
	 *
	 * @param string $api_key  API key («…-us21»).
	 * @param string $audience Audience (list) id.
	 */
	public function __construct( private string $api_key, private string $audience ) {}

	/**
	 * Identifier.
	 */
	public function id(): string {
		return 'mailchimp';
	}

	/**
	 * Name for the admin screen.
	 */
	public function label(): string {
		return 'Mailchimp';
	}

	/**
	 * Whether there are a key with its data center and an audience.
	 */
	public function configured(): bool {
		return '' !== $this->audience && 1 === preg_match( '/-[a-z]+\d+$/', $this->api_key );
	}

	/**
	 * API base of the key's data center.
	 */
	public function base(): string {
		$center = substr( (string) strrchr( $this->api_key, '-' ), 1 );
		return 'https://' . $center . '.api.mailchimp.com/3.0';
	}

	/**
	 * Adds or updates a contact.
	 *
	 * @param string   $email        Email.
	 * @param string   $name         First name.
	 * @param bool     $subscribe    Subscribe it.
	 * @param bool     $double_optin Confirm first.
	 * @param string[] $tags         Tags.
	 */
	public function add( string $email, string $name, bool $subscribe, bool $double_optin, array $tags ): string {
		if ( ! $this->configured() ) {
			return __( 'Mailchimp no está configurado', 'lachinata-core' );
		}
		$member = '/lists/' . rawurlencode( $this->audience ) . '/members/' . md5( strtolower( $email ) );
		$body   = array(
			'email_address' => $email,
			'status_if_new' => $subscribe ? ( $double_optin ? 'pending' : 'subscribed' ) : 'transactional',
		);
		if ( '' !== $name ) {
			$body['merge_fields'] = array( 'FNAME' => $name );
		}
		$error = $this->request( 'PUT', $member, $body );
		if ( '' === $error && $tags ) {
			$error = $this->request(
				'POST',
				$member . '/tags',
				array(
					'tags' => array_map(
						static fn( string $tag ): array => array(
							'name'   => $tag,
							'status' => 'active',
						),
						array_values( $tags )
					),
				)
			);
		}
		return $error;
	}

	/**
	 * A request to the API.
	 *
	 * @param string               $method Method.
	 * @param string               $path   Path.
	 * @param array<string, mixed> $body   Body.
	 * @return string Empty when it worked; otherwise why.
	 */
	private function request( string $method, string $path, array $body ): string {
		$response = wp_remote_request(
			$this->base() . $path,
			array(
				'method'  => $method,
				'timeout' => 10,
				'headers' => array(
					'Authorization' => 'Basic ' . base64_encode( 'lachinata:' . $this->api_key ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- HTTP Basic auth.
					'Content-Type'  => 'application/json',
				),
				'body'    => (string) wp_json_encode( $body ),
			)
		);
		if ( is_wp_error( $response ) ) {
			/* translators: %s: error message. */
			return sprintf( __( 'No se pudo conectar con Mailchimp: %s', 'lachinata-core' ), $response->get_error_message() );
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( $code >= 200 && $code < 300 ) {
			return '';
		}
		$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		/* translators: 1: HTTP status, 2: Mailchimp's message. */
		return sprintf( __( 'Mailchimp respondió %1$d: %2$s', 'lachinata-core' ), $code, is_array( $data ) ? (string) ( $data['detail'] ?? $data['title'] ?? '' ) : '' );
	}
}
