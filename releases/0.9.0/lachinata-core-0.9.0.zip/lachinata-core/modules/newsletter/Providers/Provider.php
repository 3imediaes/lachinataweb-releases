<?php
/**
 * A newsletter provider.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Newsletter\Providers;

defined( 'ABSPATH' ) || exit;

/**
 * Mailchimp today; Brevo or another implements this and is set with
 * `lachinata/newsletter/provider`.
 */
interface Provider {

	/**
	 * Identifier (`mailchimp`…).
	 */
	public function id(): string;

	/**
	 * Name for the admin screen.
	 */
	public function label(): string;

	/**
	 * Whether it has what it needs to work.
	 */
	public function configured(): bool;

	/**
	 * Adds or updates a contact.
	 *
	 * @param string   $email        Email.
	 * @param string   $name         First name, or ''.
	 * @param bool     $subscribe    Subscribe it to the newsletter (false: contact only).
	 * @param bool     $double_optin The contact confirms by email first.
	 * @param string[] $tags         Tags to add.
	 * @return string Empty when it worked; otherwise why.
	 */
	public function add( string $email, string $name, bool $subscribe, bool $double_optin, array $tags ): string;
}
