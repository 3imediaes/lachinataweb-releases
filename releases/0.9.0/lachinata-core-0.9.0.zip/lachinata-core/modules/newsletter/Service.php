<?php
/**
 * The newsletter service.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Newsletter;

use LaChinata\Core\Contracts\Newsletter;

defined( 'ABSPATH' ) || exit;

/**
 * Contracts\Newsletter over the configured provider; a failure is recorded (gap log) and
 * never stops what called it.
 */
final class Service implements Newsletter {

	/**
	 * The provider: Mailchimp with the module's key and audience or, without them, the ones
	 * of Mailchimp for WooCommerce.
	 */
	public function provider(): Providers\Provider {
		$key      = (string) NewsletterModule::setting( 'mailchimp_api_key' );
		$list     = (string) NewsletterModule::setting( 'mailchimp_list' );
		$key      = '' !== $key ? $key : ( function_exists( 'mailchimp_get_api_key' ) ? (string) mailchimp_get_api_key() : '' );
		$list     = '' !== $list ? $list : ( function_exists( 'mailchimp_get_list_id' ) ? (string) mailchimp_get_list_id() : '' );
		$provider = new Providers\MailchimpProvider( $key, $list );
		/**
		 * Newsletter provider (Brevo or another instead of Mailchimp).
		 *
		 * @since 0.8.0
		 *
		 * @param Providers\Provider $provider Mailchimp.
		 */
		$filtered = apply_filters( 'lachinata/newsletter/provider', $provider );
		return $filtered instanceof Providers\Provider ? $filtered : $provider;
	}

	/**
	 * Whether a provider is configured.
	 */
	public function available(): bool {
		return $this->provider()->configured();
	}

	/**
	 * Adds or updates a contact.
	 *
	 * @param string               $email Email.
	 * @param array<string, mixed> $args  name, subscribe, double_optin, tags, source.
	 */
	public function add( string $email, array $args = array() ): string {
		$email = sanitize_email( $email );
		if ( ! is_email( $email ) ) {
			return __( 'el correo no es válido', 'lachinata-core' );
		}
		$provider = $this->provider();
		$error    = $provider->configured()
			? $provider->add(
				$email,
				sanitize_text_field( (string) ( $args['name'] ?? '' ) ),
				(bool) ( $args['subscribe'] ?? true ),
				(bool) ( $args['double_optin'] ?? true ),
				array_values( array_filter( array_map( 'sanitize_text_field', (array) ( $args['tags'] ?? array() ) ) ) )
			)
			/* translators: %s: provider name. */
			: sprintf( __( '%s no está configurado', 'lachinata-core' ), $provider->label() );
		if ( '' !== $error ) {
			NewsletterModule::gaps()->record(
				'add|' . md5( $error ),
				/* translators: 1: where it came from, 2: reason. */
				sprintf( __( 'Un alta en la newsletter (%1$s) no se hizo: %2$s.', 'lachinata-core' ), (string) ( $args['source'] ?? '—' ), $error )
			);
		}
		return $error;
	}
}
