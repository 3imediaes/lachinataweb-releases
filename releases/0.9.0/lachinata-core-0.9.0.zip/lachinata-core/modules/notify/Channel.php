<?php
/**
 * The channels of the notices.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Notify;

use LaChinata\Core\Contracts\Notifier;

defined( 'ABSPATH' ) || exit;

/**
 * Email, WhatsApp and SMS: each one is switched on and set up per shop. WhatsApp and SMS
 * have a «registro» mode that writes the notice to the log instead of sending it (local,
 * staging, the end-to-end tests).
 */
final class Channel {

	/**
	 * Channels in the order they are offered.
	 */
	public const ALL = array( Notifier::EMAIL, Notifier::WHATSAPP, Notifier::SMS );

	/**
	 * Modes of WhatsApp and SMS.
	 */
	public const LIVE = 'live';
	public const LOG  = 'log';

	/**
	 * Name of a channel for people.
	 *
	 * @param string $channel Channel.
	 */
	public static function label( string $channel ): string {
		return match ( $channel ) {
			Notifier::WHATSAPP => __( 'WhatsApp', 'lachinata-core' ),
			Notifier::SMS      => __( 'SMS', 'lachinata-core' ),
			default            => __( 'Correo', 'lachinata-core' ),
		};
	}
}
