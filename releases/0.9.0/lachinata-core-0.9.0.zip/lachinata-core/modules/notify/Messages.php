<?php
/**
 * The notices sent for an order.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Notify;

use LaChinata\Core\Orders;

defined( 'ABSPATH' ) || exit;

/**
 * Each notice that leaves is kept on its order (`_lc_notify`, keyed by the provider's
 * reference) with what the fallback needs: kind, channel, mobile, the SMS text, status and
 * the reference of the SMS sent instead. `_lc_notify_ref` (one row per reference) finds the
 * order when Meta reports a status.
 */
final class Messages {

	/**
	 * Order meta with the records.
	 */
	public const META = '_lc_notify';

	/**
	 * Order meta with one reference per row, for the lookup.
	 */
	public const REF_META = '_lc_notify_ref';

	/**
	 * Records of an order.
	 *
	 * @param \WC_Order $order Order.
	 * @return array<string, array{kind: string, channel: string, to: string, sms: string, at: int, status: string, error: string, fallback: string}>
	 */
	public static function of( \WC_Order $order ): array {
		$records = $order->get_meta( self::META );
		return is_array( $records ) ? $records : array();
	}

	/**
	 * Keeps a notice that left.
	 *
	 * @param \WC_Order $order   Order.
	 * @param string    $ref     Provider reference.
	 * @param string    $kind    Kind of notice.
	 * @param string    $channel Channel.
	 * @param string    $to      Mobile.
	 * @param string    $sms     SMS text (for the fallback).
	 */
	public static function add( \WC_Order $order, string $ref, string $kind, string $channel, string $to, string $sms ): void {
		$records         = self::of( $order );
		$records[ $ref ] = array(
			'kind'     => $kind,
			'channel'  => $channel,
			'to'       => $to,
			'sms'      => $sms,
			'at'       => time(),
			'status'   => 'sent',
			'error'    => '',
			'fallback' => '',
		);
		$order->update_meta_data( self::META, $records );
		$order->add_meta_data( self::REF_META, $ref );
		$order->save_meta_data();
	}

	/**
	 * Changes a record.
	 *
	 * @param \WC_Order            $order   Order.
	 * @param string               $ref     Reference.
	 * @param array<string, mixed> $changes Fields.
	 */
	public static function update( \WC_Order $order, string $ref, array $changes ): void {
		$records = self::of( $order );
		if ( ! isset( $records[ $ref ] ) ) {
			return;
		}
		$records[ $ref ] = array_merge( $records[ $ref ], array_intersect_key( $changes, $records[ $ref ] ) );
		$order->update_meta_data( self::META, $records );
		$order->save_meta_data();
	}

	/**
	 * Order of a provider reference, or null.
	 *
	 * @param string $ref Reference (`wamid…`).
	 */
	public static function order( string $ref ): ?\WC_Order {
		if ( '' === $ref ) {
			return null;
		}
		$ids   = Orders::with_meta( self::REF_META, $ref, 1 );
		$order = $ids ? wc_get_order( $ids[0] ) : false;
		return $order instanceof \WC_Order && isset( self::of( $order )[ $ref ] ) ? $order : null;
	}

	/**
	 * Forgets the mobile and the text of the notices of a kind.
	 *
	 * @param \WC_Order $order Order.
	 * @param string    $kind  Kind.
	 */
	public static function forget( \WC_Order $order, string $kind ): void {
		$records = self::of( $order );
		$changed = false;
		foreach ( $records as $ref => $record ) {
			if ( $kind === $record['kind'] && ( '' !== $record['to'] || '' !== $record['sms'] ) ) {
				$records[ $ref ]['to']  = '';
				$records[ $ref ]['sms'] = '';
				$changed                = true;
			}
		}
		if ( $changed ) {
			$order->update_meta_data( self::META, $records );
			$order->save_meta_data();
		}
	}
}
