<?php
/**
 * Module `notify`: short notices by WhatsApp or SMS.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Notify;

use LaChinata\Core\GapLog;
use LaChinata\Core\Hooks;
use LaChinata\Core\Module;
use LaChinata\Core\Plugin;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Channels of the notices shared by `gift` and `shipment` (06-correos.md, «Avisos por
 * WhatsApp y SMS»): WhatsApp through Meta's Cloud API with approved templates (the main
 * channel, from the shop's number) and SMS through OVH (the fallback). Each channel is
 * switched on and set up per shop in WooCommerce → La Chinata → Avisos; only the active and
 * configured ones are offered. It serves Contracts\Notifier with `lachinata/notify/service`,
 * owns the short link `/s/<token>` and the webhook where Meta reports what happened to each
 * message: when WhatsApp cannot deliver one and the SMS is on, the notice goes once by SMS.
 */
final class NotifyModule extends Module {

	/**
	 * Module id.
	 */
	public function id(): string {
		return 'notify';
	}

	/**
	 * Module name.
	 */
	public function label(): string {
		return __( 'Avisos', 'lachinata-core' );
	}

	/**
	 * Module description.
	 */
	public function description(): string {
		return __( 'Avisos en corto por WhatsApp (API de Meta) y SMS (OVH, respaldo) para el regalo y el envío, con el enlace corto al seguimiento. Cada canal se activa por tienda.', 'lachinata-core' );
	}

	/**
	 * Version in which the module was added.
	 */
	public function since(): string {
		return '0.8.0';
	}

	/**
	 * Documentation.
	 */
	public function docs(): string {
		return 'plugin/modules/notify/README.md';
	}

	/**
	 * Requirements.
	 *
	 * @return array{modules: string[], woocommerce: string}
	 */
	public function requires(): array {
		return array(
			'modules'     => array(),
			'woocommerce' => '10.0',
		);
	}

	/**
	 * Settings. Credentials belong to each site and stay out of the JSON, without defaults.
	 *
	 * @return array<string, array{type: 'bool'|'int'|'float'|'string'|'array', default: mixed, export?: bool}>
	 */
	public function settings(): array {
		$secret = array(
			'type'    => 'string',
			'default' => '',
			'export'  => false,
		);
		$text   = static fn( string $value ): array => array(
			'type'    => 'string',
			'default' => $value,
			'export'  => true,
		);
		$flag   = static fn( bool $value ): array => array(
			'type'    => 'bool',
			'default' => $value,
			'export'  => true,
		);
		return array(
			'email_enabled'          => $flag( true ),
			'whatsapp_enabled'       => $flag( false ),
			'whatsapp_mode'          => $text( Channel::LIVE ),
			'wa_phone_number_id'     => $secret,
			'wa_business_account_id' => $secret,
			'wa_token'               => $secret,
			'wa_app_secret'          => $secret,
			'wa_verify_token'        => $secret,
			'wa_api_version'         => $text( 'v23.0' ),
			'wa_language'            => $text( 'es' ),
			'wa_tpl_gift'            => $text( 'lc_regalo_aviso' ),
			'wa_tpl_gift_nolink'     => $text( 'lc_regalo_aviso_sin_enlace' ),
			'wa_tpl_shipped'         => $text( 'lc_pedido_enviado' ),
			'wa_tpl_shipped_nolink'  => $text( 'lc_pedido_enviado_sin_enlace' ),
			'sms_enabled'            => $flag( false ),
			'sms_mode'               => $text( Channel::LIVE ),
			'sms_fallback'           => $flag( true ),
			'ovh_endpoint'           => $text( 'ovh-eu' ),
			'ovh_app_key'            => $secret,
			'ovh_app_secret'         => $secret,
			'ovh_consumer_key'       => $secret,
			'ovh_service'            => $secret,
			'ovh_sender'             => $secret,
		);
	}

	/**
	 * A setting of the module.
	 *
	 * @param string $key Setting key.
	 * @return mixed
	 */
	public static function setting( string $key ) {
		$module = Plugin::instance()->modules()->get( 'notify' );
		return null === $module ? null : Settings::get( $module, $key );
	}

	/**
	 * Configuration gaps of the module.
	 */
	public static function gaps(): GapLog {
		return new GapLog( 'lachinata_notify_gaps', 'lachinata-notify' );
	}

	/**
	 * Configured with some channel on; credentials complete for the channels that are live
	 * (not in «registro»).
	 *
	 * @return array{configured: bool, credentials: bool|null, notes: string[]}
	 */
	public function health(): array {
		$service = new Service();
		$live    = array();
		foreach ( array( 'whatsapp', 'sms' ) as $channel ) {
			if ( self::setting( $channel . '_enabled' ) && Channel::LOG !== self::setting( $channel . '_mode' ) ) {
				$live[ $channel ] = 'whatsapp' === $channel ? $service->whatsapp_ready() : $service->sms_ready();
			}
		}
		$notes = array();
		foreach ( array( 'email', 'whatsapp', 'sms' ) as $channel ) {
			if ( self::setting( $channel . '_enabled' ) ) {
				$notes[] = 'email' === $channel
					? Channel::label( $channel )
					: sprintf( '%1$s (%2$s)', Channel::label( $channel ), Channel::LOG === self::setting( $channel . '_mode' ) ? __( 'registro', 'lachinata-core' ) : __( 'real', 'lachinata-core' ) );
			}
		}
		return array(
			'configured'  => (bool) $notes,
			'credentials' => $live ? ! in_array( false, $live, true ) : null,
			'notes'       => $notes,
		);
	}

	/**
	 * Notices and short links kept on orders.
	 *
	 * @return array{order_meta: string[]}
	 */
	public function owned_data(): array {
		return array( 'order_meta' => array( Messages::META, '_lc_notify_ref', ShortLink::META ) );
	}

	/**
	 * Registers the hooks.
	 */
	public function boot(): void {
		$service = new Service();
		Hooks::add_filter( 'lachinata/notify/service', static fn() => $service );
		ShortLink::boot();
		Webhook::boot( $service );
		if ( is_admin() ) {
			NotifyTab::boot();
		}
	}
}
