<?php
/**
 * WooCommerce → La Chinata → Avisos.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Notify;

use LaChinata\Core\Admin\Screen;
use LaChinata\Core\Contact;
use LaChinata\Core\Contracts\Notice;
use LaChinata\Core\Contracts\Notifier;
use LaChinata\Core\Hooks;
use LaChinata\Core\Phone;
use LaChinata\Core\Plugin;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * One block per channel (switch, mode, credentials, templates) with a test, and the notices
 * that did not leave. Credentials are never printed back: an empty field keeps the saved one.
 */
final class NotifyTab {

	/**
	 * Tab id.
	 */
	public const TAB = 'notify';

	/**
	 * Actions of admin-post.php, also nonce actions.
	 */
	private const SAVE       = 'lachinata_notify_settings';
	private const TEST       = 'lachinata_notify_test';
	private const CLEAR_GAPS = 'lachinata_notify_clear_gaps';

	/**
	 * Credentials kept when their field is sent empty.
	 */
	private const SECRETS = array( 'wa_token', 'wa_app_secret', 'wa_verify_token', 'ovh_app_secret', 'ovh_consumer_key' );

	/**
	 * Text settings of the form.
	 */
	private const TEXTS = array( 'wa_phone_number_id', 'wa_business_account_id', 'wa_token', 'wa_app_secret', 'wa_verify_token', 'wa_api_version', 'wa_language', 'wa_tpl_gift', 'wa_tpl_gift_nolink', 'wa_tpl_shipped', 'wa_tpl_shipped_nolink', 'ovh_app_key', 'ovh_app_secret', 'ovh_consumer_key', 'ovh_service', 'ovh_sender' );

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/core/admin_tabs', array( self::class, 'tab' ), 30 );
		foreach ( array( self::SAVE, self::TEST, self::CLEAR_GAPS ) as $action ) {
			Hooks::add_action( 'admin_post_' . $action, array( self::class, 'handle' ) );
		}
	}

	/**
	 * Adds the tab after Checkout.
	 *
	 * @param array<string, array{label: string, render: callable}> $tabs Tabs.
	 * @return array<string, array{label: string, render: callable}>
	 */
	public static function tab( array $tabs ): array {
		$position = array_search( 'checkout', array_keys( $tabs ), true );
		$position = false === $position ? 1 : $position + 1;
		$tab      = array(
			self::TAB => array(
				'label'  => __( 'Avisos', 'lachinata-core' ),
				'render' => array( self::class, 'render' ),
			),
		);
		return array_slice( $tabs, 0, $position, true ) + $tab + $tabs;
	}

	/**
	 * Prints the tab.
	 */
	public static function render(): void {
		$sections = array(
			'settings' => __( 'Canales', 'lachinata-core' ),
			'gaps'     => __( 'Huecos de configuración', 'lachinata-core' ),
		);
		$current  = isset( $_GET['section'] ) ? sanitize_key( wp_unslash( $_GET['section'] ) ) : 'settings'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Navigation only.
		$current  = isset( $sections[ $current ] ) ? $current : 'settings';
		Screen::section_links( self::TAB, $sections, $current );
		if ( 'gaps' === $current ) {
			self::render_gaps();
		} else {
			self::render_settings();
		}
	}

	/**
	 * A text field of the form.
	 *
	 * @param string               $key    Setting.
	 * @param string               $label  Label.
	 * @param array<string, mixed> $values Current values.
	 * @param string               $hint   Help under the field.
	 */
	private static function field( string $key, string $label, array $values, string $hint = '' ): void {
		$secret = in_array( $key, self::SECRETS, true );
		$saved  = '' !== (string) $values[ $key ];
		?>
		<tr>
			<th scope="row"><label for="lc-notify-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
			<td>
				<input type="<?php echo $secret ? 'password' : 'text'; ?>" class="regular-text" id="lc-notify-<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $key ); ?>" value="<?php echo $secret ? '' : esc_attr( (string) $values[ $key ] ); ?>" autocomplete="off" placeholder="<?php echo $secret && $saved ? esc_attr__( 'Guardado (escribe otro para cambiarlo)', 'lachinata-core' ) : ''; ?>">
				<?php if ( '' !== $hint ) : ?>
					<p class="description"><?php echo esc_html( $hint ); ?></p>
				<?php endif; ?>
			</td>
		</tr>
		<?php
	}

	/**
	 * The switch and mode of a channel.
	 *
	 * @param string               $channel whatsapp or sms.
	 * @param array<string, mixed> $values  Current values.
	 */
	private static function switches( string $channel, array $values ): void {
		?>
		<tr>
			<th scope="row"><?php esc_html_e( 'Activo', 'lachinata-core' ); ?></th>
			<td><label><input type="checkbox" name="<?php echo esc_attr( $channel ); ?>_enabled" value="1" <?php checked( (bool) $values[ $channel . '_enabled' ] ); ?>> <?php esc_html_e( 'Ofrecer este canal y enviar por él', 'lachinata-core' ); ?></label></td>
		</tr>
		<tr>
			<th scope="row"><?php esc_html_e( 'Modo', 'lachinata-core' ); ?></th>
			<td>
				<fieldset>
					<label><input type="radio" name="<?php echo esc_attr( $channel ); ?>_mode" value="<?php echo esc_attr( Channel::LIVE ); ?>" <?php checked( Channel::LIVE, $values[ $channel . '_mode' ] ); ?>> <?php esc_html_e( 'Envío real', 'lachinata-core' ); ?></label><br>
					<label><input type="radio" name="<?php echo esc_attr( $channel ); ?>_mode" value="<?php echo esc_attr( Channel::LOG ); ?>" <?php checked( Channel::LOG, $values[ $channel . '_mode' ] ); ?>> <?php esc_html_e( 'Registro: no se envía, queda en WooCommerce → Estado → Registros (lachinata-notify). Para pruebas y staging.', 'lachinata-core' ); ?></label>
				</fieldset>
			</td>
		</tr>
		<?php
	}

	/**
	 * Settings section.
	 */
	private static function render_settings(): void {
		$module = Plugin::instance()->modules()->get( 'notify' );
		if ( null === $module ) {
			return;
		}
		$values  = Settings::all( $module );
		$service = new Service();
		$state   = static function ( string $channel ) use ( $service ): string {
			if ( $service->available( $channel ) ) {
				return __( 'Activo y listo: se ofrece en el checkout.', 'lachinata-core' );
			}
			return (bool) NotifyModule::setting( $channel . '_enabled' )
				? __( 'Activo pero sin todos sus datos: no se ofrece.', 'lachinata-core' )
				: __( 'Apagado: no se ofrece.', 'lachinata-core' );
		};
		?>
		<p><?php esc_html_e( 'Los avisos en corto del regalo (a quien lo recibe) y del envío (al comprador que lo pide). El checkout ofrece solo los canales activos y listos; con uno solo, no hay elección.', 'lachinata-core' ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE ); ?>">
			<?php wp_nonce_field( self::SAVE ); ?>

			<h2><?php esc_html_e( 'Correo', 'lachinata-core' ); ?></h2>
			<p class="description"><?php echo esc_html( $state( Notifier::EMAIL ) ); ?></p>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><?php esc_html_e( 'Activo', 'lachinata-core' ); ?></th>
					<td>
						<label><input type="checkbox" name="email_enabled" value="1" <?php checked( (bool) $values['email_enabled'] ); ?>> <?php esc_html_e( 'Ofrecer el aviso por correo a quien recibe un regalo', 'lachinata-core' ); ?></label>
						<p class="description"><?php esc_html_e( 'Sale por la salida de correo del sitio, con la plantilla del tema. Los correos de WooCommerce al comprador salen siempre.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
			</table>

			<h2><?php esc_html_e( 'WhatsApp (API de Meta)', 'lachinata-core' ); ?></h2>
			<p class="description"><?php echo esc_html( $state( Notifier::WHATSAPP ) ); ?></p>
			<table class="form-table" role="presentation">
				<?php
				self::switches( 'whatsapp', $values );
				self::field( 'wa_phone_number_id', __( 'ID de número', 'lachinata-core' ), $values, __( 'Phone number ID del número de la tienda en WhatsApp Manager → Números de teléfono (no es el número).', 'lachinata-core' ) );
				self::field( 'wa_business_account_id', __( 'ID de la cuenta de WhatsApp Business', 'lachinata-core' ), $values, __( 'WhatsApp Business Account ID, donde están las plantillas aprobadas.', 'lachinata-core' ) );
				self::field( 'wa_token', __( 'Token permanente', 'lachinata-core' ), $values, __( 'De un usuario del sistema con permiso whatsapp_business_messaging (Business Manager → Usuarios del sistema).', 'lachinata-core' ) );
				self::field( 'wa_app_secret', __( 'Clave secreta de la app', 'lachinata-core' ), $values, __( 'App secret de la app de Meta: firma los avisos de entrega que llegan al webhook.', 'lachinata-core' ) );
				self::field( 'wa_verify_token', __( 'Token de verificación del webhook', 'lachinata-core' ), $values, __( 'Una cadena que inventas aquí y escribes igual en Meta al dar de alta el webhook.', 'lachinata-core' ) );
				self::field( 'wa_api_version', __( 'Versión de la API', 'lachinata-core' ), $values, __( 'La de Graph API que tenga la app (v23.0, por ejemplo).', 'lachinata-core' ) );
				self::field( 'wa_language', __( 'Idioma de las plantillas', 'lachinata-core' ), $values, __( 'Código con el que se aprobaron (es).', 'lachinata-core' ) );
				self::field( 'wa_tpl_gift', __( 'Plantilla del regalo', 'lachinata-core' ), $values );
				self::field( 'wa_tpl_gift_nolink', __( 'Plantilla del regalo sin seguimiento', 'lachinata-core' ), $values );
				self::field( 'wa_tpl_shipped', __( 'Plantilla del envío', 'lachinata-core' ), $values );
				self::field( 'wa_tpl_shipped_nolink', __( 'Plantilla del envío sin seguimiento', 'lachinata-core' ), $values );
				?>
				<tr>
					<th scope="row"><?php esc_html_e( 'URL del webhook', 'lachinata-core' ); ?></th>
					<td>
						<code><?php echo esc_html( Webhook::url() ); ?></code>
						<p class="description"><?php esc_html_e( 'Pégala en la app de Meta → WhatsApp → Configuración → Webhook, con el token de verificación de arriba, y suscríbete al campo «messages». Sin ella no hay caída a SMS.', 'lachinata-core' ); ?></p>
					</td>
				</tr>
			</table>
			<p class="description">
				<?php
				$wa = Contact::get()['whatsapp'];
				echo esc_html(
					'' === $wa
						? __( 'El número de WhatsApp de la tienda se escribe en Atención al cliente; las respuestas de los clientes llegan a la misma conversación.', 'lachinata-core' )
						/* translators: %s: WhatsApp number of the shop. */
						: sprintf( __( 'Número de la tienda (Atención al cliente): %s. Debe ser el mismo que el del ID de número; las respuestas llegan a la misma conversación.', 'lachinata-core' ), $wa )
				);
				?>
			</p>

			<h2><?php esc_html_e( 'SMS (OVH)', 'lachinata-core' ); ?></h2>
			<p class="description"><?php echo esc_html( $state( Notifier::SMS ) ); ?></p>
			<table class="form-table" role="presentation">
				<?php self::switches( 'sms', $values ); ?>
				<tr>
					<th scope="row"><?php esc_html_e( 'Respaldo de WhatsApp', 'lachinata-core' ); ?></th>
					<td><label><input type="checkbox" name="sms_fallback" value="1" <?php checked( (bool) $values['sms_fallback'] ); ?>> <?php esc_html_e( 'Si WhatsApp no puede entregar un aviso (el número no tiene WhatsApp), mandarlo por SMS, una sola vez', 'lachinata-core' ); ?></label></td>
				</tr>
				<tr>
					<th scope="row"><label for="lc-notify-ovh_endpoint"><?php esc_html_e( 'API', 'lachinata-core' ); ?></label></th>
					<td>
						<select id="lc-notify-ovh_endpoint" name="ovh_endpoint">
							<?php foreach ( array_keys( Providers\OvhSmsProvider::ENDPOINTS ) as $endpoint ) : ?>
								<option value="<?php echo esc_attr( $endpoint ); ?>" <?php selected( $values['ovh_endpoint'], $endpoint ); ?>><?php echo esc_html( $endpoint ); ?></option>
							<?php endforeach; ?>
						</select>
					</td>
				</tr>
				<?php
				self::field( 'ovh_app_key', __( 'Application key', 'lachinata-core' ), $values );
				self::field( 'ovh_app_secret', __( 'Application secret', 'lachinata-core' ), $values );
				self::field( 'ovh_consumer_key', __( 'Consumer key', 'lachinata-core' ), $values );
				self::field( 'ovh_service', __( 'Servicio SMS', 'lachinata-core' ), $values, __( 'Nombre de la cuenta SMS en OVH, como sms-ab12345-1.', 'lachinata-core' ) );
				self::field( 'ovh_sender', __( 'Remitente', 'lachinata-core' ), $values, __( 'Remitente dado de alta y validado en esa cuenta (hasta 11 letras y números).', 'lachinata-core' ) );
				?>
			</table>
			<p class="description"><?php esc_html_e( 'Las credenciales se guardan solo en este sitio: no salen en la exportación de configuración.', 'lachinata-core' ); ?></p>
			<?php submit_button(); ?>
		</form>

		<h2><?php esc_html_e( 'Probar un canal', 'lachinata-core' ); ?></h2>
		<p class="description"><?php esc_html_e( 'WhatsApp envía la plantilla del envío sin seguimiento con datos de ejemplo (tiene que estar aprobada); el SMS, un texto corto. Se envía aunque el canal esté apagado, si tiene sus datos.', 'lachinata-core' ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::TEST ); ?>">
			<?php wp_nonce_field( self::TEST ); ?>
			<p>
				<label for="lc-notify-test"><?php esc_html_e( 'Móvil', 'lachinata-core' ); ?></label>
				<input type="tel" id="lc-notify-test" name="mobile" class="regular-text" placeholder="600 000 000" autocomplete="off">
				<button type="submit" class="button" name="channel" value="<?php echo esc_attr( Notifier::WHATSAPP ); ?>"><?php esc_html_e( 'Probar WhatsApp', 'lachinata-core' ); ?></button>
				<button type="submit" class="button" name="channel" value="<?php echo esc_attr( Notifier::SMS ); ?>"><?php esc_html_e( 'Probar SMS', 'lachinata-core' ); ?></button>
			</p>
		</form>
		<?php
	}

	/**
	 * Gaps section.
	 */
	private static function render_gaps(): void {
		$log = NotifyModule::gaps()->all();
		?>
		<h2><?php esc_html_e( 'Avisos que no salieron', 'lachinata-core' ); ?></h2>
		<p class="description"><?php esc_html_e( 'Un aviso que falla no bloquea el pedido: queda en su nota, aquí y en WooCommerce → Estado → Registros (lachinata-notify).', 'lachinata-core' ); ?></p>
		<?php if ( $log ) : ?>
			<table class="widefat striped">
				<thead><tr><th scope="col"><?php esc_html_e( 'Qué pasó', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Veces', 'lachinata-core' ); ?></th><th scope="col"><?php esc_html_e( 'Última', 'lachinata-core' ); ?></th></tr></thead>
				<tbody>
					<?php foreach ( $log as $entry ) : ?>
						<tr>
							<td><?php echo esc_html( $entry['message'] ); ?></td>
							<td><?php echo esc_html( number_format_i18n( $entry['count'] ) ); ?></td>
							<td><?php echo esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $entry['last'] ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="<?php echo esc_attr( self::CLEAR_GAPS ); ?>">
				<?php wp_nonce_field( self::CLEAR_GAPS ); ?>
				<?php submit_button( __( 'Vaciar la lista', 'lachinata-core' ), 'secondary' ); ?>
			</form>
		<?php else : ?>
			<p><?php esc_html_e( 'Ninguno registrado.', 'lachinata-core' ); ?></p>
		<?php endif; ?>
		<?php
	}

	/**
	 * Saves, tests or empties the gap log.
	 */
	public static function handle(): void {
		$action = (string) preg_replace( '/^admin_post_/', '', current_action() );
		Screen::check( $action );
		$module = Plugin::instance()->modules()->get( 'notify' );
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Screen::check().
		if ( self::SAVE === $action && null !== $module ) {
			foreach ( array( 'email_enabled', 'whatsapp_enabled', 'sms_enabled', 'sms_fallback' ) as $key ) {
				Settings::set( $module, $key, ! empty( $_POST[ $key ] ) );
			}
			foreach ( array( 'whatsapp_mode', 'sms_mode' ) as $key ) {
				$mode = isset( $_POST[ $key ] ) ? sanitize_key( wp_unslash( $_POST[ $key ] ) ) : Channel::LIVE;
				Settings::set( $module, $key, Channel::LOG === $mode ? Channel::LOG : Channel::LIVE );
			}
			$endpoint = isset( $_POST['ovh_endpoint'] ) ? sanitize_key( wp_unslash( $_POST['ovh_endpoint'] ) ) : 'ovh-eu';
			Settings::set( $module, 'ovh_endpoint', isset( Providers\OvhSmsProvider::ENDPOINTS[ $endpoint ] ) ? $endpoint : 'ovh-eu' );
			foreach ( self::TEXTS as $key ) {
				$value = isset( $_POST[ $key ] ) ? trim( sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) ) : '';
				if ( '' === $value && in_array( $key, self::SECRETS, true ) ) {
					continue;
				}
				Settings::set( $module, $key, $value );
			}
			Screen::flash( 'success', array( __( 'Ajustes guardados.', 'lachinata-core' ) ) );
			Screen::redirect( self::TAB, array( 'section' => 'settings' ) );
		}
		if ( self::TEST === $action ) {
			$channel = isset( $_POST['channel'] ) ? sanitize_key( wp_unslash( $_POST['channel'] ) ) : '';
			$mobile  = Phone::normalize( isset( $_POST['mobile'] ) ? sanitize_text_field( wp_unslash( $_POST['mobile'] ) ) : '', 'ES' );
			Screen::flash( ...self::test( $channel, $mobile ) );
			Screen::redirect( self::TAB, array( 'section' => 'settings' ) );
		}
		// phpcs:enable
		NotifyModule::gaps()->clear();
		Screen::flash( 'success', array( __( 'Lista vaciada.', 'lachinata-core' ) ) );
		Screen::redirect( self::TAB, array( 'section' => 'gaps' ) );
	}

	/**
	 * Sends a test and says how it went.
	 *
	 * @param string      $channel whatsapp or sms.
	 * @param string|null $mobile  Mobile in international format.
	 * @return array{0: string, 1: string[]} Type and message for Screen::flash().
	 */
	public static function test( string $channel, ?string $mobile ): array {
		if ( null === $mobile ) {
			return array( 'error', array( __( 'Escribe un móvil válido, con el prefijo si no es de España.', 'lachinata-core' ) ) );
		}
		$service = new Service();
		try {
			if ( Notifier::WHATSAPP === $channel ) {
				$provider = $service->whatsapp_provider();
				$provider->send_template(
					$mobile,
					$service->template( Notice::SHIPPED, false ),
					(string) NotifyModule::setting( 'wa_language' ),
					array( __( 'Alberto', 'lachinata-core' ), '48213', __( 'jue 24 – vie 25 oct', 'lachinata-core' ), __( 'Correos Express', 'lachinata-core' ) )
				);
			} else {
				$provider = $service->sms_provider();
				/* translators: %s: shop name. */
				$provider->send_sms( $mobile, sprintf( __( 'Prueba de los avisos de %s. Si lo lees, los SMS funcionan.', 'lachinata-core' ), (string) get_bloginfo( 'name' ) ) );
			}
		} catch ( \Throwable $error ) {
			/* translators: %s: reason. */
			return array( 'error', array( sprintf( __( 'No se pudo enviar la prueba: %s', 'lachinata-core' ), $error->getMessage() ) ) );
		}
		/* translators: 1: channel name, 2: provider name, 3: masked mobile. */
		return array( 'success', array( sprintf( __( 'Prueba por %1$s enviada (%2$s) a %3$s.', 'lachinata-core' ), Channel::label( $channel ), $provider->label(), Providers\LogProvider::mask( $mobile ) ) ) );
	}
}
