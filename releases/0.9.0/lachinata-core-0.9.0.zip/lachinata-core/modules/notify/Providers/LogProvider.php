<?php
/**
 * «Registro»: notices written to the log instead of sent.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Notify\Providers;

defined( 'ABSPATH' ) || exit;

/**
 * The channel in «registro» mode (local, staging, the end-to-end tests): every notice goes to
 * WooCommerce → Estado → Registros (lachinata-notify) with the mobile masked, and to
 * `$sent` for the tests.
 */
final class LogProvider implements SmsProvider, WhatsAppProvider {

	/**
	 * What was «sent» in this request.
	 *
	 * @var array<int, array{channel: string, to: string, message: string, template: string, params: string[], button: string}>
	 */
	public static array $sent = array();

	/**
	 * Identifier.
	 */
	public function id(): string {
		return 'log';
	}

	/**
	 * Name for the admin screen.
	 */
	public function label(): string {
		return __( 'Registro (no se envía)', 'lachinata-core' );
	}

	/**
	 * Logs an SMS.
	 *
	 * @param string $to      Mobile.
	 * @param string $message Text.
	 */
	public function send_sms( string $to, string $message ): string {
		return $this->log( 'sms', $to, $message, '', array(), '' );
	}

	/**
	 * Logs a template.
	 *
	 * @param string   $to       Mobile.
	 * @param string   $template Template.
	 * @param string   $language Language.
	 * @param string[] $params   Variables.
	 * @param string   $button   Button variable.
	 */
	public function send_template( string $to, string $template, string $language, array $params, string $button = '' ): string {
		unset( $language );
		return $this->log( 'whatsapp', $to, '', $template, $params, $button );
	}

	/**
	 * Keeps and logs a notice.
	 *
	 * @param string   $channel  Channel.
	 * @param string   $to       Mobile.
	 * @param string   $message  SMS text.
	 * @param string   $template Template.
	 * @param string[] $params   Variables.
	 * @param string   $button   Button variable.
	 */
	private function log( string $channel, string $to, string $message, string $template, array $params, string $button ): string {
		self::$sent[] = array(
			'channel'  => $channel,
			'to'       => $to,
			'message'  => $message,
			'template' => $template,
			'params'   => array_values( $params ),
			'button'   => $button,
		);
		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->info(
				'whatsapp' === $channel
					? sprintf( 'WhatsApp (registro) a %1$s: %2$s %3$s%4$s', self::mask( $to ), $template, (string) wp_json_encode( array_values( $params ), JSON_UNESCAPED_UNICODE ), '' === $button ? '' : ' [botón ' . $button . ']' )
					: sprintf( 'SMS (registro) a %1$s: %2$s', self::mask( $to ), $message ),
				array( 'source' => 'lachinata-notify' )
			);
		}
		// Unique across requests: the webhook finds orders by reference.
		return 'log-' . $channel . '-' . strtolower( wp_generate_password( 10, false ) );
	}

	/**
	 * «+34600•••233»: the mobile in notes and logs.
	 *
	 * @param string $number Mobile.
	 */
	public static function mask( string $number ): string {
		return strlen( $number ) > 6 ? substr( $number, 0, -6 ) . '•••' . substr( $number, -3 ) : '•••';
	}
}
