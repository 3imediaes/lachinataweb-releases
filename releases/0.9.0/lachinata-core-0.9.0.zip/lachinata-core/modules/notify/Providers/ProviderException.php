<?php
/**
 * A notice the provider did not accept.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Notify\Providers;

defined( 'ABSPATH' ) || exit;

/**
 * The message is for people (it goes to the order note and the gap log); the code is the
 * provider's (131026 is Meta's «no entregable»).
 */
final class ProviderException extends \RuntimeException {

	/**
	 * Builds the exception.
	 *
	 * @param string $message       Why, for people.
	 * @param int    $provider_code Provider's error code, 0 when there is none.
	 */
	public function __construct( string $message, public readonly int $provider_code = 0 ) {
		parent::__construct( $message );
	}
}
