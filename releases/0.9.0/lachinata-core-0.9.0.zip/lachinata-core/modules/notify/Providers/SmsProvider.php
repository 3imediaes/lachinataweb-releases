<?php
/**
 * Sends an SMS.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Notify\Providers;

defined( 'ABSPATH' ) || exit;

/**
 * Register another provider with `lachinata/notify/sms_provider`.
 */
interface SmsProvider {

	/**
	 * Identifier (`log`, `ovh`…).
	 */
	public function id(): string;

	/**
	 * Name for the admin screen.
	 */
	public function label(): string;

	/**
	 * Sends a message.
	 *
	 * @param string $to      Mobile in international format (+34600000000).
	 * @param string $message Text (at most two segments).
	 * @return string Provider reference of the message.
	 * @throws ProviderException When it could not be sent.
	 */
	public function send_sms( string $to, string $message ): string;
}
