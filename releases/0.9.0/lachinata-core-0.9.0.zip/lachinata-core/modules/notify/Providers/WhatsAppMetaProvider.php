<?php
/**
 * WhatsApp through Meta's Cloud API.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Notify\Providers;

defined( 'ABSPATH' ) || exit;

/**
 * `POST https://graph.facebook.com/{version}/{phone-number-id}/messages` with a permanent
 * token of a system user: a `template` message with the body variables and, when the
 * notice carries the short link, the variable of the URL button
 * (`https://{dominio}/s/{{1}}`). Meta answers with the message id (`wamid…`); what happens
 * to it after (delivered, read, failed) comes to the webhook (Webhook). The shop's number
 * (ID de número) and its WhatsApp Business account are set in the panel; nothing is kept in
 * the repository.
 */
final class WhatsAppMetaProvider implements WhatsAppProvider {

	/**
	 * Graph API base.
	 */
	public const API = 'https://graph.facebook.com';

	/**
	 * Builds the provider.
	 *
	 * @param string $phone_number_id ID de número (Phone number ID) of the shop's number.
	 * @param string $token           Permanent token of a system user with whatsapp_business_messaging.
	 * @param string $version         Graph API version (v23.0).
	 */
	public function __construct(
		private string $phone_number_id,
		private string $token,
		private string $version,
	) {}

	/**
	 * Identifier.
	 */
	public function id(): string {
		return 'meta';
	}

	/**
	 * Name for the admin screen.
	 */
	public function label(): string {
		return __( 'WhatsApp (API de Meta)', 'lachinata-core' );
	}

	/**
	 * Whether the number and the token are there.
	 */
	public function configured(): bool {
		return '' !== $this->phone_number_id && '' !== $this->token;
	}

	/**
	 * Sends a template.
	 *
	 * @param string   $to       Mobile in international format.
	 * @param string   $template Template name.
	 * @param string   $language Language code.
	 * @param string[] $params   Body variables.
	 * @param string   $button   URL button variable, or ''.
	 * @throws ProviderException When Meta refuses it or cannot be reached.
	 */
	public function send_template( string $to, string $template, string $language, array $params, string $button = '' ): string {
		if ( ! $this->configured() ) {
			throw new ProviderException( esc_html__( 'Faltan el ID de número o el token de WhatsApp.', 'lachinata-core' ) );
		}
		$response = wp_remote_post(
			self::API . '/' . rawurlencode( $this->version ) . '/' . rawurlencode( $this->phone_number_id ) . '/messages',
			array(
				'timeout' => 10,
				'headers' => array(
					'Authorization' => 'Bearer ' . $this->token,
					'Content-Type'  => 'application/json',
				),
				'body'    => (string) wp_json_encode( self::payload( $to, $template, $language, $params, $button ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
			)
		);
		if ( is_wp_error( $response ) ) {
			/* translators: %s: error message. */
			throw new ProviderException( esc_html( sprintf( __( 'No se pudo conectar con WhatsApp: %s', 'lachinata-core' ), $response->get_error_message() ) ) );
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		$data = is_array( $data ) ? $data : array();
		$id   = (string) ( $data['messages'][0]['id'] ?? '' );
		if ( $code >= 200 && $code < 300 && '' !== $id ) {
			return $id;
		}
		$error = is_array( $data['error'] ?? null ) ? $data['error'] : array();
		$text  = (string) ( $error['error_data']['details'] ?? $error['message'] ?? '' );
		throw new ProviderException(
			/* translators: 1: HTTP status, 2: Meta's error code, 3: Meta's message. */
			esc_html( sprintf( __( 'WhatsApp respondió %1$d (código %2$s): %3$s', 'lachinata-core' ), $code, (string) ( $error['code'] ?? '—' ), $text ) ),
			(int) ( $error['code'] ?? 0 )
		);
	}

	/**
	 * Body of the request.
	 *
	 * @param string   $to       Mobile.
	 * @param string   $template Template.
	 * @param string   $language Language.
	 * @param string[] $params   Body variables.
	 * @param string   $button   URL button variable, or ''.
	 * @return array<string, mixed>
	 */
	public static function payload( string $to, string $template, string $language, array $params, string $button = '' ): array {
		$components = array();
		if ( $params ) {
			$components[] = array(
				'type'       => 'body',
				'parameters' => array_map(
					static fn( $text ): array => array(
						'type' => 'text',
						'text' => (string) $text,
					),
					array_values( $params )
				),
			);
		}
		if ( '' !== $button ) {
			$components[] = array(
				'type'       => 'button',
				'sub_type'   => 'url',
				'index'      => '0',
				'parameters' => array(
					array(
						'type' => 'text',
						'text' => $button,
					),
				),
			);
		}
		$message = array(
			'messaging_product' => 'whatsapp',
			'recipient_type'    => 'individual',
			'to'                => ltrim( $to, '+' ),
			'type'              => 'template',
			'template'          => array(
				'name'     => $template,
				'language' => array( 'code' => $language ),
			),
		);
		if ( $components ) {
			$message['template']['components'] = $components;
		}
		return $message;
	}
}
