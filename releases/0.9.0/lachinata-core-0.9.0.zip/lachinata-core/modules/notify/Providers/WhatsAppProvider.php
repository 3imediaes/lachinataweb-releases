<?php
/**
 * Sends an approved WhatsApp template.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Notify\Providers;

defined( 'ABSPATH' ) || exit;

/**
 * When the shop writes first, WhatsApp only accepts templates approved by Meta: a fixed text
 * with variables. Register another provider with `lachinata/notify/whatsapp_provider`.
 */
interface WhatsAppProvider {

	/**
	 * Identifier (`log`, `meta`…).
	 */
	public function id(): string;

	/**
	 * Name for the admin screen.
	 */
	public function label(): string;

	/**
	 * Sends a template.
	 *
	 * @param string   $to       Mobile in international format (+34600000000).
	 * @param string   $template Template name (lc_regalo_aviso…).
	 * @param string   $language Language code of the template (es).
	 * @param string[] $params   Variables of the body, {{1}} first.
	 * @param string   $button   Variable of the URL button (the short link's token), or ''.
	 * @return string Message id (`wamid…`).
	 * @throws ProviderException When it could not be sent.
	 */
	public function send_template( string $to, string $template, string $language, array $params, string $button = '' ): string;
}
