# Módulo `notify`

Avisos en corto por **WhatsApp** (canal principal, API de Meta con plantillas aprobadas, desde el número de la tienda) y **SMS** (OVH, respaldo), compartidos por `gift` (aviso a quien recibe un regalo) y `shipment` (aviso al comprador cuando sale el pedido). Cada canal se activa y configura por tienda; el checkout solo ofrece los activos y listos.

Especificación: `design-system/sistema/06-correos.md` («Avisos por WhatsApp y SMS»), `03-implementacion.md` (tabla de módulos), `04-envios-entrega.md` («Regalos»). Decisiones: `design-system/docs/decisiones.md` (incremento 6). Plantillas para Meta: `docs/whatsapp-plantillas.md`. Paso a producción: `docs/despliegue-notify-tracking.md`. Ajustes: WooCommerce → La Chinata → Avisos.

## Qué hace
| Pieza | Cómo | Dónde |
| --- | --- | --- |
| Servicio de avisos para los demás módulos | Interfaz del núcleo `Contracts\Notifier` (`channels()`, `available()`, `send()`, `short_link()`, `forget()`), servida con el filtro `lachinata/notify/service`; los módulos la piden con `Services::notifier()` y comprueban que existe. Ningún módulo usa clases de `notify` | `Service.php`, `plugin/src/Contracts/` |
| Canales: correo, WhatsApp y SMS, cada uno con su interruptor. WhatsApp y SMS con modo **Envío real** o **Registro** (no se envía: va a WooCommerce → Estado → Registros, `lachinata-notify`, con el móvil enmascarado). En real, un canal sin sus datos no se ofrece | `Service::available()` | `Channel.php`, `Service.php` |
| El canal «correo» solo dice si un módulo puede escribir a un tercero (el destinatario de un regalo); el correo lo envía el módulo con su `WC_Email` y la plantilla del tema. Los correos de WooCommerce al comprador salen siempre | — | — |
| WhatsApp por la **Cloud API**: `POST graph.facebook.com/{versión}/{ID de número}/messages`, mensaje `template` con las variables del cuerpo, idioma `es` y, con seguimiento, la variable del botón de URL (la ficha del enlace corto). Ninguna variable vacía llega a Meta | `wp_remote_post`, token permanente de usuario del sistema | `Providers/WhatsAppMetaProvider.php` |
| SMS por **OVH** (`POST /sms/{serviceName}/jobs`, petición firmada con la hora de OVH, UCS-2 con acentos, `noStopClause`), movido de `gift` | `wp_remote_request` | `Providers/OvhSmsProvider.php` |
| Plantilla por aviso y por si lleva enlace: `lc_regalo_aviso(_sin_enlace)`, `lc_pedido_enviado(_sin_enlace)` (nombres en el panel) | `Service::template()`, filtro `lachinata/notify/template` para otros avisos | `Service.php` |
| Registro de cada aviso en el pedido: tipo, canal, móvil, texto del SMS, estado y referencia del SMS que salió en su lugar | `_lc_notify` (por referencia) y `_lc_notify_ref` (una fila por referencia, para buscar el pedido) | `Messages.php` |
| **Caída a SMS, una sola vez**: si Meta rechaza el número como no entregable (131026) al enviar, o lo devuelve así el webhook, y el SMS está activo con «Respaldo de WhatsApp», el aviso sale por SMS con su texto. Se marca antes de enviar para que un estado repetido no mande dos SMS. Otros errores no caen: hueco de configuración | `Service::send()`, `Service::fall_back()`; acción `lachinata/notify/fallback` | `Service.php`, `Webhook.php` |
| **Webhook** `/wp-json/lachinata/v1/notify/whatsapp`: GET responde el reto de Meta con el token de verificación; POST exige la firma `X-Hub-Signature-256` (HMAC-SHA256 del cuerpo con la clave secreta de la app): sin ella, 401. Guarda el estado (`sent`, `delivered`, `read`, `failed`) y avisa con `lachinata/notify/status`. Los mensajes de clientes se ignoran (se contestan en la app de la tienda) | REST, `rest_pre_serve_request` para devolver el reto en texto | `Webhook.php` |
| **Enlace corto** `lachinata.es/s/7Kq2xm`, uno por pedido y compartido por el regalo y el envío: redirige al último seguimiento del transportista, nunca al pedido. Lee también la ficha de la 0.7.0 (`_lc_regalo_enlace`) | `parse_request`, sin reglas de reescritura; seguimiento del núcleo (`Tracking\Tracking`) | `ShortLink.php` |
| Datos personales: `forget()` vacía el móvil y el texto de los avisos de un tipo (el regalo, a los 30 días de la entrega); el registro se queda sin ellos | Lo llama `gift` desde su borrado | `Messages.php` |
| Panel Avisos: un bloque por canal (interruptor, modo, credenciales, plantillas, URL del webhook), «Probar WhatsApp» (plantilla del envío sin enlace con datos de ejemplo) y «Probar SMS», y los avisos que no salieron | `admin-post.php` | `NotifyTab.php` |
| Al actualizar a la 0.8.0: `notify` se enciende donde estaba `gift` y las credenciales de OVH pasan de `lachinata_gift_ovh_*` a `lachinata_notify_ovh_*` (el SMS queda activo si estaban completas). No se borra nada | `LaChinata\Core\Upgrades::to_0_8_0()` | `plugin/src/Upgrades.php` |

## Depende de

Ningún módulo. WooCommerce 10. Sirve a `gift` y `shipment` por `Contracts\Notifier`; ninguno de ellos usa sus clases.

## Hooks que escucha

- `lachinata/notify/service` (lo sirve), `lachinata/core/admin_tabs` (pestaña Avisos).
- `rest_api_init` (webhook), `rest_pre_serve_request` (reto de Meta en texto) y `parse_request` (enlace corto `/s/<token>`).

## Hooks que emite

| Hook | Tipo | Para qué |
| --- | --- | --- |
| `lachinata/notify/whatsapp_provider`, `lachinata/notify/sms_provider` | filtro | Otro proveedor (interfaces `Providers\WhatsAppProvider`, `Providers\SmsProvider`) |
| `lachinata/notify/template` | filtro | Plantilla de otros tipos de aviso |
| `lachinata/notify/status` `( WC_Order, string $kind, string $state, string $reason )` | acción | Un WhatsApp cambió de estado |
| `lachinata/notify/fallback` `( WC_Order, string $kind, NoticeResult )` | acción | Un WhatsApp no entregable salió (o no) por SMS |

`lachinata/gift/sms_provider` quedó obsoleto en la 0.8.0 y ya no existe. Catálogo con versiones: `plugin/HOOKS.md`.

## Datos que guarda

- Metadatos de pedido: `_lc_notify` (avisos por referencia), `_lc_notify_ref` (una fila por referencia), `_lc_enlace` (enlace corto). Lee `_lc_regalo_enlace` (enlace de la 0.7.0).
- Opciones `lachinata_notify_*`: los ajustes de abajo y su registro de huecos (`lachinata_notify_gaps`).

## REST y API para Odoo

- `GET`/`POST /wp-json/lachinata/v1/notify/whatsapp`: el webhook de Meta (arriba).
- Nada en el objeto `lachinata` de la API de pedidos.

## Ajustes y exportación
| Ajuste | Por defecto | En el JSON |
| --- | --- | --- |
| Correo activo (`email_enabled`) | sí | sí |
| WhatsApp activo y modo (`whatsapp_enabled`, `whatsapp_mode`) | no · real | sí |
| ID de número, ID de la cuenta de WhatsApp Business, token permanente, clave secreta de la app, token de verificación (`wa_*`) | vacíos | **no** |
| Versión de Graph API (`wa_api_version`), idioma (`wa_language`) | `v23.0`, `es` | sí |
| Nombres de plantilla (`wa_tpl_*`) | los de `docs/whatsapp-plantillas.md` | sí |
| SMS activo y modo (`sms_enabled`, `sms_mode`), respaldo de WhatsApp (`sms_fallback`) | no · real · sí | sí |
| API de OVH (`ovh_endpoint`) | `ovh-eu` | sí |
| Credenciales y remitente de OVH (`ovh_*`) | vacíos | **no** |

Las credenciales no se vuelven a mostrar; un campo vacío al guardar las conserva. El número de WhatsApp que se muestra al cliente («¿Alguna duda?», pie de la web) es el de **Atención al cliente** (núcleo), que debe coincidir con el del ID de número.

## Qué pasa al apagarlo

`Services::notifier()` devuelve `null`: `gift` solo ofrece el aviso por correo (o «No avisar») y `shipment` no ofrece ni manda el WhatsApp; los correos salen igual. El enlace corto `/s/<token>` deja de redirigir (404). Como `gift` necesita `notify`, apagar `notify` apaga también el regalo hasta que se vuelva a encender. Credenciales, plantillas y registro de avisos se quedan; «Borrar datos» quita los ajustes y nunca los metadatos de los pedidos.

## Pruebas
- `tests/NotifyTest.php`: canales activos y listos (sin token no se ofrece; «registro» sin credenciales), plantilla con variables, idioma y botón a la API simulada, variable vacía que no sale, caída a SMS al enviar (131026) y no con otro error ni con el respaldo apagado, firma del webhook, caída a SMS desde el webhook una sola vez aunque Meta repita el estado, petición mal firmada (401), otro fallo solo anotado, estado entregado, reto de verificación, enlace corto compartido y el de la 0.7.0, olvido del móvil, actualización de la 0.8.0.
- `tests/OvhSmsProviderTest.php`: firma, cabeceras y cuerpo con el cliente HTTP simulado, UCS-2, errores, credenciales que hacen falta y fuera de la exportación.
- e2e: el aviso por WhatsApp en modo registro en `tests/e2e/gift.spec.mjs`.

- La pareja real `gift` + `notify` y `shipment` + `notify` (plantillas, enlace corto, proveedor que falla): `tests/profiles/GiftNotifyTest.php` y `ShipmentNotifyTest.php`. Los módulos que lo usan se prueban con un doble del contrato (`plugin/tests/Doubles/FakeNotifier.php`).

## Huecos conocidos

- Número de WhatsApp, WABA, app con token permanente, webhook y las cuatro plantillas aprobadas en Meta: pendiente de Alberto antes de activar el canal (`docs/whatsapp-plantillas.md`).
- Credenciales y remitente de OVH en el panel de cada sitio.
