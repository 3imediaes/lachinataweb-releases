<?php
/**
 * The notifier of the site.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Notify;

use LaChinata\Core\Contracts\Notice;
use LaChinata\Core\Contracts\NoticeResult;
use LaChinata\Core\Contracts\Notifier;

defined( 'ABSPATH' ) || exit;

/**
 * Contracts\Notifier: which channels are on, the providers behind them (Meta, OVH or
 * «registro»), the template of each notice, the record of what left and the fallback to
 * SMS, once, when WhatsApp cannot deliver a notice.
 */
final class Service implements Notifier {

	/**
	 * Meta's error codes that mean the number cannot get the message (no WhatsApp,
	 * undeliverable): the notice may go by SMS instead.
	 */
	public const UNDELIVERABLE = array( 131026 );

	/**
	 * Channels active and configured.
	 *
	 * @return string[]
	 */
	public function channels(): array {
		return array_values( array_filter( Channel::ALL, array( $this, 'available' ) ) );
	}

	/**
	 * Whether a channel is active and configured.
	 *
	 * @param string $channel Channel.
	 */
	public function available( string $channel ): bool {
		switch ( $channel ) {
			case self::EMAIL:
				return (bool) NotifyModule::setting( 'email_enabled' );
			case self::WHATSAPP:
				return (bool) NotifyModule::setting( 'whatsapp_enabled' ) && $this->whatsapp_ready();
			case self::SMS:
				return (bool) NotifyModule::setting( 'sms_enabled' ) && $this->sms_ready();
		}
		return false;
	}

	/**
	 * Whether WhatsApp can send: «registro», or the number and the token.
	 */
	public function whatsapp_ready(): bool {
		$provider = $this->whatsapp_provider();
		return ! $provider instanceof Providers\WhatsAppMetaProvider || $provider->configured();
	}

	/**
	 * Whether SMS can send: «registro», or the OVH credentials.
	 */
	public function sms_ready(): bool {
		$provider = $this->sms_provider();
		return ! $provider instanceof Providers\OvhSmsProvider || $provider->configured();
	}

	/**
	 * WhatsApp provider: Meta, or the log in «registro» mode.
	 */
	public function whatsapp_provider(): Providers\WhatsAppProvider {
		$provider = Channel::LOG === NotifyModule::setting( 'whatsapp_mode' )
			? new Providers\LogProvider()
			: new Providers\WhatsAppMetaProvider(
				(string) NotifyModule::setting( 'wa_phone_number_id' ),
				(string) NotifyModule::setting( 'wa_token' ),
				(string) NotifyModule::setting( 'wa_api_version' )
			);
		/**
		 * WhatsApp provider of the notices.
		 *
		 * @since 0.8.0
		 *
		 * @param Providers\WhatsAppProvider $provider Meta, or «registro».
		 */
		$filtered = apply_filters( 'lachinata/notify/whatsapp_provider', $provider );
		return $filtered instanceof Providers\WhatsAppProvider ? $filtered : $provider;
	}

	/**
	 * SMS provider: OVH, or the log in «registro» mode.
	 */
	public function sms_provider(): Providers\SmsProvider {
		$provider = Channel::LOG === NotifyModule::setting( 'sms_mode' )
			? new Providers\LogProvider()
			: new Providers\OvhSmsProvider(
				(string) NotifyModule::setting( 'ovh_app_key' ),
				(string) NotifyModule::setting( 'ovh_app_secret' ),
				(string) NotifyModule::setting( 'ovh_consumer_key' ),
				(string) NotifyModule::setting( 'ovh_service' ),
				(string) NotifyModule::setting( 'ovh_sender' ),
				(string) NotifyModule::setting( 'ovh_endpoint' )
			);
		/**
		 * SMS provider of the notices (Twilio, Vonage… instead of OVH).
		 *
		 * @since 0.8.0
		 *
		 * @param Providers\SmsProvider $provider OVH, or «registro».
		 */
		$filtered = apply_filters( 'lachinata/notify/sms_provider', $provider );
		return $filtered instanceof Providers\SmsProvider ? $filtered : $provider;
	}

	/**
	 * Name of the WhatsApp template of a notice.
	 *
	 * @param string $kind Notice kind.
	 * @param bool   $link With the link button.
	 */
	public function template( string $kind, bool $link ): string {
		$key  = array(
			Notice::GIFT    => 'wa_tpl_gift',
			Notice::SHIPPED => 'wa_tpl_shipped',
		)[ $kind ] ?? '';
		$name = '' === $key ? '' : (string) NotifyModule::setting( $link ? $key : $key . '_nolink' );
		/**
		 * WhatsApp template of a kind of notice (for kinds other modules add).
		 *
		 * @since 0.8.0
		 *
		 * @param string $name Template name.
		 * @param string $kind Notice kind.
		 * @param bool   $link With the URL button.
		 */
		return (string) apply_filters( 'lachinata/notify/template', $name, $kind, $link );
	}

	/**
	 * Sends a notice.
	 *
	 * @param string $channel WHATSAPP or SMS.
	 * @param Notice $notice  Notice.
	 */
	public function send( string $channel, Notice $notice ): NoticeResult {
		if ( ! in_array( $channel, array( self::WHATSAPP, self::SMS ), true ) || ! $this->available( $channel ) ) {
			/* translators: %s: channel name. */
			return $this->failed( $notice, $channel, sprintf( __( 'el canal %s no está activo o le faltan datos en Avisos', 'lachinata-core' ), Channel::label( $channel ) ) );
		}
		if ( self::SMS === $channel ) {
			return $this->send_sms( $notice, false );
		}

		$template = $this->template( $notice->kind, $notice->link );
		if ( '' === $template || in_array( '', array_map( 'strval', $notice->params ), true ) ) {
			return $this->failed( $notice, $channel, __( 'falta la plantilla de WhatsApp o alguna de sus variables', 'lachinata-core' ) );
		}
		try {
			$ref = $this->whatsapp_provider()->send_template(
				$notice->to,
				$template,
				(string) NotifyModule::setting( 'wa_language' ),
				$notice->params,
				$notice->link ? ShortLink::token( $notice->order ) : ''
			);
		} catch ( Providers\ProviderException $error ) {
			if ( in_array( $error->provider_code, self::UNDELIVERABLE, true ) && $this->may_fall_back() ) {
				return $this->send_sms( $notice, true );
			}
			return $this->failed( $notice, $channel, $error->getMessage() );
		} catch ( \Throwable $error ) {
			return $this->failed( $notice, $channel, $error->getMessage() );
		}
		Messages::add( $notice->order, $ref, $notice->kind, self::WHATSAPP, $notice->to, $notice->sms );
		return new NoticeResult( self::WHATSAPP, true, $ref );
	}

	/**
	 * Whether an undeliverable WhatsApp may go by SMS.
	 */
	public function may_fall_back(): bool {
		return (bool) NotifyModule::setting( 'sms_fallback' ) && $this->available( self::SMS );
	}

	/**
	 * Sends the SMS of a notice.
	 *
	 * @param Notice $notice   Notice.
	 * @param bool   $fallback Instead of a WhatsApp that could not be delivered.
	 */
	private function send_sms( Notice $notice, bool $fallback ): NoticeResult {
		if ( '' === $notice->sms ) {
			return $this->failed( $notice, self::SMS, __( 'el aviso no tiene texto de SMS', 'lachinata-core' ) );
		}
		try {
			$ref = $this->sms_provider()->send_sms( $notice->to, $notice->sms );
		} catch ( \Throwable $error ) {
			return $this->failed( $notice, self::SMS, $error->getMessage() );
		}
		Messages::add( $notice->order, $ref, $notice->kind, self::SMS, $notice->to, $notice->sms );
		return new NoticeResult( self::SMS, true, $ref, '', $fallback );
	}

	/**
	 * Falls back to SMS for a WhatsApp that Meta reports as undeliverable, once.
	 *
	 * @param \WC_Order $order Order.
	 * @param string    $ref   Reference of the WhatsApp message.
	 */
	public function fall_back( \WC_Order $order, string $ref ): ?NoticeResult {
		$record = Messages::of( $order )[ $ref ] ?? null;
		if ( null === $record || self::WHATSAPP !== $record['channel'] || '' !== $record['fallback'] || '' === $record['to'] || '' === $record['sms'] || ! $this->may_fall_back() ) {
			return null;
		}
		// Marked first: a status that arrives twice must not send two SMS.
		Messages::update( $order, $ref, array( 'fallback' => 'pending' ) );
		$notice = new Notice( $record['kind'], $order, $record['to'], array(), false, $record['sms'], 'notify' );
		$result = $this->send_sms( $notice, true );
		Messages::update( $order, $ref, array( 'fallback' => $result->ok ? $result->ref : 'failed' ) );
		return $result;
	}

	/**
	 * Short link of an order.
	 *
	 * @param \WC_Order $order Order.
	 */
	public function short_link( \WC_Order $order ): string {
		return ShortLink::for_order( $order );
	}

	/**
	 * Forgets the mobile and texts of a kind of notice.
	 *
	 * @param \WC_Order $order Order.
	 * @param string    $kind  Kind.
	 */
	public function forget( \WC_Order $order, string $kind ): void {
		Messages::forget( $order, $kind );
	}

	/**
	 * A notice that did not leave: gap log and result.
	 *
	 * @param Notice $notice  Notice.
	 * @param string $channel Channel.
	 * @param string $why     Reason.
	 */
	private function failed( Notice $notice, string $channel, string $why ): NoticeResult {
		NotifyModule::gaps()->record(
			'send|' . $channel . '|' . md5( $why ),
			/* translators: 1: channel, 2: reason. */
			sprintf( __( 'Un aviso por %1$s no salió: %2$s.', 'lachinata-core' ), Channel::label( $channel ), $why ),
			array(
				'order'  => $notice->order->get_id(),
				'source' => $notice->source,
			)
		);
		return new NoticeResult( $channel, false, '', $why );
	}
}
