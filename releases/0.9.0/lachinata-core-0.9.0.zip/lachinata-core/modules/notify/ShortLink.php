<?php
/**
 * Short link of the notices: /s/<token>.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Notify;

use LaChinata\Core\Hooks;
use LaChinata\Core\Orders;
use LaChinata\Core\Tracking\Tracking;

defined( 'ABSPATH' ) || exit;

/**
 * An SMS has no room for a carrier's tracking URL, and the URL button of a WhatsApp
 * template is fixed to the shop's domain: both carry `lachinata.es/s/7Kq2xm`, a random token
 * kept on the order that redirects to the latest tracking link. One token per order, shared
 * by the gift's notice and the buyer's. It leads only to the carrier, never to the order (a
 * gift's recipient must not see prices nor the buyer's data). No rewrite rule: the path is
 * read on `parse_request`, so nothing needs flushing.
 */
final class ShortLink {

	/**
	 * Order meta with the token.
	 */
	public const META = '_lc_enlace';

	/**
	 * Meta of 0.7.0, when only the gift had a short link: still read.
	 */
	public const LEGACY_META = '_lc_regalo_enlace';

	/**
	 * Token length and alphabet (no look-alike characters).
	 */
	public const LENGTH    = 6;
	private const ALPHABET = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'parse_request', array( self::class, 'resolve' ), 1 );
	}

	/**
	 * Token of an order (created the first time).
	 *
	 * @param \WC_Order $order Order.
	 */
	public static function token( \WC_Order $order ): string {
		foreach ( array( self::META, self::LEGACY_META ) as $key ) {
			$token = (string) $order->get_meta( $key );
			if ( self::valid( $token ) ) {
				return $token;
			}
		}
		$token = '';
		for ( $i = 0; $i < self::LENGTH; $i++ ) {
			$token .= self::ALPHABET[ random_int( 0, strlen( self::ALPHABET ) - 1 ) ];
		}
		$order->update_meta_data( self::META, $token );
		$order->save_meta_data();
		return $token;
	}

	/**
	 * Short link of an order, without scheme: «lachinata.es/s/7Kq2xm».
	 *
	 * @param \WC_Order $order Order.
	 */
	public static function for_order( \WC_Order $order ): string {
		return (string) preg_replace( '#^https?://#', '', home_url( '/s/' . self::token( $order ) ) );
	}

	/**
	 * Whether a text has the shape of a token.
	 *
	 * @param string $token Text.
	 */
	public static function valid( string $token ): bool {
		return 1 === preg_match( '/^[a-zA-Z0-9]{' . self::LENGTH . '}$/', $token );
	}

	/**
	 * Order of a token, or null.
	 *
	 * @param string $token Token.
	 */
	public static function order( string $token ): ?\WC_Order {
		foreach ( array( self::META, self::LEGACY_META ) as $key ) {
			$ids   = Orders::with_meta( $key, $token, 1 );
			$order = $ids ? wc_get_order( $ids[0] ) : false;
			if ( $order instanceof \WC_Order && hash_equals( (string) $order->get_meta( $key ), $token ) ) {
				return $order;
			}
		}
		return null;
	}

	/**
	 * Target of a path, or null when it is not a short link or leads nowhere.
	 *
	 * @param string $path Request path, relative to the site.
	 */
	public static function target( string $path ): ?string {
		if ( ! preg_match( '#^s/([a-zA-Z0-9]{' . self::LENGTH . '})$#', trim( $path, '/' ), $match ) ) {
			return null;
		}
		$order = self::order( $match[1] );
		if ( null === $order ) {
			return null;
		}
		$tracking = Tracking::of( $order );
		return null !== $tracking && '' !== $tracking['url'] ? $tracking['url'] : null;
	}

	/**
	 * Redirects a short link to the carrier.
	 *
	 * @param \WP $wp Request.
	 */
	public static function resolve( $wp ): void {
		if ( ! $wp instanceof \WP ) {
			return;
		}
		$target = self::target( (string) $wp->request );
		if ( null === $target ) {
			return;
		}
		// The carrier is another site: wp_safe_redirect() would refuse it.
		wp_redirect( $target, 302, 'La Chinata' ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- External carrier tracking page, stored by the shop.
		exit;
	}
}
