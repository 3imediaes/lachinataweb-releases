<?php
/**
 * Webhook of WhatsApp: what happened to each message.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Notify;

use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * `/wp-json/lachinata/v1/notify/whatsapp`, set as the callback URL of the app in Meta (field
 * `messages`). GET answers Meta's subscription check with the challenge when the verify
 * token matches. POST carries the statuses of the messages (sent, delivered, read, failed)
 * signed with the app secret (`X-Hub-Signature-256: sha256=<HMAC of the raw body>`): an
 * unsigned or badly signed request is refused. A message Meta could not deliver
 * (131026) goes once by SMS when the SMS is on. Messages from customers also arrive here;
 * they are answered in the WhatsApp app of the shop, so they are ignored.
 */
final class Webhook {

	/**
	 * REST namespace and route.
	 */
	public const NAMESPACE = 'lachinata/v1';
	public const ROUTE     = '/notify/whatsapp';

	/**
	 * The notifier.
	 *
	 * @var Service|null
	 */
	private static ?Service $service = null;

	/**
	 * Registers the route.
	 *
	 * @param Service $service Notifier.
	 */
	public static function boot( Service $service ): void {
		self::$service = $service;
		Hooks::add_action( 'rest_api_init', array( self::class, 'register' ) );
		Hooks::add_filter( 'rest_pre_serve_request', array( self::class, 'serve_challenge' ), 10, 4 );
	}

	/**
	 * Callback URL to paste in Meta.
	 */
	public static function url(): string {
		return rest_url( self::NAMESPACE . self::ROUTE );
	}

	/**
	 * Route.
	 */
	public static function register(): void {
		register_rest_route(
			self::NAMESPACE,
			self::ROUTE,
			array(
				array(
					'methods'             => \WP_REST_Server::READABLE,
					'callback'            => Hooks::rest( array( self::class, 'verify' ) ),
					'permission_callback' => '__return_true', // Meta's check: the verify token is the permission.
				),
				array(
					'methods'             => \WP_REST_Server::CREATABLE,
					'callback'            => Hooks::rest( array( self::class, 'receive' ) ),
					'permission_callback' => '__return_true', // Checked with the signature in receive().
				),
			)
		);
	}

	/**
	 * Subscription check: `hub.mode=subscribe`, `hub.verify_token`, `hub.challenge`.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function verify( \WP_REST_Request $request ) {
		$token    = (string) NotifyModule::setting( 'wa_verify_token' );
		$mode     = (string) $request->get_param( 'hub_mode' );
		$given    = (string) $request->get_param( 'hub_verify_token' );
		$question = (string) $request->get_param( 'hub_challenge' );
		if ( '' === $token || 'subscribe' !== $mode || ! hash_equals( $token, $given ) ) {
			return new \WP_Error( 'lachinata_notify_forbidden', 'Forbidden', array( 'status' => 403 ) );
		}
		$response = new \WP_REST_Response( $question, 200 );
		$response->header( 'Content-Type', 'text/plain; charset=utf-8' );
		return $response;
	}

	/**
	 * Meta wants the challenge as it came, not as JSON.
	 *
	 * @param mixed $served  Whether it was served.
	 * @param mixed $result  Response.
	 * @param mixed $request Request.
	 * @param mixed $server  Server.
	 */
	public static function serve_challenge( $served, $result, $request, $server = null ): bool {
		unset( $server );
		if ( $served || ! $request instanceof \WP_REST_Request || ! $result instanceof \WP_REST_Response || 'GET' !== $request->get_method() || self::ROUTE !== substr( (string) $request->get_route(), -strlen( self::ROUTE ) ) || 200 !== $result->get_status() ) {
			return (bool) $served;
		}
		echo esc_html( (string) $result->get_data() );
		return true;
	}

	/**
	 * Whether the body is signed with the app secret.
	 *
	 * @param string $body      Raw body.
	 * @param string $signature `sha256=…` header.
	 * @param string $secret    App secret.
	 */
	public static function signed( string $body, string $signature, string $secret ): bool {
		if ( '' === $secret || ! str_starts_with( $signature, 'sha256=' ) ) {
			return false;
		}
		return hash_equals( hash_hmac( 'sha256', $body, $secret ), substr( $signature, 7 ) );
	}

	/**
	 * Statuses of the messages.
	 *
	 * @param \WP_REST_Request $request Request.
	 * @return \WP_REST_Response|\WP_Error
	 */
	public static function receive( \WP_REST_Request $request ) {
		$body = (string) $request->get_body();
		if ( ! self::signed( $body, (string) $request->get_header( 'x_hub_signature_256' ), (string) NotifyModule::setting( 'wa_app_secret' ) ) ) {
			return new \WP_Error( 'lachinata_notify_signature', 'Invalid signature', array( 'status' => 401 ) );
		}
		$data = json_decode( $body, true );
		foreach ( self::statuses( is_array( $data ) ? $data : array() ) as $status ) {
			self::status( $status );
		}
		// Meta retries until it gets a 200: always 200 once the signature is good.
		return new \WP_REST_Response( array( 'ok' => true ), 200 );
	}

	/**
	 * Statuses inside a notification of Meta.
	 *
	 * @param array<string, mixed> $data Notification.
	 * @return array<int, array<string, mixed>>
	 */
	public static function statuses( array $data ): array {
		$out = array();
		foreach ( (array) ( $data['entry'] ?? array() ) as $entry ) {
			foreach ( (array) ( $entry['changes'] ?? array() ) as $change ) {
				foreach ( (array) ( $change['value']['statuses'] ?? array() ) as $status ) {
					if ( is_array( $status ) ) {
						$out[] = $status;
					}
				}
			}
		}
		return $out;
	}

	/**
	 * Applies one status to its message.
	 *
	 * @param array<string, mixed> $status Status (`id`, `status`, `errors`).
	 */
	public static function status( array $status ): void {
		$ref   = (string) ( $status['id'] ?? '' );
		$order = Messages::order( $ref );
		if ( null === $order || null === self::$service ) {
			return;
		}
		$state  = sanitize_key( (string) ( $status['status'] ?? '' ) );
		$error  = is_array( $status['errors'][0] ?? null ) ? $status['errors'][0] : array();
		$code   = (int) ( $error['code'] ?? 0 );
		$reason = (string) ( $error['error_data']['details'] ?? $error['title'] ?? $error['message'] ?? '' );
		Messages::update(
			$order,
			$ref,
			array(
				'status' => $state,
				'error'  => '' === $reason ? '' : $code . ': ' . $reason,
			)
		);
		$record = Messages::of( $order )[ $ref ] ?? array();
		$kind   = (string) ( $record['kind'] ?? '' );

		/**
		 * A WhatsApp message changed status (sent, delivered, read, failed).
		 *
		 * @since 0.8.0
		 *
		 * @param \WC_Order $order  Order.
		 * @param string    $kind   Notice kind (gift, shipped).
		 * @param string    $state  New status.
		 * @param string    $reason Meta's reason when it failed.
		 */
		do_action( 'lachinata/notify/status', $order, $kind, $state, $reason );

		if ( 'failed' !== $state ) {
			return;
		}
		if ( ! in_array( $code, Service::UNDELIVERABLE, true ) ) {
			NotifyModule::gaps()->record(
				'status|' . $code,
				/* translators: 1: Meta's code, 2: Meta's reason. */
				sprintf( __( 'WhatsApp no entregó un aviso (código %1$d: %2$s).', 'lachinata-core' ), $code, $reason ),
				array( 'order' => $order->get_id() )
			);
			return;
		}
		$result = self::$service->fall_back( $order, $ref );
		if ( null !== $result ) {
			/**
			 * A notice WhatsApp could not deliver went by SMS (or failed again).
			 *
			 * @since 0.8.0
			 *
			 * @param \WC_Order                                   $order  Order.
			 * @param string                                      $kind   Notice kind.
			 * @param \LaChinata\Core\Contracts\NoticeResult $result What happened to the SMS.
			 */
			do_action( 'lachinata/notify/fallback', $order, $kind, $result );
		}
	}
}
