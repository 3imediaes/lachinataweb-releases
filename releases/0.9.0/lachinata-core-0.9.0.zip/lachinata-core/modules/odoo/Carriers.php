<?php
/**
 * Map shipping instance → carrier.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Odoo;

use LaChinata\Core\Hooks;
use LaChinata\Core\Plugin;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Odoo receives the shipping instance id of each order (`shipping_lines[].instance_id`, and
 * `lachinata.shipping.instance_id`) and maps it to its carrier itself; that does not change.
 * This map is the shop's copy of it, by name: it fills `lachinata.shipping.carrier`
 * (informative) and the carrier of the gift notice («Llega con Correos Express»), and it
 * lets the panel warn about instance ids Odoo no longer knows (retired ids, a setting).
 */
final class Carriers {

	/**
	 * Option: instance id → carrier name.
	 */
	public const OPTION = 'lachinata_odoo_carriers';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'lachinata/order/carrier', array( self::class, 'carrier' ), 10, 2 );
		Hooks::add_action( 'lachinata/order/carrier_unknown', array( self::class, 'unknown' ), 10, 2 );
	}

	/**
	 * Option: instance id → the last time a notice left as «nuestro transportista».
	 */
	public const UNKNOWN_OPTION = 'lachinata_odoo_carriers_missing';

	/**
	 * A notice left without the carrier's name: the gap of the map is kept for the panel.
	 *
	 * @param mixed $instance_id Shipping instance id.
	 * @param mixed $order       Order.
	 */
	public static function unknown( $instance_id, $order = null ): void {
		unset( $order );
		$id = (int) $instance_id;
		if ( $id <= 0 || isset( self::map()[ $id ] ) ) {
			return;
		}
		$missing        = (array) get_option( self::UNKNOWN_OPTION, array() );
		$missing[ $id ] = time();
		update_option( self::UNKNOWN_OPTION, $missing, false );
	}

	/**
	 * The saved map.
	 *
	 * @return array<int, string>
	 */
	public static function map(): array {
		$map = get_option( self::OPTION, array() );
		$out = array();
		foreach ( is_array( $map ) ? $map : array() as $id => $name ) {
			$name = trim( (string) $name );
			if ( (int) $id > 0 && '' !== $name ) {
				$out[ (int) $id ] = $name;
			}
		}
		ksort( $out );
		return $out;
	}

	/**
	 * Saves the map (empty names are dropped).
	 *
	 * @param array<int|string, mixed> $map Instance id → carrier name.
	 */
	public static function save( array $map ): void {
		$clean = array();
		foreach ( $map as $id => $name ) {
			$name = trim( sanitize_text_field( (string) $name ) );
			if ( (int) $id > 0 && '' !== $name ) {
				$clean[ (int) $id ] = $name;
			}
		}
		ksort( $clean );
		update_option( self::OPTION, $clean, false );
	}

	/**
	 * Carrier of an order's instance.
	 *
	 * @param string|null $carrier     Carrier so far.
	 * @param int         $instance_id Instance id.
	 */
	public static function carrier( $carrier, $instance_id ): ?string {
		return self::map()[ (int) $instance_id ] ?? ( is_string( $carrier ) ? $carrier : null );
	}

	/**
	 * Instance ids Odoo no longer knows (setting).
	 *
	 * @return int[]
	 */
	public static function retired(): array {
		$module = Plugin::instance()->modules()->get( 'odoo' );
		$ids    = null === $module ? array() : (array) Settings::get( $module, 'retired_ids' );
		$ids    = array_values( array_unique( array_filter( array_map( 'intval', $ids ) ) ) );
		sort( $ids );
		return $ids;
	}

	/**
	 * Every shipping instance of every zone (also «Lugares no cubiertos»).
	 *
	 * @return array<int, array{zone: string, title: string, method: string, enabled: bool}>
	 */
	public static function instances(): array {
		$zones   = array_map( static fn( array $zone ): \WC_Shipping_Zone => new \WC_Shipping_Zone( (int) $zone['id'] ), \WC_Shipping_Zones::get_zones() );
		$zones[] = new \WC_Shipping_Zone( 0 );
		$out     = array();
		foreach ( $zones as $zone ) {
			foreach ( $zone->get_shipping_methods() as $method ) {
				if ( $method instanceof \WC_Shipping_Method && $method->get_instance_id() ) {
					$out[ (int) $method->get_instance_id() ] = array(
						'zone'    => $zone->get_zone_name(),
						'title'   => $method->get_title(),
						'method'  => $method->id,
						'enabled' => 'yes' === $method->enabled,
					);
				}
			}
		}
		ksort( $out );
		return $out;
	}

	/**
	 * Warnings for the panel: retired ids still in use or mapped, mapped ids that no longer
	 * exist and enabled instances without carrier.
	 *
	 * @return string[]
	 */
	public static function warnings(): array {
		$instances = self::instances();
		$map       = self::map();
		$warnings  = array();
		foreach ( self::retired() as $id ) {
			if ( isset( $instances[ $id ] ) && $instances[ $id ]['enabled'] ) {
				/* translators: 1: instance id, 2: method title, 3: zone name. */
				$warnings[] = sprintf( __( 'El ID %1$d (%2$s, zona «%3$s») está retirado en Odoo y sigue activo en WooCommerce: Odoo no sabrá con qué transportista enviarlo.', 'lachinata-core' ), $id, $instances[ $id ]['title'], $instances[ $id ]['zone'] );
			} elseif ( isset( $map[ $id ] ) ) {
				/* translators: %d: instance id. */
				$warnings[] = sprintf( __( 'El ID %d está retirado en Odoo y sigue en el mapa: quítalo.', 'lachinata-core' ), $id );
			}
		}
		foreach ( array_keys( $map ) as $id ) {
			if ( ! isset( $instances[ $id ] ) && ! in_array( $id, self::retired(), true ) ) {
				/* translators: %d: instance id. */
				$warnings[] = sprintf( __( 'El ID %d está en el mapa pero ya no existe en WooCommerce. Si se ha cambiado por otro, avisa a quien lleva Odoo.', 'lachinata-core' ), $id );
			}
		}
		foreach ( $instances as $id => $instance ) {
			if ( $instance['enabled'] && ! isset( $map[ $id ] ) && ! in_array( $id, self::retired(), true ) ) {
				/* translators: 1: instance id, 2: method title, 3: zone name. */
				$warnings[] = sprintf( __( 'El ID %1$d (%2$s, zona «%3$s») no tiene transportista en el mapa: los avisos dirán «nuestro transportista».', 'lachinata-core' ), $id, $instance['title'], $instance['zone'] );
			}
		}
		foreach ( (array) get_option( self::UNKNOWN_OPTION, array() ) as $id => $at ) {
			if ( ! isset( $map[ (int) $id ] ) ) {
				/* translators: 1: instance id, 2: date. */
				$warnings[] = sprintf( __( 'Un aviso del ID %1$d salió con «nuestro transportista» (último: %2$s): falta en el mapa.', 'lachinata-core' ), (int) $id, wp_date( (string) get_option( 'date_format' ), (int) $at ) );
			}
		}
		return $warnings;
	}
}
