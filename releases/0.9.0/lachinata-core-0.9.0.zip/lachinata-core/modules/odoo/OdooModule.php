<?php
/**
 * Module `odoo`: the contract of the orders API with Odoo.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Odoo;

use LaChinata\Core\Module;

defined( 'ABSPATH' ) || exit;

/**
 * Odoo reads WooCommerce's REST API with its own key and maps the carrier from the shipping
 * instance id; that does not change. Everything La Chinata adds to an order goes in the
 * single `lachinata` object (core, `plugin/src/Rest/OrderData.php`), never as loose
 * fields. This module keeps the shop's copy of the map instance → carrier (for
 * `lachinata.shipping.carrier` and the gift notice), warns about retired instance ids and
 * shows the object of any order. Contract: docs/api-odoo.md.
 */
final class OdooModule extends Module {

	/**
	 * Module id.
	 */
	public function id(): string {
		return 'odoo';
	}

	/**
	 * Module name.
	 */
	public function label(): string {
		return __( 'Odoo', 'lachinata-core' );
	}

	/**
	 * Module description.
	 */
	public function description(): string {
		return __( 'Contrato de la API de pedidos con Odoo: mapa método de envío → transportista, aviso de IDs retirados y vista del objeto lachinata de cada pedido.', 'lachinata-core' );
	}

	/**
	 * Version in which the module was added.
	 */
	public function since(): string {
		return '0.7.0';
	}

	/**
	 * Documentation.
	 */
	public function docs(): string {
		return 'plugin/modules/odoo/README.md';
	}

	/**
	 * Requirements.
	 *
	 * @return array{woocommerce: string}
	 */
	public function requires(): array {
		return array( 'woocommerce' => '10.0' );
	}

	/**
	 * Settings: instance ids Odoo no longer knows.
	 *
	 * @return array<string, array{type: 'bool'|'int'|'float'|'string'|'array', default: mixed, export?: bool}>
	 */
	public function settings(): array {
		return array(
			'retired_ids' => array(
				'type'    => 'array',
				'default' => array(),
				'export'  => true,
			),
		);
	}

	/**
	 * The map instance → carrier for the JSON export.
	 *
	 * @return array<string, mixed>
	 */
	public function export_data(): array {
		$carriers = array();
		foreach ( Carriers::map() as $id => $name ) {
			$carriers[ (string) $id ] = $name;
		}
		return array( 'carriers' => $carriers );
	}

	/**
	 * Checks an imported map: positive ids and names.
	 *
	 * @param array<string, mixed> $data Section.
	 * @return string[]
	 */
	public function validate_data( array $data ): array {
		if ( isset( $data['carriers'] ) && ! is_array( $data['carriers'] ) ) {
			return array( __( 'Odoo: «carriers» debe ser una lista de ID de instancia → transportista.', 'lachinata-core' ) );
		}
		$errors = array();
		foreach ( (array) ( $data['carriers'] ?? array() ) as $id => $name ) {
			if ( (int) $id <= 0 || ! is_string( $name ) ) {
				/* translators: %s: key of the map. */
				$errors[] = sprintf( __( 'Odoo: la entrada «%s» del mapa no es un ID de instancia con su transportista.', 'lachinata-core' ), (string) $id );
			}
		}
		return $errors;
	}

	/**
	 * Writes an imported map. The ids are the same on every copy of a site (staging,
	 * production); on another shop they are whatever its zones have.
	 *
	 * @param array<string, mixed> $data Section that passed validate_data().
	 */
	public function import_data( array $data ): void {
		if ( isset( $data['carriers'] ) ) {
			Carriers::save( (array) $data['carriers'] );
		}
	}

	/**
	 * Configured when the map instance → carrier has names; the notes count the instances
	 * a notice found without a carrier.
	 *
	 * @return array{configured: bool, credentials: null, notes: string[]}
	 */
	public function health(): array {
		$missing = count( (array) get_option( Carriers::UNKNOWN_OPTION, array() ) );
		return array(
			'configured'  => (bool) Carriers::map(),
			'credentials' => null,
			/* translators: %d: number of shipping instances. */
			'notes'       => $missing ? array( sprintf( _n( '%d método sin transportista en el mapa', '%d métodos sin transportista en el mapa', $missing, 'lachinata-core' ), $missing ) ) : array(),
		);
	}

	/**
	 * Registers the hooks.
	 */
	public function boot(): void {
		Carriers::boot();
		if ( is_admin() ) {
			OdooTab::boot();
		}
	}
}
