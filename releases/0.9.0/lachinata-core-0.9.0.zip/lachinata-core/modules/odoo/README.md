# Módulo `odoo`

Contrato de la API de pedidos con Odoo. Odoo lee la API REST de WooCommerce con su clave («Odoo») y asocia el transportista por el **ID de instancia** del método de envío; eso no cambia y no depende de este módulo. Todo lo que La Chinata añade a un pedido va en un único objeto `lachinata` (núcleo, `plugin/src/Rest/OrderData.php`), nunca en campos sueltos en la raíz.

Contrato completo con ejemplos: `docs/api-odoo.md`. Paso a producción: `docs/despliegue-gift-odoo.md`. Panel: WooCommerce → La Chinata → Odoo.

## Qué hace
| Pieza | Cómo | Dónde |
| --- | --- | --- |
| Mapa instancia de envío → transportista, con todas las instancias de todas las zonas (también «Lugares no cubiertos»), activas o no | Opción `lachinata_odoo_carriers`; exportable en el JSON de configuración (`data.carriers`) | `Carriers.php`, `OdooTab.php` |
| Nombre del transportista en `lachinata.shipping.carrier` (informativo), en el aviso de regalo y en «Tu pedido ya está en camino» (correo y WhatsApp: «llega … con Correos Express») | Filtro del núcleo `lachinata/order/carrier` | `Carriers::carrier()` |
| IDs retirados en Odoo (ajuste `retired_ids`, configuración de cada sitio; el seed pone los de lachinata.es: 18, 24, 26, 31, 32, 38, 39). Avisos: un ID retirado que sigue activo en WooCommerce o en el mapa, un ID del mapa que ya no existe, una instancia activa sin transportista y, desde la 0.8.0, una instancia con la que ya salió un aviso como «nuestro transportista» (acción `lachinata/order/carrier_unknown`, opción `lachinata_odoo_carriers_missing`) | `Carriers::warnings()`, `Carriers::unknown()` | panel |
| Regiones de España con zona propia (Baleares ES:PM, Canarias, Ceuta y Melilla) con sus IDs: son país ES + provincia, sin países ficticios | Zonas de WooCommerce | panel |
| «Objeto de un pedido»: el `lachinata` de cualquier pedido tal como lo recibe Odoo | `OrderData::of()` | panel |

Nada de lachinata.es en el código: el mapa y los IDs retirados son configuración.

## Depende de

Ningún módulo. WooCommerce 10. Sin `odoo`, `lachinata.shipping.carrier` llega como `null` y los avisos dicen «nuestro transportista».

## Hooks que escucha

- `lachinata/order/carrier` (núcleo): devuelve el nombre del mapa para la instancia de envío del pedido.
- `lachinata/order/carrier_unknown` (`gift`, `shipment`): anota la instancia que salió sin transportista.
- `lachinata/core/admin_tabs`: la pestaña Odoo.

## Hooks que emite

Ninguno propio. Lo que expone a otros va por los filtros del núcleo de arriba (`plugin/HOOKS.md`).

## Datos que guarda

- Opciones: `lachinata_odoo_carriers` (mapa instancia → transportista), `lachinata_odoo_carriers_missing` (instancias que salieron sin transportista, con fecha), `lachinata_odoo_retired_ids` (ajuste).
- Ningún metadato de pedido: el transportista se calcula al leer el pedido.

## REST y API para Odoo

No tiene rutas propias. Rellena `lachinata.shipping.carrier` del objeto `lachinata` (núcleo, `plugin/src/Rest/OrderData.php`); contrato completo en `docs/api-odoo.md`.

## Ajustes y exportación

| Ajuste | Por defecto | En el JSON |
| --- | --- | --- |
| IDs retirados en Odoo (`retired_ids`) | ninguno | sí |

El mapa de transportistas también viaja en el JSON (`data.carriers`, `export_data()`), validado contra las instancias del sitio que importa.

## Qué pasa al apagarlo

Odoo sigue leyendo la API REST de siempre y el objeto `lachinata` sin cambios, salvo `shipping.carrier` (`null`). Los avisos al comprador y al destinatario de un regalo dicen «nuestro transportista». El mapa y los IDs retirados se quedan en la base de datos; «Borrar datos» los quita.

## Pruebas
`tests/CarriersTest.php`: mapa y transportista del pedido (el `instance_id` sigue ahí), avisos, exportación e importación. El objeto completo, en `plugin/tests/OrderDataTest.php`.

- El objeto completo con el transportista y el regalo, en `tests/profiles/OrderDataTest.php` (perfiles con `gift` y `odoo`).

## Huecos conocidos

- Los nombres de transportista de lachinata.es los pone quien lleva Odoo: el seed no inventa ninguno (`docs/despliegue-gift-odoo.md`).
- Baleares sin el país ficticio `BL` y el ID nuevo de «Tarifa en vivo»: pendiente de que Odoo los reciba (roadmap, «Decisiones que faltan»).
