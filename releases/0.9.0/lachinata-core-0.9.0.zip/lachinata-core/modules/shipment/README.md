# Módulo `shipment`

El pedido en camino: cuando Odoo marca «Completado» (sale el paquete) y escribe el seguimiento con WooCommerce Shipment Tracking, el comprador recibe **«Tu pedido ya está en camino»** por correo, una sola vez, con la fecha calculada desde el día real de salida, el transportista y «Seguir el paquete»; y por **WhatsApp** si lo pidió en el checkout. Gracias y Mi cuenta muestran «En camino» y el seguimiento.

Especificación: `design-system/sistema/06-correos.md` (inventario «Pedido enviado», «Avisos por WhatsApp y SMS»), `03-implementacion.md` (tabla de módulos: `shipment`; `tracking` es la analítica), `02-plantillas.md` («Cuenta»). Decisiones: `design-system/docs/decisiones.md` (incremento 6). Ajustes: WooCommerce → La Chinata → Seguimiento. Paso a producción: `docs/despliegue-notify-tracking.md`.

No necesita otros módulos: sin `notify` no hay WhatsApp; sin `eta`, las fechas no se recalculan («en los próximos días» en el WhatsApp); sin `odoo`, el transportista sale del seguimiento si es un proveedor propio con nombre.

## Qué hace
| Pieza | Cómo | Dónde |
| --- | --- | --- |
| Casilla **«Avísame por WhatsApp cuando salga mi pedido»** en Contacto, bajo la de novedades y con la misma pieza (campo adicional del checkout de WooCommerce), apagada por defecto. Solo se ofrece con el ajuste y WhatsApp activo en Avisos; nunca por SMS. Se oculta (y se desmarca) al marcar «Es un regalo» | `woocommerce_register_additional_checkout_field`, ubicación `contact`, después de `checkout`; el script lee `lachinata-gift.open` del store `wc/store/checkout` | `Optin.php`, `src/index.js` |
| Consentimiento en el pedido con su fecha: `_lc_shipment_whatsapp`. Un regalo nunca lo guarda (el teléfono de entrega es el del destinatario) | `woocommerce_store_api_checkout_order_processed`; el regalo se lee en `_lc_regalo` | `Optin.php` |
| **Disparo único** al pasar a uno de los estados del ajuste («Completado» por defecto): se apunta `_lc_shipment_notified` y sale el correo de WooCommerce de ese estado; si el pedido vuelve a «Completado», ni el correo ni el WhatsApp se repiten | `woocommerce_order_status_<estado>`, prioridad 5; `woocommerce_email_enabled_customer_completed_order` solo para ese pedido | `Notifier.php` |
| WhatsApp **`lc_pedido_enviado`** (o `_sin_enlace` sin seguimiento) al teléfono de entrega: nombre de pila, número de pedido, fechas y transportista («nuestro transportista» si no hay, anotado con `lachinata/order/carrier_unknown`); el botón lleva el enlace corto. SMS de respaldo en dos segmentos (quita el transportista si no cabe; la fecha y el enlace nunca). Nota en el pedido y, si no sale, hueco de configuración | `Contracts\Notifier` (`notify`) | `Notifier.php` |
| Correo «Tu pedido {nº} ya está en camino» en el marco del tema (tablero «Correos transaccionales», 2): entradilla con el transportista y, con seguimiento, «Si no vas a estar…»; datos **Llega** (desde `date_shipped`), **Transportista** (con el número) y la **Entrega en** del tema; botón «Seguir el paquete» a la página del transportista; preheader con la fecha. La tabla propia de WooCommerce Shipment Tracking sale del correo | Filtros `lachinata/email/intro`, `facts`, `button`; fechas con `lachinata/delivery/from_dispatch` (`eta`) | `Emails.php` |
| Gracias: «Seguir el paquete» a la página del transportista cuando hay seguimiento (antes, «Seguir el pedido»). Mi cuenta → Pedidos: `Badge` «En camino» (`info`), transportista y número, y «Seguir el paquete» | Huecos del tema `lachinata/order/tracking` y `lachinata/order/status` | `Storefront.php` |
| API para Odoo: `lachinata.shipment` (`whatsapp_opt_in`, `opt_in_at`, `notified_at`) | `lachinata/rest/order` | `Optin.php`; contrato en `docs/api-odoo.md` |
| **Preparado y apagado**: el segundo aviso del regalo el día de la entrega. Una fuente registrada en `lachinata/shipment/delivery_events` dice si un pedido sale hoy a reparto; con el ajuste `delivery_day` (apagado, fuera del panel) una tarea horaria dispara `lachinata/shipment/out_for_delivery` una vez por pedido. Hoy no hay fuente: no se programa nada | Action Scheduler | `DeliveryDay.php` |

El seguimiento lo lee el núcleo (`LaChinata\Core\Tracking\Tracking`): el último elemento de `_wc_shipment_tracking_items`. El transportista sale del mapa del módulo `odoo` y, si no está, del nombre de un proveedor propio del seguimiento.

## Depende de

Ningún módulo en `requires`:
- `notify`, opcional, por `Contracts\Notifier`: sin él, no hay WhatsApp (solo el correo).
- `eta`, opcional, por el filtro `lachinata/delivery/from_dispatch`: sin él, las fechas no se recalculan («en los próximos días» en el WhatsApp).
- `odoo`, opcional, por `lachinata/order/carrier`: sin él, el transportista sale del seguimiento si es un proveedor propio con nombre.
- `gift`: lee `_lc_regalo` del pedido (metadato catalogado) para no avisar por WhatsApp a quien recibe un regalo.

## Hooks que escucha

- `woocommerce_init` (casilla, prioridad 20: bajo la de novedades), `woocommerce_store_api_checkout_order_processed` (consentimiento), `woocommerce_blocks_enqueue_checkout_block_scripts_after` (script).
- `woocommerce_order_status_<estado>` (prioridad 5), `woocommerce_email_enabled_customer_completed_order` (un solo correo por pedido).
- Del tema: `lachinata/email/intro`, `facts`, `button`, `lachinata/order/tracking`, `lachinata/order/status`. Del núcleo y de otros: `lachinata/rest/order`, `lachinata/notify/fallback`, `lachinata/core/admin_tabs`.

## Hooks que emite
| Hook | Tipo | Para qué |
| --- | --- | --- |
| `lachinata/delivery/from_dispatch` `( ?array $dates, WC_Order $order, ?int $shipped )` | filtro | Lo rellena `eta`: `span` («jue 24 – vie 25 oct») y `between` desde el día de salida |
| `lachinata/order/carrier_unknown` `( int $instance_id, WC_Order $order )` | acción | Un aviso salió con «nuestro transportista» (`odoo` lo anota) |
| `lachinata/shipment/delivery_events` | filtro | Fuentes del día de reparto (ninguna hoy) |
| `lachinata/shipment/out_for_delivery` `( WC_Order $order )` | acción | El pedido sale hoy a reparto |


También lee `lachinata/email/frame`. Catálogo con versiones: `plugin/HOOKS.md`.

## Datos que guarda

- Metadatos de pedido: `_lc_shipment_whatsapp` (consentimiento), `_lc_shipment_notified` (aviso hecho), `_lc_shipment_out_for_delivery` (preparado).
- Opciones `lachinata_shipment_*`: ajustes y registro de huecos.

## REST y API para Odoo

`lachinata.shipment` del objeto de la API de pedidos (`whatsapp_opt_in`, `opt_in_at`, `notified_at`): `docs/api-odoo.md`. El seguimiento lo escribe Odoo con WooCommerce Shipment Tracking (`_wc_shipment_tracking_items`). Sin rutas propias.

## Ajustes y exportación
| Ajuste | Por defecto | En el JSON |
| --- | --- | --- |
| Estados que envían el aviso (`notify_statuses`) | `completed` | sí |
| Ofrecer el aviso por WhatsApp (`whatsapp_optin`) | sí (solo se ve con WhatsApp activo) | sí |
| Aviso el día de la entrega (`delivery_day`) | no (sin fuente de datos) | sí |


El módulo no tiene `export_data()`: solo viajan los ajustes.

## Qué pasa al apagarlo

El correo de WooCommerce de «Completado» vuelve a ser el suyo (sin «Tu pedido ya está en camino» ni la fecha real), no hay casilla de WhatsApp ni WhatsApp, y gracias y Mi cuenta dejan de mostrar «En camino» y «Seguir el paquete». Los consentimientos y marcas de aviso se quedan en los pedidos: al encenderlo, un pedido ya avisado no repite.

## Pruebas
- `tests/ShipmentTest.php`: correo y WhatsApp una sola vez (y otro pedido recibe el suyo), sin consentimiento solo correo, regalo nunca por WhatsApp, WhatsApp apagado no se ofrece ni sale, sin seguimiento la plantilla sin enlace y «nuestro transportista», SMS en dos segmentos con la fecha y el enlace, piezas del correo, estado y seguimiento para el tema.
- e2e: `tests/e2e/shipment.spec.mjs` (casilla bajo novedades, apagada, oculta con el regalo, sin rastro en gracias).

Desde la 0.9.0 `ShipmentTest` usa el doble `FakeNotifier` (canal, tipo de aviso, variables y si lleva enlace); las plantillas reales de `notify` con y sin enlace están en `tests/profiles/ShipmentNotifyTest.php`.

## Huecos conocidos

- Sin fuente del día de reparto: el aviso del día de la entrega está preparado y apagado.
- Un pedido completado antes de la 0.8.0 que vuelva a «Completado» recibe una vez «Tu pedido ya está en camino».
