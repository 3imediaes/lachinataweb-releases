<?php
/**
 * Module `shipment`: the order on its way.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipment;

use LaChinata\Core\GapLog;
use LaChinata\Core\Module;
use LaChinata\Core\Plugin;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Tracking of the parcel (03-implementacion.md, `shipment`; 06-correos.md, «Pedido
 * enviado»): Odoo marks the order «Completado» when it leaves and writes the tracking with
 * WooCommerce Shipment Tracking, the only source. Then the buyer gets «Tu pedido ya está en
 * camino» by email (the theme's frame with the real dates, the carrier and «Seguir el
 * paquete»), once, and, if they ticked «Avísame por WhatsApp cuando salga mi pedido» in the
 * checkout, by WhatsApp too (template `lc_pedido_enviado`, through `notify`). Never by
 * WhatsApp for a gift: the delivery phone is the recipient's. The order received page and
 * the account show «En camino» and «Seguir el paquete».
 */
final class ShipmentModule extends Module {

	/**
	 * Module id.
	 */
	public function id(): string {
		return 'shipment';
	}

	/**
	 * Module name.
	 */
	public function label(): string {
		return __( 'Seguimiento del envío', 'lachinata-core' );
	}

	/**
	 * Module description.
	 */
	public function description(): string {
		return __( 'Correo «Tu pedido ya está en camino» con la fecha real y el seguimiento que escribe Odoo, aviso opcional por WhatsApp al comprador y «Seguir el paquete» en gracias y en Mi cuenta.', 'lachinata-core' );
	}

	/**
	 * Version in which the module was added.
	 */
	public function since(): string {
		return '0.8.0';
	}

	/**
	 * Documentation.
	 */
	public function docs(): string {
		return 'plugin/modules/shipment/README.md';
	}

	/**
	 * Requirements. Without notify there is no WhatsApp; without eta, no recalculated dates.
	 *
	 * @return array{modules: string[], woocommerce: string}
	 */
	public function requires(): array {
		return array(
			'modules'     => array(),
			'woocommerce' => '10.0',
		);
	}

	/**
	 * Settings.
	 *
	 * @return array<string, array{type: 'bool'|'int'|'float'|'string'|'array', default: mixed, export?: bool}>
	 */
	public function settings(): array {
		return array(
			'notify_statuses' => array(
				'type'    => 'array',
				'default' => array( 'completed' ),
				'export'  => true,
			),
			'whatsapp_optin'  => array(
				'type'    => 'bool',
				'default' => true,
				'export'  => true,
			),
			// Prepared, off: the carriers do not send the day of delivery yet (DeliveryDay).
			'delivery_day'    => array(
				'type'    => 'bool',
				'default' => false,
				'export'  => true,
			),
		);
	}

	/**
	 * A setting of the module.
	 *
	 * @param string $key Setting key.
	 * @return mixed
	 */
	public static function setting( string $key ) {
		$module = Plugin::instance()->modules()->get( 'shipment' );
		return null === $module ? null : Settings::get( $module, $key );
	}

	/**
	 * Configuration gaps of the module.
	 */
	public static function gaps(): GapLog {
		return new GapLog( 'lachinata_shipment_gaps', 'lachinata-shipment' );
	}

	/**
	 * Consent and notices kept on orders.
	 *
	 * @return array{order_meta: string[]}
	 */
	public function owned_data(): array {
		return array( 'order_meta' => array( Optin::META, '_lc_shipment_notified', '_lc_shipment_out_for_delivery' ) );
	}

	/**
	 * Registers the hooks.
	 */
	public function boot(): void {
		Optin::boot();
		Notifier::boot();
		Emails::boot();
		Storefront::boot();
		DeliveryDay::boot();
		if ( is_admin() ) {
			ShipmentTab::boot();
		}
	}
}
