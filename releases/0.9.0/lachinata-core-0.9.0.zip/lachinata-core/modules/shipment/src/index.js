/**
 * Module `shipment`: «Avísame por WhatsApp cuando salga mi pedido» hides while «Es un
 * regalo» is ticked (06-correos.md): a gift's delivery phone is the recipient's. The gift
 * card keeps its state in the checkout store as extension data (`lachinata-gift`); this
 * marks the body with `lc-gift-open` and the theme hides the box (checkout.css). Ticked
 * when the gift opens, the box is unticked. The server ignores it for a gift anyway.
 */
import { subscribe, select } from '@wordpress/data';

const CHECKOUT_STORE = 'wc/store/checkout';
const BOX = '.wc-block-components-address-form__lachinata-shipment-whatsapp';

let open = false;

subscribe(() => {
	const gift =
		!!select(CHECKOUT_STORE)?.getExtensionData()?.['lachinata-gift']?.open;
	if (gift === open) {
		return;
	}
	open = gift;
	document.body.classList.toggle('lc-gift-open', gift);
	const input = document.querySelector(`${BOX} input[type="checkbox"]`);
	if (gift && input?.checked) {
		// Controlled by WooCommerce's form: a click keeps its data in step.
		input.click();
	}
}, CHECKOUT_STORE);
