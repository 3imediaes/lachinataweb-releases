<?php
/**
 * A shipping method instance of a zone, as the evaluator sees it.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping;

defined( 'ABSPATH' ) || exit;

/**
 * Instance id, title for people and its conditions.
 */
final class Candidate {

	/**
	 * Builds the candidate.
	 *
	 * @param int        $instance_id WooCommerce instance id (the one Odoo reads).
	 * @param string     $title       Method title.
	 * @param Conditions $conditions  Conditions.
	 */
	public function __construct(
		public readonly int $instance_id,
		public readonly string $title,
		public readonly Conditions $conditions,
	) {}
}
