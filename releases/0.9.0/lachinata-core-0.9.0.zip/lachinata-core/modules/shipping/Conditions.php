<?php
/**
 * Conditions of a shipping method instance.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping;

use LaChinata\Core\Shipping\Package;

defined( 'ABSPATH' ) || exit;

/**
 * Positive conditions: the instance is offered when the package meets all of them.
 * Lower bounds include the value («desde 15 kg»), upper bounds do not («menos de 15 kg»),
 * so two instances split a range without gaps or overlaps.
 */
final class Conditions {

	/**
	 * Minimum amount taken from the zone's free shipping threshold.
	 */
	public const ZONE_THRESHOLD = 'zone';

	/**
	 * Keys of the instance settings, as stored by WooCommerce in the instance options.
	 */
	public const KEYS = array(
		'lc_weight_min',
		'lc_weight_max',
		'lc_amount_min_source',
		'lc_amount_min',
		'lc_amount_max',
		'lc_ignore_discounts',
		'lc_classes_required',
		'lc_classes_excluded',
		'lc_priority',
		'lc_hides',
	);

	/**
	 * Default priority: instances without one keep the zone order among themselves.
	 */
	public const DEFAULT_PRIORITY = 10;

	/**
	 * Builds the conditions.
	 *
	 * @param float|null        $weight_min       Weight from (kg, included).
	 * @param float|null        $weight_max       Weight below (kg, excluded).
	 * @param float|string|null $amount_min       Amount from (included), or ZONE_THRESHOLD.
	 * @param float|null        $amount_max       Amount below (excluded).
	 * @param bool              $ignore_discounts Compare the amount before discounts.
	 * @param string[]          $classes_required The package must carry at least one of these classes.
	 * @param string[]          $classes_excluded The package must carry none of these classes.
	 * @param int               $priority         Lower first, both in the list and when hiding.
	 * @param int[]             $hides            Instances hidden when this one is offered.
	 */
	public function __construct(
		public readonly ?float $weight_min = null,
		public readonly ?float $weight_max = null,
		public readonly float|string|null $amount_min = null,
		public readonly ?float $amount_max = null,
		public readonly bool $ignore_discounts = false,
		public readonly array $classes_required = array(),
		public readonly array $classes_excluded = array(),
		public readonly int $priority = self::DEFAULT_PRIORITY,
		public readonly array $hides = array(),
	) {}

	/**
	 * Conditions from the instance settings (missing keys mean «no condition»).
	 *
	 * @param array<string, mixed> $settings Instance settings.
	 */
	public static function from_settings( array $settings ): self {
		$source = (string) ( $settings['lc_amount_min_source'] ?? '' );
		$min    = self::number( $settings['lc_amount_min'] ?? null );
		if ( self::ZONE_THRESHOLD === $source ) {
			$min = self::ZONE_THRESHOLD;
		} elseif ( 'value' !== $source ) {
			$min = null;
		}
		$priority = self::number( $settings['lc_priority'] ?? null );

		return new self(
			self::number( $settings['lc_weight_min'] ?? null ),
			self::number( $settings['lc_weight_max'] ?? null ),
			$min,
			self::number( $settings['lc_amount_max'] ?? null ),
			in_array( $settings['lc_ignore_discounts'] ?? '', array( 'yes', true, '1' ), true ),
			self::slugs( $settings['lc_classes_required'] ?? array() ),
			self::slugs( $settings['lc_classes_excluded'] ?? array() ),
			null === $priority ? self::DEFAULT_PRIORITY : (int) $priority,
			array_values( array_filter( array_map( 'intval', (array) ( $settings['lc_hides'] ?? array() ) ) ) )
		);
	}

	/**
	 * The conditions as instance settings (the inverse of from_settings()).
	 *
	 * @return array<string, mixed>
	 */
	public function to_settings(): array {
		$text = static fn( ?float $value ): string => null === $value ? '' : (string) $value;
		return array(
			'lc_weight_min'        => $text( $this->weight_min ),
			'lc_weight_max'        => $text( $this->weight_max ),
			'lc_amount_min_source' => null === $this->amount_min ? '' : ( self::ZONE_THRESHOLD === $this->amount_min ? self::ZONE_THRESHOLD : 'value' ),
			'lc_amount_min'        => is_float( $this->amount_min ) ? (string) $this->amount_min : '',
			'lc_amount_max'        => $text( $this->amount_max ),
			'lc_ignore_discounts'  => $this->ignore_discounts ? 'yes' : 'no',
			'lc_classes_required'  => $this->classes_required,
			'lc_classes_excluded'  => $this->classes_excluded,
			'lc_priority'          => (string) $this->priority,
			'lc_hides'             => array_map( 'strval', $this->hides ),
		);
	}

	/**
	 * Conditions the package does not meet: `weight`, `amount`, `classes`, or `threshold`
	 * when the minimum is the zone's threshold and the zone has none (a configuration gap).
	 *
	 * @param Package    $package   Package.
	 * @param float|null $threshold Free shipping threshold of the zone.
	 * @return string[]
	 */
	public function failures( Package $package, ?float $threshold ): array {
		$failures = array();

		if ( ( null !== $this->weight_min && $package->weight < $this->weight_min )
			|| ( null !== $this->weight_max && $package->weight >= $this->weight_max ) ) {
			$failures[] = 'weight';
		}

		$amount = $package->amount( $this->ignore_discounts );
		$min    = self::ZONE_THRESHOLD === $this->amount_min ? $threshold : $this->amount_min;
		if ( self::ZONE_THRESHOLD === $this->amount_min && null === $threshold ) {
			$failures[] = 'threshold';
		} elseif ( ( is_float( $min ) && $amount < $min ) || ( null !== $this->amount_max && $amount >= $this->amount_max ) ) {
			$failures[] = 'amount';
		}

		$classes = $package->classes();
		if ( ( $this->classes_required && ! array_intersect( $this->classes_required, $classes ) )
			|| array_intersect( $this->classes_excluded, $classes ) ) {
			$failures[] = 'classes';
		}

		return $failures;
	}

	/**
	 * Number typed in a settings field («15», «15,5»), or null when empty or not a number.
	 *
	 * @param mixed $value Raw value.
	 */
	public static function number( mixed $value ): ?float {
		if ( is_int( $value ) || is_float( $value ) ) {
			return (float) $value;
		}
		$value = str_replace( ',', '.', trim( (string) ( is_scalar( $value ) ? $value : '' ) ) );
		return is_numeric( $value ) ? (float) $value : null;
	}

	/**
	 * List of shipping class slugs.
	 *
	 * @param mixed $value Raw value.
	 * @return string[]
	 */
	private static function slugs( mixed $value ): array {
		return array_values( array_filter( array_map( 'strval', (array) $value ), static fn( string $slug ): bool => '' !== $slug ) );
	}
}
