<?php
/**
 * Warns when plugins that do the same job are still active.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping;

use LaChinata\Core\Admin\Screen;
use LaChinata\Core\Hooks;

defined( 'ABSPATH' ) || exit;

/**
 * With Conditional Shipping and Payments, another delivery date plugin or the old free
 * shipping bar active at the same time, rates are filtered twice and the bag shows two
 * bars. The notice lists them; nothing is switched off automatically.
 */
final class ConflictNotice {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'admin_notices', array( self::class, 'render' ) );
	}

	/**
	 * Name fragments of the plugins that overlap with `shipping` and `eta`.
	 *
	 * @return string[]
	 */
	public static function patterns(): array {
		/**
		 * Name fragments of active plugins that overlap with the shipping modules.
		 *
		 * @since 0.4.0
		 *
		 * @param string[] $patterns Case-insensitive fragments of the plugin name.
		 */
		return (array) apply_filters( 'lachinata/shipping/conflicting_plugins', array( 'Conditional Shipping and Payments', 'Estimated Delivery Date', '3imedia' ) );
	}

	/**
	 * Names of the active plugins that overlap.
	 *
	 * @return string[]
	 */
	public static function active(): array {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}
		$found = array();
		foreach ( get_plugins() as $file => $plugin ) {
			if ( ! is_plugin_active( $file ) ) {
				continue;
			}
			foreach ( self::patterns() as $pattern ) {
				if ( '' !== $pattern && false !== stripos( (string) $plugin['Name'], $pattern ) ) {
					$found[] = (string) $plugin['Name'];
					break;
				}
			}
		}
		return $found;
	}

	/**
	 * Prints the notice on WooCommerce screens and plugin screens.
	 */
	public static function render(): void {
		$screen = get_current_screen();
		if ( null === $screen || ! current_user_can( Screen::CAPABILITY ) || ! in_array( $screen->id, array( 'plugins', 'woocommerce_page_wc-settings', 'woocommerce_page_' . Screen::SLUG ), true ) ) {
			return;
		}
		$active = self::active();
		if ( ! $active ) {
			return;
		}
		printf(
			'<div class="notice notice-warning"><p>%s</p></div>',
			esc_html(
				sprintf(
					/* translators: %s: plugin names. */
					__( 'El módulo Envíos de La Chinata está activo junto a %s. Las reglas se aplicarían dos veces: desactívalos el día del cambio (procedimiento en docs/despliegue-envios.md).', 'lachinata-core' ),
					wp_sprintf_l( '%l', $active )
				)
			)
		);
	}
}
