<?php
/**
 * What the evaluator decided for a package.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping;

defined( 'ABSPATH' ) || exit;

/**
 * Offered instances in order, why the others are not offered and, when nothing is
 * offered, the cause.
 */
final class Decision {

	/**
	 * Builds the decision.
	 *
	 * @param int[]                $offered    Offered instance ids, in display order.
	 * @param array<int, string[]> $rejected   Instance id → reasons (`weight`, `amount`, `classes`, `threshold`, `hidden:<id>`).
	 * @param string|null          $cause      One of ZoneRules::CAUSES when nothing is offered.
	 * @param bool                 $blocked    The package cannot ship at all (restricted product, zone weight): no rate survives, not even global ones.
	 * @param array<int, string>   $restricted Products that cannot ship to the destination (id → name).
	 * @param float|null           $max_weight Weight limit behind a `peso_max` cause.
	 */
	public function __construct(
		public readonly array $offered,
		public readonly array $rejected,
		public readonly ?string $cause,
		public readonly bool $blocked = false,
		public readonly array $restricted = array(),
		public readonly ?float $max_weight = null,
	) {}

	/**
	 * Whether an instance is offered.
	 *
	 * @param int $instance_id Instance id.
	 */
	public function offers( int $instance_id ): bool {
		return in_array( $instance_id, $this->offered, true );
	}
}
