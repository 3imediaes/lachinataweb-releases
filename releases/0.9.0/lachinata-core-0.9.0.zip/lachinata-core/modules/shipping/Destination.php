<?php
/**
 * Deprecated location of LaChinata\Core\Shipping\Destination.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping;

defined( 'ABSPATH' ) || exit;

// @deprecated 0.9.0 Moved to the core as LaChinata\Core\Shipping\Destination; this alias goes in 0.10.0.
class_alias( \LaChinata\Core\Shipping\Destination::class, __NAMESPACE__ . '\\Destination' );
