<?php
/**
 * Conditions in the settings of every shipping method instance.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping;

use LaChinata\Core\Hooks;
use LaChinata\Core\Shipping\Zones;

defined( 'ABSPATH' ) || exit;

/**
 * Adds the `lc_*` fields to the instance form of every method type that has instance
 * settings (flat rate, free shipping, live rates, third-party methods). WooCommerce saves
 * them with the rest of the instance settings. Admin only: the front end reads the
 * stored values directly.
 */
final class InstanceFields {

	/**
	 * Setting with the customer note of the instance.
	 */
	public const NOTE = 'lc_note';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_action( 'woocommerce_init', array( self::class, 'register' ), 20 );
	}

	/**
	 * Hooks the form of each method type.
	 */
	public static function register(): void {
		foreach ( array_keys( WC()->shipping()->get_shipping_method_class_names() ) as $method_id ) {
			Hooks::add_filter( 'woocommerce_shipping_instance_form_fields_' . $method_id, array( self::class, 'fields' ), 20 );
		}
	}

	/**
	 * Appends the condition fields.
	 *
	 * @param array<string, array<string, mixed>> $fields Instance fields.
	 * @return array<string, array<string, mixed>>
	 */
	public static function fields( array $fields ): array {
		$currency = html_entity_decode( get_woocommerce_currency_symbol() );
		$number   = array(
			'type'              => 'number',
			'default'           => '',
			'placeholder'       => '—',
			'desc_tip'          => true,
			'custom_attributes' => array(
				'min'  => '0',
				'step' => 'any',
			),
		);
		$classes  = self::class_options();

		return $fields + array(
			'lc_conditions'        => array(
				'title'       => __( 'Cuándo se ofrece (La Chinata)', 'lachinata-core' ),
				'type'        => 'title',
				'description' => __( 'Se ofrece si el pedido cumple todas las condiciones que rellenes. «Desde» incluye el valor; «menos de» no lo incluye.', 'lachinata-core' ),
			),
			'lc_weight_min'        => array(
				'title'       => __( 'Peso desde (kg)', 'lachinata-core' ),
				'description' => __( 'Se ofrece con este peso o más.', 'lachinata-core' ),
			) + $number,
			'lc_weight_max'        => array(
				'title'       => __( 'Peso menos de (kg)', 'lachinata-core' ),
				'description' => __( 'Se ofrece con menos de este peso.', 'lachinata-core' ),
			) + $number,
			'lc_amount_min_source' => array(
				'title'    => __( 'Importe mínimo', 'lachinata-core' ),
				'type'     => 'select',
				'default'  => '',
				'options'  => array(
					''                         => __( 'Sin mínimo', 'lachinata-core' ),
					'value'                    => __( 'Importe fijo (abajo)', 'lachinata-core' ),
					Conditions::ZONE_THRESHOLD => __( 'Umbral de envío gratis de la zona', 'lachinata-core' ),
				),
				'desc_tip' => __( 'El umbral de la zona se configura en WooCommerce → La Chinata → Envíos y es el mismo que anuncian la PromoBar, la UspBar y la bolsa.', 'lachinata-core' ),
			),
			'lc_amount_min'        => array(
				/* translators: %s: currency symbol. */
				'title'       => sprintf( __( 'Importe desde (%s)', 'lachinata-core' ), $currency ),
				'description' => __( 'Subtotal de productos con impuestos, después de descuentos y sin envío, como el envío gratuito de WooCommerce.', 'lachinata-core' ),
			) + $number,
			'lc_amount_max'        => array(
				/* translators: %s: currency symbol. */
				'title'       => sprintf( __( 'Importe menos de (%s)', 'lachinata-core' ), $currency ),
				'description' => __( 'Se ofrece con un importe menor que este.', 'lachinata-core' ),
			) + $number,
			'lc_ignore_discounts'  => array(
				'title'       => __( 'Descuentos', 'lachinata-core' ),
				'label'       => __( 'Comparar el importe antes de aplicar cupones de descuento', 'lachinata-core' ),
				'type'        => 'checkbox',
				'default'     => 'no',
				'description' => __( 'Como la opción del mismo nombre del envío gratuito de WooCommerce.', 'lachinata-core' ),
				'desc_tip'    => true,
			),
			'lc_classes_required'  => array(
				'title'       => __( 'Clases exigidas', 'lachinata-core' ),
				'type'        => 'multiselect',
				'class'       => 'wc-enhanced-select',
				'default'     => array(),
				'options'     => $classes,
				'description' => __( 'Se ofrece solo si el pedido lleva algún producto de una de estas clases.', 'lachinata-core' ),
				'desc_tip'    => true,
			),
			'lc_classes_excluded'  => array(
				'title'       => __( 'Clases excluidas', 'lachinata-core' ),
				'type'        => 'multiselect',
				'class'       => 'wc-enhanced-select',
				'default'     => array(),
				'options'     => $classes,
				'description' => __( 'No se ofrece si el pedido lleva algún producto de estas clases.', 'lachinata-core' ),
				'desc_tip'    => true,
			),
			'lc_priority'          => array(
				'title'             => __( 'Prioridad', 'lachinata-core' ),
				'type'              => 'number',
				'default'           => (string) Conditions::DEFAULT_PRIORITY,
				'description'       => __( 'Menor primero: ordena las opciones y decide quién oculta a quién.', 'lachinata-core' ),
				'desc_tip'          => true,
				'custom_attributes' => array( 'step' => '1' ),
			),
			'lc_hides'             => array(
				'title'       => __( 'Si se ofrece, oculta', 'lachinata-core' ),
				'type'        => 'multiselect',
				'class'       => 'wc-enhanced-select',
				'default'     => array(),
				'options'     => self::instance_options(),
				'description' => __( 'Por ejemplo, el envío gratis oculta el de pago. Solo cuenta dentro de la misma zona.', 'lachinata-core' ),
				'desc_tip'    => true,
			),
			self::NOTE             => array(
				'title'       => __( 'Nota para el cliente', 'lachinata-core' ),
				'type'        => 'text',
				'default'     => '',
				'placeholder' => __( 'Lleva productos frescos: va refrigerado y sale de lunes a miércoles.', 'lachinata-core' ),
				'description' => __( 'Se muestra en la bolsa cuando se elige este método y acompaña a la opción en el checkout.', 'lachinata-core' ),
				'desc_tip'    => true,
			),
		);
	}

	/**
	 * Shipping classes by slug.
	 *
	 * @return array<string, string>
	 */
	public static function class_options(): array {
		return Zones::class_options();
	}

	/**
	 * Instances grouped by zone, for the «hides» list.
	 *
	 * @return array<string, array<int, string>>
	 */
	private static function instance_options(): array {
		// Building the list creates method objects, whose constructors may ask for their
		// form fields again: return what there is while building, and build once.
		static $options = null, $building = false;
		if ( null !== $options || $building ) {
			return $options ?? array();
		}
		$building = true;
		$options  = array();
		foreach ( Config::zones() as $zone ) {
			$group = (string) $zone->get_zone_name();
			foreach ( $zone->get_shipping_methods() as $method ) {
				if ( $method instanceof \WC_Shipping_Method && $method->get_instance_id() ) {
					/* translators: 1: method title, 2: instance id. */
					$options[ $group ][ (int) $method->get_instance_id() ] = sprintf( __( '%1$s (ID %2$d)', 'lachinata-core' ), $method->get_title(), $method->get_instance_id() );
				}
			}
		}
		$building = false;
		return $options;
	}
}
