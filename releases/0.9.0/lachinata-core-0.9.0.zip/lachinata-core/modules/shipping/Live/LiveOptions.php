<?php
/**
 * Options of a «Tarifa en vivo» instance.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping\Live;

use LaChinata\Core\Modules\Shipping\Conditions;

defined( 'ABSPATH' ) || exit;

/**
 * Provider, surcharge, packaging, customs, fallback and the services shown. They belong to
 * the method, not to the provider, so they survive a change of provider (Octolize → MyDHL).
 */
final class LiveOptions {

	/**
	 * Keys of the instance settings.
	 */
	public const KEYS = array(
		'lc_live_provider',
		'lc_live_services',
		'lc_live_surcharge_percent',
		'lc_live_surcharge_fixed',
		'lc_live_box',
		'lc_live_box_weight',
		'lc_live_dutiable',
		'lc_live_fallback',
	);

	/**
	 * Builds the options.
	 *
	 * @param string                                            $provider          Provider id.
	 * @param string[]                                          $services          Service codes shown; empty shows all.
	 * @param float                                             $surcharge_percent Percentage added to the price.
	 * @param float                                             $surcharge_fixed   Amount added after the percentage.
	 * @param array{length: float, width: float, height: float} $box               Box measures in cm.
	 * @param float                                             $box_weight        Maximum kg per box.
	 * @param bool                                              $dutiable          Declare the shipment as dutiable.
	 * @param float|null                                        $fallback          Price when the provider gives nothing; null for no rate.
	 */
	public function __construct(
		public readonly string $provider,
		public readonly array $services = array(),
		public readonly float $surcharge_percent = 0.0,
		public readonly float $surcharge_fixed = 0.0,
		public readonly array $box = array(
			'length' => 40.0,
			'width'  => 40.0,
			'height' => 40.0,
		),
		public readonly float $box_weight = 10.0,
		public readonly bool $dutiable = false,
		public readonly ?float $fallback = null,
	) {}

	/**
	 * Options from the instance settings.
	 *
	 * @param array<string, mixed> $settings Instance settings.
	 */
	public static function from_settings( array $settings ): self {
		$parts = preg_split( '/\s*[x×*]\s*/iu', trim( (string) ( $settings['lc_live_box'] ?? '' ) ) );
		$box   = array_map( 'floatval', array_slice( array_pad( false === $parts ? array() : $parts, 3, '' ), 0, 3 ) );
		$codes = array_filter( array_map( 'trim', explode( ',', strtoupper( (string) ( $settings['lc_live_services'] ?? '' ) ) ) ) );
		$box_w = Conditions::number( $settings['lc_live_box_weight'] ?? null );

		return new self(
			(string) ( $settings['lc_live_provider'] ?? '' ),
			array_values( $codes ),
			Conditions::number( $settings['lc_live_surcharge_percent'] ?? null ) ?? 0.0,
			Conditions::number( $settings['lc_live_surcharge_fixed'] ?? null ) ?? 0.0,
			min( $box ) > 0 ? array(
				'length' => $box[0],
				'width'  => $box[1],
				'height' => $box[2],
			) : array(
				'length' => 40.0,
				'width'  => 40.0,
				'height' => 40.0,
			),
			null !== $box_w && $box_w > 0 ? $box_w : 10.0,
			'yes' === ( $settings['lc_live_dutiable'] ?? 'no' ),
			Conditions::number( $settings['lc_live_fallback'] ?? null )
		);
	}

	/**
	 * Price the customer pays for a service (before tax).
	 *
	 * @param Service $service  Service.
	 * @param int     $decimals Price decimals.
	 */
	public function price( Service $service, int $decimals = 2 ): float {
		return round( $service->price * ( 1 + $this->surcharge_percent / 100 ) + $this->surcharge_fixed, $decimals );
	}

	/**
	 * Whether a service is shown.
	 *
	 * @param Service $service Service.
	 */
	public function shows( Service $service ): bool {
		return ! $this->services || in_array( strtoupper( $service->code ), $this->services, true );
	}

	/**
	 * Parcels for a weight: as few boxes as the maximum weight per box allows, weight shared evenly.
	 *
	 * @param float $weight Total weight in kg.
	 * @return array<int, array{length: float, width: float, height: float, weight: float}>
	 */
	public function parcels( float $weight ): array {
		$count = max( 1, (int) ceil( $weight / $this->box_weight ) );
		return array_fill( 0, $count, $this->box + array( 'weight' => round( $weight / $count, 3 ) ) );
	}
}
