<?php
/**
 * «Tarifa en vivo»: a zone method whose price comes from a carrier.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping\Live;

defined( 'ABSPATH' ) || exit;

/**
 * An instance in a zone like any other (with its id for Odoo, conditions and delivery
 * time), whose services and prices come from the provider chosen in its settings.
 * Changing the provider keeps the instance id.
 */
final class LiveRateMethod extends \WC_Shipping_Method {

	/**
	 * Method type id.
	 */
	public const ID = 'lachinata_live';

	/**
	 * Sets the method up.
	 *
	 * @param int $instance_id Instance id.
	 */
	public function __construct( $instance_id = 0 ) {
		parent::__construct( $instance_id );
		$this->id                 = self::ID;
		$this->method_title       = __( 'Tarifa en vivo', 'lachinata-core' );
		$this->method_description = __( 'Precio y servicios de un transportista (DHL Express…) a través del proveedor que elijas. Las condiciones y el plazo se configuran como en cualquier otro método.', 'lachinata-core' );
		$this->supports           = array( 'shipping-zones', 'instance-settings', 'instance-settings-modal' );
		$this->init();
	}

	/**
	 * Loads the settings.
	 */
	public function init(): void {
		$this->instance_form_fields = $this->form_fields();
		$this->title                = (string) $this->get_option( 'title', $this->method_title );
		$this->tax_status           = (string) $this->get_option( 'tax_status', 'taxable' );
	}

	/**
	 * Instance fields.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	private function form_fields(): array {
		$providers = array( '' => __( 'Elige un proveedor', 'lachinata-core' ) );
		foreach ( LiveRates::providers() as $id => $provider ) {
			$providers[ $id ] = $provider->label();
		}
		$currency = html_entity_decode( get_woocommerce_currency_symbol() );

		return array(
			'title'                     => array(
				'title'   => __( 'Nombre', 'lachinata-core' ),
				'type'    => 'text',
				'default' => __( 'DHL Express', 'lachinata-core' ),
			),
			'tax_status'                => array(
				'title'   => __( 'Estado del impuesto', 'lachinata-core' ),
				'type'    => 'select',
				'class'   => 'wc-enhanced-select',
				'default' => 'taxable',
				'options' => array(
					'taxable' => __( 'Imponible', 'lachinata-core' ),
					'none'    => _x( 'Ninguno', 'Tax status', 'lachinata-core' ),
				),
			),
			'lc_live_provider'          => array(
				'title'       => __( 'Proveedor', 'lachinata-core' ),
				'type'        => 'select',
				'default'     => '',
				'options'     => $providers,
				'description' => __( 'Se puede cambiar sin cambiar el ID del método.', 'lachinata-core' ),
				'desc_tip'    => true,
			),
			'lc_live_services'          => array(
				'title'       => __( 'Servicios', 'lachinata-core' ),
				'type'        => 'text',
				'default'     => '',
				'placeholder' => __( 'Todos', 'lachinata-core' ),
				'description' => __( 'Códigos del transportista separados por comas (DHL: P, D…). Vacío: todos los que devuelva.', 'lachinata-core' ),
				'desc_tip'    => true,
			),
			'lc_live_surcharge_percent' => array(
				'title'             => __( 'Recargo (%)', 'lachinata-core' ),
				'type'              => 'number',
				'default'           => '',
				'placeholder'       => '0',
				'custom_attributes' => array( 'step' => 'any' ),
			),
			'lc_live_surcharge_fixed'   => array(
				/* translators: %s: currency symbol. */
				'title'             => sprintf( __( 'Recargo fijo (%s)', 'lachinata-core' ), $currency ),
				'type'              => 'number',
				'default'           => '',
				'placeholder'       => '0',
				'custom_attributes' => array( 'step' => 'any' ),
				'description'       => __( 'Se suma después del porcentaje.', 'lachinata-core' ),
				'desc_tip'          => true,
			),
			'lc_live_box'               => array(
				'title'       => __( 'Caja (cm)', 'lachinata-core' ),
				'type'        => 'text',
				'default'     => '40x40x40',
				'description' => __( 'Largo × ancho × alto de la caja con la que se pide la tarifa. Si el proveedor empaqueta por su cuenta, no se usa.', 'lachinata-core' ),
				'desc_tip'    => true,
			),
			'lc_live_box_weight'        => array(
				'title'             => __( 'Peso máximo por caja (kg)', 'lachinata-core' ),
				'type'              => 'number',
				'default'           => '10',
				'custom_attributes' => array(
					'min'  => '0',
					'step' => 'any',
				),
			),
			'lc_live_dutiable'          => array(
				'title'       => __( 'Aduanas', 'lachinata-core' ),
				'label'       => __( 'Declarar el envío con aranceles (dutiable)', 'lachinata-core' ),
				'type'        => 'checkbox',
				'default'     => 'no',
				'description' => __( 'Para envíos fuera de la UE. Si el proveedor lo gestiona por su cuenta, no se usa.', 'lachinata-core' ),
				'desc_tip'    => true,
			),
			'lc_live_fallback'          => array(
				/* translators: %s: currency symbol. */
				'title'             => sprintf( __( 'Precio si el transportista no responde (%s)', 'lachinata-core' ), $currency ),
				'type'              => 'number',
				'default'           => '',
				'placeholder'       => __( 'Sin tarifa', 'lachinata-core' ),
				'custom_attributes' => array(
					'min'  => '0',
					'step' => 'any',
				),
				'description'       => __( 'Vacío: si la API falla, el método no aparece.', 'lachinata-core' ),
				'desc_tip'          => true,
			),
		);
	}

	/**
	 * Asks the provider. Providers that read existing rates answer later, in LiveRates.
	 *
	 * @param array<string, mixed> $package WooCommerce package.
	 */
	public function calculate_shipping( $package = array() ): void {
		$options  = LiveOptions::from_settings( $this->instance_settings );
		$provider = LiveRates::provider( $options->provider );
		if ( null === $provider || $provider->reads_existing_rates() ) {
			return;
		}
		foreach ( LiveRates::rates_for( $this, $provider, $options, (array) $package, array() )['rates'] as $rate ) {
			$this->add_rate( $rate );
		}
	}
}
