<?php
/**
 * A provider could not quote.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping\Live;

defined( 'ABSPATH' ) || exit;

/**
 * Thrown by RateProvider::quote() when the carrier does not answer or refuses the request.
 */
final class RateException extends \RuntimeException {
}
