<?php
/**
 * Contract of a live rate provider.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping\Live;

defined( 'ABSPATH' ) || exit;

/**
 * A carrier API (or a plugin that talks to one) seen through one request and one response.
 * The «Tarifa en vivo» method asks the provider chosen in its settings, then applies the
 * generic options (surcharge, packaging, customs, fallback) the provider does not handle
 * itself. Providers are registered with the `lachinata/shipping/rate_providers` filter.
 */
interface RateProvider {

	/**
	 * Stable id stored in the instance settings.
	 */
	public function id(): string;

	/**
	 * Name for the admin screens.
	 */
	public function label(): string;

	/**
	 * Generic options the provider applies on its own side (`packaging`, `customs`), so
	 * the method does not apply them again and the screen says where they are set.
	 *
	 * @return string[]
	 */
	public function handles(): array;

	/**
	 * Whether the provider reads the rates other methods already calculated for the package
	 * (adapters over an existing plugin). Those providers are asked after every method ran.
	 */
	public function reads_existing_rates(): bool;

	/**
	 * Services with price and delivery time for the request.
	 *
	 * @param RateRequest $request Request.
	 * @throws RateException When the carrier cannot answer.
	 */
	public function quote( RateRequest $request ): RateResponse;
}
