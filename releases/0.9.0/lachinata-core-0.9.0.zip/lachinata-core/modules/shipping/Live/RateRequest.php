<?php
/**
 * What a live rate provider is asked.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping\Live;

defined( 'ABSPATH' ) || exit;

/**
 * Origin, destination, weight, parcels with their measures, declared value and options.
 */
final class RateRequest {

	/**
	 * Builds the request.
	 *
	 * @param array{country: string, state: string, postcode: string, city: string}        $origin         Store address.
	 * @param array{country: string, state: string, postcode: string, city: string}        $destination    Delivery address.
	 * @param float                                                                        $weight         Total weight in kg.
	 * @param array<int, array{length: float, width: float, height: float, weight: float}> $parcels        Parcels in cm and kg.
	 * @param float                                                                        $value          Declared value (product subtotal).
	 * @param string                                                                       $currency       Currency of the value and of the expected prices.
	 * @param bool                                                                         $dutiable       Whether the shipment pays import duties (customs).
	 * @param array<string, \WC_Shipping_Rate>                                             $existing_rates Rates other methods calculated, for providers that read them.
	 */
	public function __construct(
		public readonly array $origin,
		public readonly array $destination,
		public readonly float $weight,
		public readonly array $parcels,
		public readonly float $value,
		public readonly string $currency,
		public readonly bool $dutiable = false,
		public readonly array $existing_rates = array(),
	) {}
}
