<?php
/**
 * A live rate provider's answer.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping\Live;

defined( 'ABSPATH' ) || exit;

/**
 * Services offered and, for providers that read existing rates, the ids of the rates they
 * took over (the method removes them, so the customer sees each service once).
 */
final class RateResponse {

	/**
	 * Builds the response.
	 *
	 * @param Service[] $services Services.
	 * @param string[]  $consumed Ids of existing rates the response replaces.
	 */
	public function __construct(
		public readonly array $services,
		public readonly array $consumed = array(),
	) {}
}
