<?php
/**
 * One service in a provider's answer.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping\Live;

defined( 'ABSPATH' ) || exit;

/**
 * Service code and name, price, currency and delivery time in days when the carrier gives it.
 */
final class Service {

	/**
	 * Builds the service.
	 *
	 * @param string      $code     Carrier service code (DHL «P», «D»…).
	 * @param string      $name     Service name.
	 * @param float       $price    Price before the method's surcharge, without tax.
	 * @param string      $currency Currency of the price.
	 * @param int|null    $days_min Minimum transit days, when the carrier gives them.
	 * @param int|null    $days_max        Maximum transit days, when the carrier gives them.
	 * @param string|null $fallback_reason Set when the price is not the carrier's but a reserve
	 *                                     price of the provider, with the reason the carrier gave.
	 */
	public function __construct(
		public readonly string $code,
		public readonly string $name,
		public readonly float $price,
		public readonly string $currency,
		public readonly ?int $days_min = null,
		public readonly ?int $days_max = null,
		public readonly ?string $fallback_reason = null,
	) {}
}
