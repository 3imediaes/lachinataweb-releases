<?php
/**
 * What the customer reads when a package gets no shipping method.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping;

use LaChinata\Core\Shipping\Package;
use LaChinata\Core\Shipping\Destination;

defined( 'ABSPATH' ) || exit;

/**
 * Message for a cause: the zone's own text, with {peso}, {max}, {pais} and {producto}
 * replaced, or a default sentence. Plain text: whoever prints it escapes it.
 */
final class Messages {

	/**
	 * Placeholders a zone message may use.
	 */
	public const PLACEHOLDERS = array( '{peso}', '{max}', '{pais}', '{producto}' );

	/**
	 * Message for a decision with a cause, or '' when there is no cause.
	 *
	 * @param Decision          $decision Decision.
	 * @param Package           $package  Package.
	 * @param ZoneRules         $rules    Zone rules.
	 * @param \WC_Shipping_Zone $zone     Zone.
	 */
	public static function for_decision( Decision $decision, Package $package, ZoneRules $rules, \WC_Shipping_Zone $zone ): string {
		if ( null === $decision->cause ) {
			return '';
		}
		$values = array(
			'{peso}'     => self::weight( $package->weight ),
			'{max}'      => null === $decision->max_weight ? '' : self::weight( $decision->max_weight ),
			'{pais}'     => Destination::name( $package->country, $package->state, $zone ),
			'{producto}' => wp_sprintf_l( '%l', array_values( $decision->restricted ) ),
		);

		$custom = $rules->message( $decision->cause );
		if ( '' === $custom && 'sin_metodo' !== $decision->cause ) {
			// The generic message of the zone is the fallback of every cause.
			$custom = $rules->message( 'sin_metodo' );
		}
		if ( '' !== $custom ) {
			return strtr( $custom, $values );
		}
		return self::default_text( $decision, $values );
	}

	/**
	 * Default sentence of a cause.
	 *
	 * @param Decision              $decision Decision.
	 * @param array<string, string> $values   Placeholder values.
	 */
	private static function default_text( Decision $decision, array $values ): string {
		switch ( $decision->cause ) {
			case 'zona_no_cubierta':
				/* translators: %s: country or region. */
				return sprintf( __( 'Todavía no enviamos a %s.', 'lachinata-core' ), $values['{pais}'] );
			case 'producto_restringido':
				return sprintf(
					/* translators: 1: product names, 2: country or region. */
					_n( '%1$s no se puede enviar a %2$s. Quítalo de la bolsa o cambia la dirección de entrega.', '%1$s no se pueden enviar a %2$s. Quítalos de la bolsa o cambia la dirección de entrega.', count( $decision->restricted ), 'lachinata-core' ),
					$values['{producto}'],
					$values['{pais}']
				);
			case 'peso_max':
				if ( '' === $values['{max}'] ) {
					/* translators: 1: order weight, 2: country or region. */
					return sprintf( __( 'No podemos enviar %1$s a %2$s. Divide el pedido en dos o escríbenos y lo organizamos contigo.', 'lachinata-core' ), $values['{peso}'], $values['{pais}'] );
				}
				/* translators: 1: order weight, 2: country or region, 3: maximum weight. */
				return sprintf( __( 'No podemos enviar %1$s a %2$s: el máximo son %3$s. Divide el pedido en dos o escríbenos y lo organizamos contigo.', 'lachinata-core' ), $values['{peso}'], $values['{pais}'], $values['{max}'] );
			case 'importe':
				/* translators: %s: country or region. */
				return sprintf( __( 'No hay ningún envío a %s para el importe de tu pedido. Escríbenos y lo organizamos contigo.', 'lachinata-core' ), $values['{pais}'] );
			default:
				/* translators: %s: country or region. */
				return sprintf( __( 'No encontramos un envío para tu pedido a %s. Escríbenos y lo organizamos contigo.', 'lachinata-core' ), $values['{pais}'] );
		}
	}

	/**
	 * «30 kg», «2,5 kg».
	 *
	 * @param float $kg Weight in kg.
	 */
	public static function weight( float $kg ): string {
		$decimals = abs( $kg - round( $kg ) ) < 0.05 ? 0 : 1;
		/* translators: %s: weight in kilograms. */
		return sprintf( __( '%s kg', 'lachinata-core' ), number_format_i18n( $kg, $decimals ) );
	}

	/**
	 * Labels of the causes for the admin screens.
	 *
	 * @return array<string, string>
	 */
	public static function cause_labels(): array {
		return array(
			'zona_no_cubierta'     => __( 'Zona no cubierta', 'lachinata-core' ),
			'producto_restringido' => __( 'Producto restringido en el destino', 'lachinata-core' ),
			'peso_max'             => __( 'Peso por encima del máximo', 'lachinata-core' ),
			'importe'              => __( 'Importe fuera de los límites', 'lachinata-core' ),
			'sin_metodo'           => __( 'Mensaje genérico (ningún método aplica)', 'lachinata-core' ),
		);
	}
}
