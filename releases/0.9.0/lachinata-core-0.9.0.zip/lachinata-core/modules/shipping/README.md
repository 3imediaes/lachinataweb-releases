# Módulo `shipping`

Capa sobre las zonas y métodos de WooCommerce: no los sustituye. Cada tienda crea sus zonas y métodos en WooCommerce → Ajustes → Envío, con sus IDs de instancia (los que lee Odoo), y el módulo añade:

- **Condiciones por instancia** (panel de cada método, cualquier tipo): peso desde / menos de, importe mínimo (fijo o umbral de la zona) y máximo con la semántica del envío gratuito de WooCommerce, clases exigidas y excluidas, prioridad, «si se ofrece, oculta» y nota para el cliente. Claves `lc_*` en los ajustes de la instancia.
- **Por zona** (La Chinata → Envíos): peso máximo, umbral de envío gratis, aviso informativo y mensaje por causa (`zona_no_cubierta`, `producto_restringido`, `peso_max`, `importe`, `sin_metodo`). Opción `lachinata_shipping_zones`.
- **Restricciones de producto por destino**: clase de envío o `_lc_excluir_internacional`, con lugares permitidos y excepciones. Opción `lachinata_shipping_restrictions`.
- **Tarifas en vivo**: tipo de método «Tarifa en vivo» (`lachinata_live`) con proveedor seleccionable detrás de `Live\RateProvider`.

Especificación: `design-system/sistema/04-envios-entrega.md`. Paso a producción: `docs/despliegue-envios.md`. Huecos del tema que rellena: `theme/HOOKS.md`.

## Qué hace

Lo resumido arriba, con estas piezas: `Rates` y `Evaluator` (decisión en `woocommerce_package_rates`), `Storefront` (bolsa, `PromoBar`, `UspBar`, notas de línea), `StoreApi` (datos `lachinata-shipping` para el checkout), `Live\*` (tarifa en vivo), `Shippable` (si un producto viaja a un destino), `Simulator`/`SimulateCommand` (probador en el panel y `wp lachinata shipping simulate`), `ConflictNotice` (aviso de plugins que se solapan) y `ShippingTab`. Sirve `Contracts\ShippingRules` (`Rules.php`) a `eta` y a `lachinata_producto_enviable()`.

Desde la 0.9.0, `Package`, `Destination` y la lectura de zonas e instancias (`Zones`) son utilidades del núcleo (`plugin/src/Shipping/`); los nombres antiguos quedan como alias hasta la 0.10.0.

## Orden en `woocommerce_package_rates`
1. Prioridad 5, `Live\LiveRates`: los proveedores que leen tarifas existentes (Octolize) se quedan con la suya y la devuelven bajo la instancia «Tarifa en vivo» de la zona.
2. Prioridad 20, `Rates`: decisión del `Evaluator` (condiciones, prioridad, ocultación, causas).
3. Prioridad 30, módulo `eta`: fecha en cada tarifa.

## Proveedor DHL Express de Octolize
Verificado con **Shipping Live Rates for DHL Express PRO 4.3.14** (`tools/plugins-terceros/`, fuera de Git).

- **Cómo se integra: captura.** Octolize se deja como método **global** (su ajuste «Activar método de envío» en sí) con su recargo a 0 %. WooCommerce calcula su tarifa como siempre y el adaptador (`Live\OctolizeDhlProvider`) la toma: quita `flexible_shipping_dhl_express:0:<servicio>` y añade `lachinata_live:<instancia>:<servicio>` con el recargo, la caja, las aduanas y el precio de reserva de la instancia. Fuera de la zona de la instancia, la tarifa de Octolize se quita sin sustituirla.
- **Lo que se lee de su tarifa**: `method_id` = `flexible_shipping_dhl_express` (su `UNIQUE_ID`, filtrable con `lachinata/shipping/octolize_method_ids`); el servicio, del final del ID de tarifa; `business_days_in_transit`, cuando DHL lo da, pasa como plazo a `eta` (manda sobre los días de la instancia); `fallback_reason` marca su precio de reserva.
- **Precio de reserva**: si la instancia tiene el suyo, se usa el de la instancia y el de Octolize se descarta; si no, se usa el de Octolize (con el recargo). En los dos casos el motivo que dio DHL queda en Huecos de configuración. Recomendado: reserva en la instancia (sobrevive al cambio de proveedor) y la de Octolize apagada.
- **Sin tarifa**: si Octolize no devuelve nada, Huecos de configuración lo anota con los métodos buscados y los IDs de tarifa presentes en el paquete. Si la zona solo ofrecía la tarifa en vivo, el cliente ve `zona_no_cubierta` con el mensaje de la zona.
- **Configuración incompleta de Octolize = error fatal.** Sin número de cuenta, su constructor de peticiones REST lanza un `TypeError` que su código no captura (solo captura `Exception`) y tumba la petición del carrito. Cuenta, clave y secreto deben estar completos antes de activar su método global.
- **Por qué no se ejecuta su cálculo por dentro.** Es posible (`DhlExpressProShippingMethod::calculate_shipping()` es pública y deja las tarifas en `$rates`), pero solo calcula con su método activo, así que WooCommerce lo calcularía igualmente (doble llamada a DHL) o habría que sacarlo de `woocommerce_shipping_methods`; además ataría el módulo a su espacio de nombres prefijado (`FlexibleShippingDhlExpressProVendor\…`), que cambia con cada compilación. La captura obtiene lo mismo (caché de sesión, empaquetado, aduanas, reserva y plazos de Octolize) dependiendo solo del ID del método. Lo único que daría la ejecución interna es envolver su cálculo en un `try/catch` de `Throwable`, y eso se cubre con la configuración completa.
- Octolize también puede ir como instancia de zona (con su método global desactivado), pero tendría su propio ID de instancia y Odoo cambiaría al pasar a MyDHL: se descarta.

Probar en local: `wp plugin install /var/www/html/lachinata/tools/plugins-terceros/flexible-shipping-dhl-express-pro.zip --activate` en el contenedor `cli` de wp-env. Sin credenciales de DHL no hay tarifa real; para ver la captura se activa el precio de reserva de Octolize (cuenta, clave y secreto ficticios: DHL rechaza la petición y Octolize devuelve su reserva). Licencia y credenciales reales, en `.wp-env.override.json`.

## Añadir un proveedor
Una clase que implemente `Live\RateProvider` (petición: origen, destino, peso, bultos, valor, moneda, aduanas; respuesta: servicios con precio, moneda y plazo) registrada con `lachinata/shipping/rate_providers`. Si llama a la API (MyDHL), `reads_existing_rates()` devuelve `false` y el método la consulta en `calculate_shipping()`; cambiar el proveedor de la instancia no cambia su ID.

## Depende de

Ningún módulo. WooCommerce 10. La marca «excluir internacional» de un producto llega de `catalog` por el filtro `lachinata/catalog/no_ship_abroad`: sin `catalog`, solo cuentan las clases de envío. Octolize (DHL Express) es opcional, detrás del adaptador.

## Hooks que escucha

- `woocommerce_package_rates` (prioridades 5 y 20), `woocommerce_shipping_methods` («Tarifa en vivo»), `woocommerce_shipping_instance_form_fields_<método>` (condiciones de cada instancia), `woocommerce_no_shipping_available_html` y su versión de la bolsa, `woocommerce_store_api_cart_errors` (bloquea el pedido sin envío), `woocommerce_blocks_loaded` (Store API), `woocommerce_screen_ids`, `pre_get_posts`, `wp_enqueue_scripts`, `admin_notices`.
- Del tema: `lachinata/cart/line_note`, `lachinata/cart/notices`, `lachinata/cart/shipping_summary`, `lachinata/promo_bar/messages`, `lachinata/usp/items`.
- Del núcleo: `lachinata/shipping/service` (lo sirve), `lachinata/shipping/changed` (olvida lo memorizado), `lachinata/rest/order`, `lachinata/core/admin_tabs`.

## Hooks que emite

| Hook | Tipo | Para qué |
| --- | --- | --- |
| `lachinata/shipping/rate_providers` | filtro | Proveedores de tarifa en vivo |
| `lachinata/shipping/octolize_method_ids` | filtro | Métodos que toma el adaptador de Octolize |
| `lachinata/shipping/conflicting_plugins` | filtro | Plugins que se solapan (aviso) |
| `lachinata/shipping/simulation_eta` | filtro | Plazo en el probador (lo rellena `eta`) |

Catálogo con versiones: `plugin/HOOKS.md`.

## Datos que guarda

- Opciones: `lachinata_shipping_zones` (reglas por zona), `lachinata_shipping_restrictions`, `lachinata_shipping_default_zone`, registro de huecos `lachinata_shipping_gaps`.
- Claves `lc_*` dentro de los ajustes de cada instancia de WooCommerce (`woocommerce_<método>_<id>_settings`): se van con la instancia. «Borrar datos» no las toca (son ajustes de WooCommerce).
- Metadato de la línea de envío del pedido: `_lc_live` (proveedor y servicio de la tarifa en vivo).

## REST y API para Odoo

- `lachinata.shipping.live` del objeto de la API de pedidos (`docs/api-odoo.md`). Odoo asocia el transportista por el ID de instancia, que el módulo nunca cambia.
- Datos de la Store API `lachinata-shipping` en la bolsa (motivo, envío gratis, productos que no viajan, envíos no disponibles).

## Ajustes y exportación

| Ajuste | Por defecto | En el JSON |
| --- | --- | --- |
| Zona por defecto para un destino desconocido (`default_zone`) | 0 (resto del mundo) | sí |

`export_data()` lleva las reglas de zona, las restricciones y las condiciones `lc_*` de cada instancia por su ID. Al importar, cada instancia debe existir en el sitio con el mismo tipo de método.

## Qué pasa al apagarlo

WooCommerce vuelve a ofrecer sus zonas y métodos tal cual: sin condiciones, sin límites de peso, sin mensajes de «sin envío» propios y sin «Tarifa en vivo» (sus instancias dejan de calcular; Octolize, si está, vuelve a mostrar su propia tarifa). `eta` se apaga con él (lo necesita). `lachinata_producto_enviable()` responde `true`. Las reglas y las claves `lc_*` se quedan.

## Pruebas

- `tests/EvaluatorTest.php` (tabla de decisión) y `tests/StorefrontTest.php` (bolsa, avisos, Store API).
- La configuración de lachinata.es con `eta` (zonas e IDs de producción, pesos, envíos no disponibles, tarifa en vivo): `tests/profiles/LaChinataEsTest.php`, que corre en los perfiles `es` y `all`.
- Canarias y CZ sintéticos: `tests/profiles/StoreProfileTest.php`.

## Huecos conocidos

- Precios, plazos, cortes y días del frío provisionales hasta que logística valide el xlsx.
- Exclusión internacional duplicada (clase y campo): pendiente de decidir cuál manda.
- Octolize con la configuración incompleta tumba la petición del carrito (abajo, «Proveedor DHL Express de Octolize»): su `TypeError` ocurre en su método, fuera del envoltorio de los módulos.
