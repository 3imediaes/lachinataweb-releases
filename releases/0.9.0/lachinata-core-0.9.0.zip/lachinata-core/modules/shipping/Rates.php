<?php
/**
 * Applies the decision to WooCommerce's rates and explains an empty result.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping;

use LaChinata\Core\GapLog;
use LaChinata\Core\Hooks;
use LaChinata\Core\Shipping\Package;
use LaChinata\Core\Shipping\Destination;

defined( 'ABSPATH' ) || exit;

/**
 * `woocommerce_package_rates`: keeps the rates of the offered instances in their order.
 * Rates of global methods (instance 0) pass unless the package is blocked. When no rate
 * is left, the cause message replaces WooCommerce's generic text in the classic cart and
 * goes to the Store API as a cart error, which the block cart and checkout show.
 */
final class Rates {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		Hooks::add_filter( 'woocommerce_package_rates', array( self::class, 'filter' ), 20, 2 );
		Hooks::add_filter( 'woocommerce_cart_no_shipping_available_html', array( self::class, 'no_shipping_html' ) );
		Hooks::add_filter( 'woocommerce_no_shipping_available_html', array( self::class, 'no_shipping_html' ) );
		Hooks::add_action( 'woocommerce_store_api_cart_errors', array( self::class, 'cart_errors' ), 10, 2 );
	}

	/**
	 * Gap log of the module.
	 */
	public static function gaps(): GapLog {
		return new GapLog( 'lachinata_shipping_gaps', 'lachinata-shipping' );
	}

	/**
	 * Keeps the rates of the offered instances.
	 *
	 * @param array<string, \WC_Shipping_Rate> $rates   Rates by id.
	 * @param array<string, mixed>             $package WooCommerce package.
	 * @return array<string, \WC_Shipping_Rate>
	 */
	public static function filter( array $rates, array $package ): array {
		list( $decision, $zone ) = Config::evaluate( Package::from_wc( $package ) );
		self::remember_unavailable( $decision, $rates );
		if ( $decision->blocked ) {
			return array();
		}

		$order   = array_flip( $decision->offered );
		$methods = $zone->get_shipping_methods();
		$kept    = array();
		foreach ( $rates as $id => $rate ) {
			$instance = (int) $rate->get_instance_id();
			if ( 0 !== $instance && ! isset( $order[ $instance ] ) ) {
				continue;
			}
			$note = isset( $methods[ $instance ] ) ? trim( (string) ( Config::instance_settings( $methods[ $instance ] )[ InstanceFields::NOTE ] ?? '' ) ) : '';
			if ( '' !== $note ) {
				$rate->set_description( $note );
			}
			$kept[ $id ] = $rate;
		}
		uasort(
			$kept,
			static fn( \WC_Shipping_Rate $a, \WC_Shipping_Rate $b ): int => ( $order[ (int) $a->get_instance_id() ] ?? PHP_INT_MAX ) <=> ( $order[ (int) $b->get_instance_id() ] ?? PHP_INT_MAX )
		);

		if ( ! $kept && $decision->offered ) {
			// The rules offer something but the methods gave no rate (a live rate failed).
			self::record_gap( $zone, $package, __( 'Los métodos que aplican no devolvieron tarifa.', 'lachinata-core' ) );
		} elseif ( 'sin_metodo' === $decision->cause ) {
			self::record_gap( $zone, $package, __( 'Ningún método aplica al pedido.', 'lachinata-core' ) );
		}
		return $kept;
	}

	/**
	 * Session key of the rates the weight limit leaves out.
	 */
	private const UNAVAILABLE = 'lachinata_shipping_unavailable';

	/**
	 * Keeps, in the session, the rates a weight limit leaves out with their price and the
	 * reason, so the checkout can show them disabled («No disponible: supera los 25 kg»).
	 * WooCommerce caches rates per package in the session, so they are kept next to them.
	 *
	 * @param Decision                         $decision Decision.
	 * @param array<string, \WC_Shipping_Rate> $rates    Rates before the decision.
	 */
	private static function remember_unavailable( Decision $decision, array $rates ): void {
		if ( ! WC()->session ) {
			return;
		}
		$unavailable = array();
		if ( $decision->blocked && 'peso_max' === $decision->cause && null !== $decision->max_weight ) {
			$cart = WC()->cart;
			$tax  = $cart instanceof \WC_Cart && $cart->display_prices_including_tax();
			foreach ( $rates as $rate ) {
				$cost          = (float) $rate->get_cost() + ( $tax ? (float) array_sum( $rate->get_taxes() ) : 0.0 );
				$unavailable[] = array(
					'title'  => (string) $rate->get_label(),
					'cost'   => $cost,
					/* translators: %s: maximum weight («25 kg»). */
					'reason' => sprintf( __( 'No disponible: supera los %s', 'lachinata-core' ), Messages::weight( $decision->max_weight ) ),
				);
			}
		}
		WC()->session->set( self::UNAVAILABLE, $unavailable );
	}

	/**
	 * Rates the weight limit left out in the last calculation.
	 *
	 * @return array<int, array{title: string, cost: float, reason: string}>
	 */
	public static function unavailable(): array {
		if ( null === self::current_cause() || ! WC()->session ) {
			return array();
		}
		return (array) WC()->session->get( self::UNAVAILABLE, array() );
	}

	/**
	 * Cause message, or the original text when the cart has no address yet.
	 *
	 * @param string $html WooCommerce's text.
	 */
	public static function no_shipping_html( string $html ): string {
		$message = self::current_message();
		return '' === $message ? $html : '<p>' . esc_html( $message ) . '</p>';
	}

	/**
	 * Store API: the cause as a cart error when the customer has an address and no rate.
	 *
	 * @param \WP_Error $errors Errors.
	 * @param \WC_Cart  $cart   Cart.
	 */
	public static function cart_errors( \WP_Error $errors, \WC_Cart $cart ): void {
		if ( ! $cart->needs_shipping() ) {
			return;
		}
		$found = self::current_cause();
		if ( null !== $found ) {
			$errors->add( 'lachinata_shipping_' . $found['cause'], $found['message'] );
		}
	}

	/**
	 * Message for the first cart package that has no rate.
	 */
	public static function current_message(): string {
		$found = self::current_cause();
		return null === $found ? '' : $found['message'];
	}

	/**
	 * Cause and message for the first cart package left without rates, when the customer
	 * has given a destination.
	 *
	 * @return array{cause: string, message: string, restricted: array<int, string>}|null
	 */
	public static function current_cause(): ?array {
		if ( null === Destination::customer() ) {
			return null;
		}
		foreach ( self::packages() as $package ) {
			if ( ! empty( $package['rates'] ) || empty( $package['contents'] ) ) {
				continue;
			}
			list( $decision, $zone, $rules, $evaluated ) = Config::evaluate( Package::from_wc( $package ) );
			if ( null === $decision->cause ) {
				// The rules offered something but no rate came back. If all of it was live
				// rates, the carrier does not serve the destination right now.
				$decision = new Decision( array(), $decision->rejected, self::only_live( $zone, $decision->offered ) ? 'zona_no_cubierta' : 'sin_metodo' );
			}
			return array(
				'cause'      => (string) $decision->cause,
				'message'    => Messages::for_decision( $decision, $evaluated, $rules, $zone ),
				'restricted' => $decision->restricted,
			);
		}
		return null;
	}

	/**
	 * Whether every instance in the list is a «Tarifa en vivo».
	 *
	 * @param \WC_Shipping_Zone $zone      Zone.
	 * @param int[]             $instances Instance ids.
	 */
	private static function only_live( \WC_Shipping_Zone $zone, array $instances ): bool {
		$methods = $zone->get_shipping_methods();
		foreach ( $instances as $id ) {
			if ( ! isset( $methods[ $id ] ) || Live\LiveRateMethod::ID !== $methods[ $id ]->id ) {
				return false;
			}
		}
		return (bool) $instances;
	}

	/**
	 * Cart packages with their rates. Pages that print the bag without the cart shortcode
	 * (the theme's bag and sheet) never calculate shipping in the request: it is done
	 * here once, the same calculation the cart page does.
	 *
	 * @return array<int|string, array<string, mixed>>
	 */
	public static function packages(): array {
		$cart = WC()->cart;
		if ( $cart instanceof \WC_Cart && ! WC()->shipping()->get_packages() && $cart->needs_shipping() && ! did_action( 'woocommerce_after_calculate_totals' ) ) {
			$cart->calculate_totals();
		}
		return WC()->shipping()->get_packages();
	}

	/**
	 * Logs a package the configuration does not cover.
	 *
	 * @param \WC_Shipping_Zone    $zone    Zone.
	 * @param array<string, mixed> $package WooCommerce package.
	 * @param string               $reason  What happened.
	 */
	private static function record_gap( \WC_Shipping_Zone $zone, array $package, string $reason ): void {
		$evaluated = Package::from_wc( $package );
		$classes   = $evaluated->classes();
		sort( $classes );
		self::gaps()->record(
			implode( '|', array( $zone->get_id(), $evaluated->location(), implode( ',', $classes ), floor( $evaluated->weight ), floor( $evaluated->amount / 10 ) ) ),
			$reason,
			array(
				'zone'    => (string) $zone->get_zone_name(),
				'destino' => $evaluated->location(),
				'peso'    => $evaluated->weight,
				'importe' => $evaluated->amount,
				'clases'  => implode( ', ', $classes ),
			)
		);
	}
}
