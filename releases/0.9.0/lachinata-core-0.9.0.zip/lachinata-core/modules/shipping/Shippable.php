<?php
/**
 * Whether one product can ship to a destination.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping;

use LaChinata\Core\Shipping\Package;

defined( 'ABSPATH' ) || exit;

/**
 * The part of the decision that depends on the product alone: restrictions, a zone
 * without methods and the zone's maximum weight. Amount and the instance conditions
 * depend on the whole order and are left to the cart.
 */
final class Shippable {

	/**
	 * True, or the reason the product cannot ship there.
	 *
	 * @param \WC_Product                                               $product     Product or variation.
	 * @param array{country: string, state?: string, postcode?: string} $destination Destination.
	 * @return true|string
	 */
	public static function check( \WC_Product $product, array $destination ): true|string {
		if ( ! $product->needs_shipping() ) {
			return true;
		}
		$country = strtoupper( $destination['country'] );
		$state   = strtoupper( $destination['state'] ?? '' );
		$entry   = Package::product_entry( $product, (float) wc_get_weight( (float) $product->get_weight(), 'kg' ) );

		foreach ( Config::restrictions() as $restriction ) {
			if ( $restriction->applies_to( $entry ) && ! $restriction->allows( $country, $state ) ) {
				return 'producto_restringido';
			}
		}

		$zone = Config::zone_for( $destination );
		if ( ! Config::candidates( $zone ) ) {
			return 'zona_no_cubierta';
		}
		$max = Config::zone_rules( (int) $zone->get_id() )->max_weight;
		if ( null !== $max && $entry['weight'] > $max ) {
			return 'peso_max';
		}
		return true;
	}
}
