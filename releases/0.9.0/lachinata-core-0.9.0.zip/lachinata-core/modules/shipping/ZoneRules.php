<?php
/**
 * Limits and messages of a shipping zone.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Modules\Shipping;

defined( 'ABSPATH' ) || exit;

/**
 * What the module adds to a WooCommerce zone: maximum weight, free shipping threshold,
 * an informative notice and one message per cause when no method applies.
 */
final class ZoneRules {

	/**
	 * Causes of «no shipping method», in order of precedence. `sin_metodo` is internal:
	 * the configuration does not cover the package; the customer sees the zone's generic message.
	 */
	public const CAUSES = array( 'zona_no_cubierta', 'producto_restringido', 'peso_max', 'importe', 'sin_metodo' );

	/**
	 * Builds the rules.
	 *
	 * @param int                   $zone_id        WooCommerce zone id (0 = rest of the world).
	 * @param float|null            $max_weight     Maximum weight in kg (included).
	 * @param float|null            $free_threshold Free shipping threshold.
	 * @param string                $notice         Informative notice for the zone.
	 * @param array<string, string> $messages       Message per cause; empty uses the default text.
	 */
	public function __construct(
		public readonly int $zone_id,
		public readonly ?float $max_weight = null,
		public readonly ?float $free_threshold = null,
		public readonly string $notice = '',
		public readonly array $messages = array(),
	) {}

	/**
	 * Rules from their stored form.
	 *
	 * @param int                  $zone_id Zone id.
	 * @param array<string, mixed> $data    Stored rules.
	 */
	public static function from_array( int $zone_id, array $data ): self {
		$messages = array();
		foreach ( self::CAUSES as $cause ) {
			$text = trim( (string) ( $data['messages'][ $cause ] ?? '' ) );
			if ( '' !== $text ) {
				$messages[ $cause ] = $text;
			}
		}
		return new self(
			$zone_id,
			Conditions::number( $data['max_weight'] ?? null ),
			Conditions::number( $data['free_threshold'] ?? null ),
			trim( (string) ( $data['notice'] ?? '' ) ),
			$messages
		);
	}

	/**
	 * Stored form.
	 *
	 * @return array{max_weight: float|null, free_threshold: float|null, notice: string, messages: array<string, string>}
	 */
	public function to_array(): array {
		return array(
			'max_weight'     => $this->max_weight,
			'free_threshold' => $this->free_threshold,
			'notice'         => $this->notice,
			'messages'       => $this->messages,
		);
	}

	/**
	 * Custom message for a cause, or '' to use the default text.
	 *
	 * @param string $cause Cause.
	 */
	public function message( string $cause ): string {
		return $this->messages[ $cause ] ?? '';
	}
}
