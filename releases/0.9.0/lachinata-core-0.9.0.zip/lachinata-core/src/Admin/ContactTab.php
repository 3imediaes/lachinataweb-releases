<?php
/**
 * WooCommerce → La Chinata → Atención al cliente.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Admin;

use LaChinata\Core\Contact;

defined( 'ABSPATH' ) || exit;

/**
 * Phone, WhatsApp, email and opening hours of the shop (Contact). The address is not here:
 * it is the shop's address in WooCommerce → Ajustes → Generales.
 */
final class ContactTab {

	/**
	 * Tab id.
	 */
	public const TAB = 'contact';

	/**
	 * Action of admin-post.php, also the nonce action.
	 */
	private const SAVE = 'lachinata_core_contact';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_filter( 'lachinata/core/admin_tabs', array( self::class, 'tab' ), 5 );
		add_action( 'admin_post_' . self::SAVE, array( self::class, 'handle' ) );
	}

	/**
	 * Adds the tab after Módulos.
	 *
	 * @param array<string, array{label: string, render: callable}> $tabs Tabs.
	 * @return array<string, array{label: string, render: callable}>
	 */
	public static function tab( array $tabs ): array {
		$tab = array(
			self::TAB => array(
				'label'  => __( 'Atención al cliente', 'lachinata-core' ),
				'render' => array( self::class, 'render' ),
			),
		);
		return array_slice( $tabs, 0, 1, true ) + $tab + $tabs;
	}

	/**
	 * Prints the tab.
	 */
	public static function render(): void {
		$values = Contact::get();
		$fields = array(
			'phone'    => array(
				'label' => __( 'Teléfono', 'lachinata-core' ),
				'type'  => 'tel',
				'hint'  => __( 'Como lo leerá el cliente: 927 00 00 00. Sin prefijo, se usa el del país de la tienda.', 'lachinata-core' ),
				'ph'    => '927 00 00 00',
			),
			'whatsapp' => array(
				'label' => __( 'WhatsApp', 'lachinata-core' ),
				'type'  => 'tel',
				'hint'  => __( 'El número que atiende WhatsApp. Es también el remitente de los avisos por WhatsApp (módulo Avisos).', 'lachinata-core' ),
				'ph'    => '679 31 32 14',
			),
			'email'    => array(
				'label' => __( 'Correo de atención', 'lachinata-core' ),
				'type'  => 'email',
				'hint'  => __( 'Responder a los correos de la tienda llega aquí (Reply-To). Vacío: la dirección del remitente de WooCommerce.', 'lachinata-core' ),
				'ph'    => 'hola@lachinata.es',
			),
			'hours'    => array(
				'label' => __( 'Horario', 'lachinata-core' ),
				'type'  => 'text',
				'hint'  => __( 'Una frase completa, como la leerá el cliente al pie de los correos.', 'lachinata-core' ),
				'ph'    => __( 'De lunes a viernes, de 9 a 18 h.', 'lachinata-core' ),
			),
		);
		?>
		<p><?php esc_html_e( 'Lo leen el «¿Alguna duda?» de los correos, el pie de la web y la UspBar. En los menús de la UspBar y la barra de promoción puedes escribir {telefono}, {whatsapp}, {correo} y {horario}: si el dato está vacío, ese elemento no se muestra.', 'lachinata-core' ); ?></p>
		<p class="description">
			<?php
			echo wp_kses(
				sprintf(
					/* translators: %s: link to WooCommerce → Settings → General. */
					__( 'La dirección (ciudad y provincia del pie de los correos) es la de la tienda en <a href="%s">WooCommerce → Ajustes → Generales</a>.', 'lachinata-core' ),
					esc_url( admin_url( 'admin.php?page=wc-settings&tab=general' ) )
				),
				array( 'a' => array( 'href' => array() ) )
			);
			?>
		</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::SAVE ); ?>">
			<?php wp_nonce_field( self::SAVE ); ?>
			<table class="form-table" role="presentation">
				<?php foreach ( $fields as $key => $field ) : ?>
					<tr>
						<th scope="row"><label for="lc-contact-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $field['label'] ); ?></label></th>
						<td>
							<input type="<?php echo esc_attr( $field['type'] ); ?>" class="regular-text" id="lc-contact-<?php echo esc_attr( $key ); ?>" name="contact[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $values[ $key ] ); ?>" placeholder="<?php echo esc_attr( $field['ph'] ); ?>">
							<p class="description"><?php echo esc_html( $field['hint'] ); ?></p>
						</td>
					</tr>
				<?php endforeach; ?>
			</table>
			<p class="description"><?php esc_html_e( 'Son datos de este sitio: no salen en la exportación de configuración.', 'lachinata-core' ); ?></p>
			<?php submit_button(); ?>
		</form>
		<?php
	}

	/**
	 * Saves the values.
	 */
	public static function handle(): void {
		Screen::check( self::SAVE );
		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Screen::check(); Contact::save() sanitizes each value.
		$values = isset( $_POST['contact'] ) && is_array( $_POST['contact'] ) ? wp_unslash( $_POST['contact'] ) : array();
		Contact::save( (array) $values );
		Screen::flash( 'success', array( __( 'Datos de atención al cliente guardados.', 'lachinata-core' ) ) );
		Screen::redirect( self::TAB );
	}
}
