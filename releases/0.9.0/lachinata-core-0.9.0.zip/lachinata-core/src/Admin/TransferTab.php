<?php
/**
 * La Chinata → Exportar/importar.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Admin;

use LaChinata\Core\Config\Exporter;
use LaChinata\Core\Config\Importer;
use LaChinata\Core\Plugin;

defined( 'ABSPATH' ) || exit;

/**
 * Downloads the configuration as JSON and imports it in two steps: upload and review, then apply.
 */
final class TransferTab {

	/**
	 * Actions of admin-post.php, also the nonce actions.
	 */
	private const EXPORT = 'lachinata_export';
	private const UPLOAD = 'lachinata_import_upload';
	private const APPLY  = 'lachinata_import_apply';

	/**
	 * Largest file accepted.
	 */
	private const MAX_BYTES = MB_IN_BYTES;

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_action( 'admin_post_' . self::EXPORT, array( self::class, 'export' ) );
		add_action( 'admin_post_' . self::UPLOAD, array( self::class, 'upload' ) );
		add_action( 'admin_post_' . self::APPLY, array( self::class, 'apply' ) );
	}

	/**
	 * Transient that keeps the uploaded document between upload and apply.
	 */
	private static function pending_key(): string {
		return 'lachinata_core_import_' . get_current_user_id();
	}

	/**
	 * Prints the tab.
	 */
	public static function render(): void {
		$pending = get_transient( self::pending_key() );
		if ( isset( $_GET['step'] ) && 'review' === $_GET['step'] && is_array( $pending ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Navigation only.
			self::render_review( $pending );
			return;
		}
		$modules = Plugin::instance()->modules()->all();
		?>
		<h2><?php esc_html_e( 'Exportar', 'lachinata-core' ); ?></h2>
		<p><?php esc_html_e( 'Descarga qué módulos están activos y sus ajustes en un archivo JSON para llevarlos a otro sitio. Los datos propios de cada sitio y los secretos no se exportan.', 'lachinata-core' ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::EXPORT ); ?>">
			<?php wp_nonce_field( self::EXPORT ); ?>
			<fieldset>
				<legend class="screen-reader-text"><?php esc_html_e( 'Módulos que se exportan', 'lachinata-core' ); ?></legend>
				<?php foreach ( $modules as $id => $module ) : ?>
					<label class="lc-admin__check"><input type="checkbox" name="modules[]" value="<?php echo esc_attr( $id ); ?>" checked> <?php echo esc_html( $module->label() ); ?></label>
				<?php endforeach; ?>
			</fieldset>
			<?php submit_button( __( 'Descargar JSON', 'lachinata-core' ), 'secondary' ); ?>
		</form>

		<h2><?php esc_html_e( 'Importar', 'lachinata-core' ); ?></h2>
		<p><?php esc_html_e( 'Sube un archivo exportado desde otro sitio. Antes de cambiar nada verás qué cambia y podrás elegir los módulos.', 'lachinata-core' ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::UPLOAD ); ?>">
			<?php wp_nonce_field( self::UPLOAD ); ?>
			<p>
				<label for="lc-config-file"><?php esc_html_e( 'Archivo JSON', 'lachinata-core' ); ?></label><br>
				<input type="file" id="lc-config-file" name="lc_config" accept="application/json,.json" required>
			</p>
			<?php submit_button( __( 'Revisar cambios', 'lachinata-core' ), 'secondary' ); ?>
		</form>
		<?php
	}

	/**
	 * Second step: what the file changes, with a checkbox per module.
	 *
	 * @param array<mixed> $document Uploaded document.
	 */
	private static function render_review( array $document ): void {
		$registry = Plugin::instance()->modules();
		$plan     = ( new Importer( $registry ) )->plan( $document );
		$by       = array();
		foreach ( $plan->changes as $change ) {
			$by[ $change['module'] ][] = $change;
		}
		?>
		<h2><?php esc_html_e( 'Revisar la importación', 'lachinata-core' ); ?></h2>
		<?php if ( $plan->source ) : ?>
			<?php /* translators: %s: site URL. */ ?>
			<p><?php echo esc_html( sprintf( __( 'Archivo exportado desde %s.', 'lachinata-core' ), $plan->source ) ); ?></p>
		<?php endif; ?>
		<?php foreach ( array_merge( $plan->errors, $plan->warnings ) as $index => $message ) : ?>
			<div class="notice notice-<?php echo $index < count( $plan->errors ) ? 'error' : 'warning'; ?> inline"><p><?php echo esc_html( $message ); ?></p></div>
		<?php endforeach; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::APPLY ); ?>">
			<?php wp_nonce_field( self::APPLY ); ?>
			<?php if ( ! $plan->changes ) : ?>
				<p><?php esc_html_e( 'La configuración del archivo ya coincide con la de este sitio.', 'lachinata-core' ); ?></p>
			<?php endif; ?>
			<?php foreach ( $plan->modules as $id ) : ?>
				<?php $module = $registry->get( $id ); ?>
				<fieldset class="lc-admin__import">
					<legend>
						<label><input type="checkbox" name="modules[]" value="<?php echo esc_attr( $id ); ?>" checked> <strong><?php echo esc_html( null !== $module ? $module->label() : $id ); ?></strong></label>
					</legend>
					<?php if ( empty( $by[ $id ] ) ) : ?>
						<p class="description"><?php esc_html_e( 'Sin cambios.', 'lachinata-core' ); ?></p>
					<?php else : ?>
						<table class="widefat striped">
							<thead>
								<tr>
									<th scope="col"><?php esc_html_e( 'Ajuste', 'lachinata-core' ); ?></th>
									<th scope="col"><?php esc_html_e( 'Ahora', 'lachinata-core' ); ?></th>
									<th scope="col"><?php esc_html_e( 'Pasará a', 'lachinata-core' ); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( $by[ $id ] as $change ) : ?>
									<tr>
										<th scope="row"><?php echo esc_html( $change['field'] ); ?></th>
										<td><code><?php echo esc_html( Screen::format_value( $change['from'] ) ); ?></code></td>
										<td><code><?php echo esc_html( Screen::format_value( $change['to'] ) ); ?></code></td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					<?php endif; ?>
				</fieldset>
			<?php endforeach; ?>
			<p class="submit">
				<?php if ( ! $plan->errors && $plan->changes ) : ?>
					<?php submit_button( __( 'Importar', 'lachinata-core' ), 'primary', 'submit', false ); ?>
				<?php endif; ?>
				<a class="button" href="<?php echo esc_url( Screen::url( 'transfer' ) ); ?>"><?php esc_html_e( 'Volver', 'lachinata-core' ); ?></a>
			</p>
		</form>
		<?php
	}

	/**
	 * Sends the JSON file.
	 */
	public static function export(): void {
		Screen::check( self::EXPORT );
		$only     = isset( $_POST['modules'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['modules'] ) ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Screen::check().
		$document = Exporter::export( Plugin::instance()->modules(), $only );
		$host     = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		$name     = sprintf( 'lachinata-config-%1$s-%2$s.json', sanitize_file_name( $host ), gmdate( 'Ymd-His' ) );
		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $name . '"' );
		echo Exporter::to_json( $document ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON download, not HTML.
		exit;
	}

	/**
	 * Reads the uploaded file and goes to the review step.
	 */
	public static function upload(): void {
		Screen::check( self::UPLOAD );
		$file = $_FILES['lc_config'] ?? null; // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Screen::check(); only tmp_name, error and size are read.
		if ( ! is_array( $file ) || UPLOAD_ERR_OK !== ( $file['error'] ?? UPLOAD_ERR_NO_FILE ) || ! is_uploaded_file( (string) $file['tmp_name'] ) ) {
			Screen::flash( 'error', array( __( 'No se ha recibido ningún archivo.', 'lachinata-core' ) ) );
			Screen::redirect( 'transfer' );
		}
		if ( (int) $file['size'] > self::MAX_BYTES ) {
			Screen::flash( 'error', array( __( 'El archivo es demasiado grande para ser una configuración.', 'lachinata-core' ) ) );
			Screen::redirect( 'transfer' );
		}
		$document = Importer::decode( (string) file_get_contents( (string) $file['tmp_name'] ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local uploaded file.
		if ( null === $document ) {
			Screen::flash( 'error', array( __( 'El archivo no es un JSON válido.', 'lachinata-core' ) ) );
			Screen::redirect( 'transfer' );
		}
		$plan = ( new Importer( Plugin::instance()->modules() ) )->plan( $document );
		if ( $plan->errors ) {
			Screen::flash( 'error', array_merge( array( __( 'No se puede importar el archivo:', 'lachinata-core' ) ), $plan->errors ) );
			Screen::redirect( 'transfer' );
		}
		set_transient( self::pending_key(), $document, 15 * MINUTE_IN_SECONDS );
		Screen::redirect( 'transfer', array( 'step' => 'review' ) );
	}

	/**
	 * Writes the reviewed document for the chosen modules.
	 */
	public static function apply(): void {
		Screen::check( self::APPLY );
		$document = get_transient( self::pending_key() );
		if ( ! is_array( $document ) ) {
			Screen::flash( 'error', array( __( 'La revisión ha caducado. Vuelve a subir el archivo.', 'lachinata-core' ) ) );
			Screen::redirect( 'transfer' );
		}
		$only     = isset( $_POST['modules'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['modules'] ) ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Screen::check().
		$importer = new Importer( Plugin::instance()->modules() );
		$plan     = $importer->plan( $document, $only );
		if ( ! $importer->apply( $plan ) ) {
			Screen::flash( 'error', array_merge( array( __( 'No se puede importar el archivo:', 'lachinata-core' ) ), $plan->errors ) );
			Screen::redirect( 'transfer', array( 'step' => 'review' ) );
		}
		delete_transient( self::pending_key() );
		Screen::flash(
			'success',
			array(
				sprintf(
					/* translators: %d: number of changes. */
					_n( 'Configuración importada: %d cambio.', 'Configuración importada: %d cambios.', count( $plan->changes ), 'lachinata-core' ),
					count( $plan->changes )
				),
			)
		);
		Screen::redirect( 'transfer' );
	}
}
