<?php
/**
 * Configuration export.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Config;

use LaChinata\Core\ModuleRegistry;
use LaChinata\Core\Settings;

defined( 'ABSPATH' ) || exit;

/**
 * Builds the JSON document that copies the configuration of one site to another:
 * which modules are on, their settings and the section each module adds.
 */
final class Exporter {

	/**
	 * Value of the `format` field.
	 */
	public const FORMAT = 'lachinata-core/config';

	/**
	 * Version of the document structure. Raise it when an import of the old shape stops working.
	 */
	public const SCHEMA = 1;

	/**
	 * Builds the document.
	 *
	 * @param ModuleRegistry $modules Module registry.
	 * @param string[]|null  $only    Module ids to export; null for all.
	 * @return array{format: string, schema: int, version: string, site: string, exported_at: string, modules: array<string, array{enabled: bool, settings: array<string, mixed>, data?: array<string, mixed>}>}
	 */
	public static function export( ModuleRegistry $modules, ?array $only = null ): array {
		$sections = array();
		foreach ( $modules->all() as $id => $module ) {
			if ( null !== $only && ! in_array( $id, $only, true ) ) {
				continue;
			}
			$section = array(
				'enabled'  => in_array( $id, $modules->enabled(), true ),
				'settings' => Settings::all( $module, true ),
			);
			$data    = $module->export_data();
			if ( $data ) {
				$section['data'] = $data;
			}
			$sections[ $id ] = $section;
		}

		return array(
			'format'      => self::FORMAT,
			'schema'      => self::SCHEMA,
			'version'     => LACHINATA_CORE_VERSION,
			'site'        => home_url(),
			'exported_at' => gmdate( 'c' ),
			'modules'     => $sections,
		);
	}

	/**
	 * The document as pretty JSON.
	 *
	 * @param array<string, mixed> $document Document from export().
	 */
	public static function to_json( array $document ): string {
		return (string) wp_json_encode( $document, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . "\n";
	}
}
