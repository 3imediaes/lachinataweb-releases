<?php
/**
 * Result of validating an import.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Config;

defined( 'ABSPATH' ) || exit;

/**
 * What an import would write, plus its errors and warnings.
 */
final class ImportPlan {

	/**
	 * Site the document came from.
	 *
	 * @var string
	 */
	public string $source = '';

	/**
	 * Problems that stop the import.
	 *
	 * @var string[]
	 */
	public array $errors = array();

	/**
	 * Parts of the document that are skipped.
	 *
	 * @var string[]
	 */
	public array $warnings = array();

	/**
	 * Ids of the modules the plan covers.
	 *
	 * @var string[]
	 */
	public array $modules = array();

	/**
	 * Enabled state per module.
	 *
	 * @var array<string, bool>
	 */
	public array $enabled = array();

	/**
	 * Settings per module.
	 *
	 * @var array<string, array<string, mixed>>
	 */
	public array $settings = array();

	/**
	 * Module data sections.
	 *
	 * @var array<string, array<string, mixed>>
	 */
	public array $data = array();

	/**
	 * Readable list of differences with this site.
	 *
	 * @var array<int, array{module: string, field: string, from: mixed, to: mixed}>
	 */
	public array $changes = array();
}
