<?php
/**
 * Customer service contact of the shop.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core;

defined( 'ABSPATH' ) || exit;

/**
 * «Atención al cliente»: phone, WhatsApp, email and opening hours of each shop. They belong
 * to the core, not to a module, because the emails («¿Alguna duda?»), the footer and the
 * UspBar («Compra por teléfono») read them. The theme asks for them with the filter
 * `lachinata/contact` (empty by default) and the menus of the UspBar and the PromoBar may
 * use `{telefono}`, `{whatsapp}`, `{correo}` and `{horario}`. Each site keeps its own: they
 * never travel in the configuration export.
 */
final class Contact {

	/**
	 * Option with the four values.
	 */
	public const OPTION = 'lachinata_core_contact';

	/**
	 * Keys, in the order of the screen.
	 */
	public const KEYS = array( 'phone', 'whatsapp', 'email', 'hours' );

	/**
	 * Placeholders of the menus, by key.
	 */
	public const PLACEHOLDERS = array(
		'phone'    => '{telefono}',
		'whatsapp' => '{whatsapp}',
		'email'    => '{correo}',
		'hours'    => '{horario}',
	);

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_filter( 'lachinata/contact', array( self::class, 'fill' ) );
		add_filter( 'lachinata/usp/items', array( self::class, 'usp_items' ), 20 );
		add_filter( 'lachinata/promo_bar/messages', array( self::class, 'promo_messages' ), 20 );
	}

	/**
	 * The saved values, empty strings for the missing ones.
	 *
	 * @return array{phone: string, whatsapp: string, email: string, hours: string}
	 */
	public static function get(): array {
		$saved  = get_option( self::OPTION, array() );
		$saved  = is_array( $saved ) ? $saved : array();
		$values = array();
		foreach ( self::KEYS as $key ) {
			$values[ $key ] = is_string( $saved[ $key ] ?? null ) ? trim( $saved[ $key ] ) : '';
		}
		/**
		 * The keys are all there.
		 *
		 * @var array{phone: string, whatsapp: string, email: string, hours: string} $values
		 */
		return $values;
	}

	/**
	 * Saves the values (unknown keys are dropped).
	 *
	 * @param array<string, mixed> $values Values.
	 */
	public static function save( array $values ): void {
		$clean = array(
			'phone'    => self::phone( (string) ( $values['phone'] ?? '' ) ),
			'whatsapp' => self::phone( (string) ( $values['whatsapp'] ?? '' ) ),
			'email'    => sanitize_email( (string) ( $values['email'] ?? '' ) ),
			'hours'    => sanitize_text_field( (string) ( $values['hours'] ?? '' ) ),
		);
		update_option( self::OPTION, $clean, false );
	}

	/**
	 * A phone as people write it («679 31 32 14», «+420 123 456 789»): digits, spaces and a
	 * leading plus.
	 *
	 * @param string $value Raw value.
	 */
	public static function phone( string $value ): string {
		$value = trim( (string) preg_replace( '/[^\d+ ]/', '', $value ) );
		return trim( (string) preg_replace( '/\s+/', ' ', $value ) );
	}

	/**
	 * Digits for a wa.me or tel: link, with the country prefix of the shop when the number
	 * has none («679 31 32 14» → «34679313214»).
	 *
	 * @param string $phone Phone as saved.
	 */
	public static function international( string $phone ): string {
		$digits = (string) preg_replace( '/\D/', '', $phone );
		if ( '' === $digits ) {
			return '';
		}
		if ( str_starts_with( trim( $phone ), '+' ) ) {
			return $digits;
		}
		if ( str_starts_with( $digits, '00' ) ) {
			return substr( $digits, 2 );
		}
		$country = function_exists( 'WC' ) && WC()->countries ? WC()->countries->get_base_country() : 'ES';
		$prefix  = function_exists( 'WC' ) && WC()->countries ? ltrim( (string) WC()->countries->get_country_calling_code( $country ), '+' ) : '34';
		return $prefix . $digits;
	}

	/**
	 * `lachinata/contact`: the shop's values, with the links already built.
	 *
	 * @param mixed $contact What the theme passes (empty values).
	 * @return array{phone: string, whatsapp: string, email: string, hours: string, phone_url: string, whatsapp_url: string}
	 */
	public static function fill( $contact ): array {
		unset( $contact );
		$values                 = self::get();
		$values['phone_url']    = '' === $values['phone'] ? '' : 'tel:+' . self::international( $values['phone'] );
		$values['whatsapp_url'] = '' === $values['whatsapp'] ? '' : 'https://wa.me/' . self::international( $values['whatsapp'] );
		return $values;
	}

	/**
	 * Replaces the placeholders in a text. An item that needs a value the shop has not set
	 * is not shown (null).
	 *
	 * @param string $text Text.
	 */
	public static function replace( string $text ): ?string {
		$values = self::get();
		foreach ( self::PLACEHOLDERS as $key => $placeholder ) {
			if ( ! str_contains( $text, $placeholder ) ) {
				continue;
			}
			if ( '' === $values[ $key ] ) {
				return null;
			}
			$text = str_replace( $placeholder, $values[ $key ], $text );
		}
		return $text;
	}

	/**
	 * UspBar items with the placeholders filled; an item without its value is dropped.
	 *
	 * @param mixed $items Items.
	 * @return array<int, array<string, mixed>>
	 */
	public static function usp_items( $items ): array {
		$out = array();
		foreach ( is_array( $items ) ? $items : array() as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$title = self::replace( (string) ( $item['title'] ?? '' ) );
			$text  = self::replace( (string) ( $item['text'] ?? '' ) );
			if ( null === $title || null === $text ) {
				continue;
			}
			$item['title'] = $title;
			$item['text']  = $text;
			$out[]         = $item;
		}
		return $out;
	}

	/**
	 * PromoBar messages with the placeholders filled; a message without its value is dropped.
	 *
	 * @param mixed $messages Messages.
	 * @return array<int, array<string, mixed>>
	 */
	public static function promo_messages( $messages ): array {
		$out = array();
		foreach ( is_array( $messages ) ? $messages : array() as $message ) {
			if ( ! is_array( $message ) ) {
				continue;
			}
			$title = self::replace( (string) ( $message['title'] ?? '' ) );
			if ( null === $title ) {
				continue;
			}
			$message['title'] = $title;
			$out[]            = $message;
		}
		return $out;
	}
}
