<?php
/**
 * Delivery dates of an order, for the modules that tell them.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Contracts;

use LaChinata\Core\Delivery\Estimate;

defined( 'ABSPATH' ) || exit;

/**
 * The `eta` module's estimate, recalculated from the real dispatch day. Ask
 * Services::delivery(); null while `eta` is off (then read the dates stored in the order,
 * Estimate::from_meta() on `_lc_eta`).
 */
interface DeliveryEstimator {

	/**
	 * Delivery dates of an order that leaves the warehouse on a given day, or null when
	 * its method has no delivery time.
	 *
	 * @param \WC_Order          $order Order.
	 * @param \DateTimeImmutable $ships Dispatch day.
	 */
	public function shipped( \WC_Order $order, \DateTimeImmutable $ships ): ?Estimate;
}
