<?php
/**
 * The newsletter provider of the shop, for the modules.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Contracts;

defined( 'ABSPATH' ) || exit;

/**
 * The `newsletter` module serves it (Services::newsletter()): the footer form, the
 * franchise form of `blocks`… add contacts through it, whatever the provider is (Mailchimp
 * today, Brevo or another with its adapter).
 */
interface Newsletter {

	/**
	 * Whether a provider is configured.
	 */
	public function available(): bool;

	/**
	 * Adds or updates a contact. `subscribe` false keeps the contact without subscribing it
	 * (a franchise request); `double_optin` asks the contact to confirm (the footer form);
	 * `tags` are added.
	 *
	 * @param string                                                                                        $email Email.
	 * @param array{name?: string, subscribe?: bool, double_optin?: bool, tags?: string[], source?: string} $args  Contact details and what to do.
	 * @return string Empty when it worked; otherwise why, for people.
	 */
	public function add( string $email, array $args = array() ): string;
}
