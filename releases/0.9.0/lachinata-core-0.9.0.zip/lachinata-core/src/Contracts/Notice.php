<?php
/**
 * A short notice to a mobile (WhatsApp or SMS).
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Contracts;

defined( 'ABSPATH' ) || exit;

/**
 * What a module asks the notifier to send: which notice (`gift`, `shipped`), to whom, the
 * variables of the WhatsApp template in order, whether it carries the short link (the
 * button of the template, the link of the SMS) and the SMS text, already cut to two
 * segments, used by the SMS channel and by the fallback when WhatsApp cannot deliver.
 */
final class Notice {

	/**
	 * Notice to the recipient of a gift (template `lc_regalo_aviso`).
	 */
	public const GIFT = 'gift';

	/**
	 * Notice to the buyer when the order leaves (template `lc_pedido_enviado`).
	 */
	public const SHIPPED = 'shipped';

	/**
	 * Builds a notice.
	 *
	 * @param string    $kind   GIFT or SHIPPED.
	 * @param \WC_Order $order  Order it belongs to.
	 * @param string    $to     Mobile in international format (+34600000000).
	 * @param string[]  $params Variables of the template body, {{1}} first. None may be empty.
	 * @param bool      $link   With the short link of the order (button of the template).
	 * @param string    $sms    Text of the SMS (at most two segments).
	 * @param string    $source Module that sends it, for notes and logs.
	 */
	public function __construct(
		public readonly string $kind,
		public readonly \WC_Order $order,
		public readonly string $to,
		public readonly array $params,
		public readonly bool $link,
		public readonly string $sms,
		public readonly string $source,
	) {}
}
