<?php
/**
 * What happened to a notice.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Contracts;

defined( 'ABSPATH' ) || exit;

/**
 * Channel it left by, whether it left, the provider's reference (the `wamid` of WhatsApp,
 * the job of OVH) and why it did not leave.
 */
final class NoticeResult {

	/**
	 * Builds a result.
	 *
	 * @param string $channel  whatsapp or sms.
	 * @param bool   $ok       Whether the provider accepted it.
	 * @param string $ref      Provider reference.
	 * @param string $error    Why it did not leave, for people.
	 * @param bool   $fallback Sent by SMS because WhatsApp could not deliver it.
	 */
	public function __construct(
		public readonly string $channel,
		public readonly bool $ok,
		public readonly string $ref = '',
		public readonly string $error = '',
		public readonly bool $fallback = false,
	) {}
}
