<?php
/**
 * Short notices by WhatsApp or SMS, shared by the modules.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Contracts;

defined( 'ABSPATH' ) || exit;

/**
 * The `notify` module serves it (Services::notifier()); `gift` and `shipment` ask for it and
 * check it exists. Each channel is switched on and set up per shop: only the active and
 * configured ones are offered. The email channel only says whether a module may email a
 * third person (the gift's recipient); the email itself is the module's WooCommerce email.
 */
interface Notifier {

	/**
	 * Channels, in the order they are offered.
	 */
	public const EMAIL    = 'email';
	public const WHATSAPP = 'whatsapp';
	public const SMS      = 'sms';

	/**
	 * Channels active and configured, in the order EMAIL, WHATSAPP, SMS.
	 *
	 * @return string[]
	 */
	public function channels(): array;

	/**
	 * Whether a channel is active and configured.
	 *
	 * @param string $channel Channel.
	 */
	public function available( string $channel ): bool;

	/**
	 * Sends a notice by WhatsApp or SMS. Never throws: a failure comes back in the result
	 * and is recorded (order note by the caller, Huecos de configuración, log).
	 *
	 * @param string $channel WHATSAPP or SMS.
	 * @param Notice $notice  Notice.
	 */
	public function send( string $channel, Notice $notice ): NoticeResult;

	/**
	 * Short link of an order, without scheme («lachinata.es/s/7Kq2xm»): it redirects to the
	 * latest tracking of the order, never to the order itself.
	 *
	 * @param \WC_Order $order Order.
	 */
	public function short_link( \WC_Order $order ): string;

	/**
	 * Forgets the mobile and the texts of the notices of a kind sent for an order (the
	 * gift's recipient after the delivery).
	 *
	 * @param \WC_Order $order Order.
	 * @param string    $kind  Notice::GIFT or Notice::SHIPPED.
	 */
	public function forget( \WC_Order $order, string $kind ): void;
}
