<?php
/**
 * The shipping rules of the site, for the modules that need them.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Contracts;

defined( 'ABSPATH' ) || exit;

/**
 * What the `shipping` module decides that others read (`eta`, `locale`, the theme's
 * function lachinata_producto_enviable()). Ask Services::shipping_rules(); null while
 * `shipping` is off.
 */
interface ShippingRules {

	/**
	 * Whether a product can ship to a destination: true, or the reason
	 * (`producto_restringido`, `zona_no_cubierta`, `peso_max`).
	 *
	 * @param \WC_Product                                               $product     Product or variation.
	 * @param array{country: string, state?: string, postcode?: string} $destination Destination.
	 * @return true|string
	 */
	public function shippable( \WC_Product $product, array $destination ): true|string;

	/**
	 * Zone used when the visitor's destination is not known (0: the rest of the world).
	 */
	public function default_zone_id(): int;
}
