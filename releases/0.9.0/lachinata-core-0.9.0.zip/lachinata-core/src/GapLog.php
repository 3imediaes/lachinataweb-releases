<?php
/**
 * Log of configuration gaps found while serving customers.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Remembers situations the configuration does not cover (a cart with no shipping method
 * for no known reason, a method with no delivery time…) so the admin screens can list
 * them. One entry per signature with a counter; at most LIMIT entries, oldest out first.
 * Writes at most once an hour per signature, so a busy page does not write on every visit.
 */
final class GapLog {

	/**
	 * Entries kept.
	 */
	private const LIMIT = 50;

	/**
	 * Seconds between two writes of the same signature.
	 */
	private const THROTTLE = HOUR_IN_SECONDS;

	/**
	 * Option that stores the entries (not autoloaded, not exported).
	 *
	 * @var string
	 */
	private string $option;

	/**
	 * Logger source in WooCommerce → Estado → Registros.
	 *
	 * @var string
	 */
	private string $source;

	/**
	 * Sets the storage.
	 *
	 * @param string $option Option name (`lachinata_<module>_gaps`).
	 * @param string $source Logger source.
	 */
	public function __construct( string $option, string $source ) {
		$this->option = $option;
		$this->source = $source;
	}

	/**
	 * Records a gap.
	 *
	 * @param string               $signature What identifies the gap (zone + method, zone + destination…).
	 * @param string               $message   Readable description.
	 * @param array<string, mixed> $context   Data shown with it.
	 */
	public function record( string $signature, string $message, array $context = array() ): void {
		$entries = $this->all();
		$now     = time();
		$entry   = $entries[ $signature ] ?? null;
		if ( null !== $entry && $now - (int) $entry['last'] < self::THROTTLE ) {
			return;
		}

		$entries[ $signature ] = array(
			'message' => $message,
			'context' => $context,
			'count'   => ( null === $entry ? 0 : (int) $entry['count'] ) + 1,
			'first'   => null === $entry ? $now : (int) $entry['first'],
			'last'    => $now,
		);
		uasort( $entries, static fn( array $a, array $b ): int => $b['last'] <=> $a['last'] );
		update_option( $this->option, array_slice( $entries, 0, self::LIMIT, true ), false );

		if ( function_exists( 'wc_get_logger' ) ) {
			wc_get_logger()->warning( $message, array_merge( $context, array( 'source' => $this->source ) ) );
		}
	}

	/**
	 * Entries, most recent first.
	 *
	 * @return array<string, array{message: string, context: array<string, mixed>, count: int, first: int, last: int}>
	 */
	public function all(): array {
		$entries = get_option( $this->option, array() );
		return is_array( $entries ) ? $entries : array();
	}

	/**
	 * Forgets one entry or all of them.
	 *
	 * @param string|null $signature Entry to forget; null for all.
	 */
	public function clear( ?string $signature = null ): void {
		if ( null === $signature ) {
			delete_option( $this->option );
			return;
		}
		$entries = $this->all();
		unset( $entries[ $signature ] );
		update_option( $this->option, $entries, false );
	}
}
