<?php
/**
 * State of each module, at a glance, for WooCommerce → Estado and Salud del sitio.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core;

defined( 'ABSPATH' ) || exit;

/**
 * One row per module: whether it is on and running, configured, with its credentials
 * (present or not, never their values), its last incident and the version of its data.
 * The same rows go to WooCommerce's system status report (what support copies), to the
 * Site Health information and, when a module failed in the last day, to a Site Health
 * test and an admin notice.
 */
final class Health {

	/**
	 * A failure newer than this is «recent».
	 */
	public const RECENT = DAY_IN_SECONDS;

	/**
	 * Registers the hooks (admin only).
	 */
	public static function boot(): void {
		add_action( 'woocommerce_system_status_report', array( self::class, 'status_report' ) );
		add_filter( 'debug_information', array( self::class, 'debug_information' ) );
		add_filter( 'site_status_tests', array( self::class, 'site_status_tests' ) );
		add_action( 'admin_notices', array( self::class, 'notice' ) );
	}

	/**
	 * Rows of every registered module.
	 *
	 * @return array<string, array{label: string, enabled: bool, running: bool, state: string, configured: bool|null, credentials: bool|null, notes: string[], incident: array{message: string, last: int, failure: bool}|null, schema: int, schema_target: int}>
	 */
	public static function rows(): array {
		$registry = Plugin::instance()->modules();
		$rows     = array();
		foreach ( $registry->all() as $id => $module ) {
			$enabled = in_array( $id, $registry->enabled(), true );
			$running = $registry->is_active( $id );
			$health  = $running ? self::module_health( $module ) : array(
				'configured'  => null,
				'credentials' => null,
				'notes'       => array(),
			);

			$rows[ $id ] = array(
				'label'         => $module->label(),
				'enabled'       => $enabled,
				'running'       => $running,
				'state'         => self::state( $registry, $module, $enabled, $running ),
				'configured'    => $health['configured'],
				'credentials'   => $health['credentials'],
				'notes'         => $health['notes'],
				'incident'      => self::last_incident( $id ),
				'schema'        => $registry->schema( $module ),
				'schema_target' => $module->schema_version(),
			);
		}
		return $rows;
	}

	/**
	 * Modules that failed in the last day, id → incident.
	 *
	 * @return array<string, array{message: string, last: int, failure: bool}>
	 */
	public static function recent_failures(): array {
		$failures = array();
		foreach ( array_keys( Plugin::instance()->modules()->all() ) as $id ) {
			$incident = self::last_incident( $id, true );
			if ( null !== $incident && time() - $incident['last'] < self::RECENT ) {
				$failures[ $id ] = $incident;
			}
		}
		return $failures;
	}

	/**
	 * The module's own health, guarded: a failing health() is itself a failure.
	 *
	 * @param Module $module Module.
	 * @return array{configured: bool|null, credentials: bool|null, notes: string[]}
	 */
	private static function module_health( Module $module ): array {
		$health = array(
			'configured'  => null,
			'credentials' => null,
			'notes'       => array(),
		);
		Hooks::run(
			$module->id(),
			static function () use ( $module, &$health ): void {
				$health = array_merge( $health, $module->health() );
			},
			'health'
		);
		return $health;
	}

	/**
	 * Readable state of a module.
	 *
	 * @param ModuleRegistry $registry Registry.
	 * @param Module         $module   Module.
	 * @param bool           $enabled  Enabled in the panel.
	 * @param bool           $running  Booted and not failed.
	 */
	private static function state( ModuleRegistry $registry, Module $module, bool $enabled, bool $running ): string {
		if ( $running ) {
			return __( 'Funcionando', 'lachinata-core' );
		}
		if ( ! $enabled ) {
			return __( 'Apagado', 'lachinata-core' );
		}
		if ( $registry->disabled_by_constant( $module->id() ) ) {
			/* translators: %s: constant name. */
			return sprintf( __( 'Apagado por %s', 'lachinata-core' ), ModuleRegistry::DISABLE_CONSTANT );
		}
		if ( Hooks::failed( $module->id() ) ) {
			return __( 'Ha fallado en esta petición', 'lachinata-core' );
		}
		$missing = $registry->missing_requirements( $module );
		if ( $missing ) {
			return implode( ' ', $missing );
		}
		return __( 'No arranca: lo necesita otro módulo que no funciona', 'lachinata-core' );
	}

	/**
	 * Latest entry of a module's GapLog.
	 *
	 * @param string $id            Module id.
	 * @param bool   $failures_only Only failures (`fallo:*`), not configuration gaps.
	 * @return array{message: string, last: int, failure: bool}|null
	 */
	private static function last_incident( string $id, bool $failures_only = false ): ?array {
		foreach ( Hooks::log( $id )->all() as $signature => $entry ) {
			$failure = str_starts_with( (string) $signature, 'fallo:' );
			if ( $failures_only && ! $failure ) {
				continue;
			}
			return array(
				'message' => (string) $entry['message'],
				'last'    => (int) $entry['last'],
				'failure' => $failure,
			);
		}
		return null;
	}

	/**
	 * Yes, no or «—» for a check that does not apply.
	 *
	 * @param bool|null $value Value.
	 */
	private static function yes_no( ?bool $value ): string {
		if ( null === $value ) {
			return '—';
		}
		return $value ? __( 'Sí', 'lachinata-core' ) : __( 'No', 'lachinata-core' );
	}

	/**
	 * Incident as one line.
	 *
	 * @param array{message: string, last: int, failure: bool}|null $incident Incident.
	 */
	private static function incident_text( ?array $incident ): string {
		if ( null === $incident ) {
			return '—';
		}
		return wp_date( 'j M Y H:i', $incident['last'] ) . ' · ' . $incident['message'];
	}

	/**
	 * Section «La Chinata · módulos» of WooCommerce → Estado.
	 */
	public static function status_report(): void {
		?>
		<table class="wc_status_table widefat" cellspacing="0" id="lachinata-modules">
			<thead>
				<tr>
					<th colspan="3" data-export-label="La Chinata modules"><h2><?php esc_html_e( 'La Chinata · módulos', 'lachinata-core' ); ?></h2></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( self::rows() as $id => $row ) : ?>
					<tr>
						<td data-export-label="<?php echo esc_attr( $id ); ?>"><strong><?php echo esc_html( $row['label'] ); ?></strong> <code><?php echo esc_html( $id ); ?></code></td>
						<td class="help">&nbsp;</td>
						<td>
							<?php
							$facts = array(
								$row['running'] ? '<mark class="yes"><span class="dashicons dashicons-yes"></span> ' . esc_html( $row['state'] ) . '</mark>' : ( $row['enabled'] ? '<mark class="error"><span class="dashicons dashicons-warning"></span> ' . esc_html( $row['state'] ) . '</mark>' : esc_html( $row['state'] ) ),
								/* translators: %s: Sí, No or —. */
								esc_html( sprintf( __( 'Configurado: %s', 'lachinata-core' ), self::yes_no( $row['configured'] ) ) ),
								/* translators: %s: Sí, No or —. */
								esc_html( sprintf( __( 'Credenciales: %s', 'lachinata-core' ), self::yes_no( $row['credentials'] ) ) ),
								/* translators: 1: stored data version, 2: version of this code. */
								esc_html( sprintf( __( 'Datos: v%1$d de v%2$d', 'lachinata-core' ), $row['schema'], $row['schema_target'] ) ),
								/* translators: %s: last incident. */
								esc_html( sprintf( __( 'Última incidencia: %s', 'lachinata-core' ), self::incident_text( $row['incident'] ) ) ),
							);
							foreach ( $row['notes'] as $note ) {
								$facts[] = esc_html( $note );
							}
							echo wp_kses_post( implode( ' · ', $facts ) );
							?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/**
	 * Section «La Chinata» of Salud del sitio → Información.
	 *
	 * @param array<string, mixed> $info Sections.
	 * @return array<string, mixed>
	 */
	public static function debug_information( $info ): array {
		$fields = array();
		foreach ( self::rows() as $id => $row ) {
			$fields[ $id ] = array(
				'label' => $row['label'],
				'value' => implode(
					' · ',
					array_merge(
						array(
							$row['state'],
							/* translators: %s: Sí, No or —. */
							sprintf( __( 'Configurado: %s', 'lachinata-core' ), self::yes_no( $row['configured'] ) ),
							/* translators: %s: Sí, No or —. */
							sprintf( __( 'Credenciales: %s', 'lachinata-core' ), self::yes_no( $row['credentials'] ) ),
							/* translators: 1: stored data version, 2: version of this code. */
							sprintf( __( 'Datos: v%1$d de v%2$d', 'lachinata-core' ), $row['schema'], $row['schema_target'] ),
							/* translators: %s: last incident. */
							sprintf( __( 'Última incidencia: %s', 'lachinata-core' ), self::incident_text( $row['incident'] ) ),
						),
						$row['notes']
					)
				),
			);
		}
		$info = is_array( $info ) ? $info : array();

		$info['lachinata'] = array(
			'label'  => __( 'La Chinata · módulos', 'lachinata-core' ),
			'fields' => $fields,
		);
		return $info;
	}

	/**
	 * The test «Módulos de La Chinata» of Salud del sitio.
	 *
	 * @param array<string, mixed> $tests Tests.
	 * @return array<string, mixed>
	 */
	public static function site_status_tests( $tests ): array {
		$tests = is_array( $tests ) ? $tests : array();

		$tests['direct']['lachinata_modules'] = array(
			'label' => __( 'Módulos de La Chinata', 'lachinata-core' ),
			'test'  => array( self::class, 'site_status_test' ),
		);
		return $tests;
	}

	/**
	 * Result of the test: critical when a module failed in the last day, recommended when an
	 * enabled module does not run.
	 *
	 * @return array<string, mixed>
	 */
	public static function site_status_test(): array {
		$failures = self::recent_failures();
		$stopped  = array_keys( array_filter( self::rows(), static fn( array $row ): bool => $row['enabled'] && ! $row['running'] ) );
		$status   = $failures ? 'critical' : ( $stopped ? 'recommended' : 'good' );
		$messages = array();
		foreach ( $failures as $id => $incident ) {
			$messages[] = $id . ': ' . $incident['message'];
		}
		if ( $stopped ) {
			/* translators: %s: module ids. */
			$messages[] = sprintf( __( 'Activados en el panel pero sin arrancar: %s.', 'lachinata-core' ), implode( ', ', $stopped ) );
		}
		return array(
			'label'       => 'good' === $status
				? __( 'Los módulos de La Chinata funcionan', 'lachinata-core' )
				: __( 'Algún módulo de La Chinata necesita atención', 'lachinata-core' ),
			'status'      => $status,
			'badge'       => array(
				'label' => 'La Chinata',
				'color' => 'good' === $status ? 'blue' : 'red',
			),
			'description' => '<p>' . esc_html( $messages ? implode( ' ', $messages ) : __( 'Todos los módulos activados arrancan y ninguno ha fallado en el último día.', 'lachinata-core' ) ) . '</p>',
			'actions'     => '<p><a href="' . esc_url( admin_url( 'admin.php?page=wc-status#lachinata-modules' ) ) . '">' . esc_html__( 'Ver el estado de cada módulo', 'lachinata-core' ) . '</a></p>',
			'test'        => 'lachinata_modules',
		);
	}

	/**
	 * Notice in the admin when a module failed in the last day.
	 */
	public static function notice(): void {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}
		$failures = self::recent_failures();
		if ( ! $failures ) {
			return;
		}
		printf(
			'<div class="notice notice-error"><p>%1$s <a href="%2$s">%3$s</a></p></div>',
			esc_html(
				sprintf(
					/* translators: %s: module ids. */
					_n( 'El módulo %s ha fallado en el último día y se apagó en esas peticiones; el resto de la tienda siguió funcionando.', 'Los módulos %s han fallado en el último día y se apagaron en esas peticiones; el resto de la tienda siguió funcionando.', count( $failures ), 'lachinata-core' ),
					implode( ', ', array_keys( $failures ) )
				)
			),
			esc_url( admin_url( 'admin.php?page=wc-status#lachinata-modules' ) ),
			esc_html__( 'Ver el estado de los módulos', 'lachinata-core' )
		);
	}
}
