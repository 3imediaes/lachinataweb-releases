<?php
/**
 * Hooks of the modules, with each failure kept inside its module.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Modules register every action and filter here instead of add_action()/add_filter() (a
 * PHPStan rule enforces it). Each callback runs inside a guard: an exception or error
 * switches its module off for the rest of the request (its other callbacks return what
 * they got), is recorded in the module's GapLog and shows in the admin. The checkout and
 * the order go on without the module.
 *
 * The module of a callback is the one whose namespace holds it; for functions and core
 * callbacks, the module that is booting or running when the hook is added.
 */
final class Hooks {

	/**
	 * Exceptions that are part of a module's behaviour, not failures: the Store API turns
	 * a RouteException into the checkout's error message, WP-CLI exits with ExitException.
	 */
	private const EXPECTED = array(
		'Automattic\WooCommerce\StoreApi\Exceptions\RouteException',
		'WP_CLI\ExitException',
	);

	/**
	 * Modules that failed in this request, with the failure.
	 *
	 * @var array<string, \Throwable>
	 */
	private static array $failed = array();

	/**
	 * Module booting or running a callback now.
	 *
	 * @var string|null
	 */
	private static ?string $current = null;

	/**
	 * Guards of the registered callbacks, to remove them: hook → priority → key → guard.
	 *
	 * @var array<string, array<int, array<string, \Closure>>>
	 */
	private static array $guards = array();

	/**
	 * Adds a filter of a module.
	 *
	 * @param string   $hook          Hook name.
	 * @param callable $callback      Callback.
	 * @param int      $priority      Priority.
	 * @param int      $accepted_args Arguments passed.
	 */
	public static function add_filter( string $hook, callable $callback, int $priority = 10, int $accepted_args = 1 ): void {
		$module = self::module_of( $callback );
		if ( null === $module ) {
			add_filter( $hook, $callback, $priority, $accepted_args );
			return;
		}
		$guard = self::guard( $module, $callback, $hook );
		self::$guards[ $hook ][ $priority ][ self::key( $callback ) ] = $guard;
		add_filter( $hook, $guard, $priority, $accepted_args );
	}

	/**
	 * Adds an action of a module.
	 *
	 * @param string   $hook          Hook name.
	 * @param callable $callback      Callback.
	 * @param int      $priority      Priority.
	 * @param int      $accepted_args Arguments passed.
	 */
	public static function add_action( string $hook, callable $callback, int $priority = 10, int $accepted_args = 1 ): void {
		self::add_filter( $hook, $callback, $priority, $accepted_args );
	}

	/**
	 * Removes a filter added with add_filter().
	 *
	 * @param string   $hook     Hook name.
	 * @param callable $callback Callback as it was added.
	 * @param int      $priority Priority.
	 */
	public static function remove_filter( string $hook, callable $callback, int $priority = 10 ): bool {
		$key   = self::key( $callback );
		$guard = self::$guards[ $hook ][ $priority ][ $key ] ?? null;
		if ( null === $guard ) {
			return remove_filter( $hook, $callback, $priority );
		}
		unset( self::$guards[ $hook ][ $priority ][ $key ] );
		return remove_filter( $hook, $guard, $priority );
	}

	/**
	 * Removes an action added with add_action().
	 *
	 * @param string   $hook     Hook name.
	 * @param callable $callback Callback as it was added.
	 * @param int      $priority Priority.
	 */
	public static function remove_action( string $hook, callable $callback, int $priority = 10 ): bool {
		return self::remove_filter( $hook, $callback, $priority );
	}

	/**
	 * A callback that is not a hook (REST route, block render, Store API data) with the
	 * same guard. `$fallback` is what it returns when the module failed.
	 *
	 * @param callable $callback Callback.
	 * @param mixed    $fallback Value returned after a failure (default: the first argument).
	 * @param string   $label    What it is, for the record («REST /lachinata/v1/eta»).
	 */
	public static function wrap( callable $callback, mixed $fallback = null, string $label = '' ): callable {
		$module = self::module_of( $callback );
		if ( null === $module ) {
			return $callback;
		}
		$guard = self::guard( $module, $callback, $label );
		if ( null === $fallback ) {
			return $guard;
		}
		return static function ( ...$args ) use ( $guard, $fallback, $module ) {
			$result = $guard( ...$args );
			return isset( self::$failed[ $module ] ) ? $fallback : $result;
		};
	}

	/**
	 * A REST route callback with the guard: after a failure it answers 503 instead.
	 *
	 * @param callable $callback Route callback.
	 */
	public static function rest( callable $callback ): callable {
		$module = self::module_of( $callback );
		if ( null === $module ) {
			return $callback;
		}
		$guard = self::guard( $module, $callback, 'REST' );
		return static function ( ...$args ) use ( $guard, $module ) {
			$result = $guard( ...$args );
			if ( isset( self::$failed[ $module ] ) ) {
				return new \WP_Error( 'lachinata_module_failed', __( 'Este servicio no está disponible ahora mismo.', 'lachinata-core' ), array( 'status' => 503 ) );
			}
			return $result;
		};
	}

	/**
	 * Runs a module's code (its boot) with the guard. False when it failed.
	 *
	 * @param string   $module Module id.
	 * @param callable $run    Code.
	 * @param string   $label  What it is, for the record.
	 * @throws \Throwable The exceptions that are part of a module's behaviour (EXPECTED).
	 */
	public static function run( string $module, callable $run, string $label ): bool {
		if ( isset( self::$failed[ $module ] ) ) {
			return false;
		}
		$previous      = self::$current;
		self::$current = $module;
		try {
			$run();
			return true;
		} catch ( \Throwable $error ) {
			if ( self::expected( $error ) ) {
				throw $error;
			}
			self::fail( $module, $label, $error );
			return false;
		} finally {
			self::$current = $previous;
		}
	}

	/**
	 * Whether a module failed in this request.
	 *
	 * @param string $module Module id.
	 */
	public static function failed( string $module ): bool {
		return isset( self::$failed[ $module ] );
	}

	/**
	 * Modules that failed in this request.
	 *
	 * @return array<string, \Throwable>
	 */
	public static function failures(): array {
		return self::$failed;
	}

	/**
	 * Forgets the failures of this request (tests).
	 */
	public static function reset(): void {
		self::$failed  = array();
		self::$current = null;
	}

	/**
	 * Record of the failures of a module (its GapLog, entries `fallo:*`).
	 *
	 * @param string $module Module id.
	 */
	public static function log( string $module ): GapLog {
		return new GapLog( 'lachinata_' . $module . '_gaps', 'lachinata-' . $module );
	}

	/**
	 * Guard around a callback: passes the first argument through once the module failed.
	 *
	 * @param string   $module   Module id.
	 * @param callable $callback Callback.
	 * @param string   $hook     Hook or label, for the record.
	 */
	private static function guard( string $module, callable $callback, string $hook ): \Closure {
		return static function ( ...$args ) use ( $module, $callback, $hook ) {
			if ( isset( self::$failed[ $module ] ) ) {
				return $args[0] ?? null;
			}
			$previous      = self::$current;
			self::$current = $module;
			try {
				return $callback( ...$args );
			} catch ( \Throwable $error ) {
				if ( self::expected( $error ) ) {
					throw $error;
				}
				self::fail( $module, $hook, $error );
				return $args[0] ?? null;
			} finally {
				self::$current = $previous;
			}
		};
	}

	/**
	 * Switches the module off for the request and records the failure.
	 *
	 * @param string     $module Module id.
	 * @param string     $where  Hook or label.
	 * @param \Throwable $error  Failure.
	 */
	private static function fail( string $module, string $where, \Throwable $error ): void {
		self::$failed[ $module ] = $error;
		if ( did_action( 'init' ) ) {
			self::record( $module, $where, $error );
		} else {
			// Translations load on init: a failure while booting is recorded then.
			add_action( 'init', static fn() => self::record( $module, $where, $error ), 0 );
		}

		/**
		 * A module failed and is off for the rest of the request.
		 *
		 * @since 0.9.0
		 *
		 * @param string     $module Module id.
		 * @param string     $where  Hook or label where it failed.
		 * @param \Throwable $error  Failure.
		 */
		do_action( 'lachinata/core/module_failed', $module, $where, $error );
	}

	/**
	 * Writes a failure in the module's GapLog (and WooCommerce's log).
	 *
	 * @param string     $module Module id.
	 * @param string     $where  Hook or label.
	 * @param \Throwable $error  Failure.
	 */
	private static function record( string $module, string $where, \Throwable $error ): void {
		$file = str_replace( LACHINATA_CORE_DIR . '/', '', $error->getFile() );
		self::log( $module )->record(
			'fallo:' . $where . ':' . $file . ':' . $error->getLine(),
			sprintf(
				/* translators: 1: module id, 2: hook, 3: error message. */
				__( 'El módulo %1$s ha fallado en %2$s y se ha apagado en esa petición: %3$s', 'lachinata-core' ),
				$module,
				'' === $where ? 'boot' : $where,
				$error->getMessage()
			),
			array(
				'tipo'    => 'fallo',
				'hook'    => $where,
				'clase'   => get_class( $error ),
				'archivo' => $file . ':' . $error->getLine(),
			)
		);
	}

	/**
	 * Whether an exception is part of the module's behaviour.
	 *
	 * @param \Throwable $error Exception.
	 */
	private static function expected( \Throwable $error ): bool {
		foreach ( self::EXPECTED as $class_name ) {
			if ( $error instanceof $class_name ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Module of a callback: its namespace, or the module running now.
	 *
	 * @param callable $callback Callback.
	 */
	private static function module_of( callable $callback ): ?string {
		$class_name = null;
		if ( is_array( $callback ) ) {
			$class_name = is_object( $callback[0] ) ? get_class( $callback[0] ) : (string) $callback[0];
		} elseif ( $callback instanceof \Closure ) {
			$scope      = ( new \ReflectionFunction( $callback ) )->getClosureScopeClass();
			$class_name = null === $scope ? null : $scope->getName();
		} elseif ( is_object( $callback ) ) {
			$class_name = get_class( $callback );
		}
		if ( null !== $class_name && 1 === preg_match( '/^LaChinata\\\\Core\\\\Modules\\\\([A-Za-z0-9]+)\\\\/', $class_name, $match ) ) {
			return strtolower( $match[1] );
		}
		return self::$current;
	}

	/**
	 * Key of a callback, the same for the callback when it is added and removed.
	 *
	 * @param callable $callback Callback.
	 */
	private static function key( callable $callback ): string {
		if ( is_string( $callback ) ) {
			return $callback;
		}
		if ( is_array( $callback ) ) {
			return ( is_object( $callback[0] ) ? spl_object_hash( $callback[0] ) : (string) $callback[0] ) . '::' . (string) $callback[1];
		}
		return spl_object_hash( $callback );
	}
}
