<?php
/**
 * Reply-To of the shop's emails.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core;

defined( 'ABSPATH' ) || exit;

/**
 * «Responde a este correo» (06-correos.md, `help`) must reach customer service: the emails
 * to customers reply to the «Atención al cliente» address when there is one, instead of
 * the sender's. WooCommerce's own Reply-To setting (WooCommerce → Ajustes → Correos), when
 * switched on, wins: it is the shop saying so explicitly. The internal emails keep
 * WooCommerce's Reply-To (the buyer), so the shop answers the buyer directly.
 */
final class Mail {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_filter( 'woocommerce_email_headers', array( self::class, 'headers' ), 20, 4 );
	}

	/**
	 * Swaps the Reply-To of the customer emails.
	 *
	 * @param mixed $headers  Headers.
	 * @param mixed $email_id Email id.
	 * @param mixed $item     Object of the email.
	 * @param mixed $email    Email.
	 */
	public static function headers( $headers, $email_id = '', $item = null, $email = null ): string {
		unset( $email_id, $item );
		$headers = is_string( $headers ) ? $headers : '';
		$address = Contact::get()['email'];
		if ( '' === $address || ! is_email( $address ) || ! $email instanceof \WC_Email || ! $email->is_customer_email() || $email->get_reply_to_enabled() ) {
			return $headers;
		}
		$name    = wp_specialchars_decode( $email->get_from_name(), ENT_QUOTES );
		$headers = (string) preg_replace( '/^Reply-to:.*\r?\n/mi', '', $headers );
		return $headers . 'Reply-to: ' . $name . ' <' . $address . ">\r\n";
	}
}
