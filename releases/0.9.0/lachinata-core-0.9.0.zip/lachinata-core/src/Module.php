<?php
/**
 * Base class for every module.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core;

defined( 'ABSPATH' ) || exit;

/**
 * A feature that each site can switch on or off. Nothing in a module runs until boot().
 */
abstract class Module {

	/**
	 * Unique identifier, also used in hooks and options (`lachinata_<id>_*`).
	 */
	abstract public function id(): string;

	/**
	 * Human readable name for the admin screen.
	 */
	abstract public function label(): string;

	/**
	 * Short description for the admin screen.
	 */
	public function description(): string {
		return '';
	}

	/**
	 * Requirements: other module ids and the minimum WordPress and WooCommerce versions.
	 *
	 * @return array{modules?: string[], WordPress?: string, woocommerce?: string}
	 */
	public function requires(): array {
		return array();
	}

	/**
	 * Plugin version in which the module was added.
	 */
	abstract public function since(): string;

	/**
	 * Where the module is documented, as a path relative to the repository root.
	 */
	abstract public function docs(): string;

	/**
	 * Settings of the module, stored in `lachinata_<id>_<key>` options.
	 * `export => false` keeps a setting out of the JSON (site-specific values).
	 *
	 * @return array<string, array{type: 'bool'|'int'|'float'|'string'|'array', default: mixed, export?: bool}>
	 */
	public function settings(): array {
		return array();
	}

	/**
	 * Extra configuration of the module for the JSON export (beyond its settings).
	 *
	 * @return array<string, mixed>
	 */
	public function export_data(): array {
		return array();
	}

	/**
	 * Problems with an imported `data` section, as readable messages. Nothing is written
	 * when this returns messages.
	 *
	 * @param array<string, mixed> $data Section exported by export_data() on another site.
	 * @return string[]
	 */
	public function validate_data( array $data ): array {
		return $data ? array( __( 'Este módulo no importa datos propios.', 'lachinata-core' ) ) : array();
	}

	/**
	 * Writes an imported `data` section that passed validate_data().
	 *
	 * @param array<string, mixed> $data Section exported by export_data() on another site.
	 */
	public function import_data( array $data ): void {
		unset( $data );
	}

	/**
	 * Version of the data the module stores. Raise it with each migration.
	 */
	public function schema_version(): int {
		return 1;
	}

	/**
	 * Steps that bring the stored data to schema_version(), by the version they lead to.
	 * Each one is idempotent (running it twice changes nothing), additive (it writes the new
	 * shape and keeps the old one at least one minor version, so the previous zip still
	 * works) and never deletes data. They run before boot(), when the plugin updates and
	 * when the module is switched on.
	 *
	 * @return array<int, callable(): void>
	 */
	public function migrations(): array {
		return array();
	}

	/**
	 * State for WooCommerce → Estado: whether it is configured enough to work and whether
	 * the credentials it needs are there (never their values). Null when it does not apply.
	 *
	 * @return array{configured: bool|null, credentials: bool|null, notes: string[]}
	 */
	public function health(): array {
		return array(
			'configured'  => null,
			'credentials' => null,
			'notes'       => array(),
		);
	}

	/**
	 * What the module stores beyond its `lachinata_<id>_*` options and transients, for the
	 * catalogue of data and for «Borrar datos». Product, term and user meta are deleted
	 * with the module's data; order meta never (it is the order's history).
	 *
	 * @return array{product_meta?: string[], term_meta?: string[], user_meta?: string[], order_meta?: string[], options?: string[]}
	 */
	public function owned_data(): array {
		return array();
	}

	/**
	 * Registers the module hooks with Hooks::add_action()/add_filter(). Called once, on
	 * `plugins_loaded`, only when enabled and with its requirements running.
	 */
	abstract public function boot(): void;
}
