<?php
/**
 * Order lookups shared by the modules.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Finds orders by a meta value, with HPOS or with the posts store: a short link opened, a
 * WhatsApp status that arrives, a personal data request.
 */
final class Orders {

	/**
	 * Ids of the orders with a meta value, with HPOS or with the posts store.
	 *
	 * @param string $key   Meta key.
	 * @param string $value Meta value.
	 * @param int    $limit Most orders.
	 * @return int[]
	 */
	public static function with_meta( string $key, string $value, int $limit ): array {
		$hpos = class_exists( \Automattic\WooCommerce\Utilities\OrderUtil::class ) && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
		if ( $hpos ) {
			$ids = wc_get_orders(
				array(
					'limit'      => $limit,
					'type'       => 'shop_order',
					'return'     => 'ids',
					'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Rare lookups: a short link opened, a status from WhatsApp, a personal data request.
						array(
							'key'   => $key,
							'value' => $value,
						),
					),
				)
			);
		} else {
			$ids = get_posts(
				array(
					'post_type'      => 'shop_order',
					'post_status'    => 'any',
					'posts_per_page' => $limit,
					'fields'         => 'ids',
					'meta_key'       => $key, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Same.
					'meta_value'     => $value, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- Same.
				)
			);
		}
		return array_map( 'intval', is_array( $ids ) ? $ids : array() );
	}
}
