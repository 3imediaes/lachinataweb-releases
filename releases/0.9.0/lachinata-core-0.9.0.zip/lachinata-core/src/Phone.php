<?php
/**
 * Mobile numbers for the notices.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Normalises a mobile number to international format (+34600000000): spaces, dots,
 * dashes and brackets out, «00» as «+», and the calling code of the delivery country when
 * there is none. In Spain only mobiles (9 digits starting with 6 or 7) can receive a notice.
 */
final class Phone {

	/**
	 * The number in international format, or null when it cannot be a mobile.
	 *
	 * @param string $number  Number as typed.
	 * @param string $country ISO code of the delivery country.
	 */
	public static function normalize( string $number, string $country ): ?string {
		$number = (string) preg_replace( '/[\s.\-()\/]/', '', $number );
		if ( str_starts_with( $number, '00' ) ) {
			$number = '+' . substr( $number, 2 );
		}
		if ( ! preg_match( '/^\+?\d+$/', $number ) ) {
			return null;
		}
		if ( ! str_starts_with( $number, '+' ) ) {
			$code   = self::calling_code( '' === $country ? 'ES' : $country );
			$number = '' === $code ? '' : $code . ltrim( $number, '0' );
		}
		if ( str_starts_with( $number, '+34' ) ) {
			return preg_match( '/^\+34[67]\d{8}$/', $number ) ? $number : null;
		}
		return preg_match( '/^\+[1-9]\d{7,14}$/', $number ) ? $number : null;
	}

	/**
	 * Calling code of a country («+34»), from WooCommerce.
	 *
	 * @param string $country ISO code.
	 */
	private static function calling_code( string $country ): string {
		$code = function_exists( 'WC' ) && WC()->countries ? WC()->countries->get_country_calling_code( strtoupper( $country ) ) : '';
		$code = is_array( $code ) ? (string) reset( $code ) : (string) $code;
		return preg_match( '/^\+\d+$/', $code ) ? $code : '';
	}
}
