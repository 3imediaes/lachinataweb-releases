<?php
/**
 * Typed module settings.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Reads and writes the settings a module declares in Module::settings(), one option each.
 */
final class Settings {

	/**
	 * Option name of a setting: `lachinata_<module>_<key>`.
	 *
	 * @param Module $module Module.
	 * @param string $key    Setting key.
	 */
	public static function option( Module $module, string $key ): string {
		return 'lachinata_' . $module->id() . '_' . $key;
	}

	/**
	 * Current value, or the declared default.
	 *
	 * @param Module $module Module.
	 * @param string $key    Setting key.
	 * @return mixed
	 */
	public static function get( Module $module, string $key ) {
		$schema = $module->settings()[ $key ] ?? null;
		if ( null === $schema ) {
			return null;
		}
		$value = self::from_storage( $schema['type'], get_option( self::option( $module, $key ), null ) );
		return null !== $value ? $value : $schema['default'];
	}

	/**
	 * Typed value from what the options table returns. WordPress stores scalars as text
	 * (150.0 comes back as "150", true as "1"), so numbers and booleans are read back here.
	 *
	 * @param string $type  Declared type.
	 * @param mixed  $value Stored value, null when missing.
	 * @return mixed Null when the stored value does not fit the type.
	 */
	private static function from_storage( string $type, $value ) {
		if ( null === $value || self::is_valid( $type, $value ) ) {
			return 'float' === $type && is_int( $value ) ? (float) $value : $value;
		}
		if ( ! is_string( $value ) ) {
			return null;
		}
		switch ( $type ) {
			case 'bool':
				return in_array( $value, array( '1', '0', '' ), true ) ? ( '1' === $value ) : null;
			case 'int':
				return 1 === preg_match( '/^-?\d+$/', $value ) ? (int) $value : null;
			case 'float':
				return is_numeric( $value ) ? (float) $value : null;
			default:
				return null;
		}
	}

	/**
	 * Saves a value. Values of the wrong type are refused.
	 *
	 * @param Module $module Module.
	 * @param string $key    Setting key.
	 * @param mixed  $value  Value.
	 */
	public static function set( Module $module, string $key, $value ): bool {
		$schema = $module->settings()[ $key ] ?? null;
		if ( null === $schema || ! self::is_valid( $schema['type'], $value ) ) {
			return false;
		}
		update_option( self::option( $module, $key ), 'bool' === $schema['type'] ? ( $value ? '1' : '0' ) : $value );
		return true;
	}

	/**
	 * All settings of a module with their current values.
	 *
	 * @param Module $module          Module.
	 * @param bool   $exportable_only Leave out the settings declared with `export => false`.
	 * @return array<string, mixed>
	 */
	public static function all( Module $module, bool $exportable_only = false ): array {
		$values = array();
		foreach ( $module->settings() as $key => $schema ) {
			if ( $exportable_only && false === ( $schema['export'] ?? true ) ) {
				continue;
			}
			$values[ $key ] = self::get( $module, $key );
		}
		return $values;
	}

	/**
	 * Whether a value has the declared type. Strict: imports never guess.
	 *
	 * @param string $type  bool, int, float, string or array.
	 * @param mixed  $value Value.
	 */
	public static function is_valid( string $type, $value ): bool {
		return match ( $type ) {
			'bool'   => is_bool( $value ),
			'int'    => is_int( $value ),
			'float'  => is_int( $value ) || is_float( $value ),
			'string' => is_string( $value ),
			'array'  => is_array( $value ),
			default  => false,
		};
	}
}
