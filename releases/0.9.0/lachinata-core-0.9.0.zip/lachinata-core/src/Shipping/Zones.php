<?php
/**
 * WooCommerce's shipping zones, methods and classes, as the modules read them.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Shipping;

defined( 'ABSPATH' ) || exit;

/**
 * Stateless reads of WooCommerce's shipping setup shared by `shipping` and `eta` (each
 * instance keeps its own `lc_*` settings next to WooCommerce's), and the signal that the
 * setup changed.
 */
final class Zones {

	/**
	 * Every zone, the rest of the world (id 0) last.
	 *
	 * @return array<int, \WC_Shipping_Zone>
	 */
	public static function all(): array {
		$zones = array();
		foreach ( \WC_Shipping_Zones::get_zones() as $data ) {
			$zones[ (int) $data['id'] ] = new \WC_Shipping_Zone( (int) $data['id'] );
		}
		$zones[0] = new \WC_Shipping_Zone( 0 );
		return $zones;
	}

	/**
	 * Zone matching a destination.
	 *
	 * @param array{country: string, state?: string, postcode?: string} $destination Destination.
	 */
	public static function for_destination( array $destination ): \WC_Shipping_Zone {
		return \WC_Shipping_Zones::get_zone_matching_package(
			array(
				'destination' => array(
					'country'  => $destination['country'],
					'state'    => $destination['state'] ?? '',
					'postcode' => $destination['postcode'] ?? '',
				),
			)
		);
	}

	/**
	 * Every instance of every zone, by instance id.
	 *
	 * @return array<int, array{zone: \WC_Shipping_Zone, method: \WC_Shipping_Method}>
	 */
	public static function instances(): array {
		$instances = array();
		foreach ( self::all() as $zone ) {
			foreach ( $zone->get_shipping_methods() as $method ) {
				if ( $method instanceof \WC_Shipping_Method && $method->get_instance_id() ) {
					$instances[ (int) $method->get_instance_id() ] = array(
						'zone'   => $zone,
						'method' => $method,
					);
				}
			}
		}
		return $instances;
	}

	/**
	 * Settings of an instance as WooCommerce stores them.
	 *
	 * @param \WC_Shipping_Method $method Instance.
	 * @return array<string, mixed>
	 */
	public static function instance_settings( \WC_Shipping_Method $method ): array {
		$settings = get_option( $method->get_instance_option_key(), array() );
		return is_array( $settings ) ? $settings : array();
	}

	/**
	 * Shipping classes, slug → name.
	 *
	 * @return array<string, string>
	 */
	public static function class_options(): array {
		$options = array();
		foreach ( WC()->shipping()->get_shipping_classes() as $class ) {
			$options[ (string) $class->slug ] = (string) $class->name;
		}
		return $options;
	}

	/**
	 * After a change in the shipping setup: WooCommerce recalculates its cached rates and
	 * the modules forget what they memoised.
	 */
	public static function changed(): void {
		if ( class_exists( \WC_Cache_Helper::class ) ) {
			\WC_Cache_Helper::get_transient_version( 'shipping', true );
		}

		/**
		 * The shipping setup changed (zone rules, restrictions, instance settings, delivery
		 * times): forget memoised decisions and rates.
		 *
		 * @since 0.9.0
		 */
		do_action( 'lachinata/shipping/changed' );
	}
}
