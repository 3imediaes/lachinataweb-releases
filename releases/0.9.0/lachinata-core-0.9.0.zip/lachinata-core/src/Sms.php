<?php
/**
 * Length and alphabet of an SMS.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core;

defined( 'ABSPATH' ) || exit;

/**
 * The notices go with accents, so as UCS-2: two segments are at most 134 characters
 * (decisiones.md, 24/10/2026). `gift` and `shipment` cut their texts to it; `notify` tells
 * OVH the coding.
 */
final class Sms {

	/**
	 * Most UCS-2 code units of two segments (67 each).
	 */
	public const MAX = 134;

	/**
	 * Length in UCS-2 code units (an emoji counts two).
	 *
	 * @param string $text Text.
	 */
	public static function length( string $text ): int {
		return (int) ( strlen( (string) mb_convert_encoding( $text, 'UTF-16BE', 'UTF-8' ) ) / 2 );
	}

	/**
	 * Whether the text fits GSM 03.38 (7 bits); otherwise it goes as UCS-2.
	 *
	 * @param string $text Text.
	 */
	public static function is_gsm( string $text ): bool {
		$basic = "@£\$¥èéùìòÇ\nØø\rÅåΔ_ΦΓΛΩΠΨΣΘΞÆæßÉ !\"#¤%&'()*+,-./0123456789:;<=>?¡ABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÑÜ§¿abcdefghijklmnopqrstuvwxyzäöñüà^{}\\[~]|€";
		foreach ( mb_str_split( $text ) as $char ) {
			if ( ! str_contains( $basic, $char ) ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * The first text that fits, or the last one cut to the maximum.
	 *
	 * @param string[] $variants Texts from the fullest to the shortest.
	 */
	public static function first_fitting( array $variants ): string {
		foreach ( $variants as $text ) {
			if ( self::length( $text ) <= self::MAX ) {
				return $text;
			}
		}
		$last = (string) end( $variants );
		return mb_substr( $last, 0, self::MAX );
	}
}
