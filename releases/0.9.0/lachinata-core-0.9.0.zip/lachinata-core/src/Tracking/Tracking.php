<?php
/**
 * Tracking of an order.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Tracking;

use LaChinata\Core\Contracts\TrackingSource;

defined( 'ABSPATH' ) || exit;

/**
 * The latest tracking of an order from the registered sources: WooCommerce Shipment
 * Tracking, written by Odoo, is the only one today (decisiones.md, 24/10/2026). It belongs
 * to the core because `gift`, `notify` (the short link) and `shipment` read it.
 */
final class Tracking {

	/**
	 * Latest tracking of an order, or null.
	 *
	 * @param \WC_Order $order Order.
	 * @return array{carrier: string, number: string, url: string, shipped: int|null}|null
	 */
	public static function of( \WC_Order $order ): ?array {
		/**
		 * Where the tracking of an order comes from (first answer wins).
		 *
		 * @since 0.8.0
		 *
		 * @param TrackingSource[] $sources WooCommerce Shipment Tracking by default.
		 */
		$sources = (array) apply_filters( 'lachinata/tracking/sources', array( new ShipmentTracking() ) );
		$sources = (array) apply_filters_deprecated( 'lachinata/gift/tracking_sources', array( $sources ), '0.8.0', 'lachinata/tracking/sources' );
		foreach ( $sources as $source ) {
			$found = $source instanceof TrackingSource ? $source->find( $order ) : null;
			if ( null !== $found ) {
				return $found;
			}
		}
		return null;
	}
}
