<?php
/**
 * Public version manifest.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Updates;

use WP_Error;

defined( 'ABSPATH' ) || exit;

/**
 * Reads the version manifest that each release publishes in the public distribution
 * repository (3imediaes/lachinataweb-releases, GitHub Pages). No token: the source code
 * stays private, the zips are public.
 */
final class Manifest {

	/**
	 * Where the manifests and zips are published.
	 */
	public const BASE_URL = 'https://3imediaes.github.io/lachinataweb-releases/';

	/**
	 * Version of the manifest structure this plugin understands.
	 */
	public const SCHEMA = 1;

	/**
	 * Site transient with the last answer (packages or error) and when it was read.
	 */
	public const CACHE = 'lachinata_core_manifest';

	/**
	 * How long a manifest is reused before reading it again.
	 */
	private const TTL = 12 * HOUR_IN_SECONDS;

	/**
	 * How long an error is reused, so an unreachable manifest is not asked on every page.
	 */
	private const ERROR_TTL = HOUR_IN_SECONDS;

	/**
	 * Builds the client.
	 *
	 * @param bool $prereleases Read manifest-prerelease.json (staging) instead of manifest.json.
	 */
	public function __construct( private bool $prereleases = false ) {}

	/**
	 * Client configured from wp-config.php.
	 */
	public static function from_constants(): self {
		return new self( defined( 'LACHINATA_UPDATE_PRERELEASES' ) && (bool) constant( 'LACHINATA_UPDATE_PRERELEASES' ) );
	}

	/**
	 * Whether prereleases are offered.
	 */
	public function prereleases(): bool {
		return $this->prereleases;
	}

	/**
	 * Base URL of the distribution (manifests and zips).
	 */
	public static function base_url(): string {
		/**
		 * Base URL of the version distribution (a mirror, or a local copy for tests).
		 *
		 * @since 0.3.2
		 *
		 * @param string $url URL ending in a slash.
		 */
		return trailingslashit( (string) apply_filters( 'lachinata/core/releases_url', self::BASE_URL ) );
	}

	/**
	 * URL of the manifest this site reads.
	 */
	public function url(): string {
		return self::base_url() . ( $this->prereleases ? 'manifest-prerelease.json' : 'manifest.json' );
	}

	/**
	 * Packages of the newest version, from the cache unless forced.
	 *
	 * @param bool $force Read the manifest even if the cache is fresh.
	 * @return array<string, Package>|WP_Error Keyed by slug.
	 */
	public function packages( bool $force = false ) {
		$cached = $force ? false : get_site_transient( self::CACHE );
		if ( ! is_array( $cached ) || ( $cached['url'] ?? '' ) !== $this->url() ) {
			$cached = $this->fetch();
			set_site_transient( self::CACHE, $cached, isset( $cached['error'] ) ? self::ERROR_TTL : self::TTL );
		}
		if ( isset( $cached['error'] ) && is_array( $cached['error'] ) ) {
			return new WP_Error( (string) $cached['error']['code'], (string) $cached['error']['message'] );
		}
		$packages = array();
		foreach ( is_array( $cached['packages'] ?? null ) ? $cached['packages'] : array() as $slug => $data ) {
			$package = Package::from_array( $data );
			if ( null !== $package ) {
				$packages[ (string) $slug ] = $package;
			}
		}
		return $packages;
	}

	/**
	 * One package of the newest version, or null (also when the manifest cannot be read).
	 *
	 * @param string $slug lachinata or lachinata-core.
	 */
	public function package( string $slug ): ?Package {
		$packages = $this->packages();
		return is_array( $packages ) ? ( $packages[ $slug ] ?? null ) : null;
	}

	/**
	 * When the manifest was last read (Unix time), or 0.
	 */
	public static function checked_at(): int {
		$cached = get_site_transient( self::CACHE );
		return is_array( $cached ) ? (int) ( $cached['checked'] ?? 0 ) : 0;
	}

	/**
	 * Forgets the cached answer.
	 */
	public static function flush(): void {
		delete_site_transient( self::CACHE );
	}

	/**
	 * Reads the manifest.
	 *
	 * @return array{checked: int, url: string, packages?: array<string, array<string, mixed>>, error?: array{code: string, message: string}}
	 */
	private function fetch(): array {
		$url      = $this->url();
		$result   = array(
			'checked' => time(),
			'url'     => $url,
		);
		$response = wp_remote_get(
			$url,
			array(
				'timeout' => 10,
				'headers' => array( 'Accept' => 'application/json' ),
			)
		);

		if ( is_wp_error( $response ) ) {
			$result['error'] = array(
				'code'    => 'lachinata_manifest_unreachable',
				/* translators: %s: error message. */
				'message' => sprintf( __( 'No se pudo conectar con el servidor de versiones: %s', 'lachinata-core' ), $response->get_error_message() ),
			);
			return $result;
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( 404 === $code ) {
			$result['error'] = array(
				'code'    => 'lachinata_manifest_missing',
				'message' => __( 'El manifiesto de versiones no existe en el servidor de distribución.', 'lachinata-core' ),
			);
			return $result;
		}
		if ( 200 !== $code ) {
			$result['error'] = array(
				'code'    => 'lachinata_manifest_unreachable',
				/* translators: %d: HTTP status code. */
				'message' => sprintf( __( 'El servidor de versiones ha respondido con un error (%d).', 'lachinata-core' ), $code ),
			);
			return $result;
		}

		$manifest = json_decode( wp_remote_retrieve_body( $response ), true );
		$schema   = is_array( $manifest ) ? ( $manifest['schema'] ?? null ) : null;
		if ( ! is_int( $schema ) || ! is_array( $manifest['packages'] ?? null ) ) {
			$result['error'] = array(
				'code'    => 'lachinata_manifest_invalid',
				'message' => __( 'El manifiesto de versiones no tiene el formato esperado.', 'lachinata-core' ),
			);
			return $result;
		}
		if ( $schema > self::SCHEMA ) {
			$result['error'] = array(
				'code'    => 'lachinata_manifest_newer',
				'message' => __( 'El manifiesto usa un formato posterior al que entiende esta versión del plugin. Instala a mano la última versión.', 'lachinata-core' ),
			);
			return $result;
		}
		$packages = array();
		foreach ( $manifest['packages'] as $slug => $data ) {
			$package = Package::from_array( $data );
			if ( null !== $package ) {
				$packages[ (string) $slug ] = $package->to_array();
			}
		}
		$result['packages'] = $packages;
		return $result;
	}

	/**
	 * Downloads a zip of the manifest and checks its SHA-256.
	 *
	 * @param Package $package Package.
	 * @return string|WP_Error Path of the temporary file.
	 */
	public static function download( Package $package ) {
		if ( ! function_exists( 'download_url' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$file = download_url( $package->url, 300 );
		if ( is_wp_error( $file ) ) {
			return $file;
		}
		$hash = hash_file( 'sha256', $file );
		if ( ! is_string( $hash ) || ! hash_equals( $package->sha256, $hash ) ) {
			wp_delete_file( $file );
			return new WP_Error(
				'lachinata_checksum',
				/* translators: %s: zip file name. */
				sprintf( __( 'La descarga de %s no coincide con su huella SHA-256 del manifiesto. No se ha instalado nada; vuelve a intentarlo más tarde.', 'lachinata-core' ), basename( $package->url ) )
			);
		}
		return $file;
	}
}
