<?php
/**
 * One package of the version manifest.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Updates;

defined( 'ABSPATH' ) || exit;

/**
 * Version, zip and requirements of the theme (`lachinata`) or the plugin (`lachinata-core`).
 */
final class Package {

	/**
	 * Builds the package.
	 *
	 * @param string                $version  Version.
	 * @param string                $date     Release date (YYYY-MM-DD).
	 * @param string                $url      HTTPS URL of the zip.
	 * @param string                $sha256   SHA-256 of the zip, hexadecimal.
	 * @param array<string, string> $requires Minimum versions: WordPress, php, woocommerce and the other package.
	 * @param string                $notes    Release notes (Markdown, from the CHANGELOG).
	 */
	public function __construct(
		public readonly string $version,
		public readonly string $date,
		public readonly string $url,
		public readonly string $sha256,
		public readonly array $requires,
		public readonly string $notes
	) {}

	/**
	 * Builds a package from its manifest entry; null when the entry is incomplete.
	 *
	 * @param mixed $data Manifest entry.
	 */
	public static function from_array( $data ): ?self {
		if ( ! is_array( $data ) ) {
			return null;
		}
		$version = $data['version'] ?? null;
		$url     = $data['url'] ?? null;
		$sha256  = $data['sha256'] ?? null;
		if (
			! is_string( $version ) || ! preg_match( '/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/', $version )
			|| ! is_string( $url ) || ! str_starts_with( $url, 'https://' )
			|| ! is_string( $sha256 ) || ! preg_match( '/^[0-9a-f]{64}$/', $sha256 )
		) {
			return null;
		}
		$requires = array();
		foreach ( is_array( $data['requires'] ?? null ) ? $data['requires'] : array() as $key => $value ) {
			if ( is_string( $value ) ) {
				$requires[ (string) $key ] = $value;
			}
		}
		return new self(
			$version,
			is_string( $data['date'] ?? null ) ? $data['date'] : '',
			$url,
			$sha256,
			$requires,
			is_string( $data['notes'] ?? null ) ? $data['notes'] : ''
		);
	}

	/**
	 * Release notes as HTML: the CHANGELOG subset (### headings, «- » lists, `code`), escaped.
	 */
	public function notes_html(): string {
		$html = '';
		$list = false;
		foreach ( (array) preg_split( '/\R/', $this->notes ) as $line ) {
			$line = trim( $line );
			$text = preg_replace( '/`([^`]+)`/', '<code>$1</code>', esc_html( (string) preg_replace( '/^(#+|-)\s*/', '', $line ) ) );
			if ( str_starts_with( $line, '- ' ) ) {
				$html .= ( $list ? '' : '<ul>' ) . '<li>' . $text . '</li>';
				$list  = true;
				continue;
			}
			if ( $list ) {
				$html .= '</ul>';
				$list  = false;
			}
			if ( '' === $line ) {
				continue;
			}
			$html .= str_starts_with( $line, '#' ) ? '<h4>' . $text . '</h4>' : '<p>' . $text . '</p>';
		}
		return $html . ( $list ? '</ul>' : '' );
	}

	/**
	 * Plain array, the same shape as the manifest entry.
	 *
	 * @return array{version: string, date: string, url: string, sha256: string, requires: array<string, string>, notes: string}
	 */
	public function to_array(): array {
		return array(
			'version'  => $this->version,
			'date'     => $this->date,
			'url'      => $this->url,
			'sha256'   => $this->sha256,
			'requires' => $this->requires,
			'notes'    => $this->notes,
		);
	}
}
