<?php
/**
 * Data changes between versions.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Steps that run once when a site updates the plugin, before the modules boot. Each step
 * is idempotent (running it twice changes nothing) and never deletes data.
 */
final class Upgrades {

	/**
	 * Option with the last version whose steps ran.
	 */
	public const OPTION = 'lachinata_core_data_version';

	/**
	 * Runs the steps newer than the saved version.
	 *
	 * @param ModuleRegistry $modules Registry (modules registered, not booted).
	 */
	public static function run( ModuleRegistry $modules ): void {
		$done = (string) get_option( self::OPTION, '0' );
		if ( version_compare( $done, LACHINATA_CORE_VERSION, '>=' ) ) {
			return;
		}
		if ( version_compare( $done, '0.8.0', '<' ) ) {
			self::to_0_8_0( $modules );
		}
		update_option( self::OPTION, LACHINATA_CORE_VERSION, true );
	}

	/**
	 * 0.8.0: the SMS of the gift moves to the `notify` module. Where `gift` was on, `notify`
	 * is switched on (gift needs it) and the OVH credentials travel with it; the SMS channel
	 * is switched on only if they were complete (0.7 sent «registro» SMS without them).
	 *
	 * @param ModuleRegistry $modules Registry.
	 */
	public static function to_0_8_0( ModuleRegistry $modules ): void {
		if ( in_array( 'gift', $modules->enabled(), true ) && ! in_array( 'notify', $modules->enabled(), true ) ) {
			$modules->enable( 'notify' );
		}
		$keys     = array( 'ovh_endpoint', 'ovh_app_key', 'ovh_app_secret', 'ovh_consumer_key', 'ovh_service', 'ovh_sender' );
		$complete = true;
		foreach ( $keys as $key ) {
			$old = get_option( 'lachinata_gift_' . $key, null );
			if ( null === $old || '' === $old ) {
				$complete = 'ovh_endpoint' === $key ? $complete : false;
				continue;
			}
			if ( false === get_option( 'lachinata_notify_' . $key ) ) {
				update_option( 'lachinata_notify_' . $key, $old );
			}
		}
		if ( $complete && false === get_option( 'lachinata_notify_sms_enabled' ) ) {
			update_option( 'lachinata_notify_sms_enabled', '1' );
		}
	}
}
