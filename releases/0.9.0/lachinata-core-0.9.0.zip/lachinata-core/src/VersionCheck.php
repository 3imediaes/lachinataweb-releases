<?php
/**
 * Cross version check with the theme.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Theme and plugin share a version and each one declares the minimum of the other
 * (`LaChinata Theme Min` here, `LaChinata Core Min` in the theme). A mismatch is warned
 * in the admin, never blocked. The theme warns about the plugin; this warns about the theme.
 */
final class VersionCheck {

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_action( 'admin_notices', array( self::class, 'notice' ) );
	}

	/**
	 * Versions of both packages and what each one requires of the other.
	 *
	 * @return array{core: string, core_needs_theme: string, theme: string, theme_needs_core: string, theme_active: bool}
	 */
	public static function status(): array {
		$core  = get_file_data( LACHINATA_CORE_FILE, array( 'theme_min' => 'LaChinata Theme Min' ) );
		$theme = wp_get_theme( Updates\Updater::THEME_SLUG );
		$file  = $theme->exists() ? $theme->get_stylesheet_directory() . '/style.css' : '';
		$needs = '' !== $file ? get_file_data( $file, array( 'core_min' => 'LaChinata Core Min' ) )['core_min'] : '';
		return array(
			'core'             => LACHINATA_CORE_VERSION,
			'core_needs_theme' => $core['theme_min'],
			'theme'            => $theme->exists() ? (string) $theme->get( 'Version' ) : '',
			'theme_needs_core' => $needs,
			'theme_active'     => Updates\Updater::THEME_SLUG === get_template(),
		);
	}

	/**
	 * Warning when the active theme is older than this plugin needs, or null.
	 *
	 * @param string $theme_version Installed theme version.
	 * @param string $required      `LaChinata Theme Min` of the plugin.
	 */
	public static function theme_message( string $theme_version, string $required ): ?string {
		if ( '' === $theme_version || '' === $required || version_compare( $theme_version, $required, '>=' ) ) {
			return null;
		}
		return sprintf(
			/* translators: 1: required theme version, 2: installed theme version. */
			__( 'La Chinata Core necesita el tema La Chinata %1$s o superior; está instalada la %2$s. Actualiza el tema.', 'lachinata-core' ),
			$required,
			$theme_version
		);
	}

	/**
	 * Prints the warning for users who can update themes.
	 */
	public static function notice(): void {
		if ( ! current_user_can( 'update_themes' ) ) {
			return;
		}
		$status = self::status();
		if ( ! $status['theme_active'] ) {
			return;
		}
		$message = self::theme_message( $status['theme'], $status['core_needs_theme'] );
		if ( null !== $message ) {
			printf( '<div class="notice notice-warning"><p>%s</p></div>', esc_html( $message ) );
		}
	}
}
