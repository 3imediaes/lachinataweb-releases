# Módulo `eta`

Entrega estimada: la fecha en las opciones de envío, la ficha (con la cuenta atrás al corte), la bolsa, gracias y los correos, calculada por zona y método. Sustituye al plugin Estimated Delivery Date y conserva todo lo que este permitía configurar: corte por día de la semana, preparación, días de tránsito por instancia, transportistas con días sin reparto, festivos del almacén y del destino, y condiciones por clase de envío. Sin datos para una zona y un método, no muestra fecha.

Especificación: `design-system/sistema/04-envios-entrega.md` («Motor de entrega estimada»). Panel: WooCommerce → La Chinata → Entrega. Paso a producción: `docs/despliegue-envios.md`.

## Qué hace

| Pieza | Cómo | Dónde |
| --- | --- | --- |
| Configuración de la tienda: cortes por día, días de preparación, transportistas y sus días sin reparto, festivos del almacén y por país de destino, condiciones por clase de envío y el **método de referencia** de cada zona (el de la ficha y la bolsa) | Opción `lachinata_eta_config` | `EtaConfig.php`, `EtaTab.php` |
| Plan de cada instancia de envío (días de tránsito mínimo y máximo, transportista, días sin reparto) en el mismo panel que las condiciones de `shipping` | Claves `lc_eta_*` en los ajustes de la instancia (`woocommerce_shipping_instance_form_fields_<método>`) | `InstanceFields.php`, `Plan.php` |
| El cálculo: salida (corte, preparación, días del almacén), llegada mínima y máxima (tránsito, días sin reparto, festivos del destino) | Puro, sin WordPress | `Calculator.php`, `Estimator.php` |
| Fecha en cada tarifa: rango en `delivery_time` (el checkout de bloques lo pinta junto al precio) y `lc_eta`; los paquetes llevan un sello que cambia cada día y en cada corte, así que WooCommerce nunca sirve la fecha de ayer | `woocommerce_package_rates` (prioridad 30, después de `shipping`), `woocommerce_cart_shipping_packages` | `Rates.php` |
| El pedido guarda las fechas en su línea de envío (`_lc_eta`), ocultas en el panel y formateadas en los correos | `woocommerce_checkout_create_order_shipping_item`, `woocommerce_hidden_order_itemmeta`, `woocommerce_order_item_get_formatted_meta_data` | `Rates.php` |
| Ficha: el servidor imprime la fecha para el destino del visitante (la página puede ir en caché) y un script la refresca desde `GET /lachinata/v1/eta`, con la cuenta atrás al corte | `lachinata/product/availability`, REST | `Storefront.php`, `Rest.php`, `assets/` |
| Gracias y correos: titular «Llega jue 24 – vie 25 oct», datos clave «Entrega estimada», línea de envío de los totales, preheader de la confirmación, «Si lo pagas hoy…» del pedido telefónico; en texto plano, la frase tras la tabla | `lachinata/thankyou/delivery`, `lachinata/email/facts`, `intro`, `shipping_label`, `pay_today`; `woocommerce_email_after_order_table` | `Emails.php` |
| Fechas desde el día real de salida para los avisos: `lachinata/delivery/from_dispatch` (`shipment`) y `Contracts\DeliveryEstimator` (`gift`, `Services::delivery()`, 0.9.0) | `Rates::shipped()` | `Service.php`, `Calculator::from_dispatch()` |
| Festivos: Nager.Date solo cuando lo pide un administrador (con vista previa) y CSV `fecha;nombre`; después son entradas normales del calendario | Panel | `Holidays.php` |
| Plazo en el probador de envíos | `lachinata/shipping/simulation_eta` | `EtaModule::simulation()` |
| Un método sin plan o una zona sin método de referencia: Huecos de configuración | `GapLog` (`lachinata_eta_gaps`) | `Estimator::gaps()` |

Los textos de fecha («jue 24 – vie 25 oct», «el jueves 24») y el valor de las fechas son del núcleo desde la 0.9.0 (`Delivery\Format`, `Delivery\Estimate`), para que `gift` pueda formatear la fecha guardada sin `eta`. `Modules\Eta\Estimate` y `Modules\Eta\Format` quedan como alias hasta la 0.10.0.

## Depende de

- `shipping` (en `requires`): zonas, restricciones y destino. Lo pide por `Contracts\ShippingRules` (`Services::shipping_rules()`) y por las utilidades del núcleo (`Shipping\Zones`, `Shipping\Destination`, `Shipping\Package`); no usa clases de `shipping`.
- WooCommerce 10.

## Hooks que escucha

- `woocommerce_package_rates`, `woocommerce_cart_shipping_packages`, `woocommerce_checkout_create_order_shipping_item`, `woocommerce_hidden_order_itemmeta`, `woocommerce_order_item_get_formatted_meta_data`, `woocommerce_email_after_order_table`, `woocommerce_init`, `woocommerce_shipping_instance_form_fields_<método>`, `rest_api_init`.
- Del tema: `lachinata/product/availability`, `lachinata/thankyou/delivery`, `lachinata/email/facts`, `intro`, `shipping_label`, `pay_today`.
- De otros módulos y del núcleo: `lachinata/delivery/from_dispatch`, `lachinata/shipping/simulation_eta`, `lachinata/eta/service` (lo sirve), `lachinata/rest/order`, `lachinata/core/admin_tabs`.

## Hooks que emite

| Hook | Tipo | Para qué |
| --- | --- | --- |
| `lachinata/eta/rest_destination` `( ?array $destination, string $code )` | filtro | Destino del endpoint desde su parámetro `destino` (lo traducirá `locale`: «ES-IB» → `ES:PM`) |

Sirve `Contracts\DeliveryEstimator` con `lachinata/eta/service`. Catálogo: `plugin/HOOKS.md`.

## Datos que guarda

- Opción `lachinata_eta_config` (la configuración de la tienda) y registro de huecos `lachinata_eta_gaps`.
- Claves `lc_eta_*` en los ajustes de cada instancia de envío de WooCommerce (se van con la instancia; «Borrar datos» no las toca).
- Metadato de la línea de envío del pedido `_lc_eta` (`sale`, `llega_min`, `llega_max`); lo leen `gift` (sin `eta`) y la API.

## REST y API para Odoo

- `GET /wp-json/lachinata/v1/eta?product=<id>&destino=<código>`: fecha y cuenta atrás de la ficha, sin caché de página.
- `lachinata.delivery` del objeto de la API de pedidos (`ships`, `earliest`, `latest`); la clave es `delivery`, no `eta` (`docs/api-odoo.md`).

## Ajustes y exportación

Sin ajustes sueltos: todo es configuración del panel Entrega. `export_data()` lleva la configuración de la tienda (`config`) y el plan de cada instancia por su ID (`instances`). Al importar, cada instancia y cada método de referencia deben existir en el sitio, en la misma zona y con el mismo tipo.

## Qué pasa al apagarlo

Sin fechas en las opciones de envío, la ficha, la bolsa, gracias ni los correos (el tema pinta «Disponible» y el nombre del método). `gift` y `shipment` usan la fecha guardada en el pedido o ninguna («en los próximos días»). La configuración, los planes de cada instancia y las fechas de los pedidos se quedan.

## Pruebas

- `tests/CalculatorTest.php` (salida y llegada con cortes, preparación, días sin reparto, festivos y `from_dispatch`), `tests/FormatTest.php` (textos de fecha del núcleo, `Delivery\Format`), `tests/HolidaysTest.php` (Nager.Date y CSV).
- La configuración de lachinata.es con `shipping`: `tests/profiles/LaChinataEsTest.php`.
- En cada perfil: `tests/profiles/ProfileBootTest.php`. El módulo solo (con `shipping`): `tools/tests/modules-isolated.sh`.

## Huecos conocidos

- Plazos, cortes y días del frío provisionales hasta que logística valide el xlsx.
- Canarias y CZ sin plazos configurados en sus perfiles sintéticos (sin fecha hasta la fase C).
- El destino de la ficha sale de la zona por defecto hasta que `locale` rellene `lachinata/shipping/destination` (incremento 8).
