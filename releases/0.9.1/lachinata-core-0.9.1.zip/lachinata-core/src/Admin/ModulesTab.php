<?php
/**
 * La Chinata → Módulos.
 *
 * @package LaChinata\Core
 */

namespace LaChinata\Core\Admin;

use LaChinata\Core\Config\Exporter;
use LaChinata\Core\Module;
use LaChinata\Core\Plugin;

defined( 'ABSPATH' ) || exit;

/**
 * Switches modules on and off, with the version that added each one, and deletes the data of
 * one that is off.
 */
final class ModulesTab {

	/**
	 * Action of admin-post.php, also the nonce action.
	 */
	private const ACTION = 'lachinata_save_modules';

	/**
	 * Action of «Borrar datos», also the nonce action.
	 */
	private const DELETE = 'lachinata_delete_module_data';

	/**
	 * Registers the hooks.
	 */
	public static function boot(): void {
		add_action( 'admin_post_' . self::ACTION, array( self::class, 'save' ) );
		add_action( 'admin_post_' . self::DELETE, array( self::class, 'delete' ) );
	}

	/**
	 * Prints the tab.
	 */
	public static function render(): void {
		$registry = Plugin::instance()->modules();
		$enabled  = $registry->enabled();
		$delete   = isset( $_GET['delete'] ) ? $registry->get( sanitize_key( wp_unslash( $_GET['delete'] ) ) ) : null; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only shows the confirmation; delete() checks the nonce.
		if ( null !== $delete && ! in_array( $delete->id(), $enabled, true ) ) {
			self::render_delete( $delete );
			return;
		}
		?>
		<p><?php esc_html_e( 'Un módulo apagado no ejecuta nada y conserva sus datos: al encenderlo de nuevo vuelve como estaba. Los cambios se aplican al guardar.', 'lachinata-core' ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::ACTION ); ?>">
			<?php wp_nonce_field( self::ACTION ); ?>
			<table class="widefat striped lc-admin__modules">
				<thead>
					<tr>
						<th scope="col"><?php esc_html_e( 'Módulo', 'lachinata-core' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Activo', 'lachinata-core' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Añadido en', 'lachinata-core' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Datos', 'lachinata-core' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $registry->all() as $id => $module ) : ?>
						<?php
						$is_on   = in_array( $id, $enabled, true );
						$missing = $registry->missing_requirements( $module );
						?>
						<tr>
							<th scope="row">
								<label for="lc-module-<?php echo esc_attr( $id ); ?>"><strong><?php echo esc_html( $module->label() ); ?></strong> <code><?php echo esc_html( $id ); ?></code></label>
								<?php if ( $module->description() ) : ?>
									<p class="description"><?php echo esc_html( $module->description() ); ?></p>
								<?php endif; ?>
								<?php if ( $missing ) : ?>
									<p class="lc-admin__missing">
										<?php
										echo esc_html(
											$is_on
												/* translators: %s: unmet requirements. */
												? sprintf( __( 'Activado, pero no se ejecuta: %s', 'lachinata-core' ), implode( ' ', $missing ) )
												: implode( ' ', $missing )
										);
										?>
									</p>
								<?php endif; ?>
							</th>
							<td><input type="checkbox" id="lc-module-<?php echo esc_attr( $id ); ?>" name="modules[]" value="<?php echo esc_attr( $id ); ?>"<?php checked( $is_on ); ?>></td>
							<td><?php echo esc_html( $module->since() ); ?></td>
							<td>
								<?php if ( $is_on ) : ?>
									<span class="description"><?php esc_html_e( 'Apágalo para borrar sus datos.', 'lachinata-core' ); ?></span>
								<?php else : ?>
									<a href="<?php echo esc_url( Screen::url( 'modules', array( 'delete' => $id ) ) ); ?>"><?php esc_html_e( 'Borrar datos…', 'lachinata-core' ); ?></a>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<?php submit_button( __( 'Guardar cambios', 'lachinata-core' ) ); ?>
		</form>
		<?php
	}

	/**
	 * Saves the enabled modules. Ids of modules this installation does not know are kept.
	 */
	public static function save(): void {
		Screen::check( self::ACTION );
		$registry = Plugin::instance()->modules();
		$checked  = isset( $_POST['modules'] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST['modules'] ) ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Screen::check().
		foreach ( $registry->all() as $id => $module ) {
			if ( in_array( $id, $checked, true ) ) {
				$registry->enable( $id );
			} else {
				$registry->disable( $id );
			}
		}
		Screen::flash( 'success', array( __( 'Módulos guardados.', 'lachinata-core' ) ) );
		Screen::redirect( 'modules' );
	}

	/**
	 * Confirmation of «Borrar datos» for a module that is off.
	 *
	 * @param Module $module Module.
	 */
	private static function render_delete( Module $module ): void {
		$owned = $module->owned_data();
		$meta  = array_merge( $owned['product_meta'] ?? array(), $owned['term_meta'] ?? array(), $owned['user_meta'] ?? array() );
		?>
		<h2>
			<?php
			/* translators: %s: module name. */
			echo esc_html( sprintf( __( 'Borrar los datos de %s', 'lachinata-core' ), $module->label() ) );
			?>
		</h2>
		<p>
			<?php
			/* translators: %s: option prefix (lachinata_gift_*). */
			echo esc_html( sprintf( __( 'Se borran sus ajustes y opciones (%s), sus datos temporales y, si los tiene, sus campos de productos, categorías y usuarios. No se borra nada de los pedidos: es su historial y Odoo lo lee.', 'lachinata-core' ), 'lachinata_' . $module->id() . '_*' ) );
			?>
		</p>
		<?php if ( $meta ) : ?>
			<p>
				<?php
				/* translators: %s: meta keys. */
				echo esc_html( sprintf( __( 'Campos que se borran: %s.', 'lachinata-core' ), implode( ', ', $meta ) ) );
				?>
			</p>
		<?php endif; ?>
		<p><?php esc_html_e( 'Antes de borrar se descarga su configuración en JSON, como copia que se puede importar en La Chinata → Exportar e importar. Las credenciales no van en la copia.', 'lachinata-core' ); ?></p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-lc-back="<?php echo esc_url( Screen::url( 'modules' ) ); ?>" onsubmit="var f=this;setTimeout(function(){window.location=f.dataset.lcBack;},2000);">
			<input type="hidden" name="action" value="<?php echo esc_attr( self::DELETE ); ?>">
			<input type="hidden" name="module" value="<?php echo esc_attr( $module->id() ); ?>">
			<?php wp_nonce_field( self::DELETE ); ?>
			<p>
				<label for="lc-confirm">
					<?php
					/* translators: %s: module id. */
					echo esc_html( sprintf( __( 'Escribe %s para confirmar:', 'lachinata-core' ), $module->id() ) );
					?>
				</label>
				<input type="text" id="lc-confirm" name="confirm" class="regular-text" autocomplete="off" required>
			</p>
			<?php submit_button( __( 'Descargar la copia y borrar los datos', 'lachinata-core' ), 'delete' ); ?>
			<p><a href="<?php echo esc_url( Screen::url( 'modules' ) ); ?>"><?php esc_html_e( 'Cancelar', 'lachinata-core' ); ?></a></p>
		</form>
		<?php
	}

	/**
	 * Deletes a module's data after sending its JSON copy as the response.
	 */
	public static function delete(): void {
		Screen::check( self::DELETE );
		$registry = Plugin::instance()->modules();
		$id       = isset( $_POST['module'] ) ? sanitize_key( wp_unslash( $_POST['module'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Screen::check().
		$confirm  = isset( $_POST['confirm'] ) ? sanitize_key( wp_unslash( $_POST['confirm'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Screen::check().
		$module   = $registry->get( $id );
		if ( null === $module || in_array( $id, $registry->enabled(), true ) ) {
			Screen::flash( 'error', array( __( 'Solo se borran los datos de un módulo apagado.', 'lachinata-core' ) ) );
			Screen::redirect( 'modules' );
		}
		if ( $confirm !== $id ) {
			Screen::flash( 'error', array( __( 'No coincide el texto de confirmación: no se ha borrado nada.', 'lachinata-core' ) ) );
			Screen::redirect( 'modules', array( 'delete' => $id ) );
		}

		$json    = Exporter::to_json( Exporter::export( $registry, array( $id ) ) );
		$deleted = $registry->delete_data( $module );
		Screen::flash(
			'success',
			array(
				sprintf(
					/* translators: 1: module name, 2: options deleted, 3: field values deleted. */
					__( 'Datos de %1$s borrados: %2$d opciones y %3$d valores de campos. La copia se ha descargado.', 'lachinata-core' ),
					$module->label(),
					$deleted['options'],
					$deleted['meta']
				),
			)
		);

		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="lachinata-' . $id . '-' . gmdate( 'Ymd-His' ) . '.json"' );
		echo $json; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON download, not HTML.
		exit;
	}
}
